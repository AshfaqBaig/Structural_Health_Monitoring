# Introduction 

Terraform scripts for constructing deployment manifest and pushing it to IotHub edge
# Deployment manifest layers

| Layer | Modules | Description |
| --- | --- | --- |
| calibration | `image-grabber-*` | Layer used for calibration of cameras |
| capture-archive | `image-grabber-*`, `file-archiver-*` | Layer for capturing and archiving the data. Deprecated |
| capture | `image-grabber-*`, `edge-detection-*`, `edge-verification-*`, `material-classification-*` | Layer for capturing and processing single camera's input |
| core | `edgeAgent`, `edgeHub`, `telegraf-agent` | Core layer |
| sample | `mqtt-simulator`, `mqtt-sample` | Sample layer for testing |
| support | `decision-maker`, `laser-feedback`, `laser-hub`, `file-router` | Layer for supporting activities. Modules able to work with different camera simultaniously |