#!/bin/sh

for resource in $(terraform state list); do
    terraform state rm $resource;
  done