# Azure components

[[_TOC_]]

## Dev environment

| Component                                            | Type            | SKU             | Name                   | Resource name                             | Resource group     |
| ---------------------------------------------------- | --------------- | --------------- | ---------------------- | ----------------------------------------- | ------------------ |
| IoT Hub                                              | IoT_Hub         | F1              | iot-hub-dev-sgre       | IOTDEVDVLGENOBAWE01-iot-hub-dev-sgre      | RGDEVDVLGENOBAWE01 |
| Blob storage for ML                                  | Storage         | Standard_LRS    | storml                 | stdevdvlgenobawe01storml                  | RGDEVDVLGENOBAWE01 |
| Container registry                                   | Docker_Registry | Basic           | iothubacr              | ACRDEVDVLGENOBAWE01iothubacr              | RGDEVDVLGENOBAWE01 |
| A simple VM to emulate deployments to Azure IoT Edge | VM              | Standard_D2d_v4 | edge-test-vm           | VMDEVDVLGENOBAWE01-edge-test-vm           | RGDEVDVLGENOBAWE01 |
| Load balancer to access VM                           | LB              | Basic           | edge-test              | LBTDEVDVLGENOBAWE01-edge-test             | RGDEVDVLGENOBAWE01 |
| Load balancer public IP                              | IP              | Basic           | iot-edge-vnet-ip-basic | VNDEVDVLGENOBAWE01-iot-edge-vnet-ip-basic | RGDEVDVLGENOBAWE01 |
| Vnet                                                 | VNET            | Free            | iot-edge-vnet          | VNDEVDVLGENOBAWE01-iot-edge-vnet          | RGDEVDVLGENOBAWE01 |
| Subnet                                               | Subnet          | Free            | iot-edge-subnet        | SBDEVDVLGENOBAWE01-iot-edge-subnet        | RGDEVDVLGENOBAWE01 |
| Network security group                               | NSG             | Free            | iot-edge-nsg           | VMDEVDVLGENOBAWE01-edge-test-vm-nsg       | RGDEVDVLGENOBAWE01 |
| Blob storage for cloud shell                         | Storage         | Standard_LRS    | cldsh                  | stdevdvlgenobawe01cldsh                   | RGDEVDVLGENOBAWE01 |
| Machine Learning studio                              | ML_studio       | Standard        | ml                     | MLDEVDVLGENOBAWE01-ml                     | RGDEVDVLGENOBAWE01 |
| Key Vault for ML studio                              | Keyvault        | Standard        | kv-ml                  | KVDEVDVLGENOBAWE01-kv-ml                  | RGDEVDVLGENOBAWE01 |
| Blob storage for labeling data                       | Storage         | Standard_LRS    | lblng                  | stdevdvlgenobawe01lblng                   | RGDEVDVLGENOBAWE01 |
| Blob storage for data captured at initial stage      | Storage         | Stan dard_LRS   | testio                 | stdevdvlgenobawe01testio                  | RGDEVDVLGENOBAWE01 |

## MVP environment

| Component                                         | Type          | SKU           | Name              | Resource name                         | Resource group     |
| ------------------------------------------------- | ------------- | ------------- | ----------------- | ------------------------------------- | ------------------ |
| IoT Hub                                           | IoT_Hub       | S1            | iot-hub-test-sgre | IOTDEVDVLGENOBAWE01-iot-hub-test-sgre | RGDEVDVLGENOBAWE01 |
| Application insights                              | App_insights  | Pay as you go | ain-ml            | AINDEVDVLGENOBAWE01-ain-ml            | RGDEVDVLGENOBAWE01 |
| Log analytics                                     | Log_analytics | Pay as you go | edge-logs         | LA-DEV-DVL-GEN-WE01-edge-logs         | RGDEVDVLGENOBAWE01 |
| Blob storage for retraining data                  | Storage       | Standard_LRS  | mvpdev            | stdevdvlgenobawe01mvpdev              | RGDEVDVLGENOBAWE01 |
| Blob storage for sharing data to the edge servers | Storage       | Standard_LRS  | mvpedg            | stdevdvlgenobawe01mvpedg              | RGDEVDVLGENOBAWE01 |
| Blob storage for terraform state                  | Storage       | Standard_LRS  | trrfrm            | stdevdvlgenobawe01trrfrm              | RGDEVDVLGENOBAWE01 |
