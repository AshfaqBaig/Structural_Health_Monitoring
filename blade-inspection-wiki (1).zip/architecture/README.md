# Architecture overview

- [Architecture overview](#architecture-overview)
  - [Introduction](#introduction)
  - [Overview](#overview)
    - [Production process overview](#production-process-overview)
    - [Development process overview](#development-process-overview)
  - [Detailed architecture](#detailed-architecture)

## Introduction

This document defines IT solution for quality assurance of blade manufacture by using visual image recognition. Images are captured continuously during the manufacture of blades and are processed at the factory location using a pipeline of Machine Learning algorithms which identify potential manufacture deviations. Processed images are
 stored in Azure Cloud, where they could be used for further Machine Learning improvements. System metrics are captured and displayed at Azure Monitor dashboards.

The document provides overview of functional part of solution components and their overview interaction between components. Detailed design of each component is presented in  [Functional architecture document](./2.functional-architecture.md).

Non-functional aspects of the solution are covered at the high level where applicable.

## Overview

The solution uses imagery captured by cameras located over the manufactured objects so they cover the whole surface. The images are processed by various pipelines of Deep Learning components deployed at the Edge server and generating output according to the user stories. As per current phase the output consists of just metadata describing detected cases and images corresponding to each case. Processed data is converted into instructions to the laser beamer to aid manufacture process by pointing to the findings discovered by Machine Learning modules.  

### Production process overview

![Solution overview](../.attachments/architecture/diagrams/solution-overview-run/Solution%20overview%20run.svg)

Production process is based on the images are captured using external cameras. The cameras are connected to edge servers(many to one). There are multiple edge server, each of them runs identical set of edge components, which do the following activities:

- Camera API modules use camera SDK to capture images from cameras
- Image pre-processing modules encapsulate logic not related to machine learning tasks
- Machine Learning modules which execute various detection activities such as edge detection, foreign object detections, etc
- Image post-processing module(s) which do final image preparation before moving to the cloud as well as communication with the laser subsystem
- Pre and Post-processed images are uploaded to the cloud for for model re-training
- Events emitted directly by edge modules or via IoT Hub are displayed at Monitoring Dashboard 

### Development process overview

![Development overview](../.attachments/architecture/diagrams/solution-overview-dev/Solution%20overview%20dev.svg)

Images captured by the cameras are used to re-train Machine Learning models as per the diagram above. The key concepts of the diagram:

- Captured images are uploaded to the Training datasets based on Azure Blob storage at the cloud
- Azure Mashine Learning studio activities are initialised by Data scientists to train new models based on captured images using VM worker nodes
- New and re-trained ML models are stored to Git repository
- Data scientists at their discretion initialise DevOps pipelines to package and store ML models to the dedicated Azure Blob store. The format of the models conforms to the requirements of Inference service running at every edge server
- ML models at the Blob store are synced to the edge servers using scheduling mechanism
- Edge modules use updated ML models by calling Inference service that balances load of GPUs available at the edge server

## Detailed architecture

The following pages specify architectural details for the solution:

- [System context](./1.functional-context.md)
- [Functional architecture](./2.functional-architecture.md)
- [Operational architecture](./3.operational-architecture.md)
- [Architectural decisions](./4.architectural-decisions.md)
- [Architecture backlog](./5.architecture-backlog.md)
- [DevOps](./6.devops.md)
