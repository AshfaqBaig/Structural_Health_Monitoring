# Initial data set capture

This section defines setup for initial dataset capture

- [Initial data set capture](#initial-data-set-capture)
  - [Architecture overview](#architecture-overview)
  - [Decisions](#decisions)
    - [[Open] Access to edge server](#open-access-to-edge-server)
    - [[Open] file naming](#open-file-naming)
    - [[Open] Folder structure and file allocation convention](#open-folder-structure-and-file-allocation-convention)
  - [Guidance](#guidance)
  - [Modules](#modules)
    - [Image capture](#image-capture)
    - [Thumbnail generator (not used)](#thumbnail-generator-not-used)
    - [Video generator(tbd)](#video-generatortbd)
    - [Cloud uploader(tbd)](#cloud-uploadertbd)
    - [Archiver](#archiver)
    - [Data downloader](#data-downloader)
  - [Cloud](#cloud)
  - [Monitoring](#monitoring)
  - [Infrastructure](#infrastructure)

## Architecture overview

![Initial data capture](../.attachments/architecture/diagrams/initial-data-capture-overview/inital-data-capture.svg)

This is the generic flow of data from a single camera to the cloud. For multiple cameras setup some components might be shared between cameras. Each component definition species multi-cameras support. Singe camera components to be run as separate processes.

## Decisions

### [Open] Access to edge server

How to access edge server:

1. Connecting using Team Viewer to jump server located in the same network where edge server is located
   1. [+] No port forwarding to the edge server is needed
   2. [+] Quick setup
   3. [+] In case of failures, may only need to restart the server
   4. [-] Team viewer might be not reliable
   5. [-] Short term solution
2. Creating a Point-to-Site VPN connection to Azure and use Azure VM as a jump server
   1. [+] Secure
   2. [+] Re-usable in the future
   3. [+] Could be re-used in the future
   4. [-] More effort to setup
   5. [-] In case of failure a restart might not be enough, so operator's involvement is needed

### [Open] file naming

### [Open] Folder structure and file allocation convention

## Guidance

- It is not recommended to keep more than 10000 of files per folder because of wild card limitations in shell. It can also reduce performance of scripts which list files in a folder.

## Modules

### Image capture

Image capture module connects to a camera and captures images at the pre-defined rate. Images are stored to the local file system. The module should support the following parameters. Parameters having no default values are mandatory

| Parameter   | Default value                             | Description                                                                |
| ----------- | ----------------------------------------- | -------------------------------------------------------------------------- |
| camera_id   | --                                        | Logical ID assigned to the camera                                          |
| camera_ip   | --                                        | IP address of camera to connect                                            |
| res_x       | camera default value                      | Captured image width in pixels                                             |
| res_y       | camera default value                      | Captured image height in pixels                                            |
| fps         | 3.3                                       | Number of frames to capture per second                                     |
| compression | jpeg                                      | Compression type of captured images                                        |
| dest_folder | ./camera-{camera_id}/                     | Folder to store captured images to                                         |
| dest_file   | raw-{camera_id}-{timestamp}.{compression} | Pattern for file names. Currently used as DEV_{MAC_ADDR}_{camera_hz_clock} |
| log_file    | /var/logs/capture-camera-{camera_id}.log  | File location for log output. Currently not used                           |
| log_level   | INFO                                      | Level of log records for storage. Currently not used                       |

Module settings matrix:

| Camera | camera_id | camera_ip    | dest_folder                                  | dest_file |
| ------ | --------- | ------------ | -------------------------------------------- | --------- |
| Cam01  | 008-017   | 192.168.8.20 | /home/optical/iot-work-volume/camera-008-017 | default   |
| Cam02  | 008-018   | 192.168.8.26 | /home/optical/iot-work-volume/camera-008-018 | default   |
| Cam03  | 008-016   | 192.168.8.22 | /home/optical/iot-work-volume/camera-008-016 | default   |
| Cam04  | 008-015   | 192.168.8.27 | /home/optical/iot-work-volume/camera-008-015 | default   |
| Cam05  | 008-014   | 192.168.8.24 | /home/optical/iot-work-volume/camera-008-014 | default   |
| Cam06  | 008-011   | 192.168.8.19 | /home/optical/iot-work-volume/camera-008-011 | default   |
| Cam07  | 008-010   | 192.168.8.23 | /home/optical/iot-work-volume/camera-008-010 | default   |
| Cam08  | 008-013   | 192.168.8.21 | /home/optical/iot-work-volume/camera-008-013 | default   |
| Cam09  | 008-012   | 192.168.8.25 | /home/optical/iot-work-volume/camera-008-012 | default   |
| Cam10  | 008-019   | 192.168.8.29 | /home/optical/iot-work-volume/camera-008-019 | default   |

### Thumbnail generator (not used)

Thumbnail generator modules uses raw images to generate low resolution images to facilitate captured data sorting and filtering
The module should support the following parameters. Parameters having no default values are mandatory:

| Parameter      | Default value              | Description                                                                 |
| -------------- | -------------------------- | --------------------------------------------------------------------------- |
| process_id     | --                         | Id of process                                                               |
| source_folder  | --                         | File folder to get images                                                   |
| dest_folder    | --                         | Folder to store generated thumbnails                                        |
| archive_folder | --                         | Folder to archive original images. No archive if empty                      |
| res_x          | ???                        | Captured image width in pixels                                              |
| res_y          | ???                        | Captured image height in pixels                                             |
| log_file       | /var/logs/{process_id}.log | File location for log output                                                |
| log_level      | INFO                       | Level of log records for storage                                            |
| process_delay  | 5                          | Time in seconds to wait from the file creation time to start its processing |

Module settings matrix:

| process_id  | source_folder                                | dest_folder                                  | archive_folder                     |
| ----------- | -------------------------------------------- | -------------------------------------------- | ---------------------------------- |
| thumbs-0001 | /home/optical/iot-work-volume/camera-008-017 | /mnt/nfs_share/camera_archive/camera-008-017 | /archive-image-storage/camera-0001 |

### Video generator(tbd)

### Cloud uploader(tbd)

### Archiver

Archiver component moves files from one folder to another and potentially makes an archive copy.
The module should support the following parameters. Parameters having no default values are mandatory:

| Parameter           | Default value              | Description                                                                 |
| ------------------- | -------------------------- | --------------------------------------------------------------------------- |
| process_id          | --                         | Id of process                                                               |
| source_folder       | --                         | File folder to get images                                                   |
| dest_folder         | --                         | Folder to copy images                                                       |
| archive_folder      | --                         | Folder to move images. No archive if empty                                  |
| log_file            | /var/logs/{process_id}.log | File location for log output                                                |
| log_level           | INFO                       | Level of log records for storage                                            |
| process_delay       | 1                          | Time in seconds to wait from the file creation time to start its processing |
| max_files_per_cycle | -1                         | Maximum number of files to process per cycle. -1 means all available files  |
| sort_order          | inc_time                   | File sort order in format [inc/dec]_[time/size/name]                        |

Module settings matrix:

| process_id       | source_folder                                | dest_folder                                  |
| ---------------- | -------------------------------------------- | -------------------------------------------- |
| archiver-008-012 | /home/optical/iot-work-volume/camera-008-012 | /mnt/nfs_share/camera_archive/camera-008-012 |

other camera folders are defined as per above examples

### Data downloader

This component will download files from blob storage to a local machine or to another blob storage location

## Cloud

Storage to be created in the cloud:
| Name       | Level | Redundancy | Access | Description                                                          |
| ---------- | ----- | ---------- | ------ | -------------------------------------------------------------------- |
| Raw images | Cool  | Zone       | RO     | Archive storage for raw images.                                      |
| Thumbnails | Hot   | Local      | RW     | Low resolution images generated from raw images for quick navigation |
| Videos     | Hot   | Local      | RW     | Videos generated from thumbnails for quick activity detection        |

Guidance:

- Raw images. Should be accessible only to copy data for further processing. According to the storage level, should remain at least for a month. Will be reviewed for further actions after project's phase completion

## Monitoring

Since each archiver module send cloud messages after each processed file, these messages are uses as heartbeats for images capture. Azure Monitor is setup up to raise an alert when number of received messages per second is lower than typical for a predefined time period. I.e. each camera generates 198 images per minute in average which makes 1980 images for 10 cameras. Setting alert to fire in case amount of messages dr Given networking throughput irregularity o

## Infrastructure

Network shared drive is mounted using the following command:

```sh
sudo moung 192.168.8.251:/mnt/data/sgre /mnt/nfs_share
```
