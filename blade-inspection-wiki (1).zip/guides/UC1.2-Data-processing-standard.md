# Image coordinates

**columns** :

| (u,v) | point_id | cross_id | dxf_design | file_name | meters | camera_id |
| ----- | -------- | -------- | ---------- | --------- | ------ | --------- |

- (u,v) --> image coordinates
- point_id --> one of [P1,P2,P3,P4,P5], the 5 points that included in a 'Point' Label, it may not always contain 5 elements.
- Cross_id --> number the crosses from top to bottom or left to right
- dxf_design --> what is the corresponding dxf design 
- file_name --> file name of this image
- meters --> the physical meters where the image was taken
- camera_id --> which camera took this image
![image (1).png](../.attachments/image%20(1)-8e44c280-b7bd-41b2-888f-ed167933190f.png)

**Note** :

- Images that not all 11 markers are fully visible will be ignored.
