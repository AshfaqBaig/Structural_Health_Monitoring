#!/bin/bash

cmd_arg=$1
echo "Command given : $1, $cmd_arg";

IOT_HUB_NAME="IOTDEVDVLGENOBAWE01-iot-hub-test-sgre"
JOB_ID="2020-12-16-09-s"

declare -a EDGE=("EDDEVDVLGENOBAWE01-mvp-edge-1" "EDDEVDVLGENOBAWE01-mvp-edge-2" "EDDEVDVLGENOBAWE01-mvp-edge-3" "EDDEVDVLGENOBAWE01-mvp-edge-4")
declare -a EDGE_HOST=("edge1" "edge2" "edge3" "edge4")

declare -a EDGE1_CAM_NAME=("cam-aal-h08-013" "cam-aal-h08-014" "cam-aal-h08-015" "cam-aal-h08-016" "cam-aal-h08-017" )

declare -a EDGE2_CAM_NAME=("cam-aal-h08-018" "cam-aal-h08-019" "cam-aal-h08-020" "cam-aal-h08-021" "cam-aal-h08-022" )

declare -a EDGE3_CAM_NAME=("cam-aal-h08-023" "cam-aal-h08-024" "cam-aal-h08-025" "cam-aal-h08-026" "cam-aal-h08-027" )

declare -a EDGE4_CAM_NAME=("cam-aal-h08-028" "cam-aal-h08-029" "cam-aal-h08-030" "cam-aal-h08-031" "cam-aal-h08-032" )

# declare -a EDGE1_CAM_NAME=("cam-aal-h08-013" "cam-aal-h08-013" "cam-aal-h08-014" "cam-aal-h08-015" "cam-aal-h08-016" "cam-aal-h08-017" "cam-aal-h08-018" "cam-aal-h08-019" \
# "cam-aal-h08-020" "cam-aal-h08-021" "cam-aal-h08-022" "cam-aal-h08-023" "cam-aal-h08-024" "cam-aal-h08-025" "cam-aal-h08-026" "cam-aal-h08-027" "cam-aal-h08-028" \
# "cam-aal-h08-029" "cam-aal-h08-030" "cam-aal-h08-031" "cam-aal-h08-032")

# az_cmd () {
#    echo "Call azure command with payload $1 "
#     for i in "${CAM_NAME[@]}"
#     do
#         echo "Setting job id for camera $i..."
#         az iot hub module-twin update --device-id $EDGE --module-id image-grabber-$i --hub-name $IOT_HUB_NAME --set properties.desired=$1
#         sleep 10s
#     done
# }


if [ "$cmd_arg" = "on" ]; then
    echo "Set corrent job id to $JOB_ID"
    PAYLOAD='{"JOB_ID":"'${JOB_ID}'"}'

    for i in "${EDGE1_CAM_NAME[@]}"
    do
        echo "Setting job id for camera $i..."
        az iot hub module-twin update --device-id ${EDGE[0]} --module-id image-grabber-$i --hub-name $IOT_HUB_NAME --set properties.desired=$PAYLOAD
        sleep 10s
    done

    # for i in "${EDGE2_CAM_NAME[@]}"
    # do
    #     echo "Setting job id for camera $i..."
    #     az iot hub module-twin update --device-id ${EDGE[1]} --module-id image-grabber-$i --hub-name $IOT_HUB_NAME --set properties.desired=$PAYLOAD
    #     sleep 10s
    # done

    # for i in "${EDGE3_CAM_NAME[@]}"
    # do
    #     echo "Setting job id for camera $i..."
    #     az iot hub module-twin update --device-id ${EDGE[2]} --module-id image-grabber-$i --hub-name $IOT_HUB_NAME --set properties.desired=$PAYLOAD
    #     sleep 10s
    # done

    # for i in "${EDGE4_CAM_NAME[@]}"
    # do
    #     echo "Setting job id for camera $i..."
    #     az iot hub module-twin update --device-id ${EDGE[3]} --module-id image-grabber-$i --hub-name $IOT_HUB_NAME --set properties.desired=$PAYLOAD
    #     sleep 10s
    # done
else
    echo "OFF command is set skipping jobid setting...."
fi


if [ "$cmd_arg" = "on" ]; then
    PAYLOAD='{"command":"on"}'
else
    PAYLOAD='{"command":"off"}'
fi

echo "Starting streams... $PAYLOAD"

# echo "Starting streams..."
# PAYLOAD='{"command":"on"}'

for i in "${EDGE1_CAM_NAME[@]}"
do
    echo "Setting job id for camera $i..."
    az iot hub module-twin update --device-id ${EDGE[0]} --module-id image-grabber-$i --hub-name $IOT_HUB_NAME --set properties.desired=$PAYLOAD
    sleep 10s
done

# for i in "${EDGE2_CAM_NAME[@]}" 
# do
#     echo "Setting job id for camera $i..."
#     az iot hub module-twin update --device-id ${EDGE[1]} --module-id image-grabber-$i --hub-name $IOT_HUB_NAME --set properties.desired=$PAYLOAD
#     sleep 10s
# done

# for i in "${EDGE3_CAM_NAME[@]}"
# do
#     echo "Setting job id for camera $i..."
#     az iot hub module-twin update --device-id ${EDGE[2]} --module-id image-grabber-$i --hub-name $IOT_HUB_NAME --set properties.desired=$PAYLOAD
#     sleep 10s
# done

# for i in "${EDGE4_CAM_NAME[@]}"
# do
#     echo "Setting job id for camera $i..."
#     az iot hub module-twin update --device-id ${EDGE[3]} --module-id image-grabber-$i --hub-name $IOT_HUB_NAME --set properties.desired=$PAYLOAD
#     sleep 10s
# done


