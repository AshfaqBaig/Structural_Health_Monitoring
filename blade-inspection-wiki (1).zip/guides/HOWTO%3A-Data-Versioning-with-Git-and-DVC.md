# Data and Model Versioning with Git and DVC

All development datasets used for training, validation and testing are stored in the blob container *dvc-datasets*. (The models ready for deployment are
stored in the blob container dvc-models). Note that these containers are DVC storages, so having direct access to datasets or models is impossible. DVC
and Git will track and version datasets and models. To download a dataset/model one needs to use Git and DVC. Below is the outline of how to create,
update (add) dataset/model to Git and DVC repositories, as well as how to clone and checkout (download) specific versions of datasets/models.

1. Install DVC
2. Initialize dataset/model repository
3. Add data/model
4. Add version tags
5. Remove tags
6. Clone (download) dataset/model of a specific version

## DVC Setup

    pip install dvc[azure]
    dvc config core.analytics false --global

## Initialize and configure Git repositories
This step maybe skipped if the repo already exists, in which case clone it

    git init
    touch README.md
    git add README.md
    git commit -m "README file added"
    git remote add origin 'repo_link'

## Configure DVC remote

    dvc init
    git add -A
    git commit -m "Initialized DATASET_NAME repository"
    
    dvc remote add -d origin azure://dvc-datasets/DATASET_NAME
    dvc remote modify --local origin connection_string 'your_connection_string'
    git add -A
    git commit  -m "Azure remote configured"

Push Git commits:

    git push -u origin --all

Note: the connection string will not be pushed. It can be also provided with env variable at the time you want to pull/push data

    export AZURE_STORAGE_CONNECTION_STRING="your_connection_string"

## Add data

Copy data to the dataset/model directory and add it to DVC and git. If required, add a version tag:

    # Hint: all 3 folders are required
    dvc add splitset trainset
    git add splitset.dvc trainset.dvc .gitignore
    git commit -m "Baseline model data -> train: 60, valid: 8, test: 8"
    dvc push

## Add version tags

    git tag -a "v1.0.0" -m "Baseline model data -> train: 60, valid: 8, test: 8"
    git push origin master --tags

## Remove version tags

    # local
    git tag -d v1.0
    # remote
    git push --delete origin v1.0

## Clone (download) datasetl repo and checkout a specific dataset version

    git clone 'repo_link'
    cd DATASET_NAME
    git checkout v1.1.0
    dvc pull