#!/bin/bash
IOT_HUB_NAME="IOTDEVDVLGENOBAWE01-iot-hub-test-sgre"
CAM03_EDGE="EDDEVDVLGENOBAWE01-mvp-edge-1"
CAM04_EDGE="EDDEVDVLGENOBAWE01-mvp-edge-2"
CAM05_EDGE="EDDEVDVLGENOBAWE01-mvp-edge-4"
CAM03_NAME="cam03"
CAM04_NAME="cam04"
CAM05_NAME="cam05"


echo "Stopping streams..."
PAYLOAD='{"command":"off"}'
echo "Stopping camera $CAM03_NAME..."
az iot hub module-twin update --device-id $CAM03_EDGE --module-id image-grabber-$CAM03_NAME --hub-name $IOT_HUB_NAME \
  --set properties.desired=$PAYLOAD
echo "Stopping camera $CAM04_NAME..."
az iot hub module-twin update --device-id $CAM04_EDGE --module-id image-grabber-$CAM04_NAME --hub-name $IOT_HUB_NAME \
  --set properties.desired=$PAYLOAD
echo "Stopping camera $CAM05_NAME..."
az iot hub module-twin update --device-id $CAM05_EDGE --module-id image-grabber-$CAM05_NAME --hub-name $IOT_HUB_NAME \
  --set properties.desired=$PAYLOAD
echo "All streams stopped"
echo "Done"