#!/bin/bash
IOT_HUB_NAME="IOTDEVDVLGENOBAWE01-iot-hub-test-sgre"
JOB_ID="2020-12-16-09-s"
CAM03_EDGE="EDDEVDVLGENOBAWE01-mvp-edge-1"
CAM04_EDGE="EDDEVDVLGENOBAWE01-mvp-edge-2"
CAM05_EDGE="EDDEVDVLGENOBAWE01-mvp-edge-4"
CAM03_HOST="edge1"
CAM04_HOST="edge2"
CAM05_HOST="edge4"
CAM03_NAME="cam03"
CAM04_NAME="cam04"
CAM05_NAME="cam05"

echo 'Cleaning up job id in etcd'
ssh $CAM04_HOST 'etcdctl del '$JOB_ID' --prefix'
echo 'etcd cleanup done'

echo 'Cleaning edge-verification debug folder...'
#echo "Cleaning edge-verification-$CAM03_NAME debug folder..."
#ssh $CAM03_HOST 'sudo rm -rf /mnt/data/iot-work-volume/edge-verification-output/*'
echo "Cleaning edge-verification-$CAM04_NAME debug folder..."
ssh $CAM04_HOST 'sudo rm -rf /mnt/data/iot-work-volume/edge-verification-output/*'
echo "Cleaning edge-verification-$CAM05_NAME debug folder..."
ssh $CAM05_HOST 'sudo rm -rf /mnt/data/iot-work-volume/edge-verification-output/*'
echo 'All edge-verification modules cleanup done'

echo 'Restarting edge-verification modules...'
#echo "Restarting edge-verification-$CAM03_NAME module..."
#ssh $CAM03_HOST 'iotedge restart edge-verification-'$CAM03_NAME
echo "Restarting edge-verification-$CAM04_NAME module..."
ssh $CAM04_HOST 'iotedge restart edge-verification-'$CAM04_NAME
echo "Restarting edge-verification-$CAM05_NAME module..."
ssh $CAM05_HOST 'iotedge restart edge-verification-'$CAM05_NAME


echo 'Restarting decision-maker modules...'
#echo "Restarting decision-maker module for $CAM04_NAME..."
#ssh $CAM03_HOST 'iotedge restart decision-maker'
echo "Restarting decision-maker module for $CAM04_NAME..."
ssh $CAM04_HOST 'iotedge restart decision-maker'
echo "Restarting decision-maker module for $CAM05_NAME..."
ssh $CAM05_HOST 'iotedge restart decision-maker'
echo 'All decision-maker modules restarted'

echo "Set corrent job id to $JOB_ID"
PAYLOAD='{"JOB_ID":"'${JOB_ID}'"}'

# echo "Setting job id for camera $CAM03_NAME..."
# az iot hub module-twin update --device-id $CAM03_EDGE --module-id image-grabber-$CAM03_NAME --hub-name $IOT_HUB_NAME \
# --set properties.desired=$PAYLOAD

echo "Setting job id for camera $CAM04_NAME..."
az iot hub module-twin update --device-id $CAM04_EDGE --module-id image-grabber-$CAM04_NAME --hub-name $IOT_HUB_NAME \
--set properties.desired=$PAYLOAD

echo "Setting job id for camera $CAM05_NAME..."
az iot hub module-twin update --device-id $CAM05_EDGE --module-id image-grabber-$CAM05_NAME --hub-name $IOT_HUB_NAME \
--set properties.desired=$PAYLOAD


echo "Starting streams..."
PAYLOAD='{"command":"on"}'
# echo "Starting camera $CAM03_NAME..."
# az iot hub module-twin update --device-id $CAM03_EDGE --module-id image-grabber-$CAM03_NAME --hub-name $IOT_HUB_NAME \
# --set properties.desired=$PAYLOAD

echo "Starting camera $CAM04_NAME..."
az iot hub module-twin update --device-id $CAM04_EDGE --module-id image-grabber-$CAM04_NAME --hub-name $IOT_HUB_NAME \
--set properties.desired=$PAYLOAD

echo "Starting camera $CAM05_NAME..."
az iot hub module-twin update --device-id $CAM05_EDGE --module-id image-grabber-$CAM05_NAME --hub-name $IOT_HUB_NAME \
--set properties.desired=$PAYLOAD

echo "All streams started"

echo "Configuring edge-verification modules parameters..."
# az iot hub module-twin update \
#      --device-id $CAM03_EDGE --module-id edge-verification-$CAM03_NAME  --hub-name $IOT_HUB_NAME \
#      --set properties.desired='{"TOLERANCE":30, "REGION_OF_VERIFICATION": 30, "REDUCE_MASK_BY":500, "NOISE_SIZE_THRESHOLD":300 }'
az iot hub module-twin update \
      --device-id $CAM04_EDGE --module-id edge-verification-$CAM04_NAME --hub-name $IOT_HUB_NAME \
      --set properties.desired='{"TOLERANCE":35, "REGION_OF_VERIFICATION": 30, "REDUCE_MASK_BY":700, "NOISE_SIZE_THRESHOLD":500 }'
# az iot hub module-twin update \
#      --device-id $CAM05_EDGE --module-id edge-verification-$CAM05_NAME --hub-name $IOT_HUB_NAME \
#      --set properties.desired='{"TOLERANCE":30, "REGION_OF_VERIFICATION": 30, "REDUCE_MASK_BY":500, "NOISE_SIZE_THRESHOLD":500 }'
echo "edge-verification modules configuration done"

echo "Done"
