# Training on Edge with Azure ML

The following example will be based on edge-detection model training and assume you start from scratch on a new device, but corresponding code and data repositories already exist.

## Setup
Install miniconda to your home:
```
wget https://repo.anaconda.com/miniconda/Miniconda3-latest-Linux-x86_64.sh
bash Miniconda3-latest-Linux-x86_64.sh
```
restart bash and set:
```
conda config --set auto_activate_base false
```

Create code and data directories in your home:
```
mkdir code
mkdir data
```

Change to code and clone ml-edge-detection repo:
```
cd code
git clone https://SGRE-IBM@dev.azure.com/SGRE-IBM/BladeInspection/_git/ml-edge-detection
cd ml-edge-detection
git config credential.helper store
```

Change or inspect parameters, e.g., batch size, epochs number, dataset version / branch in start_az.sh script and run it providing GPU id (0,1,2 or 3) to start training on a specified GPU.

`./start_az.sh 0`

Login to Azure ML, start ML Studio and go to your experiment.