# Intro

- [Intro](#intro)
- [Prerequisites](#prerequisites)
- [Commands](#commands)
  - [Starting streaming](#starting-streaming)
  - [Stopping streaming](#stopping-streaming)
  - [Capturing single frame](#capturing-single-frame)
- [Downloading images to local machine](#downloading-images-to-local-machine)
- [Pushing images to the cloud](#pushing-images-to-the-cloud)

This functionality was implemented to simplify testing and have ability to capture images more easily. Using module twin it is possible to control camera capture functionality by starting, stopping the camera or just taking a single snapshot.

# Prerequisites

* Azure CLI toolkit installed

`az`

* Logged into Azure

`az login`

* Correct subscription is selected

`az account set --subscription cbe9d379-0f71-4dbc-994b-804713d41dec`
* IoT Hub deployment is deployed with image capturing modules running as per screenshot

![image.png](../.attachments/guides/image-grabbing/image-ec717c86-8620-4068-babc-c59c6bb6c00f.png)

# Commands

## Starting streaming

Run Azure CLI command to update module twin. Parameters:
* IoTHub name
* Device id 
* Module name corresponding covering [specific camera](/architecture/3.operational-architecture)
* Payload for module twin, which should have command `on`

Example:
```
az iot hub module-twin update \
  --device-id EDDEVDVLGENOBAWE01-dev-edge-device-1 --module-id image-grabber-cam01 --hub-name IOTDEVDVLGENOBAWE01-iot-hub-test-sgre \
  --set properties.desired='{"command":"on"}'
```
Output in module logs:

![image.png](../.attachments/guides/image-grabbing/image-d6e0a831-3086-409a-adea-1c4687480233.png)


## Stopping streaming

Run Azure CLI command to update module twin. Parameters:
* IoTHub name
* Device id
* Module name corresponding covering [specific camera](/architecture/3.operational-architecture)
* Payload for module twin, which should have command `off`

Example:
```
az iot hub module-twin update \
  --device-id EDDEVDVLGENOBAWE01-dev-edge-device-1 --module-id image-grabber-cam01 --hub-name IOTDEVDVLGENOBAWE01-iot-hub-test-sgre \
  --set properties.desired='{"command":"off"}'
```
Output in module logs:

![image.png](../.attachments/guides/image-grabbing/image-3d80b12a-4133-4250-907c-52fa6d410e33.png)

## Capturing single frame

Run Azure CLI command to update module twin. Parameters:
* IoTHub name
* Device id
* Module name corresponding covering [specific camera](/architecture/3.operational-architecture)
* Payload for module twin:
 - `command` attribute value `snapshot`
 - `snapshotMeta` attribute value `snapshotMeta` - this attributes content is saved as json file together with the image. `snapshotMeta.fileSuffix` attribute is optional - if it is specified it will be put as part of image and json file name

Example:
```
az iot hub module-twin update \
  --device-id EDDEVDVLGENOBAWE01-dev-edge-device-1 --module-id image-grabber-cam01 --hub-name IOTDEVDVLGENOBAWE01-iot-hub-test-sgre \
  --set properties.desired='{"command":"snapshot", "snapshotMeta":{"fileSuffix":"justinas-test"}}'
```
Output in module logs:

![image.png](../.attachments/guides/image-grabbing/image-ca784a42-0a02-47d2-87fc-5e1a79276b50.png)

# Downloading images to local machine

Parameters:
* Remote machine and remote folder
* Local machine

Example:
```
scp -r jbedzinskas@edge1:/home/optical/iot-work-volume/camera-cam01/ ./Downloads/.
```

Output:

![image.png](../.attachments/guides/image-grabbing/image-a6a4562f-14c2-423b-8421-fad855c2d831.png)


# Pushing images to the cloud

TODO