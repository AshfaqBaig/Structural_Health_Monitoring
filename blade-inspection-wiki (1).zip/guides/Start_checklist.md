# Layering process initialisation checklist

- [Layering process initialisation checklist](#layering-process-initialisation-checklist)
  - [Blob storage mapping](#blob-storage-mapping)
  - [Camera data check](#camera-data-check)
  - [ML model files](#ml-model-files)
  - [Job scope definition](#job-scope-definition)
  - [Ground truth preparation](#ground-truth-preparation)
    - [DXF file](#dxf-file)
    - [History file](#history-file)
    - [Feedback location file](#feedback-location-file)
  - [Process execution](#process-execution)
    - [Login to Azure](#login-to-azure)
    - [Setting Edge verification parameters](#setting-edge-verification-parameters)
    - [Start/stop camera modules](#startstop-camera-modules)
  - [Scripts for starting/stopping streams](#scripts-for-startingstopping-streams)
    - [Requirements](#requirements)
      - [Mac OX X and Linux systems](#mac-ox-x-and-linux-systems)
      - [Windows](#windows)
    - [IMPORTANT](#important)
  - [Script to start processing](#script-to-start-processing)
  - [Script to stop processing](#script-to-stop-processing)

## Blob storage mapping

All data sources (except of job files) are originally in GIT repository. However edge modules running at edge servers use Azure Blob Storage containers bound to the local edge file system. The following table provides list of mappings at each edge servers used in MVP:

| Azure Blob container                                        | Local file system path    |
| ----------------------------------------------------------- | ------------------------- |
| stdevdvlgenobawe01mvpedg.blob.core.windows.net/cameraparams | `/mnt/azure/cameraparams` |
| stdevdvlgenobawe01mvpedg.blob.core.windows.net/cad          | `/mnt/azure/cad`          |
| stdevdvlgenobawe01mvpedg.blob.core.windows.net/mlmodels     | `/mnt/azure/models`       |

All checklist file path refer to the locally mapped folders

## Camera data check

At each edge server to be used, the following file(s) should be available:

- `/mnt/azure/cameraparams/camera_meta.json`

## ML model files

Mashine Learning models used in edge modules are located at the following folders:

- `/mnt/azure/models/triton` - model repository folder
- `/mnt/data/iot-work-volume/models/triton` - model repository copy used by NVidia Triton server
- `/mnt/azure/models/other` - any other model file

## Job scope definition

Each processing is based on DXF file that defines design of a specific blase. Each DXF files is structured into a list of DXF layers, each layer corresponds to a ply location at the mould.

For each new process a new job file with the unique name(`<job_id>`) should be created:

- `/mnt/azure/cad/jobconfigs/<job_id>.json`

Job file links processing to the specific DXF file name:

```json
{
    "dxfId": "090_B97-00_LP_Outer_B1__merged_with__130_B97-00_LP_Outer_UD1",
    "plies": [
        "221000221",
        "222000222",
        "223000223",
        "224000224",
        "225000225",
        "226000226",
        "227000227",
        "228000228",
        "229000229",
        "230000230",
        "231000231",
        "260000260",
        "261000261",
        "262000262",
        "263000263",
        "264000264",
        "265000265",
        "266000266",
        "267000267",
        "268000268",
        "269000269",
        "270000270"
    ]
}
```

- `dxfId` corresponds to dxf file name without .dxf extension
- `plies` is optional and defines list of ply ids and their layering sequence to be used during processing. If `plies` is not present, `history file` is used to extract all ply ids sorted in alphabetic order.

## Ground truth preparation

### DXF file

As per job definition, a DXF file <dxfId>.dxf should be present at the following location:

- `/mnt/azure/cad/groundtruth/dxf/<dxfId>.dxf`

### History file

For DXF used in job, a ply history file should be in place. This file contains for each camera and each ply in the plan, a list of visible edges at that ply time.

File name is:

- `/mnt/azure/cad/groundtruth/<dxf_id>.history.json`

### Feedback location file

For DXF used in job there should be a file with coordinates of feedback for each ply

- `/mnt/azure/cad/caddata/<dxf_id>.regions.json`

## Process execution

### Login to Azure

`az login`

### Setting Edge verification parameters

edge-verification module might need to be finetuned. In MVPs demo `cam03` and `cam05` was running with default values, but`cam04` was configured with command below:

```bash
  az iot hub module-twin update \
      --device-id EDDEVDVLGENOBAWE01-mvp-edge-2 --module-id edge-verification-cam04 --hub-name IOTDEVDVLGENOBAWE01-iot-hub-test-sgre \
      --set properties.desired='{"TOLERANCE":35, "REGION_OF_VERIFICATION": 30, "REDUCE_MASK_BY":700, "NOISE_SIZE_THRESHOLD":500 }'
```

This logic is incorporated into final start processing script

### Start/stop camera modules

Starting and stopping camera streaming should be usually done with final start/stop processing scripts, anyhow this can be achieved using these commands:

Start `cam03` camera

```bash
az iot hub module-twin update \
  --device-id EDDEVDVLGENOBAWE01-mvp-edge-1 --module-id image-grabber-cam03 --hub-name IOTDEVDVLGENOBAWE01-iot-hub-test-sgre \
  --set properties.desired='{"command":"on", "JOB_ID":"2020-12-15-09-s"}';
```

Stop `cam03` camera

```bash
az iot hub module-twin update \
  --device-id EDDEVDVLGENOBAWE01-mvp-edge-1 --module-id image-grabber-cam03 --hub-name IOTDEVDVLGENOBAWE01-iot-hub-test-sgre \
  --set properties.desired='{"command":"off", "JOB_ID":"2020-12-15-09-s"}';
```

Start `cam04` camera

```bash
az iot hub module-twin update \
  --device-id EDDEVDVLGENOBAWE01-mvp-edge-2 --module-id image-grabber-cam04 --hub-name IOTDEVDVLGENOBAWE01-iot-hub-test-sgre \
  --set properties.desired='{"command":"on", "JOB_ID":"2020-12-15-09-s"}';
```

Stop `cam04` camera

```bash
az iot hub module-twin update \
  --device-id EDDEVDVLGENOBAWE01-mvp-edge-2 --module-id image-grabber-cam04 --hub-name IOTDEVDVLGENOBAWE01-iot-hub-test-sgre \
  --set properties.desired='{"command":"off", "JOB_ID":"2020-12-15-09-s"}';
````

Start `cam05` camera

```bash
az iot hub module-twin update \
  --device-id EDDEVDVLGENOBAWE01-mvp-edge-4 --module-id image-grabber-cam05 --hub-name IOTDEVDVLGENOBAWE01-iot-hub-test-sgre \
  --set properties.desired='{"command":"on", "JOB_ID":"2020-12-15-09-s"}';
```

Stop `cam05` camera

```bash
az iot hub module-twin update \
  --device-id EDDEVDVLGENOBAWE01-mvp-edge-4 --module-id image-grabber-cam05 --hub-name IOTDEVDVLGENOBAWE01-iot-hub-test-sgre \
  --set properties.desired='{"command":"off", "JOB_ID":"2020-12-15-09-s"}';
```

## Scripts for starting/stopping streams

### Requirements

- ssh
- azure-cli
- azure iot extension (`az extension add --name azure-iot`)

#### Mac OX X and Linux systems

It should work out of the box if software listed in `Requirements` section is installed

#### Windows

This scripts needs to be run in dedicated container. Container [Dockerfile](./Start_checklist/Dockerfile) + [docker-entrypoint.sh](./Start_checklist/docker-entrypoint.sh)

### IMPORTANT

This script is configured for `cam04` and `cam05` only. `cam03` is disabled on purpose.

## Script to start processing

[The latest script version should be downloaded from here](./Start_checklist/start_process.sh)

```sh
    #!/bin/bash
    IOT_HUB_NAME="IOTDEVDVLGENOBAWE01-iot-hub-test-sgre"
    JOB_ID="2020-12-16-09-s"
    CAM03_EDGE="EDDEVDVLGENOBAWE01-mvp-edge-1"
    CAM04_EDGE="EDDEVDVLGENOBAWE01-mvp-edge-2"
    CAM05_EDGE="EDDEVDVLGENOBAWE01-mvp-edge-4"
    CAM03_HOST="edge1"
    CAM04_HOST="edge2"
    CAM05_HOST="edge4"
    CAM03_NAME="cam03"
    CAM04_NAME="cam04"
    CAM05_NAME="cam05"

    echo 'Cleaning up job id in etcd'
    ssh $CAM04_HOST 'etcdctl del '$JOB_ID' --prefix'
    echo 'etcd cleanup done'

    echo 'Cleaning edge-verification debug folder...'
    #echo "Cleaning edge-verification-$CAM03_NAME debug folder..."
    #ssh $CAM03_HOST 'sudo rm -rf /mnt/data/iot-work-volume/edge-verification-output/*'
    echo "Cleaning edge-verification-$CAM04_NAME debug folder..."
    ssh $CAM04_HOST 'sudo rm -rf /mnt/data/iot-work-volume/edge-verification-output/*'
    echo "Cleaning edge-verification-$CAM05_NAME debug folder..."
    ssh $CAM05_HOST 'sudo rm -rf /mnt/data/iot-work-volume/edge-verification-output/*'
    echo 'All edge-verification modules cleanup done'

    echo 'Restarting edge-verification modules...'
    #echo "Restarting edge-verification-$CAM03_NAME module..."
    #ssh $CAM03_HOST 'iotedge restart edge-verification-'$CAM03_NAME
    echo "Restarting edge-verification-$CAM04_NAME module..."
    ssh $CAM04_HOST 'iotedge restart edge-verification-'$CAM04_NAME
    echo "Restarting edge-verification-$CAM05_NAME module..."
    ssh $CAM05_HOST 'iotedge restart edge-verification-'$CAM05_NAME


    echo 'Restarting decision-maker modules...'
    #echo "Restarting decision-maker module for $CAM03_NAME..."
    #ssh $CAM03_HOST 'iotedge restart decision-maker'
    echo "Restarting decision-maker module for $CAM04_NAME..."
    ssh $CAM04_HOST 'iotedge restart decision-maker'
    echo "Restarting decision-maker module for $CAM05_NAME..."
    ssh $CAM05_HOST 'iotedge restart decision-maker'
    echo 'All decision-maker modules restarted'

    echo "Set corrent job id to $JOB_ID"
    PAYLOAD='{"JOB_ID":"'${JOB_ID}'"}'

    # echo "Setting job id for camera $CAM03_NAME..."
    # az iot hub module-twin update --device-id $CAM03_EDGE --module-id image-grabber-$CAM03_NAME --hub-name $IOT_HUB_NAME \
    # --set properties.desired=$PAYLOAD

    echo "Setting job id for camera $CAM04_NAME..."
    az iot hub module-twin update --device-id $CAM04_EDGE --module-id image-grabber-$CAM04_NAME --hub-name $IOT_HUB_NAME \
    --set properties.desired=$PAYLOAD

    echo "Setting job id for camera $CAM05_NAME..."
    az iot hub module-twin update --device-id $CAM05_EDGE --module-id image-grabber-$CAM05_NAME --hub-name $IOT_HUB_NAME \
    --set properties.desired=$PAYLOAD


    echo "Starting streams..."
    PAYLOAD='{"command":"on"}'
    # echo "Starting camera $CAM03_NAME..."
    # az iot hub module-twin update --device-id $CAM03_EDGE --module-id image-grabber-$CAM03_NAME --hub-name $IOT_HUB_NAME \
    # --set properties.desired=$PAYLOAD

    echo "Starting camera $CAM04_NAME..."
    az iot hub module-twin update --device-id $CAM04_EDGE --module-id image-grabber-$CAM04_NAME --hub-name $IOT_HUB_NAME \
    --set properties.desired=$PAYLOAD

    echo "Starting camera $CAM05_NAME..."
    az iot hub module-twin update --device-id $CAM05_EDGE --module-id image-grabber-$CAM05_NAME --hub-name $IOT_HUB_NAME \
    --set properties.desired=$PAYLOAD

    echo "All streams started"

    echo "Configuring edge-verification modules parameters..."
    # az iot hub module-twin update \
    #      --device-id $CAM03_EDGE --module-id edge-verification-$CAM03_NAME  --hub-name $IOT_HUB_NAME \
    #      --set properties.desired='{"TOLERANCE":30, "REGION_OF_VERIFICATION": 30, "REDUCE_MASK_BY":500, "NOISE_SIZE_THRESHOLD":300 }'
    az iot hub module-twin update \
          --device-id $CAM04_EDGE --module-id edge-verification-$CAM04_NAME --hub-name $IOT_HUB_NAME \
          --set properties.desired='{"TOLERANCE":35, "REGION_OF_VERIFICATION": 30, "REDUCE_MASK_BY":700, "NOISE_SIZE_THRESHOLD":500 }'
    # az iot hub module-twin update \
    #      --device-id $CAM05_EDGE --module-id edge-verification-$CAM05_NAME --hub-name $IOT_HUB_NAME \
    #      --set properties.desired='{"TOLERANCE":30, "REGION_OF_VERIFICATION": 30, "REDUCE_MASK_BY":500, "NOISE_SIZE_THRESHOLD":500 }'
    echo "edge-verification modules configuration done"

    echo "Done"
```

## Script to stop processing

[The latest script version should be downloaded from here](./Start_checklist/stop_process.sh)

```sh
  #!/bin/bash
  IOT_HUB_NAME="IOTDEVDVLGENOBAWE01-iot-hub-test-sgre"
  CAM03_EDGE="EDDEVDVLGENOBAWE01-mvp-edge-1"
  CAM04_EDGE="EDDEVDVLGENOBAWE01-mvp-edge-2"
  CAM05_EDGE="EDDEVDVLGENOBAWE01-mvp-edge-4"
  CAM03_NAME="cam03"
  CAM04_NAME="cam04"
  CAM05_NAME="cam05"


  echo "Stopping streams..."
  PAYLOAD='{"command":"off"}'
  echo "Stopping camera $CAM03_NAME..."
  az iot hub module-twin update --device-id $CAM03_EDGE --module-id image-grabber-$CAM03_NAME --hub-name $IOT_HUB_NAME \
    --set properties.desired=$PAYLOAD
  echo "Stopping camera $CAM04_NAME..."
  az iot hub module-twin update --device-id $CAM04_EDGE --module-id image-grabber-$CAM04_NAME --hub-name $IOT_HUB_NAME \
    --set properties.desired=$PAYLOAD
  echo "Stopping camera $CAM05_NAME..."
  az iot hub module-twin update --device-id $CAM05_EDGE --module-id image-grabber-$CAM05_NAME --hub-name $IOT_HUB_NAME \
    --set properties.desired=$PAYLOAD
  echo "All streams stopped"
  echo "Done"
```
