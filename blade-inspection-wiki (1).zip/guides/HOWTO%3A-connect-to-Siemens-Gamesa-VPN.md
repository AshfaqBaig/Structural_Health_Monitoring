# Connecting to VPN from Mac OS X

1. Open Cisco AnyConnect software

2. Enter settings (wheel icon) and allow connection from untrusted servers (last option)

![image.png](../.attachments/guides/vpn-connectivity/image-1c158c45-37d3-4340-8ca6-2b6ec0c5cf27.png)

3. Enter into dropdown IP address **_194.182.15.114_**

![image.png](../.attachments/guides/vpn-connectivity/image-4e810e5a-1470-47d2-a51c-37b7649274c5.png)

4. Click connect and confirm all security warnings

![image.png](../.attachments/guides/vpn-connectivity/image-76090411-6e46-44f5-9a21-a522488a7c77.png)

5. Enter username _c2s-ibm-1_ and password _communicated_via_other_channel_

![image.png](../.attachments/guides/vpn-connectivity/image-2c930662-d957-42a6-9fe1-01e3ec6f84cf.png)

6. Done. You can ssh into EDGE server via same IP