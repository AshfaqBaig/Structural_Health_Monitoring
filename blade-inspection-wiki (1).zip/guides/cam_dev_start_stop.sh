#!/bin/bash

cmd_arg=$1
echo "Command given : $1, $cmd_arg";


IOT_HUB_NAME="IOTDEVDVLGENOBAWE01-iot-hub-dev-sgre"
JOB_ID="2020-12-16-09-s"
EDGE="EDDEVDVLGENOBAWE01-dev-edge-device-1"
# declare -a CAM_NAME=("cam-aal-h08-026" "cam-aal-h08-027" "cam-aal-h08-028" "cam-aal-h08-029" "cam-aal-h08-030" "cam-aal-h08-031" "cam-aal-h08-032")

# declare -a CAM_NAME=("cam-aal-h08-028" "cam-aal-h08-029" "cam-aal-h08-030" "cam-aal-h08-031" "cam-aal-h08-032" )


az_cmd () {
   echo "Call azure command with payload $1 "
    for i in "${CAM_NAME[@]}"
    do
        echo "Setting job id for camera $i..."
        az iot hub module-twin update --device-id $EDGE --module-id image-grabber-$i --hub-name $IOT_HUB_NAME --set properties.desired=$1
        sleep 5s
    done
}

# if [ "$cmd_arg" = "on" ]; then
#     echo "Set corrent job id to $JOB_ID"
#     PAYLOAD='{"JOB_ID":"'${JOB_ID}'"}'
#     az_cmd $PAYLOAD
# else
#     echo "OFF command is set skipping jobid setting...."
# fi

if [ "$cmd_arg" = "on" ]; then
    PAYLOAD='{"command":"on"}'
else
    PAYLOAD='{"command":"off"}'
fi

echo "Starting streams... $PAYLOAD"
az_cmd $PAYLOAD