[[_TOC_]]

# Update existing module version in deployment

1. Build module and capture its version. In this example `em-edge-verification` module's version 1494
![image.png](/.attachments/image-1ef3008f-512b-49c1-8acb-1ebffb175d4f.png)
2. Update edge-infrastructure _variables.tf_ file image version value captured at _step 1_. Commit file

![image.png](/.attachments/image-8ff90cb0-c1a5-4ce5-acbd-e14dad208848.png)

3. Initiate build process by running an _edge-infrastructure_ [pipeline](https://dev.azure.com/SGRE-IBM/BladeInspection/_build?definitionId=3)

![image.png](/.attachments/image-ca5e9fe1-7694-43f6-b9dc-163ffb1916fa.png)

# Add new module version into deployment

TODO