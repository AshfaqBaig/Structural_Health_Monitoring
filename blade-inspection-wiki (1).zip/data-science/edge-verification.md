# Edge Verification Method Description

The method is implemented in the *em-edge-verification* module. This description gives theoretical background to understand the code of the module.

## Assumptions

Like in any other scientific problem, we need to make some reasonable assumptions about initial and boundary conditions of the problem. The (assumed) conditions will define the method applicability. The assumptions themselves are usually based on our observations and information received from subject matter experts. The assumptions are the following:

- ply edges can be described by a polynomial of sufficiently high degree
- the ply edges CAD data is converted from 3D world coordinate system to the 2D image coordinate system and is given as ground truth data
- the laid down ply edges are detected and are given as detection data
- the verification happens in a pre-defined region around expected ground truth position in the image plane

## Method

Given the assumptions hold, we have a problem of comparing a model or theoretical curve to the detected or observed curve. In other words, we want to understand how well our observation with noise fits the theoretical model. This is achieved with the following steps:

1. fit the ground truth data with a high degree polynomial to derive the function describing the model curve
   - the high degree is required to accommodate any arbitrary complicated curve
   - the reduced chi2 metric (aka mean-squared error) is used to verify the goodness-of-fit
2. subtract the model curve from the observed edge points
   - if the observation fits the model curve, we expect to get residual points scattered around 0
3. fit the residual points with a low degree polynomial and calculate the prediction interval (here we take 95\%-prediction interval)
4. any region where the lower prediction interval is larger than 0 or the upper prediction interval is smaller than 0 is a significant deviation from the ground truth model and it should be announced as mismatch or displacement and trigger an alert

The approach is robust to identify any type of deviation from the ground truth at any point in the image plane. This is controlled by the degree of polynomial used to fit the residual points.

## Constraints of the MVP and future considerations

There are some constrains of the MVP stage that should be considered. These constraints impact some assumptions and limit current sensitivity of the method. These constraints are expected to go away in the subsequent releases of the product. Namely, the projection of the CAD data to the image plane, which itself was a PoC within the MVP, has an error of a few centimeters, thus the projected ground truth curve is not exactly where it should be. To accommodate for this uncertainty, we add a tolerance interval of a few centimeters (depending on the camera) to prediction interval and use the new interval to trigger a mismatch alert. Furthermore, due to the projection error, which is currently unknown function of the image plane, the ground truth curve may acquire spurious waviness, so fitting a polynomial of 2nd or even higher degree to the residual points makes not much sense. That is why the first MVP version fits the residual points with simple line and is sensitive only to the displacements of the complete ply like shift/rotation and not to displacements of some parts of the ply like wraps/wrinkles. As soon as the camera calibration process is automated and the projection error is minimized,  the tolerance interval may be made much smaller and the higher degree polynomial can be fit to the residual points, thus making the method sensible to the more complicated types of the ply displacements.
