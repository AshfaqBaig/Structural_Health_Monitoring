**All Information/Documentation can be found in SharePoint:** 
https://siemensgamesa.sharepoint.com/teams/EX0032D/Shared%20Documents/Forms/AllItems.aspx?viewid=a3b81b6e%2D3f50%2D4f87%2Da00b%2D2fc78f4102b0&id=%2Fteams%2FEX0032D%2FShared%20Documents%2FCalibration%202%2E0

Main documentation: 
https://siemensgamesa.sharepoint.com/:p:/r/teams/EX0032D/_layouts/15/Doc.aspx?sourcedoc=%7BC0B2D032-95CC-4982-88E6-E32EBA22A2BA%7D&file=SGRE_UC1.2_CameraCalibration_KT.pptx&action=edit&mobileredirect=true

Steps for Camera calibration and the brief structure of the corresponding codes: 
https://siemensgamesa.sharepoint.com/:w:/r/teams/EX0032D/_layouts/15/Doc.aspx?sourcedoc=%7BECE5D6BA-69A9-4831-98D6-CFF0B1800029%7D&file=Calibration%20Process%20Steps.docx&action=default&mobileredirect=true