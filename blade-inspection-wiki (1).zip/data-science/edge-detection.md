# Edge Detection Method Description

The method is implemented in the *em-edge-detection* module. This description gives a theoretical background to understand the code of the module.

## Assumptions

* Edge detection has to be robust both in detection quality (edge thickness and continuity) and position accuracy.
* The model has to adapt to new kinds of scenarios and changes in the environment (material, lighting, weather, time of day...).
* The detection has to be image-based, i.e. it detects all the edges it sees in a frame and doesn't filter any duplicates from previous frames.
* The detection has to be fast enough so that the end-to-end capture-detect-verify-feedback process is below a specific threshold (5sec currently).

## Method

Three different methods were tested within the POC and the MVP:
* Unsupervised Video-based change detection

1. Compute dense optical flow using the Farneback method `cv.calcOpticalFlowFarneback`
2. Compute the magnitude and angle of the 2D vectors in order to compute the mean motion of the scene
3. Find the global minima of the mean motion curve in order to find keyframes. These frames represent the pause between two plies.
4. Compute the difference between every two consecutive keyframes in order to find the edges of the new ply. The difference is represented by the structural similarity index ‘skimage.metrics.structural_similarity`

This method was tested in the POC and wasn't used in the MVP because it didn't fulfill the new requirements. It relied on multiple frames to give the feedback which causes multiple blockers. The offline implementation can be found in [ml-sandbox/feature-keyframeExtractor](https://dev.azure.com/SGRE-IBM/BladeInspection/_git/ml-sandbox?path=%2Fnotebooks%2Fe2e-baseline-seq9.ipynb&version=GBfeature-keyframeExtractor&_a=contents).

* Holistically-Nested Edge Detection (HED)

HED is a good suitable deep learning method to solve the problem of edge detection. It relies on labeled training data in order to predict visible ply edges. The problem is that the method is several years old. This means that the code implementations are outdated, in this case, all of them are. These outdated implementations cause problems in deep learning because the frameworks rarely allow backward compatibility, which means that retraining and deploying HED will become a problem.

Information about HED, including the paper and the code implementations, can be found [here](https://paperswithcode.com/paper/holistically-nested-edge-detection).

* Dense Extreme Inception Network: Towards a Robust CNN Model for Edge Detection (DexiNed)

DexiNed is a different design of the same functionality that is offered by HED. It is newly published and offers better performance in regards to the ODS metric. 

![Screen Shot 2021-01-18 at 00.31.43.png](/.attachments/Screen%20Shot%202021-01-18%20at%2000.31.43-7e34a62e-424a-4f65-b0a2-5329afe6b8e9.png)

The main implementation is in the old TF1.x format but a working TF2.x beta code is available. This TF2.x was used to retrain the models on our data. DexiNed is originally implemented using model subclassing, custom layers, and custom training loops. This makes refactoring the code harder. Moreover, the exported model is hard to visualize or interpret. The official implementation was used out of the box and wrapped with some functionality to track the training using Azure ML. The offline implementation can be found in [ml-edge-detection](https://dev.azure.com/SGRE-IBM/BladeInspection/_git/ml-edge-detection) which the deployment can be found in [em-ml-edge-detection](https://dev.azure.com/SGRE-IBM/BladeInspection/_git/em-ml-edge-detection).

Information about DexiNed, including the paper and the code implementations, can be found [here](https://paperswithcode.com/paper/dense-extreme-inception-network-towards-a).

DexiNed was trained on image tiles. These tiles represent 400x400 sub-images. The labels are tiled as well. By tiling instead of resizing, the model has more power to learn good data. This also means that training and inference would take more time and consume more resources. For that reason, negative tiles, where no edges are seen, weren't used for training. Some experimentation showed that these negative tiles improve model performance. The raw image data that was collected and filtered for training can be found in [stdevdvlgenobawe01testio/raw-data](https://portal.azure.com/#blade/Microsoft_Azure_Storage/ContainerMenuBlade/overview/storageAccountId/%2Fsubscriptions%2Fcbe9d379-0f71-4dbc-994b-804713d41dec%2FresourceGroups%2FRGDEVDVLGENOBAWE01%2Fproviders%2FMicrosoft.Storage%2FstorageAccounts%2Fstdevdvlgenobawe01testio/path/raw-data/etag/%220x8D8639450A4A331%22/defaultEncryptionScope/%24account-encryption-key/denyEncryptionScopeOverride//defaultId//publicAccessVal/None) while the tile datasets that were used for training can be found in [stdevdvlgenobawe01storml/dvc-dataset](https://portal.azure.com/#blade/Microsoft_Azure_Storage/ContainerMenuBlade/overview/storageAccountId/%2Fsubscriptions%2Fcbe9d379-0f71-4dbc-994b-804713d41dec%2FresourceGroups%2FRGDEVDVLGENOBAWE01%2Fproviders%2FMicrosoft.Storage%2FstorageAccounts%2Fstdevdvlgenobawe01storml/path/dvc-datasets/etag/%220x8D8817035700EFB%22/defaultEncryptionScope/%24account-encryption-key/denyEncryptionScopeOverride//defaultId//publicAccessVal/None).

The best retraining performance was reached by training from scratch in [run 64](https://ml.azure.com/experiments/id/14ebeaa4-43dd-40d0-b41d-944732b1c112/runs/10268i_150e_08b_clahe_c5_b050_3f681?wsid=/subscriptions/cbe9d379-0f71-4dbc-994b-804713d41dec/resourcegroups/RGDEVDVLGENOBAWE01/workspaces/MLDEVDVLGENOBAWE01-ml&tid=12f921d8-f30d-4596-a652-7045b338485a). The resulting model was deployed in the MVP. Since most of the detection image is black, the accuracy during training converges to 100% very fast, and only slightly continues to increase after that. The dataset mean is subtracted from the tiles before training. During inference, the mean values are stored within the exported `savedmodel`. The best model was trained on batches of size 8. The reason for using small batches is the ability to learn from under-represented scenarios that would otherwise be lost in the averaged update of a bigger batch. In case the dataset is fairly distributed, a bigger batch can be used to accelerate the training.

## Constraints of the MVP and future considerations

The baseline DexiNed model that was deployed in the MVP was minimally trained. The data that was used for that training was only included parts of the needed data. It focused on specific days (the days during which data was captured), times of day (the times the data was captured), sections of the mold (the root part), and camera types (50mm). In order to have a model that is robust enough, a bigger dataset that has more variance and describes all the needed scenarios has to be collected and processed.

Moreover, it might be worth looking into refactoring some parts of the code so that it is easier to export and optimize the model.


