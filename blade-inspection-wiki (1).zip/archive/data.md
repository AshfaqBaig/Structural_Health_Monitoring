# Data

## Collecting Data From Camera

1. Login to camera PC using Teamviewer (Username/Password in emails)
2. Prepare the SAS key sent to you per email.
3. On the camera PC
   1. Open Powershell
   2. Navigate to `cd d:/SWP`
   3. Run the following command
      `azcopy sync "." "https://stdevdvlgenobawe01storml.blob.core.windows.net/raw-data/monochrome-camera?ENTER-SAS-KEY-HERE" --put-md5 --recursive=false`
   4. Check disk space. In case it is full, delete images inside `backup-to-delete`
   5. Move the uploaded images to `backup-to-delete`

## Blob Storage Structure

- Storage account `stdevdvlgenobawe01storml`
  - Container `raw-data`
    - `mobile`: a collection of simulated mobile videos.
    - `monochrome-camera`: main data dump of the POC monochrome camera.
    - `Material-classification-data`: All the data(-sets) that is needed to reproduce modeling
    - `Material-classification-mobile` : (old) main mobile data dump, containing UD and BIAX mobile camera images as well as samples (cleaned and not cleaned)
    - `Material-classification-mobile-sampleset` : (old) cleaned mobile samples for UD and BIAX classes
