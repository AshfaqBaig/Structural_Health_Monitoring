# Edge device software installation list

## Software

- Ubuntu 18.04 LTS Server (Desktop version is needed only for dev server)
- SSH service
- The latest Nvidia Tesla V100 drivers for Ubuntu 18.04 (compatible with CUDA 10.1)

    `https://www.nvidia.com/Download/driverResults.aspx/160653/en-us`

    `https://docs.nvidia.com/datacenter/tesla/tesla-installation-notes/index.html#ubuntu-lts`

- Fail2ban

    `https://www.techrepublic.com/article/how-to-install-fail2ban-on-ubuntu-server-18-04/`

- Python 3.7

    `https://linuxize.com/post/how-to-install-python-3-7-on-ubuntu-18-04/`

    `https://github.com/aben20807/blog-post/issues/80`

- Vimba
    `https://askubuntu.com/questions/877992/how-to-put-executable-to-usr-local-bin`
- Nload
    `https://www.google.com/search?q=nload&oq=nload&aqs=chrome..69i57.1445j0j7&sourceid=chrome&ie=UTF-8`
- Stacer
    `https://github.com/oguzhaninan/Stacer`
- Moby Engine
    `sudo apt install moby-engine`
- Nvidia Container Runtime
  
    `distribution=$(. /etc/os-release;echo $ID$VERSION_ID)`

    `curl -s -L https://nvidia.github.io/nvidia-docker/gpgkey | sudo apt-key add -`

    `curl -s -L https://nvidia.github.io/nvidia-docker/$distribution/nvidia-docker.list | sudo tee /etc/apt/sources.list.d/nvidia-docker.list`

    `sudo apt-get install -y nvidia-docker2`

    `sudo systemctl restart docker`

- NVTOP(Nvidia process viewer) [https://github.com/Syllo/nvtop#older](https://github.com/Syllo/nvtop#older)

- [Azure IoT Edge Runtime](https://docs.microsoft.com/en-us/azure/iot-edge/how-to-install-iot-edge-linux)

    `curl https://packages.microsoft.com/config/ubuntu/18.04/multiarch/prod.list > ./microsoft-prod.list`

    `curl https://packages.microsoft.com/keys/microsoft.asc | gpg --dearmor > microsoft.gpg`

    `sudo cp ./microsoft.gpg /etc/apt/trusted.gpg.d/`

    `sudo apt update`

    `sudo apt install iotedge`

## Monitoring and logging

- Telegraf Agent [https://docs.microsoft.com/en-us/azure/azure-monitor/platform/collect-custom-metrics-linux-telegraf#install-and-configure-telegraf](https://docs.microsoft.com/en-us/azure/azure-monitor/platform/collect-custom-metrics-linux-telegraf#install-and-configure-telegraf)
- [Log Analytics](https://docs.microsoft.com/en-us/azure/azure-monitor/platform/agent-linux)
  
## Networking requirements

- Edge server should be able to access laser system
- Edge server should be able to access cameras and capture stations (if present) dedicated for this MVP
- Edge server should provide ssh access for management and support from outside of SGRE network. This could be a dedicated VPN connection or a jumphost based access
- Edge to Azure connection require 1Gbps (either Express Route or via Internet). After multiple cameras are installed, the might need to be increased to 2Gbps.
