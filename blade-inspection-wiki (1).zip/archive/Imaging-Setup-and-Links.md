**Cameras** 
https://www.alliedvision.com/en/products/cameras/detail/Prosilica%20GT/6400.html 
 
**Lens** 
https://www.alliedvision.com/en/products/accessories/lenses.html 
Exact model for f50 and f35 among interlock lenses?
 
**Vimba GUI (Windows/Linux)** 
https://www.alliedvision.com/en/products/software.html 
 
**Vimba's Python Git (Windows/Linux)** 
https://github.com/alliedvision/VimbaPython 
 
**IBM Camera / Image-Grabber API**
https://dev.azure.com/SGRE-IBM/BladeInspection/_git/em-image-grabber 