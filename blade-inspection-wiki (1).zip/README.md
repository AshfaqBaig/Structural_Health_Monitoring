# Introduction

- [Architecture](./architecture/README.md) - architecture documentation of the system
- [Guides](./guides) - guides to the system
