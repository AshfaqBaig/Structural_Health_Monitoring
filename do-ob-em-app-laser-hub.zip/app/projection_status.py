from enum import Enum


class ProjectionStatusEnum(Enum):
    """ENUM to provide status code"""
    ERROR_CODE = 500
    SUCCESS_CODE = 200
