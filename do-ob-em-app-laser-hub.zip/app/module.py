import threading
import socket
import asyncio
from queue import Queue
from  pyee.asyncio import AsyncIOEventEmitter
import falcon

import prometheus_client as prometheus
from prometheus_client import start_http_server
import app.config as cfg
from app.shared_storage import SharedStorage
from app.settings_change_handler import SettingsChangeHandler
from app.message_listener import MessageListener
from app.scheduler import Scheduler
from app.laser_client import LaserClient
from app.processors.projection import ProjectionProcessor

from app.logging.logger import yield_logger
log = yield_logger()

class Module():

    def __init__(self):
        self.shared_storage = SharedStorage(cfg.ETCD_URL, cfg.ETCD_TTL)
        self.projection_queue = Queue()
        event_emitter = AsyncIOEventEmitter()
        self.thread_stop_event = threading.Event()
        self.message_listener = MessageListener(event_emitter)
        self.laser_client = LaserClient(event_emitter, self.thread_stop_event)
        self.projection_request_handler = ProjectionRequestHandler(self.projection_queue)

    def start(self):
        Module.initialize_prometheus()
        self.subscribe_on_settings_change()

        self._start_laser_client_thread()
        self._start_scheduler_thread()
        self._start_message_listener_thread()

    def _start_message_listener_thread(self):
        # asyncio.run(self.message_listener.run())
        message_listener_thread = threading.Thread(target=asyncio.run, args=(self.message_listener.run(),))
        message_listener_thread.start()

    def _start_scheduler_thread(self):
        if Module.is_projection_scheduler_enabled():
            scheduler = Scheduler(self.projection_queue, self.laser_client, self.thread_stop_event)
            scheduler_thread = threading.Thread(target=scheduler.run, name='ProjectionScheduler', daemon=True)
            scheduler_thread.start()
        else:
            log.warning('Projection scheduler did not start')

    def _start_laser_client_thread(self):
        if Module.is_connection_to_prosoft_enabled():
            log.info('Activating laser hub client')
            laser_client_thread = threading.Thread(target=self.laser_client.listen, name='SocketListener', daemon=True)
            laser_client_thread.start()
        else:
            log.info('Running without active laser hub client (CONNECT_TO_PROSOFT=%s, ACTIVE_LASER_HUB_HOST=%s)',
                    cfg.CONNECT_TO_PROSOFT, cfg.ACTIVE_LASER_HUB_HOST)

    def restart(self):
        # stop
        self.thread_stop_event.set()
        self.laser_client.disconnect()
        self.thread_stop_event.clear()

        # start
        log.info("Starting all the threads")
        self._start_laser_client_thread()
        self._start_scheduler_thread()

    def create_api(self):
        '''Create falcon API object'''

        app = falcon.App()
        app.add_route('/api/projection', self.projection_request_handler)
        app.req_options.auto_parse_form_urlencoded = True
        log.info('Falcon API initialised')
        return app

    @staticmethod
    def initialize_prometheus():
        """Start Prometheus server"""

        prometheus.REGISTRY.unregister(prometheus.PROCESS_COLLECTOR)
        prometheus.REGISTRY.unregister(prometheus.PLATFORM_COLLECTOR)
        prometheus.REGISTRY.unregister(prometheus.GC_COLLECTOR)
        start_http_server(cfg.PROMETHEUS_PORT)

    def subscribe_on_settings_change(self):
        settings_change_handler = SettingsChangeHandler(self.restart)
        self.shared_storage.watch_key(cfg.MODULE_SETTINGS_KEY, settings_change_handler.on_settings_change)

    @staticmethod
    def is_projection_scheduler_enabled():
        return (cfg.CONNECT_TO_PROSOFT and cfg.ACTIVE_LASER_HUB_HOST == socket.gethostname()) or \
            cfg.CONNECT_TO_PROSOFT is False

    @staticmethod
    def is_connection_to_prosoft_enabled():
        '''
        Laser_client should connect only if it matches configured hostname.
        # This it to prevent multiple laser hubs connecting to single Prosoft instance
        '''

        return cfg.CONNECT_TO_PROSOFT and cfg.ACTIVE_LASER_HUB_HOST == socket.gethostname()

class ProjectionRequestHandler:
    '''Projection class pushes AMQP message to queue fro processing'''

    def __init__(self, projection_queue):
        self.processor = ProjectionProcessor(projection_queue)

    def on_post(self, req: falcon.Request, resp: falcon.Response) -> None:
        '''Handle POST invocation which invokes projecting DXF files'''

        self.processor.run(req.bounded_stream)
        resp.status = falcon.HTTP_200 # pylint: disable=no-member
