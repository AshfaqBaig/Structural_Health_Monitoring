import time
import math
import base64
from threading import Event

from queue import Empty
from time import sleep
from typing import List

from prometheus_client import Summary, Histogram
import app.config as cfg

from app.providers.projection import ProjectionProvider
from app.providers.image_projection import ImageProjectionProvider
from app.providers.laser_projection import LaserProjectionProvider
from app.models.projection_key import ProjectionKey
import app.metrics as Metrics

from app.logging.logger import yield_logger
log = yield_logger()


class Scheduler:
    '''Scheduler class consumes projections from the projections queue object, merges them and displays them'''

    HISTOGRAM_BUCKETS = (.1, .2, .5, 1.0, math.inf)
    METRICS_HISTOGRAM = \
        Histogram("lh_scheduler_iteration_total_duration_histogram_seconds",
                "	Laser Hub (LH) scheduler iteration processing duration histogram in seconds",
                buckets=HISTOGRAM_BUCKETS,
                labelnames=Metrics.get_label_keys())
    METRICS_SUMMARY = Summary("lh_scheduler_iteration_total_duration_seconds",
                            "Laser Hub (LH) scheduler iteration processing duration summary in seconds",
                            labelnames=Metrics.get_label_keys())

    def __init__(self, queue, laser_client, stop_event: Event):
        self.queue = queue
        self.laser_client = laser_client
        self.projections = {}
        self.projection_providers: List[ProjectionProvider] = [
            ImageProjectionProvider(),
            LaserProjectionProvider(self.laser_client)
        ]
        self._stop_event = stop_event

    def stopped(self):
        return self._stop_event.isSet()

    @staticmethod
    def _log_metrics(operation_start: int):
        operation_duration = time.time() - operation_start
        Scheduler.METRICS_HISTOGRAM.labels(**Metrics.get_labels()).observe(operation_duration)
        Scheduler.METRICS_SUMMARY.labels(**Metrics.get_labels()).observe(operation_duration)

    def _run_single_iteration(self):
        operation_start = time.time()
        try:
            if len(self.projections) > 0:
                self._expire_projections()
            if self.queue.qsize() != 0:
                self._process_projections_queue()
            # stop all projections when they are all expired
            if len(self.projections) == 0 and cfg.CONNECT_TO_PROSOFT:
                self.laser_client.stop_projection()
        except Empty:
            log.debug('No DXF files to project')
        except BaseException as be:
            log.exception("Failed to process projections")
        self._log_metrics(operation_start)

    def run(self):
        '''Main entry point method which loops over and consumes projections from queue object'''

        while not self.stopped():
            sleep(cfg.PROJECTION_PERIOD_LENGTH_S) # nosemgrep: python.lang.best-practice.sleep.arbitrary-sleep
            self._run_single_iteration()

    def _process_projections_queue(self):
        '''Read all elements from the queue and process them'''

        log.debug('Looping over queue (size=%s)', self.queue.qsize())
        while self.queue.qsize() > 0:
            payload: dict = self.queue.get(block=False)
            self._update_projections(payload)
            self.queue.task_done()

        self._display_projections()

    def _display_projections(self):
        '''Iterate over various projection providers and project data'''
        log.debug('Displaying projections (size=%s)', len(self.projections))
        for projection_provider in self.projection_providers:
            projection_provider.project(self.projections)

    @staticmethod
    def _is_empty_projection(payload: dict):
        return payload.get('expiration') == 0 or 'content' not in payload

    def _update_projections(self, payload: dict) -> None:
        projection_key: ProjectionKey = ProjectionKey(payload)
        correlation_id = payload.get('correlation_id')

        # delete old key instead of replacing it
        if self._is_empty_projection(payload):
            log.info(f'Deleting projection {projection_key}', extra={"correlation_id": correlation_id})
            self.projections.pop(projection_key, None)
        else:
            self.projections.pop(projection_key, None)
            self.projections[projection_key] = base64.b64decode(payload.get('content')).decode()
            log.info(f'Projection {projection_key} added', extra={"correlation_id": correlation_id})

    def _expire_projections(self):
        log.debug('Checking for expired projections (size=%s)', len(self.projections))
        expired_projections_count: int = 0
        projection_key: ProjectionKey
        for projection_key in self.projections.copy().keys():
            if projection_key.is_expired():
                log.info(f'Projection {projection_key} expired')
                self.projections.pop(projection_key)
                expired_projections_count += 1
            else:
                log.debug(f'Projection {projection_key} still active')

        if expired_projections_count > 0:
            self._display_projections()
