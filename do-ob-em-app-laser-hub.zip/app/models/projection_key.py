# pylint: disable=missing-module-docstring

import time
import hashlib
import json

import app.config as cfg


class ProjectionKey:
    '''Projection key model object'''

    def __init__(self, payload: dict):
        self.session: dict = payload['session']
        self.expiration = payload.get('expiration', cfg.PROJECTION_TTL)
        self.hash = self._build_hash()
        self.feedback_type = payload.get('feedbackType', 'unknown')
        self.arrival_time_ms: int = round(time.time() * 1000)

    def is_expired(self):
        '''Check if projection key is expired and supposed to be discarded'''

        return self._age() >= self.expiration * 1000

    def __eq__(self, other):
        if not isinstance(other, ProjectionKey):
            return NotImplemented

        return self.session == other.session

    def __hash__(self):
        return hash(self.hash)

    def _build_hash(self):
        dict_hash = hashlib.sha256()
        encoded = json.dumps(self.session, sort_keys=True).encode()
        dict_hash.update(encoded)
        return dict_hash.hexdigest()

    def _age(self) -> int:
        current_time_ms: int = round(time.time() * 1000)
        return current_time_ms - self.arrival_time_ms

    def __repr__(self):
        age_s = round(self._age() / 1000)
        return f'ProjectionKey(session={self.session}, feedbackType={self.feedback_type}, expiration={self.expiration}, age_s={age_s}))'
