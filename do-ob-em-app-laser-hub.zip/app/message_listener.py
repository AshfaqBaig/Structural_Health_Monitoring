import time
import asyncio
from threading import Event
from azure.iot.device.aio import IoTHubModuleClient
from azure.iot.device.exceptions import ConnectionFailedError
from pyee.base import EventEmitter
from app.logging import logger
from app.method_request_handler import MethodRequestHandler
from app.messaging_wrapper import MessagingWrapper

log = logger.yield_logger()

ERROR_OUTPUT = 'errorOutput'


class MessageListener:
    '''
    Message Listener implementation. It accepts payloads and forwards them to request processor.
    '''

    def __init__(self, event_emitter: EventEmitter):
        try:
            self.module_client = IoTHubModuleClient.create_from_edge_environment()
            self.event_emitter = event_emitter
            self._messaging = MessagingWrapper(self.module_client, self.event_emitter)
            self.method_request_handler = MethodRequestHandler(self.module_client, event_emitter)
        except ConnectionFailedError as cfe:
            log.exception(cfe)
            raise SystemExit('Terminating the app, because connection to iotedge agent failed') from cfe

    def empty_listener(self):
        '''Empty listener to keep module always running'''
        while True:
            time.sleep(600) # nosemgrep: python.lang.best-practice.sleep.arbitrary-sleep

    async def run(self):
        '''
        Entrypoint main method
        '''
        try:
            await self.module_client.connect()
            self.module_client.on_method_request_received = self.method_request_handler.run
            log.info('Message listener started')
            # Run the empty listener in the event loop
            loop = asyncio.get_event_loop()
            user_finished = loop.run_in_executor(None, self.empty_listener)
            await user_finished

            # Finally, disconnect
            await self.module_client.disconnect()

        except Exception:
            log.exception('Unexpected error')
            raise
