import uuid
from abc import ABC, abstractmethod

import app.config as cfg
from app.models.projection_key import ProjectionKey
from app.util.dxf_util import merge_dxf_str

from app.logging.logger import yield_logger
log = yield_logger()

class ProjectionProvider(ABC):
    '''Generic projection provider class'''

    @abstractmethod
    def project(self, projections: list):
        ''''Project projection'''

    @abstractmethod
    def enabled(self):
        ''''Method for checking if projection provider is enabled'''

    def _generate_merged_projection(self, projections: dict):
        '''Merge projections and generate single one'''

        path_for_prosoft = None
        output_path = None

        if len(projections) == 1:
            projection_key: ProjectionKey = next(iter(projections))
            dxf_filename_postfix = str(uuid.uuid4())
            path_for_prosoft, output_path = self._write_file(dxf_filename_postfix, projections[projection_key])
        elif len(projections) > 1:
            dxf_projections = []
            projection_key: ProjectionKey
            for projection_key in projections:
                dxf_projections.append(projections[projection_key])
            dxf_filename_postfix = str(uuid.uuid4())
            dxf = merge_dxf_str(dxf_projections)
            path_for_prosoft, output_path = self._write_file(dxf_filename_postfix, dxf)

        log.info(f"Writing file with {len(projections)} projections to {output_path} (ProSoft: {path_for_prosoft})")
        return path_for_prosoft, output_path

    @classmethod
    def _write_file(cls, dxf_filename_postfix: str, dxf_content):
        '''Write DXF file and place it for Prosoft's consumption'''

        dxf_file_path = f'feedback-{dxf_filename_postfix}.dxf'
        path_for_prosoft = f'{cfg.LASER_DXF_INPUT_PATH}{dxf_file_path}'
        output_path = f'{cfg.DXF_OUTPUT_PATH}{dxf_file_path}'
        with open(output_path, 'w', encoding="utf8") as output_file:
            output_file.write(dxf_content)
            output_file.close()
        return path_for_prosoft, output_path # WIN / UNIX
