# pylint: disable=missing-module-docstring
import os
from pathlib import Path
import app.config as cfg
from app.providers.projection import ProjectionProvider
from app.laser_client import LaserClient

from app.logging.logger import yield_logger
log = yield_logger()


class LaserProjectionProvider(ProjectionProvider):
    '''Image projection provider class'''

    def __init__(self, laser_client: LaserClient):
        self.laser_client = laser_client

    def project(self, projections: list):
        ''''Project projection'''

        if self.enabled() and not self.laser_client.is_connected():
            log.error('Not accepting projections because of lost connection to laser client (enabled=%s; is_connected=%s)',
                        self.enabled(), self.laser_client.is_connected())
        elif len(projections) > 0:
            merged_dxf_projection_path_for_prosoft, _ = self._generate_merged_projection(projections)
            self.laser_client.start_projection(merged_dxf_projection_path_for_prosoft)
            log.info(f'Projecting to laser {merged_dxf_projection_path_for_prosoft}')
            self._clear_old_projections(merged_dxf_projection_path_for_prosoft)

    def enabled(self):
        ''''Project enabled'''
        return cfg.CONNECT_TO_PROSOFT

    def _clear_old_projections(self, current_projection_filename: str) -> None:
        ''''Clear old or previously projected file'''
        try:
            file_list = list(Path(cfg.DXF_OUTPUT_PATH).glob('*.dxf'))
            for dxf_file_name in file_list:
                file_path = os.path.join(cfg.DXF_OUTPUT_PATH, dxf_file_name)
                if os.path.isfile(file_path) and file_path.split("feedback")[-1] not in current_projection_filename:
                    os.remove(file_path)
                    log.info('Deleted previous laser projection file %s', file_path)
        except (OSError) as error:
            log.error(error)
