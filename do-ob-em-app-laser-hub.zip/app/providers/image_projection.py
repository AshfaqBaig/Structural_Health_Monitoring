# pylint: disable=missing-module-docstring
import app.config as cfg
from app.util.dxf_util import dxf2image
from app.providers.projection import ProjectionProvider

from app.logging.logger import yield_logger
log = yield_logger()

class ImageProjectionProvider(ProjectionProvider):
    '''Image projection provider class'''

    def project(self, projections: list):
        ''''Project projection'''

        if self.enabled() and len(projections) > 0:
            _, merged_dxf_projection_path = self._generate_merged_projection(projections)
            dxf2image(merged_dxf_projection_path)
            log.info('Projecting to image %s', merged_dxf_projection_path)

    def enabled(self):
        return cfg.PROJECT_TO_IMG
