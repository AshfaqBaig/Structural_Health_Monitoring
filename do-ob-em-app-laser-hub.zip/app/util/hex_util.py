'''Message building helper methods'''


def padhex(data: str):
    '''Build hex from string and pad it'''

    return '0x' + data[2:].zfill(4)


def to_uint2(value: int):
    '''Convert integer to little endian bytes value'''

    return value.to_bytes(2, byteorder='little')


def from_uint2(value: bytes):
    '''Convert little endian bytes to integer value'''

    return int.from_bytes(value, 'little')
