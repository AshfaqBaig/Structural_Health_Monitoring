'''Various DXF related helper methods'''

import os
import io
from datetime import datetime
import ezdxf

from ezdxf.addons import Importer

import numpy as np
import matplotlib.pyplot as plt

from app.logging.logger import yield_logger
log = yield_logger()

DEFAULT_DXF_VERSION = os.environ.get('DEFAULT_DXF_VERSION', 'AC1032')

def _extract_entities(dxf):
    '''Extract entities from supplied DXF modelspace'''

    entities = dxf.modelspace().query('CIRCLE LINE POINT ARC TEXT POLYLINE')
    log.debug('Found %s entities in layer %s', len(entities), entities[0].dxf.layer if len(entities) > 0 else 'N/A')

    # rename entities and merge them into one
    for entity in entities:
        entity.dxf.layer = 'merged'
    return entities

def merge_dxf(projections: list):
    '''Merged all projections into single DXF. All entities are merged into single "merged" layed"'''

    target_dxf = ezdxf.new(DEFAULT_DXF_VERSION)

    for projection in projections:
        dxf_stream = io.StringIO(projection)
        dxf = ezdxf.read(dxf_stream)
        importer = Importer(dxf, target_dxf)
        entities = _extract_entities(dxf)
        importer.import_entities(entities, target_dxf.modelspace())
        importer.finalize()

    return target_dxf


def merge_dxf_str(projections: list):
    '''Merged all projections into single DXF string. All entities are merged into single "merged" layer"'''

    dxf_document = merge_dxf(projections)

    # create an empty stream to write the merged dxf (dxf_document) into it
    str_stream = io.StringIO()
    dxf_document.write(str_stream)
    return str_stream.getvalue()


def dxf2image(dxf: str):
    log.info("Loading dxf from '%s'", dxf)

    timestamp = datetime.utcnow().strftime('%Y%m%d%H%M%S%f')
    file_base = dxf.replace('.dxf','')
    file_out = f"{file_base}_{timestamp}.png"

    # create a data list with all entities from the dxf
    data = []
    try:
        doc = ezdxf.readfile(dxf)
    except IOError:
        log.error('Not a DXF file or a generic I/O error.')
        log.info('dxf2img is facing an issue! No image is generated.')
        return
    except ezdxf.DXFStructureError:
        log.error('Invalid or corrupted DXF file.')
        log.info('dxf2img is facing an issue! No image is generated.')
        return

    msp = doc.modelspace()
    entities = msp.query('CIRCLE LINE POINT ARC TEXT POLYLINE')

    for entity in entities:
        data_single = []
        for item in entity.points():
            data_single.append(np.array(item))
        if entity.is_closed: # nosemgrep
            data_single.append(data_single[0])
        data.append(np.asarray(data_single))

    # PLOT3d
    fig, ax = plt.subplots(figsize=(15,15))
    ax.set_facecolor('k')
    for i in range(len(data)):
        x = data[i][:,0]
        z = data[i][:,2]
        ax.plot(x,z,color='green',linewidth=1)
        ax.set_xlabel('x [mm]')
        ax.set_ylabel('z [mm]')
        ax.axis('equal')

    fig.savefig(file_out)
    log.debug('Convert feedback to image done: %s', file_out)
