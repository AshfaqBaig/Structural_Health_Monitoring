import logging
from azure.iot.device import MethodResponse
import app.config as cfg
from app import events
from app.logging.logger import update_log_level

log = logging.getLogger(cfg.MODULE_APP_NAME)

class MethodRequestHandler:
    """Main method request handler method"""

    def __init__(self, module_client, event_emitter):
        self.module_client = module_client
        self.event_emitter = event_emitter

    async def run(self, request):
        """ Method request handler entrypoint """

        try:
            log.info(f'Method {request.name} invocation with: {request.payload}')
            if request.name == "set_log_level" and request.payload.get("value"):
                status =  self._update_log_level(request.payload.get("value"))
            elif request.name == "enable_project_to_image":
                status = self._enable_project_to_image()
            elif request.name == "disable_project_to_image":
                status = self._disable_project_to_image()
            elif request.name == "enable_connect_to_prosoft":
                status = self._enable_connect_to_prosoft()
            elif request.name == "disable_connect_to_prosoft" :
                status = self._disable_connect_to_prosoft()
            elif request.name == "update_default_task_id" and request.payload.get("value"):
                status = self._update_default_task_id(request.payload)
            else:
                status = 400

            method_response = MethodResponse.create_from_method_request(request, status, request.payload)
            await self.module_client.send_method_response(method_response)

        except Exception:
            log.exception("Unexpected error while handling method request")
            raise

    def _update_default_task_id(self, payload: dict) -> int:
        if cfg.DEFAULT_TASK_ID != payload.get("value"):
            cfg.DEFAULT_TASK_ID = payload.get("value")
            log.info(f"Received new DEFAULT_TASK_ID {cfg.DEFAULT_TASK_ID}")
            self.event_emitter.emit(events.RECONNECT_TO_PROSOFT)
            return 200
        return 304

    def _disable_connect_to_prosoft(self) -> int:
        if cfg.CONNECT_TO_PROSOFT:
            log.info("Received PRO-SOFT disconnect request")
            cfg.CONNECT_TO_PROSOFT = False
            self.event_emitter.emit(events.DISCONNECT_FROM_PROSOFT)
            return 200
        return 304

    def _enable_connect_to_prosoft(self) -> int:
        if not cfg.CONNECT_TO_PROSOFT:
            cfg.CONNECT_TO_PROSOFT = True
            log.info("Received PRO-SOFT connect request")
            self.event_emitter.emit(events.CONNECT_TO_PROSOFT)
            return 200
        return 304

    def _enable_project_to_image(self) -> int:
        if not cfg.PROJECT_TO_IMG:
            cfg.PROJECT_TO_IMG = True
            log.info("Applied PROJECT_TO_IMG enable request")
            return 200
        return 304

    def _disable_project_to_image(self) -> int:
        if cfg.PROJECT_TO_IMG:
            cfg.PROJECT_TO_IMG = False
            log.info("Applied PROJECT_TO_IMG disable request")
            return 200
        return 304

    def _update_log_level(self, log_level: str) -> int:
        '''Update LOG_LEVEL'''
        if cfg.LOG_LEVEL != log_level:
            cfg.LOG_LEVEL = log_level
            update_log_level(log, cfg.LOG_LEVEL)
            return 200
        return 304
