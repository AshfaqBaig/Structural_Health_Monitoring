# pylint: disable=E1101
import socket
import time
from threading import Event
from pyee.base import EventEmitter
from prometheus_client import Enum
import app.config as cfg
from app import events
from app.util.hex_util import from_uint2
from app.prosoft.header import Header
from app.projection_status import ProjectionStatusEnum
from app.laser_client_status import LaserClientStatus
import app.metrics as Metrics
from app.logging.logger import yield_logger

log = yield_logger()

HEADER_LENGTH = 6


class LaserClient:
    '''Prosoft laser client capable or interacting with server: logging, starting and stopping projections'''

    def __init__(self, event_emitter: EventEmitter, stop_event: Event, task_id=None):
        self.connected = False
        self.merged_dxf_projection_path = None
        self.socket = None
        self.active_task_id = task_id  # default is None
        self.projection_shown = False
        self.event_emitter = event_emitter

        self.event_emitter.add_listener(events.CONNECT_TO_PROSOFT, self.connect)
        self.event_emitter.add_listener(events.DISCONNECT_FROM_PROSOFT, self.disconnect)
        self.event_emitter.add_listener(events.RECONNECT_TO_PROSOFT, self.reconnect)
        self._stop_event = stop_event
        self.state_reporter = Enum('lh_client_state', 'Laser Hub LaserClient state: connected/disconnected',
                                   states=[LaserClientStatus.LASER_CLIENT_CONNECTED.value, LaserClientStatus.LASER_CLIENT_DISCONNECTED.value],
                                   labelnames=Metrics.get_label_keys())

    def stopped(self):
        return self._stop_event.isSet()

    def reconnect(self):
        """ Reconnect to Prosoft """

        log.info("Reconnecting to PRO-SOFT")
        self.disconnect()
        self.connect()

    def connect(self):
        """ Connect to Prosoft """

        log.info(f'Trying to connect to {cfg.PROSOFT_HOST}:{cfg.PROSOFT_PORT}')
        self.socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.socket.connect((cfg.PROSOFT_HOST, cfg.PROSOFT_PORT))

        self._report_laser_status(LaserClientStatus.LASER_CLIENT_CONNECTED)
        # init
        log.info('Waiting for available task from PRO-SOFT...')

    def disconnect(self):
        """ Disconnect from Prosoft """
        if self.socket is not None:
            self.socket.close()
        self._report_laser_status(LaserClientStatus.LASER_CLIENT_DISCONNECTED)
        log.info("Disconnected from PRO-SOFT")

    def is_connected(self):
        '''Is client connected to Prosoft'''

        return self.connected

    def __del__(self):
        '''Class destructor'''

        if self.socket is not None:
            self.socket.close()
            self._report_laser_status(LaserClientStatus.LASER_CLIENT_DISCONNECTED)

    @staticmethod
    def _get_available_tasks(data):
        '''Parse available task message and get list of available tasks'''

        i = 2
        tasks = []
        while i < len(data):
            task_id = from_uint2(data[i:i + 2])
            tasks.append(task_id)
            i += 2
        task_count = from_uint2(data[0:2])
        if task_count != len(tasks):
            raise Exception(
                f'Invalid tasks content. Expected {len(tasks)}, got {task_count}')
        tasks.sort()
        log.info(f'Available tasks: {tasks}')
        return tasks

    def _get_msg(self):
        '''Generic method for getting messages'''

        response = self.socket.recv(1024)
        if len(response) <= 0:
            raise Exception('Socket inactive on server side')
        header = response[:6]
        body = response[6:]

        parsed_header = Header(from_uint2(header[0:2]), from_uint2(
            header[2:4]), from_uint2(header[4:6]))
        self._print_response(parsed_header, body)

        return parsed_header, body

    def _send_msg(self, header: Header, body: bytes):
        '''Generic method for sending messages'''

        log.debug('----------------------REQUEST-------------------------------')
        req_header = header.build()
        log.debug(f'BODY: {body}')
        log.debug(f'HEADER: {req_header}')
        if body:
            self.socket.send(req_header + body)
        else:
            self.socket.send(req_header)

    @staticmethod
    def _print_response(header: Header, data: bytes):
        '''Helper method for printing messages'''

        log.debug('----------------------RESPONSE-------------------------------')
        log.debug(header)
        log.debug('BODY')
        i = 0
        body = []
        while i < len(data):
            body.append(from_uint2(data[i:i + 2]))
            i += 2
        log.debug(f'{str(body)}\n')

    def _login(self):
        '''Send login message to Prosoft'''

        log.debug('----------------------LOGIN-------------------------------')
        header = Header(HEADER_LENGTH, self.active_task_id, 0x0002)
        self._send_msg(header, None)

    def start_projection(self, merged_dxf_projection_path):
        '''Send start projection message to Prosoft'''

        log.info(f'[0x0020] Sending projection from {merged_dxf_projection_path}')
        body = merged_dxf_projection_path.encode()
        msg_length = HEADER_LENGTH + len(body)
        header = Header(msg_length, self.active_task_id, 0x0020)
        log.debug(header)
        self._send_msg(header, body)
        self.projection_shown = True

    def stop_projection(self):
        '''Send stop projection message to Prosoft'''

        if self.projection_shown:
            log.info('[0x0030] Stopping projection')
            header = Header(HEADER_LENGTH, self.active_task_id, 0x0030)
            log.debug(header)
            self._send_msg(header, None)
            self.projection_shown = False

    def _handle_start_projection_response(self, body: bytes):
        '''Handle start projection response from Prosoft'''
        projection_response_code = from_uint2(body[0:2])
        if projection_response_code == 0:
            response = "[0x0120] File projection successful"
            log.info(response)
            self.event_emitter.emit(events.PROJECTION_STATUS, response, ProjectionStatusEnum.SUCCESS_CODE.value)
        elif projection_response_code == 1:
            response_error = 'Open file failed'
            log.error(response_error)
            self.event_emitter.emit(events.PROJECTION_STATUS, response_error, ProjectionStatusEnum.ERROR_CODE.value)
        elif projection_response_code == 2:
            response_error = 'Response: no file open'
            log.error(response_error)
            self.event_emitter.emit(events.PROJECTION_STATUS, response_error, ProjectionStatusEnum.ERROR_CODE.value)
        elif projection_response_code == 3:
            response_error = "System not calibrated"
            log.error(response_error)
            self.event_emitter.emit(events.PROJECTION_STATUS, response_error, ProjectionStatusEnum.ERROR_CODE.value)
        else:
            response_error = f'Invalid response code \'{projection_response_code}\' received when trying to project a file'
            self.event_emitter.emit(events.PROJECTION_STATUS, response_error, ProjectionStatusEnum.ERROR_CODE.value)
            raise Exception(response_error)

    def _handle_stop_projection_response(self, body: bytes):
        projection_response_code = from_uint2(body[0:2])
        if projection_response_code == 0:
            log.info('[0x0130] File projection stopped successfully')
        elif projection_response_code == 2:
            stop_projection_error = 'Response: no file open'
            log.error(stop_projection_error)
            self.event_emitter.emit(events.PROJECTION_STATUS, stop_projection_error, ProjectionStatusEnum.ERROR_CODE.value)
        elif projection_response_code == 3:
            stop_projection_error = 'System not calibrated'
            log.error(stop_projection_error)
            self.event_emitter.emit(events.PROJECTION_STATUS, stop_projection_error, ProjectionStatusEnum.ERROR_CODE.value)
        else:
            stop_projection_error = f'Invalid response code \'{projection_response_code}\' received when trying to project a file'
            self.event_emitter.emit(events.PROJECTION_STATUS, stop_projection_error, ProjectionStatusEnum.ERROR_CODE.value)
            raise Exception(stop_projection_error)

    def _handle_available_tasks_response(self, body: bytes):
        log.info('[0x0001] List of available tasks received')
        available_tasks = self._get_available_tasks(body)
        if cfg.DEFAULT_TASK_ID:
            self.active_task_id = cfg.DEFAULT_TASK_ID
            log.info(f'Default task provided. Trying to login with default task {self.active_task_id}')
            self._login()
        elif self.active_task_id is None:
            self._handle_available_tasks_when_active_task_not_set(
                available_tasks)
        elif self.active_task_id is not None:
            self._handle_available_tasks_when_active_task_set(available_tasks)
        else:
            log.info(f'Continuing working with task {self.active_task_id}')

    def _handle_login_response(self, body: bytes):
        '''Handle login response'''
        login_response_code = from_uint2(body[0:2])
        if login_response_code == 0:
            log.info(f'[0x0003] Login successful. Connected to task {self.active_task_id}')
            self.connected = True
        elif login_response_code == 1:
            response_error = 'Response: Login denied'
            log.error(response_error)
            self.event_emitter.emit(events.PROJECTION_STATUS, response_error, ProjectionStatusEnum.ERROR_CODE.value)
        else:
            response_error = f'Invalid response code \'{login_response_code}\' received when trying to login on task {self.active_task_id}'
            self.event_emitter.emit(events.PROJECTION_STATUS, response_error, ProjectionStatusEnum.ERROR_CODE.value)
            raise Exception(response_error)

    def _handle_logout_response(self):
        '''Handle logout response'''
        log.error('[0x0005] Prosoft logout')
        self.active_task_id = None
        self._report_laser_status(LaserClientStatus.LASER_CLIENT_DISCONNECTED)

    def wait_on_socket(self):
        '''Wait on socket and handle response message'''
        log.debug('Wait on socket!')
        header, body = self._get_msg()

        message_id = header.message_id
        if header.message_id == 0x0120:
            self._handle_start_projection_response(body)
        elif header.message_id == 0x0130:
            self._handle_stop_projection_response(body)
        elif header.message_id == 0x0001:
            self._handle_available_tasks_response(body)
        elif header.message_id == 0x0003:
            self._handle_login_response(body)
        elif header.message_id == 0x0005:
            self._handle_logout_response()
        else:
            error_message = f'Unknown message {message_id} received'
            log.error(error_message)
            self.event_emitter.emit(events.PROJECTION_STATUS, error_message, ProjectionStatusEnum.ERROR_CODE.value)

    def listen(self):
        '''Entry point method which connects to Prosoft and waits for messages to process it'''
        self.connect()
        while not self.stopped():
            try:
                self.wait_on_socket()
            except Exception as ex:
                log.error(ex)
                self.event_emitter.emit(events.PROJECTION_STATUS, str(ex), ProjectionStatusEnum.ERROR_CODE.value)
                self.connected = False
                self.socket.close()
                self._report_laser_status(LaserClientStatus.LASER_CLIENT_DISCONNECTED)
                # lets wait for some time before reconnecting
                time.sleep(10) # nosemgrep: python.lang.best-practice.sleep.arbitrary-sleep
                self.connect()

    def _handle_available_tasks_when_active_task_not_set(self, available_tasks: list):
        if len(available_tasks) > 0:
            log.info(f'Available tasks: {available_tasks}\n')
            # take first free task
            self.active_task_id = available_tasks[0]
            self._login()
        elif len(available_tasks) == 0:
            task_not_available = 'No available tasks. Connection lost to PRO-SOFT'
            log.error(task_not_available)
            self.event_emitter.emit(events.PROJECTION_STATUS, task_not_available, ProjectionStatusEnum.ERROR_CODE.value)
            self.connected = False

    def _handle_available_tasks_when_active_task_set(self, available_tasks: list):
        if self.connected and len(available_tasks) == 0:
            log.info(f'Continuing working with task {self.active_task_id}')
        elif len(available_tasks) == 0:
            task_not_available = 'No available tasks. Connection lost to PRO-SOFT'
            log.error(task_not_available)
            self.event_emitter.emit(events.PROJECTION_STATUS, task_not_available, ProjectionStatusEnum.ERROR_CODE.value)
            self.connected = False

        elif len(available_tasks) > 0:
            if self.active_task_id in available_tasks and self.connected is False:
                log.info(f'Trying to login with task id {self.active_task_id}')
                self._login()
            elif self.active_task_id not in available_tasks and self.connected:
                log.info(f'Continuing working with task {self.active_task_id}')
            else:
                self.active_task_id = available_tasks[0]
                log.info(f'Default task not available. Choose the task {self.active_task_id}')
                self._login()

    def _report_laser_status(self, status: LaserClientStatus):
        '''Generic method to report laser status'''
        self.state_reporter.labels(**Metrics.get_labels()).state(status.value)
