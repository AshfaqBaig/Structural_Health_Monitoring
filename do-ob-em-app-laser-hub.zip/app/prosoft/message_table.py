'''List of laser-hub supported messages'''

message_table = {
    0x0001: 'List of Available Tasks',
    0x0002: 'Client Login',
    0x0003: 'Client Login Acknowledge',
    0x0005: 'PRO-SOFT Logout',
    0x0020: 'Start Projection',
    0x0030: 'Stop Projection',
    0x0120: 'Result of “Start Projection”',
    0x0130: 'Result of “Stop Projection”'
}
