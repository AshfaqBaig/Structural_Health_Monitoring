# pylint: disable=missing-module-docstring

from app.util.hex_util import to_uint2, padhex
from app.prosoft.message_table import message_table


class Header:
    '''Prosoft Header builder class which takes 3 arguments it builds a valid Prosoft's message header'''

    def __init__(self, message_length, connection_id, message_id):
        if message_length is None or message_id is None or connection_id is None:
            raise BaseException('Unable to construct header due to missing parameters')
        self.message_length = message_length
        self.message_id = message_id
        self.connection_id = connection_id

    def build(self):
        '''Build final header in bytes'''

        return to_uint2(self.message_length) + to_uint2(self.connection_id) + to_uint2(self.message_id)

    def __str__(self):
        message_length = hex(self.message_length)
        connection_id = hex(self.connection_id)
        message_id = hex(self.message_id)
        msg_label = message_table.get(int(message_id, 16))
        return f'HEADER: Length: {int(message_length, 16)} ({padhex(message_length)}) \
          Connection ID: {int(connection_id, 16)} ({padhex(connection_id)}) \
          Message ID: {padhex(message_id)} ({msg_label})'

    def __eq__(self, other):
        if not isinstance(other, Header):
            return NotImplemented
        return self.message_length == other.message_length and \
            self.message_id == other.message_id and \
            self.connection_id == other.connection_id
