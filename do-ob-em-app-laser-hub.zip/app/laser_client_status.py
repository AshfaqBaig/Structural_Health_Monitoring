from enum import Enum


class LaserClientStatus(Enum):
    """
    Enum to store various possible Laser Client statuses
    """
    LASER_CLIENT_CONNECTED = 'connected'
    LASER_CLIENT_DISCONNECTED = 'disconnected'