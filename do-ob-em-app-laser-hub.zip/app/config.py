'''Module defines all configuration options'''

import os
import logging

from os import environ as env
from distutils.util import strtobool

MODULE_APP_NAME = "laser-hub"
LOGGER_CONFIG = os.getenv("LOGGER_CONFIG", "logging-plain.ini")
IOTEDGE_DEVICEID = os.environ.get("IOTEDGE_DEVICEID")
IOTEDGE_MODULEID = os.environ.get("IOTEDGE_MODULEID")
IOTEDGE_GATEWAYHOSTNAME = os.environ.get("IOTEDGE_GATEWAYHOSTNAME")\

LOCATION_ID = os.getenv("LOCATION_ID")
MOULD_ID = None # it is set from etcd

ACTIVE_LASER_HUB_HOST = env.get('ACTIVE_LASER_HUB_HOST')
LOG_LEVEL = env.get('LOG_LEVEL', logging.INFO)
PROSOFT_HOST = env.get('PROSOFT_HOST', 'host.docker.internal')
PROSOFT_PORT = int(env.get('PROSOFT_PORT', 1024))
PROJECTION_PERIOD_LENGTH_S = int(env.get('PROJECTION_PERIOD_LENGTH_S', 5))
PROJECTION_TTL = int(env.get('PROJECTION_TTL', 300))
DXF_OUTPUT_PATH = env.get('DXF_OUTPUT_PATH', '/workspaces/do-ob-em-app-laser-hub/standalone/feedback/')
LASER_DXF_INPUT_PATH: str = env.get('LASER_DXF_INPUT_PATH', 'D:\\LABShare\\')
CONNECT_TO_PROSOFT: bool = bool(strtobool(env.get('CONNECT_TO_PROSOFT', "True")))
PROJECT_TO_IMG: bool = bool(strtobool(env.get('PROJECT_TO_IMG', "False")))
DEFAULT_TASK_ID: int = (isinstance(env.get('DEFAULT_TASK_ID'), int) and int(env.get('DEFAULT_TASK_ID'))) or None

PROMETHEUS_PORT = int(os.environ.get("PROMETHEUS_PORT") or 9060)

MODULE_SETTINGS_KEY = f"/devices/{IOTEDGE_GATEWAYHOSTNAME}/modules/{MODULE_APP_NAME}/settings"
ETCD_URL = os.getenv("ETCD_URL", "localhost:2379")
ETCD_TTL = int(os.getenv("ETCD_TTL", "600"))
