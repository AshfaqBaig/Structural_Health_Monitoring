"""Module defines all events supported by module"""

PROJECTION_STATUS = "processErrorEvent"
CONNECT_TO_PROSOFT = "connectToProsoft"
DISCONNECT_FROM_PROSOFT = "disconnectFromProsoft"
RECONNECT_TO_PROSOFT = "reconnectToProsoft"
