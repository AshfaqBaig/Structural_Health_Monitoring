import json
import math
from datetime import datetime
from dateutil import parser
from prometheus_client.metrics import Histogram, Summary
import app.metrics as Metrics
import app.config as cfg

from app.logging.logger import yield_logger
log = yield_logger()

HISTOGRAM_BUCKETS = (2, 2.5, 3, 3.5, 4, 4.5, 5, math.inf)


class ProjectionProcessor:
    '''Projection class pushes AMQP message to queue for processing'''

    def __init__(self, queue):
        self.queue = queue

        self.metrics_histogram = Histogram("toolchain_duration_histogram_seconds",
                                    "Toolchain duration from IG up to LH histogram in seconds",
                                    buckets=HISTOGRAM_BUCKETS,
                                    labelnames=Metrics.get_label_keys())
        self.metrics_summary = Summary("toolchain_duration_seconds",
                                "Toolchain duration from IG up to LH summary in seconds",
                                labelnames=Metrics.get_label_keys())
    def run(self, stream) -> None:
        '''Read REST payload stream and forward it to scheduler for projecting'''

        request = json.load(stream)
        custom_properties = request.get("custom_properties", {})
        correlation_id = request.get('correlation_id')
        self._process_capture_timestamp(custom_properties, correlation_id)

        if request.get('session') is None:
            log.warning('Invalid payload, no session attribute')
            return
        self.queue.put(request)
        log.debug(f"Projection {request.get('session')} (expiration={request.get('expiration')}) pushed to the queue (size={self.queue.qsize()})", extra={"correlation_id": correlation_id})

    def _process_capture_timestamp(self, custom_properties: dict, correlation_id: str) -> None:
        timestamp = custom_properties.get("capture-timestamp")
        if timestamp is not None:
            captured_image_timestamp = parser.isoparse(timestamp)
            difference = datetime.now() - captured_image_timestamp.replace(tzinfo=None)
            difference_in_s = round(difference.total_seconds(), 2)
            log.info(f"Time difference between capture (reception) {difference_in_s}sec", extra={"correlation_id": correlation_id})
            self.metrics_histogram.labels(**Metrics.get_labels()).observe(difference_in_s)
            self.metrics_summary.labels(**Metrics.get_labels()).observe(difference_in_s)
