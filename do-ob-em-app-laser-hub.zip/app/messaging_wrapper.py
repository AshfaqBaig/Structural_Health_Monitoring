""" Messaging Wrapper """
import asyncio
import json
from pyee.base import EventEmitter
from azure.iot.device import Message
from azure.iot.device.aio import IoTHubModuleClient
import app.config as cfg
from app import events
from app import routes_constants
from app.logging.logger import yield_logger

log = yield_logger()


class MessagingWrapper:
    """ Messaging Wrapper for Edge Hub routed messages """

    def __init__(self, module_client: IoTHubModuleClient, event_emitter: EventEmitter):
        self._module_client = module_client
        log.info(f"Registering '{events.PROJECTION_STATUS}' event listener")
        event_emitter.add_listener(
            events.PROJECTION_STATUS, self.send_message_to_trace_sync)

    async def send_message_to_trace(self, status_message: str, status_code: int) -> None:
        """Sends a message to trace output"""
        trace_payload = {
            "StatusCode": status_code,
            "StatusMessage": status_message
        }
        content_type = f"{cfg.MODULE_APP_NAME}-trace"
        await self._send_message(trace_payload, routes_constants.TRACE_OUTPUT, content_type)

    def send_message_to_trace_sync(self, status_message: str, status_code: int) -> None:
        """Sends a message to trace output synchronously"""

        asyncio.run(self.send_message_to_trace(status_message, status_code))

    async def _send_message(self, message, output_name, content_type=None) -> None:
        """ Sends a message to Edge Hub routed output """
        log.debug(f"Sending message: {message} to output: {output_name}")
        message = Message(data=json.dumps(message))
        message.content_type = content_type
        await self._module_client.send_message_to_output(message, output_name)
