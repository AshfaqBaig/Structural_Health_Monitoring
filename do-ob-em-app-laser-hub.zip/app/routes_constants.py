""" Edge Hub routes constants """

TRACE_OUTPUT = "traceOutput"
