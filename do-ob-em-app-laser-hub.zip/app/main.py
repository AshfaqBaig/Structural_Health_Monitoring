'''
Application entrypoint module
'''

import app.config as cfg
from app.module import Module

from app.logging.logger import yield_logger, update_log_level

log = yield_logger()
update_log_level(log, cfg.LOG_LEVEL)

module = Module()
application = module.create_api()
module.start()
