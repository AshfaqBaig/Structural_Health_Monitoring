export PYTHONPATH='./'

echo "Executing Tests..."
python -m pytest tests/
if (($? != '0'))
then
  echo "Failed for Unit-Test"
  rm -r Noneverifier-*.log
  exit $?
fi

echo "Executing Pylint"
pylint ./app/ || pylint-exit $?

