# pylint: disable=protected-access, missing-class-docstring, missing-function-docstring

from app.util.hex_util import padhex, to_uint2, from_uint2

def test_padhex():
    result = padhex('aaaa')
    assert result is not None

def test_to_uint2_1():
    result = to_uint2(0x00FF)
    assert result == bytes([255, 0])

def test_to_uint2_2():
    result = to_uint2(0x01)
    assert result ==  bytes([1, 0])

def test_from_uint2_1():
    result = from_uint2(bytes([1, 0]))
    assert result is not None
    assert result == 0x0001

def test_from_uint2_2():
    result = from_uint2(bytes([255, 0]))
    assert result is not None
    assert result == 0x00FF
