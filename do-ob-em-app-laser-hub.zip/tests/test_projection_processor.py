# pylint: disable=missing-class-docstring, missing-function-docstring, protected-access, line-too-long
import logging
import json
import base64
import io
from queue import Queue
from prometheus_client import REGISTRY

import pytest

import app.config as cfg

@pytest.fixture(autouse=True, scope="module", name="environment")
def fixture_environment():
    cfg.CONNECT_TO_PROSOFT = True

@pytest.fixture(name="metric_labels", autouse=True)
def fixture_metric_labels(environment): # pylint: disable=unused-argument
    return {
        "device_id": cfg.IOTEDGE_DEVICEID,
        "module_id": cfg.IOTEDGE_MODULEID,
        "mould_id": cfg.MOULD_ID,
        "prosoft_host": cfg.PROSOFT_HOST,
        "location": cfg.LOCATION_ID
    }

@pytest.fixture(name="projection_processor", scope="function")
def fixture_processor(prometheus_reset): # pylint: disable=unused-argument
    queue = Queue()
    # full import here, other metrics collectors are not correctly initialised
    from app.processors.projection import ProjectionProcessor # pylint: disable=import-outside-toplevel
    return ProjectionProcessor(queue)

@pytest.fixture(name="encoded_dxf")
def fixture_encoded_dxf():
    with open('./sample-shapes/polyline.dxf', 'rb') as dxf_file:
        return base64.b64encode(dxf_file.read()).decode()

@pytest.fixture(name="payload")
def fixture_payload(encoded_dxf):
    return {
        'content': encoded_dxf,
        'session': {
            'cameraId': 'camera-id',
            'moduleId': 'em-edge-detection-feedback'
        },
        "custom_properties": {
            "capture-timestamp": "2022-02-04T07:32:52.046Z"
        }
    }

@pytest.fixture(name="payload_without_custom_properties")
def fixture_payload_without_custom_properties(encoded_dxf):
    return {
        'content': encoded_dxf,
        'session': {
            'cameraId': 'camera-id',
            'moduleId': 'em-edge-detection-feedback'
        }
    }

def test_projection_processor_with_capture_timestamp_provided(projection_processor, encoded_dxf, payload, metric_labels, caplog):
    with caplog.at_level(logging.INFO):
        projection_processor.run(io.BytesIO(json.dumps(payload).encode()))
        assert projection_processor.queue.qsize() == 1

    projection_meta = projection_processor.queue.get()
    assert projection_meta['content'] == encoded_dxf

    assert "Time difference between capture (reception)" in caplog.text

    # check that metrics have changed
    after_summary_metric_count_value = REGISTRY.get_sample_value('toolchain_duration_seconds_count', labels=metric_labels)
    after_summary_metric_sum_value = REGISTRY.get_sample_value('toolchain_duration_seconds_sum', labels=metric_labels)
    assert after_summary_metric_count_value == 1
    assert after_summary_metric_sum_value > 0

def test_projection_processor_with_capture_timestamp_not_provided(projection_processor, encoded_dxf, payload_without_custom_properties, metric_labels, caplog):
    with caplog.at_level(logging.INFO):
        projection_processor.run(io.BytesIO(json.dumps(payload_without_custom_properties).encode()))
        assert projection_processor.queue.qsize() == 1
        projection_meta = projection_processor.queue.get()
        assert projection_meta['content'] == encoded_dxf
    assert "Time difference between capture (reception)" not in caplog.text

    # check that metrics have changed
    after_summary_metric_count_value = REGISTRY.get_sample_value('toolchain_duration_seconds_count', labels=metric_labels)
    after_summary_metric_sum_value = REGISTRY.get_sample_value('toolchain_duration_seconds_sum', labels=metric_labels)
    assert after_summary_metric_count_value is None
    assert after_summary_metric_sum_value is None
