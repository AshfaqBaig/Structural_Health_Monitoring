# pylint: disable=protected-access, missing-class-docstring, missing-function-docstring
import base64
from unittest import mock
from unittest.mock import MagicMock
from queue import Queue
import pytest


from app.scheduler import Scheduler
from app.models.projection_key import ProjectionKey
import app.config as cfg


@pytest.fixture(autouse=True, scope="module", name="environment")
def fixture_environment():
    cfg.DXF_OUTPUT_PATH = '\\\\srv\\temp\\'
    cfg.LASER_DXF_INPUT_PATH = '\\\\srv\\temp\\'

@pytest.fixture(name="scheduler")
def fixture_scheduler():
    return Scheduler(Queue(), MagicMock(), MagicMock())

def test_projections_replace(scheduler):
    projection_payload_1 = {
        'session': {'jobId': 'job_id_1'},
        'expiration': 2,
        'content': base64.b64encode(str.encode("test"))
    }
    scheduler._update_projections(projection_payload_1)
    projection_payload_2 = {
        'session': {'jobId': 'job_id_1'},
        'expiration': 5,
        'content': base64.b64encode(str.encode("test"))
    }
    scheduler._update_projections(projection_payload_2)
    assert len(scheduler.projections) == 1
    projection_key = next(iter(scheduler.projections))
    assert projection_key.expiration == 5

def test_projections_expire_projections(mocker, scheduler):
    mocker.patch('time.time', mock.MagicMock(return_value=0))

    scheduler._update_projections({
        'session': {'jobId': 'job_id_1'},
        'expiration': 5,
        'content': base64.b64encode(str.encode("test"))
    })
    scheduler._update_projections({
        'session': {'jobId': 'job_id_2'},
        'expiration': 10,
        'content': base64.b64encode(str.encode("test"))
    })
    mocker.patch('time.time', mock.MagicMock(return_value=1))
    scheduler._expire_projections()
    assert len(scheduler.projections) == 2

    # expire first projection
    scheduler._update_projections({
        'session': {'jobId': 'job_id_1'},
        'expiration': 600
    })
    assert len(scheduler.projections) == 1

    # expire second projection
    scheduler._update_projections({
        'session': {'jobId': 'job_id_2'}
    })
    assert len(scheduler.projections) == 0

def test_projections_cache_ttl_simple(mocker, scheduler):
    mocker.patch('time.time', mock.MagicMock(return_value=0))

    scheduler._update_projections({
        'session': {'jobId': 'job_id_1'},
        'expiration': 2,
        'content': base64.b64encode(str.encode("test"))
    })
    scheduler._update_projections({
        'session': {'jobId': 'job_id_2'},
        'expiration': 2,
        'content': base64.b64encode(str.encode("test"))
    })
    assert len(scheduler.projections) == 2

    mocker.patch('time.time', mock.MagicMock(return_value=2.1))
    scheduler._expire_projections()
    assert len(scheduler.projections) == 0

def test_projections_cache_ttl_complex(mocker, scheduler):
    mocker.patch('time.time', mock.MagicMock(return_value=0))
    projections = scheduler.projections
    scheduler._display_projections = MagicMock()

    scheduler._update_projections({
        'session': {'jobId': 'job_id_1'},
        'expiration': 2,
        'content': base64.b64encode(str.encode("test"))
    })
    scheduler._update_projections({
        'session': {'jobId': 'job_id_2'},
        'expiration': 2,
        'content': base64.b64encode(str.encode("test"))
    })

    mocker.patch('time.time', mock.MagicMock(return_value=0.5))
    scheduler._expire_projections()
    assert len(projections) == 2
    assert scheduler._display_projections.call_count == 0

    scheduler._update_projections({
        'session': {'jobId': 'job_id_3'},
        'expiration': 2,
        'content': base64.b64encode(str.encode("test"))
    })

    mocker.patch('time.time', mock.MagicMock(return_value=1))
    scheduler._expire_projections()
    assert len(projections) == 3
    assert scheduler._display_projections.call_count == 0

    scheduler._update_projections({
        'session': {'jobId': 'job_id_4'},
        'expiration': 2,
        'content': base64.b64encode(str.encode("test"))
    })
    scheduler._update_projections({
        'session': {'jobId': 'job_id_5'},
        'expiration': 2,
        'content': base64.b64encode(str.encode("test"))
    })

    mocker.patch('time.time', mock.MagicMock(return_value=2))
    scheduler._expire_projections()
    assert len(projections) == 3
    assert projections.get(ProjectionKey({'session': {'jobId': 'job_id_1'}, 'expiration': 2})) is None
    assert projections.get(ProjectionKey({'session': {'jobId': 'job_id_2'}, 'expiration': 2})) is None
    assert projections.get(ProjectionKey({'session': {'jobId': 'job_id_3'}, 'expiration': 2}))  is not None
    assert projections.get(ProjectionKey({'session': {'jobId': 'job_id_4'}})) is not None
    assert projections.get(ProjectionKey({'session': {'jobId': 'job_id_5'}, 'expiration': 2})) is not None
    assert scheduler._display_projections.call_count == 1
