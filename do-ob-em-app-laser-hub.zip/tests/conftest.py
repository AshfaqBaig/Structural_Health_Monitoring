# pylint: disable=missing-class-docstring, missing-function-docstring, protected-access
import logging
import pytest

from prometheus_client import REGISTRY

import app.config as cfg

disable_loggers = ["ezdxf", "asyncio", "matplotlib", "matplotlib.font_manager", "matplotlib.pyplot"]

@pytest.fixture(autouse=True, name="global_environment")
def fixture_global_environment():
    cfg.IOTEDGE_DEVICEID = "device"
    cfg.IOTEDGE_MODULEID = "lg"
    cfg.MOULD_ID = "mould1"
    cfg.PROSOFT_HOST = "123"
    cfg.LOCATION_ID = "aal"
    cfg.DXF_OUTPUT_PATH = '\\\\srv\\temp\\'
    cfg.LASER_DXF_INPUT_PATH = 'D:\\Prosoft\\'
    cfg.PROJECT_TO_IMG = False

@pytest.fixture(autouse=True, name="prometheus_reset", scope="function")
def fixture_prometheus_reset():
    collectors = list(REGISTRY._collector_to_names.keys())
    for collector in collectors:
        REGISTRY.unregister(collector)

def pytest_configure():
    for logger_name in disable_loggers:
        logger = logging.getLogger(logger_name)
        logger.disabled = True
