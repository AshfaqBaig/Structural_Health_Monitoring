# pylint: disable=protected-access, missing-class-docstring, missing-function-docstring
from unittest import mock
import pytest

from app.models.projection_key import ProjectionKey
import app.config as cfg

@pytest.fixture(autouse=True, scope="module", name="environment")
def fixture_environment():
    cfg.PROJECTION_TTL = 2

def test_projection_key_equality_without_expiration():
    projection_1= ProjectionKey({'session': {'jobId': 'job_id_1'}})
    projection_2= ProjectionKey({'session': {'jobId': 'job_id_2'}})
    projection_3= ProjectionKey({'session': {'jobId': 'job_id_1'}})
    assert projection_1 != projection_2
    assert projection_1 == projection_3
    assert projection_1.expiration == cfg.PROJECTION_TTL
    assert projection_2.expiration == cfg.PROJECTION_TTL
    assert projection_3.expiration == cfg.PROJECTION_TTL

def test_projection_key_equality_with_expiration():
    projection_1 = ProjectionKey({'session': {'jobId': 'job_id_1'}})
    projection_2 = ProjectionKey({'session': {'jobId': 'job_id_1'}, 'expiration': 34})
    projection_3 = ProjectionKey({'session': {'jobId': 'job_id_1'}, 'expiration': 5})
    assert projection_1 == projection_2
    assert projection_2 == projection_3
    assert projection_1.expiration == cfg.PROJECTION_TTL
    assert projection_2.expiration == 34
    assert projection_3.expiration == 5

def test_projection_expiration_when_time_did_not_pass(mocker):
    mocker.patch('time.time', mock.MagicMock(return_value=0))
    projection = ProjectionKey({'session': {'jobId': 'job_id_1'}, 'expiration': 2})
    assert projection.expiration == 2

    mocker.patch('time.time', mock.MagicMock(return_value=1)) # mock 1 sec delay
    assert projection.is_expired() is False # not expired yet after 1sec

def test_projection_expiration_when_time_did_pass(mocker):
    mocker.patch('time.time', mock.MagicMock(return_value=0))
    projection = ProjectionKey({'session': {'jobId': 'job_id_1'}, 'expiration': 2})
    assert projection.expiration == 2

    mocker.patch('time.time', mock.MagicMock(return_value=3)) # mock 3 sec delay
    assert projection.is_expired() is True # expired after 3sec
    assert projection._age() >= 3
