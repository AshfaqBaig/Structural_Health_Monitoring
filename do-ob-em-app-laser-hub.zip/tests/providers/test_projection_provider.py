# pylint: disable=protected-access, missing-class-docstring, missing-function-docstring
import logging
from unittest.mock import MagicMock, ANY
import pytest

from app.providers.laser_projection import LaserProjectionProvider
from app.models.projection_key import ProjectionKey
import app.config as cfg


@pytest.fixture(autouse=True, scope="module")
def fixture_environment():
    cfg.CONNECT_TO_PROSOFT = True

@pytest.fixture(name="circle_dxf")
def fixture_circle_dxf():
    with open('./sample-shapes/circle.dxf', 'r', encoding="utf8") as dxf_file:
        return dxf_file.read()

@pytest.fixture(name="polyline_dxf")
def fixture_polyline_dxf():
    with open('./sample-shapes/polyline.dxf', 'r', encoding="utf8") as dxf_file:
        return dxf_file.read()

@pytest.fixture(name="projections_circle")
def fixture_shape_circle(circle_dxf):
    return {
        ProjectionKey({'session': {'jobId': 'job_id_1'}}):
        circle_dxf
    }

@pytest.fixture(name="projections_circle_and_polyline")
def fixture_projections_circle_and_polyline(circle_dxf, polyline_dxf):
    return {
        ProjectionKey({'session': {'jobId': 'job_id_1'}}): circle_dxf,
        ProjectionKey({'session': {'jobId': 'job_id_2'}}): polyline_dxf
    }


def test_project_success(mocker, caplog, projections_circle):
    laser_client = MagicMock()
    merged_dxf_projection_path_for_prosoft = f'{cfg.LASER_DXF_INPUT_PATH}projection.dxf'
    laser_client.start_projection = MagicMock(args=merged_dxf_projection_path_for_prosoft)
    projection_provider = LaserProjectionProvider(laser_client)
    dxf_path = (f'{cfg.LASER_DXF_INPUT_PATH}projection.dxf', f'{cfg.DXF_OUTPUT_PATH}/feedback.dxf')
    projection_provider._generate_merged_projection = MagicMock(args=projections_circle, return_value=dxf_path)
    mocker.patch("os.listdir")

    # RUN
    with caplog.at_level(logging.INFO):
        projection_provider.project(projections_circle)

    # VERIFY
    assert projection_provider._generate_merged_projection.call_args_list[0][0][0] == projections_circle
    laser_client.start_projection.assert_called_once_with(merged_dxf_projection_path_for_prosoft)
    assert "Projecting to laser" in caplog.text

def test_project_laser_not_connected(caplog, projections_circle):
    laser_client = MagicMock()
    merged_dxf_projection_path_for_prosoft = f'{cfg.LASER_DXF_INPUT_PATH}projection.dxf'
    laser_client.start_projection = MagicMock(args=merged_dxf_projection_path_for_prosoft)
    laser_client.is_connected = MagicMock(return_value=False)
    projection_provider = LaserProjectionProvider(laser_client)
    dxf_path = (f'{cfg.LASER_DXF_INPUT_PATH}projection.dxf', f'{cfg.DXF_OUTPUT_PATH}/feedback.dxf')
    projection_provider._generate_merged_projection = MagicMock(args=projections_circle, return_value=dxf_path)

    # RUN
    with caplog.at_level(logging.INFO):
        projection_provider.project(projections_circle)

    # VERIFY
    assert laser_client.is_connected.call_count == 2
    projection_provider._generate_merged_projection.assert_not_called()
    laser_client.start_projection.assert_not_called()

    assert "Not accepting projections because of lost connection to laser client" in caplog.text

def test_generate_merged_projection_single(caplog, circle_dxf, projections_circle):
    laser_client = MagicMock()
    projection_provider = LaserProjectionProvider(laser_client)
    dxf_path = (f'{cfg.LASER_DXF_INPUT_PATH}projection.dxf', f'{cfg.DXF_OUTPUT_PATH}/feedback.dxf')
    projection_provider._write_file = MagicMock(return_value=dxf_path)

    # RUN
    with caplog.at_level(logging.INFO):
        projection_provider._generate_merged_projection(projections_circle)

    # VERIFY
    assert projection_provider._write_file.call_args_list[0][0][0] == ANY
    assert projection_provider._write_file.call_args_list[0][0][1] == circle_dxf
    projection_provider._write_file.assert_called_once_with(
        ANY, circle_dxf)
    assert "Writing file with" in caplog.text

def test_generate_merged_projection_twice(caplog, projections_circle_and_polyline):
    laser_client = MagicMock()
    projection_provider = LaserProjectionProvider(laser_client)
    dxf_path = (f'{cfg.LASER_DXF_INPUT_PATH}projection.dxf', f'{cfg.DXF_OUTPUT_PATH}/feedback.dxf')
    projection_provider._write_file = MagicMock(return_value=dxf_path)

    # RUN
    with caplog.at_level(logging.INFO):
        result_paths = projection_provider._generate_merged_projection(projections_circle_and_polyline)

        # VERIFY
        assert projection_provider._write_file.call_args_list[0][0][0] == ANY
        assert projection_provider._write_file.call_args_list[0][0][1] == ANY
        assert result_paths == dxf_path
        projection_provider._write_file.assert_called_once()
        projection_provider._write_file.assert_called_once_with(
            ANY, ANY)
        assert "Writing file with" in caplog.text
