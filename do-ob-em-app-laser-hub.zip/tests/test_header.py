# pylint: disable=protected-access, missing-class-docstring, missing-function-docstring
import pytest
from app.prosoft.header import Header

def test_create_header_success():
    header = Header(8, 1, 0x003)  # connection id: 1; length: 8; type: 0x003 - Client Login Acknowledgement
    assert type(header), Header

    header_bytes = header.build()
    assert header_bytes == bytes([8, 0, 1, 0, 3, 0])

def test_create_header_failure_1():
    with pytest.raises(BaseException) as exc_info:
        Header(None, 1, 0x001)
    assert exc_info.type == BaseException
    assert exc_info.value.args[0] == "Unable to construct header due to missing parameters"

def test_create_header_failure_2():
    with pytest.raises(BaseException) as exc_info:
        Header(8, None, 0x001)
    assert exc_info.type == BaseException
    assert exc_info.value.args[0] == "Unable to construct header due to missing parameters"

def test_create_header_failure_3():
    with pytest.raises(BaseException) as exc_info:
        Header(None, 1, 0x001)
    assert exc_info.type == BaseException
    assert exc_info.value.args[0] == "Unable to construct header due to missing parameters"

def test_str_and_eq():
    header = Header(8, 1, 0x003)
    assert header.__eq__(header) is True
    assert len(header.__str__().split(' ')) == 34
