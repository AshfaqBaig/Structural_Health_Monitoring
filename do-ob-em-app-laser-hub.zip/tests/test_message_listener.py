# pylint: disable=protected-access, missing-class-docstring, missing-function-docstring, no-self-use
from unittest.mock import AsyncMock, MagicMock
from asyncio import BaseEventLoop
from azure.iot.device.aio import IoTHubModuleClient
import pytest
from app.message_listener import MessageListener

@pytest.fixture(name="message_listener")
def fixture_message_listener(mocker):
    mocker.patch.object(IoTHubModuleClient, "create_from_edge_environment")
    mocker.patch("asyncio.run", return_value=None)
    return MessageListener(MagicMock())

@pytest.fixture(name="asyncio_loop")
def fixture_asyncio_loop(mocker):
    """ Fixture for creating an object of type asyncio.get_event_loop()"""

    mocker.patch.object(BaseEventLoop, "run_in_executor", new_callable=AsyncMock)
    return AsyncMock()

@pytest.mark.asyncio
async def test_empty_listener(mocker, asyncio_loop, message_listener) -> None:
    """ Function to test ModuleListener.run() """
    mocked_connect = mocker.patch.object(message_listener.module_client, "connect", new_callable=AsyncMock)
    mocked_disconnect = mocker.patch.object(message_listener.module_client, "disconnect", new_callable=AsyncMock)
    mocker.patch("asyncio.get_event_loop", return_value=asyncio_loop)
    await message_listener.run()

    assert mocked_connect.call_count == 1
    assert mocked_disconnect.call_count == 1
