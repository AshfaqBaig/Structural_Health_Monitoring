# pylint: disable=protected-access, missing-class-docstring, missing-function-docstring

from app.util.dxf_util import merge_dxf

def test_merge_dxf():
    dxf_file1 = open('./sample-shapes/001000001.dxf', 'r', encoding="utf8")
    dxf_file2 = open('./sample-shapes/002000002.dxf', 'r', encoding="utf8")
    dxf = merge_dxf([dxf_file1.read(), dxf_file2.read()])
    assert dxf is not None
    assert len(dxf.modelspace().query('POLYLINE')) == 3
    for entity in dxf.modelspace().query('POLYLINE'):
        assert entity.dxf.layer == 'merged'
