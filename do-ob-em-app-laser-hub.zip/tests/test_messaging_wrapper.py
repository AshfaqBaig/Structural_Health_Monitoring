# pylint: disable=protected-access, missing-module-docstring, missing-class-docstring, missing-function-docstring, duplicate-code, line-too-long, too-few-public-methods, no-self-use, too-many-locals, too-many-lines
from unittest.mock import AsyncMock, MagicMock
from app import routes_constants
from app.messaging_wrapper import MessagingWrapper



def test_send_message_to_trace(mocker):
    module_client = mocker.patch("app.messaging_wrapper.IoTHubModuleClient", new_callable=AsyncMock)
    messaging_wrapper = MessagingWrapper(module_client, MagicMock())
    message = {
        "StatusCode": 500,
        "StatusMessage": "No available tasks. Connection lost to PRO-SOFT"
    }

    messaging_wrapper.send_message_to_trace_sync(message['StatusMessage'], message['StatusCode'])

    module_client.send_message_to_output.assert_called_once()
    call_args = module_client.send_message_to_output.call_args.args
    assert len(call_args) == 2
    assert call_args[1] == routes_constants.TRACE_OUTPUT
