# pylint: disable=protected-access, missing-class-docstring, missing-function-docstring
from unittest.mock import Mock, MagicMock
import pytest
from app.laser_client import LaserClient, HEADER_LENGTH
from app.prosoft.header import Header
import app.config as cfg

@pytest.fixture(scope="module", autouse=True)
def fixture_default_configuration():
    cfg.CONNECT_TO_PROSOFT= True
    cfg.PROJECT_TO_IMG=False
    cfg.DEFAULT_TASK_ID= None

def test_response_0x0001_use_same_task():
    current_active_task_id = 1

    laser_client = LaserClient(MagicMock(), MagicMock())
    laser_client.active_task_id = current_active_task_id
    laser_client.connected = True
    mock_header = Header(8, 1, 0x0001)  # request list of available tasks
    laser_client._get_msg = MagicMock(return_value=[mock_header, bytes(
        [2, 0, 3, 0, 2, 0])])  # tasks: 2 and 3 are available
    laser_client.event_emitter.emit = MagicMock()

    laser_client.wait_on_socket()

    laser_client._get_msg.assert_called_once()
    laser_client.event_emitter.emit.assert_not_called()
    assert laser_client.active_task_id == current_active_task_id  # use same task


def test_response_0x0001_no_available_tasks():
    laser_client = LaserClient(MagicMock(), MagicMock())
    laser_client.connected = False
    mock_header = Header(8, 1, 0x0001)  # response: list of available tasks
    laser_client._get_msg = MagicMock(return_value=[mock_header, bytes(
        [0, 0])])  # tasks: no available tasks
    laser_client.event_emitter.emit = MagicMock()

    laser_client.wait_on_socket()

    laser_client._get_msg.assert_called_once()
    laser_client.event_emitter.emit.assert_called_once()
    assert laser_client.connected is False  # laser_client as disconnected

def test_response_0x0001_take_first_available_task():
    laser_client = LaserClient(MagicMock(), MagicMock())
    laser_client.connected = False
    mock_header = Header(8, 1, 0x0001)  # request list of available tasks
    laser_client._get_msg = MagicMock(return_value=[mock_header, bytes(
        [2, 0, 1, 0, 2, 0])])  # tasks: 1 and 2 are available
    laser_client.event_emitter.emit = MagicMock()
    laser_client._login = MagicMock()

    laser_client.wait_on_socket()

    laser_client._get_msg.assert_called_once()
    laser_client.event_emitter.emit.assert_not_called()
    assert laser_client.active_task_id == 1  # use same first task

def test_response_0x0003_success():
    current_active_task_id = 1
    laser_client = LaserClient(MagicMock(), MagicMock())
    laser_client.active_task_id = current_active_task_id
    laser_client.connected = False
    mock_header = Header(6, 1, 0x0003)  # response: login
    laser_client._get_msg = MagicMock(return_value=[mock_header, bytes([])])
    laser_client.event_emitter.emit = MagicMock()

    laser_client.wait_on_socket()

    laser_client._get_msg.assert_called_once()
    laser_client.event_emitter.emit.assert_not_called()
    assert laser_client.connected is True  # laser_client is connected
    assert laser_client.active_task_id == 1  # same task

def test_response_0x0005_success():
    current_active_task_id = 1
    laser_client = LaserClient(MagicMock(), MagicMock())
    laser_client.active_task_id = current_active_task_id
    laser_client.connected = False
    mock_header = Header(6, 1, 0x0005)  # response: logout
    laser_client._get_msg = MagicMock(return_value=[mock_header, bytes([])])
    laser_client.event_emitter.emit = MagicMock()

    laser_client.wait_on_socket()

    laser_client._get_msg.assert_called_once()
    laser_client.event_emitter.emit.assert_not_called()
    assert laser_client.connected is False  # laser_client is disconnected
    assert laser_client.active_task_id is None  # no task

def test_response_0x0120_success():
    laser_client = LaserClient(MagicMock(), MagicMock())
    mock_header = Header(8, 1, 0x0120)
    laser_client._get_msg = MagicMock(return_value=[mock_header, bytes([0, 0])])
    laser_client.event_emitter.emit = MagicMock()

    laser_client.wait_on_socket()

    laser_client._get_msg.assert_called_once()
    laser_client.event_emitter.emit.assert_called_once()
    call_args = laser_client.event_emitter.emit.call_args.args
    assert len(call_args) == 3
    assert call_args[1] == '[0x0120] File projection successful'
    assert call_args[2] == 200

def test_response_0x0120_failure():
    laser_client = LaserClient(MagicMock(), MagicMock())
    mock_header = Header(8, 1, 0x0120)
    laser_client._get_msg = MagicMock(return_value=[mock_header, bytes([1, 0])])
    laser_client.event_emitter.emit = MagicMock()

    laser_client.wait_on_socket()

    laser_client._get_msg.assert_called_once()
    laser_client.event_emitter.emit.assert_called_once()

def test_response_0x0130_success():
    laser_client = LaserClient(MagicMock(), MagicMock())
    mock_header = Header(8, 1, 0x0130)
    laser_client._get_msg = MagicMock(return_value=[mock_header, bytes([0, 0])])
    laser_client.event_emitter.emit = MagicMock()

    laser_client.wait_on_socket()

    laser_client._get_msg.assert_called_once()
    laser_client.event_emitter.emit.assert_not_called()

def test_response_0x0130_failure():
    laser_client = LaserClient(MagicMock(), MagicMock())
    mock_header = Header(8, 2, 0x0130)
    laser_client._get_msg = MagicMock(return_value=[mock_header, bytes([2, 0])])
    laser_client.event_emitter.emit = MagicMock()

    laser_client.wait_on_socket()

    laser_client._get_msg.assert_called_once()
    laser_client.event_emitter.emit.assert_called_once()

def test_start_projection_success():
    current_active_task_id = 1
    dxf_path = '\\\\srv\\temp\\projection.dxf'

    laser_client = LaserClient(MagicMock(), MagicMock())
    laser_client.active_task_id = current_active_task_id
    laser_client._send_msg = MagicMock()
    laser_client.event_emitter.emit = MagicMock()

    laser_client.start_projection(dxf_path)

    expected_header = Header(HEADER_LENGTH + len(dxf_path.encode()), 1, 0x0020)  # request: start projection
    laser_client._send_msg.assert_called_once_with(expected_header, dxf_path.encode())
    laser_client.event_emitter.emit.assert_not_called()

def test_stop_projection_success():
    current_active_task_id = 1

    laser_client = LaserClient(MagicMock(), MagicMock())
    laser_client.active_task_id = current_active_task_id
    laser_client.projection_shown = True
    laser_client._send_msg = MagicMock()
    laser_client.event_emitter.emit = MagicMock()

    laser_client.stop_projection()

    expected_header = Header(HEADER_LENGTH, 1, 0x0030)  # request: stop projection
    laser_client._send_msg.assert_called_once_with(expected_header, None)
    laser_client.event_emitter.emit.assert_not_called()

def test_login_success():
    current_active_task_id = 1

    laser_client = LaserClient(MagicMock(), MagicMock())
    laser_client.active_task_id = current_active_task_id
    laser_client._send_msg = MagicMock()
    laser_client.event_emitter.emit = MagicMock()

    laser_client._login()

    expected_header = Header(HEADER_LENGTH, 1, 0x0002)  # request: login
    laser_client._send_msg.assert_called_once_with(expected_header, None)
    laser_client.event_emitter.emit.assert_not_called()

def test_get_msg():
    laser_client = LaserClient(MagicMock(), MagicMock())

    laser_client.socket = Mock()
    laser_client.socket.recv = MagicMock(return_value=bytes([8, 0, 1, 0, 1, 0, 97, 98, 99]))  # abc
    laser_client.event_emitter.emit = MagicMock()

    header, body = laser_client._get_msg()

    expected_header = Header(8, 1, 0x0001)
    assert header == expected_header
    assert body == 'abc'.encode()
    laser_client.socket.recv.assert_called_once()
    laser_client.event_emitter.emit.assert_not_called()

def test_send_msg():
    header = Header(8, 1, 0x0001)

    laser_client = LaserClient(MagicMock(), MagicMock())
    laser_client.socket = Mock()
    laser_client.socket.send = MagicMock()
    laser_client.event_emitter.emit = MagicMock()

    laser_client._send_msg(header, 'abc'.encode())
    message = header.build() + 'abc'.encode()
    laser_client.socket.send.assert_called_with(message)

    laser_client._send_msg(header,None)
    message = header.build()
    laser_client.socket.send.assert_called_with(message)
    laser_client.event_emitter.emit.assert_not_called()
