import shutil

from app.util.dxf_util import dxf2image

def test_dxf2image(tmp_path):
    '''Test for dxf2image'''
    # Arrange
    with open('./sample-shapes/001000001.dxf', 'r', encoding="utf8") as dxf_file:
        dxf_str = dxf_file.read()

        tmp_file = tmp_path/"ply.dxf"
        tmp_file.write_text(dxf_str)

        # Act
        dxf2image(str(tmp_file))
        folder_content = [str(f) for f in list(tmp_path.iterdir())]

        # Assert
        assert len(folder_content) == 2
        assert len([f for f in folder_content if f.endswith('.png')]) == 1

        # Remove the temporay path
        shutil.rmtree(str(tmp_path))
