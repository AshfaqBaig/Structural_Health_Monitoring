# em-laser-hub
![Python](https://img.shields.io/badge/Python-3.9-informational)
![Docker](https://img.shields.io/badge/do--ob--dops--base--image-v0.0.11-green)

![azure-iot-device](https://img.shields.io/badge/azure--iot--device-v2.11.0-informational)
![azure-iot-device (latest)](https://img.shields.io/pypi/v/azure--iot--device?label=latest)
![ezdxf](https://img.shields.io/badge/ezdxf-v0.17.2-informational)
![ezdxf (latest)](https://img.shields.io/pypi/v/ezdxf?label=latest)
![requests](https://img.shields.io/badge/humanize-v2.27.1-informational)
![requests (latest)](https://img.shields.io/pypi/v/humanize?label=latest)
![falcon](https://img.shields.io/badge/falcon-v3.0.1-informational)
![falcon (latest)](https://img.shields.io/pypi/v/falcon?label=latest)
![uwsgi](https://img.shields.io/badge/uwsgi-v2.0.20.0-informational)
![uwsgi (latest)](https://img.shields.io/pypi/v/uwsgi?label=latest)
![numpy](https://img.shields.io/badge/numpy-v1.22.3-informational)
![numpy (latest)](https://img.shields.io/pypi/v/numpy?label=latest)
![matplotlib](https://img.shields.io/badge/matplotlib-v3.5.2-informational)
![matplotlib (latest)](https://img.shields.io/pypi/v/matplotlib?label=latest)
![prometheus-python](https://img.shields.io/badge/prometheus--client-v0.14.1-informational)
![prometheus-python (latest)](https://img.shields.io/pypi/v/prometheus--client?label=latest)
![python-json-logger](https://img.shields.io/badge/python--json--logger-v2.0.2-informational)
![python-json-logger (latest)](https://img.shields.io/pypi/v/python--json--logger?label=latest)

# Introduction 
Laser hub module responsible for pushing DXF files to LAP PROSOFT which forwards it to laser

# Environment variables

| Parameter      | Default value                                      | Description                                                                                            |
| -------------- | -------------------------------------------------- | ------------------------------------------------------------------------------------------------------ |
| PROSOFT_HOST  | 0.0.0.0                                      | PROSOFT hostname |
| PROSOFT_PORT  | 1024                                      | PROSOFT port |
| PROJECTION_PERIOD_LENGTH_S  | 5                                      | How often queued DXFs should be merged |
| ACTIVE_LASER_HUB_HOST | | Active laser-hub host name. Module will be enabled only when this flag matches a edge machines hostname |
| PROJECTION_TTL | 300 seconds | How long projection is cached. When all projections expire, stop projection message is sent to LAP ProSoft server |
| DEFAULT_DXF_VERSION  | AC1032                                      | Default DXF version |
| DXF_OUTPUT_PATH | shared-shapes/ | DXF writer output path |
| LASER_DXF_INPUT_PATH | \\VBOXSVR\gamesa\em-laser-hub | DXF input path for laser |
| LOG_LEVEL | DEBUG | Logging level |
| PROMETHEUS_PORT | 9060 | Port exposed for Prometheus |
| MOULD_ID | None | ID of mould being used |
| IOTEDGE_DEVICEID | None | ID of device being used |
| IOTEDGE_MODULEID | None | ID of device being used |

# Run
```
pip3 install -r requirements.txt
export PYTHONPATH='./'
python3 app/main.py
```

# Test
```
pip3 install -r requirements-tests.txt
export PYTHONPATH='./'
pytest tests/
```
