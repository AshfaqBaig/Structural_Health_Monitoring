'''Module defines all configuration options'''

import os
import logging

# env vars overridable by module twin
ACTIVE_LASER_HUB_HOST = 'edge3'
LOG_LEVEL = int(os.environ.get('LOG_LEVEL', logging.DEBUG))
PROSOFT_HOST = '192.168.209.100'
PROSOFT_PORT = 1024
PROJECTION_PERIOD_LENGTH_S = int(5)
PROJECTION_TTL = int(os.environ.get('PROJECTION_TTL', 300))
DXF_OUTPUT_PATH = '/mnt/prosoft/dxf/'
LASER_DXF_INPUT_PATH = "C:\\B97-01_OpticalBlade\\"
DXF_PATH = './sample-shapes/feedback-2020-12-10-152020-12-10-15.dxf'
CONNECT_TO_PROSOFT = True
PROJECT_TO_IMG = True
DEFAULT_TASK_ID = 3
