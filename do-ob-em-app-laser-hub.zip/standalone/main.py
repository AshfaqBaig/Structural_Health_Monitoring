'''
Application entrypoint module
'''

import logging
import threading
import socket
from queue import Queue
#import io

import app.config as cfg
from app.scheduler import Scheduler
from app.laser_client import LaserClient
from standalone.mock_payload import Payload

FORMAT = '%(asctime)s %(levelname)s %(name)s [%(filename)s:%(lineno)s] %(threadName)s: %(message)s'
logging.basicConfig(format=FORMAT, level=cfg.LOG_LEVEL)
log = logging.getLogger()

DXF_PATH = './sample-shapes/feedback'

projection_queue = Queue()

mock_payload = Payload(projection_queue,DXF_PATH)
laser_client = LaserClient()
scheduler = Scheduler(projection_queue, laser_client)

# laser_client should connect only if it maches configured hostname.
# This it to prevent multile laser hubs connecting to single Prosoft instance
if cfg.CONNECT_TO_PROSOFT:
    if cfg.ACTIVE_LASER_HUB_HOST == socket.gethostname():
        log.info('Activating payload')
        t = threading.Thread(target=mock_payload.run, name='MockPayload', daemon=True)
        t.start()
        log.info('Activating laser hub client')
        p = threading.Thread(target=laser_client.listen, name='SocketListener', daemon=True)
        p.start()
        #p.join()
        log.info('Activating scheduler')
        q = threading.Thread(target=scheduler.run, name='ProjectionScheduler', daemon=True)
        q.start()
        q.join()
    else:
        log.info('Laser hub client not started, because it is already running on %s', cfg.ACTIVE_LASER_HUB_HOST)
else:
    log.info('Running without active laser hub client')
    threading.Thread(target=scheduler.run, name='ProjectionScheduler', daemon=True).start()
