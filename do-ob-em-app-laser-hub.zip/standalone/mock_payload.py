
# pylint: disable=missing-module-docstring

import logging
import json
import base64
from queue import Queue
import io
from time import sleep
import os
import glob
import itertools
from queue import Queue

import app.config as cfg
from app.processors.projection import ProjectionProcessor

FORMAT = '%(asctime)s %(levelname)s %(filename)s:%(lineno)s %(threadName)s - %(message)s'
logging.basicConfig(format=FORMAT, level=cfg.LOG_LEVEL)
logging.getLogger('azure.iot.device').setLevel(logging.WARNING)
log = logging.getLogger('em-laser-hub')

class Payload:

    def __init__(self, queue,dxf_path):
        self.queue = queue
        self.dxf_path = dxf_path

    def run(self):
        '''Main entry point method which loops over and consumes projections from queue object'''

        log.info('Filling payload')

        processor = ProjectionProcessor(self.queue)
        if os.path.isdir(self.dxf_path):
            dxf_lst = glob.glob(os.path.join(self.dxf_path,'*.dxf'))
            log.info('Process dxf-list in the loop: {}'.format(dxf_lst))

            cycle_dxf = itertools.cycle(dxf_lst)
            for count,dxf in enumerate(cycle_dxf):
                dxf_file = open(dxf, 'r', encoding="utf8")
                dxf_encoded = base64.b64encode(dxf_file.read().encode()).decode()
                dxf_file.close()
                payload = json.dumps({
                    'content': dxf_encoded,
                    'session': {
                        'jobId': 'feedback',#_'+str(count),  # if we use here a different naming then the feedback gets added to the one before. Need to check this. Looks like a Bug.
                        'cameraId': 'camera-id_XXX',
                        'moduleId': 'em-edge-detection-feedback'
                    }
                })
                processor.run(io.BytesIO(payload.encode()))
                log.info('Payload dxf: {}'.format(dxf))
                if count >= 8:
                    print('\nEND!!!!!!!!!!!!!!!\n')
                    break
                #like the same as image grabber is pushing new input data for the system
                sleep(4) # nosemgrep: python.lang.best-practice.sleep.arbitrary-sleep 

        elif os.path.isfile(self.dxf_path):
            dxf_file = open(self.dxf_path, 'r', encoding="utf8")
            dxf_encoded = base64.b64encode(dxf_file.read().encode()).decode()
            dxf_file.close()
            payload = json.dumps({
                'content': dxf_encoded,
                'session': {
                    'jobId': 'feedback_one_payload',
                    'cameraId': 'camera-id',
                    'moduleId': 'em-edge-detection-feedback'
                }
            })
            processor.run(io.BytesIO(payload.encode()))
        else:
            print('No dxf file found!')

        #projection_queue.put(payload)

if __name__=='__main__':
    DXF_PATH = './sample-shapes/feedback'
    projection_queue = Queue()
    foo = Payload(projection_queue,DXF_PATH)
    foo.run()
