#!/bin/bash
# run it with source
# . ./standalone/run_config.sh
export LASER_DXF_INPUT_PATH='C:\\Users\\Dirk.Rannacher\\Documents\\Projects\\BladeCasting\\Repos\\do-ob-em-app-laser-hub\\standalone\\feedback\\'
export DXF_OUTPUT_PATH='/workspaces/do-ob-em-app-laser-hub/standalone/feedback/'
export ACTIVE_LASER_HUB_HOST='dff146fbc798'

