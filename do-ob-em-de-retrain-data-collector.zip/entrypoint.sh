#!/bin/sh

mkdir -p /image-input
mkdir -p /data-provisioning
chown -R nonroot:nonroot /data-provisioning
chown -R nonroot:nonroot /image-input
exec runuser -u nonroot "$@"