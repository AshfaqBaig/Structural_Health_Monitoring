# pylint: disable=protected-access, missing-module-docstring, missing-class-docstring, missing-function-docstring
import json
from azure.iot.device.iothub.models import Message

import pytest

from app import routes_constants

@pytest.fixture(scope="module")
def payload_dm_image_1():
    dm_payload = {
        "correlation_id": "image_1",
        "custom_properties": {
            "$.cdid": "EDQLTDVLGENOBAWE01-qlt-edge-2",
            "$.cmid": "decision-maker",
            "capture-timestamp": "2022-04-01 07:35:07.568302",
        },
        "data": {
            "metadata": {
                "teamInstructions": [
                    {
                        "version": "v0.1.8",
                        "mouldId": "b9702u2",
                        "bladeRevision": "b97-00",
                        "bladeSn": "sn-2022-01-01",
                        "layerId": "090_B97-00_LP_Outer_B1_1-288",
                        "palletId": "pallet_2",
                        "source_device": "edqltdvlgenobawe01-qlt-edge-2-decision-maker",
                    }
                ],
                "mouldId": "b9702u2",
                "hallId": "hall10",
                "locationId": "aal",
                "session": {
                    "cameraId": "aal-b9702u2-cam004",
                    "moduleId": "edge-verification",
                },
                "correlationId": "image_1",
                "customProperties": {
                    "$.cdid": "EDQLTDVLGENOBAWE01-qlt-edge-2",
                    "$.cmid": "edge-verification-aal-b9702u2-cam004",
                    "capture-timestamp": "2022-04-01 07:35:07.568302",
                },
            },
            "correctlyPlacedPlies": {
                    "090_B97-00_LP_Outer_B1_1-288_074000074": {
                    "pallet_id": "pallet_2",
                    "previous_plies": ["090_B97-00_LP_Outer_B1_1-288_077000077"],
                    "next_plies": ["090_B97-00_LP_Outer_B1_1-288_079000079"],
                    "edges_covered": ["090_B97-00_LP_Outer_B1_1-288_077000077_2"],
                    "layer_id": "090_B97-00_LP_Outer_B1_1-288",
                    "dxf_id": "090_B97-00_LP_Outer_B1_1-288",
                    "dxf_ply_id": "078000078",
                    "edges": [
                        "090_B97-00_LP_Outer_B1_1-288_074000074_1",
                        "090_B97-00_LP_Outer_B1_1-288_074000074_2",
                    ],
                }
            },
            "pliesToBePlaced": {
                    "090_B97-00_LP_Outer_B1_1-288_075000075": {
                    "pallet_id": "pallet_2",
                    "previous_plies": ["090_B97-00_LP_Outer_B1_1-288_077000077"],
                    "next_plies": ["090_B97-00_LP_Outer_B1_1-288_079000079"],
                    "edges_covered": ["090_B97-00_LP_Outer_B1_1-288_077000077_2"],
                    "layer_id": "090_B97-00_LP_Outer_B1_1-288",
                    "dxf_id": "090_B97-00_LP_Outer_B1_1-288",
                    "dxf_ply_id": "078000078",
                    "edges": [
                        "090_B97-00_LP_Outer_B1_1-288_075000075_1",
                        "090_B97-00_LP_Outer_B1_1-288_075000075_2",
                    ],
                }
            },
            "newMissingPlies": {
                "090_B97-00_LP_Outer_B1_1-288_078000078": {
                    "pallet_id": "pallet_2",
                    "previous_plies": ["090_B97-00_LP_Outer_B1_1-288_077000077"],
                    "next_plies": ["090_B97-00_LP_Outer_B1_1-288_079000079"],
                    "edges_covered": ["090_B97-00_LP_Outer_B1_1-288_077000077_2"],
                    "layer_id": "090_B97-00_LP_Outer_B1_1-288",
                    "dxf_id": "090_B97-00_LP_Outer_B1_1-288",
                    "dxf_ply_id": "078000078",
                    "edges": [
                        "090_B97-00_LP_Outer_B1_1-288_078000078_1",
                        "090_B97-00_LP_Outer_B1_1-288_078000078_2",
                    ],
                }
            },
            "noLongerMissingPlies": {
                "090_B97-00_LP_Outer_B1_1-288_072000072": {
                    "pallet_id": "pallet_2",
                    "previous_plies": ["090_B97-00_LP_Outer_B1_1-288_071000071"],
                    "next_plies": ["090_B97-00_LP_Outer_B1_1-288_073000073"],
                    "edges_covered": ["090_B97-00_LP_Outer_B1_1-288_071000071_2"],
                    "layer_id": "090_B97-00_LP_Outer_B1_1-288",
                    "dxf_id": "090_B97-00_LP_Outer_B1_1-288",
                    "dxf_ply_id": "072000072",
                    "edges": [
                        "090_B97-00_LP_Outer_B1_1-288_072000072_1",
                        "090_B97-00_LP_Outer_B1_1-288_072000072_2",
                    ],
                },
                "090_B97-00_LP_Outer_B1_1-288_071000071": {
                    "pallet_id": "pallet_2",
                    "previous_plies": ["090_B97-00_LP_Outer_B1_1-288_070000070"],
                    "next_plies": ["090_B97-00_LP_Outer_B1_1-288_072000072"],
                    "edges_covered": ["090_B97-00_LP_Outer_B1_1-288_070000070_2"],
                    "layer_id": "090_B97-00_LP_Outer_B1_1-288",
                    "dxf_id": "090_B97-00_LP_Outer_B1_1-288",
                    "dxf_ply_id": "071000071",
                    "edges": [
                        "090_B97-00_LP_Outer_B1_1-288_071000071_1",
                        "090_B97-00_LP_Outer_B1_1-288_071000071_2",
                    ],
                },
            },
            "forcedPlies": {
                "090_B97-00_LP_Outer_B1_1-288_001000001": {
                    "pallet_id": "pallet_2",
                    "previous_plies": ["090_B97-00_LP_Outer_B1_1-288_077000077"],
                    "next_plies": ["090_B97-00_LP_Outer_B1_1-288_079000079"],
                    "edges_covered": ["090_B97-00_LP_Outer_B1_1-288_077000077_2"],
                    "layer_id": "090_B97-00_LP_Outer_B1_1-288",
                    "dxf_id": "090_B97-00_LP_Outer_B1_1-288",
                    "dxf_ply_id": "078000078",
                    "edges": [
                        "090_B97-00_LP_Outer_B1_1-288_074000074_1",
                        "090_B97-00_LP_Outer_B1_1-288_074000074_2",
                    ],
                }
            },
        },
    }
    input_ = Message({})
    input_.input_name = routes_constants.DECISION_MAKER_INPUT
    input_.correlation_id = dm_payload["correlation_id"]
    input_.custom_properties = dm_payload["custom_properties"]
    input_.data = json.dumps(dm_payload["data"])
    return input_

@pytest.fixture(scope="module")
def payload_dm_image_2():
    dm_payload = {
        "correlation_id": "image_2",
        "custom_properties": {
            "$.cdid": "EDQLTDVLGENOBAWE01-qlt-edge-2",
            "$.cmid": "decision-maker",
            "capture-timestamp": "2022-04-01 07:35:07.568302",
        },
        "data": {
            "metadata": {
                "teamInstructions": [
                    {
                        "version": "v0.1.8",
                        "mouldId": "b9702u2",
                        "bladeRevision": "b97-00",
                        "bladeSn": "sn-2022-01-01",
                        "layerId": "090_B97-00_LP_Outer_B1_1-288",
                        "palletId": "pallet_2",
                        "source_device": "edqltdvlgenobawe01-qlt-edge-2-decision-maker",
                    }
                ],
                "mouldId": "b9702u2",
                "hallId": "hall10",
                "locationId": "aal",
                "session": {
                    "cameraId": "aal-b9702u2-cam004",
                    "moduleId": "edge-verification",
                },
                "correlationId": "image_2",
                "customProperties": {
                    "$.cdid": "EDQLTDVLGENOBAWE01-qlt-edge-2",
                    "$.cmid": "edge-verification-aal-b9702u2-cam004",
                    "capture-timestamp": "2022-04-01 07:35:07.568302",
                },
            },
            "correctlyPlacedPlies": {},
            "pliesToBePlaced": {},
            "newMissingPlies": {
                "090_B97-00_LP_Outer_B1_1-288_078000078": {
                    "pallet_id": "pallet_2",
                    "previous_plies": ["090_B97-00_LP_Outer_B1_1-288_077000077"],
                    "next_plies": ["090_B97-00_LP_Outer_B1_1-288_079000079"],
                    "edges_covered": ["090_B97-00_LP_Outer_B1_1-288_077000077_2"],
                    "layer_id": "090_B97-00_LP_Outer_B1_1-288",
                    "dxf_id": "090_B97-00_LP_Outer_B1_1-288",
                    "dxf_ply_id": "078000078",
                    "edges": [
                        "090_B97-00_LP_Outer_B1_1-288_078000078_1",
                        "090_B97-00_LP_Outer_B1_1-288_078000078_2",
                    ],
                }
            },
            "noLongerMissingPlies": {
                "090_B97-00_LP_Outer_B1_1-288_072000072": {
                    "pallet_id": "pallet_2",
                    "previous_plies": ["090_B97-00_LP_Outer_B1_1-288_071000071"],
                    "next_plies": ["090_B97-00_LP_Outer_B1_1-288_073000073"],
                    "edges_covered": ["090_B97-00_LP_Outer_B1_1-288_071000071_2"],
                    "layer_id": "090_B97-00_LP_Outer_B1_1-288",
                    "dxf_id": "090_B97-00_LP_Outer_B1_1-288",
                    "dxf_ply_id": "072000072",
                    "edges": [
                        "090_B97-00_LP_Outer_B1_1-288_072000072_1",
                        "090_B97-00_LP_Outer_B1_1-288_072000072_2",
                    ],
                },
                "090_B97-00_LP_Outer_B1_1-288_071000071": {
                    "pallet_id": "pallet_2",
                    "previous_plies": ["090_B97-00_LP_Outer_B1_1-288_070000070"],
                    "next_plies": ["090_B97-00_LP_Outer_B1_1-288_072000072"],
                    "edges_covered": ["090_B97-00_LP_Outer_B1_1-288_070000070_2"],
                    "layer_id": "090_B97-00_LP_Outer_B1_1-288",
                    "dxf_id": "090_B97-00_LP_Outer_B1_1-288",
                    "dxf_ply_id": "071000071",
                    "edges": [
                        "090_B97-00_LP_Outer_B1_1-288_071000071_1",
                        "090_B97-00_LP_Outer_B1_1-288_071000071_2",
                    ],
                },
            },
            "forcedPlies": {},
        },
    }
    input_ = Message({})
    input_.input_name = routes_constants.DECISION_MAKER_INPUT
    input_.correlation_id = dm_payload["correlation_id"]
    input_.custom_properties = dm_payload["custom_properties"]
    input_.data = json.dumps(dm_payload["data"])
    return input_

@pytest.fixture(scope="module")
def payload_dm_image_3():
    dm_payload = {
        "correlation_id": "image_3",
        "custom_properties": {
            "$.cdid": "EDQLTDVLGENOBAWE01-qlt-edge-2",
            "$.cmid": "decision-maker",
            "capture-timestamp": "2022-04-01 07:35:07.568302",
        },
        "data": {
            "metadata": {
                "teamInstructions": [
                    {
                        "version": "v0.1.8",
                        "mouldId": "b9702u2",
                        "bladeRevision": "b97-00",
                        "bladeSn": "sn-2022-01-01",
                        "layerId": "090_B97-00_LP_Outer_B1_1-288",
                        "palletId": "pallet_2",
                        "source_device": "edqltdvlgenobawe01-qlt-edge-2-decision-maker",
                    }
                ],
                "mouldId": "b9702u2",
                "hallId": "hall10",
                "locationId": "aal",
                "session": {
                    "cameraId": "aal-b9702u2-cam004",
                    "moduleId": "edge-verification",
                },
                "correlationId": "image_3",
                "customProperties": {
                    "$.cdid": "EDQLTDVLGENOBAWE01-qlt-edge-2",
                    "$.cmid": "edge-verification-aal-b9702u2-cam004",
                    "capture-timestamp": "2022-04-01 07:35:07.568302",
                },
            },
            "correctlyPlacedPlies": {},
            "pliesToBePlaced": {},
            "newMissingPlies": {
                "090_B97-00_LP_Outer_B1_1-288_078000078": {
                    "pallet_id": "pallet_2",
                    "previous_plies": ["090_B97-00_LP_Outer_B1_1-288_077000077"],
                    "next_plies": ["090_B97-00_LP_Outer_B1_1-288_079000079"],
                    "edges_covered": ["090_B97-00_LP_Outer_B1_1-288_077000077_2"],
                    "layer_id": "090_B97-00_LP_Outer_B1_1-288",
                    "dxf_id": "090_B97-00_LP_Outer_B1_1-288",
                    "dxf_ply_id": "078000078",
                    "edges": [
                        "090_B97-00_LP_Outer_B1_1-288_078000078_1",
                        "090_B97-00_LP_Outer_B1_1-288_078000078_2",
                    ],
                }
            },
            "noLongerMissingPlies": {
                "090_B97-00_LP_Outer_B1_1-288_072000072": {
                    "pallet_id": "pallet_2",
                    "previous_plies": ["090_B97-00_LP_Outer_B1_1-288_071000071"],
                    "next_plies": ["090_B97-00_LP_Outer_B1_1-288_073000073"],
                    "edges_covered": ["090_B97-00_LP_Outer_B1_1-288_071000071_2"],
                    "layer_id": "090_B97-00_LP_Outer_B1_1-288",
                    "dxf_id": "090_B97-00_LP_Outer_B1_1-288",
                    "dxf_ply_id": "072000072",
                    "edges": [
                        "090_B97-00_LP_Outer_B1_1-288_072000072_1",
                        "090_B97-00_LP_Outer_B1_1-288_072000072_2",
                    ],
                },
                "090_B97-00_LP_Outer_B1_1-288_071000071": {
                    "pallet_id": "pallet_2",
                    "previous_plies": ["090_B97-00_LP_Outer_B1_1-288_070000070"],
                    "next_plies": ["090_B97-00_LP_Outer_B1_1-288_072000072"],
                    "edges_covered": ["090_B97-00_LP_Outer_B1_1-288_070000070_2"],
                    "layer_id": "090_B97-00_LP_Outer_B1_1-288",
                    "dxf_id": "090_B97-00_LP_Outer_B1_1-288",
                    "dxf_ply_id": "071000071",
                    "edges": [
                        "090_B97-00_LP_Outer_B1_1-288_071000071_1",
                        "090_B97-00_LP_Outer_B1_1-288_071000071_2",
                    ],
                },
            },
            "forcedPlies": {},
        },
    }
    input_ = Message({})
    input_.input_name = routes_constants.DECISION_MAKER_INPUT
    input_.correlation_id = dm_payload["correlation_id"]
    input_.custom_properties = dm_payload["custom_properties"]
    input_.data = json.dumps(dm_payload["data"])
    return input_

@pytest.fixture(scope="module")
def payload_ig_image_1():
    ig_payload = {
        "correlation_id": "image_1",
        "custom_properties": {
            "capture-timestamp": "2022-04-01 07:31:39.214957",
            "$.cdid": "EDQLTDVLGENOBAWE01-qlt-edge-2",
            "$.cmid": "image-grabber-aal-b9702u2-cam004",
        },
        "data": {
            "images": [
                {
                    "location": "aal-b9702u2-cam004/image_1.jpg",
                    "metadata": {
                        "camera-id": "aal-b9702u2-cam004",
                        "image-id": "img-192.168.9.125-1648798299.2149343",
                        "image-content-type": "image/jpg",
                        "capture-timestamp": "2022-04-01 07:31:39.214957",
                        "height": 4860,
                        "width": 6480,
                    },
                }
            ],
            "session": {
                "cameraId": "aal-b9702u2-cam004",
                "moduleId": "image-grabber-aal-b9702u2-cam004",
            },
            "metadata": {"session": {"mouldId": "b9702u2"}},
        },
    }
    input_ = Message({})
    input_.input_name = routes_constants.IMAGE_GRABBER_INPUT
    input_.correlation_id = ig_payload["correlation_id"]
    input_.custom_properties = ig_payload["custom_properties"]
    input_.data = json.dumps(ig_payload["data"])
    return input_

@pytest.fixture(scope="module")
def payload_ig_image_2():
    ig_payload = {
        "correlation_id": "image_2",
        "custom_properties": {
            "capture-timestamp": "2022-04-01 07:31:39.214957",
            "$.cdid": "EDQLTDVLGENOBAWE01-qlt-edge-2",
            "$.cmid": "image-grabber-aal-b9702u2-cam004",
        },
        "data": {
            "images": [
                {
                    "location": "aal-b9702u2-cam004/image_2.jpg",
                    "metadata": {
                        "camera-id": "aal-b9702u2-cam004",
                        "image-id": "img-192.168.9.125-1648798299.2149343",
                        "image-content-type": "image/jpg",
                        "capture-timestamp": "2022-04-01 07:31:39.214957",
                        "height": 4860,
                        "width": 6480,
                    },
                }
            ],
            "session": {
                "cameraId": "aal-b9702u2-cam004",
                "moduleId": "image-grabber-aal-b9702u2-cam004",
            },
            "metadata": {"session": {"mouldId": "b9702u2"}},
        },
    }
    input_ = Message({})
    input_.input_name = routes_constants.IMAGE_GRABBER_INPUT
    input_.correlation_id = ig_payload["correlation_id"]
    input_.custom_properties = ig_payload["custom_properties"]
    input_.data = json.dumps(ig_payload["data"])
    return input_

@pytest.fixture(scope="module")
def payload_ig_image_3():
    ig_payload = {
        "correlation_id": "image_3",
        "custom_properties": {
            "capture-timestamp": "2022-04-01 07:31:39.214957",
            "$.cdid": "EDQLTDVLGENOBAWE01-qlt-edge-2",
            "$.cmid": "image-grabber-aal-b9702u2-cam004",
        },
        "data": {
            "images": [
                {
                    "location": "aal-b9702u2-cam004/image_3.jpg",
                    "metadata": {
                        "camera-id": "aal-b9702u2-cam004",
                        "image-id": "img-192.168.9.125-1648798299.2149343",
                        "image-content-type": "image/jpg",
                        "capture-timestamp": "2022-04-01 07:31:39.214957",
                        "height": 4860,
                        "width": 6480,
                    },
                }
            ],
            "session": {
                "cameraId": "aal-b9702u2-cam004",
                "moduleId": "image-grabber-aal-b9702u2-cam004",
            },
            "metadata": {"session": {"mouldId": "b9702u2"}},
        },
    }
    input_ = Message({})
    input_.input_name = routes_constants.IMAGE_GRABBER_INPUT
    input_.correlation_id = ig_payload["correlation_id"]
    input_.custom_properties = ig_payload["custom_properties"]
    input_.data = json.dumps(ig_payload["data"])
    return input_

@pytest.fixture(scope="module")
def payload_ev_image_1():
    ev_payload = {
        'correlation_id': 'image_1',
        'custom_properties': {
            '$.cdid': 'EDQLTDVLGENOBAWE01-qlt-edge-2',
            '$.cmid': 'edge-verification-aal-b9702u2-cam004',
            'capture-timestamp': '2022-06-15 10:05:07.566973'
        },
        'data': {
            'session': {
                'cameraId': 'aal-b9702u2-cam004', 'moduleId': 'edge-verification'
                },
            'feedback': {
                 '090_B97-00_LP_Outer_B1_1-288_065000065_1': 'ok',
                 '090_B97-00_LP_Outer_B1_1-288_065000065_2': 'too shortly ranged x-axis'
                }
        }
    }
    input_ = Message({})
    input_.input_name = routes_constants.EDGE_VERIFICATION_INPUT
    input_.correlation_id = ev_payload["correlation_id"]
    input_.custom_properties = ev_payload["custom_properties"]
    input_.data = json.dumps(ev_payload["data"])
    return input_