# pylint: disable=protected-access, missing-class-docstring, missing-function-docstring, no-self-use, too-many-arguments
"""
This test simulates the module locally
* It copies the data from test_resources/module_test into test_resources/module_test_tmp
* If this folder 'module_test_tmp' already exists you need to delete it before running the test
* It "receives" the messages defined in conftest.py and processes them
* The logs should tell what happens and in the end there should a success which is defined as no error
* test_resources/module_test_tmp should contain a folder final_destination which contains the output of DCM
"""
import logging
import shutil
import os

import pytest

from azure.iot.device.aio import IoTHubModuleClient
from app.handler.module_message_handler import ModuleMessageHandler
from app.handler.direct_message_handler import DirectMessageHandler
from app.utils.determine_repo_root import get_repo_root
import app.config as cfg

@pytest.fixture(name="module_message_handler")
def amqp_listener(mocker):
    mocker.patch.object(IoTHubModuleClient, "create_from_edge_environment")
    return ModuleMessageHandler(mocker)

@pytest.fixture(name="direct_message_handler")
def dm_listener(mocker):
    mocker.patch.object(IoTHubModuleClient, "create_from_edge_environment")
    return DirectMessageHandler(mocker)

def test_module(module_message_handler,
                direct_message_handler,
                caplog,
                payload_dm_image_1,
                payload_dm_image_2,
                payload_dm_image_3,
                payload_ig_image_1,
                payload_ig_image_2,
                payload_ig_image_3,
                payload_ev_image_1):
    # Setup and Prepare
    caplog.set_level(logging.DEBUG)

    from_ = os.path.join(get_repo_root(), "tests", "test_resources", "module_test")
    to_ = os.path.join(get_repo_root(), "tests", "test_resources", "module_test_tmp")
    try:
        shutil.copytree(from_, to_)
    except FileExistsError:
        print(f"\n\n\n>>>> Please delete \n{to_ }\nbefore running the test<<<<\n\n\n")
    
    module_message_handler.process_message(payload_ig_image_1)
    module_message_handler.process_message(payload_ev_image_1)
    module_message_handler.process_message(payload_dm_image_1)
    module_message_handler.process_message(payload_dm_image_2)
    module_message_handler.process_message(payload_ig_image_2)
    module_message_handler.process_message(payload_dm_image_3)
    module_message_handler.process_message(payload_ig_image_3)

    assert os.path.exists(cfg.DCM_INPUT_FOLDER)

    direct_message_handler._apply_finalize("select * from data where feedback like '%too shortly ranged x-axis%'")

    assert os.path.isfile(os.path.join(get_repo_root(), "tests", "test_resources", "module_test_tmp", cfg.DCM_OUTPUT_FOLDER, "aal-b9702u2-cam004.csv"))
    assert not os.path.isfile(os.path.join(get_repo_root(), "tests", "test_resources", "module_test_tmp", cfg.DCM_OUTPUT_FOLDER, "aal-b9702u2-cam005.csv"))



