# pylint: disable=protected-access, missing-class-docstring, missing-function-docstring, no-self-use
import json
import logging

from cachetools import TTLCache

import pytest

from azure.iot.device.aio import IoTHubModuleClient
from azure.iot.device.iothub.models import Message

from app.handler.module_message_handler import ModuleMessageHandler
from app import routes_constants as routes

@pytest.fixture(name="module_message_handler_mock")
def message_listener(mocker):
    mocker.patch("azure.iot.device.aio.IoTHubModuleClient.create_from_edge_environment",
        return_value=IoTHubModuleClient)
    return ModuleMessageHandler(mocker)

def test_process_message(mocker, module_message_handler_mock, caplog):
    # Setup
    caplog.set_level(logging.DEBUG, logger="data-collector")
    mocker.patch("app.handler.module_message_handler.update_cache_on_message",
        return_value=(TTLCache(maxsize=1, ttl=1), TTLCache(maxsize=1, ttl=1), TTLCache(maxsize=1, ttl=1)))
    mocker.patch("app.handler.module_message_handler.process_metadata_pairs",
        return_value=[["path", "data"]])
    mocker.patch("app.handler.module_message_handler.MetadataWriter.run",
        return_value=None)

    # Given Message from IG
    mocker.patch("app.handler.module_message_handler.get_matching_corr_ids",
        return_value=[])

    mocker.patch("app.utils.message_handling.extract_input",
        return_value={"msg_source": routes.IMAGE_GRABBER_INPUT,
                      "correlation_id": "corr-id",
                      "custom_properties": "IG",
                      "data": "data"})
    input_ = Message({})
    input_.data = json.dumps({})
    # When
    module_message_handler_mock.process_message(input_)
    # Then
    assert "Found no matching ids so far" in caplog.text

    # Given Message from DM
    mocker.patch("app.handler.module_message_handler.get_matching_corr_ids",
        return_value=["corr-id"])

    mocker.patch("app.utils.message_handling.extract_input",
        return_value={"msg_source": routes.DECISION_MAKER_INPUT,
                      "correlation_id": "corr-id",
                      "custom_properties": "DM",
                      "data": "data"})

    input_ = Message({})
    input_.data = json.dumps({})
    # When
    module_message_handler_mock.process_message(input_)
    # Then
    assert "Found matching ids" in caplog.text

@pytest.mark.asyncio
async def test_handle_amqp_message(mocker, module_message_handler_mock, caplog):
    # Test Case 1: Valid amqp message
    # Setup
    caplog.set_level(logging.DEBUG, logger="data-collector")
    mocker.patch("app.handler.module_message_handler.ModuleMessageHandler.process_message",
        return_value=None)

    # Given Message from User
    input_ = Message({})
    input_.input_name = "IG"
    input_.data = json.dumps({})
    # When
    await module_message_handler_mock.handle_amqp_message(input_)
    # Then
    assert module_message_handler_mock.process_message.call_count == 1
    assert isinstance(module_message_handler_mock.process_message.call_args.args[0], Message)
