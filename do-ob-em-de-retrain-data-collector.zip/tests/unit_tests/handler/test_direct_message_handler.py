# pylint: disable=protected-access, missing-class-docstring, missing-function-docstring, no-self-use
import logging

from unittest.mock import MagicMock, AsyncMock

import pytest

from azure.iot.device.aio import IoTHubModuleClient
from azure.iot.device import MethodRequest

from app.handler.direct_message_handler import DirectMessageHandler

import app.config as cfg

@pytest.fixture(name="direct_message_handler_mock")
def message_listener(mocker):
    mocker.patch("azure.iot.device.aio.IoTHubModuleClient.create_from_edge_environment",
        return_value=IoTHubModuleClient)
    mocker.patch("azure.iot.device.aio.IoTHubModuleClient.send_message_to_output",
        return_value=())
    mocker.patch("azure.iot.device.aio.IoTHubModuleClient.send_method_response",
        return_value=())
    mocker.patch("app.handler.direct_message_handler.DirectMessageHandler._send_response",
        new_callable=AsyncMock)
    return DirectMessageHandler(mocker)

def test_parse_finalize_request_not_a_dictionary(direct_message_handler_mock, mocker, caplog):
    # Setup
    caplog.set_level(logging.DEBUG, logger="data-collector")
    mocker.patch("app.handler.direct_message_handler.DirectMessageHandler._apply_finalize",
        return_value=None)

    # Given Payload from User
    request = ""

    # When
    status = direct_message_handler_mock._parse_finalize_request(request)

    # Then
    assert status == 400
    assert "Invalid method-payload format, needs to be {}." in caplog.text

def test_parse_finalize_request_missing_method_key(direct_message_handler_mock, mocker, caplog):
    # Setup
    caplog.set_level(logging.DEBUG, logger="data-collector")
    mocker.patch("app.handler.direct_message_handler.DirectMessageHandler._apply_finalize",
        return_value=None)

    # Given Payload from User
    request = {}

    # When
    status = direct_message_handler_mock._parse_finalize_request(request)

    # Then
    assert status == 400
    assert "Method-payload needs to be contain query or method key." in caplog.text

def test_parse_finalize_request_query_request(direct_message_handler_mock, mocker, caplog):
    # Setup
    caplog.set_level(logging.DEBUG, logger="data-collector")
    mocker.patch("app.handler.direct_message_handler.DirectMessageHandler._apply_finalize",
        return_value=None)

    # Given Payload from User
    request = {"query": "select"}

    # When
    status = direct_message_handler_mock._parse_finalize_request(request)

    # Then
    assert status == 200
    assert direct_message_handler_mock._apply_finalize.call_count == 1

def test_parse_finalize_request_invalid_method_request(direct_message_handler_mock, mocker, caplog):
    # Setup
    caplog.set_level(logging.DEBUG, logger="data-collector")
    mocker.patch("app.handler.direct_message_handler.DirectMessageHandler._apply_finalize",
        return_value=None)

    # Given Payload from User
    request = {"method": "select"}

    # When
    status = direct_message_handler_mock._parse_finalize_request(request)

    # Then
    assert status == 400
    assert direct_message_handler_mock._apply_finalize.call_count == 0
    assert "Method value not allowed. Allowed: " in caplog.text

def test_parse_finalize_request_valid_method_request(direct_message_handler_mock, mocker, caplog):
    # Setup
    caplog.set_level(logging.DEBUG, logger="data-collector")
    mocker.patch("app.handler.direct_message_handler.DirectMessageHandler._apply_finalize",
        return_value=None)

    # Given Payload from User
    request = {"method": cfg.ALLOWED_METHODS[0]}

    # When
    status = direct_message_handler_mock._parse_finalize_request(request)

    # Then
    assert status == 200
    assert direct_message_handler_mock._apply_finalize.call_count == 1

def test_parse_finalize_request_valid_method_request_edge_case(direct_message_handler_mock, mocker, caplog):
    # Setup
    caplog.set_level(logging.DEBUG, logger="data-collector")
    mocker.patch("app.handler.direct_message_handler.DirectMessageHandler._apply_finalize",
        return_value=None)

    # Given Payload from User
    request = {"method": None}

    # When
    status = direct_message_handler_mock._parse_finalize_request(request)

    # Then
    assert status == 400
    assert direct_message_handler_mock._apply_finalize.call_count == 0

@pytest.mark.asyncio
async def test_handle_direct_message_invalid_request_default_backup(mocker, direct_message_handler_mock, caplog):
    # Test Case 1: Invalid Request
    # Setup
    caplog.set_level(logging.DEBUG, logger="data-collector")
    mocker.patch("app.handler.direct_message_handler.DirectMessageHandler._apply_finalize",
        return_value=None)

    # Given Message from User
    input_ = MethodRequest(request_id=1, name="FINALIZE", payload="invalid")
    # When
    await direct_message_handler_mock.handle_direct_message(input_)
    # Then
    assert direct_message_handler_mock._apply_finalize.call_count == 0


@pytest.mark.asyncio
async def test_handle_direct_message_finalize_valid_without_query(mocker, direct_message_handler_mock, caplog):
    # Test Case 2: Valid finalize request without query
    # Setup
    caplog.set_level(logging.DEBUG, logger="data-collector")
    mocker.patch("app.handler.direct_message_handler.DirectMessageHandler._apply_finalize",
        return_value=None)

    # Given Message from User
    input_ = MethodRequest(request_id=1, name="FINALIZE", payload={})
    # When
    await direct_message_handler_mock.handle_direct_message(input_)
    # Then
    assert direct_message_handler_mock._apply_finalize.call_count == 0

@pytest.mark.asyncio
async def test_handle_direct_message_finalize_valid_with_query(mocker, direct_message_handler_mock, caplog):
    # Test Case 3: Valid finalize request with query
    # Setup
    caplog.set_level(logging.DEBUG, logger="data-collector")
    mocker.patch("app.handler.direct_message_handler.DirectMessageHandler._apply_finalize",
        return_value=None)

    # Given Message from User
    input_ = MethodRequest(request_id=1, name="FINALIZE", payload={"query": "select"})
    # When
    await direct_message_handler_mock.handle_direct_message(input_)
    # Then
    assert direct_message_handler_mock._apply_finalize.call_count == 1
    assert direct_message_handler_mock._apply_finalize.call_args.args[0] == "select"

@pytest.mark.asyncio
async def test_handle_direct_message_finalize_no_valid_command(mocker, direct_message_handler_mock, caplog):
    # Test Case 4: No valid command
    # Setup
    caplog.set_level(logging.DEBUG, logger="data-collector")
    mocker.patch("app.handler.direct_message_handler.DirectMessageHandler._apply_finalize",
        return_value=None)

    # Given Message from User
    input_ = MethodRequest(request_id=1, name="something_else", payload="")
    # When
    await direct_message_handler_mock.handle_direct_message(input_)
    # Then
    assert "No valid command!" in caplog.text

@pytest.mark.asyncio
async def test_handle_direct_message_finalize_valid_with_method(mocker, direct_message_handler_mock, caplog):
    # Test Case 5: Valid finalize request with query
    # Setup
    caplog.set_level(logging.DEBUG, logger="data-collector")
    mocker.patch("app.handler.direct_message_handler.DirectMessageHandler._apply_finalize",
        return_value=None)

    # Given Message from User
    input_ = MethodRequest(request_id=1, name="FINALIZE", payload={"method": "RandomSampling"})
    # When
    await direct_message_handler_mock.handle_direct_message(input_)
    # Then
    assert direct_message_handler_mock._apply_finalize.call_count == 1
    assert direct_message_handler_mock._apply_finalize.call_args.args[0] == "RandomSampling"

@pytest.mark.asyncio
async def test_handle_direct_message_log_level(mocker, direct_message_handler_mock, caplog):
    # Test Case 6: Valid log-level message
    # Setup
    caplog.set_level(logging.DEBUG, logger="data-collector")
    mocker.patch("app.handler.direct_message_handler.DirectMessageHandler._update_log_level",
        return_value=None)

    # Given Message from User
    input_ = MethodRequest(request_id=1, name="set_log_level", payload={"value": 10})
    # When
    await direct_message_handler_mock.handle_direct_message(input_)
    # Then
    assert direct_message_handler_mock._update_log_level.call_count == 1
    assert direct_message_handler_mock._update_log_level.call_args.args[0] == 10


@pytest.mark.asyncio
async def test_handle_direct_message_start_data_collection(direct_message_handler_mock, caplog):
    # Setup
    caplog.set_level(logging.DEBUG, logger="data-collector")

    # Given Message from User
    method_request_payload = MethodRequest(request_id=1, name="start", payload=None)
    # When
    await direct_message_handler_mock.handle_direct_message(method_request_payload)
    # Then
    assert direct_message_handler_mock.iot_client.on_message_received

@pytest.mark.asyncio
async def test_handle_direct_message_finalize(direct_message_handler_mock, caplog, mocker):
    # Setup
    caplog.set_level(logging.DEBUG, logger="data-collector")

    mock_finalize = mocker.patch("app.handler.direct_message_handler.finalize", callable=MagicMock)

    # When
    direct_message_handler_mock._apply_finalize("option")
    # Then
    assert mock_finalize.call_count == 1


@pytest.fixture(name="set_log_level_payload", scope="function")
def fixture_set_log_level_payload(mocker):
    mock_request = MagicMock(name="set_log_level_payload")
    mocker.patch.object(mock_request, "name", "set_log_level")
    mocker.patch.object(mock_request, "payload",  {"value": "DEBUG"})
    return mock_request

@pytest.mark.asyncio
async def test_set_log_level_when_different_log_level(mocker, direct_message_handler_mock, set_log_level_payload, caplog):
    mock__send_response = mocker.patch.object(direct_message_handler_mock, "_send_response", new_callable=AsyncMock)
    cfg.LOG_LEVEL = "ERROR"

    # RUN
    with caplog.at_level(logging.DEBUG):
        await direct_message_handler_mock.handle_direct_message(set_log_level_payload)

    # VERIFY
    assert mock__send_response.call_count == 1
    assert mock__send_response.call_args[0][1] == 200
    assert "Method set_log_level invocation with:" in caplog.text
    assert "Updated log level to" in caplog.text
    assert cfg.LOG_LEVEL == set_log_level_payload.payload.get("value")

@pytest.mark.asyncio
async def test_set_log_level_when_same_log_level(mocker, direct_message_handler_mock, set_log_level_payload, caplog):
    mock__send_response = mocker.patch.object(direct_message_handler_mock, "_send_response", new_callable=AsyncMock)
    cfg.LOG_LEVEL = "DEBUG"

    # RUN
    with caplog.at_level(logging.DEBUG):
        await direct_message_handler_mock.handle_direct_message(set_log_level_payload)

    # VERIFY
    assert mock__send_response.call_count == 1
    assert mock__send_response.call_args[0][1] == 304
    assert "Method set_log_level invocation with:" in caplog.text
    assert "Updated log level to" not in caplog.text
    assert cfg.LOG_LEVEL == set_log_level_payload.payload.get("value")
