# pylint: disable=protected-access, missing-module-docstring, missing-class-docstring, missing-function-docstring

import json

from cachetools import TTLCache
from pytest import MonkeyPatch
from azure.iot.device.iothub.models import Message

from app.utils.message_handling import combine_metadata
from app.utils.message_handling import extract_input
from app.utils.message_handling import extract_image_information
from app.utils.message_handling import get_matching_corr_ids
from app.utils.message_handling import process_metadata_pairs
from app.utils.message_handling import update_cache_on_message

from app import routes_constants as routes
import app.config as cfg


def test_extract_input():
    # GIVEN
    input_ = Message({})
    input_.input_name = "IG"
    input_.correlation_id = "cid"
    input_.custom_properties = {}
    input_.data = json.dumps({})
    # WHEN
    result = extract_input(input_)
    # THEN
    expected = {
        'msg_source': 'IG',
        'correlation_id': 'cid',
        'custom_properties': {},
        'data': {}
        }
    assert expected == result

def test_update_cache_on_message():
    # GIVEN (Message from IG-Output - empty message)
    cache_ig = TTLCache(maxsize=1024, ttl=30)
    cache_ev = TTLCache(maxsize=1024, ttl=30)
    cache_dm = TTLCache(maxsize=1024, ttl=30)
    message = {
        "correlation_id": "sample_id",
        'msg_source': routes.IMAGE_GRABBER_INPUT
        }
    # WHEN
    ig_cache_res, _, dm_cache_res = update_cache_on_message(message, cache_ig, cache_ev, cache_dm)
    # THEN
    assert ig_cache_res == cache_ig
    assert dm_cache_res == cache_dm

    # GIVEN (Message from DM-Output - empty message)
    cache_ig = TTLCache(maxsize=1024, ttl=30)
    cache_ev = TTLCache(maxsize=1024, ttl=30)
    cache_dm = TTLCache(maxsize=1024, ttl=30)
    message = {
        "correlation_id": "sample_id",
        'msg_source': routes.DECISION_MAKER_INPUT
        }
    # WHEN
    ig_cache_res, _, dm_cache_res = update_cache_on_message(message, cache_ig, cache_ev, cache_dm)
    # THEN
    assert ig_cache_res == cache_ig
    assert dm_cache_res == cache_dm

    # GIVEN (Update DM Cache)
    cache_ig = TTLCache(maxsize=1024, ttl=30)
    cache_ev = TTLCache(maxsize=1024, ttl=30)
    cache_dm = TTLCache(maxsize=1024, ttl=30)
    message = {
        "correlation_id": "sample_id",
        "data": "dm-data",
        "custom_properties": "dm-cp",
        'msg_source': routes.DECISION_MAKER_INPUT
        }
    # WHEN
    ig_cache_res, _, dm_cache_res = update_cache_on_message(message, cache_ig, cache_ev, cache_dm)
    # THEN (Only DM Cache is updated)
    assert ig_cache_res == cache_ig
    assert "dm_payload" in dm_cache_res["sample_id"]
    assert "dm_custom_property" in dm_cache_res["sample_id"]

    # GIVEN (Update IG Cache)
    cache_ig = TTLCache(maxsize=1024, ttl=30)
    cache_ev = TTLCache(maxsize=1024, ttl=30)
    cache_dm = TTLCache(maxsize=1024, ttl=30)
    message = {
        "correlation_id": "sample_id",
        "data": "dm-data",
        "custom_properties": "dm-cp",
        'msg_source': routes.IMAGE_GRABBER_INPUT
        }
    # WHEN
    ig_cache_res, _, dm_cache_res = update_cache_on_message(message, cache_ig, cache_ev, cache_dm)
    # THEN (Only IG Cache is updated)
    assert ig_cache_res == cache_ig
    assert "ig_payload" in ig_cache_res["sample_id"]
    assert "ig_custom_property" in ig_cache_res["sample_id"]

    # GIVEN (When correlation id is not provided)
    cache_ig = TTLCache(maxsize=1024, ttl=30)
    cache_ev = TTLCache(maxsize=1024, ttl=30)
    cache_dm = TTLCache(maxsize=1024, ttl=30)
    message = {"data": "dm-data", "custom_properties": "dm-cp", 'msg_source': routes.IMAGE_GRABBER_INPUT}
    # WHEN
    ig_cache_res, _, dm_cache_res = update_cache_on_message(message, cache_ig, cache_ev, cache_dm)
    # THEN (Cache does not get updated)
    assert ig_cache_res == cache_ig
    assert dm_cache_res == cache_dm

def test_get_matching_corr_ids():
    # GIVEN
    cache_ig = TTLCache(maxsize=1024, ttl=30)
    cache_dm = TTLCache(maxsize=1024, ttl=30)
    cache_ig["sample_id"] = "test"
    cache_dm["sample_id"] = "test"
    cache_dm["dumple_id"] = "test"

    # WHEN
    result = get_matching_corr_ids(cache_ig, cache_dm)
    # THEN
    expected = ["sample_id"]
    assert result == expected

def test_combine_metadata():
    # GIVEN
    cache_ig = TTLCache(maxsize=1024, ttl=30)
    cache_ev = TTLCache(maxsize=1024, ttl=30)
    cache_dm = TTLCache(maxsize=1024, ttl=30)
    cache_ig["sample_id"] = {"test_ig": "123"}
    cache_ev["sample_id"] = {"test_ev": "456"}
    cache_dm["sample_id"] = {"test_dm": "789"}
    data_ig = cache_ig["sample_id"]
    data_ev = cache_ev["sample_id"]
    data_dm = cache_dm["sample_id"]

    # WHEN
    result = combine_metadata(data_ig, data_ev, data_dm)
    # THEN
    expected = {'test_ig': ['123'],'test_ev': ['456'], 'test_dm': ['789']}
    assert result == expected

def test_extract_image_information():
    # GIVEN
    input_ = {
        "ig_custom_property": [],
        "ig_payload": [
                {
                "images": [
                    {
                    "location": "aal-b9702u2-cam004/mock-DEV_000F310382AF-20220307092026853387-90.jpg",
                    "metadata": {},
                    }
                ],
                }
        ],
        "dm_custom_property": [],
        "dm_payload": [],
    }

    # WHEN
    result = extract_image_information(input_)
    # THEN
    assert "location" in result
    assert "metadata" in result

def test_process_metadata_pairs(mocker):
    # GIVEN
    dm_cache = TTLCache(maxsize=1024, ttl=30)
    ev_cache = TTLCache(maxsize=1024, ttl=30)
    ig_cache = TTLCache(maxsize=1024, ttl=30)
    matching_ids = ["1", "2"]
    dm_cache["1"] = "text"
    dm_cache["2"] = "text"
    ev_cache["1"] = "text"
    ev_cache["2"] = "text"
    ig_cache["1"] = "text"
    ig_cache["2"] = "text"

    # Patching function dependencies
    mocker.patch("app.utils.message_handling.combine_metadata",
        return_value={'test_ig': ['123'], 'test_ev': ['456'], 'test_dm': ['789']})

    mocker.patch("app.utils.message_handling.extract_image_information",
        return_value={"location": "aal-b9702u2-cam004/mock-DEV_000F310382AF--90.jpg"})

    # WHEN
    with MonkeyPatch.context() as mp:
        mp.setattr(cfg, 'DCM_INPUT_FOLDER', "output")
        result = process_metadata_pairs(matching_ids, ig_cache, ev_cache, dm_cache)
    # THEN
    for item in matching_ids:
        assert item not in dm_cache
        assert item not in ig_cache
    for output_path, metadata in result:
        assert output_path == 'output/aal-b9702u2-cam004/mock-DEV_000F310382AF--90.json'
        assert metadata == {'test_ig': ['123'], 'test_ev': ['456'], 'test_dm': ['789']}
