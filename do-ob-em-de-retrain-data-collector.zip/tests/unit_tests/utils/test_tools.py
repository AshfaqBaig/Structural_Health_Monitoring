# pylint: disable=protected-access, missing-module-docstring, missing-class-docstring, missing-function-docstring
import os

from app.utils.tools import check_for_existence

def test_check_file(tmp_path, caplog):
    # Regular file
    # GIVEN
    some_file = tmp_path / "tmpfile"
    some_file.write_text("content")
    # WHEN
    result = check_for_existence(path=some_file)
    # THEN
    assert result is True

    # Non existent file
    # GIVEN
    path = os.path.join("non_existent")
    # WHEN
    result = check_for_existence(path=path)
    # THEN
    assert result is False
    assert f"Data file at '{path}' not found" in caplog.text
