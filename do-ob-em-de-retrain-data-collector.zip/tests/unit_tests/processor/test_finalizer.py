# pylint: disable=protected-access, missing-module-docstring, missing-class-docstring, missing-function-docstring

import logging
from unittest.mock import MagicMock

import pytest

from app.processor.finalizer import extract_camera_name
from app.processor.finalizer import check_no_files
from app.processor.finalizer import sample_or_select_data


@pytest.fixture(name="mocked_instances")
def test_create_finalize_mock(mocker):
    rsamp_mock_new = mocker.patch("app.src.sampling.random_sampling.RandomSampling.__init__", return_value=None)
    rsamp_mock_run = mocker.patch("app.src.sampling.random_sampling.RandomSampling.run", return_value=MagicMock())
    ssamp_mock_new = mocker.patch("app.src.sampling.selected_sampling.SelectedSampling.__init__", return_value=None)
    ssamp_mock_run = mocker.patch("app.src.sampling.selected_sampling.SelectedSampling.run", return_value=MagicMock())
    yield rsamp_mock_new, rsamp_mock_run, ssamp_mock_new, ssamp_mock_run

def test_sample_or_select_data_use_randomsampling(mocked_instances, caplog):
    # Setup
    caplog.set_level(logging.DEBUG, logger="data-collector")
    rsamp_mock_new, rsamp_mock_run, ssamp_mock_new, ssamp_mock_run = mocked_instances
    # Given Message from User
    option_or_query = "RandomSampling"
    camera_path = "ig-output"
    camera_name = "aal-cam-001"
    # When
    sample_or_select_data(option_or_query, camera_path, camera_name)
    # Then
    assert rsamp_mock_new.assert_called_once
    assert rsamp_mock_run.assert_called_once
    assert ssamp_mock_new.assert_not_called
    assert ssamp_mock_run.assert_not_called
    assert rsamp_mock_new.call_args_list[0][1] == ({'csv_input_file': 'ig-output/aal-cam-001.csv', 'probability': 0.5})
    assert rsamp_mock_run.call_args_list[0] == []


def test_sample_or_select_data_use_selectedsampling(mocked_instances, caplog):
    # Setup
    caplog.set_level(logging.DEBUG, logger="data-collector")
    rsamp_mock_new, rsamp_mock_run, ssamp_mock_new, ssamp_mock_run = mocked_instances

    # Given Message from User
    option_or_query = "select *"
    camera_path = "ig-output"
    camera_name = "aal-cam-001"
    # When
    sample_or_select_data(option_or_query, camera_path, camera_name)
    # Then
    assert rsamp_mock_new.assert_not_called
    assert rsamp_mock_run.assert_not_called
    assert ssamp_mock_new.assert_called_once
    assert ssamp_mock_run.assert_called_once
    assert ssamp_mock_new.call_args_list[0][1] == ({'csv_input_file': 'ig-output/aal-cam-001.csv', 'query': 'select *'})
    assert ssamp_mock_run.call_args_list[0] == []

def test_sample_or_select_data_use_invalid(mocked_instances, caplog):
    # Setup
    caplog.set_level(logging.DEBUG, logger="data-collector")
    rsamp_mock_new, rsamp_mock_run, ssamp_mock_new, ssamp_mock_run = mocked_instances

    # Given Message from User
    option_or_query = "INVALID"
    camera_path = "ig-output"
    camera_name = "aal-cam-001"
    # When
    sample_or_select_data(option_or_query, camera_path, camera_name)
    # Then
    assert rsamp_mock_new.assert_not_called
    assert ssamp_mock_new.assert_not_called
    assert rsamp_mock_run.assert_not_called
    assert ssamp_mock_run.assert_not_called
    assert "No valid sampling method/query. Ignoring and continuing.." in caplog.text

def test_extract_camera_name():
    # GIVEN
    path_input = "workspaces/path/sample-cam"
    # WHEN
    result = extract_camera_name(path_input)
    # THEN
    expected = "sample-cam"
    assert result == expected

def test_check_no_files_equal(caplog):
    # GIVEN
    no_json_files = 10
    no_img_files = 10
    # WHEN
    check_no_files(no_json_files, no_img_files)
    # THEN
    expected = "Difference in number of json-files/"
    assert expected not in caplog.text

def test_check_no_files_unequal(caplog):
    # GIVEN
    no_json_files = 11
    no_img_files = 10
    # WHEN
    check_no_files(no_json_files, no_img_files)
    # THEN
    expected = "Difference in number of json-files/"
    assert expected in caplog.text
