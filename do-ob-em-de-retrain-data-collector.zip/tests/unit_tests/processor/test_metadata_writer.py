# pylint: disable=protected-access, missing-module-docstring, missing-class-docstring, missing-function-docstring

from unittest.mock import MagicMock

import pytest

from app.processor.metadata_writer import MetadataWriter
import app.config as cfg

def test_find_item():
    # GIVEN
    instance = MetadataWriter()
    dict_to_search = {"key": {"else": {"c": {"key": ["key", "value"]}}}}
    field = "key"
    # WHEN
    data = instance.find_item(dict_to_search, field)
    # THEN
    for value in data:
        assert value == {'else': {'c': {'key': ["key", "value"]}}}

def test_extract_layer_edges(mocker):
    # GIVEN
    instance = MetadataWriter()
    metadata = {"key": {"metadata": {"edges": [1,2], "layer_id": "a"}}}
    find_item_mocked = mocker.patch.object(instance, "find_item", MagicMock())
    find_item_mocked.return_value = (i for i in [[1, 2], "a"])
    # WHEN
    layer_edges_list = instance.extract_layer_edges(metadata)
    # THEN
    expected = [{'a': [1, 2]}]
    assert expected == layer_edges_list

def test_postprocess_row_happy_case():
    # GIVEN
    row = {"location": "camera_id/filename", "other_key": "no info"}
    # WHEN
    result = MetadataWriter.postprocess_row(row)
    # THEN
    assert "camera_id" in result
    assert "filename" in result
    assert "other_key" in result

def test_postprocess_row_sad_case():
    # GIVEN
    row = {"missing_key": "camera_id/filename"}
    # WHEN
    with pytest.raises(KeyError):
        MetadataWriter.postprocess_row(row)

def test_generate_data_row(mocker):
    # GIVEN
    instance = MetadataWriter()
    dict_to_search = {
        "layer_id": "090_B97-00_LP_Outer_B1_1-288",
        "edges": [
                "090_B97-00_LP_Outer_B1_1-288_074000074_1",
                "090_B97-00_LP_Outer_B1_1-288_074000074_2"
        ]
    }
    mocker.patch.object(instance, "extract_layer_edges", MagicMock(return_value=[{'074000074': [1, 2]}]))
    mocker.patch.object(instance, "find_item", MagicMock())
    # WHEN
    data = instance.generate_data_row(dict_to_search)
    # THEN
    for key in cfg.HEADER_LIST:
        assert key in data
    for key in cfg.PLY_INFO:
        assert key in data
