# pylint: disable=protected-access, missing-module-docstring, missing-class-docstring, missing-function-docstring
import numpy as np

from app.src.anonymizing.inference import HumanDetectionRunner

def test_anonymize_simple(mocker):
    # GIVEN
    image = np.ones((468, 648, 3))
    w = 6
    h = 12
    mocker.patch("app.src.anonymizing.inference.cv2.blur", return_value=np.ones((468, 648, 3)), autospec=True)
    # WHEN
    result = HumanDetectionRunner.anonymize_simple(image, w, h)
    # THEN
    assert result.all() == 1

def test_write_resultse(mocker):
    # GIVEN
    output_img = np.ones((468, 648, 3))
    class_label = 0
    xyxy = [0, 648, 648, 648+468]
    mocker.patch("app.src.anonymizing.inference.HumanDetectionRunner.anonymize_simple", return_value=np.ones((0, 648, 3)))
    # WHEN
    result = HumanDetectionRunner(input_path="").write_results(xyxy, class_label, output_img)
    # THEN
    assert result.all() == 1
