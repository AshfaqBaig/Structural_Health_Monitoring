# pylint: disable=protected-access, missing-class-docstring, missing-function-docstring, no-self-use
import os
from defusedxml import ElementTree as ET
from xml.dom import minidom # nosemgrep

import pytest

from app.src.labeling.uv2label import UV2Label

import app.config as cfg

@pytest.fixture(name="uv2_label_instance")
def uv2_label():
    work_path = "C:"
    work_instr_path = "D:"
    return UV2Label(work_path, work_instr_path)

def test_init():
    # GIVEN
    work_path = "C:"
    work_instr_path = "D:"

    # WHEN
    instance = UV2Label(work_path, work_instr_path)

    # THEN
    assert instance.work_path == work_path
    assert instance.work_instr_path == work_instr_path
    assert isinstance(instance.template_tree, ET.Element)

def test_create_img_json_map():
    # GIVEN
    input_ = ["a.jpg", "b.png", "c.json"]
    # WHEN
    result = UV2Label.create_img_json_map(input_)
    # THEN
    assert result.get("a.jpg") is None
    assert result.get("b.png") is None
    assert result.get("c.json") == "c.jpg"

def test_create_xml_string(uv2_label_instance):
    # GIVEN
    # WHEN
    xml_string = uv2_label_instance.create_xml_string()
    # THEN
    assert isinstance(xml_string, minidom.Document) # nosemgrep

def test_create_polyline_sub(uv2_label_instance):
    # GIVEN
    template_xml = "\n".join(
        (
            '<?xml version="1.0" encoding="utf-8"?>',
            "<annotations>",
            "    <version>1.1</version>",
            "</annotations>",
        )
    )
    template_tree = ET.fromstring(template_xml)
    # WHEN
    polyline_sub = uv2_label_instance.create_polyline_sub(template_tree, "3")
    # THEN
    assert isinstance(polyline_sub, ET.Element)

def test_create_image_sub(uv2_label_instance):
    # GIVEN
    # WHEN
    image_sub = uv2_label_instance.create_image_sub(1, "a.jpeg", 10, 20)
    # THEN
    assert isinstance(image_sub, ET.Element)

def test_get_meta_files(mocker):
    # GIVEN
    mocker.patch("glob.glob", return_value=["b", "a", "c"])
    # WHEN
    result = UV2Label.get_meta_files("test")
    # THEN
    assert result == ['a', 'b', 'c']

def test_extract_meta_data(mocker, uv2_label_instance, tmp_path):
    # GIVEN
    mocker.patch("app.src.labeling.uv2label.json.load",
        return_value={"dm_payload": [
            {
                "correctlyPlacedPlies":
                    {"002000002": {"edges": ["002000002_1", "002000002_2"]}}
                }
            ]
        })

    mocker.patch("app.src.labeling.uv2label.joblib.load",
        return_value={"uv_data": "result"})

    mocker.patch("app.src.labeling.uv2label.UV2Label.extract_cam_and_uvfp_from_payload",
     return_value=("cam-008", "work_instr.txt"))

    uv2_label_instance.work_instr_path = tmp_path
    f1 = tmp_path / "file.txt"
    f1.touch()
    f2 = tmp_path / "work_instr.txt"
    f2.touch()

    # WHEN
    result = uv2_label_instance.extract_meta_data(meta_fp=os.path.join(tmp_path, "file.txt"))

    # THEN
    expected = ({"uv_data": "result"}, 'cam-008', ['002000002_1', '002000002_2'])
    assert result == expected
    assert isinstance(result, tuple)

def test_extract_cam_and_uvfp_from_valid_payload():
    # GIVEN
    data =  \
    {
        "dm_payload": [
                {
                    "metadata": {
                        "mouldId": "Mould",
                        "teamInstructions": [
                            {"mouldId": "Mould", "bladeRevision": "BladeRev", "layerId": "LayerID", "version": "1"}
                            ]
                    },
                },
            ],
        "ig_payload": [{"images": [{"metadata": {"camera-id": "CameraID", "mouldId": "Mould"}}]}]
    }
    # THEN
    cam_id, uv_fp = UV2Label.extract_cam_and_uvfp_from_payload(data)

    # WHEN
    assert cam_id == "CameraID"
    assert uv_fp == "mould/1/Mould-BladeRev-LayerID-ev-input.joblib"

def test_extract_cam_and_uvfp_from_valid_inpayload(caplog):
    # GIVEN
    data =  \
    {
        "dm_payload": [{'metadata': 'Test'}],
        "ig_payload": []
    }
    # THEN & WHEN
    with pytest.raises(TypeError):
        _, _= UV2Label.extract_cam_and_uvfp_from_payload(data)

    expected = "Nested structure unexpected, raised at: 'string indices must be integers'"
    assert expected in caplog.text

    # GIVEN
    data =  \
    {
        "dm_payload": [],
        "ig_payload": []
    }
    # THEN & WHEN
    with pytest.raises(IndexError):
        _, _= UV2Label.extract_cam_and_uvfp_from_payload(data)

    expected = "Nested structure unexpected, raised at: 'list index out of range'"
    assert expected in caplog.text

    # GIVEN
    data =  \
    {
        "dm_payload": {'motordata': {}},
        "ig_payload": []
    }
    # THEN & WHEN
    with pytest.raises(KeyError):
        _, _= UV2Label.extract_cam_and_uvfp_from_payload(data)

    expected = "Nested structure unexpected, raised at: '0'"
    assert expected in caplog.text

def test_extract_groundtruth_valid_keys():
    # GIVEN
    input_ = {
        "cam-001": {
            "edgedata": {"edge-1": {"x_groundtruth": [2, 4], "y_groundtruth": [1, 3]}}
        }
    }
    # WHEN
    result = UV2Label.extract_groundtruth(input_, "cam-001", "edge-1")
    # THEN
    assert result == ([2, 4], [1, 3])


def test_extract_groundtruth_invalid_keys():
    # GIVEN
    input_ = {
        "cam-001": {
            "edgedata": {"edge-1": {"x_groundtruth": [2, 4], "y_groundtruth": [1, 3]}}
        }
    }
    # WHEN
    result = UV2Label.extract_groundtruth(input_, "cam-001", "edge-2")
    # THEN 
    assert result == ([],[])

def test_groundtruth_to_dotstring():
    # GIVEN
    dots_x, dots_y = ([2, 4, 7], [1, 3, 5])
    # WHEN
    result = UV2Label.groundtruth_to_dotstring(dots_x, dots_y)
    # THEN
    assert result == "2,1;4,3;7,5"

def test_get_uv_coordinates_from_groundtruth(mocker, uv2_label_instance):
    # GIVEN
    mocker.patch("app.src.labeling.uv2label.UV2Label.extract_groundtruth", return_value=([1,2,3],[2,3,4]))
    mocker.patch("app.src.labeling.uv2label.UV2Label.groundtruth_to_dotstring", return_value=["1,2,3"])
    uv_data = {}
    cam_id = 1
    visible_edges = ["1"]
    # WHEN
    result = uv2_label_instance.get_uv_coordinates_from_groundtruth(uv_data, cam_id, visible_edges)
    # THEN
    expected = [["1,2,3"]]
    assert result == expected
    assert isinstance(result, list)

def test_save_xml_file(uv2_label_instance, tmp_path):
    # GIVEN
    uv2_label_instance.work_path = tmp_path
    xml_string = uv2_label_instance.create_xml_string()
    # WHEN
    uv2_label_instance.save_xml_file("image_name", xml_string)
    # THEN
    assert os.path.isfile(os.path.join(tmp_path, "image_name.xml"))

def test_run(mocker, uv2_label_instance):
    # GIVEN
    mocker.patch("app.src.labeling.uv2label.UV2Label.get_meta_files",
     return_value=["file1", "file2"])

    mocker.patch("app.src.labeling.uv2label.UV2Label.create_img_json_map",
     return_value=
         {"file1": f'file.{cfg.EXPECTED_IMG_FORMAT}',
          "file2": f'file2.{cfg.EXPECTED_IMG_FORMAT}',
          "file3": f'file3.{cfg.EXPECTED_IMG_FORMAT}',
         })

    mocker.patch("app.src.labeling.uv2label.UV2Label.extract_meta_data",
     return_value=({"uv_data": "result"}, 'cam-008', ['002000002_1', '002000002_2']))

    mocker.patch("app.src.labeling.uv2label.imagesize.get",
     return_value=(400, 600))

    mocker.patch("app.src.labeling.uv2label.UV2Label.create_image_sub",
     return_value=())

    mocker.patch("app.src.labeling.uv2label.UV2Label.get_uv_coordinates_from_groundtruth",
     return_value=(['002000002_1', '002000002_2']))

    mocker.patch("app.src.labeling.uv2label.UV2Label.create_polyline_sub",
     return_value=None)

    mocker.patch("app.src.labeling.uv2label.UV2Label.create_xml_string",
     return_value=uv2_label_instance.template_tree)

    mocker.patch("app.src.labeling.uv2label.UV2Label.save_xml_file", return_value=None)
    # WHEN
    uv2_label_instance.run()
    # THEN
    assert True
