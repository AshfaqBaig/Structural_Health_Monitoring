# pylint: disable=protected-access, missing-module-docstring, missing-class-docstring, missing-function-docstring
import logging

from unittest.mock import MagicMock
import pandas as pd

import pytest

from app.src.sampling.random_sampling import RandomSampling

@pytest.fixture(name="random_sampling_instance")
def rs_instance():
    data = "camera/csv_file.csv"
    return RandomSampling(data)

def test_init():
    # Given
    data = "fail"
    # When & Then
    with pytest.raises(ValueError):
        RandomSampling(data)

def test_take_sample(random_sampling_instance):
    # Given
    df1 = pd.DataFrame({'filename': [1, 2, 3, 4]})
    random_sampling_instance.probability = 0
    # When
    result = random_sampling_instance.take_sample(df1)
    # Then
    expected = 0
    assert len(result) == expected

    # Given
    df1 = pd.DataFrame({'filename': [1, 2, 3, 4]})
    random_sampling_instance.probability = 1
    # When
    result = random_sampling_instance.take_sample(df1)
    # Then
    expected = 4
    assert len(result) == expected

def test_run_no_metadata(random_sampling_instance, mocker, caplog):
    # Setup
    caplog.set_level(logging.DEBUG, logger="data-collector")
    mocker.patch.object(random_sampling_instance, "load_metadata_csv", return_value=None)
    mocker.patch.object(random_sampling_instance, "parse_metadata_csv",  new_callable=MagicMock)
    mocker.patch.object(random_sampling_instance, "take_sample",  new_callable=MagicMock)
    mocker.patch.object(random_sampling_instance, "delete_given_whitelist_of_images",  new_callable=MagicMock)

    # When
    result = random_sampling_instance.run()
    # Then
    assert result is False
    assert random_sampling_instance.take_sample.call_count == 0

def test_run_yes_metadata(random_sampling_instance, mocker, caplog):
    # Setup
    caplog.set_level(logging.DEBUG, logger="data-collector")
    mocker.patch.object(random_sampling_instance, "load_metadata_csv", return_value="test")
    mocker.patch.object(random_sampling_instance, "parse_metadata_csv",  new_callable=MagicMock)
    mocker.patch.object(random_sampling_instance, "take_sample",  new_callable=MagicMock)
    mocker.patch.object(random_sampling_instance, "delete_given_whitelist_of_images",  new_callable=MagicMock)

    # When
    result = random_sampling_instance.run()
    # Then
    assert result is True
    assert random_sampling_instance.take_sample.call_count == 1
