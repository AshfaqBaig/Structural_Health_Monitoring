# pylint: disable=protected-access, missing-module-docstring, missing-class-docstring, missing-function-docstring
import logging

from unittest.mock import MagicMock
import pandas as pd

import pytest

from app.src.sampling.selected_sampling import SelectedSampling

@pytest.fixture(name="selected_sampling_instance")
def rs_instance():
    data = "camera/csv_file.csv"
    return SelectedSampling(data, query="select")

def test_init():
    # Given
    data = "fail"
    query = ""
    # When & Then
    with pytest.raises(ValueError):
        SelectedSampling(data, query)

    # Given
    data = "fail"
    query = "hey"
    # When & Then
    with pytest.raises(ValueError):
        SelectedSampling(data, query)

def test_take_sample():
    # Given
    df1 = pd.DataFrame({'filename': [1, 2, 3, 4]})
    data = "camera/csv_file.csv"
    query = "select * from data where filename == 2"
    # When
    selected_sampling_instance =  SelectedSampling(data, query)
    result = selected_sampling_instance._query_csv(df1)
    # Then
    expected = 1
    assert len(result) == expected

    # Given
    df1 = pd.DataFrame({'filename': [1, 2, 3, 4]})
    data = "camera/csv_file.csv"
    query = "select * from data where filename in (2, 3)"
    # When
    selected_sampling_instance =  SelectedSampling(data, query)
    result = selected_sampling_instance._query_csv(df1)
    # Then
    expected = 2
    assert len(result) == expected

    # Given
    df1 = pd.DataFrame({'filename': [1, 2, 3, 4]})
    data = "camera/csv_file.csv"
    query = "select * from data"
    # When
    selected_sampling_instance =  SelectedSampling(data, query)
    result = selected_sampling_instance._query_csv(df1)
    # Then
    expected = 4
    assert len(result) == expected

def test_run_no_metadata(selected_sampling_instance, mocker, caplog):
    # Setup
    caplog.set_level(logging.DEBUG, logger="data-collector")
    mocker.patch.object(selected_sampling_instance, "load_metadata_csv", return_value=None)
    mocker.patch.object(selected_sampling_instance, "parse_metadata_csv",  new_callable=MagicMock)
    mocker.patch.object(selected_sampling_instance, "_query_csv",  new_callable=MagicMock)
    mocker.patch.object(selected_sampling_instance, "delete_given_whitelist_of_images",  new_callable=MagicMock)

    # When
    result = selected_sampling_instance.run()
    # Then
    assert result is False
    assert selected_sampling_instance._query_csv.call_count == 0

def test_run_yes_metadata(selected_sampling_instance, mocker, caplog):
    # Setup
    caplog.set_level(logging.DEBUG, logger="data-collector")
    mocker.patch.object(selected_sampling_instance, "load_metadata_csv", return_value="test")
    mocker.patch.object(selected_sampling_instance, "parse_metadata_csv",  new_callable=MagicMock)
    mocker.patch.object(selected_sampling_instance, "_query_csv",  new_callable=MagicMock)
    mocker.patch.object(selected_sampling_instance, "delete_given_whitelist_of_images",  new_callable=MagicMock)

    # When
    result = selected_sampling_instance.run()
    # Then
    assert result is True
    assert selected_sampling_instance._query_csv.call_count == 1
