# pylint: disable=protected-access, missing-module-docstring, missing-class-docstring, missing-function-docstring
from collections import namedtuple
from unittest.mock import MagicMock

import pytest

import pandas as pd

from app.src.sampling.sampling import Sampling


@pytest.fixture(name="sampling_instance")
def sampling_inst():
    return Sampling("a/b.csv")

def test__check_for_expected_cols():
    # Given
    df1 = pd.DataFrame(columns=['noLongerMissingPlies', 'newMissingPlies', 'capture-timestamp',
     'source_device', 'image-id', 'height', 'teamInstructions', 'pliesToBePlaced', 'width',
     'forcedPlies', 'correctlyPlacedPlies','forcedPlies', 'width', 'image-id', 'teamInstructions',
      'noLongerMissingPlies', 'pliesToBePlaced', 'source_device', 'newMissingPlies', 'height',
      'capture-timestamp', 'location', 'filename', 'camera_id', 'correctlyPlacedPlies', 'feedback'])
    # When & Then
    Sampling._check_for_expected_cols(df1)

    # Given
    df1 = pd.DataFrame(columns=['noLongerMissingPlies'])
    # When & Then
    with pytest.raises(AssertionError):
        Sampling._check_for_expected_cols(df1)

def test_load_metadata_csv_all_valid(mocker, sampling_instance, tmp_path):
    # Given
    mocker.patch("app.src.sampling.sampling.check_for_existence",
     return_value=True)
    mocker.patch("app.src.sampling.sampling.check_for_read",
     return_value=True)
    sniffed = namedtuple('dialect', 'delimiter')
    mocker.patch("app.src.sampling.sampling.csv.Sniffer.sniff",
     return_value=sniffed(","))
    mocker.patch("app.src.sampling.sampling.pd.read_csv",
     return_value = pd.DataFrame(columns=['noLongerMissingPlies', 'newMissingPlies', 'capture-timestamp',
     'source_device', 'image-id', 'height', 'teamInstructions', 'pliesToBePlaced', 'width',
     'forcedPlies', 'correctlyPlacedPlies','forcedPlies', 'width', 'image-id', 'teamInstructions',
      'noLongerMissingPlies', 'pliesToBePlaced', 'source_device', 'newMissingPlies', 'height',
      'capture-timestamp', 'location', 'filename', 'camera_id', 'correctlyPlacedPlies', 'feedback']))

    sampling_instance.csv_full_inp_path = tmp_path / "file.txt"

    f1 = tmp_path / "file.txt"
    f1.touch()

    # When
    data = sampling_instance.load_metadata_csv()

    # Then
    assert not data.columns.values == []

def test_load_metadata_csv_invalid(mocker, sampling_instance):
    # Given
    mocker.patch("app.src.sampling.sampling.check_for_existence",
     return_value=False)
    mocker.patch("app.src.sampling.sampling.check_for_read",
     return_value=True)

    # When
    data = sampling_instance.load_metadata_csv()

    # Then
    assert data is None

def test_drop_if_exists_sad_case(mocker, sampling_instance):
    # Given
    mocker.patch("app.src.sampling.sampling.check_for_existence",
     return_value=False)
    mocker.patch("app.src.sampling.sampling.check_for_read",
     return_value=True)
    os_mock = mocker.patch("app.src.sampling.sampling.os.remove" , MagicMock())

    # When
    sampling_instance.drop_if_exists("any_path")

    # Then
    assert os_mock.call_count == 0

def test_drop_if_exists_happy_case(mocker, sampling_instance):
    # Given
    mocker.patch("app.src.sampling.sampling.check_for_existence",
     return_value=True)
    mocker.patch("app.src.sampling.sampling.check_for_read",
     return_value=True)
    os_mock = mocker.patch("app.src.sampling.sampling.os.remove" , MagicMock())

    # When
    sampling_instance.drop_if_exists("any_path")

    # Then
    assert os_mock.call_count == 1
