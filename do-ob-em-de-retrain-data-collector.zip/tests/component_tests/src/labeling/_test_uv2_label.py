# pylint: disable=protected-access, missing-class-docstring, missing-function-docstring, no-self-use
import os

import pytest

import app.config as cfg

from app.src.labeling.uv2label import UV2Label

@pytest.fixture(scope="function", name="uv2setup")
def resource_paths():
    cfg.WORK_PATH = os.path.join(
        cfg.REPO_ROOT, "tests", "test_resources", "datasets", "images"
    )
    cfg.WORK_INSTR_PATH = os.path.join(
        cfg.REPO_ROOT, "tests", "test_resources", "work-instructions-data"
    )
    return cfg


def test_uv2label(uv2setup):
    uv2label = UV2Label(uv2setup.WORK_PATH, uv2setup.WORK_INSTR_PATH)
    uv2label.run()
