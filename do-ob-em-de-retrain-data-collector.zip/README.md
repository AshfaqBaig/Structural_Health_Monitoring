# Introduction 
DCM

Purpose of this module is to take care of GDPR-compliance of images and enable a swift retraining process.
In that the module cares for extending taken images with metadata.

Excurso to metadata:
* Metadata is sent by image-grabber, edge-verification and decision maker.
* Image-Grabber sends it for every saved image (N)
* Edge-Verification sends it for every analysed image (M)
* Decision-Maker sends it for every EV-analysed image which result is different to the previous' image result (O)
* Therefore N >= M >= O

During production, one .json-file per image is created in which metadata is saved.
Simultaneously metadata is appended to a csv-file which is global per camera.
Both the csv and the json file are saved in the same folder as the images.

The purpose of the csv-file is to be able to select a specific set of images post-production.
The json-file is used for finding the edges on the images that can be mapped to uv-dots.

When production is over, FINALIZE command can be triggered to start the image processing.
The following steps are done:
* Sampling/Selecting a subset of images, using predefined option or query on CSV
* Deletion of unselected images
* Anonymization of selected images
* Provision of labeled data in form of an xml-file.
* Upload of the images/jsons/xml

anonymizer_model: Keeper of the HD model.
app: source code
tests: tests

# Build and Test
* Build using .devcontainer or follow the Dockerfile instructions manually in your venv
* pytest tests/module_test for fully featured example
* make unit_tests
* make component_tests

# ToDos:
* Implement HD as a restful-service to decouple from DCM
* Establish EV->DCM and include it's payload.

How to invoke FINALIZE method: TO RECHECK!!

```
az iot hub invoke-module-method \
    -n IOTQLTDVLGENOBAWE01-iot-hub \
    -d EDQLTDVLGENOBAWE01-qlt-edge-2 \
    -m data-collector \
    --method-name 'FINALIZE' \
    --method-payload '{"query": "select * from data"}'
```

```
az iot hub invoke-module-method \
    -n IOTQLTDVLGENOBAWE01-iot-hub \
    -d EDQLTDVLGENOBAWE01-qlt-edge-2 \
    -m data-collector \
    --method-name 'FINALIZE' \
    --method-payload '{"method": "RandomSampling"}'    
```


Select all images from specific camera:
"select * from data where camera_id='aal-b9702u2-cam005' "
Select all forced plies:
"select * from data where forcedPlies!='{}’”
Select images for a specific layer:
"select * from data where forcedPlies!='{}’”
Select images for a specific layer:
"select * from data where forcedPlies like '%090_B97-00_LP_Outer_B1_1-288%' or pliesToBePlaced like '%090_B97-00_LP_Outer_B1_1-288%' or newMissingPlies like '%090_B97-00_LP_Outer_B1_1-288%' or noLongerMissingPlies like '%090_B97-00_LP_Outer_B1_1-288%'"
