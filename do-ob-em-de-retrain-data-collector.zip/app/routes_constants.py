""" Edge Hub routes constants """

IMAGE_GRABBER_INPUT = "imageGrabberInput"
EDGE_VERIFICATION_INPUT = "edgeVerificationInput"
DECISION_MAKER_INPUT = "decisionMakerInput"

DEFAULT_OUTPUT = 'defaultOutput'
ERROR_OUTPUT = 'errorOutput'
