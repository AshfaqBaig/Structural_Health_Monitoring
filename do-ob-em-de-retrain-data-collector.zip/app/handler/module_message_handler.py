# pylint: disable=method-hidden, protected-access
from cachetools import TTLCache

from azure.iot.device.iothub.models import Message

from app.utils.message_handling import extract_input
from app.utils.message_handling import get_matching_corr_ids
from app.utils.message_handling import update_cache_on_message
from app.utils.message_handling import process_metadata_pairs
from app.processor.metadata_writer import MetadataWriter


from app.logging.logger import yield_logger

log = yield_logger()
ERROR_OUTPUT = "errorOutput"

class ModuleMessageHandler:
    """ Class to handle module messages """
    def __init__(self, client):
        self.iot_client = client
        self.ig_cache = TTLCache(maxsize=1024, ttl=20)
        self.ev_cache = TTLCache(maxsize=1024, ttl=20)
        self.dm_cache = TTLCache(maxsize=512, ttl=20)
        self.metadata_writer = MetadataWriter()

    async def handle_amqp_message(self, input_message: Message) -> None:
        """
        Default AMQP message handler
        -> Messages from IG, DM and EV are processed
        """
        try:
            log.debug(f"Message received on {input_message.input_name}")
            self.process_message(input_message)
        except Exception as ex:
            # pass data further to error output
            log.exception(ex)
            await self.iot_client.send_message_to_output(str(ex), ERROR_OUTPUT)

    def process_message(self, input_message: Message) -> None:
        """ Main function to process incoming message """
        message_content = extract_input(input_message)
        caches = update_cache_on_message(message_content,
                                         self.ig_cache,
                                         self.ev_cache,
                                         self.dm_cache)
        self.ig_cache, self.ev_cache, self.dm_cache = caches
        matching_ids = get_matching_corr_ids(self.ig_cache, self.dm_cache)
        if matching_ids:
            log.debug(f"Found matching ids: {matching_ids}")
            metadata_pairs = process_metadata_pairs(matching_ids,
                                                    self.ig_cache, self.ev_cache, self.dm_cache)
            for output_path, metadata in metadata_pairs:
                self.metadata_writer.run(output_path, metadata)
        else:
            log.debug("Found no matching ids so far")
