# pylint: disable=method-hidden, protected-access
from azure.iot.device import MethodRequest, MethodResponse

from app.handler.module_message_handler import ModuleMessageHandler
from app.processor.finalizer import finalize

import app.config as cfg

from app.logging.logger import update_log_level, yield_logger

log = yield_logger()
ERROR_OUTPUT = "errorOutput"

class DirectMessageHandler:
    """ Class to handle direct messages """
    def __init__(self, client):
        self.iot_client = client

    async def handle_direct_message(self, request: MethodRequest):
        '''Module direct message handler'''
        try:
            log.info(f'Method {request.name} invocation with: {request.payload}')
            if request.name.lower() == "set_log_level":
                status = self._update_log_level(request.payload.get("value"))
            elif request.name.lower() == "start":
                self._start_data_collection()
                status = 200
            elif request.name.lower() == "finalize":
                status = self._parse_finalize_request(request.payload)
            else:
                log.warning("No valid command!")
                status = 400
            await self._send_response(request, status)
        except Exception as ex:
            log.exception('Unexpected method invocation error')
            method_response = MethodResponse.create_from_method_request(request, 500, str(ex))
            await self.iot_client.send_method_response(method_response)

    def _parse_finalize_request(self, request: dict):
        """ Parsing finalize request"""
        if not isinstance(request, dict):
            log.error("Invalid method-payload format, needs to be {}.")
            return 400
        if not "method" in request and not "query" in request:
            log.error("Method-payload needs to be contain query or method key.")
            return 400
        if request.get("query") is not None:
            self._apply_finalize(request["query"])
            return 200
        if request.get("method") is not None:
            if request.get("method") not in cfg.ALLOWED_METHODS:
                log.error(f"Method value not allowed. Allowed: {cfg.ALLOWED_METHODS}")
                return 400
            self._apply_finalize(request["method"])
            return 200
        log.error("Invalid method-payload format.")
        return 400

    def _apply_finalize(self, option_or_query=cfg.SP_SAMPLING_METHOD) -> None:
        """ Applies finalize algorithm """
        # Deactivate message receiption
        self.iot_client.on_message_received = None
        finalize(option_or_query)

    def _start_data_collection(self):
        log.info("Data collection enabled")
        # Start message reception
        module_message_handler = ModuleMessageHandler(self.iot_client)
        self.iot_client.on_message_received = module_message_handler.handle_amqp_message

    @staticmethod
    def _update_log_level(log_level: str) -> int:
        '''Update LOG_LEVEL'''
        if cfg.LOG_LEVEL != log_level:
            cfg.LOG_LEVEL = log_level
            update_log_level(log, cfg.LOG_LEVEL)
            return 200
        return 304

    async def _send_response(self, request: MethodRequest, status) -> None:
        method_response = MethodResponse.create_from_method_request(request, status, request.payload)
        await self.iot_client.send_method_response(method_response)
