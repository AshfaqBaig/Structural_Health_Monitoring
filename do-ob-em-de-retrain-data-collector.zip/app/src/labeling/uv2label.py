# pylint: skip-file
import glob
import json
import joblib
import os
from typing import List, Tuple, Union
import numpy as np
import imagesize
from defusedxml.minidom import parseString 
from defusedxml import ElementTree as ET

# defusedxml doesn't define these non-parsing related objects
from xml.etree.ElementTree import Element, SubElement, tostring
ET.Element = _ElementType = Element
ET.SubElement = SubElement
ET.tostring = tostring

import app.config as cfg
from app.logging.logger import yield_logger

log = yield_logger()

class UV2Label:
    def __init__(self,
                 work_path: str,
                 work_instr_path: str,
                 label: str = "edge"):
        self.work_path = work_path
        self.work_instr_path = work_instr_path
        self.template_xml = "\n".join(
            (
                '<?xml version="1.0" encoding="utf-8"?>',
                "<annotations>",
                "    <version>1.1</version>",
                "</annotations>",
            )
        )
        self.template_tree = ET.fromstring(self.template_xml)
        self.label = label

    @staticmethod
    def create_img_json_map(list_of_meta_files: list) -> dict:
        """ Creates mapping from metafile-filename to image-filename """
        splitter = lambda x: x.split("/")[-1].split(".")[0] + "." + cfg.EXPECTED_IMG_FORMAT
        return {key: splitter(key) for key in list_of_meta_files if key.endswith("json")}

    def create_xml_string(self):
        """ Creates xml-string """
        xml_string = tostring(
                self.template_tree,
                short_empty_elements=False,
                encoding="utf-8",
            )
        xml_string = parseString(xml_string)
        return xml_string

    def create_polyline_sub(self, image_sub: Element, edge: str) -> Element:
        polyline_sub = SubElement(image_sub, "polyline")
        polyline_sub.set("label", self.label)
        polyline_sub.set("points", edge[:-1])
        polyline_sub.set("occluded", "0")
        polyline_sub.set("z_order", "0")
        return polyline_sub

    def create_image_sub(self, idx: int, image_name: str, width: int, height: int) -> Element:
        """ Create image sub element inside annotation(root). """
        self.template_tree = ET.fromstring(self.template_xml) # recreate
        image_sub = SubElement(self.template_tree, "image")
        image_sub.set("id", str(idx))
        image_sub.set("name", image_name)
        image_sub.set("width", str(width))
        image_sub.set("height", str(height))
        return image_sub

    @staticmethod
    def get_meta_files(directory: str) -> list:
        """ Gets all metafiles from a directory"""
        return [f for f in sorted(glob.glob(os.path.join(directory, "*.json")))]

    def extract_meta_data(self, meta_fp: str) -> Tuple[dict, str, list]:
        """ Reads metadata from meta_fp"""
        log.debug(f"Attempting to read metadata with from {meta_fp}")
        with open(meta_fp, "r", encoding="utf-8") as f:
            data = json.load(f)

        cam_id, uv_fp = self.extract_cam_and_uvfp_from_payload(data)

        visible_edges = []
        for ply in data["dm_payload"][0]["correctlyPlacedPlies"]:
            visible_edges.extend(data["dm_payload"][0]["correctlyPlacedPlies"][ply]['edges'])

        # TODO: Implement caching
        with open(os.path.join(self.work_instr_path, uv_fp), "rb") as f:
            uv_data = joblib.load(f)
        return uv_data, cam_id, visible_edges

    @staticmethod
    def extract_cam_and_uvfp_from_payload(data: dict) -> Tuple[str, str]:
        """ Extracts cam-id and ground-truth (uv-coordinates) filepath """
        try:
            tis = data["dm_payload"][0]["metadata"]["teamInstructions"][0]
            metadata_dm = data["dm_payload"][0]["metadata"]
            cam_id = data["ig_payload"][0]["images"][0]["metadata"]["camera-id"]
            uv_fn = f"{tis['mouldId']}-{tis['bladeRevision']}-{tis['layerId']}-ev-input.joblib"
            uv_fp = os.path.join(
                metadata_dm["mouldId"].lower(),
                tis["version"],
                uv_fn,
            )       
        except (KeyError, IndexError, TypeError) as e:
            log.error(f"Nested structure unexpected, raised at: '{e}'") 
            raise
        return cam_id, uv_fp

    @staticmethod
    def extract_groundtruth(uv_data: dict,
                            cam_id: str,
                            edge: str) -> Tuple[Union[list, np.ndarray], Union[list, np.ndarray]]:
        # To avoid key errors
        if edge not in uv_data[cam_id]["edgedata"]:
            log.warning(f"{edge} not under {cam_id}")
            return [], []
        dots_x = uv_data[cam_id]["edgedata"][edge]['x_groundtruth']
        dots_y = uv_data[cam_id]["edgedata"][edge]['y_groundtruth']
        return dots_x, dots_y

    @staticmethod
    def groundtruth_to_dotstring(dots_x: np.ndarray, dots_y: np.ndarray) -> str:
        """ Converts and binds dots to one string """
        dottis = list(zip(dots_x, dots_y))
        dots_str = ";".join([f"{a},{b}" for a, b in dottis])
        return dots_str

    def get_uv_coordinates_from_groundtruth(self, uv_data: dict, cam_id: str, visible_edges: list) -> List[str]:
        """ Extracts UV Coordinates from Data File """
        output_list = []
        for edge in visible_edges:
            dots_x, dots_y = self.extract_groundtruth(uv_data, cam_id, edge)
            dots_str = self.groundtruth_to_dotstring(dots_x, dots_y)
            output_list.append(dots_str)
        return output_list

    def save_xml_file(self, image_name: str, xml_string) -> None:
        with open(os.path.join(self.work_path, f"{image_name}.xml"), "wt", encoding="utf-8") as f:
            f.write(
                    "\n".join(
                        [
                            line
                            for line in xml_string.toprettyxml(indent="    ").split("\n")
                            if line.strip()
                        ]
                    )
                )

    def run(self) -> None:
        list_of_meta_files = self.get_meta_files(self.work_path)
        meta_img_map = self.create_img_json_map(list_of_meta_files)
        log.debug(f"Mapping of json to jpg {meta_img_map}")
        for idx, file in enumerate(list_of_meta_files):
            image_name = meta_img_map[file]

            uv_data, cam_id, visible_edges = self.extract_meta_data(file)

            width  = imagesize.get(self.work_path + "/" + image_name)[0]
            height = imagesize.get(self.work_path + "/" + image_name)[1]
            image_sub = self.create_image_sub(idx, image_name, width, height)

            # Create polyline sub element inside image element.
            edges_list = self.get_uv_coordinates_from_groundtruth(uv_data, cam_id, visible_edges)

            log.debug(f"Edges list: {len(edges_list)}")
            for edge in edges_list:
                self.create_polyline_sub(image_sub, edge)
            xml_string = self.create_xml_string()

            self.save_xml_file(image_name, xml_string)
