""" Selected Sampling implementation """
import pandas as pd
import pandasql as ps

from app.src.sampling.sampling import Sampling
from app.logging.logger import yield_logger

log = yield_logger()

class SelectedSampling(Sampling):
    """ Samples by filter criterion from query """
    def __init__(self, csv_input_file, query: str):
        super().__init__(csv_input_file)
        if query == "":
            log.error("Invalid query")
            raise ValueError
        self.query = query

    def _query_csv(self, data: pd.DataFrame):
        """ Query on data frame to select whitelisted images """
        log.debug(f"Query is {self.query} and there are {len(data)} lines.")
        log.info(f"Available columns: {data.columns.values}")
        filtered_df = ps.sqldf(self.query)["filename"].to_list()

        return filtered_df

    def run(self) -> bool:
        """ Runs the pipeline """
        raw_data        = self.load_metadata_csv()
        if raw_data is None:
            return False
        parsed_data     = self.parse_metadata_csv(raw_data)
        selected_images = self._query_csv(parsed_data)
        # Delete all images not in the list
        self.delete_given_whitelist_of_images(selected_images)
        return True
