""" Random Sampling implementation """
import pandas as pd

import app.config as cfg

from app.src.sampling.sampling import Sampling
from app.logging.logger import yield_logger

log = yield_logger()

class RandomSampling(Sampling):
    """ Samples randomly without any filter criterion """
    def __init__(self, csv_input_file, probability: float = cfg.SP_RANDOM_SMPL_PROB):
        super().__init__(csv_input_file)
        self.probability = probability

    def take_sample(self, data: pd.DataFrame) -> list:
        """ Takes a sample of images randomly """
        log.info("Selecting images to anonymize.")
        return data.sample(frac=self.probability)["filename"].to_list()

    def run(self) -> bool:
        """ Runs the pipeline """
        raw_data        = self.load_metadata_csv()
        if raw_data is None:
            return False
        parsed_data     = self.parse_metadata_csv(raw_data)
        selected_images = self.take_sample(parsed_data)
        # Delete all images not in the list
        self.delete_given_whitelist_of_images(selected_images)
        return True
