""" Sampling master class """
import csv
import glob
import os

from typing import Optional

import pandas as pd

import app.config as cfg
from app.utils.tools import check_for_existence, check_for_read
from app.logging.logger import yield_logger

log = yield_logger()

class Sampling():
    """ Base class to implement shared functions """
    def __init__(self, csv_input_file: str):
        """ Sampling initialiser """
        try:
            self.camera_id, self.csv_input_filename  = csv_input_file.split("/")[-2:]
        except ValueError:
            log.error(f"Expecting csv-filename with format 'camera/csv_file.csv' got '{csv_input_file}'")
            raise

        self.csv_full_inp_path = os.path.join(csv_input_file)

    def load_metadata_csv(self) -> Optional[pd.DataFrame]:
        """
        Method to read csv files via pandas lib
        and return it as data frame object
        """
        log.info(f"Attempting to load metadata-csv from '{self.csv_full_inp_path}'.")
        status_ex = check_for_existence(self.csv_full_inp_path)
        status_rw = check_for_read(self.csv_full_inp_path)
        if not status_ex or not status_rw:
            return None

        with open(self.csv_full_inp_path, 'r', encoding='utf-8') as csvfile:
            dialect = csv.Sniffer().sniff(csvfile.readline())
            delim = dialect.delimiter

        data = pd.read_csv(self.csv_full_inp_path, delimiter=delim)

        self._check_for_expected_cols(data)

        return data

    @staticmethod
    def parse_metadata_csv(data: pd.DataFrame) -> pd.DataFrame:
        """ Method to parse csv """
        return data

    def delete_given_whitelist_of_images(self, whitelist_of_images: list) -> None:
        """ Deletes all images in the folder except for the positive list """
        log.info(f"Getting images as per {cfg.DCM_INPUT_FOLDER}/{self.camera_id}*.{cfg.EXPECTED_IMG_FORMAT}")
        all_jpg_files = glob.glob(os.path.join(cfg.DCM_INPUT_FOLDER, self.camera_id, f"*.{cfg.EXPECTED_IMG_FORMAT}"))
        log.debug(f"There are {len(all_jpg_files)} images to be processed.")
        diff = len(all_jpg_files) - len(whitelist_of_images)
        log.info(f"Keeping {len(whitelist_of_images)} images as per whitelist, dropping {diff} image(s).")
        if diff < 0:
            log.error("<0 !! There is something wrong with writing json/csv files!")
        for image_path_jpg in all_jpg_files: # Full path
            image_fn_jpg = image_path_jpg.split(os.sep)[-1]
            image_fn_json = image_fn_jpg.split(".")[0] + ".json"
            image_path_json = image_path_jpg.split(".")[0] + ".json"

            if image_fn_jpg in whitelist_of_images:
                log.debug(f"Keeping {image_fn_jpg}")
                log.debug(f"Keeping {image_fn_json}")
                continue

            self.drop_if_exists(image_path_jpg)
            self.drop_if_exists(image_path_json)

    @staticmethod
    def drop_if_exists(path):
        """ Drops files safely """
        if check_for_existence(path) and \
            check_for_read(path):
            log.debug(f"Dropping {path}")
            os.remove(path)

    @staticmethod
    def _check_for_expected_cols(data: pd.DataFrame) -> None:
        """ Checks data for expected columns """
        log.debug("Checking Metadata-CSV for expected input.")
        expected_cols = cfg.HEADER_LIST + cfg.PLY_INFO
        try:
            assert all(col in data.columns.values for col in expected_cols)
        except AssertionError as exc:
            raise AssertionError(f"Missing columns: {set(expected_cols) - set(data.columns.values)}") from exc
