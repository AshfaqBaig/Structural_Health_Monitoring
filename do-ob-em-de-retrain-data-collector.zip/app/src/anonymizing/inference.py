# pylint: disable=no-member
import time

import cv2
import torch

from app.src.anonymizing.models.common import DetectMultiBackend
from app.src.anonymizing.utils.datasets import LoadImages
from app.src.anonymizing.utils.general import non_max_suppression, scale_coords

import app.config as cfg
from app.logging.logger import yield_logger

log = yield_logger()

class HumanDetectionRunner():
    """ Class to do the anonymization """
    def __init__(self, input_path):
        self.input_path = input_path
        # Ensure CPU
        self.device = torch.device("cpu")
        # Load model
        self.model = DetectMultiBackend(cfg.HD_MODEL_SOURCE, device=self.device, dnn=False)
        self.stride, self.pt_model, self.jit = self.model.stride, self.model.pt, self.model.jit
        self.model.model.float()
        self.model.warmup(imgsz=(1, 3))  # warmup

    def anonymize(self):
        """ Main anonymizer function """

        log.info(f"Starting the anonymizer for {self.input_path }")
        log.warning("*"*60)

        start_time = time.time() * 1000
        dataset = LoadImages(self.input_path, stride=self.stride, auto=self.pt_model and not self.jit)
        for img_path, input_img, img_stride, _, _ in dataset:

            log.debug(f"Processing {img_path}")
            input_img = torch.from_numpy(input_img).to(self.device)
            input_img = input_img.float()  # uint8 to fp16/32
            input_img /= 255  # 0 - 255 to 0.0 - 1.0
            if len(input_img.shape) == 3:
                input_img = input_img[None]  # expand for batch dim

            # Inference
            prediction = self.predictions(input_img, self.model)

            # Process predictions
            for _, predicted_values in enumerate(prediction):  # per image
                if len(predicted_values):
                    # Rescale boxes from img_size to im0 size
                    predicted_values[:, :4] = scale_coords(input_img.shape[2:], predicted_values[:, :4], img_stride.shape).round()

                    # Write results
                    for *xyxy, _, class_label in reversed(predicted_values):
                        img_stride = self.write_results(xyxy, class_label, img_stride)
                log.info(f"Done with {img_path}")
                # Override results (image with detections)
                cv2.imwrite(img_path, img_stride)
        total_time = (time.time() * 1000) - start_time
        log.warning("*"*60)
        log.warning(f"Total processing time: {round(total_time, 4)} ms for {len(dataset)} files.")

    def write_results(self, xyxy, class_label, output_img):
        """ Does something which I have no clue of """
        if int(class_label) == 0:
            log.debug("Application of blurring predictions")
            blur = output_img[int(xyxy[1]):int(xyxy[3]), int(xyxy[0]):int(xyxy[2])]
            blur = self.anonymize_simple(blur, int(xyxy[2]), int(xyxy[3]))
            output_img[int(xyxy[1]):int(xyxy[3]), int(xyxy[0]):int(xyxy[2])] = blur

        return output_img

    @staticmethod
    def predictions(input_img: torch.Tensor, model: DetectMultiBackend) -> list:
        """ Generates predictions """
        log.debug("Generating human predictions")
        prediction = model(input_img, augment=False, visualize=False)
        prediction = non_max_suppression(prediction,
                                         cfg.HD_CONF_THRESHOLD,
                                         cfg.HD_IOU_THRESHOLD,
                                         cfg.HD_CLASSES,
                                         cfg.HD_AGNOSTIC_NMS,
                                         max_det=cfg.HD_MAX_DETECTION)
        return prediction

    @staticmethod
    def anonymize_simple(image, w, h, factor=3.0):
        """ Applies the blurring """
        # automatically determine the size of the blurring kernel based on the spatial dimensions of the input image
        kw_, kh_ = int(w / factor), int(h / factor)
        # ensure the width of the kernel is odd
        if kw_ % 2 == 0:
            kw_ -= 1
        # ensure the height of the kernel is odd
        if kh_ % 2 == 0:
            kh_ -= 1
        # apply a Gaussian blur to the input image using our computed kernel size
        return cv2.blur(image, (kw_, kh_), 0)
