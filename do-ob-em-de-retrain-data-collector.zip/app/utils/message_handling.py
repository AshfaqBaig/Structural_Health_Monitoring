import json
import os

from collections import defaultdict
from typing import Tuple

from azure.iot.device.iothub.models import Message
from cachetools import TTLCache

from app import routes_constants as routes

import app.config as cfg

from app.logging.logger import yield_logger

log = yield_logger()

def extract_input(input_message: Message) -> dict:
    """ Extracts message components"""
    message_received = {"msg_source": input_message.input_name,
                        "correlation_id": input_message.correlation_id,
                        "custom_properties": input_message.custom_properties,
                        "data": json.loads(input_message.data)}
    log.debug(f"Message received: {message_received}.")
    return message_received

def update_cache_on_message(message: dict,
                            ig_cache: TTLCache,
                            ev_cache: TTLCache,
                            dm_cache: TTLCache) -> Tuple[TTLCache, TTLCache, TTLCache]:
    """ Handles inbound message by updating cache """
    correlation = message.get("correlation_id")
    if not correlation:
        log.error(f"No correlation id provided by message from {message['msg_source']}")
        return ig_cache, ev_cache, dm_cache

    if message['msg_source'] == routes.IMAGE_GRABBER_INPUT:
        ig_cache[correlation] = {"ig_payload": message.get("data"),
                                 "ig_custom_property": message.get("custom_properties")}

    if message['msg_source'] == routes.EDGE_VERIFICATION_INPUT:
        ev_cache[correlation] = {"ev_payload": message.get("data"),
                                 "ev_custom_property": message.get("custom_properties")}

    if message['msg_source'] == routes.DECISION_MAKER_INPUT:
        dm_cache[correlation] = {"dm_payload": message.get("data"),
                                 "dm_custom_property": message.get("custom_properties")}
    return (ig_cache, ev_cache, dm_cache)

def get_matching_corr_ids(ig_cache: TTLCache, dm_cache: TTLCache) -> list:
    """ Maps incoming messages using correlation id """
    # TODO: Check if there is better algo
    matching_ids = []
    for ig_correlation_id in ig_cache:
        for dm_correlation_id in dm_cache:
            if ig_correlation_id == dm_correlation_id:
                matching_ids.append(ig_correlation_id)
    return list(set(matching_ids))

def combine_metadata(ig_data: TTLCache, ev_data: TTLCache, dm_data: TTLCache) -> defaultdict:
    """ Merges Metadata-dictionaries """
    combined_metadata = defaultdict(list)
    for de_keys in (ig_data, ev_data, dm_data):
        for key, value in de_keys.items():
            try:
                combined_metadata[key].append(value)
            except KeyError:
                pass
    return combined_metadata

def extract_image_information(metadata: dict) -> str:
    """ extracts image field information """
    return metadata["ig_payload"][0]['images'][0]

def process_metadata_pairs(matching_ids: list, ig_cache: TTLCache, ev_cache: TTLCache, dm_cache: TTLCache) -> list:
    """ Calls the pipeline to write json/csv """
    result = []
    for id_ in matching_ids:
        log.debug(f"Writing the metadata file for c-id {id_}")
        # EV Cache entry is optional, just to be safe (lost messages etc)
        metadata = combine_metadata(ig_cache[id_], ev_cache.get(id_, {}), dm_cache[id_])
        ig_cache.pop(id_, None)
        ev_cache.pop(id_, None)
        dm_cache.pop(id_, None)
        image = extract_image_information(metadata)
        image_nn = image["location"].split('.')[0]
        output_path = os.path.join(cfg.DCM_INPUT_FOLDER, f"{image_nn}.json")
        result.append([output_path, metadata])
    return result
