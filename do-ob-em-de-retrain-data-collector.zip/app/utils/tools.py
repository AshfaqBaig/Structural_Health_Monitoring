""" Lib to provide tooling functions """

import os

from app.logging.logger import yield_logger

log = yield_logger()

def check_for_existence(path: str) -> bool:
    """ Checks for existence of file """
    if not os.path.isfile(path):
        out_msg = f"Data file at '{path}' not found"
        log.warning(out_msg)
        return False
    return True

def check_for_read(path: str) -> bool:
    """ Check for readability """
    if not os.access(path, os.R_OK):
        out_msg = f"Data file at '{path}' not readable!"
        log.warning(out_msg)
        return False
    return True
