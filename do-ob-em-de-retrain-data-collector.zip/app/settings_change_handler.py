import json
import logging
from etcd3.watch import WatchResponse
import app.config as cfg

log = logging.getLogger(cfg.MODULE_APP_NAME)

class SettingsChangeHandler:
    """ Handle module settings change incoming from etcd """

    @staticmethod
    def on_settings_change(response: WatchResponse):
        """ Handle module settings change incoming from etcd """
        key: str = response.events[0].key.decode("utf-8")
        try:
            value: dict = json.loads(response.events[0].value.decode("utf-8"))
            log.info(f"Etcd message key: {key}, value: {value}")
        except (ValueError, AttributeError):
            log.exception("Failed to parse settings_change")
