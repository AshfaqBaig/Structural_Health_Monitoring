""" etcd client wrapper """
import json
import logging
import sys

import etcd3
from etcd3 import Etcd3Exception

import app.config as cfg

log = logging.getLogger(cfg.MODULE_APP_NAME)


class SharedStorage:
    """ An etcd client wrapper. Instance of the class connects to etcd storage. """

    def __init__(self, etdc_url: str = None, ttl: int = 600):
        host = etdc_url.split(":")[0]
        port = etdc_url.split(":")[1]
        self.etcd_client = etcd3.client(host=host, port=port)
        self._ttl = ttl

        # ETCD connection-test
        try:
            self.etcd_client.get("ETCD connection-test")
            log.info("ETCD connection established!")
        except ConnectionError:
            log.error("No ETCD connection available")
            sys.exit()
        except Etcd3Exception:
            log.exception("Unexpected ETCD storage error")
            sys.exit()

    def __str__(self) -> str:
        return str(self.__dict__)

    def watch_key(self, key_prefix: str, handler: object) -> None:
        """ Watch for put-events with specific prefix and call "handler" in case. """
        log.info("Adding watch by given key_prefix: %s", key_prefix)
        try:
            self.etcd_client.add_watch_callback(key_prefix, callback=handler)
        except Etcd3Exception as ex:
            log.error("Failed to add watch callback for given key_prefix: %s, due to %s:", key_prefix, ex)

    def put_key(self, key: str, value: dict) -> None:
        """ Inserting/Updating key value in etcd. """
        log.debug("Putting into etcd store key:value: %s\t:%s", key, json.dumps(value))
        self.etcd_client.put(key, json.dumps(value))
