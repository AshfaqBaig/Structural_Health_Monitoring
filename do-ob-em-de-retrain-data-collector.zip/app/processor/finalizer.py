from datetime import datetime
import glob
import os
import shutil

import app.config as cfg

from app.src.sampling.random_sampling import RandomSampling
from app.src.sampling.selected_sampling import SelectedSampling
from app.src.anonymizing.inference import HumanDetectionRunner
from app.src.labeling.uv2label import UV2Label
from app.logging.logger import yield_logger

log = yield_logger()

def finalize(option_or_query):
    """
    Method to be called after all trouble is over
    TODO: Split this function up when it is done.
    """
    date_time = datetime.now()
    # Walk through all camera folders:
    log.info("Starting the finalization...")
    image_folders = [os.path.abspath(x[0]) for x in os.walk(cfg.DCM_INPUT_FOLDER)]
    log.debug(f"Image-folders to scan: {image_folders}")
    for camera_path in image_folders: # /workspaces/do-ob-em-de-retrain-data-collector/input/sample-cam/
        try:
            camera_name = extract_camera_name(camera_path) # sample-cam
            log.info(f"Processing finalization for camera ''{camera_name}''")

            #####################################################################################
            # Compare NO of json and image files
            #####################################################################################
            check_no_files(len(glob.glob(camera_path + "/" + "*.json")),
                           len(glob.glob(camera_path + "/" + f"*.{cfg.EXPECTED_IMG_FORMAT}")))

            #####################################################################################
            # Apply sampling (give it the full local path to csv in camera folder)
            # e.g. /workspaces/do-ob-em-de-retrain-data-collector/input/sample-cam/sample-cam.csv
            #####################################################################################
            log.info("Sampling/Selecting")
            sample_or_select_data(option_or_query, camera_path, camera_name)
            log.info("Done")

            #####################################################################################
            # Apply HD-Detection (give it the full local path to camera folder)
            # e.g. /workspaces/do-ob-em-de-retrain-data-collector/input/sample-cam/
            #####################################################################################
            log.info("Anonymizer")
            anonymizer_instance = HumanDetectionRunner(camera_path)
            anonymizer_instance.anonymize()
            log.info("Done")

            #####################################################################################
            # Apply extraction of UV-labels
            #####################################################################################
            log.info("Labler")
            labeling_instance = UV2Label(work_path=camera_path,
                                         work_instr_path=cfg.WORK_INSTRUCTIONS_PATH)
            labeling_instance.run()
            log.info("Done")

            #####################################################################################
            # Copy files to upload folder
            #####################################################################################
            log.info(f"copying files from {camera_path} to {cfg.DCM_OUTPUT_FOLDER}")
            shutil.copytree(
                camera_path,
                os.path.join(
                    cfg.DCM_OUTPUT_FOLDER, camera_name + "-" + date_time.strftime("%Y%m%d")
                )
            )
            log.info(f"Finalization done for camera {camera_path}")
        except Exception:
            log.exception(f"Failed to execute finalize for {camera_path}")


def extract_camera_name(camera_path: str) -> str:
    """ Extracts camera name from path """
    return camera_path.split("/")[-1]

def check_no_files(no_json_files: int, no_img_files: int):
    """
    camera_path: Absolute path of camera path
    """
    if no_json_files != no_img_files:
        log.warning(f"Difference in number of json-files/jpg-files {abs(no_img_files-no_json_files)}")

def sample_or_select_data(option_or_query: str, camera_path: str, camera_name: str) -> bool:
    """ Attempts to sample or select data, returns success status as bool """
    csv_input_file = os.path.join(camera_path, f'{camera_name}.csv')
    option_or_query = option_or_query.strip()
    if option_or_query.lower() == "randomsampling":
        sampling_instance = RandomSampling(csv_input_file=csv_input_file,
                                           probability=cfg.SP_RANDOM_SMPL_PROB)
    elif option_or_query.lower().startswith("select"):
        sampling_instance = SelectedSampling(csv_input_file=csv_input_file,
                                             query=option_or_query)
    else:
        log.warning("No valid sampling method/query. Ignoring and continuing...")
        return False
    success = sampling_instance.run()
    if not success:
        log.warning("Did not process camera folder, csv-file not found readable. Continuing...")
    return success
