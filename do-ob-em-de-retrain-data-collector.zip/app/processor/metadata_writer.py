# pylint: disable=unnecessary-dict-index-lookup
import csv

import json
import os

import app.config as cfg

from app.utils.message_handling import extract_image_information
from app.logging.logger import yield_logger

log = yield_logger()

class MetadataWriter:
    '''
    Metadata writer class
    Processes cached messages from IG, EV and DM into metadata
    '''

    def __init__(self) -> None:
        pass

    def run(self, output_path: str, metadata: dict) -> None:
        """Gets called, when a metadata pair/tuplet was found"""
        self._save_metadata_json(output_path, metadata)
        location = extract_image_information(metadata)['location']
        folder_name = location.split('/')[0]
        metadata_common_file = os.path.join(folder_name, f"{folder_name}.csv")
        file_path = os.path.join(cfg.DCM_INPUT_FOLDER, f"{metadata_common_file}")
        # append to csv
        self._append_metadata_csv(file_path, metadata)

    def _append_metadata_csv(self, file_path: str, metadata: dict) -> None:
        """append parsed metadata to csv file"""
        file_exists = os.path.isfile(file_path)
        with open(file_path, 'a', encoding="utf-8") as csvfile:
            writer = csv.DictWriter(csvfile, delimiter=',', lineterminator='\n',fieldnames=cfg.HEADER_LIST)
            if not file_exists:
                writer.writeheader()  # file doesn't exist yet, write a header
            csv_metadata = self.generate_data_row(metadata)
            csv_metadata_editable = self.postprocess_row(csv_metadata)
            writer.writerow(csv_metadata_editable)
            log.debug(f"metadata appended to csv: {file_path}")

    def generate_data_row(self, metadata: dict):
        """ Parses the metdata dictionary """
        csv_metadata = {}
        for col in cfg.HEADER_LIST:
            if col in cfg.PLY_INFO:
                value = next(self.find_item(metadata, col), None)
                log.debug(f"searching layer-edge info in {col}")
                layer_edges_dict = self.extract_layer_edges(value)
                csv_metadata.update({col: layer_edges_dict})
            else:
                value = next(self.find_item(metadata, col), None)
                csv_metadata.update({col:value})
        return csv_metadata

    @staticmethod
    def postprocess_row(csv_metadata: dict):
        """ Does some postprocessing on data row """
        csv_metadata["filename"] = csv_metadata["location"].split('/')[1]
        csv_metadata["camera_id"] = csv_metadata["location"].split('/')[0]
        csv_metadata_editable = csv_metadata.copy()
        for key, val in csv_metadata.items():
            if not val:
                csv_metadata_editable[key] = ""
        return csv_metadata_editable

    @staticmethod
    def _save_metadata_json(output_path: str, metadata: dict) -> None:
        """saves metadata json file for every image"""
        if not os.path.exists(output_path):
            with open(output_path, "wt", encoding="utf-8") as outfile:
                outfile.write(json.dumps(metadata, indent=4))
                log.info(f"metadata saved to path: {output_path}")

    def find_item(self, obj: dict, field: str) -> dict:
        """
        Takes a dict with nested lists and dicts,
        and searches all dicts for a key of the field
        provided.
        """
        if isinstance(obj, dict):
            for key, value in obj.items():
                if key == field:
                    yield value
                elif isinstance(value, (dict, list)):
                    yield from self.find_item(value, field)
        elif isinstance(obj, list):
            for value in obj:
                yield from self.find_item(value, field)

    def extract_layer_edges(self, metadata: dict) -> list:
        """extracts layerId and edges info from a dictionary"""
        layer_edges_list = []
        for _, value in metadata.items():
            edges = next(self.find_item(value, "edges"), None)
            layer_id = next(self.find_item(value, "layer_id"), None)
            if {layer_id:edges} not in layer_edges_list:
                layer_edges_list.append({layer_id: edges})
        log.debug(f"layer-edges list: {layer_edges_list}")
        return layer_edges_list
