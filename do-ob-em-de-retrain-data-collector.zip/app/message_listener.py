import asyncio
import time

from azure.iot.device.aio import IoTHubModuleClient

from app.handler.direct_message_handler import DirectMessageHandler
from app.handler.module_message_handler import ModuleMessageHandler
from app.logging import logger

log = logger.yield_logger()

class MessageListener:
    """
    AMQP Listener implementation.
    Supports:
    * AMQP payloads
    * Direct messages
    """

    def __init__(self):
        self.module_client = IoTHubModuleClient.create_from_edge_environment()
        self.direct_message_handler = DirectMessageHandler(self.module_client)
        self.module_message_handler = ModuleMessageHandler(self.module_client)

    @staticmethod
    def empty_listener():
        """
        Empty listener to keep module always running
        """
        while True:
            time.sleep(600) # nosemgrep: python.lang.best-practice.sleep.arbitrary-sleep

    async def run(self):
        """
        Entrypoint main method
        """
        try:
            await self.module_client.connect()

            self.module_client.on_message_received = self.module_message_handler.handle_amqp_message
            self.module_client.on_method_request_received = self.direct_message_handler.handle_direct_message

            log.info("AMQP listener started")
            log.info("Log level for %s logger is: %s",
                     log.name, log.getEffectiveLevel())

            # Run the empty listener in the event loop
            loop = asyncio.get_event_loop()
            user_finished = loop.run_in_executor(None, self.empty_listener)
            await user_finished

            # Finally, disconnect
            await self.module_client.disconnect()

        except Exception as ex:
            log.exception("Unexpected error %s ", ex)
            raise
