import logging.config
from os.path import exists

import app.config as cfg

logger_config_locations = [f"/app/{cfg.LOGGER_CONFIG}", f"./{cfg.LOGGER_CONFIG}"]

def yield_logger(logging_file_config: str = "") -> logging.Logger:
    """ Preconfigures application wide logging system and returns logger. """

    if not logging_file_config:
        logging_file_config = locate_logger_config()
    logging.config.fileConfig(logging_file_config)
    return logging.getLogger(cfg.MODULE_APP_NAME)

def locate_logger_config():
    """ Locate logger config which can be placed in different locations """
    for location in logger_config_locations:
        if exists(location):
            return location
    raise FileNotFoundError("Logging config not found")

def update_log_level(log, log_level):
    """ Update log level for logger & its handlers """
    log.setLevel(log_level)
    for handler in log.handlers:
        handler.setLevel(log_level)
    log.info(f"Updated log level to {log.level} for {log.name} logger")
