"""Module defines all configuration options"""
import os
import logging

from app.utils.determine_repo_root import get_repo_root

REPO_ROOT = get_repo_root()

MODULE_APP_NAME = "data-collector"
LOGGER_CONFIG = "logging-plain.ini"

MOULD_ID = os.environ.get("MOULD_ID")
IOTEDGE_MODULEID = os.environ.get("IOTEDGE_MODULEID")
IOTEDGE_DEVICEID = os.environ.get("IOTEDGE_DEVICEID")
IOTEDGE_GATEWAYHOSTNAME = os.environ.get("IOTEDGE_GATEWAYHOSTNAME")

# env var paths
DCM_INPUT_FOLDER = os.environ.get("DCM_INPUT_FOLDER") or \
                os.path.join(REPO_ROOT, "tests", "test_resources", "module_test_tmp")
DCM_OUTPUT_FOLDER = os.environ.get("DCM_OUTPUT_FOLDER") or \
                os.path.join(REPO_ROOT, "tests", "test_resources", "module_test_tmp", "final_destination")
WORK_INSTRUCTIONS_PATH = os.environ.get("WORK_INSTRUCTIONS_PATH") or \
                         os.path.join(get_repo_root(), "tests/test_resources/work-instructions-data")

CAMERA_ID   = os.getenv("CAMERA_ID")
LOCATION_ID = os.getenv("LOCATION_ID")
HALL_ID     = os.getenv("HALL_ID")
MOULD_ID    = os.getenv("MOULD_ID")
BLADE_ID    = os.getenv("BLADE_ID")

# env vars overridable by direct message
LOG_LEVEL = os.environ.get("LOG_LEVEL") or logging.DEBUG

##########################################
# General Parameters
##########################################
EXPECTED_IMG_FORMAT = "jpg"

##########################################
# Sampling Parameters
##########################################
ALLOWED_METHODS = ["RandomSampling"]
SP_SAMPLING_METHOD = "RandomSampling"
SP_RANDOM_SMPL_PROB = 0.5

##########################################
# Anonymization Model Parameters
##########################################
# Model source
HD_MODEL_SOURCE = os.path.join(get_repo_root(), "anonymizer_model", "human-detection-model.pt")

HD_CONF_THRESHOLD = 0.5  # confidence threshold
HD_IOU_THRESHOLD = 0.5  # NMS IOU threshold
HD_MAX_DETECTION = 15  # maximum detections per image

HD_CLASSES = None # filter by class: --class 0, or --class 0 2 3
HD_AGNOSTIC_NMS = False  # class-agnostic NMS

# Metadata csv file.
HEADER_LIST = ["filename", "camera_id", "location", "capture-timestamp", "image-id", "height", "width",
               "source_device", "teamInstructions", "correctlyPlacedPlies",
               "pliesToBePlaced", "newMissingPlies", "noLongerMissingPlies", "forcedPlies", "feedback"]
PLY_INFO = ["correctlyPlacedPlies", "pliesToBePlaced", "newMissingPlies", "noLongerMissingPlies"]


# ETCD
MODULE_SETTINGS_KEY = f"/devices/{IOTEDGE_GATEWAYHOSTNAME}/modules/{MODULE_APP_NAME}/settings"
ETCD_URL = os.getenv("ETCD_URL", "localhost:2379")
ETCD_TTL = int(os.getenv("ETCD_TTL", "600"))
