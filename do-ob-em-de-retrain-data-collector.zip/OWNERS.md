# Authors
- Malte Hoffmann - SGRE (malte.hoffmann@siemensgamesa.com)
- Kumar Praveen - SGRE (praveen.kumar@siemensgamesa.com)