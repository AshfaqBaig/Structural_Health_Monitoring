import setuptools

setuptools.setup(
    name="dataset-collection-module",
    packages=setuptools.find_packages(),
)