# em-ml-marker-detection
![Python](https://img.shields.io/badge/Python-3.9-informational)
![Docker](https://img.shields.io/badge/image-amd64/python:3.9.0--slim--buster-informational)

![azure-iot-device](https://img.shields.io/badge/azure--iot--device-v2.11.0-informational)
![azure-iot-device (latest)](https://img.shields.io/pypi/v/azure--iot--device?label=latest)
![tritonclient](https://img.shields.io/badge/tritonclient-v2.9.0-informational)
![tritonclient (latest)](https://img.shields.io/pypi/v/tritonclient?label=latest)
![grpcio-tools](https://img.shields.io/badge/grpcio--tools-v1.44.0-informational)
![grpcio-tools (latest)](https://img.shields.io/pypi/v/grpcio--tools?label=latest)
![opencv-python-headless](https://img.shields.io/badge/opencv--python--headless-v4.5.5.64-informational)
![opencv-python-headless (latest)](https://img.shields.io/pypi/v/opencv--python--headless?label=latest)
![grpcio-tools](https://img.shields.io/badge/grpcio--tools-v1.37.1-informational)
![grpcio-tools (latest)](https://img.shields.io/pypi/v/grpcio--tools?label=latest)
![python-json-logger](https://img.shields.io/badge/python--json--logger-v2.0.2-informational)
![python-json-logger (latest)](https://img.shields.io/pypi/v/python--json--logger?label=latest)
![etcd3](https://img.shields.io/badge/etcd3-v0.12.0-informational)
![etcd3 (latest)](https://img.shields.io/pypi/v/etcd3?label=latest)

# Introduction

IoT Edge module performing ply edge detections using DexiNed deep neural network and running on Nvidia Triton server.

# Environment variables

Module can be configured using env variables and overriden by module direct method invocation

| Parameter      | Default value                                      | Overridable by Direct Method | Description                                                                                            |
| -------------- | -------------------------------------------------- | --------------- | ------------------------------------------------------------------------------------------------------ |
| TIS_URL | tis:8001 | No | Triton inference server URI                                                               |
| INPUT_PATH | |  No |Input path which is used to read data from |
| OUTPUT_PATH |  |  No |Output path which is used to write data to |
| TIS_MODEL_NAME | | No | Inference server model |
| TIS_MODEL_VERSION | | No | Inference server model version. No version set equals to latest model version |
| TIS_BATCH_SIZE | 1 | No | Inference server batch size |
| LOG_LEVEL  | 20 |  Yes |Default log level |

# Run integration test up to Triton Inference Server

Its quite complicated to test full module workflow including both transport and business logic, so integration tests is the approach to test business logic without setting up IoT Hub Edge solution simulator. Sample integration test tests
message's DefaultProcessor including pre/post-processors. As an input `samples/siemens.png` file is used which is consumed by processors and inference result outputted into `samples/results/siemens.png` file.

### Install dependencies
```
pip3 install -r nvidia-repo.txt
pip3 install -r requirements.txt
```

### Run Triton Inference Server locally
Command params needs to be adjusted according to local environment and paths used
```
docker run --name tis --gpus=all --shm-size=1g --ulimit memlock=-1 --ulimit stack=67108864 --rm \
  -p8000:8000 -p8001:8001 -p8002:8002 \
  -v~/gamesa/triton-inference-server/docs/examples/model_repository:/models \
  nvcr.io/nvidia/tritonserver:20.09-py3 tritonserver \
  --model-repository=/models
```

### Run IT
```
export PYTHONPATH='./'
pytest it
```

### Check inference results
```
cat samples/results/siemens.png
```

# Test
### Install dependencies
```
pip3 install -r requirements-tests.txt
```
### Run unit test
```
export PYTHONPATH='./'
pytest tests/
```
### Run inference on a set of offline files

    cd samples
    ./generate_payload.sh payload_name_prefix files_location
    cd ..
    mkdir inference_outputs

edit payload name and output folder in it/test_default_preprocessor.py to point to required folders

## Module direct method commands

### Update log level
```
az iot hub invoke-module-method \
    -n IOTDEVDVLGENOBAWE01-iot-hub-test-sgre \
    -d EDDEVDVLGENOBAWE01-mvp-edge-2 \
    -m marker-detection  \
    --method-name 'set_log_level' \
    --method-payload '{"value":"INFO" }'
```
