# Authors
- Pranjall Kumar - SGRE (pranjall.kumar@siemensgamesa.com)
- Dirk Rannacher - SGRE (dirk.rannacher@siemensgamesa.com)