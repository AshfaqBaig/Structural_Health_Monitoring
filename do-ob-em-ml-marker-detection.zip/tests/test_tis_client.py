# pylint: disable=protected-access

from unittest.mock import MagicMock
import pytest
import numpy as np
import tritonclient.grpc.model_config_pb2 as mc

from app.inference.tis_client import TritonInferenceServerClient


@pytest.fixture(name="config_response")
def fixture_config_response():
    """ Fixture to mock object of config_response """
    class ConfigResponse:
        """ Class to mock config_response """

        def __init__(self):
            self.config = "some config value"
            self.format = "some config format"
            self.max_batch_size = 10
    return ConfigResponse()


@pytest.fixture(name="model_dispatcher")
def fixture_model_dispatcher():
    """ Fixture to return dummy parsed model """
    return [
        "some_input_name", "some_output_name", "some_channel",
        "some_height", "some_width", "some_format", "some_datatype"
    ]


@pytest.fixture(name="output_metadata")
def fixture_ouput_metadata():
    """ Fixture to mock output metadata """
    class OutputMetadata:
        """ Class to mock output meta object """

        def __init__(self):
            self.datatype = "some datatype"
            self.name = "some name"
    return OutputMetadata()


@pytest.fixture(name="model_metadata")
def fixture_model_metadata(output_metadata):
    """ Fixture to mock model metadata """
    class ModelMetadata():
        """ Class to mock model meta object """

        def __init__(self):
            self.name = "some model name"
            self.shape = [0, 1, 2, 3]
            self.inputs = [1, 3]
            self.outputs = [output_metadata, 6]
            self.input = [5, 8]
    return ModelMetadata()


@pytest.fixture(name="tis_client")
def fixture_tis_client(mocker, model_dispatcher: list):
    """ Fixture to mock the object of the class TritonInferenceServerClient """
    mocker.patch("grpc.insecure_channel", return_value="some_channel")
    mocker.patch("tritonclient.grpc.service_pb2_grpc.GRPCInferenceServiceStub",
                 return_value=MagicMock())
    mocker.patch("tritonclient.grpc.service_pb2.ServerLiveRequest",
                 return_value="some request")
    mocker.patch("tritonclient.grpc.service_pb2.ServerReadyRequest",
                 return_value="some ready request")
    mocker.patch("tritonclient.grpc.service_pb2.ModelReadyRequest",
                 return_value="some model ready request")
    mocker.patch("tritonclient.grpc.service_pb2.ServerMetadataRequest",
                 return_value="some server metadata request")
    mocker.patch("tritonclient.grpc.service_pb2.ModelMetadataRequest",
                 return_value="some model metadata request")
    mocker.patch("tritonclient.grpc.service_pb2.ModelConfigRequest",
                 return_value="some model config request")
    mocker.patch.object(TritonInferenceServerClient,
                        "parse_model", return_value=model_dispatcher)
    mocker.patch.object(TritonInferenceServerClient,
                        "model_dtype_to_np", return_value="some datatype")
    return TritonInferenceServerClient()


def test_set_model_name(tis_client: TritonInferenceServerClient):
    """ Function to test TritonInferenceServerClient.setModelName() """

    # RUN
    tis_client.set_model_name("some model name")

    # VERIFY
    assert tis_client.model_name == "some model name"


def test_set_model_version(tis_client: TritonInferenceServerClient):
    """ Function to test TritonInferenceServerClient.set_model_version() """

    # RUN
    tis_client.set_model_version("some model version")

    # VERIFY
    assert tis_client.model_version == "some model version"


def test_get_model_name(tis_client: TritonInferenceServerClient):
    """ Function to test TritonInferenceServerClient.get_model_name() """

    # RUN
    tis_client.set_model_name("some new model name")

    # VERIFY
    assert tis_client.get_model_name() == "some new model name"


def test_get_model_version(tis_client: TritonInferenceServerClient):
    """ Function to test TritonInferenceServerClient.get_model_version() """

    # RUN
    tis_client.set_model_version("some new model version")

    assert tis_client.get_model_version() == "some new model version"


def test_parse_model(mocker, output_metadata, model_metadata, config_response, tis_client: TritonInferenceServerClient):
    """ Function to test TritonInferenceServerClient.parse_model() """

    # RUN
    input_name, output_name, channel, height, width, input_format, input_datatype = tis_client.parse_model(
        model_metadata, config_response
    )

    # VERIFY
    assert model_metadata.outputs[0] == output_metadata
    assert input_name == "some_input_name"
    assert output_name == "some_output_name"
    assert height == "some_height"
    assert channel == "some_channel"
    assert width == "some_width"
    assert input_format == "some_format"
    assert input_datatype == "some_datatype"
