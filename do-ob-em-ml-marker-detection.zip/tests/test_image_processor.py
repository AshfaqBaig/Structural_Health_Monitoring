# Author: Pranjall Kumar
# pylint: disable=protected-access

import numpy as np
import pytest
from app.processors.image_processor import ImageProcessor

@pytest.fixture(name="tile_fns")
def fixture_tile_fns():
    """ Fixture to mock tile_fns """
    return [
        "DEV_000F310380C4-20210819232413322392_0_0_800_800.jpg",
        "DEV_000F310380C4-20210819232413322392_1600_0_2400_800.jpg"
    ]

@pytest.fixture(name="responses")
def fixture_responses():
    """ Fixture to mock responses """
    return np.asarray(
        [
            [
                [20.0, 20.0, 20.0],
                [10.0, 10.0, 10.0]
            ],
            [
                [40.0, 40.0, 40.0],
                [30.0, 30.0, 30.0]
            ]
        ]
    )

@pytest.fixture(name="zoom")
def fixture_zoom():
    """ Fixture to mock zomm instructions """
    return {
        "x": 20,
        "y": 20,
        "rotate_img": True,
        "img_side_y": np.array(
            [
                5.0, 5.0, 5.0, 5.0
            ]
        ),
        "area_x": 10,
        "area_y": 10
    }

@pytest.fixture(name="image_processor_obj")
def fixture_image_processor_obj(tile_fns, responses, zoom):
    """ Fixture to return object of ImageProcessor class """
    return ImageProcessor(tile_fns, responses, zoom)

def test_stich_keypoints(
    tile_fns: list, responses: np.ndarray, zoom: dict, image_processor_obj: ImageProcessor
) -> None:
    """ Function to test ImageProcessor.stitch_keypoints() """
    image_processor_obj.tile_fns = tile_fns
    image_processor_obj.responses = responses
    image_processor_obj.zoom_instructions = zoom
    image_processor_obj.stitch_keypoints()

    assert all(image_processor_obj.responses[:, 0] == np.array([-35, -25, -55, -45]))
    assert all(image_processor_obj.responses[:, 1] == np.array([40, 30, 1660, 1650]))

def test_save_score_for_detected_image_if_conditions(mocker, image_processor_obj: ImageProcessor):
    """ Function to test ImageProcessor.save_score_for_detected_image() """
    mocked_putText = mocker.patch("cv2.putText")
    mocker.patch("os.path.join", return_value="/score.txt")
    mocked_savetxt = mocker.patch("numpy.savetxt")
    mocked_image_with_circle = np.zeros((6480, 4680))
    image_processor_obj._save_score_for_detected_image(
        [1000, 1000], [10, 10], 500, 500, mocked_image_with_circle
    )
    mocked_putText_call_args = mocked_putText.call_args.args
    mocked_savetxt_call_args = mocked_savetxt.call_args.args

    assert len(image_processor_obj.score_list) > 0
    assert mocked_putText.call_count == 1
    assert [all(row) for row in mocked_putText_call_args[0] == np.zeros((6480, 4680))]
    assert mocked_putText_call_args[1] == "10"
    assert mocked_putText_call_args[2] == (700, 800)
    assert mocked_putText_call_args[3] == 0
    assert mocked_putText_call_args[4] == 3
    assert mocked_savetxt.call_count == 1
    assert mocked_savetxt_call_args[0] == "/score.txt"
    assert mocked_putText_call_args[5] == (0, 255, 0)
    assert mocked_putText_call_args[6] == 2
    assert all(mocked_savetxt_call_args[1] == np.array([10, 10]))

def test_save_score_for_detected_image_else_conditions(mocker, image_processor_obj: ImageProcessor):
    """ Function to test ImageProcessor.save_score_for_detected_image() """
    mocked_putText = mocker.patch("cv2.putText")
    mocker.patch("os.path.join", return_value="/score.txt")
    mocked_savetxt = mocker.patch("numpy.savetxt")
    mocked_image_with_circle = np.zeros((6480, 4680))
    image_processor_obj._save_score_for_detected_image(
        [10, 10], [10, 10], 500, 500, mocked_image_with_circle
    )
    mocked_putText_call_args = mocked_putText.call_args.args
    mocked_savetxt_call_args = mocked_savetxt.call_args.args

    assert len(image_processor_obj.score_list) > 0
    assert mocked_putText.call_count == 1
    assert [all(row) for row in mocked_putText_call_args[0] == np.zeros((6480, 4680))]
    assert mocked_putText_call_args[1] == "10"
    assert mocked_putText_call_args[2] == (30, 210)
    assert mocked_putText_call_args[3] == 0
    assert mocked_putText_call_args[4] == 3
    assert mocked_putText_call_args[5] == (0, 255, 0)
    assert mocked_putText_call_args[6] == 2
    assert mocked_savetxt.call_count == 1
    assert mocked_savetxt_call_args[0] == "/score.txt"
    assert all(mocked_savetxt_call_args[1] == np.array([10, 10]))

def test_zoom_image_if_condition(mocker, zoom: dict, image_processor_obj: ImageProcessor):
    """ Function to test ImageProcessor._zoom_image() """
    mocked_rectangle = mocker.patch("cv2.rectangle")
    image_with_rectangle = image_processor_obj._zoom_image(np.zeros((6480, 4680)), zoom)
    mocked_rectangle_call_args = mocked_rectangle.call_args.args

    assert mocked_rectangle.call_count == 1
    assert [all(row) for row in mocked_rectangle_call_args[0] == np.zeros((6480, 4680))]
    assert all(mocked_rectangle_call_args[1][0] == [-15, -15, -15, -15])
    assert mocked_rectangle_call_args[1][1] == 20
    assert all(mocked_rectangle_call_args[2][0] == [-25, -25, -25, -25])
    assert mocked_rectangle_call_args[2][1] == 30
    assert image_with_rectangle is not None

def test_zoom_image_else_condition(mocker, zoom: dict, image_processor_obj: ImageProcessor):
    """ Function to test ImageProcessor._zoom_image() """
    zoom["rotate_img"] = False
    mocked_rectangle = mocker.patch("cv2.rectangle")
    image_with_rectangle = image_processor_obj._zoom_image(np.zeros((6480, 4680)), zoom)
    mocked_rectangle_call_args = mocked_rectangle.call_args.args

    assert mocked_rectangle.call_count == 1
    assert [all(row) for row in mocked_rectangle_call_args[0] == np.zeros((6480, 4680))]
    assert mocked_rectangle_call_args[1][0] == 20
    assert mocked_rectangle_call_args[1][1] == 20
    assert mocked_rectangle_call_args[2][0] == 30
    assert mocked_rectangle_call_args[2][1] == 30
    assert image_with_rectangle is not None

def test_calculate_single_inference_responce(mocker, zoom: dict, image_processor_obj: ImageProcessor):
    """ Function to test ImageProcessor.calculate_single_inference_responce() """
    mocker.patch.object(image_processor_obj, "_save_score_for_detected_image")
    mocker.patch.object(image_processor_obj, "_zoom_image", return_value=np.zeros((800, 800)))
    mocker.patch("os.makedirs")
    mocker.patch("cv2.imwrite")
    single_inference_response = image_processor_obj.calculate_single_inference_responce(
        "some-location", np.zeros((6480, 4680)), zoom
    )

    assert single_inference_response is not None
