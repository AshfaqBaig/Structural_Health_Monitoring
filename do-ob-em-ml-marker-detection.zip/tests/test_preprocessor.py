# Author: Pranjall Kumar
# pylint: disable=protected-access

import numpy as np
import pytest
from app.processors.preprocessor import RequestPreprocessor

@pytest.fixture(name="zoom")
def fixture_zoom():
    """ Fixture to mock zomm instructions """
    return {
        "x": 20,
        "y": 20,
        "rotate_img": True,
        "img_side_y": np.array(
            [
                5.0, 5.0, 5.0, 5.0
            ]
        ),
        "area_x": 10,
        "area_y": 10
    }

@pytest.fixture(name="pre_processor_obj")
def fixture_pre_processor_obj():
    """ Fixture to return object of ResponsePostprocessor class """
    return RequestPreprocessor()

@pytest.fixture(name="payload")
def fixture_payload():
    """ Fixture to return a mock payload """
    return {
        "location": "DEV_000F3103828D-20211103095916587397.jpg",
        "metadata": {
            "camera-id": "aal-b9701u2-cam023",
            "image-id": "img-192.168.8.46-1635933556.999758",
            "image-content-type": "image/jpg",
            "capture-timestamp": "2021-11-03 09:59:16.999767",
            "height": 4860,
            "width": 6480
        }
    }

def test_tile_image(pre_processor_obj: RequestPreprocessor):
    """ Function to test RequestPreprocessor.tile_image() """
    tiles = pre_processor_obj.tile_image(np.zeros((6480, 4680, 3)), "some-name")

    assert tiles is not None
    for key, value in tiles.items():
        assert "some-name" in key
        assert "400" in key
        assert value is not None

def test_run(mocker, zoom: dict, payload: dict, pre_processor_obj: RequestPreprocessor):
    """ Function to test RequestPreprocessor.run() """
    mocker.patch("os.path.join", return_value="some-path")
    mocker.patch("os.path.exists", return_value=True)
    mocker.patch("cv2.imread", return_value=np.zeros((6480, 4680)))
    mocker.patch.object(pre_processor_obj, "tile_image", return_value="tiles")
    tiles, image = pre_processor_obj.run(payload, zoom)

    assert tiles is not None
    assert image is not None
