# pylint: disable=missing-class-docstring, missing-function-docstring

import logging
import json
from unittest.mock import MagicMock
from app.settings_change_handler import SettingsChangeHandler

def test_on_settings_change(caplog):
    # GIVEN
    handler = SettingsChangeHandler()
    output_name = "magicOutput"
    key = f"/some-module/output/{output_name}"
    value = {
        "state": "value"
    }
    response = MagicMock(
        events=[MagicMock(key=key.encode(), value=json.dumps(value).encode())])

    # WHEN
    with caplog.at_level(logging.INFO):
        # WHEN handler.on_settings_change is called
        handler.on_settings_change(response)

    # THEN correct result is returned
    assert "Etcd message key:" in caplog.text

def test_on_settings_change_exception(caplog):
    # GIVEN
    handler = SettingsChangeHandler()
    output_name = "magicOutput"
    key = f"/some-module/output/{output_name}"

    response = MagicMock(
        events=[MagicMock(key=key.encode(), value="a")])

    # WHEN handler.on_settings_change is called
    handler.on_settings_change(response)

    # THEN an exception of type AttributeError is raised
    assert "AttributeError" in caplog.text
