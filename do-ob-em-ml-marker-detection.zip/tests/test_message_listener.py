# pylint: disable=missing-class-docstring, missing-function-docstring
from unittest.mock import AsyncMock
from azure.iot.device.aio import IoTHubModuleClient
import pytest
from app.inference.tis_client import TritonInferenceServerClient
from app.message_listener import MessageListener

@pytest.fixture(name="message_listener")
def message_listener_instance(mocker):
    '''Function to mock the constructor MessageListener'''
    mocker.patch.object(TritonInferenceServerClient,
                        "__init__", return_value=None)
    mocker.patch("app.processors.default.DefaultProcessor")
    mocker.patch("app.method_request_handler")
    mocker.patch("app.message_listener.TritonInferenceServerClient")
    mocker.patch("azure.iot.device.aio.IoTHubModuleClient.create_from_edge_environment",
                 return_value=IoTHubModuleClient)
    mocker.patch("asyncio.get_event_loop", return_value=AsyncMock())
    mocker.patch("asyncio.run")
    return MessageListener()

@pytest.mark.asyncio
async def test_run(mocker, message_listener):
    """ Function to test ModuleListener.run() """
    connect = mocker.patch.object(message_listener.module_client, "connect", new_callable=AsyncMock)
    disconnect = mocker.patch.object(message_listener.module_client, "disconnect", new_callable=AsyncMock)
    await message_listener.run()

    assert connect.call_count == 1
    assert disconnect.call_count == 1
