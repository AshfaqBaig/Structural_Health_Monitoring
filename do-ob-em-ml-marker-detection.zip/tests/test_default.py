# Author: Pranjall Kumar
# pylint: disable=protected-access
import json
from unittest.mock import MagicMock
import pytest
from azure.iot.device.iothub.models import Message
from app.processors.default import DefaultProcessor
from app.processors.preprocessor import RequestPreprocessor
from app.processors.postprocessor import ResponsePostprocessor
from app.marker_detection_status import MarkerDectionStatus
from app.processors.image_processor import ImageProcessor


@pytest.fixture(name="infer_client")
def fixture_infer_client():
    """ Fixture for creating an object for InferClient class """
    class InferClient():
        """ Class to mock infer_client """

        def __init__(self) -> None:
            self.infer_bool = False

        def infer_async(self, tiles: str) -> list:
            """ Funtion to mock infer method of infer_client"""
            return [self.infer_bool, tiles]
    return InferClient()


@pytest.fixture(name="default_processor_obj")
def fixture_default_processor_obj(mocker, infer_client):
    """ Fixture for creating an object of DefaultProcessor """
    mocker.patch.object(RequestPreprocessor, "run")
    mocker.patch.object(ResponsePostprocessor, "run")
    return DefaultProcessor(infer_client)


@pytest.fixture(name="metadata")
def fixture_metadata():
    """ Fixture for creating metadata """
    return {
        "regionId": "010_B97-00_METER_16.50_C03",
        "xyz_coordinates": [2526.5482, -1075.672, 16500.0],
        "image_counter": 5,
        "image_count": 3,
        "region_retry_counter": 0,
        "step_length": 0.5,
        "fov_start": 16.0,
        "fov_end": 21.0,
        "orientation": "longitudinal"
    }


@pytest.fixture(name="payload")
def fixture_payload(metadata):
    """ Fixture for creating payload """
    return {
        "images": [
            {
                "location": "DEV_000F3103828D-20211103095916587397.jpg",
                "metadata": {
                    "camera-id": "aal-b9701u2-cam023",
                    "image-id": "img-192.168.8.46-1635933556.999758",
                    "image-content-type": "image/jpg",
                    "capture-timestamp": "2021-11-03 09:59:16.999767",
                    "height": 4860,
                    "width": 6480
                }
            }
        ],
        "session": {
            "cameraId": "aal-b9701u2-cam023",
            "moduleId": "image-grabber-aal-b9701u2-cam011"
        },
        "metadata": metadata
    }


@pytest.fixture(name="image")
def fixture_image():
    """ Fixture for creating image dictionary """
    return {
        "location": "some-data"
    }


@pytest.fixture(name="zoom_instructions")
def fixture_zoom_instructions():
    """ Fixture for creating zoom instructions """
    return {}


def test_get_more_info(metadata: dict, default_processor_obj: DefaultProcessor) -> None:
    """ Function to test DefaultProcessor._get_more_info() """
    actual_list = default_processor_obj._get_more_info(metadata)
    expected_list = [0.5, 16.0, 21.0]

    assert actual_list == expected_list


def test_perform_zooming_if_condition1(
    metadata: dict, payload: dict, default_processor_obj: DefaultProcessor
) -> None:
    """ Function to test DefaultProcessor._perform_zooming() """
    default_processor_obj.cam_current = "aal-b9702u1-cam023"
    default_processor_obj._perform_zooming(metadata, payload)

    assert default_processor_obj.zoom_area_x == 1600
    assert default_processor_obj.zoom_area_y == 3200


def test_perform_zooming_else_condition1(
    metadata: dict, payload: dict, default_processor_obj: DefaultProcessor
) -> None:
    """ Function to test DefaultProcessor._perform_zooming() """
    default_processor_obj.cam_current = "aal-b9702u1-cam003"
    default_processor_obj._perform_zooming(metadata, payload)

    assert default_processor_obj.zoom_area_x == 2400
    assert default_processor_obj.zoom_area_y == 2400


def test_perform_zooming_if_condition2_if_condition(
    mocker, metadata: dict, payload: dict, default_processor_obj: DefaultProcessor
) -> None:
    """ Function to test DefaultProcessor._perform_zooming() """
    default_processor_obj.cam_current = "aal-b9702u1-cam003"
    mocked_get_more_info = mocker.patch(
        "app.processors.default.DefaultProcessor._get_more_info", return_value=[1.0, 8.0, 12.0]
    )
    default_processor_obj._perform_zooming(metadata, payload)

    assert mocked_get_more_info.call_count == 1
    assert default_processor_obj.img_side_x == 6480
    assert default_processor_obj.img_side_y == 4860
    assert default_processor_obj.rotate_img is False


def test_perform_zooming_if_condition2_else_condition(
    mocker, metadata: dict, payload: dict, default_processor_obj: DefaultProcessor
) -> None:
    """ Function to test DefaultProcessor._perform_zooming() """
    default_processor_obj.cam_current = "aal-b9702u1-cam003"
    metadata["orientation"] = "latitudinal"
    mocked_get_more_info = mocker.patch(
        "app.processors.default.DefaultProcessor._get_more_info", return_value=[1.0, 8.0, 12.0]
    )
    default_processor_obj._perform_zooming(metadata, payload)

    assert mocked_get_more_info.call_count == 1
    assert default_processor_obj.img_side_x == 4860
    assert default_processor_obj.img_side_y == 6480
    assert default_processor_obj.rotate_img is True


def test_perform_zooming_if_condition2(
    mocker, metadata: dict, payload: dict, default_processor_obj: DefaultProcessor
) -> None:
    """ Function to test DefaultProcessor._perform_zooming() """
    default_processor_obj.cam_current = "aal-b9702u1-cam003"
    metadata["orientation"] = "latitudinal"
    mocked_get_more_info = mocker.patch(
        "app.processors.default.DefaultProcessor._get_more_info", return_value=[1.0, 8.0, 12.0]
    )
    default_processor_obj._perform_zooming(metadata, payload)
    mocked_get_more_info_call_args = mocked_get_more_info.call_args.args

    assert mocked_get_more_info.call_count == 1
    assert mocked_get_more_info_call_args[0] == metadata
    assert default_processor_obj.zoom_cols is not None
    assert default_processor_obj.zoom_rows is not None


def test_process_image_if_condition1(
    mocker, infer_client, metadata: dict, payload: dict, image: dict,
    zoom_instructions: dict, default_processor_obj: DefaultProcessor
) -> None:
    """ Function to test DefaultProcessor._process_image() """
    mocked_run = mocker.patch.object(
        default_processor_obj.preprocessor, "run", return_value=["some-data", "some-data"]
    )
    mocked_infer_asyn = mocker.patch.object(
        default_processor_obj.infer_client, "infer_async", return_value=["some-data", "some-data"]
    )

    mocker.patch("app.processors.image_processor.ImageProcessor",
                 return_value=MagicMock())
    mocker.patch.object(
        ImageProcessor, "calculate_single_inference_responce", return_value=["some-data", "some-data", "some-data"]
    )
    mocker.patch.object(ResponsePostprocessor, "run", return_value=[
                        "some-data", "some-data", "some-data"])

    marker_detection_status, json_payload = default_processor_obj._process_image(
        metadata, payload, image, zoom_instructions
    )
    mocked_run_call_args = mocked_run.call_args.args

    assert mocked_run.call_count == 1
    assert mocked_run_call_args[0] == image
    assert mocked_run_call_args[1] == zoom_instructions
    assert marker_detection_status == "done"
    assert json_payload is not None


def test_process_image_if_condition2(
    mocker, infer_client, metadata: dict, payload: dict, image: dict,
    zoom_instructions: dict, default_processor_obj: DefaultProcessor
) -> None:
    """ Function to test DefaultProcessor._process_image() """
    infer_client.infer_bool = True
    mocked_preprocessor_run = mocker.patch.object(
        default_processor_obj.preprocessor, "run", return_value=["some-data", "some-data"]
    )
    default_processor_obj.infer_client = infer_client
    mocker.patch(
        "app.processors.image_processor.ImageProcessor.calculate_single_inference_responce",
        return_value="some-data")
    mocked_postprocessor_run = mocker.patch.object(
        default_processor_obj.postprocessor, "run",
        return_value=[False, {"some-key": "some-value"}, {"some-dataset"}]
    )
    default_processor_obj._process_image(
        metadata, payload, image, zoom_instructions)
    mocked_preprocessor_run_call_args = mocked_preprocessor_run.call_args.args
    mocked_postprocessor_run_call_args = mocked_postprocessor_run.call_args.args

    assert mocked_preprocessor_run.call_count == 1
    assert mocked_postprocessor_run.call_count == 1
    assert mocked_preprocessor_run_call_args[0] == image
    assert mocked_preprocessor_run_call_args[1] == zoom_instructions
    assert mocked_postprocessor_run_call_args[0] == "some-data"
    assert mocked_postprocessor_run_call_args[1] == metadata
    assert mocked_postprocessor_run_call_args[2] == {}
    assert mocked_postprocessor_run_call_args[3] == set()
    assert len(default_processor_obj.cams) > 0
    assert len(default_processor_obj.cams_past) > 0


def test_process_image_if_condition2_if_condition(
    mocker, infer_client, metadata: dict, payload: dict, image: dict,
    zoom_instructions: dict, default_processor_obj: DefaultProcessor
) -> None:
    """ Function to test DefaultProcessor._process_image() """
    infer_client.infer_bool = True
    mocked_preprocessor_run = mocker.patch.object(
        default_processor_obj.preprocessor, "run", return_value=["some-data", "some-data"]
    )
    default_processor_obj.infer_client = infer_client
    mocker.patch(
        "app.processors.image_processor.ImageProcessor.calculate_single_inference_responce",
        return_value="some-data"
    )
    mocked_postprocessor_run = mocker.patch.object(
        default_processor_obj.postprocessor, "run",
        return_value=[True, {"some-key": "some-value"}, {"some-dataset"}]
    )
    marker_detection_status, json_payload = default_processor_obj._process_image(
        metadata, payload, image, zoom_instructions
    )
    mocked_preprocessor_run_call_args = mocked_preprocessor_run.call_args.args
    mocked_postprocessor_run_call_args = mocked_postprocessor_run.call_args.args

    assert mocked_preprocessor_run.call_count == 1
    assert mocked_postprocessor_run.call_count == 1
    assert mocked_preprocessor_run_call_args[0] == image
    assert mocked_preprocessor_run_call_args[1] == zoom_instructions
    assert mocked_postprocessor_run_call_args[0] == "some-data"
    assert mocked_postprocessor_run_call_args[1] == metadata
    assert mocked_postprocessor_run_call_args[2] == {}
    assert mocked_postprocessor_run_call_args[3] == set()
    assert len(default_processor_obj.cams) > 0
    assert len(default_processor_obj.cams_past) > 0
    assert marker_detection_status == MarkerDectionStatus.IMAGE_DONE.value
    assert json_payload is True


def test_process_image_else_condition(
    mocker, infer_client, metadata: dict, payload: dict, image: dict,
    zoom_instructions: dict, default_processor_obj: DefaultProcessor
) -> None:
    """ Function to test DefaultProcessor._process_image() """
    metadata["image_counter"] = 3
    mocked_run = mocker.patch.object(
        default_processor_obj.preprocessor, "run", return_value=["some-data", "some-data"]
    )
    mocked_infer_asyn = mocker.patch.object(
        default_processor_obj.infer_client, "infer_async", return_value=["some-data", "some-data"]
    )

    mocker.patch("app.processors.image_processor.ImageProcessor",
                 return_value=MagicMock())
    mocker.patch.object(
        ImageProcessor, "calculate_single_inference_responce", return_value=["some-data", "some-data", "some-data"]
    )
    mocker.patch.object(ResponsePostprocessor, "run", return_value=[
                        "some-data", "some-data", "some-data"])

    default_processor_obj.infer_client = infer_client
    return_value = default_processor_obj._process_image(
        metadata, payload, image, zoom_instructions
    )
    mocked_run_call_args = mocked_run.call_args.args

    assert mocked_run.call_count == 1
    assert mocked_run_call_args[0] == image
    assert mocked_run_call_args[1] == zoom_instructions
    assert return_value is not None


def test_run_if_condition1(
    mocker, metadata: dict, payload: dict, default_processor_obj: DefaultProcessor
) -> None:
    """ Function to test DefaultProcessor.run() """
    mocked_process_image = mocker.patch.object(
        default_processor_obj, "_process_image", return_value=None)
    default_processor_obj.enable_zoom = False
    message = Message(data=json.dumps(payload))
    mocker.patch.object(message, "input_name", "input1")
    marker_detection_status, json_payload = default_processor_obj.run(message)
    mocked_process_image_call_args = mocked_process_image.call_args.args

    assert default_processor_obj.cams[payload["session"]["cameraId"]] == {
        "status": False, "regions": {}}
    assert default_processor_obj.zoom_cols is None
    assert default_processor_obj.zoom_rows is None
    assert len(default_processor_obj.cams_past) == 1
    assert default_processor_obj.cam_current == payload["session"]["cameraId"]
    assert mocked_process_image.call_count == 1
    assert mocked_process_image_call_args[0] == metadata
    assert mocked_process_image_call_args[1] == payload
    assert mocked_process_image_call_args[2] == payload["images"][0]
    assert mocked_process_image_call_args[3] is None
    assert marker_detection_status == MarkerDectionStatus.PAYLOAD_SUCCESS.value
    assert json_payload is not None


def test_run_if_condition2(mocker, payload: dict, default_processor_obj: DefaultProcessor):
    """ Function to test DefaultProcessor.run() """
    message = Message(data=json.dumps(payload))
    mocker.patch.object(message, "input_name", "input1")
    default_processor_obj.cams = {
        payload["session"]["cameraId"]: {
            "regions": {
                "010_B97-00_METER_16.50_C03": True
            }
        }
    }
    marker_detection_status, json_payload = default_processor_obj.run(message)

    assert marker_detection_status == MarkerDectionStatus.PAYLOAD_SUCCESS.value
    assert json_payload is not None


def test_run_if_condition3(mocker, payload: dict, default_processor_obj: DefaultProcessor):
    """ Function to test DefaultProcessor.run() """
    message = Message(data=json.dumps(payload))
    mocker.patch.object(message, "input_name", "input1")
    default_processor_obj.cams = {
        payload["session"]["cameraId"]: {
            "regions": {
                "010_B97-00_METER_16.50_C03": False
            }
        }
    }
    mocked_perform_zooming = mocker.patch.object(
        default_processor_obj, "_perform_zooming")
    mocked_process_image = mocker.patch.object(
        default_processor_obj, "_process_image", return_value=None)
    default_processor_obj.zoom_cols = {}
    default_processor_obj.zoom_cols["16.5"] = None
    default_processor_obj.zoom_rows = {}
    default_processor_obj.zoom_rows["C03"] = None
    marker_detection_status, json_payload = default_processor_obj.run(message)
    mocked_perform_zooming_call_args = mocked_perform_zooming.call_args.args

    assert mocked_perform_zooming.call_count == 1
    assert mocked_process_image.call_count == 1
    assert mocked_perform_zooming_call_args[0] == payload["metadata"]
    assert mocked_perform_zooming_call_args[1] == payload
    assert marker_detection_status == MarkerDectionStatus.PAYLOAD_SUCCESS.value
    assert json_payload is not None
