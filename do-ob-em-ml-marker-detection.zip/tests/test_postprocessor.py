# Author: Pranjall Kumar
# pylint: disable=protected-access

from unittest.mock import patch, mock_open
import numpy as np
import pytest
from app.processors.postprocessor import ResponsePostprocessor

@pytest.fixture(name="cams")
def fixture_cams():
    """ Fixture to return a dictionay of cams """
    return {
        "aal-b9702u1-cam001": {
            "status": None,
            "regions": {
                "010_B97-00_METER_00.00_C01": "some-value",
                "010_B97-00_METER_00.50_C02": "some-value",
                "010_B97-00_METER_01.00_C03": "some-value",
                "010_B97-00_METER_01.50_C04": "some-value",
                "010_B97-00_METER_02.00_C05": "some-value",
                "010_B97-00_METER_02.50_C06": "some-value",
                "010_B97-00_METER_03.00_C07": "some-value",
                "010_B97-00_METER_03.50_C08": "some-value",
                "010_B97-00_METER_04.00_C09": "some-value",
                "010_B97-00_METER_04.50_C10": "some-value",
                "010_B97-00_METER_05.00_C11": "some-value",
                "010_B97-00_METER_05.50_C12": "some-value",
                "010_B97-00_METER_06.00_C13": "some-value",
                "010_B97-00_METER_06.50_C14": "some-value",
                "010_B97-00_METER_07.00_C15": "some-value",
                "010_B97-00_METER_07.50_C16": "some-value",
                "010_B97-00_METER_08.00_C17": "some-value",
                "010_B97-00_METER_08.50_C18": "some-value",
                "010_B97-00_METER_09.00_C19": "some-value",
                "010_B97-00_METER_09.50_C20": "some-value",
                "010_B97-00_METER_10.00_C21": "some-value"
            }
        },
        "aal-b9702u1-cam002": {
            "status": None,
            "regions": {
                "010_B97-00_METER_10.00_C01": "some-value",
                "010_B97-00_METER_10.50_C02": "some-value",
                "010_B97-00_METER_11.00_C03": "some-value",
                "010_B97-00_METER_11.50_C04": "some-value",
                "010_B97-00_METER_12.00_C05": "some-value",
                "010_B97-00_METER_12.50_C06": "some-value",
                "010_B97-00_METER_13.00_C07": "some-value",
                "010_B97-00_METER_13.50_C08": "some-value",
                "010_B97-00_METER_14.00_C09": "some-value",
                "010_B97-00_METER_14.50_C10": "some-value",
                "010_B97-00_METER_15.00_C11": "some-value",
                "010_B97-00_METER_15.50_C12": "some-value",
                "010_B97-00_METER_16.00_C13": "some-value",
                "010_B97-00_METER_16.50_C14": "some-value",
                "010_B97-00_METER_17.00_C15": "some-value",
                "010_B97-00_METER_17.50_C16": "some-value",
                "010_B97-00_METER_18.00_C17": "some-value",
                "010_B97-00_METER_18.50_C18": "some-value",
                "010_B97-00_METER_19.00_C19": "some-value",
                "010_B97-00_METER_19.50_C20": "some-value",
                "010_B97-00_METER_20.00_C21": "some-value"
            }
        },
        "aal-b9702u1-cam003": {
            "status": None,
            "regions": {
                "010_B97-00_METER_20.00_C01": "some-value",
                "010_B97-00_METER_20.50_C02": "some-value",
                "010_B97-00_METER_21.00_C03": "some-value",
                "010_B97-00_METER_21.50_C04": "some-value",
                "010_B97-00_METER_22.00_C05": "some-value",
                "010_B97-00_METER_22.50_C06": "some-value",
                "010_B97-00_METER_23.00_C07": "some-value",
                "010_B97-00_METER_23.50_C08": "some-value",
                "010_B97-00_METER_24.00_C09": "some-value",
                "010_B97-00_METER_24.50_C10": "some-value",
                "010_B97-00_METER_25.00_C11": "some-value",
                "010_B97-00_METER_25.50_C12": "some-value",
                "010_B97-00_METER_26.00_C13": "some-value",
                "010_B97-00_METER_26.50_C14": "some-value",
                "010_B97-00_METER_27.00_C15": "some-value",
                "010_B97-00_METER_27.50_C16": "some-value",
                "010_B97-00_METER_28.00_C17": "some-value",
                "010_B97-00_METER_28.50_C18": "some-value",
                "010_B97-00_METER_29.00_C19": "some-value",
                "010_B97-00_METER_29.50_C20": "some-value",
                "010_B97-00_METER_30.00_C21": "some-value"
            }
        }
    }

@pytest.fixture(name="cams_past")
def fixture_cams_past():
    """ Fixture to return a list of past cams """
    return [
        "aal-b9702u1-cam001",
        "aal-b9702u1-cam002",
        "aal-b9702u1-cam003"
    ]

@pytest.fixture(name="post_processor_obj")
def fixture_post_processor_obj():
    """ Fixture to return object of ResponsePostprocessor class """
    return ResponsePostprocessor()

def test_update_cam_status(mocker, cams: dict, cams_past: list, post_processor_obj: ResponsePostprocessor):
    """ Function to test ResponsePostprocessor.update_cam_status() """
    mocker.patch("os.path.join", return_value="")
    mocker.patch("numpy.savetxt")
    with patch('builtins.open', mock_open()):
        actual_payload, actual_cams, actual_cams_past = post_processor_obj.update_cam_status(cams, cams_past)

    assert actual_payload is not None
    assert actual_payload[0]["session"] is not None
    assert actual_payload[0]["session"]["cameraId"] == "aal-b9702u1-cam001"
    assert actual_payload[0]["metadata"] is not None
    assert actual_payload[0]["metadata"]["detectedRegions"] is not None
    assert actual_payload[0]["crossCenters"] is not None
    assert actual_payload[0]["crossCenters"]["filename"] == "cross-centers-aal-b9702u1-cam001.txt"
    assert actual_cams == cams
    assert actual_cams_past == cams_past

def test_run(mocker, cams: dict , cams_past: dict, post_processor_obj: ResponsePostprocessor):
    """ Function to test ResponsePostprocessor.run() """
    mocked_update_cam_status = mocker.patch.object(post_processor_obj, "update_cam_status", return_value = [None, None, None])
    _, _, _ = post_processor_obj.run(
        np.array([10, 10]), {"xyz_coordinates": np.array([20, 20]), "regionId": "010_B97-00_METER_00.00_C01"},
        cams, cams_past, "aal-b9702u1-cam001"
    )

    assert mocked_update_cam_status.call_count == 1
    assert mocked_update_cam_status.call_args.args[0] == cams
    assert mocked_update_cam_status.call_args.args[1] == cams_past
