import json
from etcd3.watch import WatchResponse

from app.logging.logger import yield_logger
log = yield_logger()

class SettingsChangeHandler:
    """ Handle module settings change incoming from etcd """

    def on_settings_change(self, response: WatchResponse):
        """ Handle module settings change incoming from etcd """
        key: str = response.events[0].key.decode("utf-8")
        try:
            value: dict = json.loads(response.events[0].value.decode("utf-8"))
            log.info(f"Etcd message key: {key}, value: {value}")
        except (ValueError, AttributeError):
            log.exception("Failed to parse settings_change")
