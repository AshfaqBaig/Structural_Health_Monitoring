"""
Main entrypoint module
"""
import time
import asyncio
import json

from azure.iot.device.aio import IoTHubModuleClient
import app.routes_constant as routes
from app.logging import logger
from app.marker_detection_status import MarkerDectionStatus
from app.method_request_handler import MethodRequestHandler
from app.processors.default import DefaultProcessor
from app.inference.tis_client import TritonInferenceServerClient

log = logger.yield_logger()


class MessageListener:
    """
    AMQP Listener implementation. It accepts AMQP payloads and forwards them to request processor.
    Also module direct methods are supported.
    """

    def __init__(self):
        
        self.infer_client = TritonInferenceServerClient()
        self.default_processor = DefaultProcessor(self.infer_client)
        self.module_client = IoTHubModuleClient.create_from_edge_environment()
        self.method_request_handler = MethodRequestHandler(self.module_client)

    async def message_handler(self, input_message):
        """
        Default AMQP message handler
        """

        try:
            log.info("Message received on {input_message.input_name}")
            status, output_message = self.default_processor.run(input_message)  # call pipeline logic
            # pass data further to output
            log.debug(f"Status: {status}, {output_message}")
            if status == MarkerDectionStatus.IMAGE_RETRY.value:
                await self.module_client.send_message_to_output(
                    output_message, routes.ORCHESTRATOR_OUTPUT
                )
            elif status == MarkerDectionStatus.IMAGE_DONE.value:
                for msg in output_message:
                    await self.module_client.send_message_to_output(
                        json.dumps(msg), routes.CALIBRATION_OUTPUT
                    )
        except Exception as ex:
            # pass data further to error output
            log.exception(ex)
            await self.module_client.send_message_to_output(str(ex), routes.ERROR_OUTPUT)

    def empty_listener(self):
        """
        Empty listener to keep module always running
        """
        while True:
            time.sleep(600) # nosemgrep: python.lang.best-practice.sleep.arbitrary-sleep

    async def run(self):
        """
        Entrypoint main method
        """
        try:
            await self.module_client.connect()

            self.module_client.on_message_received = self.message_handler
            self.module_client.on_method_request_received = self.method_request_handler.run

            log.info("AMQP listener started")
            log.info("Log level for %s logger is: %s", log.name, log.getEffectiveLevel())

            # Run the empty listener in the event loop
            loop = asyncio.get_event_loop()
            user_finished = loop.run_in_executor(None, self.empty_listener)
            await user_finished

            # Finally, disconnect
            await self.module_client.disconnect()

        except Exception as ex:
            log.exception("Unexpected error %s ", ex)
            raise
