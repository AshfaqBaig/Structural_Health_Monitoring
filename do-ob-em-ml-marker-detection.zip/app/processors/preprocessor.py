""" Triton Inference Server request postprocessor module """
import os
import cv2
import app.config as cfg

from app.logging.logger import yield_logger
log = yield_logger()


class RequestPreprocessor:
    """ Inference server request preprocessor """

    def __init__(self) -> None:
        # Model input is BGR but this is RGB.
        self.rgb_mean = [0, 0, 0]

    def run(self, payload: dict, zoom: dict) -> list:
        """ Function to start pre processing """
        log.info("Processing image %s", payload)
        filename = payload["location"]
        log.info("Processing image %s", filename)
        full_path = os.path.join(cfg.INPUT_PATH, filename)
        if os.path.exists(full_path):
            try:
                # Read BGR image.
                img = cv2.imread(full_path, cv2.IMREAD_COLOR)
                image = img.copy()
                # Scale, normalize, and equalize.
                # image = image[..., [2, 1, 0]] - self.rgb_mean
                # image = image - self.rgb_mean
                # use zoom if enabled in default processor
                if zoom is not None:
                    # rotate image if it is in lateral orientation
                    if zoom["rotate_img"]:
                        image = cv2.rotate(
                            image, cv2.ROTATE_90_COUNTERCLOCKWISE)

                    # zoom into image region
                    image = image[zoom["y"]: zoom["y"] + zoom["area_y"],
                                  zoom["x"]: zoom["x"] + zoom["area_x"]]
                # Normalise the image
                image = image/225.0
                # Tile image for inference.
                image_name = filename.split(".")[0]
                tiles = self.tile_image(
                    image, image_name, step_size=800, window_size=(800, 800))
                log.debug("File %s read", f"{cfg.INPUT_PATH}{filename}")
            except Exception as ex:
                log.exception(ex)
                return
        else:
            log.error("File %s doesn't exist", full_path)
            return
        return [tiles, img]

    @staticmethod
    def tile_image(image, image_name, step_size=400, window_size=(400, 400)):
        """ Function to create a dictionary of files """
        tiles = {}
        #  slide a window across the image
        for y in range(0, image.shape[0], step_size):
            for x in range(0, image.shape[1], step_size):
                # yield the current window
                tile_name = [
                    str(i) for i in [image_name, x, y, window_size[0], window_size[1]]
                ]
                tile_name = "_".join(tile_name)
                tiles[tile_name] = image[y: y +
                                         window_size[1], x: x + window_size[0]].transpose(2, 0, 1)
        return tiles
