""" Image processing module """

import os
import cv2
import numpy as np
import app.config as cfg

from app.logging.logger import yield_logger
log = yield_logger()


class ImageProcessor:
    """ Class to process the images befor post processing """

    def __init__(self, tile_fns, responses, zoom: dict) -> None:
        self.tile_fns = tile_fns
        self.responses = responses
        self.zoom_instructions = zoom
        self.score_list = []

    def stitch_keypoints(self) -> None:
        """ Function to stich keypoints together """
        for tile_id, tile_name in enumerate(self.tile_fns):
            x_y_w_h = tile_name.split(".")[0]
            x = float(x_y_w_h.split("_")[2])
            y = float(x_y_w_h.split("_")[3])
            self.responses[tile_id][:, :2] += np.array([x, y])

        self.responses = np.vstack(self.responses)

        if self.zoom_instructions is not None:
            self.responses[:, :2] += np.array(
                [self.zoom_instructions["x"], self.zoom_instructions["y"]])
            if self.zoom_instructions["rotate_img"]:
                x = self.responses[:, 0].copy()
                y = self.responses[:, 1].copy()
                self.responses[:, 0] = self.zoom_instructions["img_side_y"] - y
                self.responses[:, 1] = x

    def _save_score_for_detected_image(
        self, single_inference_response: np.ndarray, inference_score: list,
        height: int, width: int, image_with_circle: np.ndarray
    ) -> None:
        """ Function to assign a confidence score on the detected cross in the image """
        font = cv2.FONT_HERSHEY_SIMPLEX
        score = inference_score[-1]
        self.score_list.append(score)
        if int(single_inference_response[1]) + 200 > height:
            y = int(single_inference_response[1]) - 200
        else:
            y = int(single_inference_response[1]) + 200
        if int(single_inference_response[0]) + 200 > width:
            x = int(single_inference_response[0]) - 300
        else:
            x = int(single_inference_response[0]) + 20
        cv2.putText(image_with_circle, str(round(score, 2)),
                    (x, y), font, 3, (0, 255, 0), 2, cv2.LINE_AA)
        score_path = os.path.join(cfg.OUTPUT_PATH, "score.txt")
        np.savetxt(score_path, np.array(self.score_list))

    def _zoom_image(self, image_with_circle, zoom_instructions: dict) -> np.ndarray:
        """ Function to zoom the image and rotate it if needed """
        if zoom_instructions["rotate_img"]:
            image_with_rectangle = cv2.rectangle(
                image_with_circle,
                (zoom_instructions["img_side_y"] -
                 zoom_instructions["y"], zoom_instructions["x"]),
                (zoom_instructions["img_side_y"] - zoom_instructions["y"] - zoom_instructions["area_y"],
                 zoom_instructions["x"] + zoom_instructions["area_x"]),
                color=(255, 0, 0), thickness=3
            )
        else:
            image_with_rectangle = cv2.rectangle(
                image_with_circle,
                (zoom_instructions["x"], zoom_instructions["y"]),
                (zoom_instructions["x"] + zoom_instructions["area_x"],
                 zoom_instructions["y"] + zoom_instructions["area_y"]),
                color=(255, 0, 0), thickness=3
            )
        return image_with_rectangle

    def calculate_single_inference_responce(self, image_location: str, image: np.ndarray, zoom_instructions: dict):
        """ Function to calculate single inference response """
        self.stitch_keypoints()
        inference_response = self.responses
        log.info("All detected keypoints:\n %s", inference_response)
        inference_score = inference_response[np.argmax(
            inference_response[..., -1])][:4].tolist()
        # if we want a single keypoint with max score
        single_inference_response = inference_response[np.argmax(
            inference_response[..., -1])][:2].tolist()
        log.info("Final keypoint:\n %s", single_inference_response)

        height, width = image.shape[:2]
        image_with_circle = cv2.circle(
            image, (int(single_inference_response[0]), int(
                single_inference_response[1])),
            100, color=(0, 0, 255), thickness=3
        )
        self._save_score_for_detected_image(
            single_inference_response, inference_score, height, width, image_with_circle
        )
        zoomed_image = self._zoom_image(image_with_circle, zoom_instructions)
        zoomed_image_path = f"{cfg.OUTPUT_PATH}/{image_location[:-4]}.jpg"
        os.makedirs(os.path.dirname(zoomed_image_path), exist_ok=True)
        log.info(f"Writing detections to: {zoomed_image_path}")
        cv2.imwrite(zoomed_image_path, zoomed_image)
        return single_inference_response
