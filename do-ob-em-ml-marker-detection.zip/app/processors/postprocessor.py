""" Triton Inference Server response preprocessor module """
import os
import json
import numpy as np
import app.config as cfg

from app.logging.logger import yield_logger
log = yield_logger()


class ResponsePostprocessor:
    """ Inference server response postprocessor """

    def update_cam_status(self, cams, cams_past) -> list:
        """ Function to update camera status """
        payload = []
        log.info(f"Cameras past: {cams_past}")
        for cam in cams_past:
            log.info(f"Camera: {cam}")
            conditions_met = [
                True for region in cams[cam]["regions"] if region]
            log.info(f"Condition met: {conditions_met}")
            log.info(f"Cams regions: {cams[cam]['regions']}")
            if sum(conditions_met) > 20:
                cams, cam_result_payload = self._calibrate_cam(cams, cam)
                payload.append(cam_result_payload)
        return [payload, cams, cams_past]

    def _calibrate_cam(self, cams, cam):
        log.info("Cam %s ready to calibrate.", cam)
        cams[cam]["status"] = True
        log.info(f"{list(cams[cam]['regions'].values())}")
        result = np.array(list(cams[cam]["regions"].values()))
        result_path = os.path.join(cfg.OUTPUT_PATH, f"cross-centers-{cam}.txt")
        np.savetxt(result_path, result)

        payload = {
            "session": {
                "cameraId": cam
            },
            "metadata": {
                "detectedRegions": list(cams[cam]["regions"].keys())
            },
            "crossCenters": {
                "filename": f"cross-centers-{cam}.txt"
            }
        }

        log.debug(f"Result file {result_path} saved", )
        payload_path = os.path.join(cfg.OUTPUT_PATH, "payload.json")
        with open(payload_path, 'w', encoding="utf-8") as file:
            json.dump(payload, file)
        return cams, payload

    def run(
        self, single_inference_response: np.ndarray, metadata: dict,
        cams: dict, cams_past: dict, cam_current: str
    ) -> list:
        """ Function to start post processing """
        # if we want multiple keypoints we need to use NMS based on OKS
        multiple_inference_response = metadata["xyz_coordinates"] + \
            single_inference_response
        cams[cam_current]["regions"][metadata["regionId"]
                                     ] = multiple_inference_response
        payload, cams, cams_past = self.update_cam_status(cams, cams_past)
        return [payload, cams, cams_past]
