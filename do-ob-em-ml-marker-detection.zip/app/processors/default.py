import json
import time
import numpy as np

from azure.iot.device.iothub.models.message import Message
from app.processors.image_processor import ImageProcessor
from app.processors.preprocessor import RequestPreprocessor
from app.processors.postprocessor import ResponsePostprocessor
from app.marker_detection_status import MarkerDectionStatus

from app.logging.logger import yield_logger
log = yield_logger()
class DefaultProcessor:
    """ Class to implement DefaultProcessor """
    def __init__(self, infer_client):
        self.infer_client = infer_client
        self.preprocessor = RequestPreprocessor()
        self.postprocessor = ResponsePostprocessor()
        self.cams = {}
        self.cams_past = set()
        self.cam_current = None
        self.enable_zoom = True
        self.zoom_area_x = 2400  # for test to cover larger area; change to 800 for normal use
        self.zoom_area_y = 2400
        self.zoom_cols = None
        self.zoom_rows = None
        self.img_side_x = None
        self.img_side_y = None
        self.rotate_img = None

    def _get_more_info(self, metadata: dict) -> list:
        """ Function to get more info """
        return [
            float(metadata["step_length"]),
            float(metadata["fov_start"]),
            float(metadata["fov_end"])
        ]

    def _perform_zooming(self, metadata: dict, payload: dict) -> None:
        """ Function to perform zooming """
        if int(self.cam_current.split('-')[-1][-3:]) > 22:
            log.info("Adjusting zoom area for camera %s", self.cam_current)
            self.zoom_area_x = 1600
            self.zoom_area_y = 3200
        if self.zoom_cols is None or self.zoom_rows is None:
            step_len, start_dst, end_dst = self._get_more_info(metadata)
            if metadata["orientation"] == "longitudinal":
                self.img_side_x = int(payload["images"][0]["metadata"]["width"])
                self.img_side_y = int(payload["images"][0]["metadata"]["height"])
                self.rotate_img = False
            else:
                self.img_side_x = int(payload["images"][0]["metadata"]["height"])
                self.img_side_y = int(payload["images"][0]["metadata"]["width"])
                self.rotate_img = True
            num_cols = int((end_dst - start_dst) / step_len + 1)
            step_pix = int(self.img_side_x / num_cols)
            positions = np.arange(0, self.img_side_x, step_pix)[:num_cols] - int(self.zoom_area_x / 2)
            positions = np.where(positions < 0, 0, positions)
            positions = np.where(positions < self.img_side_x - self.zoom_area_x, positions,
                                    self.img_side_x - self.zoom_area_x)
            self.zoom_cols = {str(i): p for i, p in
                                zip(np.arange(start_dst, end_dst + step_len, step_len), positions)}
            log.info("Zoom cols: %s", self.zoom_cols)

            self.zoom_rows = {}
            self.zoom_rows.update({'C' + str(i).zfill(2): 0 for i in range(1, 4)})
            self.zoom_rows.update(
                {'C' + str(i).zfill(2): int(self.img_side_y / 2 - self.zoom_area_y / 2) for i in range(4, 9)})
            self.zoom_rows.update(
                {'C' + str(i).zfill(2): int(self.img_side_y - self.zoom_area_y) for i in range(9, 12)})
            log.info(f"{self.zoom_rows}")

    def _process_image(self, metadata: dict, payload: dict, image: dict, zoom_instructions: dict) -> list:
        # preprocess AMQP message
        start = time.time() * 1000
        tiles, img = self.preprocessor.run(image, zoom_instructions)
        log.info("Number of tiles %s", len(tiles))
        prep_time = (time.time() * 1000) - start
        log.info(f"Prep time: {round(prep_time, 4)} ms")
        # inference
        start = time.time() * 1000
        responses, tile_fns = self.infer_client.infer_async(tiles)
        infer_time = (time.time() * 1000) - start
        log.info(f"Inference time: {round(infer_time, 4)} ms")
        # Retry if image count reached.
        if not tile_fns and metadata["image_counter"] == 5:
            log.info("Retrying for region: %s", metadata['regionId'])
            log.info("Payload retry: %s", payload)
            return [MarkerDectionStatus.IMAGE_RETRY.value, json.dumps(payload)]
        # postprocess inference result
        start = time.time() * 1000
        if tile_fns:
            image_processor = ImageProcessor(tile_fns, responses, zoom_instructions)
            single_inference_response = image_processor.calculate_single_inference_responce(
                image["location"], img, zoom_instructions
            )
            calibration_payload, self.cams, self.cams_past = self.postprocessor.run(
                single_inference_response, metadata, self.cams, self.cams_past, self.cam_current
            )
            if calibration_payload:
                log.info("Payload calibrate: %s", calibration_payload)
                return [MarkerDectionStatus.IMAGE_DONE.value, calibration_payload]
            post_time = (time.time() * 1000) - start
            log.info("Post time: %s ms", round(post_time, 4))
        else:
            return None

    def run(self, input_message: Message):
        """ Function to start Processing """
        start = time.time() * 1000
        payload = json.loads(input_message.data)
        log.info(input_message)
        # Track camera and region change.
        cam_current = payload["session"]["cameraId"]
        # Store if camera is new.
        if cam_current not in self.cams:
            self.cams[cam_current] = {"status": False, "regions": {}}
            self.zoom_cols = None
            self.zoom_rows = None
            self.cams_past.add(cam_current)
        self.cam_current = cam_current
        log.info("Detecting markers for cam: %s", self.cam_current)
        # Skip if marker for region already found.
        metadata = payload["metadata"]
        if metadata["regionId"] in self.cams[cam_current]["regions"] and \
            self.cams[cam_current]["regions"][metadata["regionId"]]:
            log.info("Payload already done: %s", payload)
            return [MarkerDectionStatus.PAYLOAD_SUCCESS.value, json.dumps(payload)]
        # Specifying distance and cross id dependent zoom area
        # assumption: crosses are spread uniformly over the image along the mould
        # i.e., there is at least one cross at the one image edge,
        # one in the middle and one at the other edge
        if self.enable_zoom:
            self._perform_zooming(metadata, payload)
            cross_id = metadata["regionId"].split("_")[-1]
            distance = str(float(metadata["regionId"].split("_")[-2]))
            log.info("Cross ID: %s", cross_id)
            zoom_instructions = {
                "x": self.zoom_cols[distance],
                "y": self.zoom_rows[cross_id],
                "area_x": self.zoom_area_x,
                "area_y": self.zoom_area_y,
                "rotate_img": self.rotate_img,
                "img_side_x": self.img_side_x,
                "img_side_y": self.img_side_y
            }
        else:
            zoom_instructions = None
        for image in payload["images"]:
            result = self._process_image(metadata, payload, image, zoom_instructions)
            if result is not None:
                return result
        log.debug("Message processed %s", payload['session'])
        total_time = (time.time() * 1000) - start
        log.info("Total time: %s ms", round(total_time, 4))
        return [MarkerDectionStatus.PAYLOAD_SUCCESS.value, json.dumps(payload)]
