from azure.iot.device import MethodResponse
import app.config as cfg
from app.logging.logger import update_log_level
from app.logging import logger

log = logger.yield_logger()

class MethodRequestHandler:
    """Main method request handler class"""

    def __init__(self, module_client):
        self.module_client = module_client

    async def run(self, request):
        """ Method request handler entrypoint """

        try:
            log.info(f'Method {request.name} invocation with: {request.payload}')
            if request.name == "set_log_level" and request.payload.get("value"):
                status = self._update_log_level(request.payload.get("value"))
            else:
                status = 400

            method_response = MethodResponse.create_from_method_request(request, status, request.payload)
            await self.module_client.send_method_response(method_response)

        except Exception:
            log.exception("Unexpected error while handling method request")
            raise

    def _update_log_level(self, log_level: str):
        """Update LOG_LEVEL"""
        if cfg.LOG_LEVEL != log_level:
            cfg.LOG_LEVEL = log_level
            update_log_level(log, cfg.LOG_LEVEL)
            return 200
        return 304
