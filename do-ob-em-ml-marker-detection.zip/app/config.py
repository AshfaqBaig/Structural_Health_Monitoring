"""Module defines all configuration options"""
import os
import logging

MODULE_APP_NAME = "marker-detection"

# env var
LOGGER_CONFIG = os.getenv("LOGGER_CONFIG", "logging-plain.ini")
TIS_URL = os.environ.get("TIS_URL", "tis:8007")
INPUT_PATH = os.environ.get("INPUT_PATH")
OUTPUT_PATH = os.environ.get("OUTPUT_PATH")
MODEL_PATH = os.environ.get("MODEL_PATH")
IOTEDGE_GATEWAYHOSTNAME = os.environ.get("IOTEDGE_GATEWAYHOSTNAME")

TIS_MODEL_NAME = os.environ.get("TIS_MODEL_NAME", "keypoint_rcnn_onnx")
TIS_MODEL_VERSION = os.environ.get("TIS_MODEL_VERSION", "1")

TIS_BATCH_SIZE = os.environ.get("TIS_BATCH_SIZE", 1)
TIS_THRESH = float(os.environ.get("TIS_THRESH", 0.8))
TIS_THRESH_KP = float(os.environ.get("TIS_THRESH_KP", 10))

LOG_LEVEL = os.environ.get("LOG_LEVEL", logging.INFO)
MODULE_SETTINGS_KEY = f"/devices/{IOTEDGE_GATEWAYHOSTNAME}/modules/{MODULE_APP_NAME}/settings"
ETCD_URL = os.getenv("ETCD_URL", "localhost:2379")
ETCD_TTL = int(os.getenv("ETCD_TTL", 600))