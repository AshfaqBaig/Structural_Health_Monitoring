"""
Main entrypoint module
"""
import asyncio
import app.config as cfg

from app.message_listener import MessageListener
from app.shared_storage import SharedStorage
from app.settings_change_handler import SettingsChangeHandler

from app.logging.logger import yield_logger, update_log_level
log = yield_logger()
update_log_level(log, cfg.LOG_LEVEL)

def subscribe_on_settings_change():
    settings_change_handler = SettingsChangeHandler()
    shared_storage = SharedStorage(cfg.ETCD_URL, cfg.ETCD_TTL)
    shared_storage.watch_key(cfg.MODULE_SETTINGS_KEY, settings_change_handler.on_settings_change)

if __name__ == "__main__":
    subscribe_on_settings_change()
    message_listener = MessageListener()
    asyncio.run(message_listener.run())
