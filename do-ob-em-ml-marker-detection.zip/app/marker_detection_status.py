from enum import Enum

class MarkerDectionStatus(Enum):
    """ Enum to store Marker Detection status """
    IMAGE_RETRY = "retry"
    IMAGE_DONE = "done"
    PAYLOAD_SUCCESS = "success"
