"""
Triton Inference Server client module which uses gRPC as a communication protocol
"""
import struct
import functools
import operator
import grpc
import tritonclient.grpc.model_config_pb2 as mc
from tritonclient.grpc import service_pb2, service_pb2_grpc
import numpy as np

import app.config as cfg

from app.logging.logger import yield_logger
log = yield_logger()

MAX_GRPC_MESSAGE_SIZE = 2**(struct.Struct('i').size * 8 - 1) - 1


class TritonInferenceServerClient:
    """Triton Inference Server client class"""

    def __init__(self):
        """
        Create and check connection. Also output some meta data about the connection and default model used
        """

        self.model_name = cfg.TIS_MODEL_NAME
        self.model_version = cfg.TIS_MODEL_VERSION
        self.batch_size = cfg.TIS_BATCH_SIZE

        channel_opt = [
            ('grpc.max_send_message_length', MAX_GRPC_MESSAGE_SIZE),
            ('grpc.max_receive_message_length', MAX_GRPC_MESSAGE_SIZE)
        ]

        # Create gRPC stub
        log.info(f"Connecting to {cfg.TIS_URL} inference server...")
        channel = grpc.insecure_channel(cfg.TIS_URL, options=channel_opt)
        self.grpc_stub = service_pb2_grpc.GRPCInferenceServiceStub(channel)

        # Healthcheck
        try:
            request = service_pb2.ServerLiveRequest()
            response = self.grpc_stub.ServerLive(request)
            log.info(f"TIS {response}")
        except Exception as ex:
            log.error(ex)

        request = service_pb2.ServerReadyRequest()
        response = self.grpc_stub.ServerReady(request)
        log.info(f"TIS {response}")

        request = service_pb2.ModelReadyRequest(
            name=self.model_name, version=self.model_version)
        response = self.grpc_stub.ModelReady(request)
        log.debug(f"TIS model {response}")

        # TIS metadata
        request = service_pb2.ServerMetadataRequest()
        response = self.grpc_stub.ServerMetadata(request)
        log.debug(f"TIS metadata {response}")

        # Model metadata
        request = service_pb2.ModelMetadataRequest(
            name=self.model_name, version=self.model_version)
        metadata_response = self.grpc_stub.ModelMetadata(request)
        log.debug(f"TIS model metadata:\n {metadata_response}")

        # Configuration
        request = service_pb2.ModelConfigRequest(
            name=self.model_name, version=self.model_version)
        config_response = self.grpc_stub.ModelConfig(request)
        log.debug(f"TIS model config:\n {config_response}")
        [
            self.input_name, self.output_name, self.channel,
            self.height, self.width, self.format, self.dtype
        ] = self.parse_model(metadata_response, config_response.config)
        self.npdtype = self.model_dtype_to_np(self.dtype)

    def set_model_name(self, model_name: str):
        """ Function to set model name """
        self.model_name = model_name

    def set_model_version(self, model_version: str):
        """ Function to set model version """
        self.model_version = model_version

    def get_model_name(self):
        """ Function to get model name """
        return self.model_name

    def get_model_version(self):
        """ Function to get model version """
        return self.model_version

    def _input_metadata_check(self, input_metadata, expected_input_dims, model_metadata) -> None:
        if len(input_metadata.shape) != expected_input_dims:
            raise ValueError(
                f"Expecting input to have {expected_input_dims} dimensions, \
                    model '{model_metadata.name}' input has {len(input_metadata.shape)}"
            )

    def parse_model(self, model_metadata, model_config):
        """ Function to parse the document """
        if len(model_metadata.inputs) != 1:
            raise Exception(
                f"Expecting 1 input, got {len(model_metadata.inputs)}"
            )
        if len(model_metadata.outputs) != 2:
            raise Exception(
                f"Expecting 1 output, got {len(model_metadata.outputs)}"
            )

        if len(model_config.input) != 1:
            raise Exception(
                f"Expecting 1 input in model configuration, got {len(model_config.input)}"
            )

        input_metadata = model_metadata.inputs[0]
        input_config = model_config.input[0]
        output_metadata_keyscore = model_metadata.outputs[0]
        output_metadata_keypoint = model_metadata.outputs[1]

        if output_metadata_keyscore.datatype != "FP32":
            raise Exception(
                "Expecting output datatype to be FP32, model '"
                + model_metadata.name
                + "' output type is "
                + output_metadata_keyscore.datatype
            )

        # Model input must have 3 dims, either CHW or HWC (not counting
        # the batch dimension), either CHW or HWC
        input_batch_dim = model_config.max_batch_size > 0
        expected_input_dims = 3 + (1 if input_batch_dim else 0)
        self._input_metadata_check(
            input_metadata, expected_input_dims, model_metadata)
            
        channel = input_metadata.shape[1 if input_batch_dim else 0]
        height = input_metadata.shape[2 if input_batch_dim else 1]
        width = input_metadata.shape[3 if input_batch_dim else 2]

        return (
            input_metadata.name, [
                output_metadata_keyscore.name, output_metadata_keypoint.name],
            channel, height, width,
            input_config.format, input_metadata.datatype,
        )

    @staticmethod
    def model_dtype_to_np(model_dtype):
        """ Function to return NumPy datatpye according to model datatype """
        if model_dtype == "BOOL":
            return np.bool
        elif model_dtype == "INT8":
            return np.int8
        elif model_dtype == "INT16":
            return np.int16
        elif model_dtype == "INT32":
            return np.int32
        elif model_dtype == "INT64":
            return np.int64
        elif model_dtype == "UINT8":
            return np.uint8
        elif model_dtype == "UINT16":
            return np.uint16
        elif model_dtype == "FP16":
            return np.float16
        elif model_dtype == "FP32":
            return np.float32
        elif model_dtype == "FP64":
            return np.float64
        elif model_dtype == "BYTES":
            return np.dtype(object)
        return None

    def request_generator(self, images, filenames, result_filenames):
        """ Function to generate request """
        request = service_pb2.ModelInferRequest()
        request.model_name = self.model_name
        request.model_version = self.model_version

        if len(self.output_name) > 1:
            for i in range(len(self.output_name)):
                output = service_pb2.ModelInferRequest().InferRequestedOutputTensor()
                output.name = self.output_name[i]
                request.outputs.extend([output])
        else:
            output = service_pb2.ModelInferRequest().InferRequestedOutputTensor()
            output.name = self.output_name[0]
            request.outputs.extend([output])

        infer_input = service_pb2.ModelInferRequest().InferInputTensor()
        infer_input.name = self.input_name
        infer_input.datatype = self.dtype
        infer_input.shape.extend([self.channel, self.height, self.width])
        image_idx = 0
        last_request = False

        while not last_request:
            log.debug(" last_request %s", last_request)
            input_bytes = None
            input_filenames = []
            request.ClearField("inputs")
            request.ClearField("raw_input_contents")
            for idx in range(self.batch_size):
                input_filenames.append(filenames[image_idx])
                if input_bytes is None:
                    input_bytes = images[image_idx].astype(
                        self.npdtype).tobytes()
                else:
                    input_bytes += images[image_idx].astype(
                        self.npdtype).tobytes()

                image_idx = (image_idx + 1) % len(images)
                log.debug(" image_idx %s", image_idx)
                if image_idx == 0:
                    last_request = True

            log.debug(" yielding request at %s", len(input_filenames))
            request.inputs.extend([infer_input])
            result_filenames.append(input_filenames)
            request.raw_input_contents.extend([input_bytes])
            yield request

    def _post_processing_model_predictions(self, res):
        # Bytes to numpy.
        tiles_keyscores = np.frombuffer(
            res.raw_output_contents[0], dtype=np.float32)
        tiles_keyscores = np.reshape(
            tiles_keyscores, (res.outputs[0].shape))

        tiles_keypoints = np.frombuffer(
            res.raw_output_contents[1], dtype=np.float32)
        tiles_keypoints = np.reshape(
            tiles_keypoints, (res.outputs[1].shape))
        tiles_keypoints = np.squeeze(tiles_keypoints, axis=1)

        return tiles_keyscores, tiles_keypoints

    def infer_async(self, input_request):
        """Main async inference method"""

        requests = []
        responses = []
        result_filenames = []
        im_fns = []

        for request in self.request_generator(
            list(input_request.values()),
            list(input_request.keys()),
            result_filenames,
        ):
            requests.append(self.grpc_stub.ModelInfer.future(request))

        result_filenames = functools.reduce(
            operator.iconcat, result_filenames, [])

        count = 0
        for request in requests:
            res = request.result()
            
            tiles_keyscores, tiles_keypoints = self._post_processing_model_predictions(
                res)

            kp_tokeep = np.argwhere(
                tiles_keyscores.flatten() > cfg.TIS_THRESH_KP).flatten()

            if tiles_keypoints[kp_tokeep].size > 0:
                im_fns.append(result_filenames[count])
                log.info(f"result_filenames  is : {im_fns}")
                responses.append(
                    np.hstack([tiles_keypoints[kp_tokeep], tiles_keyscores[kp_tokeep]]))
            count = count + 1
            log.debug(f"kp_tokeep shape : {kp_tokeep.shape}")

        return responses, im_fns
