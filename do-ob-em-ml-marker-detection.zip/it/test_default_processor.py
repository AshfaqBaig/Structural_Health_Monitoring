import asyncio
import unittest
from azure.iot.device.iothub.models.message import Message

from app.processors.default import DefaultProcessor
from app.inference.tis_client import TritonInferenceServerClient

import app.config as cfg

import logging


class DefaultProcessorTest(unittest.TestCase):
    def setUp(self):
        """Inference server test case configurion goes here"""

        cfg.INPUT_PATH = "samples/"
        cfg.OUTPUT_PATH = "samples/results"
        cfg.MODEL_PATH = "samples/models"
        cfg.TIS_URL = "localhost:8001"
        cfg.TIS_MODEL_NAME = "keypoint_rcnn_onnx"
        cfg.TIS_MODEL_VERSION = "1"
        cfg.TIS_BATCH_SIZE = 1
        cfg.LOG_LEVEL = logging.DEBUG

        tis_client = TritonInferenceServerClient()
        self.processor = DefaultProcessor(tis_client)

    def test_processor_success(self):
        # build sample message
        message = Message(
            open("./samples/DEV_000F31038263-20211011155946078156.json", "rb").read())
        logging.debug(type(message))

        # run preprocessor, processor, postprocessor
        result = self.processor.run(message)

        # check inference results
        self.assertTrue(result)

    def test_processor_success_lat(self):
        # build sample message
        message = Message(
            open("./samples/DEV_000F3103828D-20211103095916587397.json", "rb").read())
        logging.info(type(message))

        # run preprocessor, processor, postprocessor
        result = self.processor.run(message)

        # check inference results
        self.assertTrue(result)

    def test_processor_success_offline_calibration(self):
        CAMERA_ID = "aal-b9702u2-cam001"
        cfg.INPUT_PATH = "/mnt/data/offline-calibration/" + CAMERA_ID
        cfg.OUTPUT_PATH = "/mnt/data/offline-calibration/" + CAMERA_ID + "/detections"
        # build sample message
        with open(cfg.INPUT_PATH + "/images/json_list.txt", "r") as f:
            messages = [line.rstrip('\n') for line in f]

        for payload in messages:
            message = Message(open(payload, "rb").read())
            logging.info(type(message))

            # run preprocessor, processor, postprocessor
            result = self.processor.run(message)

            # check inference results
            self.assertTrue(result)


if __name__ == "__main__":
    unittest.main()
