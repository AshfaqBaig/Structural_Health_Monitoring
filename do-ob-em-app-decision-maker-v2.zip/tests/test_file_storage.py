# pylint: disable=protected-access, missing-module-docstring, missing-class-docstring, missing-function-docstring, duplicate-code, line-too-long, too-few-public-methods, no-self-use, too-many-locals, too-many-lines
import os
from unittest.mock import patch, call

import pytest

from app import file_storage
from app.models.edge_cameras import EdgeCameras
from app.models.feedback_positions import FeedbackPositions
from app.models.graph import Graph
from app.models.team_instructions import TeamInstructions


@patch("app.dm_helper.laser_feedback.cfg.MOULD_ID", "mould_id")
@patch("app.file_storage.cfg.DATA_PROVISIONING_PATH", os.sep)
class FileStorageTests:
    def test_get_static_graph_should_pass_correct_arguments_to_read_files_and_return_correct_result(self, mocker):
        # GIVEN
        team_instructions = TeamInstructions([{
            "version": "V1.0.0",
            "mouldId": "MOULD_ID",
            "bladeSn": "BLADE_SN",
            "bladeRevision": "BLADE_REVISION",
            "layerId": "layer_id",
            "palletId": "PALLET_ID"
        }])
        file_data = {
            "version": "v1.0.0",
            "mould_id": "mould_id",
            "blade_revision": "blade_revision",
            "plies": {}
        }
        load_json_from_file = mocker.patch("app.file_storage.load_json_from_file", return_value=file_data)
        mocker.patch("app.file_storage.isfile", return_value=True)

        # WHEN file_storage.get_static_graph is called
        result = file_storage.get_static_graph(team_instructions)

        # THEN load_json_from_file is called once with correct argument
        assert load_json_from_file.call_count == 1
        call_args = load_json_from_file.call_args.args
        expected_filepath = os.path.join(
            os.sep, "mould_id", "v1.0.0", "mould_id-blade_revision-layer_id-static-graph.json")
        assert call_args[0] == expected_filepath

        # AND correct result is returned
        assert result._stored_graph_data == file_data
        assert isinstance(result, Graph)

    def test_get_edge_cameras_should_pass_correct_filepath_argument_to_load_json_from_file(self, mocker):
        # GIVEN
        ground_truth_version = "v1.0.0"
        mould_id = "mould_id"
        blade_revision = "blade_revision"
        team_instructions = TeamInstructions([{
            "version": ground_truth_version,
            "mouldId": "mould_id",
            "bladeSn": "blade_sn",
            "bladeRevision": blade_revision,
            "layerId": "layer_id",
            "palletId": "pallet_id"
        }])
        file_data = {
            "version": ground_truth_version,
            "mould_id": mould_id,
            "blade_revision": blade_revision,
            "edges": {}
        }
        load_json_from_file = mocker.patch("app.file_storage.load_json_from_file", return_value=file_data)
        mocker.patch("app.file_storage.isfile", return_value=True)

        # WHEN file_storage.get_edge_cameras is called
        result = file_storage.get_edge_cameras(team_instructions)

        # THEN load_json_from_file us called once
        assert load_json_from_file.call_count == 1

        # AND load_json_from_file is called with one argument
        call_args = load_json_from_file.call_args.args
        assert len(call_args) == 1

        # AND filepath passed to load_json_from_file as an argument is correct
        expected_filepath = os.path.join(
            os.sep, "mould_id", "v1.0.0", 'mould_id-blade_revision-layer_id-edge-to-cameras.json')
        actual_filepath = call_args[0]
        assert actual_filepath == expected_filepath

        # AND correct result is returned
        assert result._edge_to_cameras == file_data
        assert isinstance(result, EdgeCameras)

    def test_get_static_graph_should_read_multiple_files_and_merged_their_data(self, mocker):
        # GIVEN
        team_instructions = TeamInstructions([
            {
                "version": "v1.0.0",
                "mouldId": "mould_id",
                "bladeSn": "blade_sn",
                "bladeRevision": "blade_revision",
                "layerId": "layer_1",
                "palletId": "pallet_id"
            },
            {
                "version": "v1.0.0",
                "mouldId": "mould_id",
                "bladeSn": "blade_sn",
                "bladeRevision": "blade_revision",
                "layerId": "layer_2",
                "palletId": "pallet_id"
            },
        ])
        file_data_1 = {
            "version": "v1.0.0",
            "mould_id": "mould_id",
            "blade_revision": "blade_revision",
            "plies": {
                "N1": {"layer_id": "layer_N", "edges": ["N1.1", "N1.2"]},
                "N2": {"layer_id": "layer_N", "edges": ["N2.1", "N2.2"]},
                "N3": {"layer_id": "layer_N", "edges": ["N3.1", "N3.2"]},
            }
        }
        file_data_2 = {
            "version": "v1.0.0",
            "mould_id": "mould_id",
            "blade_revision": "blade_revision",
            "plies": {
                "M1": {"layer_id": "layer_M", "edges": ["M1.1", "M1.2"]},
                "M2": {"layer_id": "layer_M", "edges": ["M2.1", "M2.2"]},
                "M3": {"layer_id": "layer_M", "edges": ["M3.1", "M3.2"]},
            }
        }
        values_to_return = [file_data_1, file_data_2]
        load_json_from_file = mocker.patch("app.file_storage.load_json_from_file", side_effect=values_to_return)
        mocker.patch("app.file_storage.isfile", return_value=True)

        # WHEN
        result = file_storage.get_static_graph(team_instructions)

        # THEN
        assert load_json_from_file.call_count == 2
        actual_calls = load_json_from_file.call_args_list
        expected_calls = [
            call(os.path.join(
                os.sep, "mould_id", "v1.0.0", "mould_id-blade_revision-layer_1-static-graph.json")),
            call(os.path.join(
                os.sep, "mould_id", "v1.0.0", "mould_id-blade_revision-layer_2-static-graph.json")),
        ]
        assert actual_calls == expected_calls

        # AND
        assert result._stored_graph_data == {
            "blade_revision": "blade_revision",
            "mould_id": "mould_id",
            "version": "v1.0.0",
            "plies": {
                "M1": {"edges": ["M1.1", "M1.2"], "layer_id": "layer_M"},
                "M2": {"edges": ["M2.1", "M2.2"], "layer_id": "layer_M"},
                "M3": {"edges": ["M3.1", "M3.2"], "layer_id": "layer_M"},
                "N1": {"edges": ["N1.1", "N1.2"], "layer_id": "layer_N"},
                "N2": {"edges": ["N2.1", "N2.2"], "layer_id": "layer_N"},
                "N3": {"edges": ["N3.1", "N3.2"], "layer_id": "layer_N"}
            }
        }
        assert isinstance(result, Graph)

    def test_get_feedback_positions_should_pass_correct_arguments_to_read_files_and_return_correct_result(self, mocker):
        # GIVEN
        ground_truth_version = "v1.0.0"
        mould_id = "mould_id"
        blade_revision = "blade_revision"
        team_instructions = TeamInstructions([{
            "version": ground_truth_version,
            "mouldId": "mould_id",
            "bladeSn": "blade_sn",
            "bladeRevision": blade_revision,
            "layerId": "layer_id",
            "palletId": "pallet_id"
        }])
        file_data = {
            "version": ground_truth_version,
            "mould_id": mould_id,
            "blade_revision": blade_revision,
            "plies": {}
        }
        load_json_from_file = mocker.patch("app.file_storage.load_json_from_file", return_value=file_data)
        mocker.patch("app.file_storage.isfile", return_value=True)

        # WHEN file_storage.get_feedback_positions is called
        result = file_storage.get_feedback_positions(team_instructions)

        # THEN load_json_from_file is called once with correct argument
        assert load_json_from_file.call_count == 1
        call_args = load_json_from_file.call_args.args
        expected_filepath = os.path.join(
            os.sep, "mould_id", "v1.0.0", 'mould_id-blade_revision-layer_id-feedback-positions.json')
        assert call_args[0] == expected_filepath

        # AND correct result is returned
        assert result._feedback_positions == file_data
        assert isinstance(result, FeedbackPositions)

    def test_read_files_should_pass_correct_filepath_argument_to_load_json_from_file(self, mocker):
        # GIVEN
        file_suffix = "file_suffix"
        ground_truth_version = "v1.0.0"
        mould_id = "mould_id"
        blade_revision = "blade_revision"
        team_instructions = TeamInstructions([{
            "version": ground_truth_version,
            "mouldId": "mould_id",
            "bladeSn": "blade_sn",
            "bladeRevision": blade_revision,
            "layerId": "layer_id",
            "palletId": "pallet_id"
        }])
        file_data = {
            "version": ground_truth_version,
            "mould_id": mould_id,
            "blade_revision": blade_revision,
            "plies": {}
        }
        load_json_from_file = mocker.patch("app.file_storage.load_json_from_file", return_value=file_data)
        mocker.patch("app.file_storage.isfile", return_value=True)

        # WHEN file_storage._read_file is called
        file_storage._read_files(file_suffix, team_instructions)

        # THEN load_json_from_file is called once with correct argument
        assert load_json_from_file.call_count == 1
        call_args = load_json_from_file.call_args.args
        assert call_args[0] == os.path.join(
            os.sep, "mould_id", "v1.0.0", "mould_id-blade_revision-layer_id-file_suffix.json")

    def test_read_files_should_read_multiple_files_and_return_merged_their_data(self, mocker):
        # GIVEN
        file_suffix = "file_suffix"
        ground_truth_version = "v1.0.0"
        mould_id = "mould_id"
        blade_revision = "blade_revision"
        team_instructions = TeamInstructions([
            {
                "version": ground_truth_version,
                "mouldId": mould_id,
                "bladeRevision": blade_revision,
                "layerId": "layer_1",
                "palletId": "pallet_1"
            },
            {
                "version": ground_truth_version,
                "mouldId": mould_id,
                "bladeRevision": blade_revision,
                "layerId": "layer_2",
                "palletId": "pallet_2"
            },
        ])
        file_data_1 = {
            "version": ground_truth_version,
            "mould_id": "mould_id",
            "blade_revision": blade_revision,
            "plies": {
                "N1": {"layer_id": "layer_N", "edges": ["N1.1", "N1.2"]},
                "N2": {"layer_id": "layer_N", "edges": ["N2.1", "N2.2"]},
                "N3": {"layer_id": "layer_N", "edges": ["N3.1", "N3.2"]},
            }
        }
        file_data_2 = {
            "version": ground_truth_version,
            "mould_id": mould_id,
            "blade_revision": blade_revision,
            "plies": {
                "M1": {"layer_id": "layer_M", "edges": ["M1.1", "M1.2"]},
                "M2": {"layer_id": "layer_M", "edges": ["M2.1", "M2.2"]},
                "M3": {"layer_id": "layer_M", "edges": ["M3.1", "M3.2"]},
            }
        }
        values_to_return = [file_data_1, file_data_2]
        load_json_from_file = mocker.patch("app.file_storage.load_json_from_file", side_effect=values_to_return)
        mocker.patch("app.file_storage.isfile", return_value=True)

        # WHEN
        result = file_storage._read_files(file_suffix, team_instructions)

        # THEN
        assert load_json_from_file.call_count == 2
        actual_calls = load_json_from_file.call_args_list
        expected_calls = [
            call(os.path.join(
                os.sep, "mould_id", "v1.0.0", "mould_id-blade_revision-layer_1-file_suffix.json")),
            call(os.path.join(
                os.sep, "mould_id", "v1.0.0", "mould_id-blade_revision-layer_2-file_suffix.json")),
        ]
        assert actual_calls == expected_calls

        # AND
        assert result == {
            "blade_revision": "blade_revision",
            "mould_id": "mould_id",
            "version": "v1.0.0",
            "plies": {
                "M1": {"edges": ["M1.1", "M1.2"], "layer_id": "layer_M"},
                "M2": {"edges": ["M2.1", "M2.2"], "layer_id": "layer_M"},
                "M3": {"edges": ["M3.1", "M3.2"], "layer_id": "layer_M"},
                "N1": {"edges": ["N1.1", "N1.2"], "layer_id": "layer_N"},
                "N2": {"edges": ["N2.1", "N2.2"], "layer_id": "layer_N"},
                "N3": {"edges": ["N3.1", "N3.2"], "layer_id": "layer_N"}
            }
        }

    @pytest.mark.parametrize(
        "file_mould_id, file_blade_revision",
        [
            ("other_mould_id", "blade_revision"),
            ("mould_id", "other_blade_revision"),
            ("other_mould_id", "other_blade_revision"),
        ]
    )
    def test_read_files_should_raise_exception_when_file_data_do_not_match_given_mould_and_blade_revisions(
            self, mocker, file_mould_id, file_blade_revision):
        # GIVEN
        file_suffix = "file_suffix"
        ground_truth_version = "v1.0.0"
        mould_id = "mould_id"
        blade_revision = "blade_revision"
        team_instructions = TeamInstructions([{
            "version": "v1.0.0",
            "mouldId": mould_id,
            "bladeSn": "blade_sn",
            "bladeRevision": blade_revision,
            "layerId": "layer_id",
            "palletId": "pallet_id"
        }])
        file_data = {
            "version": ground_truth_version,
            "mould_id": file_mould_id,
            "blade_revision": file_blade_revision,
            "plies": {}
        }
        mocker.patch("app.file_storage.load_json_from_file", return_value=file_data)
        mocker.patch("app.file_storage.isfile", return_value=True)

        # WHEN file_storage._read_file is called, assert that an exception is raised
        with pytest.raises(Exception) as exc_info:
            file_storage._read_files(file_suffix, team_instructions)

        # THEN an exception of correct type is raised
        assert exc_info.type is ValueError
        file_path = os.path.join(
            os.sep, "mould_id", "v1.0.0", "mould_id-blade_revision-layer_id-file_suffix.json")
        error_message = f"Data in file: {file_path}, do not match given mould_id: {mould_id} " \
                        f"and blade_revision: {blade_revision} from Team Instructions."
        assert exc_info.value.args[0] == error_message

    @pytest.mark.parametrize(
        "file_data",
        [
            {
                "no_mould_id": "no_mould_id",
                "no_blade_revision": "no_blade_revision",
                "plies": {}
            },
            {
                "mould_id": "mould_id",
                "no_blade_revision": "no_blade_revision",
                "plies": {}
            },
            {
                "no_mould_id": "no_mould_id",
                "blade_revision": "blade_revision",
                "plies": {}
            },
            {
                "no_mould_id": "no_mould_id",
                "no_blade_revision": "no_blade_revision",
                "plies": {}
            },
        ]
    )
    def test_read_files_should_raise_exception_when_file_data_do_not_have_mould_id_or_blade_revision_attributes(
            self, mocker, file_data):
        # GIVEN
        file_suffix = "file_suffix"
        ground_truth_version = "v1.0.0"
        blade_revision = "blade_revision"
        team_instructions = TeamInstructions([{
            "version": ground_truth_version,
            "mouldId": "mould_id",
            "bladeSn": "blade_sn",
            "bladeRevision": blade_revision,
            "layerId": "layer_id",
            "palletId": "pallet_id"
        }])
        mocker.patch("app.file_storage.load_json_from_file", return_value=file_data)
        mocker.patch("app.file_storage.isfile", return_value=True)

        # WHEN file_storage._read_file is called, assert that an exception is raised
        with pytest.raises(Exception) as exc_info:
            file_storage._read_files(file_suffix, team_instructions)

        # THEN an exception of correct type is raised
        assert exc_info.type is Exception
        assert "Missing mould_id or blade_revision attribute" in exc_info.value.args[0]

    def test_read_files_should_raise_exception_when_there_is_no_file_for_given_data(self, mocker):
        # GIVEN
        file_suffix = "file_suffix"
        ground_truth_version = "v1.0.0"
        blade_revision = "blade_revision"
        team_instructions = TeamInstructions([{
            "version": ground_truth_version,
            "mouldId": "mould_id",
            "bladeSn": "blade_sn",
            "bladeRevision": blade_revision,
            "layerId": "layer_id",
            "palletId": "pallet_id"
        }])
        mocker.patch("app.file_storage.isfile", return_value=False)

        # WHEN file_storage._read_file is called, assert that an exception is raised
        with pytest.raises(Exception) as exc_info:
            file_storage._read_files(file_suffix, team_instructions)

        # THEN an exception of correct type is raised
        assert exc_info.type is ValueError
        error_message = "Failed to load file_suffix for given mould_id: mould_id, " \
                        "blade_revision: blade_revision, ground_truth_version: v1.0.0 and layer_ids: " \
                        "{'layer_id'} taken from Team Instructions."
        assert exc_info.value.args[0] == error_message
