# pylint: disable= no-member, protected-access, missing-module-docstring, missing-class-docstring, missing-function-docstring, duplicate-code, line-too-long, too-few-public-methods, no-self-use, too-many-locals, too-many-lines
from unittest.mock import AsyncMock

import pytest

from app.message_listener import MessageListener
from app.models.state.mould_state import MouldState
from app.models.team_instructions import TeamInstructions


class MessageListenerTests:
    @pytest.mark.asyncio
    async def test_run_should_start_listening_for_input_messages_and_cloud_to_device_methods(self, mocker):
        # GIVEN
        input_message_handler = mocker.patch("app.message_listener.InputMessageHandler")
        cloud_to_device_method_handler = mocker.patch("app.message_listener.CloudToDeviceMethodHandler")
        mocker.patch("app.message_listener.IoTHubModuleClient")
        mocker.patch("app.message_listener.SharedStorage")
        mocker.patch("app.message_listener.ModuleInitializer.run", return_value=(TeamInstructions(), MouldState(set())))
        message_listener = MessageListener()

        # AND patched module client connect attribute
        module_client = message_listener._module_client
        mocker.patch.object(module_client, "connect", new_callable=AsyncMock)

        # short work around to gracefully close asyncio event loop
        message_listener._empty_listener = None

        # WHEN message_listener.run is called
        await message_listener.run()

        # THEN module_client.connect() was called and awaited once
        assert module_client.connect.call_count == 1
        assert module_client.connect.await_count == 1

        # AND input_message_handler called once with correct arguments
        assert input_message_handler.call_count == 1
        call_args = input_message_handler.call_args.args
        assert call_args[0] == message_listener._decision_maker
        assert call_args[1] == message_listener._messaging

        # AND cloud_to_device_method_handler called once with correct arguments
        assert cloud_to_device_method_handler.call_count == 1
        call_args = cloud_to_device_method_handler.call_args.args
        assert call_args[0] == message_listener._decision_maker
        assert call_args[1] == message_listener._messaging

        # AND module_client.on_message_received was assigned correct callback func
        assert module_client.on_message_received == input_message_handler().handle

        # AND module_client.on_method_request_received was assigned correct callback func
        assert module_client.on_method_request_received == cloud_to_device_method_handler().handle

    def test_message_listener__init__should_exit_system_when_subscribing_to_global_state_updates_fails(self, mocker):
        # GIVEN
        mocker.patch("app.message_listener.IoTHubModuleClient")
        mocker.patch("app.message_listener.SharedStorage")
        mocker.patch("app.message_listener.ModuleInitializer.run", return_value=(TeamInstructions(), MouldState(set())))
        message_listener = MessageListener()

        # AND patched module client connect attribute
        module_client = message_listener._module_client
        mocker.patch.object(module_client, "connect", new_callable=AsyncMock)

        # short work around to gracefully close asyncio event loop
        message_listener._empty_listener = None

        # AND raised exception when self._shared_storage.watch_mould_plies_updates is called
        ex_message = "exception mock"
        mocker.patch.object(
            message_listener._decision_maker._shared_storage,
            "watch_mould_plies_updates",
            side_effect=ValueError(ex_message)
        )

        # WHEN message_listener.run is called, assert that an exception is raised
        with pytest.raises(SystemExit) as exc_info:
            MessageListener()

        # THEN an exception of correct type is raised
        assert exc_info.type is SystemExit
        error_message = f"Failed to initialize Decision Maker module, due to: {ex_message}"
        assert exc_info.value.args[0] == error_message
