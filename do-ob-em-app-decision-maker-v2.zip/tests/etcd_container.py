import json

import etcd3
import requests
from etcd3 import Etcd3Client
from requests import Response
from requests.adapters import HTTPAdapter, Retry
from testcontainers.core.container import DockerContainer
from testcontainers.core.waiting_utils import wait_container_is_ready


class EtcdContainer(DockerContainer):
    def __init__(self, image="bitnami/etcd:3.5.2", port=2379):
        super(EtcdContainer, self).__init__(image)
        self.port_to_expose = port
        self.with_exposed_ports(self.port_to_expose)

    def _configure(self) -> None:
        self.with_env("ALLOW_NONE_AUTHENTICATION", "yes")

    @wait_container_is_ready()
    def _connect(self) -> None:
        self.get_client()

        url = f"http://{self.get_host_port()}/health"
        res = self._get_container_health_status_response(url)
        status = json.loads(res.content)
        if status["health"] == "false":
            raise Exception(f"Failed to confirm ETCD container status on url: {url}, reason: '{status['reason']}'")

    def _get_container_health_status_response(self, url: str) -> Response:
        retry_strategy = Retry(total=5, backoff_factor=1, status_forcelist=[429, 500, 502, 503, 504])
        adapter = HTTPAdapter(max_retries=retry_strategy)
        http = requests.Session()
        http.mount("http://", adapter)
        return http.get(url)

    def get_client(self, **kwargs) -> Etcd3Client:
        """ Returns an instance of an Etcd3Client. """
        exposed_port = self.get_exposed_port(self.port_to_expose)
        container_host_ip = self.get_container_host_ip()
        return etcd3.client(host=container_host_ip, port=exposed_port, **kwargs)

    def get_host_port(self):
        """ Returns container exposed host:port url (without http/https scheme, ex.: localhost:2379) """
        container_host_ip = self.get_container_host_ip()
        exposed_port = self.get_exposed_port(self.port_to_expose)
        return f"{container_host_ip}:{exposed_port}"

    def start(self) -> DockerContainer:
        self._configure()
        super().start()
        self._connect()
        return self
