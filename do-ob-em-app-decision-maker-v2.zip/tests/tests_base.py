# pylint: disable=protected-access, missing-module-docstring, missing-class-docstring, missing-function-docstring, duplicate-code, line-too-long, too-few-public-methods, no-self-use, too-many-locals, too-many-lines
from azure.iot.device import MethodRequest, MethodResponse

from app.dm_helper import graph_resolver
from app.models.edge_cameras import EdgeCameras
from app.models.graph import Graph
from app.models.state.edge_cam_state import EdgeCamState
from app.models.state.edge_cam_state_enum import EdgeCamStateEnum
from app.models.state.edge_state import EdgeState
from app.models.state.edge_state_enum import EdgeStateEnum
from app.models.state.mould_state import MouldState
from app.models.state.ply_state import PlyState
from app.models.state.ply_state_enum import PlyStateEnum


def recalculate_expected_plies(mould_state: MouldState, graph: Graph, edge_cameras: EdgeCameras) -> dict:
    plies_to_be_placed = find_plies_to_be_placed(graph, mould_state)
    mould_state.add_expected_plies(plies_to_be_placed, edge_cameras)
    return plies_to_be_placed


def find_plies_to_be_placed(graph: Graph, mould_state: MouldState) -> dict:
    placed_plies_on_mould = mould_state.get_placed_plies_on_mould()
    placed_plies = graph_resolver.plies_from(placed_plies_on_mould, graph)
    return graph.find_plies_to_be_placed(placed_plies)


def create_edge_verification_feedback(detected_edges=None, missing_edges=None) -> list[dict]:
    if detected_edges is None:
        detected_edges = set()
    if missing_edges is None:
        missing_edges = set()
    return [
        {
            "type": "detected-edges",
            "edges": list(detected_edges),
        },
        {
            "type": "missing-edges",
            "edges": list(missing_edges),
        }
    ]


def create_c2dm_response(status_code: int, payload: dict = None) -> MethodResponse:
    return MethodResponse(request_id="request_id", status=status_code, payload=payload)


def create_c2dm_request(command: str, params: dict, correlation_id: str = None) -> MethodRequest:
    if params is None:
        params = {}
    if correlation_id is None:
        correlation_id = "correlation_id"
    payload = {
        "correlationId": correlation_id,
        "params": params
    }
    return MethodRequest("request_id", command, payload)


def create_add_team_instruction_c2dm_request(team_instruction: dict) -> MethodRequest:
    if team_instruction is None:
        team_instruction = {}
    return create_c2dm_request(command="add_team_instruction", params=team_instruction)


def create_finalise_c2dm_request(mould_id: str = None) -> MethodRequest:
    if mould_id is None:
        mould_id = "mould_id"
    return create_c2dm_request(command="finalise", params={"mouldId": mould_id})


def create_force_ply_c2dm_request(ply_id: str, mould_id: str = None, correlation_id: str = None) -> MethodRequest:
    if correlation_id is None:
        correlation_id = "correlation_id"
    if mould_id is None:
        mould_id = "mould_id"
    params = {
        "mouldId": mould_id,
        "ply": ply_id
    }
    return create_c2dm_request(command="force_ply", params=params, correlation_id=correlation_id)


def create_undo_ply_c2dm_request(ply_id: str, mould_id: str = None, correlation_id: str = None) -> MethodRequest:
    if correlation_id is None:
        correlation_id = "correlation_id"
    if mould_id is None:
        mould_id = "mould_id"
    params = {
        "mouldId": mould_id,
        "ply": ply_id
    }
    return create_c2dm_request(command="undo_ply", params=params, correlation_id=correlation_id)


def create_undo_plies_to_c2dm_request(
        ply_id: str, mould_id: str = None, correlation_id: str = None) -> MethodRequest:
    if correlation_id is None:
        correlation_id = "correlation_id"
    if mould_id is None:
        mould_id = "mould_id"
    params = {
        "mouldId": mould_id,
        "ply": ply_id
    }
    return create_c2dm_request(command="undo_plies_to", params=params, correlation_id=correlation_id)


def create_undo_plies_to_dry_run_c2dm_request(
        ply_id: str, mould_id: str = None, correlation_id: str = None) -> MethodRequest:
    if correlation_id is None:
        correlation_id = "correlation_id"
    if mould_id is None:
        mould_id = "mould_id"
    params = {
        "mouldId": mould_id,
        "ply": ply_id
    }
    return create_c2dm_request(command="undo_plies_to_dry_run", params=params, correlation_id=correlation_id)


def create_recheck_ply_c2dm_request(ply_id: str, mould_id: str = None, correlation_id: str = None) -> MethodRequest:
    if correlation_id is None:
        correlation_id = "correlation_id"
    if mould_id is None:
        mould_id = "mould_id"
    params = {
        "mouldId": mould_id,
        "ply": ply_id
    }
    return create_c2dm_request(command="recheck_ply", params=params, correlation_id=correlation_id)


class StateCamsMock:
    @property
    def first_cam_expected(self):
        return EdgeCamState("cam1", EdgeCamStateEnum.NEVER_DETECTED)

    @property
    def first_cam_detected(self):
        return EdgeCamState("cam1", EdgeCamStateEnum.DETECTED)

    @property
    def first_cam_missing(self):
        return EdgeCamState("cam1", EdgeCamStateEnum.MISSING)

    @property
    def second_cam_expected(self):
        return EdgeCamState("cam2", EdgeCamStateEnum.NEVER_DETECTED)

    @property
    def second_cam_detected(self):
        return EdgeCamState("cam2", EdgeCamStateEnum.DETECTED)

    @property
    def second_cam_missing(self):
        return EdgeCamState("cam2", EdgeCamStateEnum.MISSING)

    @property
    def third_cam_expected(self):
        return EdgeCamState("cam3", EdgeCamStateEnum.NEVER_DETECTED)

    @property
    def third_cam_detected(self):
        return EdgeCamState("cam3", EdgeCamStateEnum.DETECTED)

    @property
    def third_cam_missing(self):
        return EdgeCamState("cam3", EdgeCamStateEnum.MISSING)


class StatePliesMock:
    @property
    def first_ply_expected(self):
        return PlyState(
            "P1",
            edges={
                EdgeState(
                    "P1.1",
                    cams={
                        EdgeCamState("cam1", EdgeCamStateEnum.NEVER_DETECTED),
                    },
                    state=EdgeStateEnum.MISSING
                ),
                EdgeState(
                    "P1.2",
                    cams={
                        EdgeCamState("cam1", EdgeCamStateEnum.NEVER_DETECTED),
                    },
                    state=EdgeStateEnum.MISSING
                ),
            },
            state=PlyStateEnum.EXPECTED,
            previous_state=None,
            updated_by="initial",
            source_device=None
        )

    @property
    def first_ply_phantom_expected(self):
        return PlyState(
            "P1",
            edges=set(),
            state=PlyStateEnum.EXPECTED,
            previous_state=None,
            updated_by="initial",
            source_device=None
        )

    @property
    def first_ply_phantom_forced(self):
        return PlyState(
            "P1",
            edges=set(),
            state=PlyStateEnum.FORCED,
            previous_state=PlyStateEnum.EXPECTED,
            updated_by="initial",
            source_device=None
        )

    @property
    def first_ply_placed(self):
        return PlyState(
            "P1",
            edges={
                EdgeState(
                    "P1.1",
                    cams={
                        EdgeCamState("cam1", EdgeCamStateEnum.DETECTED),
                    },
                    state=EdgeStateEnum.DETECTED
                ),
                EdgeState(
                    "P1.2",
                    cams={
                        EdgeCamState("cam1", EdgeCamStateEnum.DETECTED),
                    },
                    state=EdgeStateEnum.DETECTED
                ),
            },
            state=PlyStateEnum.PLACED,
            previous_state=PlyStateEnum.EXPECTED,
            updated_by="cam:cam1",
            source_device=None
        )

    @property
    def first_ply_partially_covered(self):
        return PlyState(
            "P1",
            edges={
                EdgeState(
                    "P1.1",
                    cams={
                        EdgeCamState("cam1", EdgeCamStateEnum.DETECTED),
                    },
                    state=EdgeStateEnum.DETECTED
                ),
                EdgeState(
                    "P1.2",
                    cams={
                        EdgeCamState("cam1", EdgeCamStateEnum.DETECTED),
                    },
                    state=EdgeStateEnum.COVERED
                ),
            },
            state=PlyStateEnum.PLACED,
            previous_state=PlyStateEnum.PLACED,
            updated_by="ply:P2",
            source_device=None
        )

    @property
    def first_ply_fully_covered(self):
        return PlyState(
            "P1",
            edges={
                EdgeState(
                    "P1.1",
                    cams={
                        EdgeCamState("cam1", EdgeCamStateEnum.DETECTED),
                    },
                    state=EdgeStateEnum.COVERED
                ),
                EdgeState(
                    "P1.2",
                    cams={
                        EdgeCamState("cam1", EdgeCamStateEnum.DETECTED),
                    },
                    state=EdgeStateEnum.COVERED
                ),
            },
            state=PlyStateEnum.COVERED,
            previous_state=PlyStateEnum.PLACED,
            updated_by="ply:P2",
            source_device=None
        )

    @property
    def first_ply_missing(self):
        return PlyState(
            "P1",
            edges={
                EdgeState(
                    "P1.1",
                    cams={
                        EdgeCamState("cam1", EdgeCamStateEnum.MISSING),
                    },
                    state=EdgeStateEnum.MISSING
                ),
                EdgeState(
                    "P1.2",
                    cams={
                        EdgeCamState("cam1", EdgeCamStateEnum.MISSING),
                    },
                    state=EdgeStateEnum.MISSING
                ),
            },
            state=PlyStateEnum.MISSING,
            previous_state=PlyStateEnum.PLACED,
            updated_by="cam:cam1",
            source_device=None
        )

    @property
    def first_ply_forced_expected(self):
        return PlyState(
            "P1",
            edges={
                EdgeState(
                    "P1.1",
                    cams={
                        EdgeCamState("cam1", EdgeCamStateEnum.NEVER_DETECTED),
                    },
                    state=EdgeStateEnum.FORCED
                ),
                EdgeState(
                    "P1.2",
                    cams={
                        EdgeCamState("cam1", EdgeCamStateEnum.NEVER_DETECTED),
                    },
                    state=EdgeStateEnum.FORCED
                ),
            },
            state=PlyStateEnum.FORCED,
            previous_state=PlyStateEnum.EXPECTED,
            updated_by="command:force_ply",
            source_device=None
        )

    @property
    def second_ply_expected(self):
        return PlyState(
            "P2",
            edges={
                EdgeState(
                    "P2.1",
                    cams={
                        EdgeCamState("cam1", EdgeCamStateEnum.NEVER_DETECTED),
                    },
                    state=EdgeStateEnum.MISSING
                ),
                EdgeState(
                    "P2.2",
                    cams={
                        EdgeCamState("cam1", EdgeCamStateEnum.NEVER_DETECTED),
                        EdgeCamState("cam2", EdgeCamStateEnum.NEVER_DETECTED),
                    },
                    state=EdgeStateEnum.MISSING
                ),
            },
            state=PlyStateEnum.EXPECTED,
            previous_state=None,
            updated_by="initial",
            source_device=None
        )

    @property
    def second_ply_phantom_expected(self):
        return PlyState(
            "P2",
            edges=set(),
            state=PlyStateEnum.EXPECTED,
            previous_state=None,
            updated_by="initial",
            source_device=None
        )

    @property
    def second_ply_forced_expected(self):
        return PlyState(
            "P2",
            edges={
                EdgeState(
                    "P2.1",
                    cams={
                        EdgeCamState("cam1", EdgeCamStateEnum.NEVER_DETECTED),
                    },
                    state=EdgeStateEnum.FORCED
                ),
                EdgeState(
                    "P2.2",
                    cams={
                        EdgeCamState("cam1", EdgeCamStateEnum.NEVER_DETECTED),
                        EdgeCamState("cam2", EdgeCamStateEnum.NEVER_DETECTED),
                    },
                    state=EdgeStateEnum.FORCED
                ),
            },
            state=PlyStateEnum.FORCED,
            previous_state=PlyStateEnum.EXPECTED,
            updated_by="command:force_ply",
            source_device=None
        )

    @property
    def second_ply_phantom_forced(self):
        return PlyState(
            "P2",
            edges=set(),
            state=PlyStateEnum.FORCED,
            previous_state=PlyStateEnum.EXPECTED,
            updated_by="command:force_ply",
            source_device=None
        )

    @property
    def second_ply_placed(self):
        return PlyState(
            "P2",
            edges={
                EdgeState(
                    "P2.1",
                    cams={
                        EdgeCamState("cam1", EdgeCamStateEnum.DETECTED),
                    },
                    state=EdgeStateEnum.DETECTED
                ),
                EdgeState(
                    "P2.2",
                    cams={
                        EdgeCamState("cam1", EdgeCamStateEnum.DETECTED),
                        EdgeCamState("cam2", EdgeCamStateEnum.NEVER_DETECTED),
                    },
                    state=EdgeStateEnum.DETECTED
                ),
            },
            state=PlyStateEnum.PLACED,
            previous_state=PlyStateEnum.EXPECTED,
            updated_by="cam:cam1",
            source_device=None
        )

    @property
    def second_ply_partially_detected(self):
        return PlyState(
            "P2",
            edges={
                EdgeState(
                    "P2.1",
                    cams={
                        EdgeCamState("cam1", EdgeCamStateEnum.DETECTED),
                    },
                    state=EdgeStateEnum.DETECTED
                ),
                EdgeState(
                    "P2.2",
                    cams={
                        EdgeCamState("cam1", EdgeCamStateEnum.NEVER_DETECTED),
                        EdgeCamState("cam2", EdgeCamStateEnum.NEVER_DETECTED),
                    },
                    state=EdgeStateEnum.MISSING
                ),
            },
            state=PlyStateEnum.EXPECTED,
            previous_state=PlyStateEnum.PLACED,
            updated_by="initial",
            source_device=None
        )

    @property
    def second_ply_forced_partially_detected(self):
        return PlyState(
            "P2",
            edges={
                EdgeState(
                    "P2.1",
                    cams={
                        EdgeCamState("cam1", EdgeCamStateEnum.DETECTED),
                    },
                    state=EdgeStateEnum.FORCED
                ),
                EdgeState(
                    "P2.2",
                    cams={
                        EdgeCamState("cam1", EdgeCamStateEnum.NEVER_DETECTED),
                        EdgeCamState("cam2", EdgeCamStateEnum.NEVER_DETECTED),
                    },
                    state=EdgeStateEnum.FORCED
                ),
            },
            state=PlyStateEnum.FORCED,
            previous_state=PlyStateEnum.EXPECTED,
            updated_by="command:force_ply",
            source_device=None
        )

    @property
    def second_ply_missing_on_partially_covered(self):
        return PlyState(
            "P2",
            edges={
                EdgeState(
                    "P2.1",
                    cams={
                        EdgeCamState("cam1", EdgeCamStateEnum.MISSING),
                    },
                    state=EdgeStateEnum.MISSING
                ),
                EdgeState(
                    "P2.2",
                    cams={
                        EdgeCamState("cam1", EdgeCamStateEnum.DETECTED),
                        EdgeCamState("cam2", EdgeCamStateEnum.NEVER_DETECTED),
                    },
                    state=EdgeStateEnum.COVERED
                ),
            },
            state=PlyStateEnum.MISSING,
            previous_state=PlyStateEnum.COVERED,
            updated_by="cam:cam1",
            source_device=None
        )

    @property
    def second_ply_missing(self):
        return PlyState(
            "P2",
            edges={
                EdgeState(
                    "P2.1",
                    cams={
                        EdgeCamState("cam1", EdgeCamStateEnum.MISSING),
                    },
                    state=EdgeStateEnum.MISSING
                ),
                EdgeState(
                    "P2.2",
                    cams={
                        EdgeCamState("cam1", EdgeCamStateEnum.MISSING),
                        EdgeCamState("cam2", EdgeCamStateEnum.NEVER_DETECTED),
                    },
                    state=EdgeStateEnum.MISSING
                ),
            },
            state=PlyStateEnum.MISSING,
            previous_state=PlyStateEnum.PLACED,
            updated_by="cam:cam1",
            source_device=None
        )

    @property
    def second_ply_missing_due_being_covered(self):
        return PlyState(
            "P2",
            edges={
                EdgeState(
                    "P2.1",
                    cams={
                        EdgeCamState("cam1", EdgeCamStateEnum.DETECTED),
                    },
                    state=EdgeStateEnum.DETECTED
                ),
                EdgeState(
                    "P2.2",
                    cams={
                        EdgeCamState("cam1", EdgeCamStateEnum.MISSING),
                        EdgeCamState("cam2", EdgeCamStateEnum.NEVER_DETECTED),
                    },
                    state=EdgeStateEnum.MISSING
                ),
            },
            state=PlyStateEnum.MISSING,
            previous_state=PlyStateEnum.COVERED,
            updated_by="cam:cam1",
            source_device=None
        )

    @property
    def second_ply_forced_missing(self):
        return PlyState(
            "P2",
            edges={
                EdgeState(
                    "P2.1",
                    cams={
                        EdgeCamState("cam1", EdgeCamStateEnum.MISSING),
                    },
                    state=EdgeStateEnum.FORCED
                ),
                EdgeState(
                    "P2.2",
                    cams={
                        EdgeCamState("cam1", EdgeCamStateEnum.DETECTED),
                        EdgeCamState("cam2", EdgeCamStateEnum.NEVER_DETECTED),
                    },
                    state=EdgeStateEnum.FORCED
                ),
            },
            state=PlyStateEnum.FORCED,
            previous_state=PlyStateEnum.MISSING,
            updated_by="command:force_ply",
            source_device=None
        )

    @property
    def second_ply_partially_covered(self):
        return PlyState(
            "P2",
            edges={
                EdgeState(
                    "P2.1",
                    cams={
                        EdgeCamState("cam1", EdgeCamStateEnum.DETECTED),
                    },
                    state=EdgeStateEnum.DETECTED
                ),
                EdgeState(
                    "P2.2",
                    cams={
                        EdgeCamState("cam1", EdgeCamStateEnum.DETECTED),
                        EdgeCamState("cam2", EdgeCamStateEnum.NEVER_DETECTED),
                    },
                    state=EdgeStateEnum.COVERED
                ),
            },
            state=PlyStateEnum.PLACED,
            previous_state=PlyStateEnum.PLACED,
            updated_by="ply:P3",
            source_device=None
        )

    @property
    def second_ply_fully_covered(self):
        return PlyState(
            "P2",
            edges={
                EdgeState(
                    "P2.1",
                    cams={
                        EdgeCamState("cam1", EdgeCamStateEnum.DETECTED),
                    },
                    state=EdgeStateEnum.COVERED
                ),
                EdgeState(
                    "P2.2",
                    cams={
                        EdgeCamState("cam1", EdgeCamStateEnum.DETECTED),
                        EdgeCamState("cam2", EdgeCamStateEnum.NEVER_DETECTED),
                    },
                    state=EdgeStateEnum.COVERED
                ),
            },
            state=PlyStateEnum.COVERED,
            previous_state=PlyStateEnum.PLACED,
            updated_by="ply:P3",
            source_device=None
        )

    @property
    def third_ply_expected(self):
        return PlyState(
            "P3",
            edges={
                EdgeState(
                    "P3.1",
                    cams={
                        EdgeCamState("cam2", EdgeCamStateEnum.NEVER_DETECTED),
                    },
                    state=EdgeStateEnum.MISSING
                ),
                EdgeState(
                    "P3.2",
                    cams={
                        EdgeCamState("cam2", EdgeCamStateEnum.NEVER_DETECTED),
                        EdgeCamState("cam3", EdgeCamStateEnum.NEVER_DETECTED),
                    },
                    state=EdgeStateEnum.MISSING
                ),
            },
            state=PlyStateEnum.EXPECTED,
            previous_state=None,
            updated_by="initial",
            source_device=None
        )

    @property
    def third_ply_phantom_forced(self):
        return PlyState(
            "P3",
            edges=set(),
            state=PlyStateEnum.FORCED,
            previous_state=PlyStateEnum.EXPECTED,
            updated_by="command:force_ply",
            source_device=None
        )

    @property
    def third_ply_placed(self):
        return PlyState(
            "P3",
            edges={
                EdgeState(
                    "P3.1",
                    cams={
                        EdgeCamState("cam2", EdgeCamStateEnum.DETECTED),
                    },
                    state=EdgeStateEnum.DETECTED
                ),
                EdgeState(
                    "P3.2",
                    cams={
                        EdgeCamState("cam2", EdgeCamStateEnum.DETECTED),
                        EdgeCamState("cam3", EdgeCamStateEnum.NEVER_DETECTED),
                    },
                    state=EdgeStateEnum.DETECTED
                ),
            },
            state=PlyStateEnum.PLACED,
            previous_state=PlyStateEnum.EXPECTED,
            updated_by="cam:cam2",
            source_device=None
        )

    @property
    def third_ply_missing(self):
        return PlyState(
            "P3",
            edges={
                EdgeState(
                    "P3.1",
                    cams={
                        EdgeCamState("cam2", EdgeCamStateEnum.MISSING),
                    },
                    state=EdgeStateEnum.DETECTED
                ),
                EdgeState(
                    "P3.2",
                    cams={
                        EdgeCamState("cam2", EdgeCamStateEnum.MISSING),
                        EdgeCamState("cam3", EdgeCamStateEnum.NEVER_DETECTED),
                    },
                    state=EdgeStateEnum.DETECTED
                ),
            },
            state=PlyStateEnum.MISSING,
            previous_state=PlyStateEnum.PLACED,
            updated_by="cam:cam2",
            source_device=None
        )

    @property
    def third_ply_forced_expected(self):
        return PlyState(
            "P3",
            edges={
                EdgeState(
                    "P3.1",
                    cams={
                        EdgeCamState("cam2", EdgeCamStateEnum.MISSING),
                    },
                    state=EdgeStateEnum.FORCED
                ),
                EdgeState(
                    "P3.2",
                    cams={
                        EdgeCamState("cam2", EdgeCamStateEnum.MISSING),
                        EdgeCamState("cam3", EdgeCamStateEnum.NEVER_DETECTED),
                    },
                    state=EdgeStateEnum.FORCED
                ),
            },
            state=PlyStateEnum.FORCED,
            previous_state=PlyStateEnum.EXPECTED,
            updated_by="command:force_ply",
            source_device=None
        )

    @property
    def third_ply_partially_covered(self):
        return PlyState(
            "P3",
            edges={
                EdgeState(
                    "P3.1",
                    cams={
                        EdgeCamState("cam2", EdgeCamStateEnum.DETECTED),
                    },
                    state=EdgeStateEnum.DETECTED
                ),
                EdgeState(
                    "P3.2",
                    cams={
                        EdgeCamState("cam2", EdgeCamStateEnum.DETECTED),
                        EdgeCamState("cam3", EdgeCamStateEnum.NEVER_DETECTED),
                    },
                    state=EdgeStateEnum.COVERED
                ),
            },
            state=PlyStateEnum.PLACED,
            previous_state=PlyStateEnum.PLACED,
            updated_by="cam:cam2",
            source_device=None
        )

    @property
    def third_ply_partially_covered_by_first_edge(self):
        return PlyState(
            "P3",
            edges={
                EdgeState(
                    "P3.1",
                    cams={
                        EdgeCamState("cam2", EdgeCamStateEnum.DETECTED),
                    },
                    state=EdgeStateEnum.COVERED
                ),
                EdgeState(
                    "P3.2",
                    cams={
                        EdgeCamState("cam2", EdgeCamStateEnum.DETECTED),
                        EdgeCamState("cam3", EdgeCamStateEnum.NEVER_DETECTED),
                    },
                    state=EdgeStateEnum.DETECTED
                ),
            },
            state=PlyStateEnum.PLACED,
            previous_state=PlyStateEnum.PLACED,
            updated_by="cam:cam2",
            source_device=None
        )

    @property
    def third_ply_fully_covered(self):
        return PlyState(
            "P3",
            edges={
                EdgeState(
                    "P3.1",
                    cams={
                        EdgeCamState("cam2", EdgeCamStateEnum.DETECTED),
                    },
                    state=EdgeStateEnum.COVERED
                ),
                EdgeState(
                    "P3.2",
                    cams={
                        EdgeCamState("cam2", EdgeCamStateEnum.DETECTED),
                        EdgeCamState("cam3", EdgeCamStateEnum.NEVER_DETECTED),
                    },
                    state=EdgeStateEnum.COVERED
                ),
            },
            state=PlyStateEnum.COVERED,
            previous_state=PlyStateEnum.PLACED,
            updated_by="cam:cam2",
            source_device=None
        )

    @property
    def fourth_ply_expected(self):
        return PlyState(
            "P4",
            edges={
                EdgeState(
                    "P4.1",
                    cams={
                        EdgeCamState("cam2", EdgeCamStateEnum.NEVER_DETECTED),
                    },
                    state=EdgeStateEnum.MISSING
                ),
                EdgeState(
                    "P4.2",
                    cams={
                        EdgeCamState("cam2", EdgeCamStateEnum.NEVER_DETECTED),
                    },
                    state=EdgeStateEnum.MISSING
                ),
            },
            state=PlyStateEnum.EXPECTED,
            previous_state=None,
            updated_by="initial",
            source_device=None
        )

    @property
    def fourth_ply_placed(self):
        return PlyState(
            "P4",
            edges={
                EdgeState(
                    "P4.1",
                    cams={
                        EdgeCamState("cam2", EdgeCamStateEnum.DETECTED),
                    },
                    state=EdgeStateEnum.DETECTED
                ),
                EdgeState(
                    "P4.2",
                    cams={
                        EdgeCamState("cam2", EdgeCamStateEnum.DETECTED),
                    },
                    state=EdgeStateEnum.DETECTED
                ),
            },
            state=PlyStateEnum.PLACED,
            previous_state=PlyStateEnum.EXPECTED,
            updated_by="cam:cam2",
            source_device=None
        )

    @property
    def fourth_ply_partially_covered(self):
        return PlyState(
            "P4",
            edges={
                EdgeState(
                    "P4.1",
                    cams={
                        EdgeCamState("cam2", EdgeCamStateEnum.DETECTED),
                    },
                    state=EdgeStateEnum.DETECTED
                ),
                EdgeState(
                    "P4.2",
                    cams={
                        EdgeCamState("cam2", EdgeCamStateEnum.DETECTED),
                    },
                    state=EdgeStateEnum.COVERED
                ),
            },
            state=PlyStateEnum.PLACED,
            previous_state=PlyStateEnum.EXPECTED,
            updated_by="cam:cam2",
            source_device=None
        )

    @property
    def fourth_ply_fully_covered(self):
        return PlyState(
            "P4",
            edges={
                EdgeState(
                    "P4.1",
                    cams={
                        EdgeCamState("cam2", EdgeCamStateEnum.DETECTED),
                    },
                    state=EdgeStateEnum.COVERED
                ),
                EdgeState(
                    "P4.2",
                    cams={
                        EdgeCamState("cam2", EdgeCamStateEnum.DETECTED),
                    },
                    state=EdgeStateEnum.COVERED
                ),
            },
            state=PlyStateEnum.COVERED,
            previous_state=PlyStateEnum.PLACED,
            updated_by="ply:P3",
            source_device=None
        )

    @property
    def fifth_ply_expected(self):
        return PlyState(
            "P5",
            edges={
                EdgeState(
                    "P5.1",
                    cams={
                        EdgeCamState("cam2", EdgeCamStateEnum.NEVER_DETECTED),
                    },
                    state=EdgeStateEnum.MISSING
                ),
                EdgeState(
                    "P5.2",
                    cams={
                        EdgeCamState("cam2", EdgeCamStateEnum.NEVER_DETECTED),
                    },
                    state=EdgeStateEnum.MISSING
                ),
            },
            state=PlyStateEnum.EXPECTED,
            previous_state=None,
            updated_by="initial",
            source_device=None
        )

    @property
    def fifth_ply_placed(self):
        return PlyState(
            "P5",
            edges={
                EdgeState(
                    "P5.1",
                    cams={
                        EdgeCamState("cam2", EdgeCamStateEnum.DETECTED),
                    },
                    state=EdgeStateEnum.DETECTED
                ),
                EdgeState(
                    "P5.2",
                    cams={
                        EdgeCamState("cam2", EdgeCamStateEnum.DETECTED),
                    },
                    state=EdgeStateEnum.DETECTED
                ),
            },
            state=PlyStateEnum.PLACED,
            previous_state=PlyStateEnum.EXPECTED,
            updated_by="cam:cam2",
            source_device=None
        )

    @property
    def fifth_ply_partially_covered(self):
        return PlyState(
            "P5",
            edges={
                EdgeState(
                    "P5.1",
                    cams={
                        EdgeCamState("cam2", EdgeCamStateEnum.DETECTED),
                    },
                    state=EdgeStateEnum.COVERED
                ),
                EdgeState(
                    "P5.2",
                    cams={
                        EdgeCamState("cam2", EdgeCamStateEnum.DETECTED),
                    },
                    state=EdgeStateEnum.DETECTED
                ),
            },
            state=PlyStateEnum.PLACED,
            previous_state=PlyStateEnum.EXPECTED,
            updated_by="cam:cam2",
            source_device=None
        )

    @property
    def sixth_ply_placed(self):
        return PlyState(
            "P6",
            edges={
                EdgeState(
                    "P6.1",
                    cams={
                        EdgeCamState("cam2", EdgeCamStateEnum.DETECTED),
                    },
                    state=EdgeStateEnum.DETECTED
                ),
                EdgeState(
                    "P6.2",
                    cams={
                        EdgeCamState("cam2", EdgeCamStateEnum.DETECTED),
                    },
                    state=EdgeStateEnum.DETECTED
                ),
            },
            state=PlyStateEnum.PLACED,
            previous_state=PlyStateEnum.EXPECTED,
            updated_by="cam:cam2",
            source_device=None
        )
