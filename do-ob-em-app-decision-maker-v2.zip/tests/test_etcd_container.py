# pylint: disable=protected-access, missing-module-docstring, missing-class-docstring, missing-function-docstring, duplicate-code, line-too-long, too-few-public-methods, no-self-use, too-many-locals, too-many-lines
from tests.etcd_container import EtcdContainer

def test_etcd_container_should_get_docker_image_and_run_it_then_store_and_retrieve_value_by_key():
    with EtcdContainer(image="bitnami/etcd:3.5.2") as etcd_container:
        # GIVEN
        etcd_client = etcd_container.get_client()
        key = "/example/key".encode("utf-8")
        value = "Hello World".encode("utf-8")

        etcd_container.get_docker_client()

        # WHEN key value pair stored into etcd
        etcd_client.put(key, value)

        # AND value retrieved by key
        result = etcd_client.get(key)

        # THEN correct result is returned
        result_value, metadata = result
        assert result_value == value
        assert metadata.key == key
