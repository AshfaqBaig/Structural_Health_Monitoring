# pylint: disable=protected-access, missing-module-docstring, missing-class-docstring, missing-function-docstring, duplicate-code, line-too-long, too-few-public-methods, no-self-use, too-many-locals, too-many-lines
from unittest.mock import call, patch

import pytest

from app.global_mould_state_enum import GlobalMouldState
from app.models.team_instructions import TeamInstructions
from app.module_initializer import ModuleInitializer


@patch("app.config.MOULD_ID", "mould_id")
class ModuleInitializerRunWhenGlobalMouldStateSetToFinaliseOrNoneOrUnknownTests:
    def test_should_return_initialised_empty_local_mould_state_when_global_state_finalised(
            self, mocker):
        # GIVEN
        shared_storage = mocker.patch("app.module_initializer.SharedStorage")
        mocker.patch.object(shared_storage, "get_mould_state", return_value=GlobalMouldState.FINALISED)
        module_initializer = ModuleInitializer(shared_storage)

        # WHEN
        result_team_instructions, result_mould_state = module_initializer.run()

        # THEN
        assert result_team_instructions.data == []
        assert result_mould_state.plies == set()

    def test_should_return_initialised_empty_local_mould_state_when_global_state_none(self, mocker):
        # GIVEN
        shared_storage = mocker.patch("app.module_initializer.SharedStorage")
        mocker.patch.object(shared_storage, "get_mould_state", return_value=GlobalMouldState.NONE)
        module_initializer = ModuleInitializer(shared_storage)

        # WHEN
        result_team_instructions, result_mould_state = module_initializer.run()

        # THEN
        assert result_team_instructions.data == []
        assert result_mould_state.plies == set()

    def test_should_raise_exception_when_unknown_global_mould_state_fetched(self, mocker):
        # GIVEN
        global_mould_state = "UNKNOWN"
        shared_storage = mocker.patch("app.module_initializer.SharedStorage")
        mocker.patch.object(shared_storage, "get_mould_state", return_value=global_mould_state)
        module_initializer = ModuleInitializer(shared_storage)

        # WHEN
        with pytest.raises(Exception) as exc_info:
            module_initializer.run()

        # THEN an exception of correct type is raised
        assert exc_info.type is ValueError
        error_message = f"Failed to get Global Mould State for mould_id: mould_id, due to: " \
                        f"Unrecognised global mould state type: {global_mould_state}"
        assert exc_info.value.args[0] == error_message


@patch("app.config.MOULD_ID", "mould_id")
class ModuleInitializerRunWhenGlobalMouldStateSetToProductionTests:
    def test_should_return_initialised_local_mould_state_and_instructions_when_both_exist_in_etcd(
            self, mocker, sample_instructions_data, sample_global_mould_state_instructions_data,
            sample_mould_state_plies, sample_global_mould_state_plies_data):
        # GIVEN
        shared_storage = mocker.patch("app.module_initializer.SharedStorage")
        mocker.patch.object(
            shared_storage, "get_mould_instructions", return_value=sample_global_mould_state_instructions_data)
        mocker.patch.object(shared_storage, "get_mould_plies", return_value=sample_global_mould_state_plies_data)
        mocker.patch.object(shared_storage, "get_mould_state", return_value=GlobalMouldState.PRODUCTION)
        module_initializer = ModuleInitializer(shared_storage)

        # WHEN
        result_team_instructions, result_mould_state = module_initializer.run()

        # THEN
        assert result_team_instructions.data == sample_instructions_data

        # AND
        result_plies = result_mould_state.plies
        assert len(result_plies) == len(sample_mould_state_plies)
        sample_mould_state_plies_ids = {sample_ply.id for sample_ply in sample_mould_state_plies}
        assert all(result_ply.id in sample_mould_state_plies_ids for result_ply in result_plies)

    def test_should_return_initialised_empty_local_mould_state_when_only_plies_exist_in_etcd(
            self, mocker, sample_global_mould_state_plies_data):
        # GIVEN
        shared_storage = mocker.patch("app.module_initializer.SharedStorage")
        mocker.patch.object(shared_storage, "get_mould_instructions", return_value={})
        mocker.patch.object(shared_storage, "get_mould_plies", return_value=sample_global_mould_state_plies_data)
        mocker.patch.object(shared_storage, "get_mould_state", return_value=GlobalMouldState.PRODUCTION)
        module_initializer = ModuleInitializer(shared_storage)

        # WHEN
        result_team_instructions, result_mould_state = module_initializer.run()

        # THEN
        assert result_team_instructions.data == []
        assert result_mould_state.plies == set()

    def test_should_raise_exception_when_fetching_data_from_shared_storage_fails(self, mocker):
        # GIVEN
        shared_storage = mocker.patch("app.module_initializer.SharedStorage")
        mocker.patch.object(shared_storage, "get_mould_state", return_value=GlobalMouldState.PRODUCTION)
        module_initializer = ModuleInitializer(shared_storage)

        # AND
        ex_message = "exception message"
        mocker.patch.object(shared_storage, "get_mould_instructions", side_effect=ValueError(ex_message))

        # WHEN
        with pytest.raises(Exception) as exc_info:
            module_initializer.run()

        # THEN an exception of correct type is raised
        assert exc_info.type is ValueError
        error_message = f"Failed to get Global Mould State for mould_id: mould_id, due to: {ex_message}"
        assert exc_info.value.args[0] == error_message


@patch("app.config.MOULD_ID", "mould_id")
class ModuleInitializerInitialiseMethodsTests:
    def test_should_initialise_local_mould_state_instructions_from_global_state_when_one_exist_in_etcd(
            self, mocker, sample_instructions_data, sample_global_mould_state_instructions_data):
        # GIVEN
        global_mould_state_data = sample_global_mould_state_instructions_data
        log = mocker.patch("app.module_initializer.log")
        shared_storage = mocker.patch("app.module_initializer.SharedStorage")
        module_initializer = ModuleInitializer(shared_storage)

        # WHEN
        module_initializer._initialise_local_mould_state_instructions(global_mould_state_data)

        # THEN
        assert log.info.call_count == 1
        log_calls = log.info.call_args_list
        assert log_calls == [
            call(f"Global Mould State Team Instructions fetched from ETCD store: {global_mould_state_data}")
        ]

        # AND
        result_team_instructions_data = module_initializer._team_instructions.data
        assert result_team_instructions_data == sample_instructions_data

    def test_should_initialise_empty_local_state_instructions_when_global_state_do_not_exist_in_etcd(self, mocker):
        # GIVEN
        global_mould_state_data = {}
        log = mocker.patch("app.module_initializer.log")
        shared_storage = mocker.patch("app.module_initializer.SharedStorage")
        module_initializer = ModuleInitializer(shared_storage)

        # WHEN
        module_initializer._initialise_local_mould_state_instructions(global_mould_state_data)

        # THEN
        assert log.info.call_count == 1
        log_calls = log.info.call_args_list
        assert log_calls == [
            call(f"Fetched empty Global Mould State Instructions from ETCD store: {global_mould_state_data}, "
                 f"initialising with empty Local Team Instructions."),
        ]

        # AND
        assert module_initializer._team_instructions.data == []

    def test_should_initialise_local_mould_state_plies_from_global_state_when_one_exist_in_etcd(
            self, mocker, sample_mould_state_plies, sample_global_mould_state_plies_data, sample_instructions_data):
        # GIVEN
        global_mould_state_data = sample_global_mould_state_plies_data
        log = mocker.patch("app.module_initializer.log")
        shared_storage = mocker.patch("app.module_initializer.SharedStorage")
        module_initializer = ModuleInitializer(shared_storage)

        # AND
        module_initializer._team_instructions = TeamInstructions(sample_instructions_data)

        # WHEN
        module_initializer._initialise_local_mould_state_plies(global_mould_state_data)

        # THEN
        assert log.info.call_count == 1
        log_calls = log.info.call_args_list
        assert log_calls == [
            call(f"Global Mould State Plies fetched from ETCD store: {global_mould_state_data}")
        ]

        # AND local mould state is correct
        result_plies = module_initializer._mould_state.plies
        assert len(result_plies) == len(sample_mould_state_plies)
        sample_mould_state_plies_ids = {sample_ply.id for sample_ply in sample_mould_state_plies}
        assert all(result_ply.id in sample_mould_state_plies_ids for result_ply in result_plies)

    def test_should_initialise_empty_local_state_plies_when_global_state_do_not_exist_in_etcd(
            self, mocker, sample_instructions_data):
        # GIVEN
        global_mould_state_data = {}
        log = mocker.patch("app.module_initializer.log")
        shared_storage = mocker.patch("app.module_initializer.SharedStorage")
        module_initializer = ModuleInitializer(shared_storage)

        # AND
        module_initializer._team_instructions = TeamInstructions(sample_instructions_data)

        # WHEN
        module_initializer._initialise_local_mould_state_plies(global_mould_state_data)

        # THEN
        assert log.info.call_count == 1
        log_calls = log.info.call_args_list
        assert log_calls == [
            call(f"Fetched empty Global Mould State Plies from ETCD store: {global_mould_state_data}, "
                 f"initialising with empty Local Mould State Plies."),
        ]

        # AND local mould state is correct
        assert module_initializer._mould_state.plies == set()
