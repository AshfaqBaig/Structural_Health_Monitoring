# pylint: disable=protected-access, missing-module-docstring, missing-class-docstring, missing-function-docstring, duplicate-code, line-too-long, too-few-public-methods, no-self-use, too-many-locals, too-many-lines
from app.models import graph_plies_extraction


def test_graph_plies_extraction_edges_should_return_correct_result():
    # GIVEN
    plies = {
        "N0": {"edges": []},
        "N1": {"edges": ["edge_1", "edge_2"]},
        "N2": {"edges": ["edge_3"]},
    }

    # WHEN graph_plies_extraction.edges is called
    result = graph_plies_extraction.edges(plies)

    # THEN result is correct
    assert result == {"edge_1", "edge_2", "edge_3"}


def test_edges_should_return_empty_set_when_empty_plies_given():
    # GIVEN
    plies = {}

    # WHEN graph_plies_extraction.edges is called
    result = graph_plies_extraction.edges(plies)

    # THEN result is correct
    assert result == set()


def test_graph_plies_extraction_layer_ids_should_return_multiple_layer_ids():
    # GIVEN
    plies = {
        "N0": {"layer_id": "layer_1"},
        "N1": {"layer_id": "layer_2"},
        "N2": {"layer_id": "layer_3"},
    }

    # WHEN
    result = graph_plies_extraction.layer_ids(plies)

    # THEN
    assert result == {"layer_1", "layer_2", "layer_3"}


def test_graph_plies_extraction_layer_ids_should_return_single_layer_id():
    # GIVEN
    plies = {
        "N0": {"layer_id": "layer_1"},
        "N1": {"layer_id": "layer_1"},
        "N2": {"layer_id": "layer_1"},
    }

    # WHEN
    result = graph_plies_extraction.layer_ids(plies)

    # THEN
    assert result == {"layer_1"}


def test_layer_ids_should_return_empty_set_when_empty_plies_given():
    # GIVEN
    plies = {}

    # WHEN
    result = graph_plies_extraction.layer_ids(plies)

    # THEN
    assert result == set()
