# pylint: disable=protected-access, missing-module-docstring, missing-class-docstring, missing-function-docstring, duplicate-code, line-too-long, too-few-public-methods, no-self-use, too-many-locals, too-many-lines
from _pytest.python_api import raises

from app.utils import load_json_from_file, flatten, dict_of_dicts_merge, merge_dicts_of_data_structures


def test_load_json_from_file_should_read_and_return_dict_from_file_when_file_is_readable(tmpdir):
    # GIVEN
    path = tmpdir.join("filename.json")
    file_content = '{"a":"A", "b": "B"}'
    path.write(file_content)

    # WHEN load_json_from_file is called
    result = load_json_from_file(path)

    # THEN result is correct
    assert result == dict({"a": "A", "b": "B"})


def test_load_json_from_file_should_return_raise_an_exception_when_file_is_empty(tmpdir):
    # GIVEN
    path = tmpdir.join("filename.json")
    file_content = ""
    path.write(file_content)

    # WHEN load_json_from_file is called, assert that an exception is raised
    exc_info = raises(
        Exception,
        load_json_from_file,
        path
    )

    # THEN an exception of ValueError is raised
    assert exc_info.type is ValueError
    assert exc_info.value.args[0] == f"Can't process empty file: {path}"


def test_load_json_from_file_should_return_raise_an_exception_when_file_does_not_exist():
    # GIVEN
    path = "no_file_given"

    # WHEN load_json_from_file is called, assert that an exception is raised
    exc_info = raises(
        Exception,
        load_json_from_file,
        path
    )

    # THEN an exception of AssertionError is raised
    assert exc_info.type is AssertionError
    assert exc_info.value.args[0] == f"File {path} doesn't exist or isn't readable"


def test_flatten_should_flatten_given_list_of_lists(tmpdir):
    # GIVEN
    list_of_lists = [["sublist"], ["other", "sublist"]]

    # WHEN flatten is called
    result = flatten(list_of_lists)

    # THEN result is correct
    assert result == ["sublist", "other", "sublist"]


def test_dict_of_dicts_merge_should_merge_two_dicts_of_dicts(tmpdir):
    # GIVEN
    dict_1 = {
        "inner_dict_1": {
            "inner_dict_1": {"key": "value", "list": ["a", "b"]},
            "inner_dict_2": {"key": "value", "list": ["a", "b"]},
            "inner_dict_3": {"key": "value", "list": ["a", "b"]},
        },
    }
    dict_2 = {
        "inner_dict_1": {
            "inner_dict_4": {"key": "value", "list": ["a", "b"]},
            "inner_dict_5": {"key": "value", "list": ["a", "b"]},
            "inner_dict_6": {"key": "value", "list": ["a", "b"]},
        },
        "inner_dict_2": {
            "inner_dict_1": {"key": "value", "list": ["a", "b"]},
            "inner_dict_2": {"key": "value", "list": ["a", "b"]},
            "inner_dict_3": {"key": "value", "list": ["a", "b"]},
        },
    }

    # WHEN
    result = dict_of_dicts_merge(dict_1, dict_2)

    # THEN
    assert result == {
        "inner_dict_1": {
            "inner_dict_1": {"key": "value", "list": ["a", "b"]},
            "inner_dict_2": {"key": "value", "list": ["a", "b"]},
            "inner_dict_3": {"key": "value", "list": ["a", "b"]},
            "inner_dict_4": {"key": "value", "list": ["a", "b"]},
            "inner_dict_5": {"key": "value", "list": ["a", "b"]},
            "inner_dict_6": {"key": "value", "list": ["a", "b"]}
        },
        "inner_dict_2": {
            "inner_dict_1": {"key": "value", "list": ["a", "b"]},
            "inner_dict_2": {"key": "value", "list": ["a", "b"]},
            "inner_dict_3": {"key": "value", "list": ["a", "b"]},
        }
    }


def test_merge_dicts_of_data_structures_should_merge_two_dicts_of_dicts_with_values_of_common_keys(tmpdir):
    # GIVEN
    dict_1 = {
        "key_1": "value",
        "inner_dict_1": {
            "inner_dict_1": {"key": "value", "list": ["a", "b"]},
            "inner_dict_2": {"key": "value", "list": ["a", "b"]},
            "inner_dict_3": {"key": "value", "list": ["a", "b"]},
        },
    }
    dict_2 = {
        "key_1": "value",
        "key_2": "value",
        "key_3": "value",
        "inner_dict_1": {
            "inner_dict_4": {"key": "value", "list": ["a", "b"]},
            "inner_dict_5": {"key": "value", "list": ["a", "b"]},
            "inner_dict_6": {"key": "value", "list": ["a", "b"]},
        },
        "inner_dict_2": {
            "inner_dict_1": {"key": "value", "list": ["a", "b"]},
            "inner_dict_2": {"key": "value", "list": ["a", "b"]},
            "inner_dict_3": {"key": "value", "list": ["a", "b"]},
        },
    }

    # WHEN
    result = merge_dicts_of_data_structures(dict_1, dict_2)

    # THEN
    assert result == {
        "key_1": "value",
        "key_2": "value",
        "key_3": "value",
        "inner_dict_1": {
            "inner_dict_1": {"key": "value", "list": ["a", "b"]},
            "inner_dict_2": {"key": "value", "list": ["a", "b"]},
            "inner_dict_3": {"key": "value", "list": ["a", "b"]},
            "inner_dict_4": {"key": "value", "list": ["a", "b"]},
            "inner_dict_5": {"key": "value", "list": ["a", "b"]},
            "inner_dict_6": {"key": "value", "list": ["a", "b"]}
        },
        "inner_dict_2": {
            "inner_dict_1": {"key": "value", "list": ["a", "b"]},
            "inner_dict_2": {"key": "value", "list": ["a", "b"]},
            "inner_dict_3": {"key": "value", "list": ["a", "b"]},
        }
    }
