# pylint: disable=protected-access, missing-module-docstring, missing-class-docstring, missing-function-docstring, duplicate-code, line-too-long, too-few-public-methods, no-self-use, too-many-locals, too-many-lines
import copy
from unittest.mock import patch, call

import pytest
from _pytest.python_api import raises

from app.dm_helper import graph_resolver
from app.models.graph import Graph
from app.models.state.mould_state import MouldState
from app.models.team_instructions import TeamInstructions
from tests.tests_base import StatePliesMock


class GeneralGraphTests:
    def test_graph_instatiation_should_raise_expection_when_no_plies_attribute_exist_in_given_graph(self):
        # GIVEN
        graph_data = {"NO_PLIES": "ATTRIBUTE"}

        # WHEN Graph(graph_data) is called, assert that an exception is raised
        exc_info = raises(
            Exception,
            Graph,
            graph_data
        )

        # THEN an exception of type ValueError is raised
        assert exc_info.type is ValueError
        error_message = f"Failed to map_edge_to_ply on graph creation, due to: " \
                        f"Missing attribute: 'plies', in stored graph data: {graph_data}"
        assert exc_info.value.args[0] == error_message

    def test_graph_instatiation_should_raise_expection_when_no_edges_attribute_exist_in_given_graph_ply(self):
        # GIVEN
        graph_data = {
            "plies": {
                "P1": {"NO_EDGES": ["ATTRIBUTE"]},
            }
        }

        # WHEN Graph(graph_data) is called, assert that an exception is raised
        exc_info = raises(
            Exception,
            Graph,
            graph_data
        )

        # THEN an exception of type ValueError is raised
        assert exc_info.type is ValueError
        error_message = f"Failed to map_edge_to_ply on graph creation, due to: " \
                        f"Missing attribute: 'edges', for given ply: P1"
        assert exc_info.value.args[0] == error_message


class CreateSubGraphTests:
    @pytest.mark.asyncio
    @patch("app.dm_helper.laser_feedback.cfg.MOULD_ID", "mould_id")
    async def test_create_sub_graph_should_create_sub_graph_for_given_team_instructions(self):
        # GIVEN
        team_instructions = TeamInstructions([
            {
                "version": "v1.0.0",
                "mouldId": "mould_id",
                "bladeRevision": "blade_revision",
                "layerId": "a",
                "palletId": "b"
            }
        ])
        mould_id, blade_revision = team_instructions.mould_id, team_instructions.blade_revision
        graph_data = {
            "mould_id": mould_id,
            "blade_revision": blade_revision,
            "plies": {
                "P1": {"layer_id": "a", "pallet_id": "a", "edges": ["P1.1", "P1.2"]},
                "P2": {"layer_id": "a", "pallet_id": "b", "edges": ["P2.1", "P2.2"]},
                "P3": {"layer_id": "b", "pallet_id": "b", "edges": ["P3.1", "P3.2"]}
            }
        }
        graph = Graph(graph_data)

        # WHEN graph.create_sub_graph is called
        result = graph.create_sub_graph(team_instructions)

        # THEN correct sub-graph was created and returned
        assert isinstance(result, Graph)
        expected_sub_graph_data = {
            "mould_id": mould_id,
            "blade_revision": blade_revision,
            "plies": {
                "P2": {"layer_id": "a", "pallet_id": "b", "edges": ["P2.1", "P2.2"]}
            }
        }
        assert result.data == expected_sub_graph_data

    @pytest.mark.asyncio
    @patch("app.dm_helper.laser_feedback.cfg.MOULD_ID", "mould_id")
    async def test_create_sub_graph_should_raise_exception_when_filtered_plies_empty_for_given_team_instructions(
            self, mocker):
        # GIVEN
        log = mocker.patch("app.models.graph.log")
        team_instructions = TeamInstructions([
            {
                "version": "v1.0.0",
                "mouldId": "mould_id",
                "bladeRevision": "blade_revision",
                "layerId": "c",
                "palletId": "d"
            }
        ])
        mould_id, blade_revision = team_instructions.mould_id, team_instructions.blade_revision
        graph_data = {
            "mould_id": mould_id,
            "blade_revision": blade_revision,
            "plies": {
                "P1": {"layer_id": "a", "pallet_id": "a", "edges": ["P1.1", "P1.2"]},
                "P2": {"layer_id": "a", "pallet_id": "b", "edges": ["P2.1", "P2.2"]},
                "P3": {"layer_id": "b", "pallet_id": "b", "edges": ["P3.1", "P3.2"]}
            }
        }
        graph = Graph(graph_data)

        # WHEN graph.create_sub_graph is called, assert that an exception is raised
        exc_info = raises(
            Exception,
            graph.create_sub_graph,
            team_instructions
        )

        # THEN an exception of type ValueError is raised
        assert exc_info.type is ValueError
        warning_message = f"Failed to create sub-graph, filtered plies are empty: {{}}\n" \
                          f"for given team instructions: {team_instructions.data}"
        assert exc_info.value.args[0] == warning_message

        # AND log.warning is called with correct argument
        assert log.warning.call_count == 1
        call_args = log.warning.call_args.args
        assert call_args[0] == warning_message


class EdgeToPlyTests:
    def test_graph_instatiation_should_store_empty_edge_to_ply_mapping_when_empty_plies_dict_given(self):
        # GIVEN
        graph_data = {
            "plies": {}
        }

        # WHEN Graph(graph_data) is called
        result = Graph(graph_data)

        # THEN correct result returned
        assert result._edge_to_ply == {}

    def test_map_edge_to_ply_should_map_edges_to_plies_for_given_graph_data(self):
        # GIVEN
        graph_data = {
            "plies": {
                "P1": {"edges": ["P1.1", "P1.2"]},
                "P2": {"edges": ["P2.1", "P2.2"]}
            }
        }

        # WHEN Graph._map_edge_to_ply is called
        graph = Graph(graph_data)

        # THEN correct result returned
        expected = {
            "P1.1": "P1",
            "P1.2": "P1",
            "P2.1": "P2",
            "P2.2": "P2"
        }
        assert graph._edge_to_ply == expected


class LayerToPalletsTests:
    def test_should_correctly_store_mapped_layer_to_pallets_in_graph_for_given_data(self):
        # GIVEN
        graph_data = {
            "plies": {
                "P1": {"edges": ["P1.1", "P1.2"], "layer_id": "layer_P", "pallet_id": "pallet_1"},
                "P2": {"edges": ["P2.1", "P2.2"], "layer_id": "layer_P", "pallet_id": "pallet_1"},
                "P3": {"edges": ["P3.1", "P3.2"], "layer_id": "layer_P", "pallet_id": "pallet_1"},
                "P4": {"edges": ["P4.1", "P4.2"], "layer_id": "layer_P", "pallet_id": "pallet_2"},
                "N1": {"edges": ["N1.1", "N1.2"], "layer_id": "layer_N", "pallet_id": "pallet_3"},
            }
        }
        graph = Graph(graph_data)

        # WHEN
        graph._map_and_cache_layer_to_pallets()

        # THEN
        expected = {
            "layer_P": {"pallet_1", "pallet_2"},
            "layer_N": {"pallet_3"},
        }
        assert graph._layer_to_pallets == expected

    def test_should_store_empty_layer_to_pallets_mapping_when_empty_plies_dict_given(self):
        # GIVEN
        graph_data = {
            "plies": {}
        }
        graph = Graph(graph_data)

        # WHEN
        graph._map_and_cache_layer_to_pallets()

        # THEN
        assert graph._layer_to_pallets == {}


class GetPalletsByLayerTests:
    def test_should_return_single_pallet_by_given_layer(self):
        # GIVEN
        graph_data = {
            "plies": {
                "P1": {"edges": ["P1.1", "P1.2"], "layer_id": "layer_P", "pallet_id": "pallet_1"},
                "P2": {"edges": ["P2.1", "P2.2"], "layer_id": "layer_P", "pallet_id": "pallet_1"},
                "P3": {"edges": ["P3.1", "P3.2"], "layer_id": "layer_P", "pallet_id": "pallet_1"},
                "P4": {"edges": ["P4.1", "P4.2"], "layer_id": "layer_P", "pallet_id": "pallet_2"},
                "N1": {"edges": ["N1.1", "N1.2"], "layer_id": "layer_N", "pallet_id": "pallet_3"},
            }
        }
        graph = Graph(graph_data)
        graph._map_and_cache_layer_to_pallets()

        # WHEN
        result = graph.get_pallets_by_layer("layer_N")

        # THEN
        assert result == {"pallet_3"}

    def test_should_return_multiple_pallets_by_given_layer(self):
        # GIVEN
        graph_data = {
            "plies": {
                "P1": {"edges": ["P1.1", "P1.2"], "layer_id": "layer_P", "pallet_id": "pallet_1"},
                "P2": {"edges": ["P2.1", "P2.2"], "layer_id": "layer_P", "pallet_id": "pallet_1"},
                "P3": {"edges": ["P3.1", "P3.2"], "layer_id": "layer_P", "pallet_id": "pallet_1"},
                "P4": {"edges": ["P4.1", "P4.2"], "layer_id": "layer_P", "pallet_id": "pallet_2"},
                "N1": {"edges": ["N1.1", "N1.2"], "layer_id": "layer_N", "pallet_id": "pallet_3"},
            }
        }
        graph = Graph(graph_data)
        graph._map_and_cache_layer_to_pallets()

        # WHEN
        result = graph.get_pallets_by_layer("layer_P")

        # THEN
        assert result == {"pallet_1", "pallet_2"}

    def test_should_raise_exception_when_layer_id_is_missing(self):
        # GIVEN
        graph_data = {
            "plies": {
                "P1": {"edges": ["P1.1", "P1.2"], "layer_id": "layer_P", "pallet_id": "pallet_1"},
                "P2": {"edges": ["P2.1", "P2.2"], "layer_id": "layer_P", "pallet_id": "pallet_1"},
                "P3": {"edges": ["P3.1", "P3.2"], "layer_id": "layer_P", "pallet_id": "pallet_1"},
            }
        }
        layer_id = "NON_EXISTING_LAYER_ID"
        graph = Graph(graph_data)
        graph._map_and_cache_layer_to_pallets()

        # WHEN graph.get_pallets_by_layer is called, assert that an exception is raised
        exc_info = raises(
            Exception,
            graph.get_pallets_by_layer,
            layer_id
        )

        # THEN an exception of type ValueError is raised
        assert exc_info.type is ValueError
        warning_message = f"Failed to get pallets by given layer_id: {layer_id}, in layer-to-pallets mapping."
        assert exc_info.value.args[0] == warning_message


class GetPliesByPalletAndLayerTests:
    def test_should_return_single_ply_by_given_pallet_and_layer(self):
        # GIVEN
        graph_data = {
            "plies": {
                "P1": {"edges": ["P1.1", "P1.2"], "layer_id": "layer_P", "pallet_id": "pallet_1"},
                "P2": {"edges": ["P2.1", "P2.2"], "layer_id": "layer_P", "pallet_id": "pallet_1"},
                "P3": {"edges": ["P3.1", "P3.2"], "layer_id": "layer_P", "pallet_id": "pallet_1"},
                "P4": {"edges": ["P4.1", "P4.2"], "layer_id": "layer_P", "pallet_id": "pallet_2"},
            }
        }
        graph = Graph(graph_data)

        # WHEN
        result = graph.get_plies_by_pallet_and_layer("pallet_2", "layer_P")

        # THEN
        assert result == {
            "P4": {"edges": ["P4.1", "P4.2"], "layer_id": "layer_P", "pallet_id": "pallet_2"}
        }

    def test_should_return_multiple_plies_by_given_pallet_and_layer(self):
        # GIVEN
        graph_data = {
            "plies": {
                "P1": {"edges": ["P1.1", "P1.2"], "layer_id": "layer_P", "pallet_id": "pallet_1"},
                "P2": {"edges": ["P2.1", "P2.2"], "layer_id": "layer_P", "pallet_id": "pallet_1"},
                "P3": {"edges": ["P3.1", "P3.2"], "layer_id": "layer_P", "pallet_id": "pallet_1"},
                "P4": {"edges": ["P4.1", "P4.2"], "layer_id": "layer_P", "pallet_id": "pallet_2"},
            }
        }
        graph = Graph(graph_data)

        # WHEN
        result = graph.get_plies_by_pallet_and_layer("pallet_1", "layer_P")

        # THEN
        assert result == {
            "P1": {"edges": ["P1.1", "P1.2"], "layer_id": "layer_P", "pallet_id": "pallet_1"},
            "P2": {"edges": ["P2.1", "P2.2"], "layer_id": "layer_P", "pallet_id": "pallet_1"},
            "P3": {"edges": ["P3.1", "P3.2"], "layer_id": "layer_P", "pallet_id": "pallet_1"}
        }

    def test_should_return_single_ply_by_given_pallet_and_layer_when_multiple_layers_exist(self):
        # GIVEN
        graph_data = {
            "plies": {
                "P1": {"edges": ["P1.1", "P1.2"], "layer_id": "layer_P", "pallet_id": "pallet_1"},
                "P2": {"edges": ["P2.1", "P2.2"], "layer_id": "layer_P", "pallet_id": "pallet_1"},
                "N3": {"edges": ["N3.1", "N3.2"], "layer_id": "layer_N", "pallet_id": "pallet_1"},
                "N4": {"edges": ["N4.1", "N4.2"], "layer_id": "layer_N", "pallet_id": "pallet_2"},
            }
        }
        graph = Graph(graph_data)

        # WHEN
        result = graph.get_plies_by_pallet_and_layer("pallet_1", "layer_N")

        # THEN
        assert result == {
            "N3": {"edges": ["N3.1", "N3.2"], "layer_id": "layer_N", "pallet_id": "pallet_1"},
        }

    def test_should_return_multiple_plies_by_given_pallet_and_layer_when_multiple_layers_exist(self):
        # GIVEN
        graph_data = {
            "plies": {
                "P1": {"edges": ["P1.1", "P1.2"], "layer_id": "layer_P", "pallet_id": "pallet_1"},
                "P2": {"edges": ["P2.1", "P2.2"], "layer_id": "layer_P", "pallet_id": "pallet_1"},
                "N3": {"edges": ["N3.1", "N3.2"], "layer_id": "layer_N", "pallet_id": "pallet_1"},
                "N4": {"edges": ["N4.1", "N4.2"], "layer_id": "layer_N", "pallet_id": "pallet_2"},
            }
        }
        graph = Graph(graph_data)

        # WHEN
        result = graph.get_plies_by_pallet_and_layer("pallet_1", "layer_P")

        # THEN
        assert result == {
            "P1": {"edges": ["P1.1", "P1.2"], "layer_id": "layer_P", "pallet_id": "pallet_1"},
            "P2": {"edges": ["P2.1", "P2.2"], "layer_id": "layer_P", "pallet_id": "pallet_1"},
        }

    def test_should_return_empty_dict_when_given_layer_does_not_exist(self):
        # GIVEN
        graph_data = {
            "plies": {
                "P1": {"edges": ["P1.1", "P1.2"], "layer_id": "layer_P", "pallet_id": "pallet_1"},
                "P2": {"edges": ["P2.1", "P2.2"], "layer_id": "layer_P", "pallet_id": "pallet_1"},
                "P3": {"edges": ["P3.1", "P3.2"], "layer_id": "layer_P", "pallet_id": "pallet_1"},
                "P4": {"edges": ["P4.1", "P4.2"], "layer_id": "layer_P", "pallet_id": "pallet_2"},
            }
        }
        graph = Graph(graph_data)

        # WHEN
        result = graph.get_plies_by_pallet_and_layer("pallet_1", "layer_N")

        # THEN
        assert result == {}

    def test_should_return_empty_dict_when_given_pallet_does_not_exist(self):
        # GIVEN
        graph_data = {
            "plies": {
                "P1": {"edges": ["P1.1", "P1.2"], "layer_id": "layer_P", "pallet_id": "pallet_1"},
                "P2": {"edges": ["P2.1", "P2.2"], "layer_id": "layer_P", "pallet_id": "pallet_1"},
                "P3": {"edges": ["P3.1", "P3.2"], "layer_id": "layer_P", "pallet_id": "pallet_1"},
                "P4": {"edges": ["P4.1", "P4.2"], "layer_id": "layer_P", "pallet_id": "pallet_2"},
            }
        }
        graph = Graph(graph_data)

        # WHEN
        result = graph.get_plies_by_pallet_and_layer("pallet_3", "layer_P")

        # THEN
        assert result == {}

    def test_should_return_empty_dict_when_given_pallet_and_layer_combination_does_not_exist(self):
        # GIVEN
        graph_data = {
            "plies": {
                "P1": {"edges": ["P1.1", "P1.2"], "layer_id": "layer_P", "pallet_id": "pallet_1"},
                "P2": {"edges": ["P2.1", "P2.2"], "layer_id": "layer_P", "pallet_id": "pallet_1"},
                "N3": {"edges": ["N3.1", "N3.2"], "layer_id": "layer_N", "pallet_id": "pallet_1"},
                "N4": {"edges": ["N4.1", "N4.2"], "layer_id": "layer_N", "pallet_id": "pallet_2"},
            }
        }
        graph = Graph(graph_data)

        # WHEN
        result = graph.get_plies_by_pallet_and_layer("pallet_2", "layer_P")

        # THEN
        assert result == {}


class GetPliesByPalletTests:
    def test_should_return_single_ply_by_given_pallet(self):
        # GIVEN
        graph_data = {
            "plies": {
                "P1": {"edges": ["P1.1", "P1.2"], "layer_id": "layer_P", "pallet_id": "pallet_1"},
                "P2": {"edges": ["P2.1", "P2.2"], "layer_id": "layer_P", "pallet_id": "pallet_1"},
                "P3": {"edges": ["P3.1", "P3.2"], "layer_id": "layer_P", "pallet_id": "pallet_1"},
                "P4": {"edges": ["P4.1", "P4.2"], "layer_id": "layer_P", "pallet_id": "pallet_2"},
            }
        }
        graph = Graph(graph_data)

        # WHEN
        result = graph._get_plies_by_pallet("pallet_2")

        # THEN
        assert result == {
            "P4": {"edges": ["P4.1", "P4.2"], "layer_id": "layer_P", "pallet_id": "pallet_2"}
        }

    def test_should_return_multiple_plies_by_given_pallet(self):
        # GIVEN
        graph_data = {
            "plies": {
                "P1": {"edges": ["P1.1", "P1.2"], "layer_id": "layer_P", "pallet_id": "pallet_1"},
                "P2": {"edges": ["P2.1", "P2.2"], "layer_id": "layer_P", "pallet_id": "pallet_1"},
                "P3": {"edges": ["P3.1", "P3.2"], "layer_id": "layer_P", "pallet_id": "pallet_1"},
                "P4": {"edges": ["P4.1", "P4.2"], "layer_id": "layer_P", "pallet_id": "pallet_2"},
            }
        }
        graph = Graph(graph_data)

        # WHEN
        result = graph._get_plies_by_pallet("pallet_1")

        # THEN
        assert result == {
            "P1": {"edges": ["P1.1", "P1.2"], "layer_id": "layer_P", "pallet_id": "pallet_1"},
            "P2": {"edges": ["P2.1", "P2.2"], "layer_id": "layer_P", "pallet_id": "pallet_1"},
            "P3": {"edges": ["P3.1", "P3.2"], "layer_id": "layer_P", "pallet_id": "pallet_1"}
        }

    def test_should_return_single_ply_by_given_pallet_when_multiple_layers_exist(self):
        # GIVEN
        graph_data = {
            "plies": {
                "P1": {"edges": ["P1.1", "P1.2"], "layer_id": "layer_P", "pallet_id": "pallet_1"},
                "P2": {"edges": ["P2.1", "P2.2"], "layer_id": "layer_P", "pallet_id": "pallet_1"},
                "N3": {"edges": ["N3.1", "N3.2"], "layer_id": "layer_N", "pallet_id": "pallet_1"},
                "N4": {"edges": ["N4.1", "N4.2"], "layer_id": "layer_N", "pallet_id": "pallet_2"},
            }
        }
        graph = Graph(graph_data)

        # WHEN
        result = graph._get_plies_by_pallet("pallet_2")

        # THEN
        assert result == {
            "N4": {"edges": ["N4.1", "N4.2"], "layer_id": "layer_N", "pallet_id": "pallet_2"}
        }

    def test_should_return_multiple_plies_by_given_pallet_when_multiple_layers_exist(self):
        # GIVEN
        graph_data = {
            "plies": {
                "P1": {"edges": ["P1.1", "P1.2"], "layer_id": "layer_P", "pallet_id": "pallet_1"},
                "P2": {"edges": ["P2.1", "P2.2"], "layer_id": "layer_P", "pallet_id": "pallet_1"},
                "N3": {"edges": ["N3.1", "N3.2"], "layer_id": "layer_N", "pallet_id": "pallet_1"},
                "N4": {"edges": ["N4.1", "N4.2"], "layer_id": "layer_N", "pallet_id": "pallet_2"},
            }
        }
        graph = Graph(graph_data)

        # WHEN
        result = graph._get_plies_by_pallet("pallet_1")

        # THEN
        assert result == {
            "P1": {"edges": ["P1.1", "P1.2"], "layer_id": "layer_P", "pallet_id": "pallet_1"},
            "P2": {"edges": ["P2.1", "P2.2"], "layer_id": "layer_P", "pallet_id": "pallet_1"},
            "N3": {"edges": ["N3.1", "N3.2"], "layer_id": "layer_N", "pallet_id": "pallet_1"},
        }


class GetLayerTests:
    def test_should_return_correct_layer_id_by_given_ply(self):
        # GIVEN
        graph_data = {
            "plies": {
                "P1": {"edges": ["P1.1", "P1.2"], "layer_id": "layer_1"},
                "P2": {"edges": ["P2.1", "P2.2"], "layer_id": "layer_2"},
                "P3": {"edges": ["P3.1", "P3.2"], "layer_id": "layer_3"},
            }
        }
        ply_id = "P2"
        graph = Graph(graph_data)

        # WHEN
        result = graph.get_layer(ply_id)

        # THEN result is correct
        assert result == "layer_2"

    def test_should_raise_exception_when_layer_id_is_missing(self):
        # GIVEN
        graph_data = {
            "plies": {
                "P1": {"edges": ["P1.1", "P1.2"], "layer_id": "layer_1"},
                "P2": {"edges": ["P2.1", "P2.2"], "NO_LAYER_ID": "no_layer_2"},
                "P3": {"edges": ["P3.1", "P3.2"], "layer_id": "layer_3"},
            }
        }
        ply_id = "P2"
        graph = Graph(graph_data)

        # WHEN graph.get_layer is called, assert that an exception is raised
        exc_info = raises(
            Exception,
            graph.get_layer,
            ply_id
        )

        # THEN an exception of type ValueError is raised
        assert exc_info.type is ValueError
        warning_message = f"Failed to get_layer. Missing attribute: 'layer_id', in ply: {ply_id}"
        assert exc_info.value.args[0] == warning_message


class FindPliesByEdgesTests:
    def test_find_plies_by_edges_should_return_plies_from_graph_by_given_edges(self, mocker):
        # GIVEN
        log = mocker.patch("app.models.graph.log")
        graph_data = {
            "plies": {
                "P1": {"edges": ["P1.1", "P1.2"]},
                "P2": {"edges": ["P2.1", "P2.2"]},
                "P3": {"edges": ["P3.1", "P3.2"]}
            }
        }
        edges = {"P1.1", "P2.1", "P3.2"}
        graph = Graph(graph_data)

        # WHEN graph.find_plies_by_edges is called
        result = graph.find_plies_by_edges(edges)

        # THEN correct result returned
        assert result == graph_data["plies"]

        # AND log.debug is called with correct argument
        assert log.debug.call_count == 1
        log_calls = log.debug.call_args_list
        assert log_calls[0] == call("Found plies: %s for given edges: %s", graph_data["plies"].keys(), edges)

    def test_find_plies_by_edges_should_return_empty_dict_when_empty_set_given(self, mocker):
        # GIVEN
        log = mocker.patch("app.models.graph.log")
        graph_data = {
            "plies": {
                "P1": {"edges": ["P1.1", "P1.2"]},
            }
        }
        empty_set = set()
        graph = Graph(graph_data)

        # WHEN graph.find_plies_by_edges is called
        result = graph.find_plies_by_edges(empty_set)

        # THEN correct result returned
        assert result == {}

        # AND log.warning is called with correct argument
        assert log.warning.call_count == 1
        call_args = log.warning.call_args.args
        assert call_args[0] == "No edges given to find plies by in the graph, returning empty result."

    def test_find_plies_by_edges_should_return_empty_dict_when_non_existing_edges_given(self, mocker):
        # GIVEN
        graph_data = {
            "plies": {
                "P1": {"edges": ["P1.1", "P1.2"]},
                "P2": {"edges": ["P2.1", "P2.2"]},
                "P3": {"edges": ["P3.1", "P3.2"]}
            }
        }
        non_existing_edge = "NON_EXISTING_EDGE_0"
        edges = {non_existing_edge}
        graph = Graph(graph_data)

        # WHEN graph.find_plies_by_edges is called
        result = graph.find_plies_by_edges(edges)

        # THEN correct result returned
        assert result == {}


class GetPlyByEdgeTests:
    def test_get_ply_by_edge_should_return_ply_from_graph_by_given_edge(self, mocker):
        # GIVEN
        log = mocker.patch("app.models.graph.log")
        graph_data = {
            "plies": {
                "P1": {"edges": ["P1.1", "P1.2"]},
                "P2": {"edges": ["P2.1", "P2.2"]},
                "P3": {"edges": ["P3.1", "P3.2"]}
            }
        }
        edge = "P2.2"
        graph = Graph(graph_data)

        # WHEN graph.get_ply_by_edge is called
        result = graph.get_ply_by_edge(edge)

        # THEN correct result returned
        assert result == ("P2", {"edges": ["P2.1", "P2.2"]})

        # AND log.error is not called
        assert log.error.call_count == 0

    def test_get_ply_by_edge_should_raise_exception_when_non_existing_edge_given(self, mocker):
        # GIVEN
        graph_data = {
            "plies": {
                "P1": {"edges": ["P1.1", "P1.2"]}
            }
        }
        non_existing_edge = "NON_EXISTING_EDGE"
        graph = Graph(graph_data)

        # WHEN graph.get_ply_by_edge is called, assert that an exception is raised
        exc_info = raises(
            Exception,
            graph.get_ply_by_edge,
            non_existing_edge
        )

        # THEN an exception of type ValueError is raised
        assert exc_info.type is ValueError
        error_message = f"Failed to found ply by given edge: {non_existing_edge}, in edge-to-ply mapping."
        assert exc_info.value.args[0] == error_message


class GetEdgesByPlyTests:
    def test_get_edges_by_ply_should_return_edges_from_graph_ply_by_given_ply(self, mocker):
        # GIVEN
        log = mocker.patch("app.models.graph.log")
        graph_data = {
            "plies": {
                "P1": {"edges": ["P1.1", "P1.2"]},
                "P2": {"edges": ["P2.1", "P2.2"]},
                "P3": {"edges": ["P3.1", "P3.2"]}
            }
        }
        ply_id = "P2"
        graph = Graph(graph_data)

        # WHEN graph.get_edges_by_ply is called
        result = graph.get_edges_by_ply(ply_id)

        # THEN correct result returned
        assert result == {"P2.1", "P2.2"}

        # AND log.error is not called
        assert log.error.call_count == 0

    def test_get_edges_by_ply_should_raise_exception_when_non_existing_ply_id_given(self, mocker):
        # GIVEN
        graph_data = {
            "plies": {
                "P1": {"edges": ["P1.1", "P1.2"]},
                "P2": {"edges": ["P2.1", "P2.2"]},
                "P3": {"edges": ["P3.1", "P3.2"]}
            }
        }
        ply_id = "NON_EXISTING_PLY_ID"
        graph = Graph(graph_data)

        # WHEN graph.get_edges_by_ply is called, assert that an exception is raised
        exc_info = raises(
            Exception,
            graph.get_edges_by_ply,
            ply_id
        )

        # THEN an exception of type ValueError is raised
        assert exc_info.type is ValueError
        get_ply_ex_message = f"Failed to found ply in graph by given ply_id: {KeyError(ply_id)}"
        error_message = f"Failed to get_edges_by_ply for given ply: {ply_id}, due to: {get_ply_ex_message}"
        assert exc_info.value.args[0] == error_message


class GetEdgesByPliesTests:
    def test_get_edges_by_plies_should_return_edges_from_graph_plies_by_given_ply_ids(self, mocker):
        # GIVEN
        log = mocker.patch("app.models.graph.log")
        graph_data = {
            "plies": {
                "P1": {"edges": ["P1.1", "P1.2"]},
                "P2": {"edges": ["P2.1", "P2.2"]},
                "P3": {"edges": ["P3.1", "P3.2"]}
            }
        }
        ply_ids = {"P2", "P3"}
        graph = Graph(graph_data)

        # WHEN graph.get_edges_by_plies is called
        result = graph.get_edges_by_plies(ply_ids)

        # THEN correct result returned
        assert result == {"P2.1", "P2.2", "P3.1", "P3.2"}

        # AND log.error is not called
        assert log.error.call_count == 0

    def test_get_edges_by_plies_should_raise_exception_when_non_existing_ply_ids_given(self, mocker):
        # GIVEN
        graph_data = {
            "plies": {
                "P1": {"edges": ["P1.1", "P1.2"]},
                "P2": {"edges": ["P2.1", "P2.2"]},
                "P3": {"edges": ["P3.1", "P3.2"]}
            }
        }
        ply_id = "NON_EXISTING_PLY_ID_0"
        ply_ids = {ply_id}
        graph = Graph(graph_data)

        # WHEN graph.get_edges_by_plies is called, assert that an exception is raised
        exc_info = raises(
            Exception,
            graph.get_edges_by_plies,
            ply_ids
        )

        # THEN an exception of type ValueError is raised
        assert exc_info.type is ValueError
        get_ply_ex_message = f"Failed to found ply in graph by given ply_id: {KeyError(ply_id)}"
        get_edges_by_ply_ex_message = f"Failed to get_edges_by_ply for given ply: {ply_id}, " \
                                      f"due to: {ValueError(get_ply_ex_message)}"
        error_message = f"Failed to get_edges_by_plies for given plies: {ply_ids}, " \
                        f"due to: {ValueError(get_edges_by_ply_ex_message)}"
        assert exc_info.value.args[0] == error_message


class GetAllEdgesAndPliesTests:
    def test_get_all_edges_should_return_all_edges_in_graph(self, mocker):
        # GIVEN
        log = mocker.patch("app.models.graph.log")
        graph_data = {
            "plies": {
                "P1": {"edges": ["P1.1", "P1.2"]},
                "P2": {"edges": ["P2.1", "P2.2"]},
                "P3": {"edges": ["P3.1", "P3.2"]}
            }
        }
        graph = Graph(graph_data)

        # WHEN graph.get_all_edges is called
        result = graph.get_all_edges()

        # THEN correct result returned
        assert result == {"P1.1", "P1.2", "P2.1", "P2.2", "P3.1", "P3.2"}

        # AND log.error is not called
        assert log.error.call_count == 0

    def test_get_all_plies_should_return_all_plies_from_graph(self, mocker):
        # GIVEN
        log = mocker.patch("app.models.graph.log")
        graph_data = {
            "plies": {
                "P1": {"edges": ["P1.1", "P1.2"]},
                "P2": {"edges": ["P2.1", "P2.2"]},
                "P3": {"edges": ["P3.1", "P3.2"]}
            }
        }
        graph = Graph(graph_data)

        # WHEN graph.get_all_plies is called
        result = graph.get_all_plies()

        # THEN correct result returned
        assert result == graph_data["plies"]

        # AND log.error is not called
        assert log.error.call_count == 0


class GetPreviousPliesTests:
    def test_should_return_previous_plies(self):
        # GIVEN
        graph_data = {
            "plies": {
                "P1": {"previous_plies": [], "pallet_id": "pallet_1", "edges": ["P1.1", "P1.2"]},
                "P2": {"previous_plies": ["P1"], "pallet_id": "pallet_1", "edges": ["P2.1", "P2.2"]},
                "P3": {"previous_plies": ["P2"], "pallet_id": "pallet_1", "edges": ["P3.1", "P3.2"]}
            }
        }
        ply_id = "P2"
        graph = Graph(graph_data)

        # WHEN
        result = graph.get_previous_plies(ply_id)

        # THEN result is correct
        assert result == {"P1"}

    def test_should_return_empty_set_when_previous_plies_are_empty(self):
        # GIVEN
        graph_data = {
            "plies": {
                "P1": {"previous_plies": [], "pallet_id": "pallet_1", "edges": ["P1.1", "P1.2"]},
                "P2": {"previous_plies": ["P1"], "pallet_id": "pallet_1", "edges": ["P2.1", "P2.2"]},
                "P3": {"previous_plies": ["P2"], "pallet_id": "pallet_1", "edges": ["P3.1", "P3.2"]}
            }
        }
        ply_id = "P1"
        graph = Graph(graph_data)

        # WHEN
        result = graph.get_previous_plies(ply_id)

        # THEN result is correct
        assert result == set()

    def test_should_raise_exception_when_previous_plies_missing(self):
        # GIVEN
        graph_data = {
            "plies": {
                "P1": {"previous_plies": [], "pallet_id": "pallet_1", "edges": ["P1.1", "P1.2"]},
                "P2": {"NO_PREVIOUS_PLIES": [], "pallet_id": "pallet_1", "edges": ["P2.1", "P2.2"]},
                "P3": {"previous_plies": ["P2"], "pallet_id": "pallet_1", "edges": ["P3.1", "P3.2"]}
            }
        }
        ply_id = "P2"
        graph = Graph(graph_data)

        # WHEN graph.get_previous_plies is called, assert that an exception is raised
        exc_info = raises(
            Exception,
            graph.get_previous_plies,
            ply_id
        )

        # THEN an exception of type ValueError is raised
        assert exc_info.type is ValueError
        warning_message = f"Failed to get_previous_plies. Missing attribute: 'previous_plies', in ply: {ply_id}"
        assert exc_info.value.args[0] == warning_message


class GetPlyTests:
    def test_get_ply_should_return_ply_from_graph_by_given_ply_id(self, mocker):
        # GIVEN
        log = mocker.patch("app.models.graph.log")
        ply_id = "P2"
        graph_data = {
            "plies": {
                "P1": {"edges": ["P1.1", "P1.2"]},
                "P2": {"edges": ["P2.1", "P2.2"]},
                "P3": {"edges": ["P3.1", "P3.2"]}
            }
        }
        graph = Graph(graph_data)

        # WHEN graph.get_ply is called
        result = graph.get_ply(ply_id)

        # THEN correct result returned
        assert result == graph_data["plies"][ply_id]

        # AND log.error is not called
        assert log.error.call_count == 0

    def test_get_ply_should_return_empty_dict_and_log_error_when_non_existing_ply_id_given(self, mocker):
        # GIVEN
        non_existing_ply_id = "NON_EXISTING_PLY_ID"
        graph_data = {
            "plies": {
                "P1": {"edges": ["P1.1", "P1.2"]},
            }
        }
        graph = Graph(graph_data)

        # WHEN graph.get_ply is called, assert that an exception is raised
        exc_info = raises(
            Exception,
            graph.get_ply,
            non_existing_ply_id
        )

        # THEN an exception of type ValueError is raised
        assert exc_info.type is ValueError
        error_message = f"Failed to found ply in graph by given ply_id: {KeyError(non_existing_ply_id)}"
        assert exc_info.value.args[0] == error_message


class RemoveInvisibleEdgesTests:
    def test_remove_invisible_edges_should_correctly_prune_plies_edges_and_edges_covered_when_single_edge_given(
            self, mocker):
        # GIVEN
        log = mocker.patch("app.models.graph.log")
        edges_to_remove = {"P1.2"}
        graph_data = {
            "plies": {
                "P1": {"edges": ["P1.1", "P1.2"], "edges_covered": []},
                "P2": {"edges": ["P2.1", "P2.2"], "edges_covered": ["P1.2"]},
                "P3": {"edges": ["P3.1", "P3.2"], "edges_covered": ["P1.2", "P2.2"]}
            }
        }
        graph = Graph(graph_data)

        # WHEN graph.remove_invisible_edges is called
        graph.remove_invisible_edges(edges_to_remove)

        # THEN correct result returned
        expected_graph_data = {
            "plies": {
                "P1": {"edges": ["P1.1"], "edges_covered": []},
                "P2": {"edges": ["P2.1", "P2.2"], "edges_covered": []},
                "P3": {"edges": ["P3.1", "P3.2"], "edges_covered": ["P2.2"]}
            }
        }
        assert graph._stored_graph_data == expected_graph_data

        # AND log.warning is called and first call have correct arguments
        assert log.warning.call_count == 4
        log_calls = log.warning.call_args_list
        assert log_calls[0] == call(
            "Removing invisible edges: %s, from graph plies attributes 'edges' and 'edges_covered'.", edges_to_remove)

    def test_remove_invisible_edges_should_correctly_prune_plies_edges_and_edges_covered_when_multiple_edges_given(
            self, mocker):
        # GIVEN
        log = mocker.patch("app.models.graph.log")
        edges_to_remove = {"P1.1", "P1.2", "P2.1", "P3.1"}
        graph_data = {
            "plies": {
                "P1": {"edges": ["P1.1", "P1.2"], "edges_covered": []},
                "P2": {"edges": ["P2.1", "P2.2"], "edges_covered": ["P1.2"]},
                "P3": {"edges": ["P3.1", "P3.2"], "edges_covered": ["P1.2", "P2.2"]}
            }
        }
        graph = Graph(graph_data)

        # WHEN graph.remove_invisible_edges is called
        graph.remove_invisible_edges(edges_to_remove)

        # THEN correct result returned
        expected_graph_data = {
            "plies": {
                "P1": {"edges": [], "edges_covered": []},
                "P2": {"edges": ["P2.2"], "edges_covered": []},
                "P3": {"edges": ["P3.2"], "edges_covered": ["P2.2"]}
            }
        }
        assert graph._stored_graph_data == expected_graph_data

        # AND log.warning is called and first call have correct arguments
        assert log.warning.call_count == 13
        log_calls = log.warning.call_args_list
        assert log_calls[0] == call(
            "Removing invisible edges: %s, from graph plies attributes 'edges' and 'edges_covered'.", edges_to_remove)

    def test_remove_invisible_edges_should_not_prune_plies_edges_and_edges_covered_when_empty_edges_given(
            self, mocker):
        # GIVEN
        log = mocker.patch("app.models.graph.log")
        edges_to_remove = set()
        graph_data = {
            "plies": {
                "P1": {"edges": ["P1.1", "P1.2"], "edges_covered": []},
                "P2": {"edges": ["P2.1", "P2.2"], "edges_covered": ["P1.2"]},
                "P3": {"edges": ["P3.1", "P3.2"], "edges_covered": ["P1.2", "P2.2"]}
            }
        }
        expected_graph_data = copy.deepcopy(graph_data)
        graph = Graph(graph_data)

        # WHEN graph.remove_invisible_edges is called
        graph.remove_invisible_edges(edges_to_remove)

        # THEN correct result returned
        assert graph._stored_graph_data == expected_graph_data

        # AND log.warning is called with correct arguments
        assert log.warning.call_count == 1
        log_calls = log.warning.call_args_list
        assert log_calls[0] == call(
            "Removing invisible edges: %s, from graph plies attributes 'edges' and 'edges_covered'.", edges_to_remove)

    def test_prune_plies_edges_should_correctly_prune_graph_plies_edges_by_given_edge(self, mocker):
        # GIVEN
        log = mocker.patch("app.models.graph.log")
        edge_to_remove = "P2.1"
        graph_data = {
            "plies": {
                "P1": {"edges": ["P1.1", "P1.2"]},
                "P2": {"edges": ["P2.1", "P2.2"]},
                "P3": {"edges": ["P3.1", "P3.2"]}
            }
        }
        graph = Graph(graph_data)

        # WHEN graph._prune_plies_edges is called
        graph._prune_plies_edges(edge_to_remove)

        # THEN correct result returned
        expected_graph_data = {
            "plies": {
                "P1": {"edges": ["P1.1", "P1.2"]},
                "P2": {"edges": ["P2.2"]},
                "P3": {"edges": ["P3.1", "P3.2"]}
            }
        }
        assert graph._stored_graph_data == expected_graph_data

        # AND log.warning is called with correct arguments
        assert log.warning.call_count == 1
        log_calls = log.warning.call_args_list
        assert log_calls[0] == call("Edge %s removed from 'edges' attributes in ply: %s", edge_to_remove, "P2")

    def test_prune_plies_edges_should_low_warning_when_non_existing_edge_given(self, mocker):
        # GIVEN
        log = mocker.patch("app.models.graph.log")
        edge_to_remove = "NON_EXISTING_EDGE"
        graph_data = {
            "plies": {
                "P1": {"edges": ["P1.1", "P1.2"]},
                "P2": {"edges": ["P2.1", "P2.2"]},
                "P3": {"edges": ["P3.1", "P3.2"]}
            }
        }
        expected_graph_data = copy.deepcopy(graph_data)
        graph = Graph(graph_data)

        # WHEN
        graph._prune_plies_edges(edge_to_remove)

        # THEN correct result returned
        assert graph._stored_graph_data == expected_graph_data

        # AND log.warning is called and first call have correct arguments
        assert log.warning.call_count == 1
        log_calls = log.warning.call_args_list
        ex_message = f"Failed to found ply by given edge: {edge_to_remove}, in edge-to-ply mapping."
        assert log_calls[0] == call(
            f"Failed to remove edge: {edge_to_remove} from 'edges' attribute in graph plies, due to: {ex_message}")

    def test_prune_plies_edges_covered_should_correctly_prune_graph_plies_edges_covered_by_given_edge(self, mocker):
        # GIVEN
        log = mocker.patch("app.models.graph.log")
        edge_to_remove = "P2.2"
        graph_data = {
            "plies": {
                "P1": {"edges": ["P1.1", "P1.2"], "edges_covered": []},
                "P2": {"edges": ["P2.1", "P2.2"], "edges_covered": ["P1.2"]},
                "P3": {"edges": ["P3.1", "P3.2"], "edges_covered": ["P1.2", "P2.2"]}
            }
        }
        graph = Graph(graph_data)

        # WHEN graph._prune_plies_edges_covered is called
        graph._prune_plies_edges_covered(edge_to_remove)

        # THEN correct result returned
        expected_graph_data = {
            "plies": {
                "P1": {"edges": ["P1.1", "P1.2"], "edges_covered": []},
                "P2": {"edges": ["P2.1", "P2.2"], "edges_covered": ["P1.2"]},
                "P3": {"edges": ["P3.1", "P3.2"], "edges_covered": ["P1.2"]}
            }
        }
        assert graph._stored_graph_data == expected_graph_data

        # AND log.warning is called and first call have correct arguments
        assert log.warning.call_count == 1
        log_calls = log.warning.call_args_list
        assert log_calls[0] == call("Edge %s removed from 'edges_covered' attributes in ply: %s", edge_to_remove, "P3")

    def test_prune_plies_edges_covered_should_not_prune_graph_plies_edges_covered_when_non_existing_edge_given(
            self, mocker):
        # GIVEN
        log = mocker.patch("app.models.graph.log")
        edge_to_remove = "NON_EXISTING_EDGE"
        graph_data = {
            "plies": {
                "P1": {"edges": ["P1.1", "P1.2"], "edges_covered": []},
                "P2": {"edges": ["P2.1", "P2.2"], "edges_covered": ["P1.2"]},
                "P3": {"edges": ["P3.1", "P3.2"], "edges_covered": ["P1.2", "P2.2"]}
            }
        }
        expected_graph_data = copy.deepcopy(graph_data)
        graph = Graph(graph_data)

        # WHEN graph._prune_plies_edges_covered is called
        graph._prune_plies_edges_covered(edge_to_remove)

        # THEN correct result returned
        assert graph._stored_graph_data == expected_graph_data

        # AND log.warning is called and first call have correct arguments
        assert log.warning.call_count == 2
        log_calls = log.warning.call_args_list
        ex_message = f"Failed to found any ply where given edge: {edge_to_remove}, in ply's 'edges_covered' attribute."
        assert log_calls[0] == call(ex_message)
        assert log_calls[1] == call(
            f"Failed to remove edge: {edge_to_remove} from 'edges_covered' attr in graph plies, due to: {ex_message}")

    def test_find_plies_by_edges_covered_should_return_plies_where_given_edge_in_ply_edges_covered_attr(self, mocker):
        # GIVEN
        log = mocker.patch("app.models.graph.log")
        edge = "P1.2"
        graph_data = {
            "plies": {
                "P1": {"edges": ["P1.1", "P1.2"], "edges_covered": []},
                "P2": {"edges": ["P2.1", "P2.2"], "edges_covered": ["P1.2"]},
                "P3": {"edges": ["P3.1", "P3.2"], "edges_covered": ["P1.2", "P2.2"]}
            }
        }
        graph = Graph(graph_data)

        # WHEN graph.get_plies_by_edges_covered is called
        result = graph._get_plies_by_edges_covered(edge)

        # THEN correct result returned
        expected_graph_data = {
            "P2": {"edges": ["P2.1", "P2.2"], "edges_covered": ["P1.2"]},
            "P3": {"edges": ["P3.1", "P3.2"], "edges_covered": ["P1.2", "P2.2"]}
        }
        assert result == expected_graph_data

        # AND log.warning is not called
        assert log.warning.call_count == 0

    def test_find_plies_by_edges_covered_should_raise_exception_when_given_edge_is_not_in_any_ply_edges_covered_attr(
            self, mocker):
        # GIVEN
        log = mocker.patch("app.models.graph.log")
        edge = "P1.1"
        graph_data = {
            "plies": {
                "P1": {"edges": ["P1.1", "P1.2"], "edges_covered": []},
                "P2": {"edges": ["P2.1", "P2.2"], "edges_covered": ["P1.2"]},
                "P3": {"edges": ["P3.1", "P3.2"], "edges_covered": ["P1.2", "P2.2"]}
            }
        }
        graph = Graph(graph_data)

        # WHEN graph._get_plies_by_edges_covered is called, assert that an exception is raised
        exc_info = raises(
            Exception,
            graph._get_plies_by_edges_covered,
            edge
        )

        # THEN an exception of type ValueError is raised
        assert exc_info.type is ValueError
        warning_message = f"Failed to found any ply where given edge: {edge}, in ply's 'edges_covered' attribute."
        assert exc_info.value.args[0] == warning_message

        # AND log.warning is called with correct argument
        assert log.warning.call_count == 1
        call_args = log.warning.call_args.args
        assert call_args[0] == warning_message

    def test_find_plies_by_edges_covered_should_return_correct_result_and_log_warning_when_missing_edges_covered_attr(
            self, mocker):
        # GIVEN
        log = mocker.patch("app.models.graph.log")
        edge = "P1.2"
        graph_data = {
            "plies": {
                "P1": {"edges": ["P1.1", "P1.2"], "edges_covered": []},
                "P2": {"edges": ["P2.1", "P2.2"], "NO_EDGES_COVERED_ATTRIBUTE": []},
                "P3": {"edges": ["P3.1", "P3.2"], "edges_covered": ["P1.2", "P2.2"]}
            }
        }
        graph = Graph(graph_data)

        # WHEN graph.get_plies_by_edges_covered is called
        result = graph._get_plies_by_edges_covered(edge)

        # THEN correct result returned
        expected_graph_data = {
            "P3": {"edges": ["P3.1", "P3.2"], "edges_covered": ["P1.2", "P2.2"]}
        }
        assert result == expected_graph_data

        # AND log.warning is called with correct argument
        assert log.warning.call_count == 1
        call_args = log.warning.call_args.args
        assert call_args[0] == "Missing '%s' attribute in ply: %s".format("edges_covered", "P2")


class GetPalletTests:
    def test_should_return_correct_pallet_id_by_given_ply(self):
        # GIVEN
        graph_data = {
            "plies": {
                "P1": {"next_plies": ["P2"], "pallet_id": "pallet_1", "edges": ["P1.1", "P1.2"]},
                "P2": {"next_plies": ["P3"], "pallet_id": "pallet_2", "edges": ["P2.1", "P2.2"]},
                "P3": {"next_plies": [], "pallet_id": "pallet_3", "edges": ["P3.1", "P3.2"]}
            }
        }
        ply_id = "P2"
        graph = Graph(graph_data)

        # WHEN
        result = graph.get_pallet(ply_id)

        # THEN
        assert result == "pallet_2"

    def test_get_pallet_should_raise_exception_when_pallet_id_is_missing(self):
        # GIVEN
        graph_data = {
            "plies": {
                "P1": {"next_plies": ["P2"], "pallet_id": "pallet_id", "edges": ["P1.1", "P1.2"]},
                "P2": {"next_plies": ["P3"], "NO_PALLET_ID": "pallet_id", "edges": ["P2.1", "P2.2"]},
                "P3": {"next_plies": [], "pallet_id": "pallet_id", "edges": ["P3.1", "P3.2"]}
            }
        }
        ply_id = "P2"
        graph = Graph(graph_data)

        # WHEN graph.get_pallet is called, assert that an exception is raised
        exc_info = raises(
            Exception,
            graph.get_pallet,
            ply_id
        )

        # THEN an exception of type ValueError is raised
        assert exc_info.type is ValueError
        warning_message = f"Failed to get_pallet. Missing attribute: 'pallet_id', in ply: {ply_id}"
        assert exc_info.value.args[0] == warning_message


class GetNextPliesPalletsTests:
    def test_should_return_next_plies_pallets_when_next_plies_are_not_empty(self):
        # GIVEN
        graph_data = {
            "plies": {
                "P1": {"next_plies": ["P2"], "pallet_id": "pallet_1", "edges": ["P1.1", "P1.2"]},
                "P2": {"next_plies": ["P3"], "pallet_id": "pallet_1", "edges": ["P2.1", "P2.2"]},
                "P3": {"next_plies": [], "pallet_id": "pallet_1", "edges": ["P3.1", "P3.2"]}
            }
        }
        ply_id = "P1"
        graph = Graph(graph_data)

        # WHEN
        result = graph.get_next_plies_pallets(ply_id)

        # THEN result is correct
        assert result == ["pallet_1"]

    def test_should_return_none_next_plies_pallets_when_next_plies_are_empty(self):
        # GIVEN
        graph_data = {
            "plies": {
                "P1": {"next_plies": ["P2"], "pallet_id": "pallet_1", "edges": ["P1.1", "P1.2"]},
                "P2": {"next_plies": ["P3"], "pallet_id": "pallet_1", "edges": ["P2.1", "P2.2"]},
                "P3": {"next_plies": [], "pallet_id": "pallet_1", "edges": ["P3.1", "P3.2"]}
            }
        }
        ply_id = "P3"
        graph = Graph(graph_data)

        # WHEN
        result = graph.get_next_plies_pallets(ply_id)

        # THEN result is correct
        assert result == []

    def test_should_return_single_next_plies_pallet_when_next_plies_on_same_pallet(self):
        # GIVEN
        graph_data = {
            "plies": {
                "P4": {"next_plies": ["P5", "P6"], "pallet_id": "pallet_2", "edges": ["P4.1", "P4.2"]},
                "P5": {"next_plies": ["P7"], "pallet_id": "pallet_2", "edges": ["P5.1", "P5.2"]},
                "P6": {"next_plies": ["P8"], "pallet_id": "pallet_2", "edges": ["P6.1", "P6.2"]}
            }
        }
        ply_id = "P4"
        graph = Graph(graph_data)

        # WHEN
        result = graph.get_next_plies_pallets(ply_id)

        # THEN result is correct
        assert result == ["pallet_2"]

    def test_should_return_multiple_next_plies_pallets_when_next_plies_on_multiple_pallets(self):
        # GIVEN
        graph_data = {
            "plies": {
                "P4": {"next_plies": ["P5", "P6"], "pallet_id": "pallet_2", "edges": ["P4.1", "P4.2"]},
                "P5": {"next_plies": ["P7"], "pallet_id": "pallet_2", "edges": ["P5.1", "P5.2"]},
                "P6": {"next_plies": ["P8"], "pallet_id": "pallet_3", "edges": ["P6.1", "P6.2"]}
            }
        }
        ply_id = "P4"
        graph = Graph(graph_data)

        # WHEN
        result = graph.get_next_plies_pallets(ply_id)

        # THEN result is correct
        assert sorted(result) == sorted(["pallet_2", "pallet_3"])


class GetNextPliesTests:
    def test_should_return_next_plies_when_next_plies_are_not_empty(self):
        # GIVEN
        graph_data = {
            "plies": {
                "P1": {"next_plies": ["P2"], "pallet_id": "pallet_1", "edges": ["P1.1", "P1.2"]},
                "P2": {"next_plies": ["P3"], "pallet_id": "pallet_1", "edges": ["P2.1", "P2.2"]},
                "P3": {"next_plies": [], "pallet_id": "pallet_1", "edges": ["P3.1", "P3.2"]}
            }
        }
        ply_id = "P1"
        graph = Graph(graph_data)

        # WHEN
        result = graph.get_next_plies(ply_id)

        # THEN result is correct
        assert result == {"P2"}

    def test_should_return_none_next_plies_when_next_plies_are_empty(self):
        # GIVEN
        graph_data = {
            "plies": {
                "P1": {"next_plies": ["P2"], "pallet_id": "pallet_1", "edges": ["P1.1", "P1.2"]},
                "P2": {"next_plies": ["P3"], "pallet_id": "pallet_1", "edges": ["P2.1", "P2.2"]},
                "P3": {"next_plies": [], "pallet_id": "pallet_1", "edges": ["P3.1", "P3.2"]}
            }
        }
        ply_id = "P3"
        graph = Graph(graph_data)

        # WHEN
        result = graph.get_next_plies(ply_id)

        # THEN result is correct
        assert result == set()

    def test_get_next_plies_should_raise_exception_when_next_plies_is_missing(self):
        # GIVEN
        graph_data = {
            "plies": {
                "P1": {"pallet_id": "pallet_1", "edges": ["P1.1", "P1.2"]},
                "P2": {"next_plies": ["P3"], "pallet_id": "pallet_1", "edges": ["P2.1", "P2.2"]},
                "P3": {"next_plies": [], "pallet_id": "pallet_1", "edges": ["P3.1", "P3.2"]}
            }
        }
        ply_id = "P1"
        graph = Graph(graph_data)

        # WHEN graph.get_next_plies is called, assert that an exception is raised
        exc_info = raises(
            Exception,
            graph.get_next_plies,
            ply_id
        )

        # THEN an exception of type ValueError is raised
        assert exc_info.type is ValueError
        warning_message = f"Failed to get_next_plies. Missing attribute: 'next_plies', in ply: {ply_id}"
        assert exc_info.value.args[0] == warning_message


class FindPliesToBePlacedTests:
    def test_should_return_correct_plies_to_be_placed_when_multiple_placed_plies_given(
            self, sample_graph_data, sample_mould_state_plies):
        # GIVEN
        mould_state = MouldState(sample_mould_state_plies)
        graph = Graph(sample_graph_data)

        # AND
        placed_plies_on_mould = mould_state.get_placed_plies_on_mould()
        placed_plies = graph_resolver.plies_from(placed_plies_on_mould, graph)

        # WHEN graph.find_plies_to_be_placed is called
        result = graph.find_plies_to_be_placed(placed_plies)

        # THEN result is correct
        assert set(result) == {"P3", "Z1", "T1", "E1", "L1", "PH1"}

    def test_should_return_single_initial_ply_when_given_placed_plies_is_empty(self):
        # GIVEN
        mould_state = MouldState(set())
        graph = Graph({
            "plies": {
                "P1": {"previous_plies": [], "edges": []},
                "P2": {"previous_plies": ["P1"], "edges": []},
            }
        })

        # AND
        placed_plies_on_mould = mould_state.get_placed_plies_on_mould()
        placed_plies = graph_resolver.plies_from(placed_plies_on_mould, graph)

        # WHEN graph.find_plies_to_be_placed is called
        result = graph.find_plies_to_be_placed(placed_plies)

        # THEN result is correct
        assert set(result) == {"P1"}

    def test_should_return_multiple_initial_plies_when_given_placed_plies_is_empty(self):
        # GIVEN
        mould_state = MouldState(set())
        graph = Graph({
            "plies": {
                "P1": {"previous_plies": [], "edges": []},
                "P2": {"previous_plies": ["P1"], "edges": []},
                "Z1": {"previous_plies": [], "edges": []},
            }
        })

        # AND
        placed_plies_on_mould = mould_state.get_placed_plies_on_mould()
        placed_plies = graph_resolver.plies_from(placed_plies_on_mould, graph)

        # WHEN graph.find_plies_to_be_placed is called
        result = graph.find_plies_to_be_placed(placed_plies)

        # THEN result is correct
        assert set(result) == {"P1", "Z1"}

    def test_should_return_upper_layer_ply_T1_when_all_its_previous_plies_in_given_placed_plies(self):
        # GIVEN
        state_plies_mock = StatePliesMock()
        mould_state = MouldState({
            state_plies_mock.first_ply_partially_covered,
            state_plies_mock.second_ply_placed
        })
        graph = Graph({
            "plies": {
                "P1": {"previous_plies": [], "edges": []},
                "P2": {"previous_plies": ["P1"], "edges": []},
                "T1": {"previous_plies": ["P1", "P2"], "edges": ["T1.1", "T1.2"]}
            }
        })

        # AND
        placed_plies_on_mould = mould_state.get_placed_plies_on_mould()
        placed_plies = graph_resolver.plies_from(placed_plies_on_mould, graph)

        # WHEN graph.find_plies_to_be_placed is called
        result = graph.find_plies_to_be_placed(placed_plies)

        # THEN result is correct
        assert "T1" in set(result)
        assert set(result) == {"T1"}

    def test_should_not_return_upper_layer_ply_T1_when_not_all_its_previous_plies_in_given_placed_plies(self):
        # GIVEN
        state_plies_mock = StatePliesMock()
        mould_state = MouldState({
            state_plies_mock.first_ply_placed,
            state_plies_mock.second_ply_expected
        })
        graph = Graph({
            "plies": {
                "P1": {"previous_plies": [], "edges": []},
                "P2": {"previous_plies": ["P1"], "edges": []},
                "T1": {"previous_plies": ["P1", "P2"], "edges": ["T1.1", "T1.2"]}
            }
        })

        # AND
        placed_plies_on_mould = mould_state.get_placed_plies_on_mould()
        placed_plies = graph_resolver.plies_from(placed_plies_on_mould, graph)

        # WHEN graph.find_plies_to_be_placed is called
        result = graph.find_plies_to_be_placed(placed_plies)

        # THEN result is correct
        assert "T1" not in set(result)
        assert set(result) == {"P2"}

    def test_should_return_empty_set_when_all_graph_plies_placed(self):
        # GIVEN
        state_plies_mock = StatePliesMock()
        mould_state = MouldState({
            state_plies_mock.first_ply_partially_covered,
            state_plies_mock.second_ply_partially_covered,
            state_plies_mock.third_ply_placed
        })
        graph = Graph({
            "plies": {
                "P1": {
                    "previous_plies": [],
                    "next_plies": ["P2"],
                    "edges_covered": [],
                    "edges": ["P1.1", "P1.2"]
                },
                "P2": {
                    "previous_plies": ["P1"],
                    "next_plies": ["P3"],
                    "edges_covered": ["P1.2"],
                    "edges": ["P2.1", "P2.2"]
                },
                "P3": {
                    "previous_plies": ["P2"],
                    "next_plies": [],
                    "edges_covered": ["P2.2"],
                    "edges": ["P3.1", "P3.2"]
                },
            }
        })

        # AND
        placed_plies_on_mould = mould_state.get_placed_plies_on_mould()
        placed_plies = graph_resolver.plies_from(placed_plies_on_mould, graph)

        # WHEN graph.find_plies_to_be_placed is called
        result = graph.find_plies_to_be_placed(placed_plies)

        # THEN result is correct
        assert set(result) == set()


class GetNPreviousPliesTests:
    def test_should_return_none_previous_plies_when_initial_ply_and_depth_of_3_given(self, sample_graph_data):
        # GIVEN
        current_ply_id = "P1"
        depth = 3
        graph = Graph(sample_graph_data)

        # WHEN
        result = graph.get_n_previous_plies(current_ply_id, depth)

        # THEN result is correct
        assert result == set()

    def test_should_return_none_previous_plies_when_initial_ply_and_depth_of_1_given(self, sample_graph_data):
        # GIVEN
        current_ply_id = "P1"
        depth = 1
        graph = Graph(sample_graph_data)

        # WHEN
        result = graph.get_n_previous_plies(current_ply_id, depth)

        # THEN result is correct
        assert result == set()

    def test_should_return_none_previous_plies_when_initial_ply_and_depth_of_0_given(self, sample_graph_data):
        # GIVEN
        current_ply_id = "P1"
        depth = 0
        graph = Graph(sample_graph_data)

        # WHEN
        result = graph.get_n_previous_plies(current_ply_id, depth)

        # THEN result is correct
        assert result == set()

    def test_should_return_correct_n_previous_plies_when_second_ply_and_depth_of_3_given(self, sample_graph_data):
        # GIVEN
        current_ply_id = "P2"
        depth = 3
        graph = Graph(sample_graph_data)

        # WHEN
        result = graph.get_n_previous_plies(current_ply_id, depth)

        # THEN result is correct
        assert result == {"P1"}

    def test_should_return_correct_n_previous_plies_when_second_ply_and_depth_of_1_given(self, sample_graph_data):
        # GIVEN
        current_ply_id = "P2"
        depth = 1
        graph = Graph(sample_graph_data)

        # WHEN
        result = graph.get_n_previous_plies(current_ply_id, depth)

        # THEN result is correct
        assert result == {"P1"}

    def test_should_return_none_previous_plies_when_second_ply_and_depth_of_0_given(self, sample_graph_data):
        # GIVEN
        current_ply_id = "P2"
        depth = 0
        graph = Graph(sample_graph_data)

        # WHEN
        result = graph.get_n_previous_plies(current_ply_id, depth)

        # THEN result is correct
        assert result == set()

    def test_should_return_correct_n_previous_plies_when_third_ply_and_depth_of_3_given(self, sample_graph_data):
        # GIVEN
        current_ply_id = "P3"
        depth = 3
        graph = Graph(sample_graph_data)

        # WHEN
        result = graph.get_n_previous_plies(current_ply_id, depth)

        # THEN result is correct
        assert result == {"P1", "P2"}

    def test_should_return_correct_n_previous_plies_when_third_ply_and_depth_of_1_given(self, sample_graph_data):
        # GIVEN
        current_ply_id = "P3"
        depth = 1
        graph = Graph(sample_graph_data)

        # WHEN
        result = graph.get_n_previous_plies(current_ply_id, depth)

        # THEN result is correct
        assert result == {"P2"}

    def test_should_return_none_previous_plies_when_third_ply_and_depth_of_0_given(self, sample_graph_data):
        # GIVEN
        current_ply_id = "P3"
        depth = 0
        graph = Graph(sample_graph_data)

        # WHEN
        result = graph.get_n_previous_plies(current_ply_id, depth)

        # THEN result is correct
        assert result == set()

    def test_should_return_correct_n_previous_plies_when_third_ply_and_depth_of_more_then_plies_in_a_pallet_given(
            self, sample_graph_data):
        # GIVEN
        current_ply_id = "P3"
        depth = 5
        graph = Graph(sample_graph_data)

        # WHEN
        result = graph.get_n_previous_plies(current_ply_id, depth)

        # THEN result is correct
        assert result == {"P1", "P2"}

    def test_should_return_none_previous_plies_when_next_dependent_pallet_first_ply_and_depth_of_0_given(
            self, sample_graph_data):
        # GIVEN
        current_ply_id = "T1"
        depth = 0
        graph = Graph(sample_graph_data)

        # WHEN
        result = graph.get_n_previous_plies(current_ply_id, depth)

        # THEN result is correct
        assert result == set()

    def test_should_return_correct_n_previous_plies_when_next_dependent_pallet_first_ply_and_depth_of_1_given(
            self, sample_graph_data):
        # GIVEN
        current_ply_id = "T1"
        depth = 1
        graph = Graph(sample_graph_data)

        # WHEN
        result = graph.get_n_previous_plies(current_ply_id, depth)

        # THEN result is correct
        assert result == {"P1", "P2"}

    def test_should_return_correct_n_previous_plies_when_next_dependent_pallet_first_ply_and_depth_of_3_given(
            self, sample_graph_data):
        # GIVEN
        current_ply_id = "T1"
        depth = 3
        graph = Graph(sample_graph_data)

        # WHEN
        result = graph.get_n_previous_plies(current_ply_id, depth)

        # THEN result is correct
        assert result == {"P1", "P2"}


class GetAllDependentPliesOnPlyTests:
    def test_should_return_empty_list_when_none_given(self):
        # GIVEN
        graph_data = {
            "plies": {
                "P1": {"previous_plies": [], "edges": ["P1.1", "P1.2"]},
                "P2": {"previous_plies": ["P1"], "edges": ["P2.1", "P2.2"]},
                "P3": {"previous_plies": ["P2"], "edges": ["P3.1", "P3.2"]}
            }
        }
        ply_id = None
        graph = Graph(graph_data)

        # WHEN
        result = graph.get_all_dependent_plies_on_ply(ply_id)

        # THEN result is correct
        assert result == []

    def test_should_return_empty_list_when_empty_string_given(self):
        # GIVEN
        graph_data = {
            "plies": {
                "P1": {"previous_plies": [], "edges": ["P1.1", "P1.2"]},
                "P2": {"previous_plies": ["P1"], "edges": ["P2.1", "P2.2"]},
                "P3": {"previous_plies": ["P2"], "edges": ["P3.1", "P3.2"]}
            }
        }
        ply_id = ""
        graph = Graph(graph_data)

        # WHEN
        result = graph.get_all_dependent_plies_on_ply(ply_id)

        # THEN result is correct
        assert result == []

    def test_should_return_empty_list_when_invalid_ply_given(self):
        # GIVEN
        graph_data = {
            "plies": {
                "P1": {"previous_plies": [], "edges": ["P1.1", "P1.2"]},
                "P2": {"previous_plies": ["P1"], "edges": ["P2.1", "P2.2"]},
                "P3": {"previous_plies": ["P2"], "edges": ["P3.1", "P3.2"]}
            }
        }
        ply_id = "INVALID"
        graph = Graph(graph_data)

        # WHEN
        result = graph.get_all_dependent_plies_on_ply(ply_id)

        # THEN result is correct
        assert result == []

    def test_should_return_empty_list_when_graph_plies_empty(self):
        # GIVEN
        graph_data = {
            "plies": {}
        }
        ply_id = "P1"
        graph = Graph(graph_data)

        # WHEN
        result = graph.get_all_dependent_plies_on_ply(ply_id)

        # THEN result is correct
        assert result == []

    def test_should_return_plies_in_correct_order_when_initial_ply_given(self):
        # GIVEN
        graph_data = {
            "plies": {
                "P1": {"previous_plies": [], "edges": ["P1.1", "P1.2"]},
                "P2": {"previous_plies": ["P1"], "edges": ["P2.1", "P2.2"]},
                "P3": {"previous_plies": ["P2"], "edges": ["P3.1", "P3.2"]},
                "P4": {"previous_plies": ["P3"], "edges": ["P4.1", "P4.2"]},
                "P5": {"previous_plies": ["P4"], "edges": ["P5.1", "P5.2"]},
                "P6": {"previous_plies": ["P5"], "edges": ["P6.1", "P6.2"]},
            }
        }
        ply_id = "P1"
        graph = Graph(graph_data)

        # WHEN
        result = graph.get_all_dependent_plies_on_ply(ply_id)

        # THEN result is correct
        assert result == ["P2", "P3", "P4", "P5", "P6"]

    def test_should_return_plies_in_correct_order_when_middle_ply_given(self):
        # GIVEN
        graph_data = {
            "plies": {
                "P1": {"previous_plies": [], "edges": ["P1.1", "P1.2"]},
                "P2": {"previous_plies": ["P1"], "edges": ["P2.1", "P2.2"]},
                "P3": {"previous_plies": ["P2"], "edges": ["P3.1", "P3.2"]},
                "P4": {"previous_plies": ["P3"], "edges": ["P4.1", "P4.2"]},
                "P5": {"previous_plies": ["P4"], "edges": ["P5.1", "P5.2"]},
                "P6": {"previous_plies": ["P5"], "edges": ["P6.1", "P6.2"]},
            }
        }
        ply_id = "P3"
        graph = Graph(graph_data)

        # WHEN
        result = graph.get_all_dependent_plies_on_ply(ply_id)

        # THEN result is correct
        assert result == ["P4", "P5", "P6"]

    def test_should_return_correct_plies_when_middle_initial_ply_given(self):
        # GIVEN
        graph_data = {
            "plies": {
                "P1": {"previous_plies": [], "edges": ["P1.1", "P1.2"]},
                "P2": {"previous_plies": ["P1"], "edges": ["P2.1", "P2.2"]},
                "P3": {"previous_plies": ["P2"], "edges": ["P3.1", "P3.2"]},
                "P4": {"previous_plies": [], "edges": ["P4.1", "P4.2"]},
                "P5": {"previous_plies": ["P4"], "edges": ["P5.1", "P5.2"]},
                "P6": {"previous_plies": ["P5"], "edges": ["P6.1", "P6.2"]},
            }
        }
        ply_id = "P4"
        graph = Graph(graph_data)

        # WHEN
        result = graph.get_all_dependent_plies_on_ply(ply_id)

        # THEN result is correct
        assert result == ["P5", "P6"]

    def test_should_return_empty_set_when_last_ply_without_dependants_given(self):
        # GIVEN
        graph_data = {
            "plies": {
                "P1": {"previous_plies": [], "edges": ["P1.1", "P1.2"]},
                "P2": {"previous_plies": ["P1"], "edges": ["P2.1", "P2.2"]},
                "P3": {"previous_plies": ["P2"], "edges": ["P3.1", "P3.2"]},
                "P4": {"previous_plies": ["P3"], "edges": ["P4.1", "P4.2"]},
                "P5": {"previous_plies": ["P4"], "edges": ["P5.1", "P5.2"]},
                "P6": {"previous_plies": ["P5"], "edges": ["P6.1", "P6.2"]},
            }
        }
        ply_id = "P6"
        graph = Graph(graph_data)

        # WHEN
        result = graph.get_all_dependent_plies_on_ply(ply_id)

        # THEN result is correct
        assert result == []

    def test_should_return_empty_set_when_middle_ply_without_dependants_given(self):
        # GIVEN
        graph_data = {
            "plies": {
                "P1": {"previous_plies": [], "edges": ["P1.1", "P1.2"]},
                "P2": {"previous_plies": ["P1"], "edges": ["P2.1", "P2.2"]},
                "P3": {"previous_plies": ["P2"], "edges": ["P3.1", "P3.2"]},
                "P4": {"previous_plies": [], "edges": ["P4.1", "P4.2"]},
                "P5": {"previous_plies": ["P4"], "edges": ["P5.1", "P5.2"]},
                "P6": {"previous_plies": ["P5"], "edges": ["P6.1", "P6.2"]},
            }
        }
        ply_id = "P3"
        graph = Graph(graph_data)

        # WHEN
        result = graph.get_all_dependent_plies_on_ply(ply_id)

        # THEN result is correct
        assert result == []

    @pytest.mark.parametrize(
        "ply_id_undo_to, expected_result",
        [
            ("P1", ["P2", "P3"]),
            ("P2", ["P3"]),
            ("P3", []),
            ("P4", ["P5", "P3", "P6"]),
            ("P5", ["P3", "P6"]),
            ("P6", []),
        ]
    )
    def test_should_return_correct_result_when_graph_with_multiple_independent_plies_given(
            self, ply_id_undo_to, expected_result):
        # GIVEN
        graph_data = {
            "plies": {
                "P1": {"previous_plies": [], "edges": ["P1.1", "P1.2"]},
                "P2": {"previous_plies": ["P1"], "edges": ["P2.1", "P2.2"]},
                "P3": {"previous_plies": ["P2", "P4", "P5"], "edges": ["P3.1", "P3.2"]},
                "P4": {"previous_plies": [], "edges": ["P4.1", "P4.2"]},
                "P5": {"previous_plies": ["P4"], "edges": ["P5.1", "P5.2"]},
                "P6": {"previous_plies": ["P5"], "edges": ["P6.1", "P6.2"]},
            }
        }
        graph = Graph(graph_data)

        # WHEN
        result = graph.get_all_dependent_plies_on_ply(ply_id_undo_to)

        # THEN result is correct
        assert result == expected_result

    @pytest.mark.parametrize(
        "ply_id_undo_to, expected_result",
        [
            ("P1", ["P2", "P3", "P4", "P6", "P5", "P7", "P8", "P11", "P9", "P10"]),
            ("P2", []),
            ("P3", ["P6", "P7", "P9", "P10", "P11"]),
            ("P4", ["P5", "P7", "P8", "P11"]),
            ("P5", ["P7", "P8", "P11"]),
            ("P6", ["P9", "P10"]),
            ("P7", ["P11"]),
            ("P8", []),
            ("P9", []),
            ("P10", []),
            ("P11", []),
        ]
    )
    def test_should_return_correct_result_when_graph_plies_with_multiple_mixed_dependents_given(
            self, ply_id_undo_to, expected_result):
        # GIVEN
        graph_data = {
            "plies": {
                "P1": {"previous_plies": [], "edges": ["P1.1", "P1.2"]},
                "P2": {"previous_plies": ["P1"], "edges": ["P2.1", "P2.2"]},
                "P3": {"previous_plies": ["P1"], "edges": ["P3.1", "P3.2"]},
                "P4": {"previous_plies": ["P1"], "edges": ["P4.1", "P4.2"]},
                "P5": {"previous_plies": ["P4"], "edges": ["P5.1", "P5.2"]},
                "P6": {"previous_plies": ["P1", "P3"], "edges": ["P6.1", "P6.2"]},
                "P7": {"previous_plies": ["P3", "P5"], "edges": ["P7.1", "P7.2"]},
                "P8": {"previous_plies": ["P5"], "edges": ["P8.1", "P8.2"]},
                "P9": {"previous_plies": ["P6"], "edges": ["P9.1", "P9.2"]},
                "P10": {"previous_plies": ["P6"], "edges": ["P10.1", "P10.2"]},
                "P11": {"previous_plies": ["P7"], "edges": ["P11.1", "P11.2"]},
            }
        }
        graph = Graph(graph_data)

        # WHEN
        result = graph.get_all_dependent_plies_on_ply(ply_id_undo_to)

        # THEN result is correct
        assert result == expected_result
