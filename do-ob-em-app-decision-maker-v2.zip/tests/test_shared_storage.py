# pylint: disable=protected-access, missing-module-docstring, missing-class-docstring, missing-function-docstring, duplicate-code, line-too-long, too-few-public-methods, no-self-use, too-many-locals, too-many-lines
import json
from unittest.mock import call, patch

import pytest
from _pytest.python_api import raises

from app.models.state.edge_cam_state import EdgeCamState
from app.models.state.edge_state import EdgeState
from app.models.state.ply_state import PlyState
from app.models.state.ply_state_enum import PlyStateEnum
from app.shared_storage import SharedStorage


@patch("app.config.MOULD_ID", "mould_id")
@patch("app.config.DEVICE_MODULE_ID", "device_module_id")
@pytest.mark.xfail(reason="Often for unknown reason Azure pipeline tests run will fail due to testcontainers used here")
class SharedStorageWithEtcdContainersTests:
    def test_watch_prefix_should_watch_key_prefix_and_call_handler_function_on_put_event_for_given_key_prefix(
            self, mocker, etcd_container):
        with etcd_container:
            # GIVEN
            shared_storage = SharedStorage(etdc_url=etcd_container.get_host_port())
            key = "/moulds/mould_id"
            value = {"sample": "data"}

            # AND handler to call back on put events
            handler = mocker.stub(name="handle_global_mould_state_update_stub")

            # AND key prefix watcher
            key_prefix = key[0:key.rindex("/")]
            shared_storage.watch_prefix(key_prefix, handler)

            # WHEN shared_storage.put_key is called
            shared_storage.put_key(key, value)

            # THEN value is stored in etcd
            result = shared_storage.get_values_by_prefix(key_prefix)
            assert result == {key: value}

            # AND handler is called with correct argument
            assert handler.call_count == 1
            handler_arg = handler.call_args.args[0]
            assert handler_arg.events[0].key.decode("utf-8") == key
            assert handler_arg.events[0].value.decode("utf-8") == json.dumps(value)

            # AND watcher is saved
            assert shared_storage._watchers == {key_prefix: 0}

    def test_watch_prefix_should_watch_key_prefix_and_not_call_handler_function_when_no_put_events_for_given_key_prefix(
            self, mocker, etcd_container):
        with etcd_container:
            # GIVEN
            shared_storage = SharedStorage(etdc_url=etcd_container.get_host_port())
            key = "/moulds/mould_id"
            key_prefix = key[0:key.rindex("/")]
            other_key = "other_key"
            value = {"sample": "data"}

            # AND handler to call back on put events
            handler = mocker.stub(name="handle_global_mould_state_update_stub")

            # AND key prefix watcher
            shared_storage.watch_prefix(key_prefix, handler)

            # WHEN shared_storage.put_key is called
            shared_storage.put_key(other_key, value)

            # THEN value is stored in etcd
            result = shared_storage.get_values_by_prefix(other_key)
            assert result == {other_key: value}

            # AND handler is not called
            assert handler.call_count == 0

    def test_watch_prefix_should_call_handler_function_on_put_event_with_correct_argument(
            self, mocker, etcd_container):
        with etcd_container:
            # GIVEN
            shared_storage = SharedStorage(etdc_url=etcd_container.get_host_port())
            key = "/moulds/mould_id"
            value = "sample data"

            # AND handler to call back on put events
            handler = mocker.stub(name="handle_global_mould_state_update_stub")

            # AND key prefix watcher
            shared_storage.watch_prefix(key, handler)

            # WHEN shared_storage.put_key is called
            shared_storage.put_key(key, value)

            # THEN value is stored in etcd
            assert shared_storage.get_value_by_complete_key(key) == value

            # AND handler is called with correct argument
            assert handler.call_count == 1
            handler_arg = handler.call_args.args[0]
            assert handler_arg.events[0].key.decode("utf-8") == key
            assert handler_arg.events[0].value.decode("utf-8") == value

    def test_watch_prefix_should_call_handler_function_on_delete_event_with_correct_argument(
            self, mocker, etcd_container):
        with etcd_container:
            # GIVEN
            shared_storage = SharedStorage(etdc_url=etcd_container.get_host_port())
            key = "/moulds/mould_id"
            value = "sample data"

            # AND handler to call back on put events
            handler = mocker.stub(name="handle_global_mould_state_update_stub")

            # AND key prefix watcher
            shared_storage.watch_prefix(key, handler)

            # WHEN shared_storage.put_key is called
            shared_storage.put_key(key, value)

            # AND value is stored in etcd
            assert shared_storage.get_value_by_complete_key(key) == value

            # THEN value is stored in etcd
            result = shared_storage._delete(key)
            assert result is True

            # AND value is no longer stored in etcd
            assert shared_storage.get_value_by_complete_key(key) is None

            # AND handler is called with correct argument on second call
            assert handler.call_count == 2
            handler_arg = handler.call_args.args[0]
            assert handler_arg.events[0].key.decode("utf-8") == key
            assert handler_arg.events[0].value.decode("utf-8") == ""

    def test_watch_key_should_watch_key_and_call_handler_function_on_put_event_for_given_key(self, mocker, etcd_container):
        with etcd_container:
            # GIVEN
            shared_storage = SharedStorage(etdc_url=etcd_container.get_host_port())
            key = "/moulds/mould_id"
            value = {"sample": "data"}

            # AND handler to call back on put events
            handler = mocker.stub(name="handle_global_mould_state_update_stub")

            # AND key watcher
            shared_storage.watch_key(key, handler)

            # WHEN shared_storage.put_key is called
            shared_storage.put_key(key, value)

            # THEN value is stored in etcd
            result = shared_storage.get_values_by_prefix(key)
            assert result == {key: value}

            # AND handler is called with correct argument
            assert handler.call_count == 1
            handler_arg = handler.call_args.args[0]
            assert handler_arg.events[0].key.decode("utf-8") == key
            assert handler_arg.events[0].value.decode("utf-8") == json.dumps(value)

            # AND watcher is saved
            assert shared_storage._watchers == {key: 0}

    def test_watch_key_should_watch_key_and_not_call_handler_function_when_no_put_events_for_given_key(
            self, mocker, etcd_container):
        with etcd_container:
            # GIVEN
            shared_storage = SharedStorage(etdc_url=etcd_container.get_host_port())
            key = "/moulds/mould_id"
            other_key = "other_key"
            value = {"sample": "data"}

            # AND handler to call back on put events
            handler = mocker.stub(name="handle_global_mould_state_update_stub")

            # AND key watcher
            shared_storage.watch_key(key, handler)

            # WHEN shared_storage.put_key is called
            shared_storage.put_key(other_key, value)

            # THEN value is stored in etcd
            result = shared_storage.get_values_by_prefix(other_key)
            assert result == {other_key: value}

            # AND handler is not called
            assert handler.call_count == 0

    def test_unwatch_prefix_should_unwatch_key_prefix(self, mocker, etcd_container):
        with etcd_container:
            # GIVEN
            shared_storage = SharedStorage(etdc_url=etcd_container.get_host_port())
            key = "/moulds/mould_id"
            key_prefix = key[0:key.rindex("/")]
            value = {"sample": "data"}
            other_key_prefix = "other_key_prefix"

            # AND handler to call back on put events
            handler = mocker.stub(name="handle_global_mould_state_update_stub")

            # AND key prefix watchers
            shared_storage.watch_prefix(key_prefix, handler)
            shared_storage.watch_prefix(other_key_prefix, handler)

            # AND watchers are saved
            assert shared_storage._watchers == {key_prefix: 0, other_key_prefix: 1}

            # WHEN shared_storage.unwatch_prefix is called
            shared_storage.unwatch_prefix(key_prefix)

            # AND shared_storage.put_key is called
            shared_storage.put_key(key, value)

            # THEN value is stored in etcd
            result = shared_storage.get_values_by_prefix(key_prefix)
            assert result == {key: value}

            # AND handler is not called
            assert handler.call_count == 0

            # AND watcher for key_prefix is removed
            assert shared_storage._watchers == {other_key_prefix: 1}

    def test_unwatch_prefix_should_raise_exception_when_given_prefix_is_not_watched(self, mocker, etcd_container):
        with etcd_container:
            # GIVEN
            shared_storage = SharedStorage(etdc_url=etcd_container.get_host_port())
            key = "/moulds/mould_id"
            key_prefix = key[0:key.rindex("/")]
            non_existing_key_prefix = "non_existing_key_prefix"

            # AND handler to call back on put events
            handler = mocker.stub(name="handle_global_mould_state_update_stub")

            # AND key prefix watcher
            shared_storage.watch_prefix(key_prefix, handler)

            # AND watcher are saved
            assert shared_storage._watchers == {key_prefix: 0}

            # WHEN shared_storage.unwatch_prefix is called, assert that an exception is raised
            exc_info = raises(
                Exception,
                shared_storage.unwatch_prefix,
                non_existing_key_prefix
            )

            # THEN an exception of type ValueError is raised with correct message
            assert exc_info.type is ValueError
            assert f"Failed to unwatch key prefix: {non_existing_key_prefix};\n" in exc_info.value.args[0]

            # AND watcher for key_prefix is not removed
            assert shared_storage._watchers == {key_prefix: 0}

    def test_get_values_by_prefix_should_return_complete_key_to_value_when_key_prefix_given(self, etcd_container):
        with etcd_container:
            # GIVEN
            shared_storage = SharedStorage(etdc_url=etcd_container.get_host_port())
            key = "/moulds/mould_id/plies/ply_1"
            key_prefix = key[0:key.rindex("/")]
            value = {"sample": "data"}

            # AND key value pair stored into etcd
            shared_storage.put_key(key, value)

            # WHEN shared_storage.get_by_prefix is called
            result = shared_storage.get_values_by_prefix(key_prefix)

            # THEN correct result returned
            assert result == {key: value}

    def test_get_values_by_prefix_should_return_multiple_key_to_value_pairs_when_mould_key_prefix_given(self,
                                                                                                        etcd_container):
        with etcd_container:
            # GIVEN
            shared_storage = SharedStorage(etdc_url=etcd_container.get_host_port())
            mould_key = "/moulds/mould_id"
            ply_1 = PlyState(
                "ply_1",
                {
                    EdgeState("edge_1", {EdgeCamState("cam_1"), EdgeCamState("cam_2")}),
                    EdgeState("edge_2", {EdgeCamState("cam_3"), EdgeCamState("cam_4")}),
                },
                PlyStateEnum.PLACED,
                PlyStateEnum.EXPECTED,
                "cam:cam_1",
                "device_module_id"
            )
            ply_2 = PlyState(
                "ply_2",
                {
                    EdgeState("edge_3", {EdgeCamState("cam_5"), EdgeCamState("cam_6")}),
                    EdgeState("edge_4", {EdgeCamState("cam_7"), EdgeCamState("cam_8")}),
                },
                PlyStateEnum.PLACED,
                PlyStateEnum.EXPECTED,
                "cam:cam_2",
                "device_module_id"
            )
            ply_key_1 = "/plies/" + ply_1.id
            ply_key_2 = "/plies/" + ply_2.id
            ply_1_serialized = ply_1.serialize()
            ply_2_serialized = ply_2.serialize()

            # AND multiple key value pairs stored into etcd
            shared_storage.put_key(mould_key + ply_key_1, ply_1_serialized)
            shared_storage.put_key(mould_key + ply_key_2, ply_2_serialized)

            # WHEN shared_storage.get_by_prefix is called
            result = shared_storage.get_values_by_prefix(mould_key)

            # THEN correct result returned
            assert result == {
                "/moulds/mould_id/plies/ply_1": ply_1_serialized,
                "/moulds/mould_id/plies/ply_2": ply_2_serialized,
            }

    def test_get_values_by_prefix_should_return_single_value_when_a_complete_key_to_a_single_of_few_stored_items_given(
            self, etcd_container, sample_mould_state_plies):
        with etcd_container:
            # GIVEN
            shared_storage = SharedStorage(etdc_url=etcd_container.get_host_port())
            mould_state_key = "/moulds/mould_id"
            ply_key = mould_state_key + "/plies/P1"

            # AND multiple plies stored into etcd
            shared_storage.update_mould_plies(sample_mould_state_plies)

            # WHEN shared_storage.get_values_by_prefix is called
            result = shared_storage.get_values_by_prefix(ply_key)

            # THEN correct result returned
            assert result == {
                ply_key: {"edges": [{"cams": [{"cam_id": "cam1", "state": "DETECTED"}],
                                     "edge_id": "P1.1",
                                     "state": "DETECTED"},
                                    {"cams": [{"cam_id": "cam1", "state": "DETECTED"}],
                                     "edge_id": "P1.2",
                                     "state": "COVERED"}],
                          "ply_id": "P1",
                          "previous_state": "PLACED",
                          "source_device": "device_module_id",
                          "state": "PLACED",
                          "updated_by": "ply:P2"}}

    def test_get_values_by_prefix_should_return_complete_key_to_value_when_complete_key_given(self, etcd_container):
        with etcd_container:
            # GIVEN
            shared_storage = SharedStorage(etdc_url=etcd_container.get_host_port())
            key = "/moulds/mould_id"
            value = {"sample": "data"}

            # AND key value pair stored into etcd
            shared_storage.put_key(key, value)

            # WHEN shared_storage.get_by_prefix is called
            result = shared_storage.get_values_by_prefix(key)

            # THEN correct result returned
            assert result == {key: value}

    def test_get_values_by_prefix_should_return_empty_result_when_value_do_not_exist_by_given_key_prefix(self,
                                                                                                         etcd_container):
        with etcd_container:
            # GIVEN
            shared_storage = SharedStorage(etdc_url=etcd_container.get_host_port())
            key = "non_existing_key"

            # WHEN shared_storage.get_by_prefix is called
            result = shared_storage.get_values_by_prefix(key)

            # THEN correct result returned
            assert result == {}

    def test_get_value_by_complete_key_should_return_value_when_complete_key_given(self, etcd_container):
        with etcd_container:
            # GIVEN
            shared_storage = SharedStorage(etdc_url=etcd_container.get_host_port())
            key = "/moulds/mould_id"
            value = "sample data"

            # AND key value pair stored into etcd
            shared_storage.put_key(key, value)

            # WHEN shared_storage.get_value_by_complete_key is called
            result = shared_storage.get_value_by_complete_key(key)

            # THEN correct result returned
            assert result == value

    def test_get_value_by_complete_key_should_return_none_when_key_prefix_given(self, etcd_container):
        with etcd_container:
            # GIVEN
            shared_storage = SharedStorage(etdc_url=etcd_container.get_host_port())
            key = "/moulds/mould_id"
            key_prefix = key[0:key.rindex("/")]
            value = "sample data"

            # AND key value pair stored into etcd
            shared_storage.put_key(key, value)

            # WHEN shared_storage.get_value_by_complete_key is called
            result = shared_storage.get_value_by_complete_key(key_prefix)

            # THEN correct result returned
            assert result is None

    def test_get_by_complete_key_should_return_single_value_when_a_single_key_of_few_stored_items_given(
            self, etcd_container):
        with etcd_container:
            # GIVEN
            shared_storage = SharedStorage(etdc_url=etcd_container.get_host_port())
            mould_state_key = "/moulds/mould_id"
            item_key_1 = "/items/item_1"
            item_key_2 = "/items/item_2"
            item_value_1 = "sample data 1"
            item_value_2 = "sample data 2"

            # AND multiple items stored into etcd
            shared_storage.put_key(mould_state_key + item_key_1, item_value_1)
            shared_storage.put_key(mould_state_key + item_key_2, item_value_2)

            # WHEN shared_storage.get_values_by_prefix is called
            result = shared_storage.get_value_by_complete_key(mould_state_key + item_key_1)

            # THEN correct result returned
            assert result == item_value_1

    def test_put_key_should_store_new_key_and_value_pair(self, etcd_container):
        with etcd_container:
            # GIVEN
            shared_storage = SharedStorage(etdc_url=etcd_container.get_host_port())
            key = "/moulds/mould_id"
            value = {"sample": "data"}

            # WHEN shared_storage.put_key is called
            shared_storage.put_key(key, value)

            # THEN correct value by key is found in etcd
            result = shared_storage.get_values_by_prefix(key)
            assert result == {key: value}

    def test_put_key_should_update_key_and_value_pair(self, etcd_container):
        with etcd_container:
            # GIVEN
            shared_storage = SharedStorage(etdc_url=etcd_container.get_host_port())
            key = "/moulds/mould_id"
            value = {"sample": "data"}
            update = {
                "mould_id": "mould_id",
                "blade_revision": "blade_revision",
                "plies": {}
            }

            # AND key value pair stored into etcd
            shared_storage.put_key(key, value)

            # WHEN shared_storage.put_key is called
            shared_storage.put_key(key, update)

            # THEN updated value by key is retrieved from etcd
            result = shared_storage.get_values_by_prefix(key)
            assert result == {key: update}

    def test_put_key_and_get_value_by_complete_key_should_store_and_retreive_value_of_str_type(self, etcd_container):
        with etcd_container:
            # GIVEN
            shared_storage = SharedStorage(etdc_url=etcd_container.get_host_port())
            key = "/moulds/mould_id"
            value = "sample data"

            # AND key value pair stored into etcd
            shared_storage.put_key(key, value)

            # WHEN shared_storage.get_value_by_complete_key is called
            result = shared_storage.get_value_by_complete_key(key)

            # THEN correct result returned
            assert result == value

    def test_delete_should_remove_value_and_return_true(self, etcd_container):
        with etcd_container:
            # GIVEN
            shared_storage = SharedStorage(etdc_url=etcd_container.get_host_port())
            key = "/moulds/mould_id"
            value = "sample data"

            # AND key value pair stored into etcd
            shared_storage.put_key(key, value)
            assert shared_storage.get_value_by_complete_key(key) != {}

            # WHEN
            result = shared_storage._delete(key)

            # THEN
            assert result is True
            assert shared_storage.get_value_by_complete_key(key) is None

    def test_delete_prefix_should_remove_all_items_by_given_prefix(self, etcd_container):
        with etcd_container:
            # GIVEN
            shared_storage = SharedStorage(etdc_url=etcd_container.get_host_port())
            mould_state_key = "/moulds/mould_id"
            item_key_1 = "/items/item_1"
            item_key_2 = "/items/item_2"
            item_value_1 = {"sample_1": "data_1"}
            item_value_2 = {"sample_2": "data_2"}

            # AND multiple items stored into etcd
            shared_storage.put_key(mould_state_key + item_key_1, item_value_1)
            shared_storage.put_key(mould_state_key + item_key_2, item_value_2)
            result = shared_storage.get_values_by_prefix(mould_state_key)
            assert result == {
                mould_state_key + item_key_1: item_value_1,
                mould_state_key + item_key_2: item_value_2
            }

            # WHEN
            shared_storage.delete_prefix(mould_state_key)

            # THEN correct result returned
            assert shared_storage.get_values_by_prefix(mould_state_key) == {}

    def test_watch_mould_plies_updates_should_call_handler_with_correct_arguments_when_mould_state_updated(
            self, mocker, etcd_container):
        with etcd_container:
            # GIVEN
            shared_storage = SharedStorage(etdc_url=etcd_container.get_host_port())
            ply_id = "ply123"
            key = f"/moulds/mould_id/plies/{ply_id}"
            value = {
                "id": ply_id
            }

            # AND handler to call back on put events
            global_mould_state_update_callback = mocker.stub(name="global_mould_state_update_callback")
            handle_global_mould_changes = mocker.patch.object(shared_storage, "_handle_global_mould_changes")

            # WHEN shared_storage.watch_mould_plies_updates is called
            shared_storage.watch_mould_plies_updates(global_mould_state_update_callback)

            # AND shared_storage.put_key is called
            shared_storage.put_key(key, value)

            # THEN global_mould_state_update_callback callback is set
            assert shared_storage._global_mould_state_plies_update_callback is global_mould_state_update_callback

            # AND value is stored in etcd
            result = shared_storage.get_values_by_prefix(key)
            assert result == {key: value}

            # AND handle_global_mould_changes is called with correct argument
            assert handle_global_mould_changes.call_count == 1
            handler_arg = handle_global_mould_changes.call_args.args[0]
            assert handler_arg.events[0].key.decode("utf-8") == key
            assert handler_arg.events[0].value.decode("utf-8") == '{"id": "ply123"}'

    def test_watch_mould_plies_updates_should_not_call_handler_when_different_mould_state_updated(
            self, mocker, etcd_container):
        with etcd_container:
            # GIVEN
            shared_storage = SharedStorage(etdc_url=etcd_container.get_host_port())
            mould_state_key = "/moulds/mould_id"
            different_mould_state_key = f"/moulds/different_mould_id"
            ply_state = {
                "id": "ply001"
            }

            # AND provide mock callback
            global_mould_state_update_callback = mocker.stub(name="global_mould_state_update_callback")

            # WHEN shared_storage.watch_mould_plies_updates is called
            shared_storage.watch_mould_plies_updates(global_mould_state_update_callback)

            # AND updated ply state is put
            shared_storage.put_key(different_mould_state_key, ply_state)

            # THEN global_mould_state_update_callback callback is set and shared_storage.watch_prefix called
            assert shared_storage._global_mould_state_plies_update_callback is global_mould_state_update_callback

            # THEN value is stored in etcd
            result = shared_storage.get_values_by_prefix(mould_state_key)
            assert result == {}

            # AND global_mould_state_update_callback is never called
            assert global_mould_state_update_callback.call_count == 0

    def test_should_remove_mould_state_plies_and_instructions(self, etcd_container):
        with etcd_container:
            # GIVEN
            shared_storage = SharedStorage(etdc_url=etcd_container.get_host_port())
            mould_plies_key_prefix = "/moulds/mould_id/plies"
            mould_instructions_key_prefix = "/moulds/mould_id/instructions"
            item_key_1 = "/items/item_1"
            item_key_2 = "/items/item_2"
            item_value_1 = {"sample_1": "data_1"}
            item_value_2 = {"sample_2": "data_2"}

            # AND multiple items stored into etcd
            shared_storage.put_key(mould_plies_key_prefix + item_key_1, item_value_1)
            shared_storage.put_key(mould_instructions_key_prefix + item_key_2, item_value_2)
            assert shared_storage.get_values_by_prefix(mould_plies_key_prefix) != {}
            assert shared_storage.get_values_by_prefix(mould_instructions_key_prefix) != {}

            # WHEN
            shared_storage.remove_mould_plies()
            shared_storage.remove_mould_instructions()

            # THEN global mould state is cleaned
            assert shared_storage.get_values_by_prefix(mould_plies_key_prefix) == {}
            assert shared_storage.get_values_by_prefix(mould_instructions_key_prefix) == {}

    def test_update_mould_plies_should_publish_each_global_mould_state_plies_update_callback(self, mocker,
                                                                                             etcd_container):
        with etcd_container:
            # GIVEN
            shared_storage = SharedStorage(etdc_url=etcd_container.get_host_port())
            ply1_state = PlyState("ply001")
            ply2_state = PlyState("ply002")
            put_key_mock = mocker.patch.object(shared_storage, "put_key")

            # WHEN shared_storage.update_mould_plies is called
            shared_storage.update_mould_plies({ply1_state, ply2_state})

            # THEN put_key_mock is called twice with correct arguments
            assert put_key_mock.call_count == 2
            actual_calls = put_key_mock.call_args_list
            expected_calls = [
                call(f"/moulds/mould_id/plies/{ply1_state.id}", ply1_state.serialize()),
                call(f"/moulds/mould_id/plies/{ply2_state.id}", ply2_state.serialize()),
            ]
            sorted_actual_calls = sorted([{"key": c[0], "value": c[1]} for c, _ in actual_calls],
                                         key=lambda i: i["key"])
            sorted_expected_calls = sorted(
                [{"key": c[1][0], "value": c[1][1]} for c in expected_calls], key=lambda i: i["key"])
            assert sorted_actual_calls == sorted_expected_calls


class SharedStorageTests:
    def test_put_key_should_raise_exception_when_invalid_data_type_value_given(
            self, mocker):
        # GIVEN
        mocker.patch("app.shared_storage.etcd3")
        shared_storage = SharedStorage()
        key = "/moulds/mould_id"
        value = ["invalid_data_type"]

        # WHEN
        with pytest.raises(Exception) as exc_info:
            shared_storage.put_key(key, value)

        # THEN
        assert exc_info.type is NotImplementedError
        error_message = f"put_key method supports only dict and str types, given type: {type(value)}"
        assert exc_info.value.args[0] == error_message
