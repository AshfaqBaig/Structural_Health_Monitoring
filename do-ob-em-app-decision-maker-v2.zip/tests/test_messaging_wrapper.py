# pylint: disable=protected-access, missing-module-docstring, missing-class-docstring, missing-function-docstring, duplicate-code, line-too-long, too-few-public-methods, no-self-use, too-many-locals, too-many-lines
from unittest.mock import AsyncMock

import pytest
from azure.iot.device import MethodResponse

from app import routes_constants
from app.messaging_wrapper import MessagingWrapper
from app.models.payload_metadata import PayloadMetadata


class MessagingWrapperTests:
    @pytest.mark.asyncio
    async def test_send_c2dm_response_should_send_response_via_hub(self, mocker):
        # GIVEN
        module_client = mocker.patch("app.messaging_wrapper.IoTHubModuleClient", new_callable=AsyncMock)
        messaging_wrapper = MessagingWrapper(module_client)
        response = MethodResponse("request_id", 200, "payload")

        # WHEN
        await messaging_wrapper.send_c2dm_response(response)

        # THEN
        assert module_client.send_method_response.await_count == 1
        assert module_client.send_method_response.call_count == 1

    @pytest.mark.asyncio
    async def test_send_message_to_default_output_should_send_message_in_json_to_correct_output(
            self, mocker):
        # GIVEN
        module_client = mocker.patch("app.messaging_wrapper.IoTHubModuleClient", new_callable=AsyncMock)
        messaging_wrapper = MessagingWrapper(module_client)
        message = {"a": 1, "b": {"c": "d"}}
        metadata_to_forward = PayloadMetadata(correlation_id="correlation_id", custom_properties="custom_properties")

        # WHEN messaging_wrapper.send_message_to_default_output is called
        await messaging_wrapper.send_message_to_default_output(message, metadata_to_forward)

        # THEN module_client.send_message_to_output was called and awaited once
        module_client.send_message_to_output.assert_called_once()
        module_client.send_message_to_output.assert_awaited_once()

        # AND send_message_to_output was called with two arguments
        call_args = module_client.send_message_to_output.call_args.args
        assert len(call_args) == 2

        # AND correct message was sent in JSON
        expected_message_data = '{"a": 1, "b": {"c": "d"}}'
        actual_message = call_args[0]
        assert actual_message.data == expected_message_data
        assert actual_message.correlation_id == "correlation_id"
        assert actual_message.custom_properties == "custom_properties"

        # AND output_name is correct
        actual_output_name = call_args[1]
        assert actual_output_name == routes_constants.DEFAULT_OUTPUT

    @pytest.mark.asyncio
    async def test_send_message_to_error_output_should_send_message_in_json_to_correct_output(
            self, mocker):
        # GIVEN
        module_client = mocker.patch("app.messaging_wrapper.IoTHubModuleClient", new_callable=AsyncMock)
        messaging_wrapper = MessagingWrapper(module_client)
        message = {"a": 1, "b": {"c": "d"}}
        metadata_to_forward = PayloadMetadata(correlation_id="correlation_id", custom_properties="custom_properties")

        # WHEN messaging_wrapper.send_message_to_error_output is called
        await messaging_wrapper.send_message_to_error_output(message, metadata_to_forward)

        # THEN module_client.send_message_to_output was called and awaited once
        module_client.send_message_to_output.assert_called_once()
        module_client.send_message_to_output.assert_awaited_once()

        # AND send_message_to_output was called with two arguments
        call_args = module_client.send_message_to_output.call_args.args
        assert len(call_args) == 2

        # AND correct message was sent in JSON
        expected_message_data = '{"a": 1, "b": {"c": "d"}}'
        actual_message = call_args[0]
        assert actual_message.data == expected_message_data
        assert actual_message.correlation_id == "correlation_id"
        assert actual_message.custom_properties == "custom_properties"

        # AND output_name is correct
        actual_output_name = call_args[1]
        assert actual_output_name == routes_constants.ERROR_OUTPUT

    @pytest.mark.asyncio
    async def test_send_message_to_feedback_should_send_message_in_json_to_correct_output(
            self, mocker):
        # GIVEN
        module_client = mocker.patch("app.messaging_wrapper.IoTHubModuleClient", new_callable=AsyncMock)
        messaging_wrapper = MessagingWrapper(module_client)
        message = {"a": 1, "b": {"c": "d"}}
        metadata_to_forward = PayloadMetadata(correlation_id="correlation_id", custom_properties="custom_properties")

        # WHEN messaging_wrapper.send_message_to_feedback is called
        await messaging_wrapper.send_message_to_feedback(message, metadata_to_forward)

        # THEN module_client.send_message_to_output was called and awaited once
        module_client.send_message_to_output.assert_called_once()
        module_client.send_message_to_output.assert_awaited_once()

        # AND send_message_to_output was called with two arguments
        call_args = module_client.send_message_to_output.call_args.args
        assert len(call_args) == 2

        # AND correct message was sent in JSON
        expected_message_data = '{"a": 1, "b": {"c": "d"}}'
        actual_message = call_args[0]
        assert actual_message.data == expected_message_data
        assert actual_message.correlation_id == "correlation_id"
        assert actual_message.custom_properties == "custom_properties"

        # AND output_name is correct
        actual_output_name = call_args[1]
        assert actual_output_name == routes_constants.FEEDBACK_OUTPUT

    @pytest.mark.asyncio
    async def test_send_message_to_image_grabber_should_send_message_in_json_to_correct_output(
            self, mocker):
        # GIVEN
        module_client = mocker.patch("app.messaging_wrapper.IoTHubModuleClient", new_callable=AsyncMock)
        messaging_wrapper = MessagingWrapper(module_client)
        message = {"a": 1, "b": {"c": "d"}}
        metadata_to_forward = PayloadMetadata(correlation_id="correlation_id", custom_properties="custom_properties")

        # WHEN messaging_wrapper.send_message_to_image_grabber is called
        await messaging_wrapper.send_message_to_image_grabber(message, metadata_to_forward)

        # THEN module_client.send_message_to_output was called and awaited once
        module_client.send_message_to_output.assert_called_once()
        module_client.send_message_to_output.assert_awaited_once()

        # AND send_message_to_output was called with two arguments
        call_args = module_client.send_message_to_output.call_args.args
        assert len(call_args) == 2

        # AND correct message was sent in JSON
        expected_message_data = '{"a": 1, "b": {"c": "d"}}'
        actual_message = call_args[0]
        assert actual_message.data == expected_message_data
        assert actual_message.correlation_id == "correlation_id"
        assert actual_message.custom_properties == "custom_properties"

        # AND output_name is correct
        actual_output_name = call_args[1]
        assert actual_output_name == routes_constants.START_STREAMING_OUTPUT

    @pytest.mark.asyncio
    async def test_send_message_to_edge_verification_should_send_message_in_json_to_correct_output(
            self, mocker):
        # GIVEN
        module_client = mocker.patch("app.messaging_wrapper.IoTHubModuleClient", new_callable=AsyncMock)
        messaging_wrapper = MessagingWrapper(module_client)
        message = {"a": 1, "b": {"c": "d"}}
        metadata_to_forward = PayloadMetadata(correlation_id="correlation_id", custom_properties="custom_properties")

        # WHEN messaging_wrapper.send_message_to_edge_verification is called
        await messaging_wrapper.send_message_to_edge_verification(message, metadata_to_forward)

        # THEN module_client.send_message_to_output was called and awaited once
        module_client.send_message_to_output.assert_called_once()
        module_client.send_message_to_output.assert_awaited_once()

        # AND send_message_to_output was called with two arguments
        call_args = module_client.send_message_to_output.call_args.args
        assert len(call_args) == 2

        # AND correct message was sent in JSON
        expected_message_data = '{"a": 1, "b": {"c": "d"}}'
        actual_message = call_args[0]
        assert actual_message.data == expected_message_data
        assert actual_message.correlation_id == "correlation_id"
        assert actual_message.custom_properties == "custom_properties"

        # AND output_name is correct
        actual_output_name = call_args[1]
        assert actual_output_name == routes_constants.EDGE_VERIFICATION_OUTPUT

    @pytest.mark.asyncio
    async def test_send_message_to_trace_should_send_message_in_json_to_correct_output(self, mocker):
        # GIVEN
        module_client = mocker.patch("app.messaging_wrapper.IoTHubModuleClient", new_callable=AsyncMock)
        messaging_wrapper = MessagingWrapper(module_client)
        message = {"a": 1, "b": {"c": "d"}}
        metadata_to_forward = PayloadMetadata(correlation_id="correlation_id", custom_properties="custom_properties")

        # WHEN messaging_wrapper.send_message_to_trace is called
        await messaging_wrapper.send_message_to_trace(message, metadata_to_forward)

        # THEN module_client.send_message_to_output was called and awaited once
        module_client.send_message_to_output.assert_called_once()
        module_client.send_message_to_output.assert_awaited_once()

        # AND send_message_to_output was called with two arguments
        call_args = module_client.send_message_to_output.call_args.args
        assert len(call_args) == 2

        # AND correct message was sent in JSON
        expected_message_data = '{"a": 1, "b": {"c": "d"}}'
        actual_message = call_args[0]
        assert actual_message.data == expected_message_data
        assert actual_message.content_type == "decision-maker-trace"
        assert actual_message.correlation_id == "correlation_id"
        assert actual_message.custom_properties == "custom_properties"

        # AND output_name is correct
        actual_output_name = call_args[1]
        assert actual_output_name == routes_constants.TRACE_OUTPUT
