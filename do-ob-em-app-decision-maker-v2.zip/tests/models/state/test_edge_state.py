# pylint: disable=protected-access, missing-module-docstring, missing-class-docstring, missing-function-docstring, duplicate-code, line-too-long, too-few-public-methods, no-self-use, too-many-locals, too-many-lines

from unittest.mock import patch

import pytest

from app.models.state.edge_cam_state import EdgeCamState
from app.models.state.edge_cam_state_enum import EdgeCamStateEnum
from app.models.state.edge_state import EdgeState
from app.models.state.edge_state_enum import EdgeStateEnum


class EdgeStateAndEdgeCamStateTests:

    @patch("app.config.FF_EDGE_DETECTION_STRICT", False)
    @pytest.mark.parametrize(
        "new_cam1_state, expected_cam_updated, expected_edge_updated, expected_edge_state, expected_cam_state",
        [
            (EdgeCamStateEnum.DETECTED, True, True, EdgeStateEnum.DETECTED, EdgeCamStateEnum.DETECTED),
            (EdgeCamStateEnum.MISSING, False, False, EdgeStateEnum.MISSING, EdgeCamStateEnum.NEVER_DETECTED)
        ]
    )
    def test_update_cam_should_work_for_common_scenarios_when_cam_state_changes(self, new_cam1_state,
                                                                                expected_cam_updated,
                                                                                expected_edge_updated,
                                                                                expected_edge_state,
                                                                                expected_cam_state):
        # GIVEN
        edge_state: EdgeState = EdgeState("edge_001")
        edge_state.init_state(["cam01", "cam02"])

        # WHEN edge_cam_state.update_cam is called
        edge_updated, cam_updated = edge_state.update_cam("cam01", new_cam1_state)

        # THEN correct result is returned
        assert cam_updated is expected_cam_updated
        assert edge_updated is expected_edge_updated
        assert edge_state.state is expected_edge_state

        cam01_state: EdgeCamState = next(cam for cam in edge_state.cams if cam.id == "cam01")
        assert cam01_state.state == expected_cam_state
        cam02_state: EdgeCamState = next(cam for cam in edge_state.cams if cam.id == "cam02")
        assert cam02_state.state == EdgeCamStateEnum.NEVER_DETECTED

    @patch("app.config.FF_EDGE_DETECTION_STRICT", False)
    def test_update_cam_should_not_update_edge_state_when_edge_already_detected(self):
        # GIVEN
        edge_state: EdgeState = EdgeState("edge_001", [EdgeCamState("cam01", EdgeCamStateEnum.DETECTED),
                                                       EdgeCamState("cam02", EdgeCamStateEnum.MISSING)],
                                          state=EdgeStateEnum.DETECTED)

        # WHEN edge_cam_state.update_cam is called
        edge_updated, cam_updated = edge_state.update_cam("cam02", EdgeCamStateEnum.DETECTED)

        # THEN correct result is returned
        assert cam_updated is True
        assert edge_updated is False
        assert edge_state.state is EdgeStateEnum.DETECTED

        cam01_state: EdgeCamState = next(cam for cam in edge_state.cams if cam.id == "cam01")
        assert cam01_state.state == EdgeCamStateEnum.DETECTED
        cam02_state: EdgeCamState = next(cam for cam in edge_state.cams if cam.id == "cam02")
        assert cam02_state.state == EdgeCamStateEnum.DETECTED

    @patch("app.config.FF_EDGE_DETECTION_STRICT", False)
    def test_update_cam_should_not_update_edge_state_when_edge_missing(self):
        # GIVEN
        edge_state: EdgeState = EdgeState("edge_001")
        edge_state.init_state(["cam01", "cam02"])

        # WHEN edge_cam_state.update_cam is called
        edge_updated, cam_updated = edge_state.update_cam("cam01", EdgeCamStateEnum.MISSING)

        # THEN correct result is returned
        assert cam_updated is False
        assert edge_updated is False
        assert edge_state.state is EdgeStateEnum.MISSING

        cam01_state: EdgeCamState = next(cam for cam in edge_state.cams if cam.id == "cam01")
        assert cam01_state.state == EdgeCamStateEnum.NEVER_DETECTED
        cam02_state: EdgeCamState = next(cam for cam in edge_state.cams if cam.id == "cam02")
        assert cam02_state.state == EdgeCamStateEnum.NEVER_DETECTED

    @patch("app.config.FF_EDGE_DETECTION_STRICT", False)
    def test_update_cam_should_throw_exception_when_edge_state_invalid(self):
        # GIVEN
        edge_state: EdgeState = EdgeState("edge_001")
        edge_state.init_state(["cam01", "cam02"])

        # WHEN edge_cam_state.update_cam is called
        with pytest.raises(Exception) as value_error_exc:
            edge_state.update_cam("cam01", "invalid")

        # THEN ValueError exception is raised
        assert value_error_exc.type is ValueError
        assert "Failed to find cam transition rule for" in value_error_exc.value.args[0]

    @patch("app.config.FF_EDGE_DETECTION_STRICT", True)
    @pytest.mark.parametrize(
        "new_cam1_state, expected_cam_updated, expected_edge_updated, expected_edge_state, expected_cam1_state",
        [
            (EdgeCamStateEnum.DETECTED, True, False, EdgeStateEnum.MISSING, EdgeCamStateEnum.DETECTED),
            (EdgeCamStateEnum.MISSING, False, False, EdgeStateEnum.MISSING, EdgeCamStateEnum.NEVER_DETECTED)
        ]
    )
    def test_update_cam_should_not_update_edge_state_when_edge_not_detected_on_all_cams_in_strict_mode(self,
                                                                                                       new_cam1_state,
                                                                                                       expected_cam_updated,
                                                                                                       expected_edge_updated,
                                                                                                       expected_edge_state,
                                                                                                       expected_cam1_state
                                                                                                       ):
        # GIVEN
        edge_state: EdgeState = EdgeState("edge_001")
        edge_state.init_state(["cam01", "cam02"])

        # WHEN edge_cam_state.update_cam is called
        edge_updated, cam_updated = edge_state.update_cam("cam01", new_cam1_state)

        # THEN correct result is returned
        assert cam_updated is expected_cam_updated
        assert edge_updated is expected_edge_updated
        assert edge_state.state is expected_edge_state

        cam01_state: EdgeCamState = next(cam for cam in edge_state.cams if cam.id == "cam01")
        assert cam01_state.state == expected_cam1_state
        cam02_state: EdgeCamState = next(cam for cam in edge_state.cams if cam.id == "cam02")
        assert cam02_state.state == EdgeCamStateEnum.NEVER_DETECTED

    @patch("app.config.FF_EDGE_DETECTION_STRICT", True)
    def test_update_cam_should_update_edge_state_when_edge_detected_on_all_cam_in_strict_mode(self):
        # GIVEN
        edge_state: EdgeState = EdgeState("edge_001")
        edge_state.init_state(["cam01", "cam02"])

        # WHEN edge_cam_state.update_cam is called
        edge_updated: bool
        cam_updated: bool
        _, cam_updated = edge_state.update_cam("cam01", EdgeCamStateEnum.DETECTED)
        assert cam_updated is True
        edge_updated, cam_updated = edge_state.update_cam("cam02", EdgeCamStateEnum.DETECTED)

        # THEN correct result is returned
        assert cam_updated is True
        assert edge_updated is True
        assert edge_state.state is EdgeStateEnum.DETECTED

        cam01_state: EdgeCamState = next(cam for cam in edge_state.cams if cam.id == "cam01")
        assert cam01_state.state == EdgeCamStateEnum.DETECTED
        cam02_state: EdgeCamState = next(cam for cam in edge_state.cams if cam.id == "cam02")
        assert cam02_state.state == EdgeCamStateEnum.DETECTED

    @patch("app.config.FF_EDGE_DETECTION_STRICT", True)
    @pytest.mark.parametrize(
        "new_cams_state, current_edge_state, expected_cam_updated, expected_edge_updated, expected_cams_state",
        [
            (EdgeCamStateEnum.DETECTED, EdgeStateEnum.COVERED, True, False, EdgeCamStateEnum.DETECTED),
            (EdgeCamStateEnum.MISSING, EdgeStateEnum.COVERED, False, False, EdgeCamStateEnum.NEVER_DETECTED),
            (EdgeCamStateEnum.MISSING, EdgeStateEnum.FORCED, False, False, EdgeCamStateEnum.NEVER_DETECTED),
            (EdgeCamStateEnum.DETECTED, EdgeStateEnum.FORCED, True, False, EdgeCamStateEnum.DETECTED)
        ]
    )
    def test_update_cam_should_not_update_edge_state_when_edge_state_forced_or_covered_strict_mode(self, new_cams_state,
                                                                                                   current_edge_state,
                                                                                                   expected_cam_updated,
                                                                                                   expected_edge_updated,
                                                                                                   expected_cams_state):
        # GIVEN
        edge_state: EdgeState = EdgeState("edge_001", state=current_edge_state)
        edge_state.init_state({"cam01", "cam02"})

        # WHEN edge_cam_state.update_cam is called
        edge_updated: bool
        cam_updated: bool
        _, cam_updated = edge_state.update_cam("cam01", new_cams_state)
        assert cam_updated is expected_cam_updated
        edge_updated, cam_updated = edge_state.update_cam("cam02", new_cams_state)

        # THEN correct result is returned
        assert cam_updated is expected_cam_updated
        assert edge_updated is expected_edge_updated
        assert edge_state.state is current_edge_state

        cam01_state: EdgeCamState = next(cam for cam in edge_state.cams if cam.id == "cam01")
        assert cam01_state.state.name == expected_cams_state.name
        cam02_state: EdgeCamState = next(cam for cam in edge_state.cams if cam.id == "cam02")
        assert cam02_state.state.name == expected_cams_state.name

    @pytest.mark.parametrize(
        "edge_id, cam_id, edge_state_value_to_init",
        [
            ("edgE101", "cam01", EdgeStateEnum.MISSING),
            ("edgE101", "cam01", EdgeStateEnum.DETECTED),
            ("edgE101", "cam01", EdgeStateEnum.COVERED),
            ("edgE101", "cam01", EdgeStateEnum.FORCED)
        ]
    )
    def test_serialization_should_return_dict_when_various_ply_state_enums_given(
            self, edge_id: str, cam_id: str, edge_state_value_to_init: EdgeStateEnum):
        # GIVEN
        edge_state = EdgeState(edge_id, state=edge_state_value_to_init,
                               cams={EdgeCamState(cam_id, EdgeCamStateEnum.MISSING)})

        # WHEN edge_state.serialize is called
        result = edge_state.serialize()

        # THEN correct result is returned
        assert result is not None
        assert result == {
            "edge_id": edge_id,
            "state": edge_state_value_to_init.name,
            "cams": [{
                "cam_id": cam_id,
                "state": EdgeCamStateEnum.MISSING.name
            }]
        }

    @pytest.mark.parametrize(
        "edge_id, cam_id, edge_state_value, cam_state_value",
        [
            ("edgE11", "cam01", EdgeStateEnum.MISSING, EdgeCamStateEnum.MISSING),
            ("edgE11", "cam01", EdgeStateEnum.DETECTED, EdgeCamStateEnum.DETECTED),
            ("edgE11", "cam01", EdgeStateEnum.COVERED, EdgeCamStateEnum.MISSING),
            ("edgE11", "cam01", EdgeStateEnum.FORCED, EdgeCamStateEnum.MISSING)
        ]
    )
    def test_deserialization_should_return_object_when_various_ply_state_enums_given(self, edge_id: str, cam_id: str,
                                                                                     edge_state_value: EdgeStateEnum,
                                                                                     cam_state_value: EdgeCamStateEnum):
        # GIVEN
        state_dict = {
            "edge_id": edge_id,
            "state": edge_state_value.name,
            "cams": [{
                "cam_id": cam_id,
                "state": cam_state_value.name
            }]
        }

        # WHEN edge_state.deserialize is called
        result = EdgeState.deserialize(state_dict)

        # THEN correct result is returned
        assert result is not None
        assert result.id is edge_id
        assert result.state.name is edge_state_value.name
        for cam in result.cams:
            assert cam.id is cam_id
            assert cam.state.name is cam_state_value.name

    def test_deserialization_should_raise_exception_when_edge_id_missing(self):
        # GIVEN
        state_dict = {
            "state": EdgeStateEnum.MISSING.name,
            "cams": [{
                "cam_id": "cam01",
                "state": EdgeCamStateEnum.MISSING.name
            }]
        }

        # WHEN edge_state.deserialize is called
        with pytest.raises(Exception) as value_error_exc:
            EdgeState.deserialize(state_dict)

        # THEN ValueError exception is raised
        assert value_error_exc.type is ValueError
        assert "Invalid edge state keys" in value_error_exc.value.args[0]

    def test_deserialization_should_raise_exception_when_state_missing(self):
        # GIVEN
        state_dict = {
            "edge_id": "edgE11",
            "cams": [{
                "cam_id": "cam01",
                "state": EdgeCamStateEnum.MISSING.name
            }]
        }

        # WHEN edge_state.deserialize is called
        with pytest.raises(Exception) as value_error_exc:
            EdgeState.deserialize(state_dict)

        # THEN ValueError exception is raised
        assert value_error_exc.type is ValueError
        assert "Invalid edge state keys" in value_error_exc.value.args[0]

    def test_deserialization_should_raise_exception_when_cams_missing(self):
        # GIVEN
        state_dict = {
            "edge_id": "edgE11",
            "state": EdgeStateEnum.MISSING.name
        }

        # WHEN edge_state.deserialize is called
        with pytest.raises(Exception) as value_error_exc:
            EdgeState.deserialize(state_dict)

        # THEN ValueError exception is raised
        assert value_error_exc.type is ValueError
        assert "Invalid edge state keys" in value_error_exc.value.args[0]
