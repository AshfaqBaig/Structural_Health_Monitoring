# pylint: disable=protected-access, missing-module-docstring, missing-class-docstring, missing-function-docstring, duplicate-code, line-too-long, too-few-public-methods, no-self-use, too-many-locals, too-many-lines

import copy
from unittest.mock import patch

import pytest

from app.models.state.edge_cam_state import EdgeCamState
from app.models.state.edge_cam_state_enum import EdgeCamStateEnum as ECSE, EdgeCamStateEnum
from app.models.state.edge_state import EdgeState
from app.models.state.edge_state_enum import EdgeStateEnum as ESE, EdgeStateEnum
from app.models.state.ply_state import PlyState
from app.models.state.ply_state_enum import PlyStateEnum as PSE, PlyStateEnum
from tests.tests_base import StatePliesMock


class PlyStateTests:
    @pytest.mark.parametrize(
        "ply_id, edge_id, cam_id, ply_state_value_to_init",
        [
            ("ply001", "edgE101", "cam001", PSE.EXPECTED),
            ("ply001", "edgE101", "cam001", PSE.PLACED),
            ("ply001", "edgE101", "cam001", PSE.MISSING),
            ("ply001", "edgE101", "cam001", PSE.COVERED),
            ("ply001", "edgE101", "cam001", PSE.FORCED)
        ]
    )
    def test_serialization_should_return_correct_dict_when_various_ply_state_enums_given(
            self, ply_id: str, edge_id: str, cam_id: str, ply_state_value_to_init: PSE):
        # GIVEN
        ply_state: PlyState = PlyState(ply_id, state=ply_state_value_to_init, previous_state=ply_state_value_to_init,
                                       edges={EdgeState(edge_id, cams={EdgeCamState(cam_id)})},
                                       updated_by=f"cam:{cam_id}")

        result = ply_state.serialize()

        # THEN correct result is returned
        assert result is not None
        assert result == {
            "ply_id": ply_id,
            "state": ply_state_value_to_init.name,
            "previous_state": ply_state_value_to_init.name,
            "updated_by": f"cam:{cam_id}",
            "source_device": None,
            "edges": [{
                "edge_id": edge_id,
                "state": ECSE.MISSING.name,
                "cams": [{
                    "cam_id": cam_id,
                    "state": ECSE.NEVER_DETECTED.name
                }]
            }]
        }

    @pytest.mark.parametrize(
        "ply_id, edge_id, cam_id, ply_state_value, edge_state_value, cam_state_value",
        [
            ("ply01", "edgE11", "cam01", PSE.EXPECTED, ESE.MISSING, ECSE.MISSING),
            ("ply01", "edgE11", "cam01", PSE.PLACED, ESE.MISSING, ECSE.MISSING),
            ("ply01", "edgE11", "cam01", PSE.MISSING, ESE.MISSING, ECSE.MISSING),
            ("ply01", "edgE11", "cam01", PSE.COVERED, ESE.MISSING, ECSE.MISSING),
            ("ply01", "edgE11", "cam01", PSE.FORCED, ESE.MISSING, ECSE.MISSING),
        ]
    )
    def test_deserialization_should_return_correct_object_when_various_states_enums_given(
            self, ply_id: str, edge_id: str,
            cam_id: str,
            ply_state_value: PSE,
            edge_state_value: ESE,
            cam_state_value: ECSE):
        # GIVEN
        state_dict = {
            "ply_id": ply_id,
            "state": ply_state_value.name,
            "previous_state": ply_state_value.name,
            "updated_by": f"cam:{cam_id}",
            "edges": [{
                "edge_id": edge_id,
                "state": edge_state_value.name,
                "cams": [{
                    "cam_id": cam_id,
                    "state": cam_state_value.name
                }]
            }]
        }

        # WHEN edge_state.deserialize is called
        result = PlyState.deserialize(state_dict)

        # THEN correct result is returned
        assert result is not None
        assert result.id is ply_id
        assert result.state is ply_state_value
        assert result._updated_by == f"cam:{cam_id}"
        assert result._previous_state == ply_state_value
        for edge in result.edges:
            assert edge.id is edge_id
            assert edge.state is edge_state_value
            for cam in edge.cams:
                assert cam.id is cam_id
                assert cam.state is cam_state_value

    def test_deserialization_should__return_correct_object_when_none_values(self):
        # GIVEN
        state_dict = {
            "ply_id": "ply01",
            "state": PSE.COVERED.name,
            "edges": [],
            "previous_state": None,
            "updated_by": None
        }

        # WHEN edge_state.deserialize is called
        result = PlyState.deserialize(state_dict)

        # THEN ValueError exception is raised
        assert result is not None
        assert result.id is state_dict["ply_id"]
        assert result.state.name is state_dict["state"]
        assert result._updated_by is None
        assert result._previous_state is None
        assert len(result.edges) is 0

    def test_deserialization_should_raise_exception_when_ply_state_missing(self):
        # GIVEN
        state_dict = {
            "ply_id": "ply01",
            "previous_state": PSE.COVERED.name,
            "updated_by": "cam01",
            "edges": [{
                "edge_id": "edgE11",
                "state": ESE.MISSING.name,
                "cams": [{
                    "cam_id": "cam01",
                    "state": ECSE.NEVER_DETECTED.name
                }
                ]
            }]
        }

        # WHEN edge_state.deserialize is called
        with pytest.raises(Exception) as value_error_exc:
            PlyState.deserialize(state_dict)

        # THEN ValueError exception is raised
        assert value_error_exc.type is ValueError
        assert "Invalid ply state keys" in value_error_exc.value.args[0]

    def test_deserialization_should_raise_exception_when_ply_updated_by_missing(self):
        # GIVEN
        state_dict = {
            "ply_id": "ply01",
            "previous_state": PSE.COVERED.name,
            "updated_by": "cam01",
            "edges": [{
                "edge_id": "edgE11",
                "state": ESE.MISSING.name,
                "cams": [{
                    "cam_id": "cam01",
                    "state": ECSE.NEVER_DETECTED.name
                }
                ]
            }]
        }

        # WHEN edge_state.deserialize is called
        with pytest.raises(Exception) as value_error_exc:
            PlyState.deserialize(state_dict)

        # THEN ValueError exception is raised
        assert value_error_exc.type is ValueError
        assert "Invalid ply state keys" in value_error_exc.value.args[0]

    def test_deserialization_should_raise_exception_when_edges_by_missing(self):
        # GIVEN
        state_dict = {
            "ply_id": "ply01",
            "state": PSE.COVERED.name,
            "previous_state": PSE.COVERED.name,
            "updated_by": "cam01"
        }

        # WHEN edge_state.deserialize is called
        with pytest.raises(Exception) as value_error_exc:
            PlyState.deserialize(state_dict)

        # THEN ValueError exception is raised
        assert value_error_exc.type is ValueError
        assert "Invalid ply state keys" in value_error_exc.value.args[0]

    @pytest.mark.parametrize(
        "id_dict, updated_by_cam, initial_ply_state_dict, new_ply_state_dict, expected_ply_state_dict",
        [
            ({'ply_id': "ply001", 'edge_id': "edgE101", 'cam1_id': "cam001", 'cam2_id': "cam002"},
             "cam001",
             {'ply': PSE.EXPECTED, 'edge': ESE.MISSING, 'cam1': ECSE.NEVER_DETECTED, 'cam2': ECSE.NEVER_DETECTED},
             {'ply': PSE.COVERED, 'edge': ESE.COVERED, 'cam1': ECSE.DETECTED, 'cam2': ECSE.NEVER_DETECTED},
             {'ply': PSE.COVERED, 'edge': ESE.COVERED, 'cam1': ECSE.DETECTED, 'cam2': ECSE.NEVER_DETECTED}),
            ({'ply_id': "ply002", 'edge_id': "edgE101", 'cam1_id': "cam001", 'cam2_id': "cam002"},
             "cam001",
             {'ply': PSE.EXPECTED, 'edge': ESE.MISSING, 'cam1': ECSE.NEVER_DETECTED, 'cam2': ECSE.NEVER_DETECTED},
             {'ply': PSE.FORCED, 'edge': ESE.FORCED, 'cam1': ECSE.MISSING, 'cam2': ECSE.NEVER_DETECTED},
             {'ply': PSE.FORCED, 'edge': ESE.FORCED, 'cam1': ECSE.NEVER_DETECTED, 'cam2': ECSE.NEVER_DETECTED}),
            ({'ply_id': "ply003", 'edge_id': "edgE101", 'cam1_id': "cam001", 'cam2_id': "cam002"},
             "cam002",
             {'ply': PSE.EXPECTED, 'edge': ESE.MISSING, 'cam1': ECSE.DETECTED, 'cam2': ECSE.NEVER_DETECTED},
             {'ply': PSE.EXPECTED, 'edge': ESE.MISSING, 'cam1': ECSE.NEVER_DETECTED, 'cam2': ECSE.DETECTED},
             {'ply': PSE.PLACED, 'edge': ESE.DETECTED, 'cam1': ECSE.DETECTED, 'cam2': ECSE.DETECTED})
        ]
    )
    def test_merge_should_merge_only_cam_states_when_updated_by_cam(self, id_dict: dict,
                                                                    updated_by_cam: str,
                                                                    initial_ply_state_dict: dict,
                                                                    new_ply_state_dict: dict,
                                                                    expected_ply_state_dict: dict):
        # GIVEN
        ply_state = PlyState(id_dict['ply_id'],
                             state=initial_ply_state_dict['ply'],
                             edges={EdgeState(id_dict['edge_id'],
                                              state=initial_ply_state_dict['edge'],
                                              cams={EdgeCamState(id_dict['cam1_id'],
                                                                 state=initial_ply_state_dict['cam1']),
                                                    EdgeCamState(id_dict['cam2_id'],
                                                                 state=initial_ply_state_dict['cam2'])})}
                             )
        new_ply_state = PlyState(id_dict['ply_id'],
                                 state=new_ply_state_dict['ply'],
                                 updated_by=f"cam:{updated_by_cam}",
                                 edges={EdgeState(id_dict['edge_id'],
                                                  state=new_ply_state_dict['edge'],
                                                  cams={EdgeCamState(id_dict['cam1_id'],
                                                                     state=new_ply_state_dict['cam1']),
                                                        EdgeCamState(id_dict['cam2_id'],
                                                                     state=new_ply_state_dict['cam2'])})}
                                 )

        # WHEN ply_state.merge is called
        ply_state.merge(new_ply_state)

        # THEN correct result is returned - ONLY cam states should be updated
        assert ply_state.id == id_dict['ply_id']
        assert ply_state.state == expected_ply_state_dict['ply']
        for edge in ply_state.edges:
            assert edge.id is id_dict['edge_id']
            assert edge.state is expected_ply_state_dict['edge']
            cam1_state = next((cam for cam in edge.cams if cam.id == id_dict['cam1_id']), None)
            cam2_state = next((cam for cam in edge.cams if cam.id == id_dict['cam2_id']), None)
            assert cam1_state.state is expected_ply_state_dict['cam1']
            assert cam2_state.state is expected_ply_state_dict['cam2']

    @pytest.mark.parametrize(
        "id_dict, initial_ply_state_dict, new_ply_state_dict, expected_ply_state_dict",
        [
            ({'ply_id': "ply001", 'edge_id': "edgE101", 'cam_id': "cam001"},
             {'ply': PSE.EXPECTED, 'edge': ESE.MISSING, 'cam': ECSE.NEVER_DETECTED},
             {'ply': PSE.FORCED, 'edge': ESE.FORCED, 'cam': ECSE.MISSING},
             {'ply': PSE.FORCED, 'edge': ESE.FORCED, 'cam': ECSE.MISSING}),
            ({'ply_id': "ply002", 'edge_id': "edgE101", 'cam_id': "cam001"},
             {'ply': PSE.EXPECTED, 'edge': ESE.MISSING, 'cam': ECSE.NEVER_DETECTED},
             {'ply': PSE.FORCED, 'edge': ESE.FORCED, 'cam': ECSE.DETECTED},
             {'ply': PSE.FORCED, 'edge': ESE.FORCED, 'cam': ECSE.DETECTED})
        ]
    )
    def test_merge_should_merge_only_ply_and_cam_states_when_updated_by_force(self, id_dict: dict,
                                                                              initial_ply_state_dict: dict,
                                                                              new_ply_state_dict: dict,
                                                                              expected_ply_state_dict: dict):
        # GIVEN
        ply_state = PlyState(id_dict['ply_id'],
                             state=initial_ply_state_dict['ply'],
                             edges={EdgeState(id_dict['edge_id'],
                                              state=initial_ply_state_dict['edge'],
                                              cams={EdgeCamState(id_dict['cam_id'],
                                                                 state=initial_ply_state_dict['cam'])})}
                             )
        new_ply_state = PlyState(id_dict['ply_id'],
                                 state=new_ply_state_dict['ply'],
                                 updated_by="force",
                                 edges={EdgeState(id_dict['edge_id'],
                                                  state=new_ply_state_dict['edge'],
                                                  cams={EdgeCamState(id_dict['cam_id'],
                                                                     state=new_ply_state_dict['cam'])})}
                                 )

        # WHEN ply_state.merge is called
        ply_state.merge(new_ply_state)

        # THEN correct result is returned - ONLY ply and edge states should be updated
        assert ply_state.id == id_dict['ply_id']
        assert ply_state.state == expected_ply_state_dict['ply']
        for edge in ply_state.edges:
            assert edge.id is id_dict['edge_id']
            assert edge.state is expected_ply_state_dict['edge']
            for cam in edge.cams:
                assert cam.id is id_dict['cam_id']
                assert cam.state is expected_ply_state_dict['cam']

    @pytest.mark.parametrize(
        "id_dict, initial_ply_state_dict, new_ply_state_dict, expected_ply_state_dict",
        [
            ({'ply_id': "ply001", 'edge_id': "edgE101", 'cam_id': "cam001"},
             {'ply': PSE.EXPECTED, 'edge': ESE.MISSING, 'cam': ECSE.NEVER_DETECTED},
             {'ply': PSE.EXPECTED, 'edge': ESE.COVERED, 'cam': ECSE.DETECTED},  # edge of ply is COVERED but ply is not?
             {'ply': PSE.EXPECTED, 'edge': ESE.MISSING, 'cam': ECSE.NEVER_DETECTED}),
            # TODO: new_ply_state needs to be realistic and expected_ply_state should be corrected
            # {'ply': PSE.COVERED, 'edge': ESE.COVERED, 'cam': ECSE.DETECTED},
            # {'ply': PSE.COVERED, 'edge': ESE.COVERED, 'cam': ECSE.DETECTED}),
            ({'ply_id': "ply002", 'edge_id': "edgE101", 'cam_id': "cam001"},
             {'ply': PSE.EXPECTED, 'edge': ESE.MISSING, 'cam': ECSE.DETECTED},  # cam DETECTED but edge MISSING?
             {'ply': PSE.COVERED, 'edge': ESE.COVERED, 'cam': ECSE.NEVER_DETECTED},
             {'ply': PSE.COVERED, 'edge': ESE.COVERED, 'cam': ECSE.DETECTED})
        ]
    )
    def test_merge_should_merge_only_edge_states_when_updated_by_ply(self, id_dict: dict,
                                                                     initial_ply_state_dict: dict,
                                                                     new_ply_state_dict: dict,
                                                                     expected_ply_state_dict: dict):
        # GIVEN
        ply_state = PlyState(id_dict['ply_id'],
                             state=initial_ply_state_dict['ply'],
                             edges={EdgeState(id_dict['edge_id'],
                                              state=initial_ply_state_dict['edge'],
                                              cams={EdgeCamState(id_dict['cam_id'],
                                                                 state=initial_ply_state_dict['cam'])})}
                             )
        new_ply_state = PlyState(id_dict['ply_id'], state=new_ply_state_dict['ply'],
                                 updated_by="ply",
                                 edges={EdgeState(id_dict['edge_id'],
                                                  state=new_ply_state_dict['edge'],
                                                  cams={EdgeCamState(id_dict['cam_id'],
                                                                     state=new_ply_state_dict['cam'])})}
                                 )

        # WHEN ply_state.merge is called
        ply_state.merge(new_ply_state)

        # THEN correct result is returned - ONLY edge states should be updated
        assert ply_state.id == id_dict['ply_id']
        assert ply_state.state == expected_ply_state_dict['ply']
        for edge in ply_state.edges:
            assert edge.id is id_dict['edge_id']
            assert edge.state is expected_ply_state_dict['edge']
            cam_state = next((cam for cam in edge.cams if cam.id == id_dict['cam_id']), None)
            assert cam_state.state is expected_ply_state_dict['cam']

    @pytest.mark.parametrize(
        "ply_id, edge_id, cam_id, initial_ply_state_value, initial_edge_state_value, initial_cam_state_value",
        [
            ("ply001", "edgE101", "cam001", PSE.EXPECTED, ESE.MISSING, ECSE.NEVER_DETECTED),
            ("ply002", "edgE101", "cam001", PSE.EXPECTED, ESE.MISSING, ECSE.DETECTED)
        ]
    )
    def test_merge_should_merge_only_edge_states_when_updated_by_ply_2(self, ply_id: str, edge_id: str, cam_id: str,
                                                                       initial_ply_state_value: PlyStateEnum,
                                                                       initial_edge_state_value: EdgeStateEnum,
                                                                       initial_cam_state_value: EdgeCamStateEnum):
        # GIVEN
        ply_state = PlyState(ply_id,
                             state=initial_ply_state_value,
                             edges={EdgeState(edge_id,
                                              state=initial_edge_state_value,
                                              cams={EdgeCamState(cam_id, state=initial_cam_state_value)})}
                             )
        new_ply_state = PlyState(ply_id)

        # WHEN ply_state.merge is called
        ply_state.merge(new_ply_state)

        # THEN correct result is returned - ONLY edge states should be updated
        assert ply_state.id == ply_id
        assert ply_state.state == initial_ply_state_value
        for edge in ply_state.edges:
            assert edge.id is edge_id
            assert edge.state is initial_edge_state_value
            cam_state = next((cam for cam in edge.cams if cam.id == cam_id), None)
            assert cam_state.state is initial_cam_state_value


class EqualityComparisonOperatorTests:
    def test_equality_comparison_operator_should_return_true_when_two_given_ply_state_objects_equal(self):
        # GIVEN
        ply_one = StatePliesMock().first_ply_placed
        ply_two = copy.deepcopy(StatePliesMock().first_ply_placed)

        # WHEN
        result = ply_one == ply_two

        # THEN
        assert result is True

    def test_equality_comparison_operator_should_return_false_when_two_given_ply_state_objects_not_equal(self):
        # GIVEN
        ply_one = StatePliesMock().first_ply_placed
        ply_two = StatePliesMock().second_ply_placed

        # WHEN
        result = ply_one == ply_two

        # THEN
        assert result is False

    def test_equality_comparison_operator_should_return_false_when_two_given_ply_state_objects_not_equal_in_deep(self):
        # GIVEN
        ply_one = PlyState(
            "P1",
            edges={
                EdgeState(
                    "P1.1",
                    cams={
                        EdgeCamState("cam1", EdgeCamStateEnum.DETECTED),
                    },
                    state=EdgeStateEnum.DETECTED
                ),
                EdgeState(
                    "P1.2",
                    cams={
                        EdgeCamState("cam1", EdgeCamStateEnum.DETECTED),
                    },
                    state=EdgeStateEnum.DETECTED
                ),
            },
            state=PlyStateEnum.PLACED,
            previous_state=PlyStateEnum.EXPECTED,
            updated_by="cam:cam1",
            source_device="device_module_id"
        )
        ply_two = PlyState(
            "P1",
            edges={
                EdgeState(
                    "P1.1",
                    cams={
                        EdgeCamState("cam1", EdgeCamStateEnum.DETECTED),
                    },
                    state=EdgeStateEnum.DETECTED
                ),
                EdgeState(
                    "P1.2",
                    cams={
                        EdgeCamState("cam1", EdgeCamStateEnum.NEVER_DETECTED),
                    },
                    state=EdgeStateEnum.DETECTED
                ),
            },
            state=PlyStateEnum.PLACED,
            previous_state=PlyStateEnum.EXPECTED,
            updated_by="cam:cam1",
            source_device="device_module_id"
        )

        # WHEN
        result = ply_one == ply_two

        # THEN
        assert result is False

    def test_equality_comparison_operator_should_raise_exception_when_invalid_type_class_given(self):
        # GIVEN
        state_plies_mock = StatePliesMock()
        ply_state = state_plies_mock.first_ply_placed
        other_type_object = EdgeState("edge_id")

        # WHEN
        with pytest.raises(Exception) as exc_info:
            ply_state == other_type_object

        # THEN an exception of correct type is raised
        assert exc_info.type is TypeError
        assert "PlyState equality comparator cannot compare itself to other type" in exc_info.value.args[0]


@patch("app.config.FF_EDGE_DETECTION_STRICT", True)
class UpdateCamStatesWhenStrictEdgeDetectionEnabledTests:
    def test_should_return_true_when_any_edge_with_cam_states_updated(self):
        # GIVEN
        cam_id = "cam1"
        ply = PlyState(ply_id="ply1",
                       edges={
                           EdgeState("edge1",
                                     cams={EdgeCamState(cam_id, EdgeCamStateEnum.NEVER_DETECTED)},
                                     state=EdgeStateEnum.MISSING),
                           EdgeState("edge2",
                                     cams={EdgeCamState(cam_id, EdgeCamStateEnum.NEVER_DETECTED)},
                                     state=EdgeStateEnum.MISSING)},
                       state=PlyStateEnum.PLACED)
        new_ply_state = PlyState(ply_id="ply1",
                                 edges={
                                     EdgeState("edge1",
                                               cams={EdgeCamState(cam_id, EdgeCamStateEnum.DETECTED)},
                                               state=EdgeStateEnum.DETECTED),
                                     EdgeState("edge2",
                                               cams={EdgeCamState(cam_id, EdgeCamStateEnum.NEVER_DETECTED)},
                                               state=EdgeStateEnum.MISSING)},
                                 state=PlyStateEnum.PLACED)

        # WHEN
        result = ply._update_cam_states(cam_id, new_ply_state)

        # THEN
        assert result is True

    def test_should_return_true_when_all_edges_with_cam_states_updated(self):
        # GIVEN
        cam_id = "cam1"
        ply = PlyState(ply_id="ply1",
                       edges={
                           EdgeState("edge1",
                                     cams={EdgeCamState(cam_id, EdgeCamStateEnum.NEVER_DETECTED)},
                                     state=EdgeStateEnum.MISSING),
                           EdgeState("edge2",
                                     cams={EdgeCamState(cam_id, EdgeCamStateEnum.NEVER_DETECTED)},
                                     state=EdgeStateEnum.MISSING)},
                       state=PlyStateEnum.PLACED)
        new_ply_state = PlyState(ply_id="ply1",
                                 edges={
                                     EdgeState("edge1",
                                               cams={EdgeCamState(cam_id, EdgeCamStateEnum.DETECTED)},
                                               state=EdgeStateEnum.DETECTED),
                                     EdgeState("edge2",
                                               cams={EdgeCamState(cam_id, EdgeCamStateEnum.DETECTED)},
                                               state=EdgeStateEnum.DETECTED)},
                                 state=PlyStateEnum.PLACED)

        # WHEN
        result = ply._update_cam_states(cam_id, new_ply_state)

        # THEN
        assert result is True

    def test_should_return_false_when_no_cam_or_edge_state_updated(self):
        # GIVEN
        cam_id = "cam1"
        ply = PlyState(ply_id="ply1",
                       edges={
                           EdgeState("edge1",
                                     cams={EdgeCamState(cam_id, EdgeCamStateEnum.NEVER_DETECTED)},
                                     state=EdgeStateEnum.MISSING),
                           EdgeState("edge2",
                                     cams={EdgeCamState(cam_id, EdgeCamStateEnum.NEVER_DETECTED)},
                                     state=EdgeStateEnum.MISSING)},
                       state=PlyStateEnum.PLACED)
        new_ply_state = PlyState(ply_id="ply1",
                                 edges={
                                     EdgeState("edge1",
                                               cams={EdgeCamState(cam_id, EdgeCamStateEnum.NEVER_DETECTED)},
                                               state=EdgeStateEnum.MISSING),
                                     EdgeState("edge2",
                                               cams={EdgeCamState(cam_id, EdgeCamStateEnum.NEVER_DETECTED)},
                                               state=EdgeStateEnum.MISSING)},
                                 state=PlyStateEnum.PLACED)

        # WHEN
        result = ply._update_cam_states(cam_id, new_ply_state)

        # THEN
        assert result is False

    def test_should_return_true_when_edge_state_changed_for_a_given_new_cam_state_update(self):
        # GIVEN
        cam_id = "cam1"
        ply = PlyState(ply_id="ply1",
                       edges={
                           EdgeState("edge1",
                                     cams={EdgeCamState(cam_id, EdgeCamStateEnum.NEVER_DETECTED)},
                                     state=EdgeStateEnum.MISSING),
                           EdgeState("edge2",
                                     cams={EdgeCamState(cam_id, EdgeCamStateEnum.NEVER_DETECTED)},
                                     state=EdgeStateEnum.MISSING)},
                       state=PlyStateEnum.PLACED)
        new_ply_state = PlyState(ply_id="ply1",
                                 edges={
                                     EdgeState("edge1",
                                               cams={EdgeCamState(cam_id, EdgeCamStateEnum.DETECTED)},
                                               state=EdgeStateEnum.MISSING),
                                     EdgeState("edge2",
                                               cams={EdgeCamState(cam_id, EdgeCamStateEnum.NEVER_DETECTED)},
                                               state=EdgeStateEnum.MISSING)},
                                 state=PlyStateEnum.PLACED)

        # WHEN
        result = ply._update_cam_states(cam_id, new_ply_state)

        # THEN
        assert result is True

    def test_should_return_true_when_edge_state_changed_for_given_multiple_new_cam_state_updates(self):
        # GIVEN
        cam_id = "cam1"
        ply = PlyState(ply_id="ply1",
                       edges={
                           EdgeState("edge1",
                                     cams={EdgeCamState(cam_id, EdgeCamStateEnum.NEVER_DETECTED)},
                                     state=EdgeStateEnum.MISSING),
                           EdgeState("edge2",
                                     cams={EdgeCamState(cam_id, EdgeCamStateEnum.NEVER_DETECTED)},
                                     state=EdgeStateEnum.MISSING)},
                       state=PlyStateEnum.PLACED)
        new_ply_state = PlyState(ply_id="ply1",
                                 edges={
                                     EdgeState("edge1",
                                               cams={EdgeCamState(cam_id, EdgeCamStateEnum.DETECTED)},
                                               state=EdgeStateEnum.MISSING),
                                     EdgeState("edge2",
                                               cams={EdgeCamState(cam_id, EdgeCamStateEnum.DETECTED)},
                                               state=EdgeStateEnum.MISSING)},
                                 state=PlyStateEnum.PLACED)

        # WHEN
        result = ply._update_cam_states(cam_id, new_ply_state)

        # THEN
        assert result is True

    def test_should_return_false_when_no_edge_state_changed_for_a_given_new_cam_state_update(self):
        # GIVEN
        cam_id = "cam1"
        ply = PlyState(ply_id="ply1",
                       edges={
                           EdgeState("edge1",
                                     cams={EdgeCamState(cam_id, EdgeCamStateEnum.NEVER_DETECTED)},
                                     state=EdgeStateEnum.MISSING),
                           EdgeState("edge2",
                                     cams={EdgeCamState(cam_id, EdgeCamStateEnum.NEVER_DETECTED)},
                                     state=EdgeStateEnum.MISSING)},
                       state=PlyStateEnum.PLACED)
        new_ply_state = PlyState(ply_id="ply1",
                                 edges={
                                     EdgeState("edge1",
                                               cams={EdgeCamState(cam_id, EdgeCamStateEnum.MISSING)},
                                               state=EdgeStateEnum.MISSING),
                                     EdgeState("edge2",
                                               cams={EdgeCamState(cam_id, EdgeCamStateEnum.NEVER_DETECTED)},
                                               state=EdgeStateEnum.MISSING)},
                                 state=PlyStateEnum.PLACED)

        # WHEN
        result = ply._update_cam_states(cam_id, new_ply_state)

        # THEN
        assert result is False

    def test_should_return_false_when_no_edge_state_changed_for_given_multiple_new_cam_state_updates(self):
        # GIVEN
        cam_id = "cam1"
        ply = PlyState(ply_id="ply1",
                       edges={
                           EdgeState("edge1",
                                     cams={EdgeCamState(cam_id, EdgeCamStateEnum.NEVER_DETECTED)},
                                     state=EdgeStateEnum.MISSING),
                           EdgeState("edge2",
                                     cams={EdgeCamState(cam_id, EdgeCamStateEnum.NEVER_DETECTED)},
                                     state=EdgeStateEnum.MISSING)},
                       state=PlyStateEnum.PLACED)
        new_ply_state = PlyState(ply_id="ply1",
                                 edges={
                                     EdgeState("edge1",
                                               cams={EdgeCamState(cam_id, EdgeCamStateEnum.MISSING)},
                                               state=EdgeStateEnum.MISSING),
                                     EdgeState("edge2",
                                               cams={EdgeCamState(cam_id, EdgeCamStateEnum.MISSING)},
                                               state=EdgeStateEnum.MISSING)},
                                 state=PlyStateEnum.PLACED)

        # WHEN
        result = ply._update_cam_states(cam_id, new_ply_state)

        # THEN
        assert result is False

    @pytest.mark.parametrize(
        "current_cam_state, new_cam_state",
        [
            (EdgeCamStateEnum.NEVER_DETECTED, EdgeCamStateEnum.MISSING),
            (EdgeCamStateEnum.NEVER_DETECTED, EdgeCamStateEnum.DETECTED),
            (EdgeCamStateEnum.NEVER_DETECTED, EdgeCamStateEnum.NEVER_DETECTED),
            (EdgeCamStateEnum.MISSING, EdgeCamStateEnum.DETECTED),
            (EdgeCamStateEnum.MISSING, EdgeCamStateEnum.MISSING),
            (EdgeCamStateEnum.DETECTED, EdgeCamStateEnum.MISSING),
            (EdgeCamStateEnum.DETECTED, EdgeCamStateEnum.DETECTED),
        ]
    )
    def test_should_return_true_when_new_edge_state_forced_no_matter_what_cam_state_changes_are_given(
            self, current_cam_state, new_cam_state):
        # GIVEN
        cam_id = "cam1"
        ply = PlyState(ply_id="ply1",
                       edges={
                           EdgeState("edge1",
                                     cams={EdgeCamState(cam_id, current_cam_state)},
                                     state=EdgeStateEnum.DETECTED)},
                       state=PlyStateEnum.EXPECTED)
        new_ply_state = PlyState(ply_id="ply1",
                                 edges={
                                     EdgeState("edge1",
                                               cams={EdgeCamState(cam_id, new_cam_state)},
                                               state=EdgeStateEnum.FORCED)},
                                 state=PlyStateEnum.EXPECTED)

        # WHEN
        result = ply._update_cam_states(cam_id, new_ply_state)

        # THEN
        assert result is True

    @pytest.mark.parametrize(
        "current_cam_state, new_cam_state",
        [
            (EdgeCamStateEnum.NEVER_DETECTED, EdgeCamStateEnum.MISSING),
            (EdgeCamStateEnum.NEVER_DETECTED, EdgeCamStateEnum.DETECTED),
            (EdgeCamStateEnum.NEVER_DETECTED, EdgeCamStateEnum.NEVER_DETECTED),
            (EdgeCamStateEnum.MISSING, EdgeCamStateEnum.DETECTED),
            (EdgeCamStateEnum.MISSING, EdgeCamStateEnum.MISSING),
            (EdgeCamStateEnum.DETECTED, EdgeCamStateEnum.MISSING),
            (EdgeCamStateEnum.DETECTED, EdgeCamStateEnum.DETECTED),
        ]
    )
    def test_should_return_true_when_new_edge_state_covered_no_matter_what_cam_state_changes_are_given(
            self, current_cam_state, new_cam_state):
        # GIVEN
        cam_id = "cam1"
        ply = PlyState(ply_id="ply1",
                       edges={
                           EdgeState("edge1",
                                     cams={EdgeCamState(cam_id, current_cam_state)},
                                     state=EdgeStateEnum.MISSING)},
                       state=PlyStateEnum.EXPECTED)
        new_ply_state = PlyState(ply_id="ply1",
                                 edges={
                                     EdgeState("edge1",
                                               cams={EdgeCamState(cam_id, new_cam_state)},
                                               state=EdgeStateEnum.COVERED)},
                                 state=PlyStateEnum.EXPECTED)

        # WHEN
        result = ply._update_cam_states(cam_id, new_ply_state)

        # THEN
        assert result is True

    @pytest.mark.parametrize(
        "current_cam_state, new_cam_state",
        [
            (EdgeCamStateEnum.NEVER_DETECTED, EdgeCamStateEnum.MISSING),
            (EdgeCamStateEnum.NEVER_DETECTED, EdgeCamStateEnum.DETECTED),
            (EdgeCamStateEnum.NEVER_DETECTED, EdgeCamStateEnum.NEVER_DETECTED),
            (EdgeCamStateEnum.MISSING, EdgeCamStateEnum.DETECTED),
            (EdgeCamStateEnum.MISSING, EdgeCamStateEnum.MISSING),
            (EdgeCamStateEnum.DETECTED, EdgeCamStateEnum.MISSING),
            (EdgeCamStateEnum.DETECTED, EdgeCamStateEnum.DETECTED),
        ]
    )
    def test_should_return_false_when_existing_edge_state_is_already_forced_no_matter_what_cam_state_changes_are_given(
            self, current_cam_state, new_cam_state):
        # GIVEN
        cam_id = "cam1"
        ply = PlyState(ply_id="ply1",
                       edges={
                           EdgeState("edge1",
                                     cams={EdgeCamState(cam_id, current_cam_state)},
                                     state=EdgeStateEnum.FORCED)},
                       state=PlyStateEnum.PLACED)
        new_ply_state = PlyState(ply_id="ply1",
                                 edges={
                                     EdgeState("edge1",
                                               cams={EdgeCamState(cam_id, new_cam_state)},
                                               state=EdgeStateEnum.FORCED)},
                                 state=PlyStateEnum.PLACED)

        # WHEN
        result = ply._update_cam_states(cam_id, new_ply_state)

        # THEN
        assert result is False

    @pytest.mark.parametrize(
        "current_cam_state, new_cam_state",
        [
            (EdgeCamStateEnum.NEVER_DETECTED, EdgeCamStateEnum.MISSING),
            (EdgeCamStateEnum.NEVER_DETECTED, EdgeCamStateEnum.DETECTED),
            (EdgeCamStateEnum.NEVER_DETECTED, EdgeCamStateEnum.NEVER_DETECTED),
            (EdgeCamStateEnum.MISSING, EdgeCamStateEnum.DETECTED),
            (EdgeCamStateEnum.MISSING, EdgeCamStateEnum.MISSING),
            (EdgeCamStateEnum.DETECTED, EdgeCamStateEnum.MISSING),
            (EdgeCamStateEnum.DETECTED, EdgeCamStateEnum.DETECTED),
        ]
    )
    def test_should_return_false_when_existing_edge_state_is_already_covered_no_matter_what_cam_state_changes_are_given(
            self, current_cam_state, new_cam_state):
        # GIVEN
        cam_id = "cam1"
        ply = PlyState(ply_id="ply1",
                       edges={
                           EdgeState("edge1",
                                     cams={EdgeCamState(cam_id, current_cam_state)},
                                     state=EdgeStateEnum.COVERED)},
                       state=PlyStateEnum.PLACED)
        new_ply_state = PlyState(ply_id="ply1",
                                 edges={
                                     EdgeState("edge1",
                                               cams={EdgeCamState(cam_id, new_cam_state)},
                                               state=EdgeStateEnum.COVERED)},
                                 state=PlyStateEnum.PLACED)

        # WHEN
        result = ply._update_cam_states(cam_id, new_ply_state)

        # THEN
        assert result is False


@patch("app.config.FF_EDGE_DETECTION_STRICT", False)
class UpdateCamStatesWhenStrictEdgeDetectionDisabledTests:
    def test_should_return_true_when_any_edge_with_cam_states_updated(self):
        # GIVEN
        cam_id = "cam1"
        ply = PlyState(ply_id="ply1",
                       edges={
                           EdgeState("edge1",
                                     cams={EdgeCamState(cam_id, EdgeCamStateEnum.NEVER_DETECTED)},
                                     state=EdgeStateEnum.MISSING),
                           EdgeState("edge2",
                                     cams={EdgeCamState(cam_id, EdgeCamStateEnum.NEVER_DETECTED)},
                                     state=EdgeStateEnum.MISSING)},
                       state=PlyStateEnum.PLACED)
        new_ply_state = PlyState(ply_id="ply1",
                                 edges={
                                     EdgeState("edge1",
                                               cams={EdgeCamState(cam_id, EdgeCamStateEnum.DETECTED)},
                                               state=EdgeStateEnum.DETECTED),
                                     EdgeState("edge2",
                                               cams={EdgeCamState(cam_id, EdgeCamStateEnum.NEVER_DETECTED)},
                                               state=EdgeStateEnum.MISSING)},
                                 state=PlyStateEnum.PLACED)

        # WHEN
        result = ply._update_cam_states(cam_id, new_ply_state)

        # THEN
        assert result is True

    def test_should_return_true_when_all_edges_with_cam_states_updated(self):
        # GIVEN
        cam_id = "cam1"
        ply = PlyState(ply_id="ply1",
                       edges={
                           EdgeState("edge1",
                                     cams={EdgeCamState(cam_id, EdgeCamStateEnum.NEVER_DETECTED)},
                                     state=EdgeStateEnum.MISSING),
                           EdgeState("edge2",
                                     cams={EdgeCamState(cam_id, EdgeCamStateEnum.NEVER_DETECTED)},
                                     state=EdgeStateEnum.MISSING)},
                       state=PlyStateEnum.PLACED)
        new_ply_state = PlyState(ply_id="ply1",
                                 edges={
                                     EdgeState("edge1",
                                               cams={EdgeCamState(cam_id, EdgeCamStateEnum.DETECTED)},
                                               state=EdgeStateEnum.DETECTED),
                                     EdgeState("edge2",
                                               cams={EdgeCamState(cam_id, EdgeCamStateEnum.DETECTED)},
                                               state=EdgeStateEnum.DETECTED)},
                                 state=PlyStateEnum.PLACED)

        # WHEN
        result = ply._update_cam_states(cam_id, new_ply_state)

        # THEN
        assert result is True

    def test_should_return_false_when_no_cam_or_edge_state_updated(self):
        # GIVEN
        cam_id = "cam1"
        ply = PlyState(ply_id="ply1",
                       edges={
                           EdgeState("edge1",
                                     cams={EdgeCamState(cam_id, EdgeCamStateEnum.NEVER_DETECTED)},
                                     state=EdgeStateEnum.MISSING),
                           EdgeState("edge2",
                                     cams={EdgeCamState(cam_id, EdgeCamStateEnum.NEVER_DETECTED)},
                                     state=EdgeStateEnum.MISSING)},
                       state=PlyStateEnum.PLACED)
        new_ply_state = PlyState(ply_id="ply1",
                                 edges={
                                     EdgeState("edge1",
                                               cams={EdgeCamState(cam_id, EdgeCamStateEnum.NEVER_DETECTED)},
                                               state=EdgeStateEnum.MISSING),
                                     EdgeState("edge2",
                                               cams={EdgeCamState(cam_id, EdgeCamStateEnum.NEVER_DETECTED)},
                                               state=EdgeStateEnum.MISSING)},
                                 state=PlyStateEnum.PLACED)

        # WHEN
        result = ply._update_cam_states(cam_id, new_ply_state)

        # THEN
        assert result is False

    def test_should_return_true_when_edge_state_changed_for_a_given_new_cam_state_update(self):
        # GIVEN
        cam_id = "cam1"
        ply = PlyState(ply_id="ply1",
                       edges={
                           EdgeState("edge1",
                                     cams={EdgeCamState(cam_id, EdgeCamStateEnum.NEVER_DETECTED)},
                                     state=EdgeStateEnum.MISSING),
                           EdgeState("edge2",
                                     cams={EdgeCamState(cam_id, EdgeCamStateEnum.NEVER_DETECTED)},
                                     state=EdgeStateEnum.MISSING)},
                       state=PlyStateEnum.PLACED)
        new_ply_state = PlyState(ply_id="ply1",
                                 edges={
                                     EdgeState("edge1",
                                               cams={EdgeCamState(cam_id, EdgeCamStateEnum.DETECTED)},
                                               state=EdgeStateEnum.MISSING),
                                     EdgeState("edge2",
                                               cams={EdgeCamState(cam_id, EdgeCamStateEnum.NEVER_DETECTED)},
                                               state=EdgeStateEnum.MISSING)},
                                 state=PlyStateEnum.PLACED)

        # WHEN
        result = ply._update_cam_states(cam_id, new_ply_state)

        # THEN
        assert result is True

    def test_should_return_true_when_edge_state_changed_for_given_multiple_new_cam_state_updates(self):
        # GIVEN
        cam_id = "cam1"
        ply = PlyState(ply_id="ply1",
                       edges={
                           EdgeState("edge1",
                                     cams={EdgeCamState(cam_id, EdgeCamStateEnum.NEVER_DETECTED)},
                                     state=EdgeStateEnum.MISSING),
                           EdgeState("edge2",
                                     cams={EdgeCamState(cam_id, EdgeCamStateEnum.NEVER_DETECTED)},
                                     state=EdgeStateEnum.MISSING)},
                       state=PlyStateEnum.PLACED)
        new_ply_state = PlyState(ply_id="ply1",
                                 edges={
                                     EdgeState("edge1",
                                               cams={EdgeCamState(cam_id, EdgeCamStateEnum.DETECTED)},
                                               state=EdgeStateEnum.MISSING),
                                     EdgeState("edge2",
                                               cams={EdgeCamState(cam_id, EdgeCamStateEnum.DETECTED)},
                                               state=EdgeStateEnum.MISSING)},
                                 state=PlyStateEnum.PLACED)

        # WHEN
        result = ply._update_cam_states(cam_id, new_ply_state)

        # THEN
        assert result is True

    def test_should_return_false_when_no_edge_state_changed_for_a_given_new_cam_state_update(self):
        # GIVEN
        cam_id = "cam1"
        ply = PlyState(ply_id="ply1",
                       edges={
                           EdgeState("edge1",
                                     cams={EdgeCamState(cam_id, EdgeCamStateEnum.NEVER_DETECTED)},
                                     state=EdgeStateEnum.MISSING),
                           EdgeState("edge2",
                                     cams={EdgeCamState(cam_id, EdgeCamStateEnum.NEVER_DETECTED)},
                                     state=EdgeStateEnum.MISSING)},
                       state=PlyStateEnum.PLACED)
        new_ply_state = PlyState(ply_id="ply1",
                                 edges={
                                     EdgeState("edge1",
                                               cams={EdgeCamState(cam_id, EdgeCamStateEnum.MISSING)},
                                               state=EdgeStateEnum.MISSING),
                                     EdgeState("edge2",
                                               cams={EdgeCamState(cam_id, EdgeCamStateEnum.NEVER_DETECTED)},
                                               state=EdgeStateEnum.MISSING)},
                                 state=PlyStateEnum.PLACED)

        # WHEN
        result = ply._update_cam_states(cam_id, new_ply_state)

        # THEN
        assert result is False

    def test_should_return_false_when_no_edge_state_changed_for_given_multiple_new_cam_state_updates(self):
        # GIVEN
        cam_id = "cam1"
        ply = PlyState(ply_id="ply1",
                       edges={
                           EdgeState("edge1",
                                     cams={EdgeCamState(cam_id, EdgeCamStateEnum.NEVER_DETECTED)},
                                     state=EdgeStateEnum.MISSING),
                           EdgeState("edge2",
                                     cams={EdgeCamState(cam_id, EdgeCamStateEnum.NEVER_DETECTED)},
                                     state=EdgeStateEnum.MISSING)},
                       state=PlyStateEnum.PLACED)
        new_ply_state = PlyState(ply_id="ply1",
                                 edges={
                                     EdgeState("edge1",
                                               cams={EdgeCamState(cam_id, EdgeCamStateEnum.MISSING)},
                                               state=EdgeStateEnum.MISSING),
                                     EdgeState("edge2",
                                               cams={EdgeCamState(cam_id, EdgeCamStateEnum.MISSING)},
                                               state=EdgeStateEnum.MISSING)},
                                 state=PlyStateEnum.PLACED)

        # WHEN
        result = ply._update_cam_states(cam_id, new_ply_state)

        # THEN
        assert result is False

    @pytest.mark.parametrize(
        "current_cam_state, new_cam_state",
        [
            (EdgeCamStateEnum.NEVER_DETECTED, EdgeCamStateEnum.MISSING),
            (EdgeCamStateEnum.NEVER_DETECTED, EdgeCamStateEnum.DETECTED),
            (EdgeCamStateEnum.NEVER_DETECTED, EdgeCamStateEnum.NEVER_DETECTED),
            (EdgeCamStateEnum.MISSING, EdgeCamStateEnum.DETECTED),
            (EdgeCamStateEnum.MISSING, EdgeCamStateEnum.MISSING),
            (EdgeCamStateEnum.DETECTED, EdgeCamStateEnum.MISSING),
            (EdgeCamStateEnum.DETECTED, EdgeCamStateEnum.DETECTED),
        ]
    )
    def test_should_return_true_when_new_edge_state_forced_no_matter_what_cam_state_changes_are_given(
            self, current_cam_state, new_cam_state):
        # GIVEN
        cam_id = "cam1"
        ply = PlyState(ply_id="ply1",
                       edges={
                           EdgeState("edge1",
                                     cams={EdgeCamState(cam_id, current_cam_state)},
                                     state=EdgeStateEnum.DETECTED)},
                       state=PlyStateEnum.EXPECTED)
        new_ply_state = PlyState(ply_id="ply1",
                                 edges={
                                     EdgeState("edge1",
                                               cams={EdgeCamState(cam_id, new_cam_state)},
                                               state=EdgeStateEnum.FORCED)},
                                 state=PlyStateEnum.EXPECTED)

        # WHEN
        result = ply._update_cam_states(cam_id, new_ply_state)

        # THEN
        assert result is True

    @pytest.mark.parametrize(
        "current_cam_state, new_cam_state",
        [
            (EdgeCamStateEnum.NEVER_DETECTED, EdgeCamStateEnum.MISSING),
            (EdgeCamStateEnum.NEVER_DETECTED, EdgeCamStateEnum.DETECTED),
            (EdgeCamStateEnum.NEVER_DETECTED, EdgeCamStateEnum.NEVER_DETECTED),
            (EdgeCamStateEnum.MISSING, EdgeCamStateEnum.DETECTED),
            (EdgeCamStateEnum.MISSING, EdgeCamStateEnum.MISSING),
            (EdgeCamStateEnum.DETECTED, EdgeCamStateEnum.MISSING),
            (EdgeCamStateEnum.DETECTED, EdgeCamStateEnum.DETECTED),
        ]
    )
    def test_should_return_true_when_new_edge_state_covered_no_matter_what_cam_state_changes_are_given(
            self, current_cam_state, new_cam_state):
        # GIVEN
        cam_id = "cam1"
        ply = PlyState(ply_id="ply1",
                       edges={
                           EdgeState("edge1",
                                     cams={EdgeCamState(cam_id, current_cam_state)},
                                     state=EdgeStateEnum.MISSING)},
                       state=PlyStateEnum.EXPECTED)
        new_ply_state = PlyState(ply_id="ply1",
                                 edges={
                                     EdgeState("edge1",
                                               cams={EdgeCamState(cam_id, new_cam_state)},
                                               state=EdgeStateEnum.COVERED)},
                                 state=PlyStateEnum.EXPECTED)

        # WHEN
        result = ply._update_cam_states(cam_id, new_ply_state)

        # THEN
        assert result is True

    @pytest.mark.parametrize(
        "current_cam_state, new_cam_state",
        [
            (EdgeCamStateEnum.NEVER_DETECTED, EdgeCamStateEnum.MISSING),
            (EdgeCamStateEnum.NEVER_DETECTED, EdgeCamStateEnum.DETECTED),
            (EdgeCamStateEnum.NEVER_DETECTED, EdgeCamStateEnum.NEVER_DETECTED),
            (EdgeCamStateEnum.MISSING, EdgeCamStateEnum.DETECTED),
            (EdgeCamStateEnum.MISSING, EdgeCamStateEnum.MISSING),
            (EdgeCamStateEnum.DETECTED, EdgeCamStateEnum.MISSING),
            (EdgeCamStateEnum.DETECTED, EdgeCamStateEnum.DETECTED),
        ]
    )
    def test_should_return_false_when_existing_edge_state_is_already_forced_no_matter_what_cam_state_changes_are_given(
            self, current_cam_state, new_cam_state):
        # GIVEN
        cam_id = "cam1"
        ply = PlyState(ply_id="ply1",
                       edges={
                           EdgeState("edge1",
                                     cams={EdgeCamState(cam_id, current_cam_state)},
                                     state=EdgeStateEnum.FORCED)},
                       state=PlyStateEnum.PLACED)
        new_ply_state = PlyState(ply_id="ply1",
                                 edges={
                                     EdgeState("edge1",
                                               cams={EdgeCamState(cam_id, new_cam_state)},
                                               state=EdgeStateEnum.FORCED)},
                                 state=PlyStateEnum.PLACED)

        # WHEN
        result = ply._update_cam_states(cam_id, new_ply_state)

        # THEN
        assert result is False

    @pytest.mark.parametrize(
        "current_cam_state, new_cam_state",
        [
            (EdgeCamStateEnum.NEVER_DETECTED, EdgeCamStateEnum.MISSING),
            (EdgeCamStateEnum.NEVER_DETECTED, EdgeCamStateEnum.DETECTED),
            (EdgeCamStateEnum.NEVER_DETECTED, EdgeCamStateEnum.NEVER_DETECTED),
            (EdgeCamStateEnum.MISSING, EdgeCamStateEnum.DETECTED),
            (EdgeCamStateEnum.MISSING, EdgeCamStateEnum.MISSING),
            (EdgeCamStateEnum.DETECTED, EdgeCamStateEnum.MISSING),
            (EdgeCamStateEnum.DETECTED, EdgeCamStateEnum.DETECTED),
        ]
    )
    def test_should_return_false_when_existing_edge_state_is_already_covered_no_matter_what_cam_state_changes_are_given(
            self, current_cam_state, new_cam_state):
        # GIVEN
        cam_id = "cam1"
        ply = PlyState(ply_id="ply1",
                       edges={
                           EdgeState("edge1",
                                     cams={EdgeCamState(cam_id, current_cam_state)},
                                     state=EdgeStateEnum.COVERED)},
                       state=PlyStateEnum.PLACED)
        new_ply_state = PlyState(ply_id="ply1",
                                 edges={
                                     EdgeState("edge1",
                                               cams={EdgeCamState(cam_id, new_cam_state)},
                                               state=EdgeStateEnum.COVERED)},
                                 state=PlyStateEnum.PLACED)

        # WHEN
        result = ply._update_cam_states(cam_id, new_ply_state)

        # THEN
        assert result is False
