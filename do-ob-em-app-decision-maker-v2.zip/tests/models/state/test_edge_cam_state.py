# pylint: disable=protected-access, missing-module-docstring, missing-class-docstring, missing-function-docstring, duplicate-code, line-too-long, too-few-public-methods, no-self-use, too-many-locals, too-many-lines
import pytest

from app.models.state.edge_cam_state import EdgeCamState
from app.models.state.edge_cam_state_enum import EdgeCamStateEnum


class EdgeCamStateTests:

    @pytest.mark.parametrize(
        "current_cam_state, new_cam_state, expected_cam_state, expected_cam_updated",
        [
            (EdgeCamStateEnum.NEVER_DETECTED, EdgeCamStateEnum.MISSING, EdgeCamStateEnum.NEVER_DETECTED, False),
            (EdgeCamStateEnum.NEVER_DETECTED, EdgeCamStateEnum.DETECTED, EdgeCamStateEnum.DETECTED, True),
            (EdgeCamStateEnum.MISSING, EdgeCamStateEnum.MISSING, EdgeCamStateEnum.MISSING, False),
            (EdgeCamStateEnum.MISSING, EdgeCamStateEnum.DETECTED, EdgeCamStateEnum.DETECTED, True),
            (EdgeCamStateEnum.DETECTED, EdgeCamStateEnum.MISSING, EdgeCamStateEnum.MISSING, True),
            (EdgeCamStateEnum.DETECTED, EdgeCamStateEnum.DETECTED, EdgeCamStateEnum.DETECTED, False)

        ]
    )
    def test_update_cam_should_transition_state_when_invoking(self, current_cam_state, new_cam_state,
                                                              expected_cam_state, expected_cam_updated):
        # GIVEN
        edge_cam_state = EdgeCamState("cam01", current_cam_state)

        # WHEN edge_cam_state.update_cam is called
        cam_updated = edge_cam_state.update_cam(new_cam_state)

        # THEN correct result is returned
        assert cam_updated is expected_cam_updated
        assert edge_cam_state.state.name is expected_cam_state.name

    def test_update_cam_should_throw_exception_when_edge_state_invalid(self):
        # GIVEN
        edge_cam_state = EdgeCamState("cam01", EdgeCamStateEnum.MISSING)

        # WHEN edge_cam_state.update_cam is called exception should be raised
        with pytest.raises(Exception) as value_error_exc:
            edge_cam_state.update_cam("unknown")

        # THEN ValueError exception is raised
        assert value_error_exc.type is ValueError
        assert "Failed to find cam transition rule for" in value_error_exc.value.args[0]

    @pytest.mark.parametrize(
        "cam_id, cam_state_value",
        [
            ("cam01", EdgeCamStateEnum.MISSING),
            ("cam01", EdgeCamStateEnum.NEVER_DETECTED),
            ("cam01", EdgeCamStateEnum.DETECTED)
        ]
    )
    def test_serialization_should_return_dict_when_various_ply_state_enums_given(self, cam_id,
                                                                                 cam_state_value: EdgeCamStateEnum):
        # GIVEN
        edge_cam_state = EdgeCamState(cam_id, cam_state_value)

        result = edge_cam_state.serialize()

        # THEN correct result is returned
        assert result is not None
        assert result == {
            "cam_id": cam_id,
            "state": cam_state_value.name,
        }

    @pytest.mark.parametrize(
        "cam_id, cam_state_value",
        [
            ("cam01", EdgeCamStateEnum.MISSING),
            ("cam01", EdgeCamStateEnum.NEVER_DETECTED),
            ("cam01", EdgeCamStateEnum.DETECTED)
        ]
    )
    def test_deserialization_should_return_object_when_various_ply_state_enums_given(self, cam_id,
                                                                                     cam_state_value: EdgeCamStateEnum):
        # GIVEN
        state_dict = {
            "cam_id": cam_id,
            "state": cam_state_value.name
        }

        result = EdgeCamState.deserialize(state_dict)

        # THEN correct result is returned
        assert result is not None
        assert result.id is cam_id
        assert result.state.name is cam_state_value.name

    def test_deserialization_should_raise_exception_when_cam_id_missing(self):
        # GIVEN
        state_dict = {
            "state": EdgeCamStateEnum.MISSING.name
        }

        # WHEN edge_state.deserialize is called
        with pytest.raises(Exception) as value_error_exc:
            EdgeCamState.deserialize(state_dict)

        # THEN ValueError exception is raised
        assert value_error_exc.type is ValueError
        assert "Invalid cam state keys" in value_error_exc.value.args[0]

    def test_deserialization_should_raise_exception_when_state_missing(self):
        # GIVEN
        state_dict = {
            "cam_id": "edgE11"
        }

        # WHEN edge_state.deserialize is called
        with pytest.raises(Exception) as value_error_exc:
            EdgeCamState.deserialize(state_dict)

        # THEN ValueError exception is raised
        assert value_error_exc.type is ValueError
        assert "Invalid cam state keys" in value_error_exc.value.args[0]