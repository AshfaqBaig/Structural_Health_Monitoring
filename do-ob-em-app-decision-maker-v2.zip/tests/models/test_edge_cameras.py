# pylint: disable=protected-access, missing-module-docstring, missing-class-docstring, missing-function-docstring, duplicate-code, line-too-long, too-few-public-methods, no-self-use, too-many-locals, too-many-lines
from app.models.edge_cameras import EdgeCameras


class EdgeCamerasTests:
    def test_mould_id_should_return_correct_result(self, sample_edge_to_cameras):
        # GIVEN
        edge_cameras = EdgeCameras(sample_edge_to_cameras)

        # WHEN edge_cameras.mould_id is called
        result = edge_cameras.mould_id

        # THEN correct result is returned
        assert result == sample_edge_to_cameras["mould_id"]

    def test_blade_revision_should_return_correct_result(self, sample_edge_to_cameras):
        # GIVEN
        edge_cameras = EdgeCameras(sample_edge_to_cameras)

        # WHEN edge_cameras.blade_revision is called
        result = edge_cameras.blade_revision

        # THEN correct result is returned
        assert result == sample_edge_to_cameras["blade_revision"]

    def test_invisible_edges_should_return_correct_result(self, sample_edge_to_cameras):
        # GIVEN
        edge_cameras = EdgeCameras(sample_edge_to_cameras)

        # WHEN edge_cameras.invisible_edges is called
        result = edge_cameras.invisible_edges

        # THEN correct result is returned
        assert result == {"E1.1"}

    def test_get_cameras_should_return_correct_result_for_given_edge_id(self, sample_edge_to_cameras):
        # GIVEN
        edge_id = "P3.1"
        edge_cameras = EdgeCameras(sample_edge_to_cameras)

        # WHEN edge_cameras.get_cameras is called
        result = edge_cameras.get_cameras(edge_id)

        # THEN correct result is returned
        assert result == sample_edge_to_cameras["edges"][edge_id]

    def test_get_cameras_should_return_empty_list_for_given_edge_without_cameras(self, sample_edge_to_cameras):
        # GIVEN
        edge_id = "E1.1"
        edge_cameras = EdgeCameras(sample_edge_to_cameras)

        # WHEN edge_cameras.get_cameras is called
        result = edge_cameras.get_cameras(edge_id)

        # THEN correct result is returned
        assert result == []

    def test_is_edge_invisible_should_return_true_if_given_edge_has_no_cameras(self):
        # GIVEN
        edge_to_cameras = {
            "mould_id": "mould_id",
            "blade_revision": "blade_revision",
            "edges": {
                "P1.1": [],
                "P1.2": ["cam1"]
            }
        }
        edge_id = "P1.1"
        edge_cameras = EdgeCameras(edge_to_cameras)

        # WHEN edge_cameras.is_edge_invisible is called
        result = edge_cameras.is_edge_invisible(edge_id)

        # THEN correct result is returned
        assert result is True

    def test_is_edge_invisible_should_return_false_if_given_edge_has_cameras(self):
        # GIVEN
        edge_to_cameras = {
            "mould_id": "mould_id",
            "blade_revision": "blade_revision",
            "edges": {
                "N0.1": [],
                "N0.2": ["cam1"]
            }
        }
        edge_id = "N0.2"
        edge_cameras = EdgeCameras(edge_to_cameras)

        # WHEN edge_cameras.is_edge_invisible is called
        result = edge_cameras.is_edge_invisible(edge_id)

        # THEN correct result is returned
        assert result is False

    def test_filter_invisible_should_return_set_of_invisible_edge_ids(self):
        # GIVEN
        edge_to_cameras = {
            "mould_id": "mould_id",
            "blade_revision": "blade_revision",
            "edges": {
                "N0.1": [],
                "N0.2": ["cam1"],
                "N1.1": ["cam1", "cam2"],
                "N1.2": ["cam2"],
                "N2.1": ["cam2"],
                "N2.2": []
            }
        }

        # WHEN edge_cameras._filter_invisible is called
        result = EdgeCameras._filter_invisible(edge_to_cameras)

        # THEN correct result is returned
        assert result == {"N0.1", "N2.2"}

    def test_filter_invisible_should_return_empty_set_when_all_edges_visible(self):
        # GIVEN
        edge_to_cameras = {
            "mould_id": "mould_id",
            "blade_revision": "blade_revision",
            "edges": {
                "N0.2": ["cam1"],
                "N1.1": ["cam1", "cam2"],
                "N1.2": ["cam2"],
                "N2.1": ["cam2"],
            }
        }

        # WHEN edge_cameras._filter_invisible is called
        result = EdgeCameras._filter_invisible(edge_to_cameras)

        # THEN correct result is returned
        assert result == set()

    def test_filter_invisible_should_return_all_edge_ids_when_all_edges_invisible(self):
        # GIVEN
        edge_to_cameras = {
            "mould_id": "mould_id",
            "blade_revision": "blade_revision",
            "edges": {
                "N0.1": [],
                "N2.2": []
            }
        }

        # WHEN edge_cameras._filter_invisible is called
        result = EdgeCameras._filter_invisible(edge_to_cameras)

        # THEN correct result is returned
        assert result == edge_to_cameras["edges"].keys()
