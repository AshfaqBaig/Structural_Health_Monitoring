# pylint: disable=protected-access, missing-module-docstring, missing-class-docstring, missing-function-docstring, duplicate-code, line-too-long, too-few-public-methods, no-self-use, too-many-locals, too-many-lines
import pytest

from app.dm_helper import edge_verification_message_validation
from app.models.edge_cameras import EdgeCameras
from app.models.graph import Graph
from app.models.state.mould_state import MouldState
from tests.tests_base import recalculate_expected_plies


class EdgeVerificationMessageValidationTests:
    @pytest.mark.parametrize(
        "detected_edges, missing_edges",
        [
            # valid edges variations with visible and expected edges
            ({"P2.1", "P2.2"}, {"P3.1"}),
            ({"P2.1", "P3.2"}, {"P1.1"}),
            ({"P2.1", "P3.1"}, {"P1.1"}),
            ({"P3.1", "P3.2"}, {"P1.1"}),
            ({"P3.1", "P2.2"}, {"P1.1"}),
            ({"P3.1", "P3.2"}, {"P2.1"}),
            ({"P3.1", "P3.2"}, {"P2.2"}),
            # valid edges variation with empty sets
            (set(), set()),
            # valid edges variation with only visible edges
            ({"P2.1", "P2.2"}, {"P1.1"}),
            # valid edges variations with only expected edges
            ({"P3.1", "P3.2"}, {"T1.1", "T1.2"}),
            ({"T1.1", "T1.2"}, {"P3.1", "P3.2"}),
            ({"P3.1", "T1.2"}, {"T1.1", "P3.2"}),
            ({"P3.1", "T1.1"}, {"T1.2", "P3.2"}),
        ]
    )
    def test_should_not_raise_exception_when_given_missing_and_detected_edges_valid(
            self, mocker, sample_mould_state_plies, sample_graph_data, detected_edges, missing_edges,
            sample_edge_to_cameras):
        # GIVEN
        log = mocker.patch("app.dm_helper.edge_verification_message_validation.log")

        mould_state = MouldState(sample_mould_state_plies)
        graph = Graph(sample_graph_data)
        edge_cameras = EdgeCameras(sample_edge_to_cameras)

        # AND
        recalculate_expected_plies(mould_state, graph, edge_cameras)

        # WHEN edge_verification_message_validation.validate is called
        edge_verification_message_validation.validate(detected_edges, missing_edges, mould_state)

        # THEN log.warning is not called
        assert log.warning.call_count == 0

    @pytest.mark.parametrize(
        "detected_edges, missing_edges",
        [
            # invalid edges variations with few valid visible edges
            ({"EX.1", "EX.2"}, {"P1.2"}),
            ({"P2.1", "EX.2"}, {"P1.2"}),
            ({"EX.1", "P2.2"}, {"P1.2"}),
            ({"P2.1", "P2.2"}, {"P1.2"}),
            ({"EX.1", "EX.2"}, {"P1.1"}),
            ({"P2.1", "EX.2"}, {"P1.1"}),
            ({"EX.1", "P2.2"}, {"P1.1"}),
            # invalid edges variations with few valid expected edges
            ({"EX.1", "EX.2"}, {"P1.2"}),
            ({"P3.1", "EX.2"}, {"P1.2"}),
            ({"EX.1", "P3.2"}, {"P1.2"}),
            ({"P3.1", "P3.2"}, {"P1.2"}),
            ({"EX.1", "EX.2"}, {"P1.1"}),
            ({"P3.1", "EX.2"}, {"P1.1"}),
            ({"EX.1", "P3.2"}, {"P1.1"}),
        ]
    )
    def test_should_raise_exception_when_given_missing_or_detected_edges_not_valid(
            self, mocker, sample_mould_state_plies, sample_graph_data, detected_edges, missing_edges,
            sample_edge_to_cameras):
        # GIVEN
        log = mocker.patch("app.dm_helper.edge_verification_message_validation.log")

        mould_state = MouldState(sample_mould_state_plies)
        graph = Graph(sample_graph_data)
        edge_cameras = EdgeCameras(sample_edge_to_cameras)

        # AND
        recalculate_expected_plies(mould_state, graph, edge_cameras)

        # WHEN edge_verification_message_validation.validate is called, assert that an exception is raised
        with pytest.raises(Exception) as exc_info:
            edge_verification_message_validation.validate(detected_edges, missing_edges, mould_state)

        # THEN an exception of type ValueError is raised
        assert exc_info.type is ValueError
        assert "Invalid edge verification data received" in exc_info.value.args[0]

        # AND log.warning is called
        assert log.warning.call_count == 1
        assert "Invalid edge verification data received" in log.warning.call_args.args[0]
