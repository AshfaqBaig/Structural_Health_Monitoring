# pylint: disable=protected-access, missing-module-docstring, missing-class-docstring, missing-function-docstring, duplicate-code, line-too-long, too-few-public-methods, no-self-use, too-many-locals, too-many-lines
from app.dm_helper import edge_verification_message_extraction


class ExtractDetectedAndMissingEdgesTests:
    def test_should_return_correct_result_when_detected_and_missing_edges_feedback_given(self):
        # GIVEN
        detected_edges = {"edge_1", "edge_3"}
        missing_edges = {"edge_2"}
        feedback = [
            {
                "type": "detected-edges",
                "edges": list(detected_edges),
            },
            {
                "type": "missing-edges",
                "edges": list(missing_edges),
            }
        ]

        # WHEN input_message_extraction.detected_and_missing_edges is called
        result = edge_verification_message_extraction.detected_and_missing_edges(feedback)

        # THEN correct result is returned
        assert result == (detected_edges, missing_edges)

    def test_should_return_correct_result_when_empty_feedback_given(self):
        # GIVEN
        detected_edges = set()
        missing_edges = set()
        feedback = []

        # WHEN input_message_extraction.detected_and_missing_edges is called
        result = edge_verification_message_extraction.detected_and_missing_edges(feedback)

        # THEN correct result is returned
        assert result == (detected_edges, missing_edges)

    def test_should_return_correct_result_when_only_detected_edges_feedback_given(self):
        # GIVEN
        detected_edges = {"edge_1", "edge_3"}
        missing_edges = set()
        feedback = [
            {
                "type": "detected-edges",
                "edges": list(detected_edges),
            },
        ]

        # WHEN input_message_extraction.detected_and_missing_edges is called
        result = edge_verification_message_extraction.detected_and_missing_edges(feedback)

        # THEN correct result is returned
        assert result == (detected_edges, missing_edges)

    def test_should_return_correct_result_when_detected_edges_and_empty_missing_edges_feedback_given(self):
        # GIVEN
        detected_edges = {"edge_1", "edge_3"}
        missing_edges = set()
        feedback = [
            {
                "type": "detected-edges",
                "edges": list(detected_edges),
            },
            {
                "type": "missing-edges",
                "edges": list(missing_edges),
            }
        ]

        # WHEN input_message_extraction.detected_and_missing_edges is called
        result = edge_verification_message_extraction.detected_and_missing_edges(feedback)

        # THEN correct result is returned
        assert result == (detected_edges, missing_edges)

    def test_should_return_correct_result_when_only_missing_edges_feedback_given(self):
        # GIVEN
        detected_edges = set()
        missing_edges = {"edge_2", "edge_4"}
        feedback = [
            {
                "type": "missing-edges",
                "edges": list(missing_edges),
            }
        ]

        # WHEN input_message_extraction.detected_and_missing_edges is called
        result = edge_verification_message_extraction.detected_and_missing_edges(feedback)

        # THEN correct result is returned
        assert result == (detected_edges, missing_edges)

    def test_should_return_correct_result_when_missing_edges_and_empty_detected_edges_feedback_given(self):
        # GIVEN
        detected_edges = set()
        missing_edges = {"edge_2", "edge_4"}
        feedback = [
            {
                "type": "detected-edges",
                "edges": list(detected_edges),
            },
            {
                "type": "missing-edges",
                "edges": list(missing_edges),
            }
        ]

        # WHEN input_message_extraction.detected_and_missing_edges is called
        result = edge_verification_message_extraction.detected_and_missing_edges(feedback)

        # THEN correct result is returned
        assert result == (detected_edges, missing_edges)
