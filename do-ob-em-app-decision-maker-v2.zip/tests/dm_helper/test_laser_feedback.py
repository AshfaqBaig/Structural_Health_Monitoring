# pylint: disable=protected-access, missing-module-docstring, missing-class-docstring, missing-function-docstring, duplicate-code, line-too-long, too-few-public-methods, no-self-use, too-many-locals, too-many-lines
from unittest.mock import AsyncMock, patch, call

import pytest

import tests.scenarios.mock_data as mock_data
from app.dm_helper.laser_feedback import LaserFeedback
from app.models.graph import Graph
from app.models.payload_metadata import PayloadMetadata
from app.models.team_instructions import TeamInstructions


@pytest.mark.asyncio
@patch("app.dm_helper.laser_feedback.cfg.MOULD_ID", "mould_id")
class LaserFeedbackInvokeTests:
    async def test_should_create_four_payloads_and_send_all_to_feedback_module_when_four_type_feedback_data_given(
            self, mocker):
        # GIVEN
        feedback_data = {
            "missing-plies": {"P3": {"ply_data": "mock_data"}},
            "plies-to-be-placed": {"P3": {"ply_data": "mock_data"}},
            "correctly-placed-plies": {"P3": {"ply_data": "mock_data"}},
            "last-plies-placed": {"P3": {"ply_data": "mock_data"}},
            "plies-to-null": {"P3": {"ply_data": "mock_data"}},
        }
        team_instruction_data = {
            "version": "v1.0.0",
            "mouldId": "mould_id",
            "bladeSn": "blade_sn",
            "bladeRevision": "blade_revision",
            "layerId": "layer_id",
            "palletId": "pallet_id"
        }
        team_instructions = TeamInstructions([team_instruction_data])
        metadata_to_forward = PayloadMetadata()
        graph_data = Graph(mock_data.static_graph_data)
        messaging_wrapper = mocker.patch("app.dm_helper.laser_feedback.MessagingWrapper", new_callable=AsyncMock)
        laser_feedback = LaserFeedback(messaging_wrapper, graph_data, team_instructions)

        # WHEN laser_feedback.invoke is called
        await laser_feedback.invoke(feedback_data, metadata_to_forward)

        # THEN messaging_wrapper.send_message_to_feedback is called and awaited
        assert messaging_wrapper.send_message_to_feedback.call_count == 5
        assert messaging_wrapper.send_message_to_feedback.await_count == 5

        # AND correct payloads are sent
        actual_payload_calls = messaging_wrapper.send_message_to_feedback.call_args_list
        expected_payload_calls = [
            call({
                "metadata": {
                    "session": {
                        "mouldId": "mould_id",
                        "plyId": "P3",
                        "moduleId": "em-decision-maker"
                    },
                    "groundTruthVersion": "v1.0.0",
                    "mouldId": "mould_id",
                    "bladeSn": "blade_sn",
                    "bladeRevision": "blade_revision",
                    "layers": [
                        "layer_id"
                    ]
                },
                "feedback": [
                    {
                        "type": "missing-plies",
                        "P3": {"ply_data": "mock_data", "next_plies_pallets": []}
                    }
                ],
                "feedbackType": "missing-plies"
            }, metadata_to_forward),
            call({
                "metadata": {
                    "session": {
                        "mouldId": "mould_id",
                        "plyId": "P3",
                        "moduleId": "em-decision-maker"
                    },
                    "groundTruthVersion": "v1.0.0",
                    "mouldId": "mould_id",
                    "bladeSn": "blade_sn",
                    "bladeRevision": "blade_revision",
                    "layers": [
                        "layer_id"
                    ]
                },
                "feedback": [
                    {
                        "type": "plies-to-be-placed",
                        "P3": {"ply_data": "mock_data", "next_plies_pallets": []}
                    }
                ],
                "feedbackType": "plies-to-be-placed"
            }, metadata_to_forward),
            call({
                "metadata": {
                    "session": {
                        "mouldId": "mould_id",
                        "plyId": "P3",
                        "moduleId": "em-decision-maker"
                    },
                    "groundTruthVersion": "v1.0.0",
                    "mouldId": "mould_id",
                    "bladeSn": "blade_sn",
                    "bladeRevision": "blade_revision",
                    "layers": [
                        "layer_id"
                    ]
                },
                "feedback": [
                    {
                        "type": "correctly-placed-plies",
                        "P3": {"ply_data": "mock_data", "next_plies_pallets": []}
                    }
                ],
                "feedbackType": "correctly-placed-plies"
            }, metadata_to_forward),
            call({
                "metadata": {
                    "session": {
                        "mouldId": "mould_id",
                        "plyId": "P3",
                        "moduleId": "em-decision-maker"
                    },
                    "groundTruthVersion": "v1.0.0",
                    "mouldId": "mould_id",
                    "bladeSn": "blade_sn",
                    "bladeRevision": "blade_revision",
                    "layers": [
                        "layer_id"
                    ]
                },
                "feedback": [
                    {
                        "type": "last-plies-placed",
                        "P3": {"ply_data": "mock_data", "next_plies_pallets": []}
                    }
                ],
                "feedbackType": "last-plies-placed"
            }, metadata_to_forward),
            call({
                "metadata": {
                    "session": {
                        "mouldId": "mould_id",
                        "plyId": "P3",
                        "moduleId": "em-decision-maker"
                    },
                    "groundTruthVersion": "v1.0.0",
                    "mouldId": "mould_id",
                    "bladeSn": "blade_sn",
                    "bladeRevision": "blade_revision",
                    "layers": [
                        "layer_id"
                    ]
                },
                "feedback": [
                    {
                        "type": "plies-to-null",
                        "P3": {"ply_data": "mock_data", "next_plies_pallets": []}
                    }
                ],
                "feedbackType": "plies-to-null"
            }, metadata_to_forward),
        ]
        assert actual_payload_calls == expected_payload_calls

    async def test_should_create_single_payload_and_send_to_feedback_module_when_single_type_feedback_data_given(
            self, mocker):
        # GIVEN
        feedback_data = {
            "missing-plies": {"P1": {"ply_data": "mock_data"}},
        }
        team_instruction_data = {
            "version": "v1.0.0",
            "mouldId": "mould_id",
            "bladeSn": "blade_sn",
            "bladeRevision": "blade_revision",
            "layerId": "layer_id",
            "palletId": "pallet_id"
        }
        team_instructions = TeamInstructions([team_instruction_data])
        graph_data = Graph(mock_data.static_graph_data)
        metadata_to_forward = PayloadMetadata()
        messaging_wrapper = mocker.patch("app.dm_helper.laser_feedback.MessagingWrapper", new_callable=AsyncMock)
        laser_feedback = LaserFeedback(messaging_wrapper, graph_data, team_instructions)

        # WHEN laser_feedback.invoke is called
        await laser_feedback.invoke(feedback_data, metadata_to_forward)

        # THEN messaging_wrapper.send_message_to_feedback is called and awaited
        assert messaging_wrapper.send_message_to_feedback.call_count == 1
        assert messaging_wrapper.send_message_to_feedback.await_count == 1

        # AND correct payloads are sent
        actual_payload_calls = messaging_wrapper.send_message_to_feedback.call_args_list
        expected_payload_calls = [
            call({
                "metadata": {
                    "session": {
                        "mouldId": "mould_id",
                        "plyId": "P1",
                        "moduleId": "em-decision-maker"
                    },
                    "groundTruthVersion": "v1.0.0",
                    "mouldId": "mould_id",
                    "bladeSn": "blade_sn",
                    "bladeRevision": "blade_revision",
                    "layers": [
                        "layer_id"
                    ]
                },
                "feedback": [
                    {
                        "type": "missing-plies",
                        "P1": {"ply_data": "mock_data", "next_plies_pallets": ["pallet_1"]}
                    }
                ],
                "feedbackType": "missing-plies"
            }, metadata_to_forward),
        ]
        assert actual_payload_calls == expected_payload_calls

    async def test_should_create_single_payload_and_send_to_feedback_module_when_feedback_of_last_plies_placed_given(
            self, mocker):
        # GIVEN
        feedback_data = {
            "last-plies-placed": {"P9": {"ply_data": "mock_data"}},
        }
        team_instruction_data = {
            "version": "v1.0.0",
            "mouldId": "mould_id",
            "bladeSn": "blade_sn",
            "bladeRevision": "blade_revision",
            "layerId": "layer_id",
            "palletId": "pallet_id"
        }
        team_instructions = TeamInstructions([team_instruction_data])
        graph_data = Graph(mock_data.static_graph_data)
        metadata_to_forward = PayloadMetadata()
        messaging_wrapper = mocker.patch("app.dm_helper.laser_feedback.MessagingWrapper", new_callable=AsyncMock)
        laser_feedback = LaserFeedback(messaging_wrapper, graph_data, team_instructions)

        # WHEN laser_feedback.invoke is called
        await laser_feedback.invoke(feedback_data, metadata_to_forward)

        # THEN messaging_wrapper.send_message_to_feedback is called and awaited
        assert messaging_wrapper.send_message_to_feedback.call_count == 1
        assert messaging_wrapper.send_message_to_feedback.await_count == 1

        # AND correct payloads are sent
        actual_payload_calls = messaging_wrapper.send_message_to_feedback.call_args_list
        expected_payload_calls = [
            call({
                "metadata": {
                    "session": {
                        "mouldId": "mould_id",
                        "plyId": "P9",
                        "moduleId": "em-decision-maker"
                    },
                    "groundTruthVersion": "v1.0.0",
                    "mouldId": "mould_id",
                    "bladeSn": "blade_sn",
                    "bladeRevision": "blade_revision",
                    "layers": [
                        "layer_id"
                    ]
                },
                "feedback": [
                    {
                        "type": "last-plies-placed",
                        "P9": {"ply_data": "mock_data", "next_plies_pallets": []}
                    }
                ],
                "feedbackType": "last-plies-placed"
            }, metadata_to_forward),
        ]
        assert actual_payload_calls == expected_payload_calls

    async def test_should_create_two_payloads_and_send_to_feedback_module_when_two_type_feedback_data_given(
            self, mocker):
        # GIVEN
        feedback_data = {
            "plies-to-be-placed": {"P3": {"ply_data": "mock_data"}},
            "correctly-placed-plies": {"P2": {"ply_data": "mock_data"}},
        }
        team_instruction_data = {
            "version": "v1.0.0",
            "mouldId": "mould_id",
            "bladeSn": "blade_sn",
            "bladeRevision": "blade_revision",
            "layerId": "layer_id",
            "palletId": "pallet_id"
        }
        team_instructions = TeamInstructions([team_instruction_data])
        graph_data = Graph(mock_data.static_graph_data)
        metadata_to_forward = PayloadMetadata()
        messaging_wrapper = mocker.patch("app.dm_helper.laser_feedback.MessagingWrapper", new_callable=AsyncMock)
        laser_feedback = LaserFeedback(messaging_wrapper, graph_data, team_instructions)

        # WHEN laser_feedback.invoke is called
        await laser_feedback.invoke(feedback_data, metadata_to_forward)

        # THEN messaging_wrapper.send_message_to_feedback is called and awaited
        assert messaging_wrapper.send_message_to_feedback.call_count == 2
        assert messaging_wrapper.send_message_to_feedback.await_count == 2

        # AND correct payloads are sent
        actual_payload_calls = messaging_wrapper.send_message_to_feedback.call_args_list
        expected_payload_calls = [
            call({
                "metadata": {
                    "session": {
                        "mouldId": "mould_id",
                        "plyId": "P3",
                        "moduleId": "em-decision-maker"
                    },
                    "groundTruthVersion": "v1.0.0",
                    "mouldId": "mould_id",
                    "bladeSn": "blade_sn",
                    "bladeRevision": "blade_revision",
                    "layers": [
                        "layer_id"
                    ]
                },
                "feedback": [
                    {
                        "type": "plies-to-be-placed",
                        "P3": {"ply_data": "mock_data", "next_plies_pallets": []}
                    }
                ],
                "feedbackType": "plies-to-be-placed"
            }, metadata_to_forward),
            call({
                "metadata": {
                    "session": {
                        "mouldId": "mould_id",
                        "plyId": "P2",
                        "moduleId": "em-decision-maker"
                    },
                    "groundTruthVersion": "v1.0.0",
                    "mouldId": "mould_id",
                    "bladeSn": "blade_sn",
                    "bladeRevision": "blade_revision",
                    "layers": [
                        "layer_id"
                    ]
                },
                "feedback": [
                    {
                        "type": "correctly-placed-plies",
                        "P2": {"ply_data": "mock_data", "next_plies_pallets": ["pallet_1"]}
                    }
                ],
                "feedbackType": "correctly-placed-plies"
            }, metadata_to_forward),
        ]
        assert actual_payload_calls == expected_payload_calls

    async def test_should_not_create_payload_and_do_not_send_to_feedback_module_when_given_feedback_data_is_empty(
            self, mocker):
        # GIVEN
        feedback_data = {}
        team_instruction_data = {
            "version": "v1.0.0",
            "mouldId": "mould_id",
            "bladeSn": "blade_sn",
            "bladeRevision": "blade_revision",
            "layerId": "layer_id",
            "palletId": "pallet_id"
        }
        team_instructions = TeamInstructions([team_instruction_data])
        graph_data = Graph(mock_data.static_graph_data)
        metadata_to_forward = PayloadMetadata()
        messaging_wrapper = mocker.patch("app.dm_helper.laser_feedback.MessagingWrapper", new_callable=AsyncMock)
        laser_feedback = LaserFeedback(messaging_wrapper, graph_data, team_instructions)

        # AND more patched external methods
        log = mocker.patch("app.dm_helper.laser_feedback.log")
        create_feedback_items_and_send = mocker.patch.object(laser_feedback, "_create_feedback_items_and_send")

        # WHEN laser_feedback.invoke is called
        await laser_feedback.invoke(feedback_data, metadata_to_forward)

        # THEN laser_feedback.create_feedback_items_and_send is not called
        assert create_feedback_items_and_send.call_count == 0

        # AND messaging_wrapper.send_message_to_feedback is not called and awaited
        assert messaging_wrapper.send_message_to_feedback.call_count == 0
        assert messaging_wrapper.send_message_to_feedback.await_count == 0

        # AND log.warning is called once with correct argument
        warning_message = "Nothing to process, empty or None feedback_data given: {}"
        log.warning.assert_called_once()
        call_args = log.warning.call_args.args
        assert call_args[0] == warning_message

    async def test_should_log_warning_and_skip_one_feedback_to_send_as_payload_when_one_of_given_plies_data_is_empty(
            self, mocker):
        # GIVEN
        feedback_data = {
            "missing-plies": {},
            "plies-to-be-placed": {"P3": {"ply_data": "mock_data"}},
            "correctly-placed-plies": {"P2": {"ply_data": "mock_data"}},
        }
        team_instruction_data = {
            "version": "v1.0.0",
            "mouldId": "mould_id",
            "bladeSn": "blade_sn",
            "bladeRevision": "blade_revision",
            "layerId": "layer_id",
            "palletId": "pallet_id"
        }
        team_instructions = TeamInstructions([team_instruction_data])
        graph_data = Graph(mock_data.static_graph_data)
        metadata_to_forward = PayloadMetadata()
        messaging_wrapper = mocker.patch("app.dm_helper.laser_feedback.MessagingWrapper", new_callable=AsyncMock)
        laser_feedback = LaserFeedback(messaging_wrapper, graph_data, team_instructions)

        # AND more patched external methods
        log = mocker.patch("app.dm_helper.laser_feedback.log")

        # WHEN laser_feedback.invoke is called
        await laser_feedback.invoke(feedback_data, metadata_to_forward)

        # THEN log.warning is called once with correct argument (missing_plies was skipped)
        warning_message = f"Can't process empty or None plies for feedback_type: missing-plies," \
                          f" in given feedback_data: {feedback_data}"
        log.warning.assert_called_once()
        call_args = log.warning.call_args.args
        assert call_args[0] == warning_message

        # AND messaging_wrapper.send_message_to_feedback is called and awaited
        assert messaging_wrapper.send_message_to_feedback.call_count == 2
        assert messaging_wrapper.send_message_to_feedback.await_count == 2

        # AND correct payloads are sent
        actual_payload_calls = messaging_wrapper.send_message_to_feedback.call_args_list
        expected_payload_calls = [
            call({
                "metadata": {
                    "session": {
                        "mouldId": "mould_id",
                        "plyId": "P3",
                        "moduleId": "em-decision-maker"
                    },
                    "groundTruthVersion": "v1.0.0",
                    "mouldId": "mould_id",
                    "bladeSn": "blade_sn",
                    "bladeRevision": "blade_revision",
                    "layers": [
                        "layer_id"
                    ]
                },
                "feedback": [
                    {
                        "type": "plies-to-be-placed",
                        "P3": {"ply_data": "mock_data", "next_plies_pallets": []}
                    }
                ],
                "feedbackType": "plies-to-be-placed"
            }, metadata_to_forward),
            call({
                "metadata": {
                    "session": {
                        "mouldId": "mould_id",
                        "plyId": "P2",
                        "moduleId": "em-decision-maker"
                    },
                    "groundTruthVersion": "v1.0.0",
                    "mouldId": "mould_id",
                    "bladeSn": "blade_sn",
                    "bladeRevision": "blade_revision",
                    "layers": [
                        "layer_id"
                    ]
                },
                "feedback": [
                    {
                        "type": "correctly-placed-plies",
                        "P2": {"ply_data": "mock_data", "next_plies_pallets": ["pallet_1"]}
                    }
                ],
                "feedbackType": "correctly-placed-plies"
            }, metadata_to_forward),
        ]
        assert actual_payload_calls == expected_payload_calls

    async def test_should_log_warning_and_skip_one_feedback_to_send_as_payload_when_one_of_given_plies_data_is_none(
            self, mocker):
        # GIVEN
        feedback_data = {
            "missing-plies": None,
            "plies-to-be-placed": {"P3": {"ply_data": "mock_data"}},
        }
        team_instruction_data = {
            "version": "v1.0.0",
            "mouldId": "mould_id",
            "bladeSn": "blade_sn",
            "bladeRevision": "blade_revision",
            "layerId": "layer_id",
            "palletId": "pallet_id"
        }
        team_instructions = TeamInstructions([team_instruction_data])
        graph_data = Graph(mock_data.static_graph_data)
        metadata_to_forward = PayloadMetadata()
        messaging_wrapper = mocker.patch("app.dm_helper.laser_feedback.MessagingWrapper", new_callable=AsyncMock)
        laser_feedback = LaserFeedback(messaging_wrapper, graph_data, team_instructions)

        # AND more patched external methods
        log = mocker.patch("app.dm_helper.laser_feedback.log")

        # WHEN laser_feedback.invoke is called
        await laser_feedback.invoke(feedback_data, metadata_to_forward)

        # THEN log.warning is called once with correct argument (missing_plies was skipped)
        warning_message = f"Can't process empty or None plies for feedback_type: missing-plies," \
                          f" in given feedback_data: {feedback_data}"
        log.warning.assert_called_once()
        call_args = log.warning.call_args.args
        assert call_args[0] == warning_message

        # AND messaging_wrapper.send_message_to_feedback is called and awaited
        assert messaging_wrapper.send_message_to_feedback.call_count == 1
        assert messaging_wrapper.send_message_to_feedback.await_count == 1

        # AND correct payloads are sent
        actual_payload_calls = messaging_wrapper.send_message_to_feedback.call_args_list
        expected_payload_calls = [
            call({
                "metadata": {
                    "session": {
                        "mouldId": "mould_id",
                        "plyId": "P3",
                        "moduleId": "em-decision-maker"
                    },
                    "groundTruthVersion": "v1.0.0",
                    "mouldId": "mould_id",
                    "bladeSn": "blade_sn",
                    "bladeRevision": "blade_revision",
                    "layers": [
                        "layer_id"
                    ]
                },
                "feedback": [
                    {
                        "type": "plies-to-be-placed",
                        "P3": {"ply_data": "mock_data", "next_plies_pallets": []}
                    }
                ],
                "feedbackType": "plies-to-be-placed"
            }, metadata_to_forward),
        ]
        assert actual_payload_calls == expected_payload_calls
