# pylint: disable=protected-access, missing-module-docstring, missing-class-docstring, missing-function-docstring, duplicate-code, line-too-long, too-few-public-methods, no-self-use, too-many-locals, too-many-lines
from unittest.mock import AsyncMock, patch

import pytest

import app.config as cfg
from app.dm_helper.image_grabbing import ImageGrabbing
from app.models.payload_metadata import PayloadMetadata


@pytest.mark.asyncio
@patch("app.dm_helper.image_grabbing.cfg.MOULD_ID", "mould_id")
class ImageGrabbingTests:
    async def test_start_should_create_correct_payload_and_send_to_image_grabbers(self, mocker):
        # GIVEN
        messaging_wrapper = mocker.patch("app.dm_helper.image_grabbing.MessagingWrapper", new_callable=AsyncMock)
        image_grabbing = ImageGrabbing(messaging_wrapper)
        refresh_interval_in_seconds = 180
        cams = {"cam1", "cam2", "cam3"}
        metadata_to_forward = PayloadMetadata()

        # WHEN
        await image_grabbing.start_update(cams, refresh_interval_in_seconds, metadata_to_forward)

        # THEN
        messaging_wrapper.send_message_to_image_grabber.assert_called_once()
        messaging_wrapper.send_message_to_image_grabber.assert_awaited_once()

        # AND correct payload is sent
        call_args = messaging_wrapper.send_message_to_image_grabber.call_args.args
        assert len(call_args) == 2
        inner_payload = {
            "command": "start_capture",
            "params": {
                "refresh_interval_in_seconds": refresh_interval_in_seconds
            },
            "metadata": {
                "session": {"mouldId": cfg.MOULD_ID}
            }
        }
        expected_payload = {
            "cam1": inner_payload,
            "cam2": inner_payload,
            "cam3": inner_payload,
        }
        actual_payload = call_args[0]
        assert actual_payload == expected_payload

        # AND correct metadata is sent
        actual_metadata = call_args[1]
        assert actual_metadata.session == metadata_to_forward.session
        assert actual_metadata.correlation_id == metadata_to_forward.correlation_id
        assert actual_metadata.custom_properties == metadata_to_forward.custom_properties

    async def test_stop_should_create_correct_payload_and_send_to_image_grabbers(self, mocker):
        # GIVEN
        messaging_wrapper = mocker.patch("app.dm_helper.image_grabbing.MessagingWrapper", new_callable=AsyncMock)
        image_grabbing = ImageGrabbing(messaging_wrapper)
        cams = {"cam1", "cam2", "cam3"}
        metadata_to_forward = PayloadMetadata()

        # WHEN
        await image_grabbing.stop(cams, metadata_to_forward)

        # THEN
        messaging_wrapper.send_message_to_image_grabber.assert_called_once()
        messaging_wrapper.send_message_to_image_grabber.assert_awaited_once()

        # AND correct payload is sent
        call_args = messaging_wrapper.send_message_to_image_grabber.call_args.args
        assert len(call_args) == 2
        inner_payload = {
            "command": "stop_capture",
            "metadata": {
                "session": {"mouldId": cfg.MOULD_ID}
            }
        }
        expected_payload = {
            "cam1": inner_payload,
            "cam2": inner_payload,
            "cam3": inner_payload,
        }
        actual_payload = call_args[0]
        assert actual_payload == expected_payload

        # AND correct metadata is sent
        actual_metadata = call_args[1]
        assert actual_metadata.session == metadata_to_forward.session
        assert actual_metadata.correlation_id == metadata_to_forward.correlation_id
        assert actual_metadata.custom_properties == metadata_to_forward.custom_properties
