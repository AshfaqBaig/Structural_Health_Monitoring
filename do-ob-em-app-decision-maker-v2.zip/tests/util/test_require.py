# pylint: disable=protected-access, missing-module-docstring, missing-class-docstring, missing-function-docstring, duplicate-code, line-too-long, too-few-public-methods, no-self-use, too-many-locals, too-many-lines
import pytest

from app.util import require


class RequireNotEmptyTests:
    def test_should_raise_exception_when_empty_list_given(self, mocker):
        # GIVEN
        value = []
        value_name = "list"
        log = mocker.patch("app.util.require.log")

        # WHEN require.not_empty is called, assert that an exception is raised
        with pytest.raises(Exception) as exc_info:
            require.not_empty(value, value_name)

        # THEN an exception of correct type is raised
        assert exc_info.type is ValueError
        error_message = f"'{value_name}' must not be empty or None."
        assert exc_info.value.args[0] == error_message

        # AND log.error is called with correct argument
        assert log.error.call_count == 1
        call_args = log.error.call_args.args
        assert call_args[0] == error_message

    def test_should_not_raise_exception_when_not_empty_list_given(self, mocker):
        # GIVEN
        value = ["not", "empty"]
        value_name = "list"
        log = mocker.patch("app.util.require.log")

        # WHEN require.not_empty is called
        require.not_empty(value, value_name)

        # THEN an exception is not raised AND log.error is not called
        assert log.error.call_count == 0

    def test_should_raise_exception_when_empty_set_given(self, mocker):
        # GIVEN
        value = set()
        value_name = "set"
        log = mocker.patch("app.util.require.log")

        # WHEN require.not_empty is called, assert that an exception is raised
        with pytest.raises(Exception) as exc_info:
            require.not_empty(value, value_name)

        # THEN an exception of correct type is raised
        assert exc_info.type is ValueError
        error_message = f"'{value_name}' must not be empty or None."
        assert exc_info.value.args[0] == error_message

        # AND log.error is called with correct argument
        assert log.error.call_count == 1
        call_args = log.error.call_args.args
        assert call_args[0] == error_message

    def test_should_not_raise_exception_when_not_empty_set_given(self, mocker):
        # GIVEN
        value = {"not", "empty"}
        value_name = "set"
        log = mocker.patch("app.util.require.log")

        # WHEN require.not_empty is called
        require.not_empty(value, value_name)

        # THEN an exception is not raised AND log.error is not called
        assert log.error.call_count == 0

    def test_should_raise_exception_when_empty_dict_given(self, mocker):
        # GIVEN
        value = {}
        value_name = "dict"
        log = mocker.patch("app.util.require.log")

        # WHEN require.not_empty is called, assert that an exception is raised
        with pytest.raises(Exception) as exc_info:
            require.not_empty(value, value_name)

        # THEN an exception of correct type is raised
        assert exc_info.type is ValueError
        error_message = f"'{value_name}' must not be empty or None."
        assert exc_info.value.args[0] == error_message

        # AND log.error is called with correct argument
        assert log.error.call_count == 1
        call_args = log.error.call_args.args
        assert call_args[0] == error_message

    def test_should_not_raise_exception_when_not_empty_dict_given(self, mocker):
        # GIVEN
        value = {"not": "empty"}
        value_name = "dict"
        log = mocker.patch("app.util.require.log")

        # WHEN require.not_empty is called
        require.not_empty(value, value_name)

        # THEN an exception is not raised AND log.error is not called
        assert log.error.call_count == 0

    def test_should_raise_exception_when_value_of_none_given(self, mocker):
        # GIVEN
        value = None
        value_name = "None"
        log = mocker.patch("app.util.require.log")

        # WHEN require.not_empty is called, assert that an exception is raised
        with pytest.raises(Exception) as exc_info:
            require.not_empty(value, value_name)

        # THEN an exception of correct type is raised
        assert exc_info.type is ValueError
        error_message = f"'{value_name}' must not be empty or None."
        assert exc_info.value.args[0] == error_message

        # AND log.error is called with correct argument
        assert log.error.call_count == 1
        call_args = log.error.call_args.args
        assert call_args[0] == error_message


class RequireNotNoneTests:
    def test_should_raise_exception_when_value_of_none_given(self, mocker):
        # GIVEN
        value = None
        value_name = "None"
        log = mocker.patch("app.util.require.log")

        # WHEN require.not_none is called, assert that an exception is raised
        with pytest.raises(Exception) as exc_info:
            require.not_none(value, value_name)

        # THEN an exception of correct type is raised
        assert exc_info.type is ValueError
        error_message = f"'{value_name}' must not be None."
        assert exc_info.value.args[0] == error_message

        # AND log.error is called with correct argument
        assert log.error.call_count == 1
        call_args = log.error.call_args.args
        assert call_args[0] == error_message

    def test_should_not_raise_exception_when_not_value_of_none_given(self, mocker):
        # GIVEN
        value = "string"
        value_name = "string"
        log = mocker.patch("app.util.require.log")

        # WHEN require.not_empty is called
        require.not_empty(value, value_name)

        # THEN an exception is not raised AND log.error is not called
        assert log.error.call_count == 0
