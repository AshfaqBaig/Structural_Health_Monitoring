# pylint: disable=protected-access, missing-module-docstring, missing-class-docstring, missing-function-docstring, duplicate-code, line-too-long, too-few-public-methods, no-self-use, too-many-locals, too-many-lines

import pytest

from app.models.team_instructions import TeamInstructions


@pytest.mark.asyncio
class TeamInstructionsStoreTests:
    async def test_should_store_all_team_instructions_when_all_matching_given_mould_id_in_config(
            self, mocker, sample_instructions_data):
        # GIVEN
        mould_id = sample_instructions_data[0]["mouldId"]
        mocker.patch("app.models.team_instructions.cfg.MOULD_ID", mould_id)
        team_instructions = TeamInstructions()

        # WHEN team_instructions._store is called
        team_instructions._store(sample_instructions_data)

        # THEN correct team instructions are stored
        team_instructions_data = team_instructions.data
        assert team_instructions_data is not None and len(team_instructions_data) > 0
        assert team_instructions_data == sample_instructions_data

    async def test_should_store_only_team_instructions_matching_given_mould_id_in_config(
            self, mocker, sample_instructions_data):
        # GIVEN
        sample_instructions_data[0]["mouldId"] = "assign_different_not_matching_mould_id"
        mould_id = sample_instructions_data[1]["mouldId"]
        mocker.patch("app.models.team_instructions.cfg.MOULD_ID", mould_id)
        team_instructions = TeamInstructions()

        # WHEN team_instructions._store is called
        team_instructions._store(sample_instructions_data)

        # THEN correct team instruction is stored
        team_instructions_data = team_instructions.data
        assert team_instructions_data is not None and len(team_instructions_data) > 0
        assert team_instructions_data == [sample_instructions_data[1], sample_instructions_data[2]]

    async def test_should_store_empty_list_when_none_matching_given_mould_id_in_config(
            self, mocker, sample_instructions_data):
        # GIVEN
        mould_id = "not_matching_mould_id"
        mocker.patch("app.models.team_instructions.cfg.MOULD_ID", mould_id)
        team_instructions = TeamInstructions()

        # WHEN team_instructions._store is called
        team_instructions._store(sample_instructions_data)

        # THEN team instructions are not stored
        assert team_instructions.data == []

    @pytest.mark.parametrize(
        "mould_team_instructions",
        [
            [  # when_not_homogenous_blade_revision
                {
                    "version": "v1.0.0",
                    "mouldId": "mould_id",
                    "bladeRevision": "blade_revision",
                    "layerId": "layer_id",
                    "palletId": "pallet_1"
                },
                {
                    "version": "v1.0.0",
                    "mouldId": "mould_id",
                    "bladeRevision": "not_homogenous_blade_revision",
                    "layerId": "layer_id",
                    "palletId": "pallet_2"
                },
            ],
            [  # when_not_homogenous_version
                {
                    "version": "v1.0.0",
                    "mouldId": "mould_id",
                    "bladeRevision": "blade_revision",
                    "layerId": "layer_id",
                    "palletId": "pallet_1"
                },
                {
                    "version": "not_homogenous_version",
                    "mouldId": "mould_id",
                    "bladeRevision": "blade_revision",
                    "layerId": "layer_id",
                    "palletId": "pallet_2"
                },
            ],
            [  # when_both_properties_not_homogenous
                {
                    "version": "v1.0.0",
                    "mouldId": "mould_id",
                    "bladeRevision": "blade_revision",
                    "layerId": "layer_id",
                    "palletId": "pallet_1"
                },
                {
                    "version": "not_homogenous_version",
                    "mouldId": "mould_id",
                    "bladeRevision": "not_homogenous_blade_revision",
                    "layerId": "layer_id",
                    "palletId": "pallet_2"
                },
            ],
        ]
    )
    async def test_should_send_error_and_raise_exception_when_properties_not_homogenous_in_filtered_instructions_given(
            self, mocker, mould_team_instructions):
        # GIVEN
        blade_revisions = {mould_team_instructions[0]["bladeRevision"], mould_team_instructions[1]["bladeRevision"]}
        versions = {mould_team_instructions[0]["version"], mould_team_instructions[1]["version"]}
        mould_id = mould_team_instructions[0]["mouldId"]
        mocker.patch("app.models.team_instructions.cfg.MOULD_ID", mould_id)
        team_instructions = TeamInstructions()

        # WHEN team_instructions._store is called, assert that an exception is raised
        with pytest.raises(Exception) as exc_info:
            team_instructions._store(mould_team_instructions)

        # THEN an exception of correct type is raised
        assert exc_info.type is ValueError
        error_message = f"Filtered mould_team_instructions: {mould_team_instructions}\n" \
                        f"have different, not homogenous (mould_id, blade_revision, version) combinations. " \
                        f"Found blade_revisions: {blade_revisions} and versions: {versions}, for mould_id: {mould_id}."
        assert exc_info.value.args[0] == error_message
