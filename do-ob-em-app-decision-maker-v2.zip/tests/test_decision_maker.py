# pylint: disable=protected-access, missing-module-docstring, missing-class-docstring, missing-function-docstring, duplicate-code, line-too-long, too-few-public-methods, no-self-use, too-many-locals, too-many-lines
import copy
from unittest.mock import Mock, AsyncMock, call, patch

import pytest

from app.decision_maker import DecisionMaker
from app.global_mould_state_enum import GlobalMouldState
from app.models.edge_cameras import EdgeCameras
from app.models.graph import Graph
from app.models.payload_metadata import PayloadMetadata
from app.models.state.edge_cam_state import EdgeCamState
from app.models.state.edge_cam_state_enum import EdgeCamStateEnum
from app.models.state.edge_state import EdgeState
from app.models.state.edge_state_enum import EdgeStateEnum
from app.models.state.mould_state import MouldState
from app.models.state.ply_state import PlyState
from app.models.state.ply_state_enum import PlyStateEnum
from app.models.team_instructions import TeamInstructions
from tests.scenarios.mock_data import static_graph_data
from tests.tests_base import recalculate_expected_plies, StatePliesMock, create_edge_verification_feedback, \
    create_finalise_c2dm_request, create_force_ply_c2dm_request, create_add_team_instruction_c2dm_request, \
    create_recheck_ply_c2dm_request, create_undo_ply_c2dm_request, create_undo_plies_to_dry_run_c2dm_request, \
    create_undo_plies_to_c2dm_request


@pytest.mark.asyncio
@patch("app.config.MOULD_ID", "mould_id")
class HandleAddTeamInstructionCommandTests:
    async def test_should_correctly_process_initial_team_instruction(self, mocker):
        # GIVEN
        team_instruction_data = {
            "version": "v1.0.0",
            "mouldId": "mould_id",
            "bladeSn": "blade_sn",
            "bladeRevision": "blade_revision",
            "layerId": "layer_id",
            "palletId": "pallet_id"
        }
        team_instruction_request = create_add_team_instruction_c2dm_request(team_instruction_data)

        global_mould_state_plies = {}
        expected_initial_ply = PlyState(
            "N0",
            edges={
                EdgeState(
                    "N0.1",
                    cams=set(),
                    state=EdgeStateEnum.MISSING
                ),
                EdgeState(
                    "N0.2",
                    cams=set(),
                    state=EdgeStateEnum.MISSING
                ),
            },
            state=PlyStateEnum.EXPECTED,
            previous_state=None,
            updated_by="initial",
            source_device=None
        )
        expected_mould_state_plies = {expected_initial_ply}

        static_graph_data = {
            "mould_id": "mould_id",
            "blade_revision": "blade_revision",
            "plies": {
                "N0": {
                    "layer_id": "layer_id",
                    "pallet_id": "pallet_id",
                    "previous_plies": [],
                    "edges_covered": [],
                    "edges": ["N0.1", "N0.2"]},
                "M0": {
                    "layer_id": "new_layer_id",
                    "pallet_id": "pallet_id",
                    "previous_plies": [],
                    "edges_covered": [],
                    "edges": ["M0.1", "M0.2"]},
            }
        }
        expected_sub_graph_data = {
            "mould_id": "mould_id",
            "blade_revision": "blade_revision",
            "plies": {
                "N0": {
                    "layer_id": "layer_id",
                    "pallet_id": "pallet_id",
                    "previous_plies": [],
                    "edges_covered": [],
                    "edges": ["N0.1", "N0.2"]},
            }
        }

        shared_storage = mocker.patch("app.decision_maker.SharedStorage")
        messaging_wrapper = mocker.patch("app.decision_maker.MessagingWrapper", new_callable=AsyncMock)
        team_instructions = TeamInstructions([])
        decision_maker = DecisionMaker(shared_storage, messaging_wrapper, team_instructions, MouldState(set()))

        # AND more methods patched
        file_storage = mocker.patch("app.decision_maker.file_storage")
        mocker.patch("app.decision_maker.file_storage.get_static_graph", return_value=Graph(static_graph_data))

        mocker.patch("app.decision_maker.SharedStorage.get_mould_plies", return_value=global_mould_state_plies)
        mocker.patch("app.decision_maker.SharedStorage.get_mould_state", return_value=GlobalMouldState.NONE)
        mocker.patch("app.decision_maker.SharedStorage.get_mould_blade_sn", return_value=None)
        mocker.patch("app.decision_maker.SharedStorage.watch_prefix")

        image_grabbing_start = mocker.patch("app.decision_maker.ImageGrabbing.start_update")
        feedback_invoke = mocker.patch("app.decision_maker.LaserFeedback.invoke")

        # WHEN decision_maker.handle_add_team_instruction_command is called
        await decision_maker.handle_add_team_instruction_command(team_instruction_request.payload)

        # THEN file_storage is called to load all files from file system with correct arguments
        assert file_storage.get_static_graph.call_count == 1
        call_args = file_storage.get_static_graph.call_args.args
        assert call_args[0] == team_instructions
        assert file_storage.get_edge_cameras.call_count == 1
        call_args = file_storage.get_edge_cameras.call_args.args
        assert call_args[0] == team_instructions
        assert file_storage.get_feedback_positions.call_count == 1
        call_args = file_storage.get_feedback_positions.call_args.args
        assert call_args[0] == team_instructions

        # AND to initially value of None, the instance of Graph is assigned
        _static_graph = decision_maker._static_graph
        assert _static_graph is not None
        assert isinstance(_static_graph, Graph)
        assert _static_graph._stored_graph_data == static_graph_data

        # AND to initially value of None, read files are assigned
        assert decision_maker._edge_cameras is not None
        assert decision_maker._feedback_positions is not None

        # AND to initially value of None, the instance of SubGraphStorage is assigned
        _sub_graph = decision_maker._sub_graph
        assert _sub_graph is not None
        assert isinstance(_sub_graph, Graph)
        assert _sub_graph.data == expected_sub_graph_data

        # AND
        assert shared_storage.get_mould_plies.call_count == 1

        # AND
        assert shared_storage.watch_mould_plies_updates.call_count == 1

        # AND to initially value of None, the instance of MouldState is assigned
        _state_mould = decision_maker._mould_state
        assert _state_mould is not None
        assert isinstance(_state_mould, MouldState)

        # AND messaging.send_message_to_edge_verification is called and awaited
        assert messaging_wrapper.send_message_to_edge_verification.call_count == 1
        assert messaging_wrapper.send_message_to_edge_verification.await_count == 1

        # AND
        assert image_grabbing_start.call_count == 2
        assert image_grabbing_start.await_count == 2

        # AND Feedback().invoke is called and awaited once with correct argument
        assert feedback_invoke.call_count == 1
        assert feedback_invoke.await_count == 1
        call_args = feedback_invoke.call_args.args
        assert call_args[0] == {
            "plies-to-be-placed": expected_sub_graph_data["plies"]
        }

        # AND sub_graph with team_instructions and mould state have correct values
        assert decision_maker._sub_graph.data == expected_sub_graph_data
        assert decision_maker._team_instructions.data == [team_instruction_data]
        assert len(_state_mould.plies) == len(expected_mould_state_plies)
        expected_state_plies = sorted(
            [ply.serialize() for ply in expected_mould_state_plies], key=lambda i: i["ply_id"])
        actual_state_plies = sorted([ply.serialize() for ply in _state_mould.plies], key=lambda i: i["ply_id"])
        assert actual_state_plies == expected_state_plies

    async def test_should_correctly_process_not_initial_team_instruction(self, mocker, sample_edge_to_cameras):
        # GIVEN
        team_instruction_data = {
            "version": "v1.0.0",
            "mouldId": "mould_id",
            "bladeSn": "blade_sn",
            "bladeRevision": "blade_revision",
            "layerId": "layer_id",
            "palletId": "pallet_id"
        }
        team_instruction_data_update = {
            "version": "v1.0.0",
            "mouldId": "mould_id",
            "bladeSn": "blade_sn",
            "bladeRevision": "blade_revision",
            "layerId": "new_layer_id",
            "palletId": "pallet_id"
        }
        team_instruction_update_request = create_add_team_instruction_c2dm_request(team_instruction_data_update)

        expected_mould_state_plies = {
            PlyState(
                "M0",
                edges={
                    EdgeState("M0.1", cams=set(), state=EdgeStateEnum.MISSING),
                    EdgeState("M0.2", cams=set(), state=EdgeStateEnum.MISSING),
                },
                state=PlyStateEnum.EXPECTED,
                previous_state=None,
                updated_by="initial"
            ),
            PlyState(
                "N0",
                edges={
                    EdgeState("N0.1", cams=set(), state=EdgeStateEnum.MISSING),
                    EdgeState("N0.2", cams=set(), state=EdgeStateEnum.MISSING),
                },
                state=PlyStateEnum.EXPECTED,
                previous_state=None,
                updated_by="initial"
            )
        }

        static_graph_data = {
            "mould_id": "mould_id",
            "blade_revision": "blade_revision",
            "plies": {
                "N0": {
                    "layer_id": "layer_id",
                    "pallet_id": "pallet_id",
                    "previous_plies": [],
                    "edges": ["N0.1", "N0.2"]
                },
                "M0": {
                    "layer_id": "new_layer_id",
                    "pallet_id": "pallet_id",
                    "previous_plies": [],
                    "edges": ["M0.1", "M0.2"]
                }
            }
        }

        shared_storage = mocker.patch("app.decision_maker.SharedStorage")
        messaging_wrapper = mocker.patch("app.decision_maker.MessagingWrapper", new_callable=AsyncMock)
        team_instructions = TeamInstructions([team_instruction_data])
        decision_maker = DecisionMaker(shared_storage, messaging_wrapper, team_instructions, MouldState(set()))

        # AND
        decision_maker._static_graph = Graph(static_graph_data)
        decision_maker._edge_cameras = EdgeCameras(sample_edge_to_cameras)
        decision_maker._feedback_positions = Mock(spec=dict)

        # AND more methods patched
        file_storage = mocker.patch("app.decision_maker.file_storage")
        image_grabbing_start = mocker.patch("app.decision_maker.ImageGrabbing.start_update")
        feedback_invoke = mocker.patch("app.decision_maker.LaserFeedback.invoke")
        mocker.patch("app.decision_maker.SharedStorage.get_mould_state", return_value=GlobalMouldState.NONE)
        mocker.patch("app.decision_maker.SharedStorage.get_mould_blade_sn", return_value=None)

        # WHEN decision_maker.handle_add_team_instruction_command is called
        await decision_maker.handle_add_team_instruction_command(team_instruction_update_request.payload)

        # THEN file_storage is not called - all files from file system was already loaded
        assert file_storage.get_static_graph.call_count == 0
        assert file_storage.get_edge_cameras.call_count == 0
        assert file_storage.get_feedback_positions.call_count == 0

        # AND shared_storage.watch_prefix is not called
        assert shared_storage.watch_prefix.call_count == 0

        # AND messaging.send_message_to_edge_verification is called and awaited
        assert messaging_wrapper.send_message_to_edge_verification.call_count == 1
        assert messaging_wrapper.send_message_to_edge_verification.await_count == 1

        # AND
        assert image_grabbing_start.call_count == 2
        assert image_grabbing_start.await_count == 2

        # AND Feedback().invoke is called and awaited once with correct argument
        assert feedback_invoke.call_count == 1
        assert feedback_invoke.await_count == 1
        call_args = feedback_invoke.call_args.args
        assert call_args[0] == {
            "plies-to-be-placed": static_graph_data["plies"]
        }

        # AND sub_graph with team_instructions and mould state have correct values
        assert decision_maker._sub_graph.data == static_graph_data
        assert decision_maker._team_instructions.data == [team_instruction_data, team_instruction_data_update]
        assert len(decision_maker._mould_state.plies) == len(expected_mould_state_plies)
        expected_state_plies = sorted([ply.serialize() for ply in expected_mould_state_plies],
                                      key=lambda i: i["ply_id"])
        actual_state_plies = sorted([ply.serialize() for ply in decision_maker._mould_state.plies],
                                    key=lambda i: i["ply_id"])
        assert actual_state_plies == expected_state_plies

    async def test_should_raise_exception_and_abort_processing_when_static_graph_does_not_match_given_team_instruction(
            self, mocker):
        # GIVEN
        team_instruction = {
            "version": "v1.0.0",
            "mouldId": "mould_id",
            "bladeSn": "blade_sn",
            "bladeRevision": "blade_revision",
            "layerId": "layer_id",
            "palletId": "pallet_id"
        }
        team_instruction_request = create_add_team_instruction_c2dm_request(team_instruction)
        mocker.patch("app.decision_maker.cfg.MOULD_ID", team_instruction["mouldId"])
        static_graph_data = {
            "mould_id": "mould_id",
            "blade_revision": "blade_revision",
            "plies": {
                "M0": {
                    "layer_id": "new_layer_id",
                    "pallet_id": "pallet_id",
                    "previous_plies": [],
                    "edges": ["M0.1", "M0.2"]
                }
            }
        }
        shared_storage = mocker.patch("app.decision_maker.SharedStorage")
        messaging_wrapper = mocker.patch("app.decision_maker.MessagingWrapper", new_callable=AsyncMock)
        decision_maker = DecisionMaker(shared_storage, messaging_wrapper, TeamInstructions([]), MouldState(set()))

        # AND more methods patched
        mocker.patch("app.decision_maker.file_storage")
        mocker.patch("app.decision_maker.file_storage.get_static_graph", return_value=Graph(static_graph_data))
        mocker.patch("app.decision_maker.SharedStorage.get_mould_state", return_value=GlobalMouldState.NONE)
        mocker.patch("app.decision_maker.SharedStorage.get_mould_blade_sn", return_value=None)

        # WHEN decision_maker.handle_add_team_instruction_command is called, assert that an exception is raised
        with pytest.raises(Exception) as exc_info:
            await decision_maker.handle_add_team_instruction_command(team_instruction_request.payload)

        # THEN an exception of type ValueError is raised
        assert exc_info.type is ValueError
        warning_message = f"Failed to create sub-graph, filtered plies are empty: {{}}\n" \
                          f"for given team instructions: {[team_instruction]}"
        assert exc_info.value.args[0] == warning_message

        # THEN decision_maker._sub_graph is None, means execution of handler was aborted
        assert decision_maker._sub_graph is None

    async def test_should_raise_exception_and_abort_processing_when_empty_instruction_recieved(self, mocker):
        # GIVEN
        empty_team_instruction_data = {}
        team_instruction_request = create_add_team_instruction_c2dm_request(empty_team_instruction_data)
        team_instructions = mocker.patch("app.decision_maker.TeamInstructions", new_callable=AsyncMock)
        decision_maker = DecisionMaker(Mock(), Mock(), team_instructions, MouldState(set()))

        # WHEN decision_maker.handle_add_team_instruction_command is called, assert that an exception is raised
        with pytest.raises(Exception) as exc_info:
            await decision_maker.handle_add_team_instruction_command(team_instruction_request.payload)

        # THEN an exception of type ValueError is raised
        assert exc_info.type is ValueError
        warning_message = "'handle_add_team_instruction_command params' must not be empty or None."
        assert exc_info.value.args[0] == warning_message

        # AND team_instructions._store is not called nor awaited, means execution of handler was aborted
        assert team_instructions._store.call_count == 0
        assert team_instructions._store.await_count == 0

    async def test_should_raise_exception_and_abort_processing_when_none_instruction_recieved(self):
        # GIVEN
        none_team_instruction_data = None
        team_instruction_request = create_add_team_instruction_c2dm_request(none_team_instruction_data)
        decision_maker = DecisionMaker(Mock(), Mock(), TeamInstructions([]), MouldState(set()))

        # WHEN decision_maker.handle_add_team_instruction_command is called, assert that an exception is raised
        with pytest.raises(Exception) as exc_info:
            await decision_maker.handle_add_team_instruction_command(team_instruction_request.payload)

        # THEN an exception of type ValueError is raised
        assert exc_info.type is ValueError
        warning_message = "'handle_add_team_instruction_command params' must not be empty or None."
        assert exc_info.value.args[0] == warning_message


@pytest.mark.asyncio
@patch("app.config.MOULD_ID", "mould_id")
class HandleAddTeamInstructionCommandAndGlobalMouldStateTests:
    async def test_should_raise_exception_and_abort_processing_when_global_state_finalised_and_team_instruction_with_finalised_blade_sn_given(
            self, mocker):
        # GIVEN
        team_instruction_data = {
            "version": "v1.0.0",
            "mouldId": "mould_id",
            "bladeSn": "blade_sn",
            "bladeRevision": "blade_revision",
            "layerId": "layer_id",
            "palletId": "pallet_id"
        }
        team_instruction_request = create_add_team_instruction_c2dm_request(team_instruction_data)
        global_mould_state = GlobalMouldState.FINALISED
        global_blade_sn = team_instruction_data["bladeSn"]

        log = mocker.patch("app.decision_maker.log")
        shared_storage = mocker.patch("app.decision_maker.SharedStorage")
        decision_maker = DecisionMaker(shared_storage, Mock(), TeamInstructions([]), MouldState(set()))

        # AND more methods patched
        handle_team_instruction_update = mocker.patch.object(decision_maker, "_handle_team_instruction_update")
        mocker.patch("app.decision_maker.SharedStorage.get_mould_state", return_value=global_mould_state)
        mocker.patch("app.decision_maker.SharedStorage.get_mould_blade_sn", return_value=global_blade_sn)

        # WHEN decision_maker.handle_add_team_instruction_command is called, assert that an exception is raised
        with pytest.raises(Exception) as exc_info:
            await decision_maker.handle_add_team_instruction_command(team_instruction_request.payload)

        # THEN an exception of type ValueError is raised
        assert exc_info.type is ValueError
        warning_message = "Discarding team instruction, given blade_sn: blade_sn is already finalised."
        assert exc_info.value.args[0] == warning_message

        # AND decision_maker._handle_team_instruction_update is not called, means execution of method was aborted
        assert handle_team_instruction_update.call_count == 0
        assert handle_team_instruction_update.await_count == 0

        # AND
        assert shared_storage.set_mould_state.call_count == 0
        assert shared_storage.set_mould_blade_sn.call_count == 0

        # AND
        assert log.warning.call_count == 1
        call_args = log.warning.call_args.args
        assert call_args[0] == warning_message

    async def test_should_raise_exception_and_abort_processing_when_global_state_production_and_team_instruction_with_not_matching_blade_sn_given(
            self, mocker):
        # GIVEN
        team_instruction_data = {
            "version": "v1.0.0",
            "mouldId": "mould_id",
            "bladeSn": "blade_sn",
            "bladeRevision": "blade_revision",
            "layerId": "layer_id",
            "palletId": "pallet_id"
        }
        team_instruction_request = create_add_team_instruction_c2dm_request(team_instruction_data)
        global_mould_state = GlobalMouldState.PRODUCTION
        global_blade_sn = "finalised_blade_sn"

        log = mocker.patch("app.decision_maker.log")
        shared_storage = mocker.patch("app.decision_maker.SharedStorage")
        decision_maker = DecisionMaker(shared_storage, Mock(), TeamInstructions([]), MouldState(set()))

        # AND more methods patched
        handle_team_instruction_update = mocker.patch.object(decision_maker, "_handle_team_instruction_update")
        mocker.patch("app.decision_maker.SharedStorage.get_mould_state", return_value=global_mould_state)
        mocker.patch("app.decision_maker.SharedStorage.get_mould_blade_sn", return_value=global_blade_sn)

        # WHEN decision_maker.handle_add_team_instruction_command is called, assert that an exception is raised
        with pytest.raises(Exception) as exc_info:
            await decision_maker.handle_add_team_instruction_command(team_instruction_request.payload)

        # THEN an exception of type ValueError is raised
        assert exc_info.type is ValueError
        warning_message = "Discarding team instruction for blade_sn: blade_sn, " \
                          "given mould_id mould_id is already in production for different blade_sn: finalised_blade_sn"
        assert exc_info.value.args[0] == warning_message

        # AND decision_maker._handle_team_instruction_update is not called, means execution of method was aborted
        assert handle_team_instruction_update.call_count == 0
        assert handle_team_instruction_update.await_count == 0

        # AND
        assert shared_storage.set_mould_state.call_count == 0
        assert shared_storage.set_mould_blade_sn.call_count == 0

        # AND
        assert log.warning.call_count == 1
        call_args = log.warning.call_args.args
        assert call_args[0] == warning_message

    async def test_should_not_abort_processing_when_global_state_production_and_team_instruction_with_matching_blade_sn_given(
            self, mocker):
        # GIVEN
        team_instruction_data = {
            "version": "v1.0.0",
            "mouldId": "mould_id",
            "bladeSn": "blade_sn",
            "bladeRevision": "blade_revision",
            "layerId": "layer_id",
            "palletId": "pallet_id"
        }
        team_instruction_request = create_add_team_instruction_c2dm_request(team_instruction_data)
        global_mould_state = GlobalMouldState.PRODUCTION
        global_blade_sn = team_instruction_data["bladeSn"]
        metadata = PayloadMetadata(correlation_id=team_instruction_request.payload.get("correlationId"))

        log = mocker.patch("app.decision_maker.log")
        shared_storage = mocker.patch("app.decision_maker.SharedStorage")
        messaging_wrapper = mocker.patch("app.decision_maker.MessagingWrapper", new_callable=AsyncMock)
        decision_maker = DecisionMaker(shared_storage, messaging_wrapper, TeamInstructions([]), MouldState(set()))

        # AND more methods patched
        handle_team_instruction_update = mocker.patch.object(decision_maker, "_handle_team_instruction_update")
        mocker.patch("app.decision_maker.SharedStorage.get_mould_state", return_value=global_mould_state)
        mocker.patch("app.decision_maker.SharedStorage.get_mould_blade_sn", return_value=global_blade_sn)

        # WHEN decision_maker.handle_add_team_instruction_command is called
        await decision_maker.handle_add_team_instruction_command(team_instruction_request.payload)

        # THEN decision_maker._handle_team_instruction_update is called, means execution of method was not aborted
        assert handle_team_instruction_update.call_count == 1
        assert handle_team_instruction_update.await_count == 1
        call_args = handle_team_instruction_update.call_args.args
        assert call_args[0] == team_instruction_data
        actual_metadata = call_args[1]
        assert actual_metadata.correlation_id == metadata.correlation_id
        assert actual_metadata.session == metadata.session
        assert actual_metadata.camera_id == metadata.camera_id
        assert actual_metadata.content_type == metadata.content_type
        assert actual_metadata.custom_properties == metadata.custom_properties

        # AND
        assert shared_storage.set_mould_state.call_count == 1
        call_args = shared_storage.set_mould_state.call_args.args
        assert call_args[0] == GlobalMouldState.PRODUCTION

        # AND
        assert shared_storage.set_mould_blade_sn.call_count == 1
        call_args = shared_storage.set_mould_blade_sn.call_args.args
        assert call_args[0] == team_instruction_data

        # AND
        assert log.warning.call_count == 0


@pytest.mark.asyncio
@patch("app.config.MOULD_ID", "mould_id")
class DecisionMakerResetToInitialSateWhenExceptionRaisedTests:
    async def test_load_data_from_mapping_files_into_memory_should_reset_decision_maker_to_initial_state_on_exception(
            self, mocker, sample_instructions_data, sample_graph_data):
        # GIVEN
        shared_storage = mocker.patch("app.decision_maker.SharedStorage")
        messaging_wrapper = mocker.patch("app.decision_maker.MessagingWrapper", new_callable=AsyncMock)
        team_instructions = TeamInstructions(sample_instructions_data)
        metadata_to_forward = PayloadMetadata()

        decision_maker = DecisionMaker(shared_storage, messaging_wrapper, team_instructions, MouldState(set()))

        # AND more methods patched
        mocker.patch("app.decision_maker.file_storage")
        mocker.patch("app.decision_maker.file_storage.get_static_graph", return_value=Graph(sample_graph_data))
        mocker.patch("app.decision_maker.EdgeCameras.invisible_edges", return_value=True)

        # AND raised exception when self._static_graph.remove_invisible_edges is called
        ex_message = "exception mock"
        mocker.patch("app.decision_maker.file_storage.get_feedback_positions", side_effect=ValueError(ex_message))

        # WHEN decision_maker.process_team_instructions_changes is called, assert that an exception is raised
        with pytest.raises(Exception) as exc_info:
            await decision_maker.process_team_instructions_changes(metadata_to_forward)

        # THEN an exception of correct type is raised
        assert exc_info.type is ValueError
        error_message = f"Failed to load_data_from_mapping_files for team instructions: " \
                        f"{sample_instructions_data}"
        assert exc_info.value.args[0] == error_message

        # AND class members were reset to None
        assert decision_maker._static_graph is None
        assert decision_maker._sub_graph is None
        assert decision_maker._mould_state.plies == set()
        assert decision_maker._team_instructions.data == []
        assert decision_maker._edge_cameras is None
        assert decision_maker._feedback_positions is None


@pytest.mark.asyncio
@patch("app.decision_maker.cfg.MOULD_ID", "mould_id")
class HandleEdgeVerificationMessageAndStateChangesTests:
    async def test_should_correctly_update_local_and_global_mould_state_when_new_visible_edges_detected(
            self, mocker, sample_edge_to_cameras, sample_instructions_data):
        # GIVEN
        detected_edges = {"P3.1", "P3.2"}
        missing_edges = {"P2.2"}
        verification_data = create_edge_verification_feedback(detected_edges, missing_edges)
        session = {"cameraId": "cam2"}
        metadata_to_forward = PayloadMetadata(session=session)

        shared_storage = mocker.patch("app.decision_maker.SharedStorage")
        messaging_wrapper = mocker.patch("app.decision_maker.MessagingWrapper", new_callable=AsyncMock)
        team_instructions = TeamInstructions(sample_instructions_data)
        state_plies_mock = StatePliesMock()
        state_plies = {state_plies_mock.first_ply_partially_covered, state_plies_mock.second_ply_placed}
        mould_state = MouldState(copy.deepcopy(state_plies))
        decision_maker = DecisionMaker(shared_storage, messaging_wrapper, team_instructions, mould_state)

        # AND more methods patched
        mocker.patch("app.decision_maker.LaserFeedback.invoke")

        # AND
        graph_data = {
            "plies": {
                "P1": static_graph_data["plies"]["P1"],
                "P2": static_graph_data["plies"]["P2"],
                "P3": static_graph_data["plies"]["P3"],
            }
        }
        graph = Graph(graph_data)
        graph._map_and_cache_layer_to_pallets()
        edge_cameras = EdgeCameras(sample_edge_to_cameras)
        decision_maker._sub_graph = graph
        decision_maker._edge_cameras = edge_cameras

        # AND
        recalculate_expected_plies(mould_state, graph, edge_cameras)

        # WHEN decision_maker.handle_edge_verification_message is called
        await decision_maker.handle_edge_verification_message(verification_data, metadata_to_forward)

        # THEN local mould state is correctly updated
        result_plies = decision_maker._mould_state.plies
        expected_plies = [
            state_plies_mock.first_ply_partially_covered,
            state_plies_mock.second_ply_partially_covered,
            state_plies_mock.third_ply_placed
        ]
        assert len(result_plies) == len(expected_plies)
        expected_state_plies = sorted([ply.serialize() for ply in expected_plies], key=lambda i: i["ply_id"])
        actual_state_plies = sorted([ply.serialize() for ply in result_plies], key=lambda i: i["ply_id"])
        assert actual_state_plies == expected_state_plies

        # AND shared_storage.update_mould_plies is called (global mould state is updated)
        assert shared_storage.update_mould_plies.call_count == 1

    async def test_should_not_update_local_and_global_mould_state_when_no_new_visible_edges_detected(
            self, mocker, sample_edge_to_cameras, sample_instructions_data):
        # GIVEN
        detected_edges = {"P2.1", "P2.2"}
        missing_edges = set()
        verification_data = create_edge_verification_feedback(detected_edges, missing_edges)
        session = {"cameraId": "cam1"}
        metadata_to_forward = PayloadMetadata(session=session)

        shared_storage = mocker.patch("app.decision_maker.SharedStorage")
        messaging_wrapper = mocker.patch("app.decision_maker.MessagingWrapper", new_callable=AsyncMock)
        team_instructions = TeamInstructions(sample_instructions_data)
        state_plies_mock = StatePliesMock()
        state_plies = {state_plies_mock.first_ply_partially_covered, state_plies_mock.second_ply_placed}
        mould_state = MouldState(copy.deepcopy(state_plies))
        decision_maker = DecisionMaker(shared_storage, messaging_wrapper, team_instructions, mould_state)

        # AND more methods patched
        mocker.patch("app.decision_maker.LaserFeedback.invoke")

        # AND
        graph_data = {
            "plies": {
                "P1": static_graph_data["plies"]["P1"],
                "P2": static_graph_data["plies"]["P2"],
                "P3": static_graph_data["plies"]["P3"],
            }
        }
        graph = Graph(graph_data)
        edge_cameras = EdgeCameras(sample_edge_to_cameras)
        decision_maker._sub_graph = graph
        decision_maker._edge_cameras = edge_cameras

        # AND
        recalculate_expected_plies(mould_state, graph, edge_cameras)

        # WHEN decision_maker.handle_edge_verification_message is called
        await decision_maker.handle_edge_verification_message(verification_data, metadata_to_forward)

        # THEN local mould state is not updated
        assert decision_maker._mould_state == mould_state

        # AND shared_storage.update_mould_plies is not called (global mould state is not updated)
        assert shared_storage.update_mould_plies.call_count == 0

    async def test_should_not_update_local_and_global_mould_state_when_expected_edges_detected_as_missing(
            self, mocker, sample_edge_to_cameras, sample_instructions_data):
        # GIVEN
        detected_edges = {"P2.2"}
        missing_edges = {"P3.1", "P3.2"}
        verification_data = create_edge_verification_feedback(detected_edges, missing_edges)
        session = {"cameraId": "cam2"}
        metadata_to_forward = PayloadMetadata(session=session)

        shared_storage = mocker.patch("app.decision_maker.SharedStorage")
        team_instructions = TeamInstructions(sample_instructions_data)
        state_plies_mock = StatePliesMock()
        state_plies = {state_plies_mock.first_ply_partially_covered, state_plies_mock.second_ply_placed}
        mould_state = MouldState(copy.deepcopy(state_plies))
        decision_maker = DecisionMaker(shared_storage, Mock(), team_instructions, mould_state)

        # AND more methods patched
        mocker.patch("app.decision_maker.LaserFeedback.invoke")

        # AND
        graph_data = {
            "plies": {
                "P1": static_graph_data["plies"]["P1"],
                "P2": static_graph_data["plies"]["P2"],
                "P3": static_graph_data["plies"]["P3"],
            }
        }
        graph = Graph(graph_data)
        edge_cameras = EdgeCameras(sample_edge_to_cameras)
        decision_maker._sub_graph = graph
        decision_maker._edge_cameras = edge_cameras

        # AND
        recalculate_expected_plies(mould_state, graph, edge_cameras)

        # WHEN decision_maker.handle_edge_verification_message is called
        await decision_maker.handle_edge_verification_message(verification_data, metadata_to_forward)

        # THEN local mould state is not updated
        assert decision_maker._mould_state == mould_state

        # AND shared_storage.update_mould_plies is not called (global mould state is not updated)
        assert shared_storage.update_mould_plies.call_count == 0

    @patch("app.config.FF_EDGE_DETECTION_STRICT", False)
    async def test_should_update_mould_plies_with_detected_ply_when_only_one_cam_detected_edges_while_strict_false(
            self, mocker, sample_edge_to_cameras, sample_instructions_data):
        # GIVEN
        detected_edges = {"P3.2", "P3.1"}
        missing_edges = {"P2.2"}
        verification_data = create_edge_verification_feedback(detected_edges, missing_edges)
        session = {"cameraId": "cam2"}
        metadata_to_forward = PayloadMetadata(session=session)

        shared_storage = mocker.patch("app.decision_maker.SharedStorage")
        messaging_wrapper = mocker.patch("app.decision_maker.MessagingWrapper", new_callable=AsyncMock)
        team_instructions = TeamInstructions(sample_instructions_data)
        state_plies_mock = StatePliesMock()
        state_plies = {state_plies_mock.first_ply_partially_covered, state_plies_mock.second_ply_placed}
        mould_state = MouldState(copy.deepcopy(state_plies))
        decision_maker = DecisionMaker(shared_storage, messaging_wrapper, team_instructions, mould_state)

        # AND more methods patched
        mocker.patch("app.decision_maker.LaserFeedback.invoke")

        # AND
        graph_data = {
            "plies": {
                "P1": static_graph_data["plies"]["P1"],
                "P2": static_graph_data["plies"]["P2"],
                "P3": static_graph_data["plies"]["P3"],
            }
        }
        graph = Graph(graph_data)
        graph._map_and_cache_layer_to_pallets()
        edge_cameras = EdgeCameras(sample_edge_to_cameras)
        decision_maker._sub_graph = graph
        decision_maker._edge_cameras = edge_cameras

        # AND
        recalculate_expected_plies(mould_state, graph, edge_cameras)

        # WHEN decision_maker.handle_edge_verification_message is called
        await decision_maker.handle_edge_verification_message(verification_data, metadata_to_forward)

        # THEN local mould state is updated with new visible edges and covered edges removed
        result_plies = decision_maker._mould_state.plies
        third_ply = PlyState(
            "P3",
            edges={
                EdgeState(
                    "P3.1",
                    cams={
                        EdgeCamState("cam2", EdgeCamStateEnum.DETECTED),
                    },
                    state=EdgeStateEnum.DETECTED
                ),
                EdgeState(
                    "P3.2",
                    cams={
                        EdgeCamState("cam2", EdgeCamStateEnum.DETECTED),
                        EdgeCamState("cam3", EdgeCamStateEnum.NEVER_DETECTED),
                    },
                    state=EdgeStateEnum.DETECTED
                ),
            },
            state=PlyStateEnum.PLACED,
            previous_state=PlyStateEnum.EXPECTED,
            updated_by="cam:cam2",
            source_device=None
        )
        expected_plies = [
            state_plies_mock.first_ply_partially_covered,
            state_plies_mock.second_ply_partially_covered,
            third_ply
        ]
        assert len(result_plies) == len(expected_plies)
        expected_state_plies = sorted([ply.serialize() for ply in expected_plies], key=lambda i: i["ply_id"])
        actual_state_plies = sorted([ply.serialize() for ply in result_plies], key=lambda i: i["ply_id"])
        assert actual_state_plies == expected_state_plies

        # AND shared_storage.update_mould_plies is called (global mould state is updated)
        assert shared_storage.update_mould_plies.call_count == 1

    @patch("app.config.FF_EDGE_DETECTION_STRICT", False)
    async def test_should_not_update_mould_plies_with_detected_ply_when_only_one_of_edges_detected_while_strict_false(
            self, mocker, sample_edge_to_cameras, sample_instructions_data):
        # GIVEN
        detected_edges = {"P3.2"}
        missing_edges = {"P2.2", "P3.1"}
        verification_data = create_edge_verification_feedback(detected_edges, missing_edges)
        session = {"cameraId": "cam2"}
        metadata_to_forward = PayloadMetadata(session=session)

        shared_storage = mocker.patch("app.decision_maker.SharedStorage")
        messaging_wrapper = mocker.patch("app.decision_maker.MessagingWrapper", new_callable=AsyncMock)
        team_instructions = TeamInstructions(sample_instructions_data)
        state_plies_mock = StatePliesMock()
        state_plies = {state_plies_mock.first_ply_partially_covered, state_plies_mock.second_ply_placed}
        mould_state = MouldState(copy.deepcopy(state_plies))
        decision_maker = DecisionMaker(shared_storage, messaging_wrapper, team_instructions, mould_state)

        # AND more methods patched
        mocker.patch("app.decision_maker.LaserFeedback.invoke")

        # AND
        graph_data = {
            "plies": {
                "P1": static_graph_data["plies"]["P1"],
                "P2": static_graph_data["plies"]["P2"],
                "P3": static_graph_data["plies"]["P3"],
            }
        }
        graph = Graph(graph_data)
        graph._map_and_cache_layer_to_pallets()
        edge_cameras = EdgeCameras(sample_edge_to_cameras)
        decision_maker._sub_graph = graph
        decision_maker._edge_cameras = edge_cameras

        # AND
        recalculate_expected_plies(mould_state, graph, edge_cameras)

        # WHEN decision_maker.handle_edge_verification_message is called
        await decision_maker.handle_edge_verification_message(verification_data, metadata_to_forward)

        # THEN local mould state is updated with new visible edges and covered edges removed
        result_plies = decision_maker._mould_state.plies
        third_ply = PlyState(
            "P3",
            edges={
                EdgeState(
                    "P3.1",
                    cams={
                        EdgeCamState("cam2", EdgeCamStateEnum.NEVER_DETECTED),
                    },
                    state=EdgeStateEnum.MISSING
                ),
                EdgeState(
                    "P3.2",
                    cams={
                        EdgeCamState("cam2", EdgeCamStateEnum.DETECTED),
                        EdgeCamState("cam3", EdgeCamStateEnum.NEVER_DETECTED),
                    },
                    state=EdgeStateEnum.DETECTED
                ),
            },
            state=PlyStateEnum.EXPECTED,
            previous_state=None,
            updated_by="cam:cam2",
            source_device=None
        )
        expected_plies = [
            state_plies_mock.first_ply_partially_covered,
            state_plies_mock.second_ply_placed,
            third_ply
        ]
        assert len(result_plies) == len(expected_plies)
        expected_state_plies = sorted([ply.serialize() for ply in expected_plies], key=lambda i: i["ply_id"])
        actual_state_plies = sorted([ply.serialize() for ply in result_plies], key=lambda i: i["ply_id"])
        assert actual_state_plies == expected_state_plies

        # AND shared_storage.update_mould_plies is called (global mould state is updated)
        assert shared_storage.update_mould_plies.call_count == 1

    @patch("app.config.FF_EDGE_DETECTION_STRICT", True)
    async def test_should_not_update_mould_plies_with_detected_ply_when_only_one_cam_detected_edges_while_strict_true(
            self, mocker, sample_edge_to_cameras, sample_instructions_data):
        # GIVEN
        detected_edges = {"P3.2", "P3.1"}
        missing_edges = {"P2.2"}
        verification_data = create_edge_verification_feedback(detected_edges, missing_edges)
        session = {"cameraId": "cam2"}
        metadata_to_forward = PayloadMetadata(session=session)

        shared_storage = mocker.patch("app.decision_maker.SharedStorage")
        messaging_wrapper = mocker.patch("app.decision_maker.MessagingWrapper", new_callable=AsyncMock)
        team_instructions = TeamInstructions(sample_instructions_data)
        state_plies_mock = StatePliesMock()
        state_plies = {state_plies_mock.first_ply_partially_covered, state_plies_mock.second_ply_placed}
        mould_state = MouldState(copy.deepcopy(state_plies))
        decision_maker = DecisionMaker(shared_storage, messaging_wrapper, team_instructions, mould_state)

        # AND more methods patched
        mocker.patch("app.decision_maker.LaserFeedback.invoke")

        # AND
        graph_data = {
            "plies": {
                "P1": static_graph_data["plies"]["P1"],
                "P2": static_graph_data["plies"]["P2"],
                "P3": static_graph_data["plies"]["P3"],
            }
        }
        graph = Graph(graph_data)
        graph._map_and_cache_layer_to_pallets()
        edge_cameras = EdgeCameras(sample_edge_to_cameras)
        decision_maker._sub_graph = graph
        decision_maker._edge_cameras = edge_cameras

        # AND
        recalculate_expected_plies(mould_state, graph, edge_cameras)

        # WHEN decision_maker.handle_edge_verification_message is called
        await decision_maker.handle_edge_verification_message(verification_data, metadata_to_forward)

        # THEN local mould state is updated with new visible edges and covered edges removed
        result_plies = decision_maker._mould_state.plies
        third_ply = PlyState(
            "P3",
            edges={
                EdgeState(
                    "P3.1",
                    cams={
                        EdgeCamState("cam2", EdgeCamStateEnum.DETECTED),
                    },
                    state=EdgeStateEnum.DETECTED
                ),
                EdgeState(
                    "P3.2",
                    cams={
                        EdgeCamState("cam2", EdgeCamStateEnum.DETECTED),
                        EdgeCamState("cam3", EdgeCamStateEnum.NEVER_DETECTED),
                    },
                    state=EdgeStateEnum.MISSING
                ),
            },
            state=PlyStateEnum.EXPECTED,
            previous_state=None,
            updated_by="cam:cam2",
            source_device=None
        )
        expected_plies = [
            state_plies_mock.first_ply_partially_covered,
            state_plies_mock.second_ply_placed,
            third_ply
        ]
        assert len(result_plies) == len(expected_plies)
        expected_state_plies = sorted([ply.serialize() for ply in expected_plies], key=lambda i: i["ply_id"])
        actual_state_plies = sorted([ply.serialize() for ply in result_plies], key=lambda i: i["ply_id"])
        assert actual_state_plies == expected_state_plies

        # AND shared_storage.update_mould_plies is called (global mould state is updated)
        assert shared_storage.update_mould_plies.call_count == 1

    async def test_should_invoke_edge_verification_when_mould_state_changes_on_newly_detected_edges(
            self, mocker, sample_edge_to_cameras, sample_instructions_data):
        # GIVEN
        detected_edges = {"P3.1", "P3.2"}
        missing_edges = {"P2.2"}
        verification_data = create_edge_verification_feedback(detected_edges, missing_edges)
        session = {"cameraId": "cam2"}
        metadata_to_forward = PayloadMetadata(session=session)

        shared_storage = mocker.patch("app.decision_maker.SharedStorage")
        messaging_wrapper = mocker.patch("app.decision_maker.MessagingWrapper", new_callable=AsyncMock)
        team_instructions = TeamInstructions(sample_instructions_data)
        state_plies_mock = StatePliesMock()
        initial_state_plies = {state_plies_mock.first_ply_partially_covered, state_plies_mock.second_ply_placed}
        mould_state = MouldState(copy.deepcopy(initial_state_plies))
        decision_maker = DecisionMaker(shared_storage, messaging_wrapper, team_instructions, mould_state)

        # AND more methods patched
        mocker.patch("app.decision_maker.LaserFeedback.invoke")

        # AND
        graph_data = {
            "plies": {
                "P1": static_graph_data["plies"]["P1"],
                "P2": static_graph_data["plies"]["P2"],
                "P3": static_graph_data["plies"]["P3"],
            }
        }
        graph = Graph(graph_data)
        graph._map_and_cache_layer_to_pallets()
        edge_cameras = EdgeCameras(sample_edge_to_cameras)
        decision_maker._sub_graph = graph
        decision_maker._edge_cameras = edge_cameras

        # AND
        recalculate_expected_plies(mould_state, graph, edge_cameras)

        # WHEN decision_maker.handle_edge_verification_message is called
        await decision_maker.handle_edge_verification_message(verification_data, metadata_to_forward)

        # THEN messaging.send_message_to_edge_verification is called and awaited once with correct arguments
        assert messaging_wrapper.send_message_to_edge_verification.call_count == 1
        assert messaging_wrapper.send_message_to_edge_verification.await_count == 1
        actual_payload = messaging_wrapper.send_message_to_edge_verification.call_args.args[0]
        expected_payload = {
            "metadata": {
                "groundTruthVersion": team_instructions.ground_truth_version,
                "mouldId": team_instructions.mould_id,
                "bladeSn": team_instructions.blade_sn,
                "bladeRevision": team_instructions.blade_revision,
                "layers": sorted(list(team_instructions.layer_ids)),
                "session": metadata_to_forward.session
            },
            "data": {
                "cam1": {"detectedEdges": ["P1.1", "P2.1"]},
                "cam2": {"detectedEdges": ["P3.1", "P3.2"]},
                "cam3": {"detectedEdges": ["P3.2"]}
            }
        }
        assert all(
            set(actual_payload["data"][cam_id]) == set(expected_payload["data"][cam_id])
            for cam_id in actual_payload["data"]
        )
        assert actual_payload["metadata"] == expected_payload["metadata"]

        # AND local mould state is updated
        assert len(decision_maker._mould_state.plies) != len(initial_state_plies)
        assert {ply.id for ply in decision_maker._mould_state.plies} != {ply.id for ply in initial_state_plies}

    async def test_should_not_invoke_edge_verification_when_mould_state_do_not_change_on_previously_detected_edges(
            self, mocker, sample_edge_to_cameras, sample_instructions_data):
        # GIVEN
        detected_edges = {"P1.1", "P2.2"}
        missing_edges = set()
        verification_data = create_edge_verification_feedback(detected_edges, missing_edges)
        session = {"cameraId": "cam1"}
        metadata_to_forward = PayloadMetadata(session=session)

        shared_storage = mocker.patch("app.decision_maker.SharedStorage")
        messaging_wrapper = mocker.patch("app.decision_maker.MessagingWrapper", new_callable=AsyncMock)
        team_instructions = TeamInstructions(sample_instructions_data)
        state_plies_mock = StatePliesMock()
        initial_state_plies = {
            state_plies_mock.first_ply_partially_covered,
            state_plies_mock.second_ply_placed,
            state_plies_mock.third_ply_expected
        }
        mould_state = MouldState(copy.deepcopy(initial_state_plies))
        decision_maker = DecisionMaker(shared_storage, messaging_wrapper, team_instructions, mould_state)

        # AND more methods patched
        mocker.patch("app.decision_maker.LaserFeedback.invoke")

        # AND
        graph_data = {
            "plies": {
                "P1": static_graph_data["plies"]["P1"],
                "P2": static_graph_data["plies"]["P2"],
                "P3": static_graph_data["plies"]["P3"],
            }
        }
        graph = Graph(graph_data)
        graph._map_and_cache_layer_to_pallets()
        edge_cameras = EdgeCameras(sample_edge_to_cameras)
        decision_maker._sub_graph = graph
        decision_maker._edge_cameras = edge_cameras

        # AND
        recalculate_expected_plies(mould_state, graph, edge_cameras)

        # WHEN decision_maker.handle_edge_verification_message is called
        await decision_maker.handle_edge_verification_message(verification_data, metadata_to_forward)

        # THEN messaging.send_message_to_edge_verification is not called
        assert messaging_wrapper.send_message_to_edge_verification.call_count == 0
        assert messaging_wrapper.send_message_to_edge_verification.await_count == 0

        # AND local mould state is not updated
        assert len(decision_maker._mould_state.plies) == len(initial_state_plies)
        assert {ply.id for ply in decision_maker._mould_state.plies} == {ply.id for ply in initial_state_plies}

    async def test_should_not_change_mould_state_nor_plies_to_be_placed_when_same_ev_message_received_in_a_row(
            self, mocker, sample_edge_to_cameras, sample_instructions_data):
        # GIVEN
        detected_edges = {"P2.1", "P2.2"}
        missing_edges = set()
        verification_data = create_edge_verification_feedback(detected_edges, missing_edges)
        session = {"cameraId": "cam1"}
        metadata_to_forward = PayloadMetadata(session=session)

        shared_storage = mocker.patch("app.decision_maker.SharedStorage")
        messaging_wrapper = mocker.patch("app.decision_maker.MessagingWrapper", new_callable=AsyncMock)
        team_instructions = TeamInstructions(sample_instructions_data)
        state_plies_mock = StatePliesMock()
        state_plies = {state_plies_mock.first_ply_placed}
        mould_state = MouldState(copy.deepcopy(state_plies))
        decision_maker = DecisionMaker(shared_storage, messaging_wrapper, team_instructions, mould_state)

        # AND more methods patched
        mocker.patch("app.decision_maker.LaserFeedback.invoke")

        # AND
        graph_data = {
            "plies": {
                "P1": static_graph_data["plies"]["P1"],
                "P2": static_graph_data["plies"]["P2"],
                "P3": static_graph_data["plies"]["P3"],
            }
        }
        graph = Graph(graph_data)
        graph._map_and_cache_layer_to_pallets()
        edge_cameras = EdgeCameras(sample_edge_to_cameras)
        decision_maker._sub_graph = graph
        decision_maker._edge_cameras = edge_cameras

        # AND
        plies_to_be_placed = recalculate_expected_plies(mould_state, graph, edge_cameras)
        plies_to_be_placed_initially = copy.deepcopy(plies_to_be_placed)

        # WHEN decision_maker.handle_edge_verification_message is called
        await decision_maker.handle_edge_verification_message(verification_data, metadata_to_forward)

        plies_to_be_placed = recalculate_expected_plies(mould_state, graph, edge_cameras)
        plies_to_be_placed_on_first_message = copy.deepcopy(plies_to_be_placed)

        # THEN local mould state is correctly updated (on first time)
        result_plies = decision_maker._mould_state.plies
        expected_plies = [
            state_plies_mock.first_ply_partially_covered,
            state_plies_mock.second_ply_placed,
            state_plies_mock.third_ply_expected,
        ]
        assert len(result_plies) == len(expected_plies)
        expected_state_plies = sorted([ply.serialize() for ply in expected_plies], key=lambda i: i["ply_id"])
        actual_state_plies = sorted([ply.serialize() for ply in result_plies], key=lambda i: i["ply_id"])
        assert actual_state_plies == expected_state_plies
        copy_of_result_plies_on_first_message = copy.deepcopy(result_plies)

        # AND shared_storage.update_mould_plies is called (global state is updated on first time)
        assert shared_storage.update_mould_plies.call_count == 1

        # WHEN decision_maker.handle_edge_verification_message is called
        await decision_maker.handle_edge_verification_message(verification_data, metadata_to_forward)

        plies_to_be_placed = recalculate_expected_plies(mould_state, graph, edge_cameras)
        plies_to_be_placed_on_second_message = copy.deepcopy(plies_to_be_placed)

        # THEN local mould state is not updated on same message second time in a row
        assert len(decision_maker._mould_state.plies) == len(copy_of_result_plies_on_first_message)
        assert {ply.id for ply in decision_maker._mould_state.plies} == \
               {ply.id for ply in copy_of_result_plies_on_first_message}

        # AND global mould state is not updated on repetitive verification data message (no new calls)
        assert shared_storage.update_mould_plies.call_count == 1

        # WHEN decision_maker.handle_edge_verification_message is called with same message third time in a row
        await decision_maker.handle_edge_verification_message(verification_data, metadata_to_forward)

        plies_to_be_placed = recalculate_expected_plies(mould_state, graph, edge_cameras)
        plies_to_be_placed_on_third_message = copy.deepcopy(plies_to_be_placed)

        # THEN local mould state is not updated on same message third time in a row
        assert len(decision_maker._mould_state.plies) == len(copy_of_result_plies_on_first_message)
        assert {ply.id for ply in decision_maker._mould_state.plies} == \
               {ply.id for ply in copy_of_result_plies_on_first_message}

        # AND global mould state is not updated on repetitive verification data message (no new calls)
        assert shared_storage.update_mould_plies.call_count == 1

        # AND plies_to_be_placed changed on first time, but not on repetitive verification data in a row
        assert plies_to_be_placed_initially != plies_to_be_placed_on_first_message
        assert plies_to_be_placed_on_second_message == plies_to_be_placed_on_first_message
        assert plies_to_be_placed_on_third_message == plies_to_be_placed_on_first_message

    async def test_should_change_mould_state_and_plies_to_be_placed_when_unique_ev_message_received_after_two_the_same(
            self, mocker, sample_edge_to_cameras, sample_instructions_data):
        # GIVEN
        verification_data = create_edge_verification_feedback({"P1.1", "P1.2"})
        session = {"cameraId": "cam1"}
        metadata_to_forward = PayloadMetadata(session=session)
        verification_data_other = create_edge_verification_feedback({"P2.1", "P2.2"}, set())
        metadata_to_forward_other = PayloadMetadata(session=session)

        shared_storage = mocker.patch("app.decision_maker.SharedStorage")
        messaging_wrapper = mocker.patch("app.decision_maker.MessagingWrapper", new_callable=AsyncMock)
        team_instructions = TeamInstructions(sample_instructions_data)
        state_plies_mock = StatePliesMock()
        state_plies = set()
        mould_state = MouldState(copy.deepcopy(state_plies))
        decision_maker = DecisionMaker(shared_storage, messaging_wrapper, team_instructions, mould_state)

        # AND more methods patched
        mocker.patch("app.decision_maker.LaserFeedback.invoke")

        # AND
        graph_data = {
            "plies": {
                "P1": static_graph_data["plies"]["P1"],
                "P2": static_graph_data["plies"]["P2"],
                "P3": static_graph_data["plies"]["P3"],
            }
        }
        graph = Graph(graph_data)
        graph._map_and_cache_layer_to_pallets()
        edge_cameras = EdgeCameras(sample_edge_to_cameras)
        decision_maker._sub_graph = graph
        decision_maker._edge_cameras = edge_cameras

        # AND
        plies_to_be_placed = recalculate_expected_plies(mould_state, graph, edge_cameras)
        plies_to_be_placed_initially = copy.deepcopy(plies_to_be_placed)

        # WHEN decision_maker.handle_edge_verification_message is called
        await decision_maker.handle_edge_verification_message(verification_data, metadata_to_forward)

        plies_to_be_placed = recalculate_expected_plies(mould_state, graph, edge_cameras)
        plies_to_be_placed_on_first_message = copy.deepcopy(plies_to_be_placed)

        # THEN local mould state is correctly updated (on first time)
        result_plies = decision_maker._mould_state.plies
        expected_plies = [
            state_plies_mock.first_ply_placed,
            state_plies_mock.second_ply_expected,
        ]
        assert len(result_plies) == len(expected_plies)
        expected_state_plies = sorted([ply.serialize() for ply in expected_plies], key=lambda i: i["ply_id"])
        actual_state_plies = sorted([ply.serialize() for ply in result_plies], key=lambda i: i["ply_id"])
        assert actual_state_plies == expected_state_plies
        copy_of_result_plies_on_first_message = copy.deepcopy(result_plies)

        # AND shared_storage.update_mould_plies is called (global state is updated on first time)
        assert shared_storage.update_mould_plies.call_count == 1

        # WHEN decision_maker.handle_edge_verification_message is called
        await decision_maker.handle_edge_verification_message(verification_data, metadata_to_forward)

        plies_to_be_placed = recalculate_expected_plies(mould_state, graph, edge_cameras)
        plies_to_be_placed_on_second_message = copy.deepcopy(plies_to_be_placed)

        # THEN local mould state is not updated on same message second time in a row
        assert len(decision_maker._mould_state.plies) == len(copy_of_result_plies_on_first_message)
        assert {ply.id for ply in decision_maker._mould_state.plies} == \
               {ply.id for ply in copy_of_result_plies_on_first_message}

        # AND global mould state is not updated on repetitive verification data message (no new calls)
        assert shared_storage.update_mould_plies.call_count == 1

        # WHEN decision_maker.handle_edge_verification_message is called again but with other unique message data
        await decision_maker.handle_edge_verification_message(verification_data_other, metadata_to_forward_other)

        plies_to_be_placed = recalculate_expected_plies(mould_state, graph, edge_cameras)
        plies_to_be_placed_on_third_message = copy.deepcopy(plies_to_be_placed)

        # THEN local mould state is updated with new visible edges and covered edges removed (on unique message)
        result_plies = decision_maker._mould_state.plies
        expected_plies = [
            state_plies_mock.first_ply_partially_covered,
            state_plies_mock.second_ply_placed,
            state_plies_mock.third_ply_expected,
        ]
        assert len(result_plies) == len(expected_plies)
        expected_state_plies = sorted([ply.serialize() for ply in expected_plies], key=lambda i: i["ply_id"])
        actual_state_plies = sorted([ply.serialize() for ply in result_plies], key=lambda i: i["ply_id"])
        assert actual_state_plies == expected_state_plies

        # AND shared_storage.update_mould_plies is called (global state is updated again, on unique message)
        assert shared_storage.update_mould_plies.call_count == 2

        # AND plies_to_be_placed changed on first and third time, but not on repetitive message in a row
        assert plies_to_be_placed_initially != plies_to_be_placed_on_first_message
        assert plies_to_be_placed_on_second_message == plies_to_be_placed_on_first_message
        assert plies_to_be_placed_on_third_message != plies_to_be_placed_on_first_message


@pytest.mark.asyncio
@patch("app.decision_maker.cfg.MOULD_ID", "mould_id")
class HandleEdgeVerificationMessageAndEdgeVerificationInvocationTests:
    async def test_should_invoke_edge_verification_only_once_when_multiple_repetitive_ev_message_received_in_a_row(
            self, mocker, sample_graph_data, sample_edge_to_cameras, sample_instructions_data):
        # GIVEN
        detected_edges = {"P2.1", "P2.2"}
        missing_edges = set()
        verification_data = create_edge_verification_feedback(detected_edges, missing_edges)
        session = {"cameraId": "cam1"}
        metadata_to_forward = PayloadMetadata(session=session)

        shared_storage = mocker.patch("app.decision_maker.SharedStorage")
        messaging_wrapper = mocker.patch("app.decision_maker.MessagingWrapper", new_callable=AsyncMock)
        team_instructions = TeamInstructions(sample_instructions_data)
        state_plies = {StatePliesMock().first_ply_placed}
        mould_state = MouldState(copy.deepcopy(state_plies))
        decision_maker = DecisionMaker(shared_storage, messaging_wrapper, team_instructions, mould_state)

        # AND more methods patched
        mocker.patch("app.decision_maker.LaserFeedback.invoke")

        # AND
        graph = Graph(sample_graph_data)
        graph._map_and_cache_layer_to_pallets()
        edge_cameras = EdgeCameras(sample_edge_to_cameras)
        decision_maker._sub_graph = graph
        decision_maker._edge_cameras = edge_cameras

        # AND
        recalculate_expected_plies(mould_state, graph, edge_cameras)

        # WHEN decision_maker.handle_edge_verification_message is called
        await decision_maker.handle_edge_verification_message(verification_data, metadata_to_forward)

        # THEN messaging.send_message_to_edge_verification is called and awaited (on first time)
        assert messaging_wrapper.send_message_to_edge_verification.call_count == 1
        assert messaging_wrapper.send_message_to_edge_verification.await_count == 1

        # AND correct payload is sent (on first time)
        expected_payload = {
            "metadata": {
                "groundTruthVersion": team_instructions.ground_truth_version,
                "mouldId": team_instructions.mould_id,
                "bladeSn": team_instructions.blade_sn,
                "bladeRevision": team_instructions.blade_revision,
                "layers": sorted(list(team_instructions.layer_ids)),
                "session": metadata_to_forward.session
            },
            "data": {
                "cam1": {"detectedEdges": ["P1.1", "P2.1", "P2.2"], "missingEdges": ["T1.1", "T1.2"]},
                "cam2": {"detectedEdges": ["P2.2"], "missingEdges": ["P3.1", "P3.2"]},
                "cam3": {"missingEdges": ["P3.2"]},
                "cam4": {"missingEdges": ["Z1.1", "Z1.2"]},
                "cam5": {"missingEdges": ["E1.2"]},
                "cam6": {"missingEdges": ["L1.1", "L1.2"]},
            }
        }
        actual_payload = messaging_wrapper.send_message_to_edge_verification.call_args.args[0]
        assert all(
            set(actual_payload["data"][cam_id]) == set(expected_payload["data"][cam_id])
            for cam_id in actual_payload["data"]
        )
        assert actual_payload["metadata"] == expected_payload["metadata"]

        # WHEN decision_maker.handle_edge_verification_message is called with same message second time in a row
        await decision_maker.handle_edge_verification_message(verification_data, metadata_to_forward)

        # THEN messaging.send_message_to_edge_verification is not called on repetitive data (no new calls)
        assert messaging_wrapper.send_message_to_edge_verification.call_count == 1

        # WHEN decision_maker.handle_edge_verification_message is called with same message third time in a row
        await decision_maker.handle_edge_verification_message(verification_data, metadata_to_forward)

        # THEN messaging.send_message_to_edge_verification is not called on repetitive data (no new calls)
        assert messaging_wrapper.send_message_to_edge_verification.call_count == 1

    async def test_should_invoke_edge_verification_twice_when_unique_ev_message_received_after_two_repetitive(
            self, mocker, sample_graph_data, sample_edge_to_cameras, sample_instructions_data):
        # GIVEN
        verification_data = create_edge_verification_feedback({"P1.1", "P1.2"})
        session = {"cameraId": "cam1"}
        metadata_to_forward = PayloadMetadata(session=session)
        verification_data_other = create_edge_verification_feedback({"P2.1", "P2.2"}, {"P1.2"})
        metadata_to_forward_other = PayloadMetadata(session=session)

        shared_storage = mocker.patch("app.decision_maker.SharedStorage")
        messaging_wrapper = mocker.patch("app.decision_maker.MessagingWrapper", new_callable=AsyncMock)
        team_instructions = TeamInstructions(sample_instructions_data)
        mould_state = MouldState(set())
        decision_maker = DecisionMaker(shared_storage, messaging_wrapper, team_instructions, mould_state)

        # AND more methods patched
        mocker.patch("app.decision_maker.LaserFeedback.invoke")

        # AND
        graph = Graph(sample_graph_data)
        graph._map_and_cache_layer_to_pallets()
        edge_cameras = EdgeCameras(sample_edge_to_cameras)
        decision_maker._sub_graph = graph
        decision_maker._edge_cameras = edge_cameras

        # AND
        recalculate_expected_plies(mould_state, graph, edge_cameras)

        # WHEN decision_maker.handle_edge_verification_message is called
        await decision_maker.handle_edge_verification_message(verification_data, metadata_to_forward)

        # THEN messaging.send_message_to_edge_verification is called and awaited
        assert messaging_wrapper.send_message_to_edge_verification.call_count == 1
        assert messaging_wrapper.send_message_to_edge_verification.await_count == 1

        # AND correct payload is sent (on first time)
        expected_payload = {
            "metadata": {
                "groundTruthVersion": team_instructions.ground_truth_version,
                "mouldId": team_instructions.mould_id,
                "bladeSn": team_instructions.blade_sn,
                "bladeRevision": team_instructions.blade_revision,
                "layers": sorted(list(team_instructions.layer_ids)),
                "session": metadata_to_forward.session
            },
            "data": {
                "cam1": {"detectedEdges": ["P1.1", "P1.2"], "missingEdges": ["P2.1", "P2.2"]},
                "cam2": {"missingEdges": ["P2.2"]},
                "cam4": {"missingEdges": ["Z1.1", "Z1.2"]},
                "cam5": {"missingEdges": ["E1.2"]},
                "cam6": {"missingEdges": ["L1.1", "L1.2"]},
            }
        }
        actual_payload = messaging_wrapper.send_message_to_edge_verification.call_args.args[0]
        assert all(
            set(actual_payload["data"][cam_id]) == set(expected_payload["data"][cam_id])
            for cam_id in actual_payload["data"]
        )
        assert actual_payload["metadata"] == expected_payload["metadata"]

        # WHEN decision_maker.handle_edge_verification_message is called with same message second time in a row
        await decision_maker.handle_edge_verification_message(verification_data, metadata_to_forward)

        # THEN messaging.send_message_to_edge_verification is not called on repetitive data (no new calls)
        assert messaging_wrapper.send_message_to_edge_verification.call_count == 1
        assert messaging_wrapper.send_message_to_edge_verification.await_count == 1

        # WHEN decision_maker.handle_edge_verification_message is called again but with other unique message data
        await decision_maker.handle_edge_verification_message(verification_data_other, metadata_to_forward_other)

        # THEN messaging.send_message_to_edge_verification is called and awaited (new call for not repetitive data)
        assert messaging_wrapper.send_message_to_edge_verification.call_count == 2
        assert messaging_wrapper.send_message_to_edge_verification.await_count == 2

        # AND correct payload is sent on unique message data
        expected_payload = {
            "metadata": {
                "groundTruthVersion": team_instructions.ground_truth_version,
                "mouldId": team_instructions.mould_id,
                "bladeSn": team_instructions.blade_sn,
                "bladeRevision": team_instructions.blade_revision,
                "layers": sorted(list(team_instructions.layer_ids)),
                "session": metadata_to_forward_other.session
            },
            "data": {
                "cam1": {"detectedEdges": ["P1.1"], "missingEdges": ["P1.2", "T1.1", "T1.2"]},
                "cam2": {"detectedEdges": ["P2.1", "P2.2"], "missingEdges": ["P3.1", "P3.2"]},
                "cam3": {"missingEdges": ["3.2"]},
                "cam4": {"missingEdges": ["Z1.1", "Z1.2"]},
                "cam5": {"missingEdges": ["E1.2"]},
                "cam6": {"missingEdges": ["L1.1", "L1.2"]},
            }
        }
        actual_payload = messaging_wrapper.send_message_to_edge_verification.call_args.args[0]
        assert all(
            set(actual_payload["data"][cam_id]) == set(expected_payload["data"][cam_id])
            for cam_id in actual_payload["data"]
        )
        assert actual_payload["metadata"] == expected_payload["metadata"]


@pytest.mark.asyncio
class HandleEdgeVerificationMessageTests:
    async def test_should_raise_exception_and_abort_verification_message_handling_when_state_is_not_yet_initialised(
            self, mocker):
        # GIVEN
        detected_edges = {"P2.1", "P2.2"}
        missing_edges = {"P1.1"}
        verification_data = create_edge_verification_feedback(detected_edges, missing_edges)
        session = {"cameraId": "cam1"}
        metadata_to_forward = PayloadMetadata(session=session)

        shared_storage = mocker.patch("app.decision_maker.SharedStorage")
        messaging_wrapper = mocker.patch("app.decision_maker.MessagingWrapper", new_callable=AsyncMock)
        decision_maker = DecisionMaker(shared_storage, messaging_wrapper, TeamInstructions([]), MouldState(set()))

        # AND more methods patched
        log = mocker.patch("app.decision_maker.log")
        ev_message_validation = mocker.patch("app.decision_maker.edge_verification_message_validation")

        # WHEN decision_maker.handle_edge_verification_message is called, assert that an exception is raised
        with pytest.raises(Exception) as exc_info:
            await decision_maker.handle_edge_verification_message(verification_data, metadata_to_forward)

        # THEN an exception of type ValueError is raised
        assert exc_info.type is ValueError
        warning_message = "Can't process handle_edge_verification_message " \
                          "while DM is not yet loaded with Team Instructions."
        assert exc_info.value.args[0] == warning_message

        # AND log.warning is called with correct argument
        assert log.warning.call_count == 1
        log_calls = log.warning.call_args_list
        assert log_calls[0] == call(warning_message)

        # AND edge_verification_message_validation is not called, means execution of the handling process is aborted
        assert ev_message_validation.validate.call_count == 0

        # AND decision_maker._mould_state.plies is empty
        assert decision_maker._mould_state.plies == set()

    @patch("app.decision_maker.cfg.MOULD_ID", "mould_id")
    async def test_should_not_raise_exception_nor_abort_edge_verification_message_handling_when_state_is_initialised(
            self, mocker, sample_instructions_data, sample_mould_state_plies, sample_graph_data,
            sample_edge_to_cameras):
        # GIVEN
        graph = Graph(sample_graph_data)
        graph._map_and_cache_layer_to_pallets()
        edge_cameras = EdgeCameras(sample_edge_to_cameras)
        detected_edges = {"P2.1", "P2.2"}
        missing_edges = {"P1.1"}
        verification_data = create_edge_verification_feedback(detected_edges, missing_edges)
        session = {"cameraId": "cam1"}
        metadata_to_forward = PayloadMetadata(session=session)

        shared_storage = mocker.patch("app.decision_maker.SharedStorage")
        messaging_wrapper = mocker.patch("app.decision_maker.MessagingWrapper", new_callable=AsyncMock)
        team_instructions = TeamInstructions(sample_instructions_data)
        mould_state = MouldState(sample_mould_state_plies)
        decision_maker = DecisionMaker(shared_storage, messaging_wrapper, team_instructions, mould_state)

        # AND
        decision_maker._sub_graph = graph
        decision_maker._edge_cameras = edge_cameras

        # AND more methods patched
        mocker.patch("app.decision_maker.LaserFeedback.invoke")
        ev_message_validation = mocker.patch("app.decision_maker.edge_verification_message_validation")

        # WHEN decision_maker.handle_edge_verification_message is called
        await decision_maker.handle_edge_verification_message(verification_data, metadata_to_forward)

        # THEN edge_verification_message_validation is called, means execution of the handling process is not aborted
        assert ev_message_validation.validate.call_count == 1


@pytest.mark.asyncio
@patch("app.config.MOULD_ID", "mould_id")
class HandleEdgeVerificationMessageValidationIntegrationTests:
    async def test_should_not_abort_edge_verification_data_handling_when_given_missing_and_detected_edges_valid(
            self, mocker, sample_graph_data, sample_edge_to_cameras,
            sample_instructions_data):
        # GIVEN
        detected_edges = {"P2.1", "P2.2"}
        missing_edges = {"P1.1"}
        verification_data = create_edge_verification_feedback(detected_edges, missing_edges)
        session = {"cameraId": "cam1"}
        metadata_to_forward = PayloadMetadata(session=session)

        mould_state = MouldState({StatePliesMock().first_ply_placed})
        graph = Graph(sample_graph_data)
        graph._map_and_cache_layer_to_pallets()
        edge_cameras = EdgeCameras(sample_edge_to_cameras)
        messaging_wrapper = mocker.patch("app.decision_maker.MessagingWrapper", new_callable=AsyncMock)
        team_instructions = TeamInstructions(sample_instructions_data)
        decision_maker = DecisionMaker(Mock(), messaging_wrapper, team_instructions, mould_state)

        # AND
        decision_maker._sub_graph = graph
        decision_maker._edge_cameras = edge_cameras

        # AND
        recalculate_expected_plies(mould_state, graph, edge_cameras)

        # AND more methods patched
        mocker.patch.object(decision_maker, "_static_graph")
        feedback_invoke = mocker.patch("app.decision_maker.LaserFeedback.invoke")
        log = mocker.patch("app.dm_helper.edge_verification_message_validation.log")

        # WHEN decision_maker.handle_edge_verification_message is called
        await decision_maker.handle_edge_verification_message(verification_data, metadata_to_forward)

        # AND Feedback().invoke is called, means execution of handler was not aborted
        assert feedback_invoke.call_count == 1

        # AND log.warning is not called
        assert log.warning.call_count == 0

    async def test_should_abort_edge_verification_data_handling_when_given_missing_and_detected_edges_not_valid(
            self, mocker, sample_graph_data, sample_edge_to_cameras):
        # GIVEN
        mould_state = MouldState({StatePliesMock().first_ply_placed})
        graph = Graph(sample_graph_data)
        graph._map_and_cache_layer_to_pallets()
        edge_cameras = EdgeCameras(sample_edge_to_cameras)
        detected_edges = {"NOT_VALID_EDGE_0", "NOT_VALID_EDGE_1"}
        missing_edges = {"NOT_VALID_EDGE_2"}
        verification_data = create_edge_verification_feedback(detected_edges, missing_edges)
        session = {"cameraId": "cam1"}
        metadata_to_forward = PayloadMetadata(session=session)
        decision_maker = DecisionMaker(Mock(), Mock(), Mock(), Mock())

        # AND
        decision_maker._sub_graph = graph
        decision_maker._mould_state = mould_state
        decision_maker._edge_cameras = edge_cameras

        # AND
        recalculate_expected_plies(mould_state, graph, edge_cameras)

        # AND more methods patched
        mocker.patch.object(decision_maker, "_static_graph")
        feedback_invoke = mocker.patch("app.decision_maker.LaserFeedback.invoke")
        log = mocker.patch("app.dm_helper.edge_verification_message_validation.log")

        # WHEN decision_maker.handle_edge_verification_message is called, assert that an exception is raised
        with pytest.raises(Exception) as exc_info:
            await decision_maker.handle_edge_verification_message(verification_data, metadata_to_forward)

        # THEN an exception of type ValueError is raised
        assert exc_info.type is ValueError
        assert "Invalid edge verification data received" in exc_info.value.args[0]

        # AND Feedback().invoke is not called, means execution of handler was aborted
        assert feedback_invoke.call_count == 0

        # AND log.warning is called
        assert log.warning.call_count == 1
        assert "Invalid edge verification data received" in log.warning.call_args.args[0]


@pytest.mark.asyncio
@patch("app.config.MOULD_ID", "mould_id")
class HandleFinaliseCommandTests:
    async def test_should_raise_exception_and_abort_finalise_command_handling_when_state_is_not_yet_initialised(
            self, mocker):
        # GIVEN
        messaging_wrapper = mocker.patch("app.decision_maker.MessagingWrapper", new_callable=AsyncMock)
        mould_state = MouldState(set())
        decision_maker = DecisionMaker(Mock(), messaging_wrapper, Mock(), mould_state)
        finalise_request = create_finalise_c2dm_request(mould_id="mould_id")

        # AND more methods patched
        log = mocker.patch("app.decision_maker.log")
        image_grabbing_stop = mocker.patch("app.decision_maker.ImageGrabbing.stop")

        # WHEN decision_maker.handle_finalise_command is called, assert that an exception is raised
        with pytest.raises(Exception) as exc_info:
            await decision_maker.handle_finalise_command(finalise_request.payload)

        # THEN an exception of correct type is raised
        assert exc_info.type is ValueError

        warning_message = "Can't process handle_finalise_command while DM is not yet loaded with Team Instructions."
        assert exc_info.value.args[0] == warning_message

        # AND log.warning is called once with correct arguments
        assert log.warning.call_count == 1
        call_args = log.warning.call_args.args
        assert call_args[0] == warning_message

        # AND image_grabbing.stop is not called, means execution of the handling process is aborted
        assert image_grabbing_stop.call_count == 0

    async def test_should_not_abort_finalise_command_handling_when_state_is_initialised(
            self, mocker, sample_mould_state_plies, sample_instructions_data):
        # GIVEN
        messaging_wrapper = mocker.patch("app.decision_maker.MessagingWrapper", new_callable=AsyncMock)
        mould_state = MouldState(sample_mould_state_plies)
        team_instructions = TeamInstructions(sample_instructions_data)
        decision_maker = DecisionMaker(Mock(), messaging_wrapper, team_instructions, mould_state)
        finalise_request = create_finalise_c2dm_request(mould_id="mould_id")

        # AND
        decision_maker._mould_state = mould_state

        # AND more methods patched
        image_grabbing_stop = mocker.patch("app.decision_maker.ImageGrabbing.stop")
        mocker.patch.object(decision_maker, "_sub_graph")

        # WHEN decision_maker.handle_finalise_command is called
        await decision_maker.handle_finalise_command(finalise_request.payload)

        # THEN image_grabbing_stop is called and awaited, means execution of the handling process is not aborted
        assert image_grabbing_stop.call_count == 1
        assert image_grabbing_stop.await_count == 1

    async def test_should_raise_exception_when_state_is_initialised_but_invalid_mould_id_given(
            self, mocker, sample_mould_state_plies):
        # GIVEN
        log = mocker.patch("app.decision_maker.log")
        messaging_wrapper = mocker.patch("app.decision_maker.MessagingWrapper", new_callable=AsyncMock)
        mould_state = MouldState(sample_mould_state_plies)
        decision_maker = DecisionMaker(Mock(), messaging_wrapper, Mock(), mould_state)
        finalise_request = create_finalise_c2dm_request(mould_id="other_mould_id")

        # AND
        decision_maker._mould_state = mould_state

        # AND more methods patched
        image_grabbing_stop = mocker.patch("app.decision_maker.ImageGrabbing.stop")
        mocker.patch.object(decision_maker, "_sub_graph")

        # WHEN decision_maker.handle_finalise_command is called, assert that an exception is raised
        with pytest.raises(Exception) as exc_info:
            await decision_maker.handle_finalise_command(finalise_request.payload)

        # THEN an exception of correct type is raised
        assert exc_info.type is ValueError

        warning_message = f"Aborting handle_finalise_command, " \
                          f"due to given mouldId != preconfigured mould_id (other_mould_id != mould_id)"
        assert exc_info.value.args[0] == warning_message

        # AND log.warning is called once with correct arguments
        assert log.warning.call_count == 1
        call_args = log.warning.call_args.args
        assert call_args[0] == warning_message

        # AND image_grabbing.stop is not called, means execution of the handling process is aborted
        assert image_grabbing_stop.call_count == 0

    async def test_should_correctly_reset_decision_maker_module_into_initial_state(
            self, mocker, sample_mould_state_plies, sample_graph_data, sample_instructions_data):
        # GIVEN
        shared_storage = mocker.patch("app.decision_maker.SharedStorage")
        messaging_wrapper = mocker.patch("app.decision_maker.MessagingWrapper", new_callable=AsyncMock)
        mould_state = MouldState(sample_mould_state_plies)
        team_instructions = TeamInstructions(sample_instructions_data)
        decision_maker = DecisionMaker(shared_storage, messaging_wrapper, team_instructions, mould_state)
        finalise_request = create_finalise_c2dm_request(mould_id="mould_id")

        # AND
        sub_graph = Graph(sample_graph_data)
        decision_maker._sub_graph = sub_graph

        # AND decision_maker state methods patched
        mocker.patch.object(decision_maker, "_static_graph")
        mocker.patch.object(decision_maker._team_instructions, "_stored_team_instructions_data")
        mocker.patch.object(decision_maker, "_feedback_positions")

        # AND more methods patched
        feedback_invoke = mocker.patch("app.decision_maker.LaserFeedback.invoke")
        image_grabbing_stop = mocker.patch("app.decision_maker.ImageGrabbing.stop")

        # WHEN decision_maker.handle_finalise_command is called
        await decision_maker.handle_finalise_command(finalise_request.payload)

        # THEN ImageGrabbing.stop is called and awaited with correct arguments
        assert image_grabbing_stop.call_count == 1
        assert image_grabbing_stop.await_count == 1
        call_args = image_grabbing_stop.call_args.args
        assert call_args[0] == {"cam1", "cam2"}

        # AND
        assert shared_storage.remove_mould_plies.call_count == 1
        assert shared_storage.remove_mould_instructions.call_count == 1

        # AND
        assert shared_storage.set_mould_state.call_count == 1
        call_args = shared_storage.set_mould_state.call_args.args
        assert call_args[0] == GlobalMouldState.FINALISED

        # AND decision_maker state is cleared
        assert decision_maker._static_graph is None
        assert decision_maker._sub_graph is None
        assert decision_maker._mould_state.plies == set()
        assert decision_maker._team_instructions.data == []
        assert decision_maker._edge_cameras is None
        assert decision_maker._feedback_positions is None

        # AND Feedback().invoke is called and awaited once with correct argument
        assert feedback_invoke.call_count == 1
        assert feedback_invoke.await_count == 1
        call_args = feedback_invoke.call_args.args
        expected_feedback_to_send = {"plies-to-null": {"P1": {"dxf_id": "dxf_id_P",
                                                              "dxf_ply_id": "dxf_ply_id_P1",
                                                              "edges": ["P1.1", "P1.2"],
                                                              "edges_covered": [],
                                                              "layer_id": "layer_P",
                                                              "next_plies": ["P2"],
                                                              "pallet_id": "pallet_1",
                                                              "previous_plies": []},
                                                       "P2": {"dxf_id": "dxf_id_P",
                                                              "dxf_ply_id": "dxf_ply_id_P2",
                                                              "edges": ["P2.1", "P2.2"],
                                                              "edges_covered": ["P1.2"],
                                                              "layer_id": "layer_P",
                                                              "next_plies": ["P3"],
                                                              "pallet_id": "pallet_1",
                                                              "previous_plies": ["P1"]}}}
        assert call_args[0] == expected_feedback_to_send


class GlobalMouldStateUpdateCallbackTests:
    @pytest.mark.parametrize(
        "state_update, expected_finalise_call_count",
        [
            (GlobalMouldState.FINALISED, 1),
            (GlobalMouldState.NONE, 0),
            (GlobalMouldState.PRODUCTION, 0),
        ]
    )
    def test_should_finalise_only_on_global_mould_state_change_to_finalised_when_various_state_types_via_etcd_received(
            self, mocker, state_update, expected_finalise_call_count):
        # GIVEN
        mould_state_plies_is_not_empty = True
        decision_maker = DecisionMaker(Mock(), Mock(), Mock(), Mock())
        decision_maker_finalise = mocker.patch.object(decision_maker, "_finalise")
        mocker.patch.object(decision_maker._mould_state, "plies", mould_state_plies_is_not_empty)

        # WHEN
        decision_maker._global_mould_state_finalisation_update_callback(state_update.name)

        # THEN
        assert decision_maker_finalise.call_count == expected_finalise_call_count
        assert decision_maker_finalise.await_count == expected_finalise_call_count

    def test_should_raise_exception_when_mould_state_not_initialised_and_finalised_global_mould_state_update_recieved(
            self, mocker):
        # GIVEN
        mould_state_plies_is_not_empty = False
        decision_maker = DecisionMaker(Mock(), Mock(), Mock(), Mock())
        mocker.patch.object(decision_maker._mould_state, "plies", mould_state_plies_is_not_empty)

        # WHEN decision_maker._global_mould_state_update_callback is called, assert that an exception is raised
        with pytest.raises(Exception) as exc_info:
            decision_maker._global_mould_state_finalisation_update_callback(GlobalMouldState.FINALISED.name)

        # THEN an exception of type ValueError is raised
        assert exc_info.type is ValueError
        error_message = "Can't process finalised_state_received_via_etcd " \
                        "while DM is not yet loaded with Team Instructions."
        assert exc_info.value.args[0] == error_message


@pytest.mark.asyncio
@patch("app.config.MOULD_ID", "mould_id")
class HandleUndoPliesToCommandTests:
    @pytest.mark.parametrize(
        "ply_state", [PlyStateEnum.PLACED, PlyStateEnum.MISSING, PlyStateEnum.FORCED, PlyStateEnum.COVERED])
    async def test_should_not_abort_command_handling_when_ply_with_valid_state_given(self, mocker, ply_state):
        # GIVEN
        messaging_wrapper = mocker.patch("app.decision_maker.MessagingWrapper", new_callable=AsyncMock)
        ply_to_undo_id = "ply_to_undo_id"
        state_plies = {PlyState(ply_to_undo_id, state=ply_state)}
        mould_state = MouldState(copy.deepcopy(state_plies))
        decision_maker = DecisionMaker(Mock(), messaging_wrapper, Mock(), mould_state)
        undo_plies_request = create_undo_plies_to_c2dm_request(ply_id=ply_to_undo_id, mould_id="mould_id")

        # AND more methods patched
        mocker.patch.object(decision_maker, "_sub_graph", return_value=Graph({"plies": {}}))
        process_mould_state_changes = mocker.patch.object(decision_maker, "_process_mould_state_changes")
        mocker.patch.object(decision_maker._mould_state, "undo_ply")

        # WHEN decision_maker.handle_undo_plies_to_command is called
        await decision_maker.handle_undo_plies_to_command(undo_plies_request.payload)

        # THEN DecisionMaker._process_mould_state_changes is called, means execution of the process is not aborted
        assert process_mould_state_changes.call_count == 1
        assert process_mould_state_changes.await_count == 1

    @pytest.mark.parametrize("ply_state", [PlyStateEnum.EXPECTED])
    async def test_should_raise_exception_and_abort_command_handling_when_ply_with_invalid_state_given(
            self, mocker, ply_state):
        # GIVEN
        messaging_wrapper = mocker.patch("app.decision_maker.MessagingWrapper", new_callable=AsyncMock)
        ply_to_undo_id = "ply_to_undo_id"
        state_plies = {PlyState(ply_to_undo_id, state=ply_state)}
        mould_state = MouldState(copy.deepcopy(state_plies))
        decision_maker = DecisionMaker(Mock(), messaging_wrapper, Mock(), mould_state)
        undo_plies_request = create_undo_plies_to_c2dm_request(ply_id=ply_to_undo_id, mould_id="mould_id")

        # AND more methods patched
        process_mould_state_changes = mocker.patch.object(decision_maker, "_process_mould_state_changes")

        # WHEN decision_maker.handle_undo_plies_to_command is called, assert that an exception is raised
        with pytest.raises(Exception) as exc_info:
            await decision_maker.handle_undo_plies_to_command(undo_plies_request.payload)

        # THEN an exception of correct type is raised
        assert exc_info.type is ValueError
        error_message = f"Given ply {ply_to_undo_id} is not valid ply to undo_plies_to, " \
                        f"it must be not {ply_state.name} ply."
        assert exc_info.value.args[0] == error_message

        # AND DecisionMaker._process_mould_state_changes is not called, means execution of the process is aborted
        assert process_mould_state_changes.call_count == 0
        assert process_mould_state_changes.await_count == 0

    async def test_should_correctly_report_error_when_exception_raised_while_undoing_plies(self, mocker):
        # GIVEN
        messaging_wrapper = mocker.patch("app.decision_maker.MessagingWrapper", new_callable=AsyncMock)
        ply_to_undo_id = "ply_to_undo_id"
        state_plies = {PlyState(ply_to_undo_id, state=PlyStateEnum.PLACED)}
        mould_state = MouldState(copy.deepcopy(state_plies))
        decision_maker = DecisionMaker(Mock(), messaging_wrapper, Mock(), mould_state)
        undo_plies_request = create_undo_plies_to_c2dm_request(ply_id=ply_to_undo_id, mould_id="mould_id")

        # AND more methods patched
        mocker.patch.object(decision_maker, "_sub_graph", return_value=Graph({"plies": {}}))
        process_mould_state_changes = mocker.patch.object(decision_maker, "_process_mould_state_changes")

        # AND raised exception when mould_state.undo_ply is called
        ex_message = "exception message"
        mocker.patch.object(mould_state, "undo_ply", side_effect=ValueError(ex_message))

        # WHEN decision_maker.handle_undo_plies_to_command is called, assert that an exception is raised
        with pytest.raises(Exception) as exc_info:
            await decision_maker.handle_undo_plies_to_command(undo_plies_request.payload)

        # THEN an exception of correct type is raised
        assert exc_info.type is ValueError
        error_message = f"Failed to undo_plies_to for given ply_id: {ply_to_undo_id} " \
                        f"and its dependents: {[ply_to_undo_id]}, due to {ex_message}"
        assert exc_info.value.args[0] == error_message

        # AND DecisionMaker._process_mould_state_changes is not called, means execution of the process is aborted
        assert process_mould_state_changes.call_count == 0
        assert process_mould_state_changes.await_count == 0

    async def test_should_raise_exception_and_abort_command_handling_when_non_existing_ply_id_given(self, mocker):
        # GIVEN
        messaging_wrapper = mocker.patch("app.decision_maker.MessagingWrapper", new_callable=AsyncMock)
        ply_to_undo_id = "NON_EXISTING_PLY_ID"
        state_plies = {PlyState("P1", state=PlyStateEnum.EXPECTED)}
        mould_state = MouldState(copy.deepcopy(state_plies))
        decision_maker = DecisionMaker(Mock(), messaging_wrapper, Mock(), mould_state)
        undo_plies_request = create_undo_plies_to_c2dm_request(ply_id=ply_to_undo_id, mould_id="mould_id")

        # WHEN decision_maker.handle_undo_plies_to_command is called, assert that an exception is raised
        with pytest.raises(Exception) as exc_info:
            await decision_maker.handle_undo_plies_to_command(undo_plies_request.payload)

        # THEN an exception of correct type is raised
        assert exc_info.type is ValueError
        error_message = f"Failed to get ply in mould state by given ply_id: {ply_to_undo_id}"
        assert exc_info.value.args[0] == error_message

    async def test_should_correctly_undo_single_placed_ply_when_initial_ply_given(self, mocker):
        # GIVEN
        messaging_wrapper = mocker.patch("app.decision_maker.MessagingWrapper", new_callable=AsyncMock)
        state_plies_mock = StatePliesMock()
        first_ply_undo_to = state_plies_mock.first_ply_placed
        second_ply = state_plies_mock.second_ply_expected
        state_plies = {first_ply_undo_to, second_ply}
        mould_state = MouldState(state_plies)
        graph_data = {
            "plies": {
                "P1": {"previous_plies": [], "edges": ["P1.1", "P1.2"], "edges_covered": []},
                "P2": {"previous_plies": ["P1"], "edges": ["P2.1", "P2.2"], "edges_covered": ["P1.2"]},
                "P3": {"previous_plies": ["P2"], "edges": ["P3.1", "P3.2"], "edges_covered": ["P2.2"]},
                "P4": {"previous_plies": ["P3"], "edges": ["P4.1", "P4.2"], "edges_covered": ["P3.2"]},
                "P5": {"previous_plies": ["P4"], "edges": ["P5.1", "P5.2"], "edges_covered": ["P4.2"]},
            }
        }
        decision_maker = DecisionMaker(Mock(), messaging_wrapper, Mock(), mould_state)
        decision_maker._sub_graph = Graph(graph_data)
        undo_plies_request = create_undo_plies_to_c2dm_request(ply_id=first_ply_undo_to.id, mould_id="mould_id")

        # AND more methods patched
        process_mould_state_changes = mocker.patch.object(decision_maker, "_process_mould_state_changes")

        # WHEN decision_maker.handle_undo_plies_to_command is called
        await decision_maker.handle_undo_plies_to_command(undo_plies_request.payload)

        # THEN DecisionMaker._process_mould_state_changes is called
        assert process_mould_state_changes.call_count == 1
        assert process_mould_state_changes.await_count == 1
        call_args = process_mould_state_changes.call_args.args
        assert call_args[0] == {second_ply, first_ply_undo_to}

        # AND ply to undo to is correctly reset to expected
        result = mould_state.find_ply(first_ply_undo_to.id)
        assert result is not None
        assert result.state == PlyStateEnum.EXPECTED
        assert result.previous_state == PlyStateEnum.PLACED
        assert result.updated_by == "command:undo_ply:force"
        assert result.get_edge("P1.1").state == EdgeStateEnum.MISSING
        assert result.get_edge("P1.2").state == EdgeStateEnum.MISSING
        assert result.get_edge("P1.1").get_cam("cam1").state == EdgeCamStateEnum.NEVER_DETECTED
        assert result.get_edge("P1.2").get_cam("cam1").state == EdgeCamStateEnum.NEVER_DETECTED

        # AND next ply is removed from local mould state
        assert mould_state.find_ply(second_ply.id) is None

    async def test_should_correctly_undo_multiple_placed_plies_when_initial_ply_given(self, mocker):
        # GIVEN
        messaging_wrapper = mocker.patch("app.decision_maker.MessagingWrapper", new_callable=AsyncMock)
        state_plies_mock = StatePliesMock()
        first_ply_undo_to = state_plies_mock.first_ply_partially_covered
        second_ply = state_plies_mock.second_ply_partially_covered
        third_ply = state_plies_mock.third_ply_partially_covered
        fourth_ply = state_plies_mock.fourth_ply_partially_covered
        fifth_ply = state_plies_mock.fifth_ply_placed
        state_plies = {first_ply_undo_to, second_ply, third_ply, fourth_ply, fifth_ply}
        mould_state = MouldState(state_plies)
        graph_data = {
            "plies": {
                "P1": {"previous_plies": [], "edges": ["P1.1", "P1.2"], "edges_covered": []},
                "P2": {"previous_plies": ["P1"], "edges": ["P2.1", "P2.2"], "edges_covered": ["P1.2"]},
                "P3": {"previous_plies": ["P2"], "edges": ["P3.1", "P3.2"], "edges_covered": ["P2.2"]},
                "P4": {"previous_plies": ["P3"], "edges": ["P4.1", "P4.2"], "edges_covered": ["P3.2"]},
                "P5": {"previous_plies": ["P4"], "edges": ["P5.1", "P5.2"], "edges_covered": ["P4.2"]},
            }
        }
        decision_maker = DecisionMaker(Mock(), messaging_wrapper, Mock(), mould_state)
        decision_maker._sub_graph = Graph(graph_data)
        undo_plies_request = create_undo_plies_to_c2dm_request(ply_id=first_ply_undo_to.id, mould_id="mould_id")

        # AND more methods patched
        process_mould_state_changes = mocker.patch.object(decision_maker, "_process_mould_state_changes")

        # WHEN decision_maker.handle_undo_plies_to_command is called
        await decision_maker.handle_undo_plies_to_command(undo_plies_request.payload)

        # THEN DecisionMaker._process_mould_state_changes is called
        assert process_mould_state_changes.call_count == 1
        assert process_mould_state_changes.await_count == 1
        call_args = process_mould_state_changes.call_args.args
        assert call_args[0] == {first_ply_undo_to, second_ply, third_ply, fourth_ply, fifth_ply}

        # AND ply to undo to is correctly reset to expected
        result = mould_state.find_ply(first_ply_undo_to.id)
        assert result is not None
        assert result.state == PlyStateEnum.EXPECTED
        assert result.previous_state == PlyStateEnum.PLACED
        assert result.updated_by == "command:undo_ply:force"
        assert result.get_edge("P1.1").state == EdgeStateEnum.MISSING
        assert result.get_edge("P1.2").state == EdgeStateEnum.MISSING
        assert result.get_edge("P1.1").get_cam("cam1").state == EdgeCamStateEnum.NEVER_DETECTED
        assert result.get_edge("P1.2").get_cam("cam1").state == EdgeCamStateEnum.NEVER_DETECTED

        # AND next plies are removed from local mould state
        assert mould_state.find_ply(second_ply.id) is None
        assert mould_state.find_ply(third_ply.id) is None
        assert mould_state.find_ply(fourth_ply.id) is None
        assert mould_state.find_ply(fifth_ply.id) is None

    async def test_should_correctly_undo_multiple_placed_plies_when_middle_ply_given(self, mocker):
        # GIVEN
        messaging_wrapper = mocker.patch("app.decision_maker.MessagingWrapper", new_callable=AsyncMock)
        state_plies_mock = StatePliesMock()
        first_ply = state_plies_mock.first_ply_partially_covered
        second_ply = state_plies_mock.second_ply_partially_covered
        third_ply_undo_to = state_plies_mock.third_ply_partially_covered
        fourth_ply = state_plies_mock.fourth_ply_partially_covered
        fifth_ply = state_plies_mock.fifth_ply_placed
        state_plies = {first_ply, second_ply, third_ply_undo_to, fourth_ply, fifth_ply}
        mould_state = MouldState(state_plies)
        graph_data = {
            "plies": {
                "P1": {"previous_plies": [], "edges": ["P1.1", "P1.2"], "edges_covered": []},
                "P2": {"previous_plies": ["P1"], "edges": ["P2.1", "P2.2"], "edges_covered": ["P1.2"]},
                "P3": {"previous_plies": ["P2"], "edges": ["P3.1", "P3.2"], "edges_covered": ["P2.2"]},
                "P4": {"previous_plies": ["P3"], "edges": ["P4.1", "P4.2"], "edges_covered": ["P3.2"]},
                "P5": {"previous_plies": ["P4"], "edges": ["P5.1", "P5.2"], "edges_covered": ["P4.2"]},
            }
        }
        decision_maker = DecisionMaker(Mock(), messaging_wrapper, Mock(), mould_state)
        decision_maker._sub_graph = Graph(graph_data)
        undo_plies_request = create_undo_plies_to_c2dm_request(ply_id=third_ply_undo_to.id, mould_id="mould_id")

        # AND more methods patched
        process_mould_state_changes = mocker.patch.object(decision_maker, "_process_mould_state_changes")

        # WHEN decision_maker.handle_undo_plies_to_command is called
        await decision_maker.handle_undo_plies_to_command(undo_plies_request.payload)

        # THEN DecisionMaker._process_mould_state_changes is called
        assert process_mould_state_changes.call_count == 1
        assert process_mould_state_changes.await_count == 1
        call_args = process_mould_state_changes.call_args.args
        assert call_args[0] == {second_ply, third_ply_undo_to, fourth_ply, fifth_ply}

        # AND previous ply is unchanged
        assert mould_state.find_ply(first_ply.id) == StatePliesMock().first_ply_partially_covered

        # AND partially covered ply is correctly reset to placed
        result = mould_state.find_ply(second_ply.id)
        assert result is not None
        assert result.state == PlyStateEnum.PLACED
        assert result.previous_state == PlyStateEnum.PLACED
        assert result.updated_by == "command:undo_ply:force"
        assert result.get_edge("P2.1").state == EdgeStateEnum.DETECTED
        assert result.get_edge("P2.2").state == EdgeStateEnum.DETECTED
        assert result.get_edge("P2.1").get_cam("cam1").state == EdgeCamStateEnum.DETECTED
        assert result.get_edge("P2.2").get_cam("cam1").state == EdgeCamStateEnum.DETECTED
        assert result.get_edge("P2.2").get_cam("cam2").state == EdgeCamStateEnum.NEVER_DETECTED

        # AND ply to undo to is correctly reset to expected
        result = mould_state.find_ply(third_ply_undo_to.id)
        assert result is not None
        assert result.state == PlyStateEnum.EXPECTED
        assert result.previous_state == PlyStateEnum.PLACED
        assert result.updated_by == "command:undo_ply:force"
        assert result.get_edge("P3.1").state == EdgeStateEnum.MISSING
        assert result.get_edge("P3.2").state == EdgeStateEnum.MISSING
        assert result.get_edge("P3.1").get_cam("cam2").state == EdgeCamStateEnum.NEVER_DETECTED
        assert result.get_edge("P3.2").get_cam("cam2").state == EdgeCamStateEnum.NEVER_DETECTED

        # AND next plies are removed from local mould state
        assert mould_state.find_ply(fourth_ply.id) is None
        assert mould_state.find_ply(fifth_ply.id) is None

    async def test_should_correctly_undo_single_placed_ply_when_last_ply_given(self, mocker):
        # GIVEN
        messaging_wrapper = mocker.patch("app.decision_maker.MessagingWrapper", new_callable=AsyncMock)
        state_plies_mock = StatePliesMock()
        first_ply = state_plies_mock.first_ply_partially_covered
        second_ply = state_plies_mock.second_ply_partially_covered
        third_ply = state_plies_mock.third_ply_partially_covered
        fourth_ply = state_plies_mock.fourth_ply_partially_covered
        fifth_ply_undo_to = state_plies_mock.fifth_ply_placed
        state_plies = {first_ply, second_ply, third_ply, fourth_ply, fifth_ply_undo_to}
        mould_state = MouldState(state_plies)
        graph_data = {
            "plies": {
                "P1": {"previous_plies": [], "edges": ["P1.1", "P1.2"], "edges_covered": []},
                "P2": {"previous_plies": ["P1"], "edges": ["P2.1", "P2.2"], "edges_covered": ["P1.2"]},
                "P3": {"previous_plies": ["P2"], "edges": ["P3.1", "P3.2"], "edges_covered": ["P2.2"]},
                "P4": {"previous_plies": ["P3"], "edges": ["P4.1", "P4.2"], "edges_covered": ["P3.2"]},
                "P5": {"previous_plies": ["P4"], "edges": ["P5.1", "P5.2"], "edges_covered": ["P4.2"]},
            }
        }
        decision_maker = DecisionMaker(Mock(), messaging_wrapper, Mock(), mould_state)
        decision_maker._sub_graph = Graph(graph_data)
        undo_plies_request = create_undo_plies_to_c2dm_request(ply_id=fifth_ply_undo_to.id, mould_id="mould_id")

        # AND more methods patched
        process_mould_state_changes = mocker.patch.object(decision_maker, "_process_mould_state_changes")

        # WHEN decision_maker.handle_undo_plies_to_command is called
        await decision_maker.handle_undo_plies_to_command(undo_plies_request.payload)

        # THEN DecisionMaker._process_mould_state_changes is called
        assert process_mould_state_changes.call_count == 1
        assert process_mould_state_changes.await_count == 1
        call_args = process_mould_state_changes.call_args.args
        assert call_args[0] == {fourth_ply, fifth_ply_undo_to}

        # AND previous plies are unchanged
        assert mould_state.find_ply(first_ply.id) == StatePliesMock().first_ply_partially_covered
        assert mould_state.find_ply(second_ply.id) == StatePliesMock().second_ply_partially_covered
        assert mould_state.find_ply(third_ply.id) == StatePliesMock().third_ply_partially_covered

        # AND partially covered ply is correctly reset to placed
        result = mould_state.find_ply(fourth_ply.id)
        assert result is not None
        assert result.state == PlyStateEnum.PLACED
        assert result.previous_state == PlyStateEnum.EXPECTED
        assert result.updated_by == "command:undo_ply:force"
        assert result.get_edge("P4.1").state == EdgeStateEnum.DETECTED
        assert result.get_edge("P4.2").state == EdgeStateEnum.DETECTED
        assert result.get_edge("P4.1").get_cam("cam2").state == EdgeCamStateEnum.DETECTED
        assert result.get_edge("P4.2").get_cam("cam2").state == EdgeCamStateEnum.DETECTED

        # AND ply to undo to is correctly reset to expected
        result = mould_state.find_ply(fifth_ply_undo_to.id)
        assert result is not None
        assert result.state == PlyStateEnum.EXPECTED
        assert result.previous_state == PlyStateEnum.PLACED
        assert result.updated_by == "command:undo_ply:force"
        assert result.get_edge("P5.1").state == EdgeStateEnum.MISSING
        assert result.get_edge("P5.2").state == EdgeStateEnum.MISSING
        assert result.get_edge("P5.1").get_cam("cam2").state == EdgeCamStateEnum.NEVER_DETECTED
        assert result.get_edge("P5.2").get_cam("cam2").state == EdgeCamStateEnum.NEVER_DETECTED

    async def test_should_correctly_undo_some_plies_when_initial_ply_and_graph_with_multiple_independent_plies_given(
            self, mocker):
        # GIVEN
        messaging_wrapper = mocker.patch("app.decision_maker.MessagingWrapper", new_callable=AsyncMock)
        state_plies_mock = StatePliesMock()
        first_ply_undo_to = state_plies_mock.first_ply_partially_covered
        second_ply = state_plies_mock.second_ply_partially_covered
        third_ply = state_plies_mock.third_ply_placed
        fourth_ply = state_plies_mock.fourth_ply_partially_covered
        fifth_ply = state_plies_mock.fifth_ply_placed
        state_plies = {first_ply_undo_to, second_ply, third_ply, fourth_ply, fifth_ply}
        mould_state = MouldState(state_plies)
        graph_data = {
            "plies": {
                "P1": {"previous_plies": [], "edges": ["P1.1", "P1.2"], "edges_covered": []},
                "P2": {"previous_plies": ["P1"], "edges": ["P2.1", "P2.2"], "edges_covered": ["P1.2"]},
                "P3": {"previous_plies": ["P2"], "edges": ["P3.1", "P3.2"], "edges_covered": ["P2.2"]},
                "P4": {"previous_plies": [], "edges": ["P4.1", "P4.2"], "edges_covered": []},
                "P5": {"previous_plies": ["P4"], "edges": ["P5.1", "P5.2"], "edges_covered": ["P4.2"]},
            }
        }
        decision_maker = DecisionMaker(Mock(), messaging_wrapper, Mock(), mould_state)
        decision_maker._sub_graph = Graph(graph_data)
        undo_plies_request = create_undo_plies_to_c2dm_request(ply_id=first_ply_undo_to.id, mould_id="mould_id")

        # AND more methods patched
        process_mould_state_changes = mocker.patch.object(decision_maker, "_process_mould_state_changes")

        # WHEN decision_maker.handle_undo_plies_to_command is called
        await decision_maker.handle_undo_plies_to_command(undo_plies_request.payload)

        # THEN DecisionMaker._process_mould_state_changes is called
        assert process_mould_state_changes.call_count == 1
        assert process_mould_state_changes.await_count == 1
        call_args = process_mould_state_changes.call_args.args
        assert call_args[0] == {first_ply_undo_to, second_ply, third_ply}

        # AND ply to undo to is correctly reset to expected
        result = mould_state.find_ply(first_ply_undo_to.id)
        assert result is not None
        assert result.state == PlyStateEnum.EXPECTED
        assert result.previous_state == PlyStateEnum.PLACED
        assert result.updated_by == "command:undo_ply:force"
        assert result.get_edge("P1.1").state == EdgeStateEnum.MISSING
        assert result.get_edge("P1.2").state == EdgeStateEnum.MISSING
        assert result.get_edge("P1.1").get_cam("cam1").state == EdgeCamStateEnum.NEVER_DETECTED
        assert result.get_edge("P1.2").get_cam("cam1").state == EdgeCamStateEnum.NEVER_DETECTED

        # AND next plies are removed from local mould state
        assert mould_state.find_ply(second_ply.id) is None
        assert mould_state.find_ply(third_ply.id) is None

        # AND next plies are unchanged
        assert mould_state.find_ply(fourth_ply.id) == StatePliesMock().fourth_ply_partially_covered
        assert mould_state.find_ply(fifth_ply.id) == StatePliesMock().fifth_ply_placed

    async def test_should_correctly_undo_only_middle_ply_when_middle_ply_and_graph_with_multiple_independent_plies_given(
            self, mocker):
        # GIVEN
        messaging_wrapper = mocker.patch("app.decision_maker.MessagingWrapper", new_callable=AsyncMock)
        state_plies_mock = StatePliesMock()
        first_ply = state_plies_mock.first_ply_partially_covered
        second_ply = state_plies_mock.second_ply_partially_covered
        third_ply_undo_to = state_plies_mock.third_ply_placed
        fourth_ply = state_plies_mock.fourth_ply_partially_covered
        fifth_ply = state_plies_mock.fifth_ply_placed
        state_plies = {first_ply, second_ply, third_ply_undo_to, fourth_ply, fifth_ply}
        mould_state = MouldState(state_plies)
        graph_data = {
            "plies": {
                "P1": {"previous_plies": [], "edges": ["P1.1", "P1.2"], "edges_covered": []},
                "P2": {"previous_plies": ["P1"], "edges": ["P2.1", "P2.2"], "edges_covered": ["P1.2"]},
                "P3": {"previous_plies": ["P2"], "edges": ["P3.1", "P3.2"], "edges_covered": ["P2.2"]},
                "P4": {"previous_plies": [], "edges": ["P4.1", "P4.2"], "edges_covered": []},
                "P5": {"previous_plies": ["P4"], "edges": ["P5.1", "P5.2"], "edges_covered": ["P4.2"]},
            }
        }
        decision_maker = DecisionMaker(Mock(), messaging_wrapper, Mock(), mould_state)
        decision_maker._sub_graph = Graph(graph_data)
        undo_plies_request = create_undo_plies_to_c2dm_request(ply_id=third_ply_undo_to.id, mould_id="mould_id")

        # AND more methods patched
        process_mould_state_changes = mocker.patch.object(decision_maker, "_process_mould_state_changes")

        # WHEN decision_maker.handle_undo_plies_to_command is called
        await decision_maker.handle_undo_plies_to_command(undo_plies_request.payload)

        # THEN DecisionMaker._process_mould_state_changes is called
        assert process_mould_state_changes.call_count == 1
        assert process_mould_state_changes.await_count == 1
        call_args = process_mould_state_changes.call_args.args
        assert call_args[0] == {second_ply, third_ply_undo_to}

        # AND previous ply are unchanged
        assert mould_state.find_ply(first_ply.id) == StatePliesMock().first_ply_partially_covered

        # AND partially covered ply is correctly reset to placed
        result = mould_state.find_ply(second_ply.id)
        assert result is not None
        assert result.state == PlyStateEnum.PLACED
        assert result.previous_state == PlyStateEnum.PLACED
        assert result.updated_by == "command:undo_ply:force"
        assert result.get_edge("P2.1").state == EdgeStateEnum.DETECTED
        assert result.get_edge("P2.2").state == EdgeStateEnum.DETECTED
        assert result.get_edge("P2.1").get_cam("cam1").state == EdgeCamStateEnum.DETECTED
        assert result.get_edge("P2.2").get_cam("cam1").state == EdgeCamStateEnum.DETECTED
        assert result.get_edge("P2.2").get_cam("cam2").state == EdgeCamStateEnum.NEVER_DETECTED

        # AND ply to undo to is correctly reset to expected
        result = mould_state.find_ply(third_ply_undo_to.id)
        assert result is not None
        assert result.state == PlyStateEnum.EXPECTED
        assert result.previous_state == PlyStateEnum.PLACED
        assert result.updated_by == "command:undo_ply:force"
        assert result.get_edge("P3.1").state == EdgeStateEnum.MISSING
        assert result.get_edge("P3.2").state == EdgeStateEnum.MISSING
        assert result.get_edge("P3.1").get_cam("cam2").state == EdgeCamStateEnum.NEVER_DETECTED
        assert result.get_edge("P3.2").get_cam("cam2").state == EdgeCamStateEnum.NEVER_DETECTED

        # AND next plies are unchanged
        assert mould_state.find_ply(fourth_ply.id) == StatePliesMock().fourth_ply_partially_covered
        assert mould_state.find_ply(fifth_ply.id) == StatePliesMock().fifth_ply_placed

    async def test_should_correctly_undo_some_plies_when_initial_ply_and_graph_plies_with_multiple_dependents_given(
            self, mocker):
        # GIVEN
        messaging_wrapper = mocker.patch("app.decision_maker.MessagingWrapper", new_callable=AsyncMock)
        state_plies_mock = StatePliesMock()
        first_ply_undo_to = state_plies_mock.first_ply_partially_covered
        second_ply = state_plies_mock.second_ply_partially_covered
        third_ply = state_plies_mock.third_ply_placed
        fourth_ply = state_plies_mock.fourth_ply_fully_covered
        fifth_ply = state_plies_mock.fifth_ply_partially_covered
        state_plies = {first_ply_undo_to, second_ply, third_ply, fourth_ply, fifth_ply}
        mould_state = MouldState(state_plies)
        graph_data = {
            "plies": {
                "P1": {"previous_plies": [], "edges": ["P1.1", "P1.2"], "edges_covered": []},
                "P2": {"previous_plies": ["P1"], "edges": ["P2.1", "P2.2"], "edges_covered": ["P1.2"]},
                "P3": {"previous_plies": ["P2", "P4", "P5"], "edges": ["P3.1", "P3.2"],
                       "edges_covered": ["P2.2", "P4.1", "P5.1"]},
                "P4": {"previous_plies": [], "edges": ["P4.1", "P4.2"], "edges_covered": []},
                "P5": {"previous_plies": ["P4"], "edges": ["P5.1", "P5.2"], "edges_covered": ["P4.2"]},
            }
        }
        decision_maker = DecisionMaker(Mock(), messaging_wrapper, Mock(), mould_state)
        decision_maker._sub_graph = Graph(graph_data)
        undo_plies_request = create_undo_plies_to_c2dm_request(ply_id=first_ply_undo_to.id, mould_id="mould_id")

        # AND more methods patched
        process_mould_state_changes = mocker.patch.object(decision_maker, "_process_mould_state_changes")

        # WHEN decision_maker.handle_undo_plies_to_command is called
        await decision_maker.handle_undo_plies_to_command(undo_plies_request.payload)

        # THEN DecisionMaker._process_mould_state_changes is called
        assert process_mould_state_changes.call_count == 1
        assert process_mould_state_changes.await_count == 1
        call_args = process_mould_state_changes.call_args.args
        assert call_args[0] == {first_ply_undo_to, second_ply, third_ply, fourth_ply, fifth_ply}

        # AND ply to undo to is correctly reset to expected
        result = mould_state.find_ply(first_ply_undo_to.id)
        assert result is not None
        assert result.state == PlyStateEnum.EXPECTED
        assert result.previous_state == PlyStateEnum.PLACED
        assert result.updated_by == "command:undo_ply:force"
        assert result.get_edge("P1.1").state == EdgeStateEnum.MISSING
        assert result.get_edge("P1.2").state == EdgeStateEnum.MISSING
        assert result.get_edge("P1.1").get_cam("cam1").state == EdgeCamStateEnum.NEVER_DETECTED
        assert result.get_edge("P1.2").get_cam("cam1").state == EdgeCamStateEnum.NEVER_DETECTED

        # AND dependent plies are removed from local mould state
        assert mould_state.find_ply(second_ply.id) is None
        assert mould_state.find_ply(third_ply.id) is None

        # AND fully covered ply is correctly reset to partially covered
        result = mould_state.find_ply(fourth_ply.id)
        assert result is not None
        assert result.state == PlyStateEnum.PLACED
        assert result.previous_state == PlyStateEnum.COVERED
        assert result.updated_by == "command:undo_ply:force"
        assert result.get_edge("P4.1").state == EdgeStateEnum.DETECTED
        assert result.get_edge("P4.2").state == EdgeStateEnum.COVERED
        assert result.get_edge("P4.1").get_cam("cam2").state == EdgeCamStateEnum.DETECTED
        assert result.get_edge("P4.2").get_cam("cam2").state == EdgeCamStateEnum.DETECTED

        # AND partially covered ply is correctly reset to placed
        result = mould_state.find_ply(fifth_ply.id)
        assert result is not None
        assert result.state == PlyStateEnum.PLACED
        assert result.previous_state == PlyStateEnum.EXPECTED
        assert result.updated_by == "command:undo_ply:force"
        assert result.get_edge("P5.1").state == EdgeStateEnum.DETECTED
        assert result.get_edge("P5.2").state == EdgeStateEnum.DETECTED
        assert result.get_edge("P5.1").get_cam("cam2").state == EdgeCamStateEnum.DETECTED
        assert result.get_edge("P5.2").get_cam("cam2").state == EdgeCamStateEnum.DETECTED


@pytest.mark.asyncio
@patch("app.config.MOULD_ID", "mould_id")
class HandleUndoPliesToCommandWhenGraphWithMultipleIndependentPliesGivenTests:
    async def test_should_correctly_undo_plies_when_first_ply_given(self, mocker):
        # GIVEN
        messaging_wrapper = mocker.patch("app.decision_maker.MessagingWrapper", new_callable=AsyncMock)
        state_plies_mock = StatePliesMock()
        first_ply = state_plies_mock.first_ply_partially_covered
        second_ply = state_plies_mock.second_ply_partially_covered
        third_ply = state_plies_mock.third_ply_fully_covered
        fourth_ply = state_plies_mock.fourth_ply_partially_covered
        fifth_ply = state_plies_mock.fifth_ply_partially_covered
        sixth_ply = state_plies_mock.sixth_ply_placed
        ply_id_undo_to = first_ply.id
        state_plies = {first_ply, second_ply, third_ply, fourth_ply, fifth_ply, sixth_ply}
        mould_state = MouldState(state_plies)
        graph_data = {
            "plies": {
                "P1": {"previous_plies": [], "edges": ["P1.1", "P1.2"], "edges_covered": []},
                "P2": {"previous_plies": ["P1"], "edges": ["P2.1", "P2.2"], "edges_covered": ["P1.2"]},
                "P3": {"previous_plies": [], "edges": ["P3.1", "P3.2"], "edges_covered": []},
                "P4": {"previous_plies": ["P2", "P3"], "edges": ["P4.1", "P4.2"], "edges_covered": ["P2.2", "P3.1"]},
                "P5": {"previous_plies": ["P3", "P4"], "edges": ["P5.1", "P5.2"], "edges_covered": ["P4.2", "P3.2"]},
                "P6": {"previous_plies": ["P5"], "edges": ["P6.1", "P6.2"], "edges_covered": ["P5.1"]},
            }
        }
        decision_maker = DecisionMaker(Mock(), messaging_wrapper, Mock(), mould_state)
        decision_maker._sub_graph = Graph(graph_data)
        undo_plies_request = create_undo_plies_to_c2dm_request(ply_id=ply_id_undo_to, mould_id="mould_id")

        # AND more methods patched
        process_mould_state_changes = mocker.patch.object(decision_maker, "_process_mould_state_changes")

        # WHEN decision_maker.handle_undo_plies_to_command is called
        await decision_maker.handle_undo_plies_to_command(undo_plies_request.payload)

        # THEN DecisionMaker._process_mould_state_changes is called
        assert process_mould_state_changes.call_count == 1
        assert process_mould_state_changes.await_count == 1
        call_args = process_mould_state_changes.call_args.args
        assert call_args[0] == {first_ply, second_ply, third_ply, fourth_ply, fifth_ply, sixth_ply}

        # AND ply to undo to is correctly reset to expected
        result = mould_state.find_ply(ply_id_undo_to)
        assert result is not None
        assert result.state == PlyStateEnum.EXPECTED
        assert result.previous_state == PlyStateEnum.PLACED
        assert result.updated_by == "command:undo_ply:force"
        assert result.get_edge("P1.1").state == EdgeStateEnum.MISSING
        assert result.get_edge("P1.2").state == EdgeStateEnum.MISSING
        assert result.get_edge("P1.1").get_cam("cam1").state == EdgeCamStateEnum.NEVER_DETECTED
        assert result.get_edge("P1.2").get_cam("cam1").state == EdgeCamStateEnum.NEVER_DETECTED

        # AND dependent plies are removed from local mould state
        assert mould_state.find_ply(second_ply.id) is None
        assert mould_state.find_ply(fourth_ply.id) is None
        assert mould_state.find_ply(fifth_ply.id) is None
        assert mould_state.find_ply(sixth_ply.id) is None

        # AND fully covered ply is correctly reset to placed
        result = mould_state.find_ply(third_ply.id)
        assert result is not None
        assert result.state == PlyStateEnum.PLACED
        assert result.previous_state == PlyStateEnum.COVERED
        assert result.updated_by == "command:undo_ply:force"
        assert result.get_edge("P3.1").state == EdgeStateEnum.DETECTED
        assert result.get_edge("P3.2").state == EdgeStateEnum.DETECTED
        assert result.get_edge("P3.1").get_cam("cam2").state == EdgeCamStateEnum.DETECTED
        assert result.get_edge("P3.2").get_cam("cam2").state == EdgeCamStateEnum.DETECTED
        assert result.get_edge("P3.2").get_cam("cam3").state == EdgeCamStateEnum.NEVER_DETECTED

    async def test_should_correctly_undo_plies_when_second_ply_given(self, mocker):
        # GIVEN
        messaging_wrapper = mocker.patch("app.decision_maker.MessagingWrapper", new_callable=AsyncMock)
        state_plies_mock = StatePliesMock()
        first_ply = state_plies_mock.first_ply_partially_covered
        second_ply = state_plies_mock.second_ply_partially_covered
        third_ply = state_plies_mock.third_ply_fully_covered
        fourth_ply = state_plies_mock.fourth_ply_partially_covered
        fifth_ply = state_plies_mock.fifth_ply_partially_covered
        sixth_ply = state_plies_mock.sixth_ply_placed
        ply_id_undo_to = second_ply.id
        state_plies = {first_ply, second_ply, third_ply, fourth_ply, fifth_ply, sixth_ply}
        mould_state = MouldState(state_plies)
        graph_data = {
            "plies": {
                "P1": {"previous_plies": [], "edges": ["P1.1", "P1.2"], "edges_covered": []},
                "P2": {"previous_plies": ["P1"], "edges": ["P2.1", "P2.2"], "edges_covered": ["P1.2"]},
                "P3": {"previous_plies": [], "edges": ["P3.1", "P3.2"], "edges_covered": []},
                "P4": {"previous_plies": ["P2", "P3"], "edges": ["P4.1", "P4.2"], "edges_covered": ["P2.2", "P3.1"]},
                "P5": {"previous_plies": ["P3", "P4"], "edges": ["P5.1", "P5.2"], "edges_covered": ["P4.2", "P3.2"]},
                "P6": {"previous_plies": ["P5"], "edges": ["P6.1", "P6.2"], "edges_covered": ["P5.1"]},
            }
        }
        decision_maker = DecisionMaker(Mock(), messaging_wrapper, Mock(), mould_state)
        decision_maker._sub_graph = Graph(graph_data)
        undo_plies_request = create_undo_plies_to_c2dm_request(ply_id=ply_id_undo_to, mould_id="mould_id")

        # AND more methods patched
        process_mould_state_changes = mocker.patch.object(decision_maker, "_process_mould_state_changes")

        # WHEN decision_maker.handle_undo_plies_to_command is called
        await decision_maker.handle_undo_plies_to_command(undo_plies_request.payload)

        # THEN DecisionMaker._process_mould_state_changes is called
        assert process_mould_state_changes.call_count == 1
        assert process_mould_state_changes.await_count == 1
        call_args = process_mould_state_changes.call_args.args
        assert call_args[0] == {first_ply, second_ply, third_ply, fourth_ply, fifth_ply, sixth_ply}

        # AND partially covered ply is correctly reset to placed
        result = mould_state.find_ply(first_ply.id)
        assert result is not None
        assert result.state == PlyStateEnum.PLACED
        assert result.previous_state == PlyStateEnum.PLACED
        assert result.updated_by == "command:undo_ply:force"
        assert result.get_edge("P1.1").state == EdgeStateEnum.DETECTED
        assert result.get_edge("P1.2").state == EdgeStateEnum.DETECTED
        assert result.get_edge("P1.1").get_cam("cam1").state == EdgeCamStateEnum.DETECTED
        assert result.get_edge("P1.2").get_cam("cam1").state == EdgeCamStateEnum.DETECTED

        # AND ply to undo to is correctly reset to expected
        result = mould_state.find_ply(ply_id_undo_to)
        assert result is not None
        assert result.state == PlyStateEnum.EXPECTED
        assert result.previous_state == PlyStateEnum.PLACED
        assert result.updated_by == "command:undo_ply:force"
        assert result.get_edge("P2.1").state == EdgeStateEnum.MISSING
        assert result.get_edge("P2.2").state == EdgeStateEnum.MISSING
        assert result.get_edge("P2.1").get_cam("cam1").state == EdgeCamStateEnum.NEVER_DETECTED
        assert result.get_edge("P2.2").get_cam("cam1").state == EdgeCamStateEnum.NEVER_DETECTED
        assert result.get_edge("P2.2").get_cam("cam2").state == EdgeCamStateEnum.NEVER_DETECTED

        # AND dependent plies are removed from local mould state
        assert mould_state.find_ply(fourth_ply.id) is None
        assert mould_state.find_ply(fifth_ply.id) is None
        assert mould_state.find_ply(sixth_ply.id) is None

        # AND fully covered ply is correctly reset to placed
        result = mould_state.find_ply(third_ply.id)
        assert result is not None
        assert result.state == PlyStateEnum.PLACED
        assert result.previous_state == PlyStateEnum.COVERED
        assert result.updated_by == "command:undo_ply:force"
        assert result.get_edge("P3.1").state == EdgeStateEnum.DETECTED
        assert result.get_edge("P3.2").state == EdgeStateEnum.DETECTED
        assert result.get_edge("P3.1").get_cam("cam2").state == EdgeCamStateEnum.DETECTED
        assert result.get_edge("P3.2").get_cam("cam2").state == EdgeCamStateEnum.DETECTED
        assert result.get_edge("P3.2").get_cam("cam3").state == EdgeCamStateEnum.NEVER_DETECTED

    async def test_should_correctly_undo_plies_when_third_ply_given(self, mocker):
        # GIVEN
        messaging_wrapper = mocker.patch("app.decision_maker.MessagingWrapper", new_callable=AsyncMock)
        state_plies_mock = StatePliesMock()
        first_ply = state_plies_mock.first_ply_partially_covered
        second_ply = state_plies_mock.second_ply_partially_covered
        third_ply = state_plies_mock.third_ply_fully_covered
        fourth_ply = state_plies_mock.fourth_ply_partially_covered
        fifth_ply = state_plies_mock.fifth_ply_partially_covered
        sixth_ply = state_plies_mock.sixth_ply_placed
        ply_id_undo_to = third_ply.id
        state_plies = {first_ply, second_ply, third_ply, fourth_ply, fifth_ply, sixth_ply}
        mould_state = MouldState(state_plies)
        graph_data = {
            "plies": {
                "P1": {"previous_plies": [], "edges": ["P1.1", "P1.2"], "edges_covered": []},
                "P2": {"previous_plies": ["P1"], "edges": ["P2.1", "P2.2"], "edges_covered": ["P1.2"]},
                "P3": {"previous_plies": [], "edges": ["P3.1", "P3.2"], "edges_covered": []},
                "P4": {"previous_plies": ["P2", "P3"], "edges": ["P4.1", "P4.2"], "edges_covered": ["P2.2", "P3.1"]},
                "P5": {"previous_plies": ["P3", "P4"], "edges": ["P5.1", "P5.2"], "edges_covered": ["P4.2", "P3.2"]},
                "P6": {"previous_plies": ["P5"], "edges": ["P6.1", "P6.2"], "edges_covered": ["P5.1"]},
            }
        }
        decision_maker = DecisionMaker(Mock(), messaging_wrapper, Mock(), mould_state)
        decision_maker._sub_graph = Graph(graph_data)
        undo_plies_request = create_undo_plies_to_c2dm_request(ply_id=ply_id_undo_to, mould_id="mould_id")

        # AND more methods patched
        process_mould_state_changes = mocker.patch.object(decision_maker, "_process_mould_state_changes")

        # WHEN decision_maker.handle_undo_plies_to_command is called
        await decision_maker.handle_undo_plies_to_command(undo_plies_request.payload)

        # THEN DecisionMaker._process_mould_state_changes is called
        assert process_mould_state_changes.call_count == 1
        assert process_mould_state_changes.await_count == 1
        call_args = process_mould_state_changes.call_args.args
        assert call_args[0] == {second_ply, third_ply, fourth_ply, fifth_ply, sixth_ply}

        # AND previous ply is unchanged
        assert mould_state.find_ply(first_ply.id) == StatePliesMock().first_ply_partially_covered

        # AND partially covered ply is correctly reset to placed
        result = mould_state.find_ply(second_ply.id)
        assert result is not None
        assert result.state == PlyStateEnum.PLACED
        assert result.previous_state == PlyStateEnum.PLACED
        assert result.updated_by == "command:undo_ply:force"
        assert result.get_edge("P2.1").state == EdgeStateEnum.DETECTED
        assert result.get_edge("P2.2").state == EdgeStateEnum.DETECTED
        assert result.get_edge("P2.1").get_cam("cam1").state == EdgeCamStateEnum.DETECTED
        assert result.get_edge("P2.2").get_cam("cam1").state == EdgeCamStateEnum.DETECTED
        assert result.get_edge("P2.2").get_cam("cam2").state == EdgeCamStateEnum.NEVER_DETECTED

        # AND ply to undo to is correctly reset to expected
        result = mould_state.find_ply(ply_id_undo_to)
        assert result is not None
        assert result.state == PlyStateEnum.EXPECTED
        assert result.previous_state == PlyStateEnum.PLACED
        assert result.updated_by == "command:undo_ply:force"
        assert result.get_edge("P3.1").state == EdgeStateEnum.MISSING
        assert result.get_edge("P3.2").state == EdgeStateEnum.MISSING
        assert result.get_edge("P3.1").get_cam("cam2").state == EdgeCamStateEnum.NEVER_DETECTED
        assert result.get_edge("P3.2").get_cam("cam2").state == EdgeCamStateEnum.NEVER_DETECTED
        assert result.get_edge("P3.2").get_cam("cam3").state == EdgeCamStateEnum.NEVER_DETECTED

        # AND dependent plies are removed from local mould state
        assert mould_state.find_ply(fourth_ply.id) is None
        assert mould_state.find_ply(fifth_ply.id) is None
        assert mould_state.find_ply(sixth_ply.id) is None

    async def test_should_correctly_undo_plies_when_fourth_ply_given(self, mocker):
        # GIVEN
        messaging_wrapper = mocker.patch("app.decision_maker.MessagingWrapper", new_callable=AsyncMock)
        state_plies_mock = StatePliesMock()
        first_ply = state_plies_mock.first_ply_partially_covered
        second_ply = state_plies_mock.second_ply_partially_covered
        third_ply = state_plies_mock.third_ply_fully_covered
        fourth_ply = state_plies_mock.fourth_ply_partially_covered
        fifth_ply = state_plies_mock.fifth_ply_partially_covered
        sixth_ply = state_plies_mock.sixth_ply_placed
        ply_id_undo_to = fourth_ply.id
        state_plies = {first_ply, second_ply, third_ply, fourth_ply, fifth_ply, sixth_ply}
        mould_state = MouldState(state_plies)
        graph_data = {
            "plies": {
                "P1": {"previous_plies": [], "edges": ["P1.1", "P1.2"], "edges_covered": []},
                "P2": {"previous_plies": ["P1"], "edges": ["P2.1", "P2.2"], "edges_covered": ["P1.2"]},
                "P3": {"previous_plies": [], "edges": ["P3.1", "P3.2"], "edges_covered": []},
                "P4": {"previous_plies": ["P2", "P3"], "edges": ["P4.1", "P4.2"], "edges_covered": ["P2.2", "P3.1"]},
                "P5": {"previous_plies": ["P3", "P4"], "edges": ["P5.1", "P5.2"], "edges_covered": ["P4.2", "P3.2"]},
                "P6": {"previous_plies": ["P5"], "edges": ["P6.1", "P6.2"], "edges_covered": ["P5.1"]},
            }
        }
        decision_maker = DecisionMaker(Mock(), messaging_wrapper, Mock(), mould_state)
        decision_maker._sub_graph = Graph(graph_data)
        undo_plies_request = create_undo_plies_to_c2dm_request(ply_id=ply_id_undo_to, mould_id="mould_id")

        # AND more methods patched
        process_mould_state_changes = mocker.patch.object(decision_maker, "_process_mould_state_changes")

        # WHEN decision_maker.handle_undo_plies_to_command is called
        await decision_maker.handle_undo_plies_to_command(undo_plies_request.payload)

        # THEN DecisionMaker._process_mould_state_changes is called
        assert process_mould_state_changes.call_count == 1
        assert process_mould_state_changes.await_count == 1
        call_args = process_mould_state_changes.call_args.args
        assert call_args[0] == {second_ply, third_ply, fourth_ply, fifth_ply, sixth_ply}

        # AND previous ply is unchanged
        assert mould_state.find_ply(first_ply.id) == StatePliesMock().first_ply_partially_covered

        # AND partially covered ply is correctly reset to placed
        result = mould_state.find_ply(second_ply.id)
        assert result is not None
        assert result.state == PlyStateEnum.PLACED
        assert result.previous_state == PlyStateEnum.PLACED
        assert result.updated_by == "command:undo_ply:force"
        assert result.get_edge("P2.1").state == EdgeStateEnum.DETECTED
        assert result.get_edge("P2.2").state == EdgeStateEnum.DETECTED
        assert result.get_edge("P2.1").get_cam("cam1").state == EdgeCamStateEnum.DETECTED
        assert result.get_edge("P2.2").get_cam("cam1").state == EdgeCamStateEnum.DETECTED
        assert result.get_edge("P2.2").get_cam("cam2").state == EdgeCamStateEnum.NEVER_DETECTED

        # AND fully covered ply is correctly reset to placed
        result = mould_state.find_ply(third_ply.id)
        assert result is not None
        assert result.state == PlyStateEnum.PLACED
        assert result.previous_state == PlyStateEnum.COVERED
        assert result.updated_by == "command:undo_ply:force"
        assert result.get_edge("P3.1").state == EdgeStateEnum.DETECTED
        assert result.get_edge("P3.2").state == EdgeStateEnum.DETECTED
        assert result.get_edge("P3.1").get_cam("cam2").state == EdgeCamStateEnum.DETECTED
        assert result.get_edge("P3.2").get_cam("cam2").state == EdgeCamStateEnum.DETECTED
        assert result.get_edge("P3.2").get_cam("cam3").state == EdgeCamStateEnum.NEVER_DETECTED

        # AND ply to undo to is correctly reset to expected
        result = mould_state.find_ply(ply_id_undo_to)
        assert result is not None
        assert result.state == PlyStateEnum.EXPECTED
        assert result.previous_state == PlyStateEnum.PLACED
        assert result.updated_by == "command:undo_ply:force"
        assert result.get_edge("P4.1").state == EdgeStateEnum.MISSING
        assert result.get_edge("P4.2").state == EdgeStateEnum.MISSING
        assert result.get_edge("P4.1").get_cam("cam2").state == EdgeCamStateEnum.NEVER_DETECTED
        assert result.get_edge("P4.2").get_cam("cam2").state == EdgeCamStateEnum.NEVER_DETECTED

        # AND dependent plies are removed from local mould state
        assert mould_state.find_ply(fifth_ply.id) is None
        assert mould_state.find_ply(sixth_ply.id) is None

    async def test_should_correctly_undo_plies_when_fifth_ply_given(self, mocker):
        # GIVEN
        messaging_wrapper = mocker.patch("app.decision_maker.MessagingWrapper", new_callable=AsyncMock)
        state_plies_mock = StatePliesMock()
        first_ply = state_plies_mock.first_ply_partially_covered
        second_ply = state_plies_mock.second_ply_partially_covered
        third_ply = state_plies_mock.third_ply_fully_covered
        fourth_ply = state_plies_mock.fourth_ply_partially_covered
        fifth_ply = state_plies_mock.fifth_ply_partially_covered
        sixth_ply = state_plies_mock.sixth_ply_placed
        ply_id_undo_to = fifth_ply.id
        state_plies = {first_ply, second_ply, third_ply, fourth_ply, fifth_ply, sixth_ply}
        mould_state = MouldState(state_plies)
        graph_data = {
            "plies": {
                "P1": {"previous_plies": [], "edges": ["P1.1", "P1.2"], "edges_covered": []},
                "P2": {"previous_plies": ["P1"], "edges": ["P2.1", "P2.2"], "edges_covered": ["P1.2"]},
                "P3": {"previous_plies": [], "edges": ["P3.1", "P3.2"], "edges_covered": []},
                "P4": {"previous_plies": ["P2", "P3"], "edges": ["P4.1", "P4.2"], "edges_covered": ["P2.2", "P3.1"]},
                "P5": {"previous_plies": ["P3", "P4"], "edges": ["P5.1", "P5.2"], "edges_covered": ["P4.2", "P3.2"]},
                "P6": {"previous_plies": ["P5"], "edges": ["P6.1", "P6.2"], "edges_covered": ["P5.1"]},
            }
        }
        decision_maker = DecisionMaker(Mock(), messaging_wrapper, Mock(), mould_state)
        decision_maker._sub_graph = Graph(graph_data)
        undo_plies_request = create_undo_plies_to_c2dm_request(ply_id=ply_id_undo_to, mould_id="mould_id")

        # AND more methods patched
        process_mould_state_changes = mocker.patch.object(decision_maker, "_process_mould_state_changes")

        # WHEN decision_maker.handle_undo_plies_to_command is called
        await decision_maker.handle_undo_plies_to_command(undo_plies_request.payload)

        # THEN DecisionMaker._process_mould_state_changes is called
        assert process_mould_state_changes.call_count == 1
        assert process_mould_state_changes.await_count == 1
        call_args = process_mould_state_changes.call_args.args
        assert call_args[0] == {third_ply, fourth_ply, fifth_ply, sixth_ply}

        # AND previous ply is unchanged
        assert mould_state.find_ply(first_ply.id) == StatePliesMock().first_ply_partially_covered
        assert mould_state.find_ply(second_ply.id) == StatePliesMock().second_ply_partially_covered

        # AND fully covered ply is correctly reset to partially covered
        result = mould_state.find_ply(third_ply.id)
        assert result is not None
        assert result.state == PlyStateEnum.PLACED
        assert result.previous_state == PlyStateEnum.COVERED
        assert result.updated_by == "command:undo_ply:force"
        assert result.get_edge("P3.1").state == EdgeStateEnum.COVERED
        assert result.get_edge("P3.2").state == EdgeStateEnum.DETECTED
        assert result.get_edge("P3.1").get_cam("cam2").state == EdgeCamStateEnum.DETECTED
        assert result.get_edge("P3.2").get_cam("cam2").state == EdgeCamStateEnum.DETECTED
        assert result.get_edge("P3.2").get_cam("cam3").state == EdgeCamStateEnum.NEVER_DETECTED

        # AND partially covered ply is correctly reset to placed
        result = mould_state.find_ply(fourth_ply.id)
        assert result is not None
        assert result.state == PlyStateEnum.PLACED
        assert result.previous_state == PlyStateEnum.EXPECTED
        assert result.updated_by == "command:undo_ply:force"
        assert result.get_edge("P4.1").state == EdgeStateEnum.DETECTED
        assert result.get_edge("P4.2").state == EdgeStateEnum.DETECTED
        assert result.get_edge("P4.1").get_cam("cam2").state == EdgeCamStateEnum.DETECTED
        assert result.get_edge("P4.2").get_cam("cam2").state == EdgeCamStateEnum.DETECTED

        # AND ply to undo to is correctly reset to expected
        result = mould_state.find_ply(ply_id_undo_to)
        assert result is not None
        assert result.state == PlyStateEnum.EXPECTED
        assert result.previous_state == PlyStateEnum.PLACED
        assert result.updated_by == "command:undo_ply:force"
        assert result.get_edge("P5.1").state == EdgeStateEnum.MISSING
        assert result.get_edge("P5.2").state == EdgeStateEnum.MISSING
        assert result.get_edge("P5.1").get_cam("cam2").state == EdgeCamStateEnum.NEVER_DETECTED
        assert result.get_edge("P5.2").get_cam("cam2").state == EdgeCamStateEnum.NEVER_DETECTED

        # AND dependent ply is removed from local mould state
        assert mould_state.find_ply(sixth_ply.id) is None

    async def test_should_correctly_undo_plies_when_sixth_ply_given(self, mocker):
        # GIVEN
        messaging_wrapper = mocker.patch("app.decision_maker.MessagingWrapper", new_callable=AsyncMock)
        state_plies_mock = StatePliesMock()
        first_ply = state_plies_mock.first_ply_partially_covered
        second_ply = state_plies_mock.second_ply_partially_covered
        third_ply = state_plies_mock.third_ply_fully_covered
        fourth_ply = state_plies_mock.fourth_ply_partially_covered
        fifth_ply = state_plies_mock.fifth_ply_partially_covered
        sixth_ply = state_plies_mock.sixth_ply_placed
        ply_id_undo_to = sixth_ply.id
        state_plies = {first_ply, second_ply, third_ply, fourth_ply, fifth_ply, sixth_ply}
        mould_state = MouldState(state_plies)
        graph_data = {
            "plies": {
                "P1": {"previous_plies": [], "edges": ["P1.1", "P1.2"], "edges_covered": []},
                "P2": {"previous_plies": ["P1"], "edges": ["P2.1", "P2.2"], "edges_covered": ["P1.2"]},
                "P3": {"previous_plies": [], "edges": ["P3.1", "P3.2"], "edges_covered": []},
                "P4": {"previous_plies": ["P2", "P3"], "edges": ["P4.1", "P4.2"], "edges_covered": ["P2.2", "P3.1"]},
                "P5": {"previous_plies": ["P3", "P4"], "edges": ["P5.1", "P5.2"], "edges_covered": ["P4.2", "P3.2"]},
                "P6": {"previous_plies": ["P5"], "edges": ["P6.1", "P6.2"], "edges_covered": ["P5.1"]},
            }
        }
        decision_maker = DecisionMaker(Mock(), messaging_wrapper, Mock(), mould_state)
        decision_maker._sub_graph = Graph(graph_data)
        undo_plies_request = create_undo_plies_to_c2dm_request(ply_id=ply_id_undo_to, mould_id="mould_id")

        # AND more methods patched
        process_mould_state_changes = mocker.patch.object(decision_maker, "_process_mould_state_changes")

        # WHEN decision_maker.handle_undo_plies_to_command is called
        await decision_maker.handle_undo_plies_to_command(undo_plies_request.payload)

        # THEN DecisionMaker._process_mould_state_changes is called
        assert process_mould_state_changes.call_count == 1
        assert process_mould_state_changes.await_count == 1
        call_args = process_mould_state_changes.call_args.args
        assert call_args[0] == {fifth_ply, sixth_ply}

        # AND previous ply is unchanged
        assert mould_state.find_ply(first_ply.id) == StatePliesMock().first_ply_partially_covered
        assert mould_state.find_ply(second_ply.id) == StatePliesMock().second_ply_partially_covered
        assert mould_state.find_ply(third_ply.id) == StatePliesMock().third_ply_fully_covered
        assert mould_state.find_ply(fourth_ply.id) == StatePliesMock().fourth_ply_partially_covered

        # AND partially covered ply is correctly reset to placed
        result = mould_state.find_ply(fifth_ply.id)
        assert result is not None
        assert result.state == PlyStateEnum.PLACED
        assert result.previous_state == PlyStateEnum.EXPECTED
        assert result.updated_by == "command:undo_ply:force"
        assert result.get_edge("P5.1").state == EdgeStateEnum.DETECTED
        assert result.get_edge("P5.2").state == EdgeStateEnum.DETECTED
        assert result.get_edge("P5.1").get_cam("cam2").state == EdgeCamStateEnum.DETECTED
        assert result.get_edge("P5.2").get_cam("cam2").state == EdgeCamStateEnum.DETECTED

        # AND ply to undo to is correctly reset to expected
        result = mould_state.find_ply(ply_id_undo_to)
        assert result is not None
        assert result.state == PlyStateEnum.EXPECTED
        assert result.previous_state == PlyStateEnum.PLACED
        assert result.updated_by == "command:undo_ply:force"
        assert result.get_edge("P6.1").state == EdgeStateEnum.MISSING
        assert result.get_edge("P6.2").state == EdgeStateEnum.MISSING
        assert result.get_edge("P6.1").get_cam("cam2").state == EdgeCamStateEnum.NEVER_DETECTED
        assert result.get_edge("P6.2").get_cam("cam2").state == EdgeCamStateEnum.NEVER_DETECTED


@pytest.mark.asyncio
@patch("app.config.MOULD_ID", "mould_id")
class HandleUndoPliesToCommandWhenGraphPliesWithMultipleMixedDependentsGivenTests:
    async def test_should_correctly_undo_plies_when_first_ply_given(self, mocker):
        # GIVEN
        messaging_wrapper = mocker.patch("app.decision_maker.MessagingWrapper", new_callable=AsyncMock)
        state_plies_mock = StatePliesMock()
        first_ply = state_plies_mock.first_ply_fully_covered
        second_ply = state_plies_mock.second_ply_partially_covered
        third_ply = state_plies_mock.third_ply_fully_covered
        fourth_ply = state_plies_mock.fourth_ply_partially_covered
        fifth_ply = state_plies_mock.fifth_ply_partially_covered
        sixth_ply = state_plies_mock.sixth_ply_placed
        ply_id_undo_to = first_ply.id
        state_plies = {first_ply, second_ply, third_ply, fourth_ply, fifth_ply, sixth_ply}
        mould_state = MouldState(state_plies)
        graph_data = {
            "plies": {
                "P1": {"previous_plies": [], "edges": ["P1.1", "P1.2"], "edges_covered": []},
                "P2": {"previous_plies": ["P1"], "edges": ["P2.1", "P2.2"], "edges_covered": ["P1.1"]},
                "P3": {"previous_plies": ["P1"], "edges": ["P3.1", "P3.2"], "edges_covered": ["P1.2"]},
                "P4": {"previous_plies": ["P2", "P3"], "edges": ["P4.1", "P4.2"], "edges_covered": ["P2.2", "P3.1"]},
                "P5": {"previous_plies": ["P3"], "edges": ["P5.1", "P5.2"], "edges_covered": ["P3.2"]},
                "P6": {"previous_plies": ["P4", "P5"], "edges": ["P6.1", "P6.2"], "edges_covered": ["P4.2", "P5.1"]},
            }
        }
        decision_maker = DecisionMaker(Mock(), messaging_wrapper, Mock(), mould_state)
        decision_maker._sub_graph = Graph(graph_data)
        undo_plies_request = create_undo_plies_to_c2dm_request(ply_id=ply_id_undo_to, mould_id="mould_id")

        # AND more methods patched
        process_mould_state_changes = mocker.patch.object(decision_maker, "_process_mould_state_changes")

        # WHEN decision_maker.handle_undo_plies_to_command is called
        await decision_maker.handle_undo_plies_to_command(undo_plies_request.payload)

        # THEN DecisionMaker._process_mould_state_changes is called
        assert process_mould_state_changes.call_count == 1
        assert process_mould_state_changes.await_count == 1
        call_args = process_mould_state_changes.call_args.args
        assert call_args[0] == {first_ply, second_ply, third_ply, fourth_ply, fifth_ply, sixth_ply}

        # AND ply to undo to is correctly reset to expected
        result = mould_state.find_ply(ply_id_undo_to)
        assert result is not None
        assert result.state == PlyStateEnum.EXPECTED
        assert result.previous_state == PlyStateEnum.PLACED
        assert result.updated_by == "command:undo_ply:force"
        assert result.get_edge("P1.1").state == EdgeStateEnum.MISSING
        assert result.get_edge("P1.2").state == EdgeStateEnum.MISSING
        assert result.get_edge("P1.1").get_cam("cam1").state == EdgeCamStateEnum.NEVER_DETECTED
        assert result.get_edge("P1.2").get_cam("cam1").state == EdgeCamStateEnum.NEVER_DETECTED

        # AND dependent plies are removed from local mould state
        assert mould_state.find_ply(second_ply.id) is None
        assert mould_state.find_ply(third_ply.id) is None
        assert mould_state.find_ply(fourth_ply.id) is None
        assert mould_state.find_ply(fifth_ply.id) is None
        assert mould_state.find_ply(sixth_ply.id) is None

    async def test_should_correctly_undo_plies_when_second_ply_given(self, mocker):
        # GIVEN
        messaging_wrapper = mocker.patch("app.decision_maker.MessagingWrapper", new_callable=AsyncMock)
        state_plies_mock = StatePliesMock()
        first_ply = state_plies_mock.first_ply_fully_covered
        second_ply = state_plies_mock.second_ply_partially_covered
        third_ply = state_plies_mock.third_ply_fully_covered
        fourth_ply = state_plies_mock.fourth_ply_partially_covered
        fifth_ply = state_plies_mock.fifth_ply_partially_covered
        sixth_ply = state_plies_mock.sixth_ply_placed
        ply_id_undo_to = second_ply.id
        state_plies = {first_ply, second_ply, third_ply, fourth_ply, fifth_ply, sixth_ply}
        mould_state = MouldState(state_plies)
        graph_data = {
            "plies": {
                "P1": {"previous_plies": [], "edges": ["P1.1", "P1.2"], "edges_covered": []},
                "P2": {"previous_plies": ["P1"], "edges": ["P2.1", "P2.2"], "edges_covered": ["P1.1"]},
                "P3": {"previous_plies": ["P1"], "edges": ["P3.1", "P3.2"], "edges_covered": ["P1.2"]},
                "P4": {"previous_plies": ["P2", "P3"], "edges": ["P4.1", "P4.2"], "edges_covered": ["P2.2", "P3.1"]},
                "P5": {"previous_plies": ["P3"], "edges": ["P5.1", "P5.2"], "edges_covered": ["P3.2"]},
                "P6": {"previous_plies": ["P4", "P5"], "edges": ["P6.1", "P6.2"], "edges_covered": ["P4.2", "P5.1"]},
            }
        }
        decision_maker = DecisionMaker(Mock(), messaging_wrapper, Mock(), mould_state)
        decision_maker._sub_graph = Graph(graph_data)
        undo_plies_request = create_undo_plies_to_c2dm_request(ply_id=ply_id_undo_to, mould_id="mould_id")

        # AND more methods patched
        process_mould_state_changes = mocker.patch.object(decision_maker, "_process_mould_state_changes")

        # WHEN decision_maker.handle_undo_plies_to_command is called
        await decision_maker.handle_undo_plies_to_command(undo_plies_request.payload)

        # THEN DecisionMaker._process_mould_state_changes is called
        assert process_mould_state_changes.call_count == 1
        assert process_mould_state_changes.await_count == 1
        call_args = process_mould_state_changes.call_args.args
        assert call_args[0] == {first_ply, second_ply, third_ply, fourth_ply, fifth_ply, sixth_ply}

        # AND fully covered ply is correctly reset to partially covered
        result = mould_state.find_ply(first_ply.id)
        assert result is not None
        assert result.state == PlyStateEnum.PLACED
        assert result.previous_state == PlyStateEnum.COVERED
        assert result.updated_by == "command:undo_ply:force"
        assert result.get_edge("P1.1").state == EdgeStateEnum.DETECTED
        assert result.get_edge("P1.2").state == EdgeStateEnum.COVERED
        assert result.get_edge("P1.1").get_cam("cam1").state == EdgeCamStateEnum.DETECTED
        assert result.get_edge("P1.2").get_cam("cam1").state == EdgeCamStateEnum.DETECTED

        # AND ply to undo to is correctly reset to expected
        result = mould_state.find_ply(ply_id_undo_to)
        assert result is not None
        assert result.state == PlyStateEnum.EXPECTED
        assert result.previous_state == PlyStateEnum.PLACED
        assert result.updated_by == "command:undo_ply:force"
        assert result.get_edge("P2.1").state == EdgeStateEnum.MISSING
        assert result.get_edge("P2.2").state == EdgeStateEnum.MISSING
        assert result.get_edge("P2.1").get_cam("cam1").state == EdgeCamStateEnum.NEVER_DETECTED
        assert result.get_edge("P2.2").get_cam("cam1").state == EdgeCamStateEnum.NEVER_DETECTED
        assert result.get_edge("P2.2").get_cam("cam2").state == EdgeCamStateEnum.NEVER_DETECTED

        # AND dependent plies are removed from local mould state
        assert mould_state.find_ply(fourth_ply.id) is None
        assert mould_state.find_ply(sixth_ply.id) is None

        # AND fully covered ply is correctly reset to partially covered
        result = mould_state.find_ply(third_ply.id)
        assert result is not None
        assert result.state == PlyStateEnum.PLACED
        assert result.previous_state == PlyStateEnum.COVERED
        assert result.updated_by == "command:undo_ply:force"
        assert result.get_edge("P3.1").state == EdgeStateEnum.DETECTED
        assert result.get_edge("P3.2").state == EdgeStateEnum.COVERED
        assert result.get_edge("P3.1").get_cam("cam2").state == EdgeCamStateEnum.DETECTED
        assert result.get_edge("P3.2").get_cam("cam2").state == EdgeCamStateEnum.DETECTED
        assert result.get_edge("P3.2").get_cam("cam3").state == EdgeCamStateEnum.NEVER_DETECTED

        # AND partially covered ply is correctly reset to placed
        result = mould_state.find_ply(fifth_ply.id)
        assert result is not None
        assert result.state == PlyStateEnum.PLACED
        assert result.previous_state == PlyStateEnum.EXPECTED
        assert result.updated_by == "command:undo_ply:force"
        assert result.get_edge("P5.1").state == EdgeStateEnum.DETECTED
        assert result.get_edge("P5.2").state == EdgeStateEnum.DETECTED
        assert result.get_edge("P5.1").get_cam("cam2").state == EdgeCamStateEnum.DETECTED
        assert result.get_edge("P5.2").get_cam("cam2").state == EdgeCamStateEnum.DETECTED

    async def test_should_correctly_undo_plies_when_third_ply_given(self, mocker):
        # GIVEN
        messaging_wrapper = mocker.patch("app.decision_maker.MessagingWrapper", new_callable=AsyncMock)
        state_plies_mock = StatePliesMock()
        first_ply = state_plies_mock.first_ply_fully_covered
        second_ply = state_plies_mock.second_ply_partially_covered
        third_ply = state_plies_mock.third_ply_fully_covered
        fourth_ply = state_plies_mock.fourth_ply_partially_covered
        fifth_ply = state_plies_mock.fifth_ply_partially_covered
        sixth_ply = state_plies_mock.sixth_ply_placed
        ply_id_undo_to = third_ply.id
        state_plies = {first_ply, second_ply, third_ply, fourth_ply, fifth_ply, sixth_ply}
        mould_state = MouldState(state_plies)
        graph_data = {
            "plies": {
                "P1": {"previous_plies": [], "edges": ["P1.1", "P1.2"], "edges_covered": []},
                "P2": {"previous_plies": ["P1"], "edges": ["P2.1", "P2.2"], "edges_covered": ["P1.1"]},
                "P3": {"previous_plies": ["P1"], "edges": ["P3.1", "P3.2"], "edges_covered": ["P1.2"]},
                "P4": {"previous_plies": ["P2", "P3"], "edges": ["P4.1", "P4.2"], "edges_covered": ["P2.2", "P3.1"]},
                "P5": {"previous_plies": ["P3"], "edges": ["P5.1", "P5.2"], "edges_covered": ["P3.2"]},
                "P6": {"previous_plies": ["P4", "P5"], "edges": ["P6.1", "P6.2"], "edges_covered": ["P4.2", "P5.1"]},
            }
        }
        decision_maker = DecisionMaker(Mock(), messaging_wrapper, Mock(), mould_state)
        decision_maker._sub_graph = Graph(graph_data)
        undo_plies_request = create_undo_plies_to_c2dm_request(ply_id=ply_id_undo_to, mould_id="mould_id")

        # AND more methods patched
        process_mould_state_changes = mocker.patch.object(decision_maker, "_process_mould_state_changes")

        # WHEN decision_maker.handle_undo_plies_to_command is called
        await decision_maker.handle_undo_plies_to_command(undo_plies_request.payload)

        # THEN DecisionMaker._process_mould_state_changes is called
        assert process_mould_state_changes.call_count == 1
        assert process_mould_state_changes.await_count == 1
        call_args = process_mould_state_changes.call_args.args
        assert call_args[0] == {first_ply, second_ply, third_ply, fourth_ply, fifth_ply, sixth_ply}

        # AND fully covered ply is correctly reset to partially covered
        result = mould_state.find_ply(first_ply.id)
        assert result is not None
        assert result.state == PlyStateEnum.PLACED
        assert result.previous_state == PlyStateEnum.COVERED
        assert result.updated_by == "command:undo_ply:force"
        assert result.get_edge("P1.1").state == EdgeStateEnum.COVERED
        assert result.get_edge("P1.2").state == EdgeStateEnum.DETECTED
        assert result.get_edge("P1.1").get_cam("cam1").state == EdgeCamStateEnum.DETECTED
        assert result.get_edge("P1.2").get_cam("cam1").state == EdgeCamStateEnum.DETECTED

        # AND partially covered ply is correctly reset to placed
        result = mould_state.find_ply(second_ply.id)
        assert result is not None
        assert result.state == PlyStateEnum.PLACED
        assert result.previous_state == PlyStateEnum.PLACED
        assert result.updated_by == "command:undo_ply:force"
        assert result.get_edge("P2.1").state == EdgeStateEnum.DETECTED
        assert result.get_edge("P2.2").state == EdgeStateEnum.DETECTED
        assert result.get_edge("P2.1").get_cam("cam1").state == EdgeCamStateEnum.DETECTED
        assert result.get_edge("P2.2").get_cam("cam1").state == EdgeCamStateEnum.DETECTED
        assert result.get_edge("P2.2").get_cam("cam2").state == EdgeCamStateEnum.NEVER_DETECTED

        # AND ply to undo to is correctly reset to expected
        result = mould_state.find_ply(ply_id_undo_to)
        assert result is not None
        assert result.state == PlyStateEnum.EXPECTED
        assert result.previous_state == PlyStateEnum.PLACED
        assert result.updated_by == "command:undo_ply:force"
        assert result.get_edge("P3.1").state == EdgeStateEnum.MISSING
        assert result.get_edge("P3.2").state == EdgeStateEnum.MISSING
        assert result.get_edge("P3.1").get_cam("cam2").state == EdgeCamStateEnum.NEVER_DETECTED
        assert result.get_edge("P3.2").get_cam("cam2").state == EdgeCamStateEnum.NEVER_DETECTED
        assert result.get_edge("P3.2").get_cam("cam3").state == EdgeCamStateEnum.NEVER_DETECTED

        # AND dependent plies are removed from local mould state
        assert mould_state.find_ply(fourth_ply.id) is None
        assert mould_state.find_ply(fifth_ply.id) is None
        assert mould_state.find_ply(sixth_ply.id) is None

    async def test_should_correctly_undo_plies_when_fourth_ply_given(self, mocker):
        # GIVEN
        messaging_wrapper = mocker.patch("app.decision_maker.MessagingWrapper", new_callable=AsyncMock)
        state_plies_mock = StatePliesMock()
        first_ply = state_plies_mock.first_ply_fully_covered
        second_ply = state_plies_mock.second_ply_partially_covered
        third_ply = state_plies_mock.third_ply_fully_covered
        fourth_ply = state_plies_mock.fourth_ply_partially_covered
        fifth_ply = state_plies_mock.fifth_ply_partially_covered
        sixth_ply = state_plies_mock.sixth_ply_placed
        ply_id_undo_to = fourth_ply.id
        state_plies = {first_ply, second_ply, third_ply, fourth_ply, fifth_ply, sixth_ply}
        mould_state = MouldState(state_plies)
        graph_data = {
            "plies": {
                "P1": {"previous_plies": [], "edges": ["P1.1", "P1.2"], "edges_covered": []},
                "P2": {"previous_plies": ["P1"], "edges": ["P2.1", "P2.2"], "edges_covered": ["P1.1"]},
                "P3": {"previous_plies": ["P1"], "edges": ["P3.1", "P3.2"], "edges_covered": ["P1.2"]},
                "P4": {"previous_plies": ["P2", "P3"], "edges": ["P4.1", "P4.2"], "edges_covered": ["P2.2", "P3.1"]},
                "P5": {"previous_plies": ["P3"], "edges": ["P5.1", "P5.2"], "edges_covered": ["P3.2"]},
                "P6": {"previous_plies": ["P4", "P5"], "edges": ["P6.1", "P6.2"], "edges_covered": ["P4.2", "P5.1"]},
            }
        }
        decision_maker = DecisionMaker(Mock(), messaging_wrapper, Mock(), mould_state)
        decision_maker._sub_graph = Graph(graph_data)
        undo_plies_request = create_undo_plies_to_c2dm_request(ply_id=ply_id_undo_to, mould_id="mould_id")

        # AND more methods patched
        process_mould_state_changes = mocker.patch.object(decision_maker, "_process_mould_state_changes")

        # WHEN decision_maker.handle_undo_plies_to_command is called
        await decision_maker.handle_undo_plies_to_command(undo_plies_request.payload)

        # THEN DecisionMaker._process_mould_state_changes is called
        assert process_mould_state_changes.call_count == 1
        assert process_mould_state_changes.await_count == 1
        call_args = process_mould_state_changes.call_args.args
        assert call_args[0] == {second_ply, third_ply, fourth_ply, fifth_ply, sixth_ply}

        # AND previous ply is unchanged
        assert mould_state.find_ply(first_ply.id) == StatePliesMock().first_ply_fully_covered

        # AND partially covered ply is correctly reset to placed
        result = mould_state.find_ply(second_ply.id)
        assert result is not None
        assert result.state == PlyStateEnum.PLACED
        assert result.previous_state == PlyStateEnum.PLACED
        assert result.updated_by == "command:undo_ply:force"
        assert result.get_edge("P2.1").state == EdgeStateEnum.DETECTED
        assert result.get_edge("P2.2").state == EdgeStateEnum.DETECTED
        assert result.get_edge("P2.1").get_cam("cam1").state == EdgeCamStateEnum.DETECTED
        assert result.get_edge("P2.2").get_cam("cam1").state == EdgeCamStateEnum.DETECTED
        assert result.get_edge("P2.2").get_cam("cam2").state == EdgeCamStateEnum.NEVER_DETECTED

        # AND fully covered ply is correctly reset to partially covered
        result = mould_state.find_ply(third_ply.id)
        assert result is not None
        assert result.state == PlyStateEnum.PLACED
        assert result.previous_state == PlyStateEnum.COVERED
        assert result.updated_by == "command:undo_ply:force"
        assert result.get_edge("P3.1").state == EdgeStateEnum.DETECTED
        assert result.get_edge("P3.2").state == EdgeStateEnum.COVERED
        assert result.get_edge("P3.1").get_cam("cam2").state == EdgeCamStateEnum.DETECTED
        assert result.get_edge("P3.2").get_cam("cam2").state == EdgeCamStateEnum.DETECTED
        assert result.get_edge("P3.2").get_cam("cam3").state == EdgeCamStateEnum.NEVER_DETECTED

        # AND ply to undo to is correctly reset to expected
        result = mould_state.find_ply(ply_id_undo_to)
        assert result is not None
        assert result.state == PlyStateEnum.EXPECTED
        assert result.previous_state == PlyStateEnum.PLACED
        assert result.updated_by == "command:undo_ply:force"
        assert result.get_edge("P4.1").state == EdgeStateEnum.MISSING
        assert result.get_edge("P4.2").state == EdgeStateEnum.MISSING
        assert result.get_edge("P4.1").get_cam("cam2").state == EdgeCamStateEnum.NEVER_DETECTED
        assert result.get_edge("P4.2").get_cam("cam2").state == EdgeCamStateEnum.NEVER_DETECTED

        # AND partially covered ply is correctly reset to placed
        result = mould_state.find_ply(fifth_ply.id)
        assert result is not None
        assert result.state == PlyStateEnum.PLACED
        assert result.previous_state == PlyStateEnum.EXPECTED
        assert result.updated_by == "command:undo_ply:force"
        assert result.get_edge("P5.1").state == EdgeStateEnum.DETECTED
        assert result.get_edge("P5.2").state == EdgeStateEnum.DETECTED
        assert result.get_edge("P5.1").get_cam("cam2").state == EdgeCamStateEnum.DETECTED
        assert result.get_edge("P5.2").get_cam("cam2").state == EdgeCamStateEnum.DETECTED

        # AND dependent plies are removed from local mould state
        assert mould_state.find_ply(sixth_ply.id) is None

    async def test_should_correctly_undo_plies_when_fifth_ply_given(self, mocker):
        # GIVEN
        messaging_wrapper = mocker.patch("app.decision_maker.MessagingWrapper", new_callable=AsyncMock)
        state_plies_mock = StatePliesMock()
        first_ply = state_plies_mock.first_ply_fully_covered
        second_ply = state_plies_mock.second_ply_partially_covered
        third_ply = state_plies_mock.third_ply_fully_covered
        fourth_ply = state_plies_mock.fourth_ply_partially_covered
        fifth_ply = state_plies_mock.fifth_ply_partially_covered
        sixth_ply = state_plies_mock.sixth_ply_placed
        ply_id_undo_to = fifth_ply.id
        state_plies = {first_ply, second_ply, third_ply, fourth_ply, fifth_ply, sixth_ply}
        mould_state = MouldState(state_plies)
        graph_data = {
            "plies": {
                "P1": {"previous_plies": [], "edges": ["P1.1", "P1.2"], "edges_covered": []},
                "P2": {"previous_plies": ["P1"], "edges": ["P2.1", "P2.2"], "edges_covered": ["P1.1"]},
                "P3": {"previous_plies": ["P1"], "edges": ["P3.1", "P3.2"], "edges_covered": ["P1.2"]},
                "P4": {"previous_plies": ["P2", "P3"], "edges": ["P4.1", "P4.2"], "edges_covered": ["P2.2", "P3.1"]},
                "P5": {"previous_plies": ["P3"], "edges": ["P5.1", "P5.2"], "edges_covered": ["P3.2"]},
                "P6": {"previous_plies": ["P4", "P5"], "edges": ["P6.1", "P6.2"], "edges_covered": ["P4.2", "P5.1"]},
            }
        }
        decision_maker = DecisionMaker(Mock(), messaging_wrapper, Mock(), mould_state)
        decision_maker._sub_graph = Graph(graph_data)
        undo_plies_request = create_undo_plies_to_c2dm_request(ply_id=ply_id_undo_to, mould_id="mould_id")

        # AND more methods patched
        process_mould_state_changes = mocker.patch.object(decision_maker, "_process_mould_state_changes")

        # WHEN decision_maker.handle_undo_plies_to_command is called
        await decision_maker.handle_undo_plies_to_command(undo_plies_request.payload)

        # THEN DecisionMaker._process_mould_state_changes is called
        assert process_mould_state_changes.call_count == 1
        assert process_mould_state_changes.await_count == 1
        call_args = process_mould_state_changes.call_args.args
        assert call_args[0] == {third_ply, fourth_ply, fifth_ply, sixth_ply}

        # AND previous ply is unchanged
        assert mould_state.find_ply(first_ply.id) == StatePliesMock().first_ply_fully_covered
        assert mould_state.find_ply(second_ply.id) == StatePliesMock().second_ply_partially_covered

        # AND fully covered ply is correctly reset to partially covered
        result = mould_state.find_ply(third_ply.id)
        assert result is not None
        assert result.state == PlyStateEnum.PLACED
        assert result.previous_state == PlyStateEnum.COVERED
        assert result.updated_by == "command:undo_ply:force"
        assert result.get_edge("P3.1").state == EdgeStateEnum.COVERED
        assert result.get_edge("P3.2").state == EdgeStateEnum.DETECTED
        assert result.get_edge("P3.1").get_cam("cam2").state == EdgeCamStateEnum.DETECTED
        assert result.get_edge("P3.2").get_cam("cam2").state == EdgeCamStateEnum.DETECTED
        assert result.get_edge("P3.2").get_cam("cam3").state == EdgeCamStateEnum.NEVER_DETECTED

        # AND partially covered ply is correctly reset to placed
        result = mould_state.find_ply(fourth_ply.id)
        assert result is not None
        assert result.state == PlyStateEnum.PLACED
        assert result.previous_state == PlyStateEnum.EXPECTED
        assert result.updated_by == "command:undo_ply:force"
        assert result.get_edge("P4.1").state == EdgeStateEnum.DETECTED
        assert result.get_edge("P4.2").state == EdgeStateEnum.DETECTED
        assert result.get_edge("P4.1").get_cam("cam2").state == EdgeCamStateEnum.DETECTED
        assert result.get_edge("P4.2").get_cam("cam2").state == EdgeCamStateEnum.DETECTED

        # AND ply to undo to is correctly reset to expected
        result = mould_state.find_ply(ply_id_undo_to)
        assert result is not None
        assert result.state == PlyStateEnum.EXPECTED
        assert result.previous_state == PlyStateEnum.PLACED
        assert result.updated_by == "command:undo_ply:force"
        assert result.get_edge("P5.1").state == EdgeStateEnum.MISSING
        assert result.get_edge("P5.2").state == EdgeStateEnum.MISSING
        assert result.get_edge("P5.1").get_cam("cam2").state == EdgeCamStateEnum.NEVER_DETECTED
        assert result.get_edge("P5.2").get_cam("cam2").state == EdgeCamStateEnum.NEVER_DETECTED

        # AND dependent plies are removed from local mould state
        assert mould_state.find_ply(sixth_ply.id) is None

    async def test_should_correctly_undo_plies_when_sixth_ply_given(self, mocker):
        # GIVEN
        messaging_wrapper = mocker.patch("app.decision_maker.MessagingWrapper", new_callable=AsyncMock)
        state_plies_mock = StatePliesMock()
        first_ply = state_plies_mock.first_ply_fully_covered
        second_ply = state_plies_mock.second_ply_partially_covered
        third_ply = state_plies_mock.third_ply_fully_covered
        fourth_ply = state_plies_mock.fourth_ply_partially_covered
        fifth_ply = state_plies_mock.fifth_ply_partially_covered
        sixth_ply = state_plies_mock.sixth_ply_placed
        ply_id_undo_to = sixth_ply.id
        state_plies = {first_ply, second_ply, third_ply, fourth_ply, fifth_ply, sixth_ply}
        mould_state = MouldState(state_plies)
        graph_data = {
            "plies": {
                "P1": {"previous_plies": [], "edges": ["P1.1", "P1.2"], "edges_covered": []},
                "P2": {"previous_plies": ["P1"], "edges": ["P2.1", "P2.2"], "edges_covered": ["P1.1"]},
                "P3": {"previous_plies": ["P1"], "edges": ["P3.1", "P3.2"], "edges_covered": ["P1.2"]},
                "P4": {"previous_plies": ["P2", "P3"], "edges": ["P4.1", "P4.2"], "edges_covered": ["P2.2", "P3.1"]},
                "P5": {"previous_plies": ["P3"], "edges": ["P5.1", "P5.2"], "edges_covered": ["P3.2"]},
                "P6": {"previous_plies": ["P4", "P5"], "edges": ["P6.1", "P6.2"], "edges_covered": ["P4.2", "P5.1"]},
            }
        }
        decision_maker = DecisionMaker(Mock(), messaging_wrapper, Mock(), mould_state)
        decision_maker._sub_graph = Graph(graph_data)
        undo_plies_request = create_undo_plies_to_c2dm_request(ply_id=ply_id_undo_to, mould_id="mould_id")

        # AND more methods patched
        process_mould_state_changes = mocker.patch.object(decision_maker, "_process_mould_state_changes")

        # WHEN decision_maker.handle_undo_plies_to_command is called
        await decision_maker.handle_undo_plies_to_command(undo_plies_request.payload)

        # THEN DecisionMaker._process_mould_state_changes is called
        assert process_mould_state_changes.call_count == 1
        assert process_mould_state_changes.await_count == 1
        call_args = process_mould_state_changes.call_args.args
        assert call_args[0] == {fourth_ply, fifth_ply, sixth_ply}

        # AND previous ply is unchanged
        assert mould_state.find_ply(first_ply.id) == StatePliesMock().first_ply_fully_covered
        assert mould_state.find_ply(second_ply.id) == StatePliesMock().second_ply_partially_covered
        assert mould_state.find_ply(third_ply.id) == StatePliesMock().third_ply_fully_covered

        # AND partially covered ply is correctly reset to placed
        result = mould_state.find_ply(fourth_ply.id)
        assert result is not None
        assert result.state == PlyStateEnum.PLACED
        assert result.previous_state == PlyStateEnum.EXPECTED
        assert result.updated_by == "command:undo_ply:force"
        assert result.get_edge("P4.1").state == EdgeStateEnum.DETECTED
        assert result.get_edge("P4.2").state == EdgeStateEnum.DETECTED
        assert result.get_edge("P4.1").get_cam("cam2").state == EdgeCamStateEnum.DETECTED
        assert result.get_edge("P4.2").get_cam("cam2").state == EdgeCamStateEnum.DETECTED

        # AND partially covered ply is correctly reset to placed
        result = mould_state.find_ply(fifth_ply.id)
        assert result is not None
        assert result.state == PlyStateEnum.PLACED
        assert result.previous_state == PlyStateEnum.EXPECTED
        assert result.updated_by == "command:undo_ply:force"
        assert result.get_edge("P5.1").state == EdgeStateEnum.DETECTED
        assert result.get_edge("P5.2").state == EdgeStateEnum.DETECTED
        assert result.get_edge("P5.1").get_cam("cam2").state == EdgeCamStateEnum.DETECTED
        assert result.get_edge("P5.2").get_cam("cam2").state == EdgeCamStateEnum.DETECTED

        # AND ply to undo to is correctly reset to expected
        result = mould_state.find_ply(ply_id_undo_to)
        assert result is not None
        assert result.state == PlyStateEnum.EXPECTED
        assert result.previous_state == PlyStateEnum.PLACED
        assert result.updated_by == "command:undo_ply:force"
        assert result.get_edge("P6.1").state == EdgeStateEnum.MISSING
        assert result.get_edge("P6.2").state == EdgeStateEnum.MISSING
        assert result.get_edge("P6.1").get_cam("cam2").state == EdgeCamStateEnum.NEVER_DETECTED
        assert result.get_edge("P6.2").get_cam("cam2").state == EdgeCamStateEnum.NEVER_DETECTED


@pytest.mark.asyncio
@patch("app.config.MOULD_ID", "mould_id")
class HandleUndoPliesToDryRunCommandTests:
    @pytest.mark.parametrize(
        "ply_state", [PlyStateEnum.PLACED, PlyStateEnum.MISSING, PlyStateEnum.FORCED, PlyStateEnum.COVERED])
    async def test_should_not_abort_command_handling_when_ply_with_valid_state_given(self, mocker, ply_state):
        # GIVEN
        messaging_wrapper = mocker.patch("app.decision_maker.MessagingWrapper", new_callable=AsyncMock)
        ply_to_undo_id = "ply_to_undo_id"
        state_plies = {PlyState(ply_to_undo_id, state=ply_state)}
        mould_state = MouldState(copy.deepcopy(state_plies))
        decision_maker = DecisionMaker(Mock(), messaging_wrapper, Mock(), mould_state)
        undo_plies_request = create_undo_plies_to_dry_run_c2dm_request(ply_id=ply_to_undo_id, mould_id="mould_id")

        # AND more methods patched
        mocker.patch.object(decision_maker, "_sub_graph", return_value=Graph({"plies": {}}))

        # WHEN decision_maker.handle_undo_plies_to_dry_run_command is called
        result = await decision_maker.handle_undo_plies_to_dry_run_command(undo_plies_request.payload)

        # THEN result is correct, exception not raised, means execution of the process is not aborted
        assert result == ["ply_to_undo_id"]

    @pytest.mark.parametrize("ply_state", [PlyStateEnum.EXPECTED])
    async def test_should_raise_exception_and_abort_command_handling_when_ply_with_invalid_state_given(
            self, mocker, ply_state):
        # GIVEN
        messaging_wrapper = mocker.patch("app.decision_maker.MessagingWrapper", new_callable=AsyncMock)
        ply_to_undo_id = "ply_to_undo_id"
        state_plies = {PlyState(ply_to_undo_id, state=ply_state)}
        mould_state = MouldState(copy.deepcopy(state_plies))
        decision_maker = DecisionMaker(Mock(), messaging_wrapper, Mock(), mould_state)
        undo_plies_request = create_undo_plies_to_dry_run_c2dm_request(ply_id=ply_to_undo_id, mould_id="mould_id")

        # WHEN decision_maker.handle_undo_plies_to_dry_run_command is called, assert that an exception is raised
        with pytest.raises(Exception) as exc_info:
            await decision_maker.handle_undo_plies_to_dry_run_command(undo_plies_request.payload)

        # THEN an exception of correct type is raised
        assert exc_info.type is ValueError
        error_message = f"Given ply {ply_to_undo_id} is not valid ply to undo_plies_to_dry_run, " \
                        f"it must be not {ply_state.name} ply."
        assert exc_info.value.args[0] == error_message

    async def test_should_raise_exception_and_abort_command_handling_when_non_existing_ply_id_given(self, mocker):
        # GIVEN
        messaging_wrapper = mocker.patch("app.decision_maker.MessagingWrapper", new_callable=AsyncMock)
        ply_to_undo_id = "NON_EXISTING_PLY_ID"
        state_plies = {PlyState("P1", state=PlyStateEnum.EXPECTED)}
        mould_state = MouldState(copy.deepcopy(state_plies))
        decision_maker = DecisionMaker(Mock(), messaging_wrapper, Mock(), mould_state)
        undo_plies_request = create_undo_plies_to_dry_run_c2dm_request(ply_id=ply_to_undo_id, mould_id="mould_id")

        # WHEN decision_maker.handle_undo_plies_to_dry_run_command is called, assert that an exception is raised
        with pytest.raises(Exception) as exc_info:
            await decision_maker.handle_undo_plies_to_dry_run_command(undo_plies_request.payload)

        # THEN an exception of correct type is raised
        assert exc_info.type is ValueError
        error_message = f"Failed to get ply in mould state by given ply_id: {ply_to_undo_id}"
        assert exc_info.value.args[0] == error_message

    async def test_should_return_correct_plies_and_in_correct_order_when_initial_ply_given(self, mocker):
        # GIVEN
        messaging_wrapper = mocker.patch("app.decision_maker.MessagingWrapper", new_callable=AsyncMock)
        state_plies_mock = StatePliesMock()
        first_ply_undo_to = state_plies_mock.first_ply_partially_covered
        second_ply = state_plies_mock.second_ply_partially_covered
        third_ply = state_plies_mock.third_ply_partially_covered
        fourth_ply = state_plies_mock.fourth_ply_partially_covered
        fifth_ply = state_plies_mock.fifth_ply_placed
        state_plies = {first_ply_undo_to, second_ply, third_ply, fourth_ply, fifth_ply}
        mould_state = MouldState(state_plies)
        graph_data = {
            "plies": {
                "P1": {"previous_plies": [], "edges": ["P1.1", "P1.2"]},
                "P2": {"previous_plies": ["P1"], "edges": ["P2.1", "P2.2"]},
                "P3": {"previous_plies": ["P2"], "edges": ["P3.1", "P3.2"]},
                "P4": {"previous_plies": ["P3"], "edges": ["P4.1", "P4.2"]},
                "P5": {"previous_plies": ["P4"], "edges": ["P5.1", "P5.2"]},
            }
        }
        decision_maker = DecisionMaker(Mock(), messaging_wrapper, Mock(), mould_state)
        decision_maker._sub_graph = Graph(graph_data)
        undo_plies_request = create_undo_plies_to_dry_run_c2dm_request(ply_id=first_ply_undo_to.id, mould_id="mould_id")

        # WHEN decision_maker.handle_undo_plies_to_dry_run_command is called
        result = await decision_maker.handle_undo_plies_to_dry_run_command(undo_plies_request.payload)

        # THEN result is correct
        assert result == ["P1", "P2", "P3", "P4", "P5"]

    async def test_should_return_correct_plies_and_in_correct_order_when_middle_ply_given(self, mocker):
        # GIVEN
        messaging_wrapper = mocker.patch("app.decision_maker.MessagingWrapper", new_callable=AsyncMock)
        state_plies_mock = StatePliesMock()
        first_ply = state_plies_mock.first_ply_partially_covered
        second_ply = state_plies_mock.second_ply_partially_covered
        third_ply_undo_to = state_plies_mock.third_ply_partially_covered
        fourth_ply = state_plies_mock.fourth_ply_partially_covered
        fifth_ply = state_plies_mock.fifth_ply_placed
        state_plies = {first_ply, second_ply, third_ply_undo_to, fourth_ply, fifth_ply}
        mould_state = MouldState(state_plies)
        graph_data = {
            "plies": {
                "P1": {"previous_plies": [], "edges": ["P1.1", "P1.2"]},
                "P2": {"previous_plies": ["P1"], "edges": ["P2.1", "P2.2"]},
                "P3": {"previous_plies": ["P2"], "edges": ["P3.1", "P3.2"]},
                "P4": {"previous_plies": ["P3"], "edges": ["P4.1", "P4.2"]},
                "P5": {"previous_plies": ["P4"], "edges": ["P5.1", "P5.2"]},
            }
        }
        decision_maker = DecisionMaker(Mock(), messaging_wrapper, Mock(), mould_state)
        decision_maker._sub_graph = Graph(graph_data)
        undo_plies_request = create_undo_plies_to_dry_run_c2dm_request(ply_id=third_ply_undo_to.id, mould_id="mould_id")

        # WHEN decision_maker.handle_undo_plies_to_dry_run_command is called
        result = await decision_maker.handle_undo_plies_to_dry_run_command(undo_plies_request.payload)

        # THEN result is correct
        assert result == ["P3", "P4", "P5"]

    async def test_should_return_only_last_ply_when_last_ply_given(self, mocker):
        # GIVEN
        messaging_wrapper = mocker.patch("app.decision_maker.MessagingWrapper", new_callable=AsyncMock)
        state_plies_mock = StatePliesMock()
        first_ply = state_plies_mock.first_ply_partially_covered
        second_ply = state_plies_mock.second_ply_partially_covered
        third_ply = state_plies_mock.third_ply_partially_covered
        fourth_ply = state_plies_mock.fourth_ply_partially_covered
        fifth_ply_undo_to = state_plies_mock.fifth_ply_placed
        state_plies = {first_ply, second_ply, third_ply, fourth_ply, fifth_ply_undo_to}
        mould_state = MouldState(state_plies)
        graph_data = {
            "plies": {
                "P1": {"previous_plies": [], "edges": ["P1.1", "P1.2"]},
                "P2": {"previous_plies": ["P1"], "edges": ["P2.1", "P2.2"]},
                "P3": {"previous_plies": ["P2"], "edges": ["P3.1", "P3.2"]},
                "P4": {"previous_plies": ["P3"], "edges": ["P4.1", "P4.2"]},
                "P5": {"previous_plies": ["P4"], "edges": ["P5.1", "P5.2"]},
            }
        }
        decision_maker = DecisionMaker(Mock(), messaging_wrapper, Mock(), mould_state)
        decision_maker._sub_graph = Graph(graph_data)
        undo_plies_request = create_undo_plies_to_dry_run_c2dm_request(ply_id=fifth_ply_undo_to.id, mould_id="mould_id")

        # WHEN decision_maker.handle_undo_plies_to_dry_run_command is called
        result = await decision_maker.handle_undo_plies_to_dry_run_command(undo_plies_request.payload)

        # THEN result is correct
        assert result == ["P5"]

    async def test_should_return_only_initial_ply_when_only_initial_ply_placed(self, mocker):
        # GIVEN
        messaging_wrapper = mocker.patch("app.decision_maker.MessagingWrapper", new_callable=AsyncMock)
        state_plies_mock = StatePliesMock()
        first_ply_undo_to = state_plies_mock.first_ply_placed
        second_ply = state_plies_mock.second_ply_expected
        state_plies = {first_ply_undo_to, second_ply}
        mould_state = MouldState(state_plies)
        graph_data = {
            "plies": {
                "P1": {"previous_plies": [], "edges": ["P1.1", "P1.2"]},
                "P2": {"previous_plies": ["P1"], "edges": ["P2.1", "P2.2"]},
                "P3": {"previous_plies": ["P2"], "edges": ["P3.1", "P3.2"]},
                "P4": {"previous_plies": ["P3"], "edges": ["P4.1", "P4.2"]},
                "P5": {"previous_plies": ["P4"], "edges": ["P5.1", "P5.2"]},
            }
        }
        decision_maker = DecisionMaker(Mock(), messaging_wrapper, Mock(), mould_state)
        decision_maker._sub_graph = Graph(graph_data)
        undo_plies_request = create_undo_plies_to_dry_run_c2dm_request(ply_id=first_ply_undo_to.id, mould_id="mould_id")

        # WHEN decision_maker.handle_undo_plies_to_dry_run_command is called
        result = await decision_maker.handle_undo_plies_to_dry_run_command(undo_plies_request.payload)

        # THEN result is correct
        assert result == ["P1"]

    @pytest.mark.parametrize(
        "third_ply_undo_to_state, fourth_ply_state",
        [
            (PlyStateEnum.PLACED, PlyStateEnum.PLACED),
            (PlyStateEnum.PLACED, PlyStateEnum.FORCED),
            (PlyStateEnum.PLACED, PlyStateEnum.MISSING),
            (PlyStateEnum.PLACED, PlyStateEnum.COVERED),
            (PlyStateEnum.FORCED, PlyStateEnum.FORCED),
            (PlyStateEnum.FORCED, PlyStateEnum.PLACED),
            (PlyStateEnum.FORCED, PlyStateEnum.MISSING),
            (PlyStateEnum.FORCED, PlyStateEnum.COVERED),
            (PlyStateEnum.MISSING, PlyStateEnum.MISSING),
            (PlyStateEnum.MISSING, PlyStateEnum.PLACED),
            (PlyStateEnum.MISSING, PlyStateEnum.FORCED),
            (PlyStateEnum.MISSING, PlyStateEnum.COVERED),
            (PlyStateEnum.COVERED, PlyStateEnum.COVERED),
            (PlyStateEnum.COVERED, PlyStateEnum.PLACED),
            (PlyStateEnum.COVERED, PlyStateEnum.FORCED),
            (PlyStateEnum.COVERED, PlyStateEnum.MISSING),
        ]
    )
    async def test_should_return_only_plies_of_placed_type(self, mocker, third_ply_undo_to_state, fourth_ply_state):
        # GIVEN
        messaging_wrapper = mocker.patch("app.decision_maker.MessagingWrapper", new_callable=AsyncMock)
        state_plies_mock = StatePliesMock()
        first_ply = state_plies_mock.first_ply_partially_covered
        second_ply = state_plies_mock.second_ply_partially_covered
        third_ply_undo_to = PlyState("P3", state=third_ply_undo_to_state)
        fourth_ply = PlyState("P4", state=fourth_ply_state)
        fifth_ply = state_plies_mock.fifth_ply_expected
        state_plies = {first_ply, second_ply, third_ply_undo_to, fourth_ply, fifth_ply}
        mould_state = MouldState(state_plies)
        graph_data = {
            "plies": {
                "P1": {"previous_plies": [], "edges": ["P1.1", "P1.2"]},
                "P2": {"previous_plies": ["P1"], "edges": ["P2.1", "P2.2"]},
                "P3": {"previous_plies": ["P2"], "edges": ["P3.1", "P3.2"]},
                "P4": {"previous_plies": ["P3"], "edges": ["P4.1", "P4.2"]},
                "P5": {"previous_plies": ["P4"], "edges": ["P5.1", "P5.2"]},
            }
        }
        decision_maker = DecisionMaker(Mock(), messaging_wrapper, Mock(), mould_state)
        decision_maker._sub_graph = Graph(graph_data)
        undo_plies_request = create_undo_plies_to_dry_run_c2dm_request(ply_id=third_ply_undo_to.id, mould_id="mould_id")

        # WHEN decision_maker.handle_undo_plies_to_dry_run_command is called
        result = await decision_maker.handle_undo_plies_to_dry_run_command(undo_plies_request.payload)

        # THEN result is correct
        assert result == ["P3", "P4"]

    async def test_should_return_some_plies_when_initial_ply_and_graph_with_multiple_independent_plies_given(
            self, mocker):
        # GIVEN
        messaging_wrapper = mocker.patch("app.decision_maker.MessagingWrapper", new_callable=AsyncMock)
        state_plies_mock = StatePliesMock()
        first_ply_undo_to = state_plies_mock.first_ply_partially_covered
        second_ply = state_plies_mock.second_ply_partially_covered
        third_ply = state_plies_mock.third_ply_placed
        fourth_ply = state_plies_mock.fourth_ply_partially_covered
        fifth_ply = state_plies_mock.fifth_ply_placed
        state_plies = {first_ply_undo_to, second_ply, third_ply, fourth_ply, fifth_ply}
        mould_state = MouldState(state_plies)
        graph_data = {
            "plies": {
                "P1": {"previous_plies": [], "edges": ["P1.1", "P1.2"]},
                "P2": {"previous_plies": ["P1"], "edges": ["P2.1", "P2.2"]},
                "P3": {"previous_plies": ["P2"], "edges": ["P3.1", "P3.2"]},
                "P4": {"previous_plies": [], "edges": ["P4.1", "P4.2"]},
                "P5": {"previous_plies": ["P4"], "edges": ["P5.1", "P5.2"]},
            }
        }
        decision_maker = DecisionMaker(Mock(), messaging_wrapper, Mock(), mould_state)
        decision_maker._sub_graph = Graph(graph_data)
        undo_plies_request = create_undo_plies_to_dry_run_c2dm_request(ply_id=first_ply_undo_to.id, mould_id="mould_id")

        # WHEN decision_maker.handle_undo_plies_to_dry_run_command is called
        result = await decision_maker.handle_undo_plies_to_dry_run_command(undo_plies_request.payload)

        # THEN result is correct
        assert result == ["P1", "P2", "P3"]

    async def test_should_return_only_middle_ply_when_middle_ply_and_graph_with_multiple_independent_plies_given(self,
                                                                                                                 mocker):
        # GIVEN
        messaging_wrapper = mocker.patch("app.decision_maker.MessagingWrapper", new_callable=AsyncMock)
        state_plies_mock = StatePliesMock()
        first_ply = state_plies_mock.first_ply_partially_covered
        second_ply = state_plies_mock.second_ply_partially_covered
        third_ply_undo_to = state_plies_mock.third_ply_placed
        fourth_ply = state_plies_mock.fourth_ply_partially_covered
        fifth_ply = state_plies_mock.fifth_ply_placed
        state_plies = {first_ply, second_ply, third_ply_undo_to, fourth_ply, fifth_ply}
        mould_state = MouldState(state_plies)
        graph_data = {
            "plies": {
                "P1": {"previous_plies": [], "edges": ["P1.1", "P1.2"]},
                "P2": {"previous_plies": ["P1"], "edges": ["P2.1", "P2.2"]},
                "P3": {"previous_plies": ["P2"], "edges": ["P3.1", "P3.2"]},
                "P4": {"previous_plies": [], "edges": ["P4.1", "P4.2"]},
                "P5": {"previous_plies": ["P4"], "edges": ["P5.1", "P5.2"]},
            }
        }
        decision_maker = DecisionMaker(Mock(), messaging_wrapper, Mock(), mould_state)
        decision_maker._sub_graph = Graph(graph_data)
        undo_plies_request = create_undo_plies_to_dry_run_c2dm_request(ply_id=third_ply_undo_to.id, mould_id="mould_id")

        # WHEN decision_maker.handle_undo_plies_to_dry_run_command is called
        result = await decision_maker.handle_undo_plies_to_dry_run_command(undo_plies_request.payload)

        # THEN result is correct
        assert result == ["P3"]

    async def test_should_return_correct_plies_when_initial_ply_and_graph_plies_with_multiple_dependents_given(
            self, mocker):
        # GIVEN
        messaging_wrapper = mocker.patch("app.decision_maker.MessagingWrapper", new_callable=AsyncMock)
        state_plies_mock = StatePliesMock()
        first_ply_undo_to = state_plies_mock.first_ply_partially_covered
        second_ply = state_plies_mock.second_ply_partially_covered
        third_ply = state_plies_mock.third_ply_placed
        fourth_ply = state_plies_mock.fourth_ply_partially_covered
        fifth_ply = state_plies_mock.fifth_ply_placed
        state_plies = {first_ply_undo_to, second_ply, third_ply, fourth_ply, fifth_ply}
        mould_state = MouldState(state_plies)
        graph_data = {
            "plies": {
                "P1": {"previous_plies": [], "edges": ["P1.1", "P1.2"]},
                "P2": {"previous_plies": ["P1"], "edges": ["P2.1", "P2.2"]},
                "P3": {"previous_plies": ["P2", "P4", "P5"], "edges": ["P3.1", "P3.2"]},
                "P4": {"previous_plies": [], "edges": ["P4.1", "P4.2"]},
                "P5": {"previous_plies": ["P4"], "edges": ["P5.1", "P5.2"]},
            }
        }
        decision_maker = DecisionMaker(Mock(), messaging_wrapper, Mock(), mould_state)
        decision_maker._sub_graph = Graph(graph_data)
        undo_plies_request = create_undo_plies_to_dry_run_c2dm_request(ply_id=first_ply_undo_to.id, mould_id="mould_id")

        # WHEN decision_maker.handle_undo_plies_to_dry_run_command is called
        result = await decision_maker.handle_undo_plies_to_dry_run_command(undo_plies_request.payload)

        # THEN result is correct
        assert result == ["P1", "P2", "P3"]

    @pytest.mark.parametrize(
        "ply_id_undo_to, expected_result",
        [
            ("P1", ["P1", "P2", "P4", "P5", "P6"]),
            ("P2", ["P2", "P4", "P5", "P6"]),
            ("P3", ["P3", "P4", "P5", "P6"]),
            ("P4", ["P4", "P5", "P6"]),
            ("P5", ["P5", "P6"]),
            ("P6", ["P6"]),
        ]
    )
    async def test_should_return_correct_result_when_graph_with_multiple_independent_plies_given(
            self, mocker, ply_id_undo_to, expected_result):
        # GIVEN
        messaging_wrapper = mocker.patch("app.decision_maker.MessagingWrapper", new_callable=AsyncMock)
        state_plies_mock = StatePliesMock()
        first_ply = state_plies_mock.first_ply_partially_covered
        second_ply = state_plies_mock.second_ply_partially_covered
        third_ply = state_plies_mock.third_ply_fully_covered
        fourth_ply = state_plies_mock.fourth_ply_partially_covered
        fifth_ply = state_plies_mock.fifth_ply_partially_covered
        sixth_ply = state_plies_mock.sixth_ply_placed
        state_plies = {first_ply, second_ply, third_ply, fourth_ply, fifth_ply, sixth_ply}
        mould_state = MouldState(state_plies)
        graph_data = {
            "plies": {
                "P1": {"previous_plies": [], "edges": ["P1.1", "P1.2"]},
                "P2": {"previous_plies": ["P1"], "edges": ["P2.1", "P2.2"]},
                "P3": {"previous_plies": [], "edges": ["P3.1", "P3.2"]},
                "P4": {"previous_plies": ["P2", "P3"], "edges": ["P4.1", "P4.2"]},
                "P5": {"previous_plies": ["P3", "P4"], "edges": ["P5.1", "P5.2"]},
                "P6": {"previous_plies": ["P5"], "edges": ["P6.1", "P6.2"]},
            }
        }
        decision_maker = DecisionMaker(Mock(), messaging_wrapper, Mock(), mould_state)
        decision_maker._sub_graph = Graph(graph_data)
        undo_plies_request = create_undo_plies_to_dry_run_c2dm_request(ply_id=ply_id_undo_to, mould_id="mould_id")

        # WHEN decision_maker.handle_undo_plies_to_dry_run_command is called
        result = await decision_maker.handle_undo_plies_to_dry_run_command(undo_plies_request.payload)

        # THEN result is correct
        assert result == expected_result

    @pytest.mark.parametrize(
        "ply_id_undo_to, expected_result",
        [
            ("P1", ["P1", "P2", "P3", "P4", "P5", "P6"]),
            ("P2", ["P2", "P4", "P6"]),
            ("P3", ["P3", "P4", "P5", "P6"]),
            ("P4", ["P4", "P6"]),
            ("P5", ["P5", "P6"]),
            ("P6", ["P6"]),
        ]
    )
    async def test_should_return_correct_result_when_graph_plies_with_multiple_mixed_dependents_given(
            self, mocker, ply_id_undo_to, expected_result):
        # GIVEN
        messaging_wrapper = mocker.patch("app.decision_maker.MessagingWrapper", new_callable=AsyncMock)
        state_plies_mock = StatePliesMock()
        first_ply = state_plies_mock.first_ply_fully_covered
        second_ply = state_plies_mock.second_ply_partially_covered
        third_ply = state_plies_mock.third_ply_fully_covered
        fourth_ply = state_plies_mock.fourth_ply_partially_covered
        fifth_ply = state_plies_mock.fifth_ply_partially_covered
        sixth_ply = state_plies_mock.sixth_ply_placed
        state_plies = {first_ply, second_ply, third_ply, fourth_ply, fifth_ply, sixth_ply}
        mould_state = MouldState(state_plies)
        graph_data = {
            "plies": {
                "P1": {"previous_plies": [], "edges": ["P1.1", "P1.2"]},
                "P2": {"previous_plies": ["P1"], "edges": ["P2.1", "P2.2"]},
                "P3": {"previous_plies": ["P1"], "edges": ["P3.1", "P3.2"]},
                "P4": {"previous_plies": ["P2", "P3"], "edges": ["P4.1", "P4.2"]},
                "P5": {"previous_plies": ["P3"], "edges": ["P5.1", "P5.2"]},
                "P6": {"previous_plies": ["P4", "P5"], "edges": ["P6.1", "P6.2"]},
            }
        }
        decision_maker = DecisionMaker(Mock(), messaging_wrapper, Mock(), mould_state)
        decision_maker._sub_graph = Graph(graph_data)
        undo_plies_request = create_undo_plies_to_dry_run_c2dm_request(ply_id=ply_id_undo_to, mould_id="mould_id")

        # WHEN decision_maker.handle_undo_plies_to_dry_run_command is called
        result = await decision_maker.handle_undo_plies_to_dry_run_command(undo_plies_request.payload)

        # THEN result is correct
        assert result == expected_result


@pytest.mark.asyncio
@patch("app.config.MOULD_ID", "mould_id")
class HandleUndoPlyCommandTests:
    @pytest.mark.parametrize(
        "ply_state", [PlyStateEnum.PLACED, PlyStateEnum.MISSING, PlyStateEnum.FORCED])
    async def test_should_not_abort_undo_ply_command_handling_when_ply_with_valid_state_given(self, mocker, ply_state):
        # GIVEN
        messaging_wrapper = mocker.patch("app.decision_maker.MessagingWrapper", new_callable=AsyncMock)
        ply_to_undo_id = "ply_to_undo_id"
        state_plies = {PlyState(ply_to_undo_id, state=ply_state)}
        mould_state = MouldState(copy.deepcopy(state_plies))
        decision_maker = DecisionMaker(Mock(), messaging_wrapper, Mock(), mould_state)
        undo_ply_request = create_undo_ply_c2dm_request(ply_id=ply_to_undo_id, mould_id="mould_id")

        # AND more methods patched
        mocker.patch.object(decision_maker, "_sub_graph", return_value=Graph({"plies": {}}))
        process_mould_state_changes = mocker.patch.object(decision_maker, "_process_mould_state_changes")

        # WHEN decision_maker.handle_undo_ply_command is called
        await decision_maker.handle_undo_ply_command(undo_ply_request.payload)

        # THEN DecisionMaker._process_mould_state_changes is called, means execution of the process is not aborted
        assert process_mould_state_changes.call_count == 1
        assert process_mould_state_changes.await_count == 1

    @pytest.mark.parametrize("ply_state", [PlyStateEnum.COVERED, PlyStateEnum.EXPECTED])
    async def test_should_raise_exception_and_abort_undo_ply_command_handling_when_ply_with_invalid_state_given(
            self, mocker, ply_state):
        # GIVEN
        messaging_wrapper = mocker.patch("app.decision_maker.MessagingWrapper", new_callable=AsyncMock)
        ply_to_undo_id = "ply_to_undo_id"
        state_plies = {PlyState(ply_to_undo_id, state=ply_state)}
        mould_state = MouldState(copy.deepcopy(state_plies))
        decision_maker = DecisionMaker(Mock(), messaging_wrapper, Mock(), mould_state)
        undo_ply_request = create_undo_ply_c2dm_request(ply_id=ply_to_undo_id, mould_id="mould_id")

        # AND more methods patched
        process_mould_state_changes = mocker.patch.object(decision_maker, "_process_mould_state_changes")

        # WHEN decision_maker.handle_undo_ply_command is called, assert that an exception is raised
        with pytest.raises(Exception) as exc_info:
            await decision_maker.handle_undo_ply_command(undo_ply_request.payload)

        # THEN an exception of correct type is raised
        assert exc_info.type is ValueError

        error_message = f"Given ply {ply_to_undo_id} is not valid ply to undo, it must be not {ply_state.name} ply."
        assert exc_info.value.args[0] == error_message

        # AND DecisionMaker._process_mould_state_changes is not called, means execution of the process is aborted
        assert process_mould_state_changes.call_count == 0
        assert process_mould_state_changes.await_count == 0

        # AND ply to undo is not removed from local mould state
        assert mould_state.find_ply(ply_to_undo_id) is not None

    @pytest.mark.parametrize(
        "edge_1_state, edge_2_state",
        [
            (EdgeStateEnum.COVERED, EdgeStateEnum.DETECTED),
            (EdgeStateEnum.DETECTED, EdgeStateEnum.COVERED),
            (EdgeStateEnum.COVERED, EdgeStateEnum.COVERED),
            (EdgeStateEnum.COVERED, EdgeStateEnum.MISSING),
            (EdgeStateEnum.MISSING, EdgeStateEnum.COVERED),
            (EdgeStateEnum.COVERED, EdgeStateEnum.COVERED),
            (EdgeStateEnum.COVERED, EdgeStateEnum.FORCED),
            (EdgeStateEnum.FORCED, EdgeStateEnum.COVERED),
            (EdgeStateEnum.COVERED, EdgeStateEnum.COVERED),
        ]
    )
    async def test_should_raise_exception_and_abort_undo_ply_command_handling_when_ply_with_invalid_edge_state_given(
            self, mocker, edge_1_state, edge_2_state):
        # GIVEN
        messaging_wrapper = mocker.patch("app.decision_maker.MessagingWrapper", new_callable=AsyncMock)
        ply_to_undo_id = "ply_to_undo_id"
        state_plies = {
            PlyState(ply_to_undo_id, state=PlyStateEnum.PLACED, edges={
                EdgeState("edge_1", cams=set(), state=edge_1_state),
                EdgeState("edge_2", cams=set(), state=edge_2_state),
            })
        }
        mould_state = MouldState(copy.deepcopy(state_plies))
        decision_maker = DecisionMaker(Mock(), messaging_wrapper, Mock(), mould_state)
        undo_ply_request = create_undo_ply_c2dm_request(ply_id=ply_to_undo_id, mould_id="mould_id")

        # AND more methods patched
        process_mould_state_changes = mocker.patch.object(decision_maker, "_process_mould_state_changes")

        # WHEN decision_maker.handle_undo_ply_command is called, assert that an exception is raised
        with pytest.raises(Exception) as exc_info:
            await decision_maker.handle_undo_ply_command(undo_ply_request.payload)

        # THEN an exception of correct type is raised
        assert exc_info.type is ValueError

        error_message = f"Given ply {ply_to_undo_id} is not valid to undo, it has COVERED edge."
        assert exc_info.value.args[0] == error_message

        # AND DecisionMaker._process_mould_state_changes is not called, means execution of the process is aborted
        assert process_mould_state_changes.call_count == 0
        assert process_mould_state_changes.await_count == 0

        # AND ply to undo is not removed from local mould state
        assert mould_state.find_ply(ply_to_undo_id) is not None

    async def test_should_raise_exception_and_abort_ply_undo_command_handling_when_non_existing_ply_id_given(
            self, mocker):
        # GIVEN
        messaging_wrapper = mocker.patch("app.decision_maker.MessagingWrapper", new_callable=AsyncMock)
        ply_to_undo_id = "NON_EXISTING_PLY_ID"
        state_plies = {PlyState("P1", state=PlyStateEnum.EXPECTED)}
        mould_state = MouldState(copy.deepcopy(state_plies))
        decision_maker = DecisionMaker(Mock(), messaging_wrapper, Mock(), mould_state)
        undo_ply_request = create_undo_ply_c2dm_request(ply_id=ply_to_undo_id, mould_id="mould_id")

        # AND more methods patched
        process_mould_state_changes = mocker.patch.object(decision_maker, "_process_mould_state_changes")

        # WHEN decision_maker.handle_undo_ply_command is called, assert that an exception is raised
        with pytest.raises(Exception) as exc_info:
            await decision_maker.handle_undo_ply_command(undo_ply_request.payload)

        # THEN an exception of correct type is raised
        assert exc_info.type is ValueError

        error_message = f"Failed to get ply in mould state by given ply_id: {ply_to_undo_id}"
        assert exc_info.value.args[0] == error_message

        # AND DecisionMaker._process_mould_state_changes is not called, means execution of the process is aborted
        assert process_mould_state_changes.call_count == 0
        assert process_mould_state_changes.await_count == 0

        # AND plies are not removed in local mould state
        assert mould_state.plies == state_plies

    async def test_should_remove_expected_ply_when_ply_to_undo_in_its_previous_plies(self, mocker):
        # GIVEN
        messaging_wrapper = mocker.patch("app.decision_maker.MessagingWrapper", new_callable=AsyncMock)
        state_plies_mock = StatePliesMock()
        first_ply_to_undo = state_plies_mock.first_ply_placed
        second_ply = state_plies_mock.second_ply_expected
        state_plies = {first_ply_to_undo, second_ply}
        mould_state = MouldState(state_plies)
        graph_data = {
            "plies": {
                "P1": {"previous_plies": [], "edges_covered": [], "edges": ["P1.1", "P1.2"]},
                "P2": {"previous_plies": ["P1"], "edges_covered": ["P1.2"], "edges": ["P2.1", "P2.2"]},
                "P3": {"previous_plies": ["P2"], "edges_covered": ["P2.2"], "edges": ["P3.1", "P3.2"]},
            }
        }
        decision_maker = DecisionMaker(Mock(), messaging_wrapper, Mock(), mould_state)
        decision_maker._sub_graph = Graph(graph_data)
        undo_ply_request = create_undo_ply_c2dm_request(ply_id=first_ply_to_undo.id, mould_id="mould_id")

        # AND more methods patched
        mocker.patch.object(decision_maker, "_process_mould_state_changes")

        # WHEN decision_maker.handle_undo_ply_command is called
        await decision_maker.handle_undo_ply_command(undo_ply_request.payload)

        # THEN expected ply is removed from local mould state
        assert mould_state.find_ply(second_ply.id) is None

    async def test_should_remove_expected_plies_when_ply_to_undo_in_their_previous_plies(self, mocker):
        # GIVEN
        messaging_wrapper = mocker.patch("app.decision_maker.MessagingWrapper", new_callable=AsyncMock)
        state_plies_mock = StatePliesMock()
        first_ply_to_undo = state_plies_mock.first_ply_placed
        second_ply = state_plies_mock.second_ply_expected
        third_ply = state_plies_mock.third_ply_expected
        state_plies = {first_ply_to_undo, second_ply, third_ply}
        mould_state = MouldState(state_plies)
        graph_data = {
            "plies": {
                "P1": {"previous_plies": [], "edges_covered": [], "edges": ["P1.1", "P1.2"]},
                "P2": {"previous_plies": ["P1"], "edges_covered": ["P1.2"], "edges": ["P2.1", "P2.2"]},
                "P3": {"previous_plies": ["P1"], "edges_covered": ["P1.1"], "edges": ["P3.1", "P3.2"]},
            }
        }
        decision_maker = DecisionMaker(Mock(), messaging_wrapper, Mock(), mould_state)
        decision_maker._sub_graph = Graph(graph_data)
        undo_ply_request = create_undo_ply_c2dm_request(ply_id=first_ply_to_undo.id, mould_id="mould_id")

        # AND more methods patched
        mocker.patch.object(decision_maker, "_process_mould_state_changes")

        # WHEN decision_maker.handle_undo_ply_command is called
        await decision_maker.handle_undo_ply_command(undo_ply_request.payload)

        # THEN expected plies are removed from local mould state
        assert mould_state.find_ply(second_ply.id) is None
        assert mould_state.find_ply(third_ply.id) is None

    async def test_should_not_remove_expected_ply_when_ply_to_undo_not_in_their_previous_plies(self, mocker):
        # GIVEN
        messaging_wrapper = mocker.patch("app.decision_maker.MessagingWrapper", new_callable=AsyncMock)
        state_plies_mock = StatePliesMock()
        first_ply_to_undo = state_plies_mock.first_ply_placed
        second_ply = state_plies_mock.second_ply_expected
        third_ply = state_plies_mock.third_ply_expected
        state_plies = {first_ply_to_undo, second_ply, third_ply}
        mould_state = MouldState(state_plies)
        graph_data = {
            "plies": {
                "P1": {"previous_plies": [], "edges_covered": [], "edges": ["P1.1", "P1.2"]},
                "P2": {"previous_plies": [], "edges_covered": [], "edges": ["P2.1", "P2.2"]},
                "P3": {"previous_plies": ["P2"], "edges_covered": ["P2.2"], "edges": ["P3.1", "P3.2"]},
            }
        }
        decision_maker = DecisionMaker(Mock(), messaging_wrapper, Mock(), mould_state)
        decision_maker._sub_graph = Graph(graph_data)
        undo_ply_request = create_undo_ply_c2dm_request(ply_id=first_ply_to_undo.id, mould_id="mould_id")

        # AND more methods patched
        mocker.patch.object(decision_maker, "_process_mould_state_changes")

        # WHEN decision_maker.handle_undo_ply_command is called
        await decision_maker.handle_undo_ply_command(undo_ply_request.payload)

        # THEN expected plies are not removed from local mould state
        assert mould_state.find_ply(second_ply.id) is not None
        assert mould_state.find_ply(third_ply.id) is not None

    async def test_should_correctly_undo_placed_ply_when_no_ply_placed_previously(self, mocker):
        # GIVEN
        messaging_wrapper = mocker.patch("app.decision_maker.MessagingWrapper", new_callable=AsyncMock)
        state_plies_mock = StatePliesMock()
        first_ply_to_undo = state_plies_mock.first_ply_placed
        second_ply = state_plies_mock.second_ply_expected
        state_plies = {first_ply_to_undo, second_ply}
        mould_state = MouldState(state_plies)
        graph_data = {
            "plies": {
                "P1": {"previous_plies": [], "edges_covered": [], "edges": ["P1.1", "P1.2"]},
                "P2": {"previous_plies": ["P1"], "edges_covered": ["P1.2"], "edges": ["P2.1", "P2.2"]},
                "P3": {"previous_plies": ["P2"], "edges_covered": ["P2.2"], "edges": ["P3.1", "P3.2"]},
            }
        }
        decision_maker = DecisionMaker(Mock(), messaging_wrapper, Mock(), mould_state)
        decision_maker._sub_graph = Graph(graph_data)
        undo_ply_request = create_undo_ply_c2dm_request(ply_id=first_ply_to_undo.id, mould_id="mould_id")

        # AND more methods patched
        process_mould_state_changes = mocker.patch.object(decision_maker, "_process_mould_state_changes")

        # WHEN decision_maker.handle_undo_ply_command is called
        await decision_maker.handle_undo_ply_command(undo_ply_request.payload)

        # THEN DecisionMaker._process_mould_state_changes is called
        assert process_mould_state_changes.call_count == 1
        assert process_mould_state_changes.await_count == 1
        call_args = process_mould_state_changes.call_args.args
        assert call_args[0] == {second_ply, first_ply_to_undo}

        # AND old expected ply is removed from local mould state
        assert mould_state.find_ply(second_ply.id) is None

        # AND first ply is correctly reset to expected
        result = mould_state.find_ply(first_ply_to_undo.id)
        assert result is not None
        assert result.state == PlyStateEnum.EXPECTED
        assert result.previous_state == PlyStateEnum.PLACED
        assert result.updated_by == "command:undo_ply:force"
        assert result.get_edge("P1.1").state == EdgeStateEnum.MISSING
        assert result.get_edge("P1.2").state == EdgeStateEnum.MISSING
        assert result.get_edge("P1.1").get_cam("cam1").state == EdgeCamStateEnum.NEVER_DETECTED
        assert result.get_edge("P1.2").get_cam("cam1").state == EdgeCamStateEnum.NEVER_DETECTED

    async def test_should_correctly_undo_placed_phantom_ply_when_no_ply_placed_previously(self, mocker):
        # GIVEN
        messaging_wrapper = mocker.patch("app.decision_maker.MessagingWrapper", new_callable=AsyncMock)
        state_plies_mock = StatePliesMock()
        first_ply_to_undo = state_plies_mock.first_ply_phantom_forced
        second_ply = state_plies_mock.second_ply_expected
        state_plies = {first_ply_to_undo, second_ply}
        mould_state = MouldState(state_plies)
        graph_data = {
            "plies": {
                "P1": {"previous_plies": [], "edges_covered": [], "edges": ["P1.1", "P1.2"]},
                "P2": {"previous_plies": ["P1"], "edges_covered": ["P1.2"], "edges": ["P2.1", "P2.2"]},
                "P3": {"previous_plies": ["P2"], "edges_covered": [], "edges": ["P3.1", "P3.2"]},
            }
        }
        decision_maker = DecisionMaker(Mock(), messaging_wrapper, Mock(), mould_state)
        decision_maker._sub_graph = Graph(graph_data)
        undo_ply_request = create_undo_ply_c2dm_request(ply_id=first_ply_to_undo.id, mould_id="mould_id")

        # AND more methods patched
        process_mould_state_changes = mocker.patch.object(decision_maker, "_process_mould_state_changes")

        # WHEN decision_maker.handle_undo_ply_command is called
        await decision_maker.handle_undo_ply_command(undo_ply_request.payload)

        # THEN DecisionMaker._process_mould_state_changes is called
        assert process_mould_state_changes.call_count == 1
        assert process_mould_state_changes.await_count == 1
        call_args = process_mould_state_changes.call_args.args
        assert call_args[0] == {second_ply, first_ply_to_undo}

        # AND old expected ply is removed from local mould state
        assert mould_state.find_ply(second_ply.id) is None

        # AND first ply is correctly reset to expected
        result = mould_state.find_ply(first_ply_to_undo.id)
        assert result is not None
        assert result.state == PlyStateEnum.EXPECTED
        assert result.previous_state == PlyStateEnum.FORCED
        assert result.updated_by == "command:undo_ply:force"
        assert result.edges == set()

    async def test_should_correctly_undo_placed_ply_when_a_ply_placed_previously(self, mocker):
        # GIVEN
        messaging_wrapper = mocker.patch("app.decision_maker.MessagingWrapper", new_callable=AsyncMock)
        state_plies_mock = StatePliesMock()
        first_ply = state_plies_mock.first_ply_partially_covered
        second_ply_to_undo = state_plies_mock.second_ply_placed
        third_ply = state_plies_mock.third_ply_expected
        state_plies = {first_ply, second_ply_to_undo, third_ply}
        mould_state = MouldState(state_plies)
        graph_data = {
            "plies": {
                "P1": {"previous_plies": [], "edges_covered": [], "edges": ["P1.1", "P1.2"]},
                "P2": {"previous_plies": ["P1"], "edges_covered": ["P1.2"], "edges": ["P2.1", "P2.2"]},
                "P3": {"previous_plies": ["P2"], "edges_covered": ["P2.2"], "edges": ["P3.1", "P3.2"]},
            }
        }
        decision_maker = DecisionMaker(Mock(), messaging_wrapper, Mock(), mould_state)
        decision_maker._sub_graph = Graph(graph_data)
        undo_ply_request = create_undo_ply_c2dm_request(ply_id=second_ply_to_undo.id, mould_id="mould_id")

        # AND more methods patched
        process_mould_state_changes = mocker.patch.object(decision_maker, "_process_mould_state_changes")

        # WHEN decision_maker.handle_undo_ply_command is called
        await decision_maker.handle_undo_ply_command(undo_ply_request.payload)

        # THEN DecisionMaker._process_mould_state_changes is called
        assert process_mould_state_changes.call_count == 1
        assert process_mould_state_changes.await_count == 1
        call_args = process_mould_state_changes.call_args.args
        assert call_args[0] == {third_ply, second_ply_to_undo, first_ply}

        # AND old expected ply is removed from local mould state
        assert mould_state.find_ply(third_ply.id) is None

        # AND first ply is correctly reset to placed
        result = mould_state.find_ply(first_ply.id)
        assert result is not None
        assert result.state == PlyStateEnum.PLACED
        assert result.previous_state == PlyStateEnum.PLACED
        assert result.updated_by == "command:undo_ply:force"
        assert result.get_edge("P1.1").state == EdgeStateEnum.DETECTED
        assert result.get_edge("P1.2").state == EdgeStateEnum.DETECTED
        assert result.get_edge("P1.1").get_cam("cam1").state == EdgeCamStateEnum.DETECTED
        assert result.get_edge("P1.2").get_cam("cam1").state == EdgeCamStateEnum.DETECTED

        # AND second ply is correctly reset to expected
        result = mould_state.find_ply(second_ply_to_undo.id)
        assert result is not None
        assert result.state == PlyStateEnum.EXPECTED
        assert result.previous_state == PlyStateEnum.PLACED
        assert result.updated_by == "command:undo_ply:force"
        assert result.get_edge("P2.1").state == EdgeStateEnum.MISSING
        assert result.get_edge("P2.2").state == EdgeStateEnum.MISSING
        assert result.get_edge("P2.1").get_cam("cam1").state == EdgeCamStateEnum.NEVER_DETECTED
        assert result.get_edge("P2.2").get_cam("cam1").state == EdgeCamStateEnum.NEVER_DETECTED
        assert result.get_edge("P2.2").get_cam("cam2").state == EdgeCamStateEnum.NEVER_DETECTED

    async def test_should_correctly_undo_placed_ply_when_ply_to_undo_has_no_edges_covered(self, mocker):
        # GIVEN
        messaging_wrapper = mocker.patch("app.decision_maker.MessagingWrapper", new_callable=AsyncMock)
        state_plies_mock = StatePliesMock()
        first_ply = state_plies_mock.first_ply_placed
        second_ply_to_undo = state_plies_mock.second_ply_placed
        third_ply = state_plies_mock.third_ply_expected
        state_plies = {first_ply, second_ply_to_undo, third_ply}
        mould_state = MouldState(state_plies)
        graph_data = {
            "plies": {
                "P1": {"previous_plies": [], "edges_covered": [], "edges": ["P1.1", "P1.2"]},
                "P2": {"previous_plies": ["P1"], "edges_covered": [], "edges": ["P2.1", "P2.2"]},
                "P3": {"previous_plies": ["P2"], "edges_covered": ["P2.2"], "edges": ["P3.1", "P3.2"]},
            }
        }
        decision_maker = DecisionMaker(Mock(), messaging_wrapper, Mock(), mould_state)
        decision_maker._sub_graph = Graph(graph_data)
        undo_ply_request = create_undo_ply_c2dm_request(ply_id=second_ply_to_undo.id, mould_id="mould_id")

        # AND more methods patched
        process_mould_state_changes = mocker.patch.object(decision_maker, "_process_mould_state_changes")

        # WHEN decision_maker.handle_undo_ply_command is called
        await decision_maker.handle_undo_ply_command(undo_ply_request.payload)

        # THEN DecisionMaker._process_mould_state_changes is called
        assert process_mould_state_changes.call_count == 1
        assert process_mould_state_changes.await_count == 1
        call_args = process_mould_state_changes.call_args.args
        assert call_args[0] == {third_ply, second_ply_to_undo}

        # AND old expected ply is removed from local mould state
        assert mould_state.find_ply(third_ply.id) is None

        # AND first ply is unchanged
        assert mould_state.find_ply(first_ply.id) == StatePliesMock().first_ply_placed

        # AND second ply is correctly reset to expected
        result = mould_state.find_ply(second_ply_to_undo.id)
        assert result is not None
        assert result.state == PlyStateEnum.EXPECTED
        assert result.previous_state == PlyStateEnum.PLACED
        assert result.updated_by == "command:undo_ply:force"
        assert result.get_edge("P2.1").state == EdgeStateEnum.MISSING
        assert result.get_edge("P2.2").state == EdgeStateEnum.MISSING
        assert result.get_edge("P2.1").get_cam("cam1").state == EdgeCamStateEnum.NEVER_DETECTED
        assert result.get_edge("P2.2").get_cam("cam1").state == EdgeCamStateEnum.NEVER_DETECTED
        assert result.get_edge("P2.2").get_cam("cam2").state == EdgeCamStateEnum.NEVER_DETECTED

    async def test_should_correctly_undo_placed_ply_when_next_ply_expected_and_has_dependency_on_ply_to_undo(
            self, mocker):
        # GIVEN
        messaging_wrapper = mocker.patch("app.decision_maker.MessagingWrapper", new_callable=AsyncMock)
        state_plies_mock = StatePliesMock()
        first_ply = state_plies_mock.first_ply_partially_covered
        second_ply_to_undo = state_plies_mock.second_ply_placed
        third_ply = state_plies_mock.third_ply_expected
        state_plies = {first_ply, second_ply_to_undo, third_ply}
        mould_state = MouldState(state_plies)
        graph_data = {
            "plies": {
                "P1": {"previous_plies": [], "edges_covered": [], "edges": ["P1.1", "P1.2"]},
                "P2": {"previous_plies": ["P1"], "edges_covered": ["P1.2"], "edges": ["P2.1", "P2.2"]},
                "P3": {"previous_plies": [], "edges_covered": [], "edges": ["P3.1", "P3.2"]},
            }
        }
        decision_maker = DecisionMaker(Mock(), messaging_wrapper, Mock(), mould_state)
        decision_maker._sub_graph = Graph(graph_data)
        undo_ply_request = create_undo_ply_c2dm_request(ply_id=second_ply_to_undo.id, mould_id="mould_id")

        # AND more methods patched
        process_mould_state_changes = mocker.patch.object(decision_maker, "_process_mould_state_changes")

        # WHEN decision_maker.handle_undo_ply_command is called
        await decision_maker.handle_undo_ply_command(undo_ply_request.payload)

        # THEN DecisionMaker._process_mould_state_changes is called
        assert process_mould_state_changes.call_count == 1
        assert process_mould_state_changes.await_count == 1
        call_args = process_mould_state_changes.call_args.args
        assert call_args[0] == {first_ply, second_ply_to_undo}

        # AND first ply is correctly reset to placed
        result = mould_state.find_ply(first_ply.id)
        assert result is not None
        assert result.state == PlyStateEnum.PLACED
        assert result.previous_state == PlyStateEnum.PLACED
        assert result.updated_by == "command:undo_ply:force"
        assert result.get_edge("P1.1").state == EdgeStateEnum.DETECTED
        assert result.get_edge("P1.2").state == EdgeStateEnum.DETECTED
        assert result.get_edge("P1.1").get_cam("cam1").state == EdgeCamStateEnum.DETECTED
        assert result.get_edge("P1.2").get_cam("cam1").state == EdgeCamStateEnum.DETECTED

        # AND second ply is correctly reset to expected
        result = mould_state.find_ply(second_ply_to_undo.id)
        assert result is not None
        assert result.state == PlyStateEnum.EXPECTED
        assert result.previous_state == PlyStateEnum.PLACED
        assert result.updated_by == "command:undo_ply:force"
        assert result.get_edge("P2.1").state == EdgeStateEnum.MISSING
        assert result.get_edge("P2.2").state == EdgeStateEnum.MISSING
        assert result.get_edge("P2.1").get_cam("cam1").state == EdgeCamStateEnum.NEVER_DETECTED
        assert result.get_edge("P2.2").get_cam("cam1").state == EdgeCamStateEnum.NEVER_DETECTED
        assert result.get_edge("P2.2").get_cam("cam2").state == EdgeCamStateEnum.NEVER_DETECTED

        # AND third ply is unchanged
        assert mould_state.find_ply(third_ply.id) == StatePliesMock().third_ply_expected

    async def test_should_correctly_undo_placed_ply_when_it_has_no_dependency_on_other_ply(self, mocker):
        # GIVEN
        messaging_wrapper = mocker.patch("app.decision_maker.MessagingWrapper", new_callable=AsyncMock)
        state_plies_mock = StatePliesMock()
        first_ply = state_plies_mock.first_ply_partially_covered
        second_ply = state_plies_mock.second_ply_placed
        third_ply_to_undo = state_plies_mock.third_ply_placed
        state_plies = {first_ply, second_ply, third_ply_to_undo}
        mould_state = MouldState(state_plies)
        graph_data = {
            "plies": {
                "P1": {"previous_plies": [], "edges_covered": [], "edges": ["P1.1", "P1.2"]},
                "P2": {"previous_plies": ["P1"], "edges_covered": ["P1.2"], "edges": ["P2.1", "P2.2"]},
                "P3": {"previous_plies": [], "edges_covered": [], "edges": ["P3.1", "P3.2"]},
            }
        }
        decision_maker = DecisionMaker(Mock(), messaging_wrapper, Mock(), mould_state)
        decision_maker._sub_graph = Graph(graph_data)
        undo_ply_request = create_undo_ply_c2dm_request(ply_id=third_ply_to_undo.id, mould_id="mould_id")

        # AND more methods patched
        process_mould_state_changes = mocker.patch.object(decision_maker, "_process_mould_state_changes")

        # WHEN decision_maker.handle_undo_ply_command is called
        await decision_maker.handle_undo_ply_command(undo_ply_request.payload)

        # THEN DecisionMaker._process_mould_state_changes is called
        assert process_mould_state_changes.call_count == 1
        assert process_mould_state_changes.await_count == 1
        call_args = process_mould_state_changes.call_args.args
        assert call_args[0] == {third_ply_to_undo}

        # AND third ply is unchanged
        assert mould_state.find_ply(first_ply.id) == StatePliesMock().first_ply_partially_covered

        # AND third ply is unchanged
        assert mould_state.find_ply(second_ply.id) == StatePliesMock().second_ply_placed

        # AND third ply is correctly reset to expected
        result = mould_state.find_ply(third_ply_to_undo.id)
        assert result is not None
        assert result.state == PlyStateEnum.EXPECTED
        assert result.previous_state == PlyStateEnum.PLACED
        assert result.updated_by == "command:undo_ply:force"
        assert result.get_edge("P3.1").state == EdgeStateEnum.MISSING
        assert result.get_edge("P3.2").state == EdgeStateEnum.MISSING
        assert result.get_edge("P3.1").get_cam("cam2").state == EdgeCamStateEnum.NEVER_DETECTED
        assert result.get_edge("P3.2").get_cam("cam2").state == EdgeCamStateEnum.NEVER_DETECTED
        assert result.get_edge("P3.2").get_cam("cam3").state == EdgeCamStateEnum.NEVER_DETECTED

    async def test_should_correctly_undo_placed_ply_when_next_ply_placed_but_has_no_dependency_on_ply_to_undo(
            self, mocker):
        # GIVEN
        messaging_wrapper = mocker.patch("app.decision_maker.MessagingWrapper", new_callable=AsyncMock)
        state_plies_mock = StatePliesMock()
        first_ply = state_plies_mock.first_ply_partially_covered
        second_ply_to_undo = state_plies_mock.second_ply_placed
        third_ply = state_plies_mock.third_ply_placed
        state_plies = {first_ply, second_ply_to_undo, third_ply}
        mould_state = MouldState(state_plies)
        graph_data = {
            "plies": {
                "P1": {"previous_plies": [], "edges_covered": [], "edges": ["P1.1", "P1.2"]},
                "P2": {"previous_plies": ["P1"], "edges_covered": ["P1.2"], "edges": ["P2.1", "P2.2"]},
                "P3": {"previous_plies": [], "edges_covered": [], "edges": ["P3.1", "P3.2"]},
            }
        }
        decision_maker = DecisionMaker(Mock(), messaging_wrapper, Mock(), mould_state)
        decision_maker._sub_graph = Graph(graph_data)
        undo_ply_request = create_undo_ply_c2dm_request(ply_id=second_ply_to_undo.id, mould_id="mould_id")

        # AND more methods patched
        process_mould_state_changes = mocker.patch.object(decision_maker, "_process_mould_state_changes")

        # WHEN decision_maker.handle_undo_ply_command is called
        await decision_maker.handle_undo_ply_command(undo_ply_request.payload)

        # THEN DecisionMaker._process_mould_state_changes is called
        assert process_mould_state_changes.call_count == 1
        assert process_mould_state_changes.await_count == 1
        call_args = process_mould_state_changes.call_args.args
        assert call_args[0] == {first_ply, second_ply_to_undo}

        # AND first ply is correctly reset to placed
        result = mould_state.find_ply(first_ply.id)
        assert result is not None
        assert result.state == PlyStateEnum.PLACED
        assert result.previous_state == PlyStateEnum.PLACED
        assert result.updated_by == "command:undo_ply:force"
        assert result.get_edge("P1.1").state == EdgeStateEnum.DETECTED
        assert result.get_edge("P1.2").state == EdgeStateEnum.DETECTED
        assert result.get_edge("P1.1").get_cam("cam1").state == EdgeCamStateEnum.DETECTED
        assert result.get_edge("P1.2").get_cam("cam1").state == EdgeCamStateEnum.DETECTED

        # AND second ply is correctly reset to expected
        result = mould_state.find_ply(second_ply_to_undo.id)
        assert result is not None
        assert result.state == PlyStateEnum.EXPECTED
        assert result.previous_state == PlyStateEnum.PLACED
        assert result.updated_by == "command:undo_ply:force"
        assert result.get_edge("P2.1").state == EdgeStateEnum.MISSING
        assert result.get_edge("P2.2").state == EdgeStateEnum.MISSING
        assert result.get_edge("P2.1").get_cam("cam1").state == EdgeCamStateEnum.NEVER_DETECTED
        assert result.get_edge("P2.2").get_cam("cam1").state == EdgeCamStateEnum.NEVER_DETECTED
        assert result.get_edge("P2.2").get_cam("cam2").state == EdgeCamStateEnum.NEVER_DETECTED

        # AND third ply is unchanged
        assert mould_state.find_ply(third_ply.id) == StatePliesMock().third_ply_placed

    @pytest.mark.parametrize(
        "ply_to_undo_state, next_ply_state",
        [
            (PlyStateEnum.PLACED, PlyStateEnum.PLACED),
            (PlyStateEnum.PLACED, PlyStateEnum.FORCED),
            (PlyStateEnum.FORCED, PlyStateEnum.PLACED),
            (PlyStateEnum.FORCED, PlyStateEnum.FORCED),
            (PlyStateEnum.PLACED, PlyStateEnum.MISSING),
            (PlyStateEnum.MISSING, PlyStateEnum.PLACED),
            (PlyStateEnum.MISSING, PlyStateEnum.MISSING),
            (PlyStateEnum.PLACED, PlyStateEnum.COVERED),
        ]
    )
    async def test_should_not_undo_ply_of_placed_type_when_next_ply_has_dependency_on_ply_to_undo(
            self, mocker, ply_to_undo_state, next_ply_state):
        # GIVEN
        messaging_wrapper = mocker.patch("app.decision_maker.MessagingWrapper", new_callable=AsyncMock)
        state_plies_mock = StatePliesMock()
        first_ply = state_plies_mock.first_ply_partially_covered
        second_ply_to_undo = PlyState("P2", state=ply_to_undo_state)
        third_ply = PlyState("P3", state=next_ply_state)
        state_plies = {first_ply, second_ply_to_undo, third_ply}
        mould_state = MouldState(state_plies)
        graph_data = {
            "plies": {
                "P1": {"previous_plies": [], "edges_covered": [], "edges": ["P1.1", "P1.2"]},
                "P2": {"previous_plies": ["P1"], "edges_covered": ["P1.2"], "edges": ["P2.1", "P2.2"]},
                "P3": {"previous_plies": ["P2"], "edges_covered": ["P2.2"], "edges": ["P3.1", "P3.2"]},
            }
        }
        decision_maker = DecisionMaker(Mock(), messaging_wrapper, Mock(), mould_state)
        decision_maker._sub_graph = Graph(graph_data)
        undo_ply_request = create_undo_ply_c2dm_request(ply_id=second_ply_to_undo.id, mould_id="mould_id")

        # AND more methods patched
        process_mould_state_changes = mocker.patch.object(decision_maker, "_process_mould_state_changes")

        # WHEN decision_maker.handle_undo_ply_command is called, assert that an exception is raised
        with pytest.raises(Exception) as exc_info:
            await decision_maker.handle_undo_ply_command(undo_ply_request.payload)

        # THEN an exception of correct type is raised
        assert exc_info.type is ValueError

        error_message = f"Given ply {second_ply_to_undo.id} is not valid to undo, " \
                        f"plies: {[third_ply.id]} depend on it, undo them first."
        assert exc_info.value.args[0] == error_message

        # AND DecisionMaker._process_mould_state_changes is not called, means execution of the process is aborted
        assert process_mould_state_changes.call_count == 0
        assert process_mould_state_changes.await_count == 0

        # AND first ply is unchanged
        assert mould_state.find_ply(first_ply.id) == StatePliesMock().first_ply_partially_covered

        # AND second ply is unchanged
        assert mould_state.find_ply(second_ply_to_undo.id) == PlyState("P2", state=ply_to_undo_state)

        # AND third ply is unchanged
        assert mould_state.find_ply(third_ply.id) == PlyState("P3", state=next_ply_state)

    @pytest.mark.parametrize(
        "first_ply_to_undo_state, second_ply_state, third_ply_state",
        [
            (PlyStateEnum.PLACED, PlyStateEnum.PLACED, PlyStateEnum.PLACED),
            (PlyStateEnum.PLACED, PlyStateEnum.PLACED, PlyStateEnum.COVERED),
            (PlyStateEnum.PLACED, PlyStateEnum.COVERED, PlyStateEnum.PLACED),
            (PlyStateEnum.PLACED, PlyStateEnum.COVERED, PlyStateEnum.COVERED),
            (PlyStateEnum.PLACED, PlyStateEnum.PLACED, PlyStateEnum.FORCED),
            (PlyStateEnum.PLACED, PlyStateEnum.FORCED, PlyStateEnum.PLACED),
            (PlyStateEnum.PLACED, PlyStateEnum.FORCED, PlyStateEnum.FORCED),
            (PlyStateEnum.PLACED, PlyStateEnum.PLACED, PlyStateEnum.MISSING),
            (PlyStateEnum.PLACED, PlyStateEnum.MISSING, PlyStateEnum.PLACED),
            (PlyStateEnum.PLACED, PlyStateEnum.MISSING, PlyStateEnum.MISSING),
            (PlyStateEnum.PLACED, PlyStateEnum.FORCED, PlyStateEnum.MISSING),
            (PlyStateEnum.PLACED, PlyStateEnum.MISSING, PlyStateEnum.FORCED),
            (PlyStateEnum.PLACED, PlyStateEnum.FORCED, PlyStateEnum.COVERED),
            (PlyStateEnum.PLACED, PlyStateEnum.COVERED, PlyStateEnum.FORCED),
            (PlyStateEnum.PLACED, PlyStateEnum.COVERED, PlyStateEnum.MISSING),
            (PlyStateEnum.PLACED, PlyStateEnum.MISSING, PlyStateEnum.COVERED),
            (PlyStateEnum.FORCED, PlyStateEnum.PLACED, PlyStateEnum.PLACED),
            (PlyStateEnum.FORCED, PlyStateEnum.PLACED, PlyStateEnum.COVERED),
            (PlyStateEnum.FORCED, PlyStateEnum.COVERED, PlyStateEnum.PLACED),
            (PlyStateEnum.FORCED, PlyStateEnum.COVERED, PlyStateEnum.COVERED),
            (PlyStateEnum.FORCED, PlyStateEnum.PLACED, PlyStateEnum.FORCED),
            (PlyStateEnum.FORCED, PlyStateEnum.FORCED, PlyStateEnum.PLACED),
            (PlyStateEnum.FORCED, PlyStateEnum.FORCED, PlyStateEnum.FORCED),
            (PlyStateEnum.FORCED, PlyStateEnum.PLACED, PlyStateEnum.MISSING),
            (PlyStateEnum.FORCED, PlyStateEnum.MISSING, PlyStateEnum.PLACED),
            (PlyStateEnum.FORCED, PlyStateEnum.MISSING, PlyStateEnum.MISSING),
            (PlyStateEnum.FORCED, PlyStateEnum.FORCED, PlyStateEnum.MISSING),
            (PlyStateEnum.FORCED, PlyStateEnum.MISSING, PlyStateEnum.FORCED),
            (PlyStateEnum.FORCED, PlyStateEnum.FORCED, PlyStateEnum.COVERED),
            (PlyStateEnum.FORCED, PlyStateEnum.COVERED, PlyStateEnum.FORCED),
            (PlyStateEnum.FORCED, PlyStateEnum.COVERED, PlyStateEnum.MISSING),
            (PlyStateEnum.FORCED, PlyStateEnum.MISSING, PlyStateEnum.COVERED),
            (PlyStateEnum.MISSING, PlyStateEnum.PLACED, PlyStateEnum.PLACED),
            (PlyStateEnum.MISSING, PlyStateEnum.PLACED, PlyStateEnum.COVERED),
            (PlyStateEnum.MISSING, PlyStateEnum.COVERED, PlyStateEnum.PLACED),
            (PlyStateEnum.MISSING, PlyStateEnum.COVERED, PlyStateEnum.COVERED),
            (PlyStateEnum.MISSING, PlyStateEnum.PLACED, PlyStateEnum.FORCED),
            (PlyStateEnum.MISSING, PlyStateEnum.FORCED, PlyStateEnum.PLACED),
            (PlyStateEnum.MISSING, PlyStateEnum.FORCED, PlyStateEnum.FORCED),
            (PlyStateEnum.MISSING, PlyStateEnum.PLACED, PlyStateEnum.MISSING),
            (PlyStateEnum.MISSING, PlyStateEnum.MISSING, PlyStateEnum.PLACED),
            (PlyStateEnum.MISSING, PlyStateEnum.MISSING, PlyStateEnum.MISSING),
            (PlyStateEnum.MISSING, PlyStateEnum.FORCED, PlyStateEnum.MISSING),
            (PlyStateEnum.MISSING, PlyStateEnum.MISSING, PlyStateEnum.FORCED),
            (PlyStateEnum.MISSING, PlyStateEnum.FORCED, PlyStateEnum.COVERED),
            (PlyStateEnum.MISSING, PlyStateEnum.COVERED, PlyStateEnum.FORCED),
            (PlyStateEnum.MISSING, PlyStateEnum.COVERED, PlyStateEnum.MISSING),
            (PlyStateEnum.MISSING, PlyStateEnum.MISSING, PlyStateEnum.COVERED),
        ]
    )
    async def test_should_not_undo_ply_of_placed_type_when_next_plies_has_dependency_on_ply_to_undo(
            self, mocker, first_ply_to_undo_state, second_ply_state, third_ply_state):
        # GIVEN
        messaging_wrapper = mocker.patch("app.decision_maker.MessagingWrapper", new_callable=AsyncMock)
        first_ply_to_undo = PlyState("P1", state=first_ply_to_undo_state)
        second_ply = PlyState("P2", state=second_ply_state)
        third_ply = PlyState("P3", state=third_ply_state)
        state_plies = {first_ply_to_undo, second_ply, third_ply}
        mould_state = MouldState(state_plies)
        graph_data = {
            "plies": {
                "P1": {"previous_plies": [], "edges_covered": [], "edges": ["P1.1", "P1.2"]},
                "P2": {"previous_plies": ["P1"], "edges_covered": ["P1.1"], "edges": ["P2.1", "P2.2"]},
                "P3": {"previous_plies": ["P1"], "edges_covered": ["P1.2"], "edges": ["P3.1", "P3.2"]},
            }
        }
        decision_maker = DecisionMaker(Mock(), messaging_wrapper, Mock(), mould_state)
        decision_maker._sub_graph = Graph(graph_data)
        undo_ply_request = create_undo_ply_c2dm_request(ply_id=first_ply_to_undo.id, mould_id="mould_id")

        # AND more methods patched
        process_mould_state_changes = mocker.patch.object(decision_maker, "_process_mould_state_changes")

        # WHEN decision_maker.handle_undo_ply_command is called, assert that an exception is raised
        with pytest.raises(Exception) as exc_info:
            await decision_maker.handle_undo_ply_command(undo_ply_request.payload)

        # THEN an exception of correct type is raised
        assert exc_info.type is ValueError

        error_message = f"Given ply {first_ply_to_undo.id} is not valid to undo, " \
                        f"plies: {[second_ply.id, third_ply.id]} depend on it, undo them first."
        assert exc_info.value.args[0] == error_message

        # AND DecisionMaker._process_mould_state_changes is not called, means execution of the process is aborted
        assert process_mould_state_changes.call_count == 0
        assert process_mould_state_changes.await_count == 0

        # AND first ply is unchanged
        assert mould_state.find_ply(first_ply_to_undo.id) == PlyState("P1", state=first_ply_to_undo_state)

        # AND second ply is unchanged
        assert mould_state.find_ply(second_ply.id) == PlyState("P2", state=second_ply_state)

        # AND third ply is unchanged
        assert mould_state.find_ply(third_ply.id) == PlyState("P3", state=third_ply_state)

    async def test_should_correctly_undo_placed_ply_when_ply_to_undo_has_no_edges_covered_and_no_dependency_on_other_ply(
            self, mocker):
        # GIVEN
        messaging_wrapper = mocker.patch("app.decision_maker.MessagingWrapper", new_callable=AsyncMock)
        state_plies_mock = StatePliesMock()
        first_ply = state_plies_mock.first_ply_partially_covered
        second_ply_to_undo = state_plies_mock.second_ply_placed
        third_ply = state_plies_mock.third_ply_expected
        state_plies = {first_ply, second_ply_to_undo, third_ply}
        mould_state = MouldState(state_plies)
        graph_data = {
            "plies": {
                "P1": {"previous_plies": [], "edges_covered": [], "edges": ["P1.1", "P1.2"]},
                "P2": {"previous_plies": [], "edges_covered": [], "edges": ["P2.1", "P2.2"]},
                "P3": {"previous_plies": ["P2"], "edges_covered": ["P2.2"], "edges": ["P3.1", "P3.2"]},
            }
        }
        decision_maker = DecisionMaker(Mock(), messaging_wrapper, Mock(), mould_state)
        decision_maker._sub_graph = Graph(graph_data)
        undo_ply_request = create_undo_ply_c2dm_request(ply_id=second_ply_to_undo.id, mould_id="mould_id")

        # AND more methods patched
        process_mould_state_changes = mocker.patch.object(decision_maker, "_process_mould_state_changes")

        # WHEN decision_maker.handle_undo_ply_command is called
        await decision_maker.handle_undo_ply_command(undo_ply_request.payload)

        # THEN DecisionMaker._process_mould_state_changes is called
        assert process_mould_state_changes.call_count == 1
        assert process_mould_state_changes.await_count == 1
        call_args = process_mould_state_changes.call_args.args
        assert call_args[0] == {third_ply, second_ply_to_undo}

        # AND old expected ply is removed from local mould state
        assert mould_state.find_ply(third_ply.id) is None

        # AND first ply is unchanged
        assert mould_state.find_ply(first_ply.id) == StatePliesMock().first_ply_partially_covered

        # AND second ply is correctly reset to expected
        result = mould_state.find_ply(second_ply_to_undo.id)
        assert result is not None
        assert result.state == PlyStateEnum.EXPECTED
        assert result.previous_state == PlyStateEnum.PLACED
        assert result.updated_by == "command:undo_ply:force"
        assert result.get_edge("P2.1").state == EdgeStateEnum.MISSING
        assert result.get_edge("P2.2").state == EdgeStateEnum.MISSING
        assert result.get_edge("P2.1").get_cam("cam1").state == EdgeCamStateEnum.NEVER_DETECTED
        assert result.get_edge("P2.2").get_cam("cam1").state == EdgeCamStateEnum.NEVER_DETECTED
        assert result.get_edge("P2.2").get_cam("cam2").state == EdgeCamStateEnum.NEVER_DETECTED

    async def test_should_correctly_undo_upper_layer_placed_ply_when_it_covers_placed_ply_from_other_pallet(
            self, mocker):
        # GIVEN
        messaging_wrapper = mocker.patch("app.decision_maker.MessagingWrapper", new_callable=AsyncMock)
        state_plies_mock = StatePliesMock()
        first_ply = state_plies_mock.first_ply_partially_covered
        second_ply = state_plies_mock.second_ply_partially_covered
        third_ply_to_undo = state_plies_mock.third_ply_placed
        fourth_ply = state_plies_mock.fourth_ply_expected
        fifth_ply = state_plies_mock.fifth_ply_partially_covered
        state_plies = {first_ply, second_ply, third_ply_to_undo, fourth_ply, fifth_ply}
        mould_state = MouldState(state_plies)
        graph_data = {
            "plies": {
                "P1": {"previous_plies": [], "edges_covered": [], "edges": ["P1.1", "P1.2"]},
                "P2": {"previous_plies": ["P1"], "edges_covered": ["P1.2"], "edges": ["P2.1", "P2.2"]},
                "P3": {"previous_plies": ["P2"], "edges_covered": ["P2.2", "P5.1"], "edges": ["P3.1", "P3.2"]},
                "P4": {"previous_plies": ["P3"], "edges_covered": [], "edges": ["P4.1", "P4.2"]},
                "P5": {"previous_plies": [], "edges_covered": [], "edges": ["P5.1", "P5.2"]},
            }
        }
        decision_maker = DecisionMaker(Mock(), messaging_wrapper, Mock(), mould_state)
        decision_maker._sub_graph = Graph(graph_data)
        undo_ply_request = create_undo_ply_c2dm_request(ply_id=third_ply_to_undo.id, mould_id="mould_id")

        # AND more methods patched
        process_mould_state_changes = mocker.patch.object(decision_maker, "_process_mould_state_changes")

        # WHEN decision_maker.handle_undo_ply_command is called
        await decision_maker.handle_undo_ply_command(undo_ply_request.payload)

        # THEN DecisionMaker._process_mould_state_changes is called
        assert process_mould_state_changes.call_count == 1
        assert process_mould_state_changes.await_count == 1
        call_args = process_mould_state_changes.call_args.args
        assert call_args[0] == {second_ply, third_ply_to_undo, fourth_ply, fifth_ply}

        # AND old expected ply is removed from local mould state
        assert mould_state.find_ply(fourth_ply.id) is None

        # AND first ply is unchanged
        assert mould_state.find_ply(first_ply.id) == StatePliesMock().first_ply_partially_covered

        # AND second ply is correctly reset to placed
        result = mould_state.find_ply(second_ply.id)
        assert result is not None
        assert result.state == PlyStateEnum.PLACED
        assert result.previous_state == PlyStateEnum.PLACED
        assert result.updated_by == "command:undo_ply:force"
        assert result.get_edge("P2.1").state == EdgeStateEnum.DETECTED
        assert result.get_edge("P2.2").state == EdgeStateEnum.DETECTED
        assert result.get_edge("P2.1").get_cam("cam1").state == EdgeCamStateEnum.DETECTED
        assert result.get_edge("P2.2").get_cam("cam1").state == EdgeCamStateEnum.DETECTED
        assert result.get_edge("P2.2").get_cam("cam2").state == EdgeCamStateEnum.NEVER_DETECTED

        # AND third ply is correctly reset to expected
        result = mould_state.find_ply(third_ply_to_undo.id)
        assert result is not None
        assert result.state == PlyStateEnum.EXPECTED
        assert result.previous_state == PlyStateEnum.PLACED
        assert result.updated_by == "command:undo_ply:force"
        assert result.get_edge("P3.1").state == EdgeStateEnum.MISSING
        assert result.get_edge("P3.2").state == EdgeStateEnum.MISSING
        assert result.get_edge("P3.1").get_cam("cam2").state == EdgeCamStateEnum.NEVER_DETECTED
        assert result.get_edge("P3.2").get_cam("cam2").state == EdgeCamStateEnum.NEVER_DETECTED
        assert result.get_edge("P3.2").get_cam("cam3").state == EdgeCamStateEnum.NEVER_DETECTED

        # AND fifth ply is correctly reset to placed
        result = mould_state.find_ply(fifth_ply.id)
        assert result is not None
        assert result.state == PlyStateEnum.PLACED
        assert result.previous_state == PlyStateEnum.EXPECTED
        assert result.updated_by == "command:undo_ply:force"
        assert result.get_edge("P5.1").state == EdgeStateEnum.DETECTED
        assert result.get_edge("P5.2").state == EdgeStateEnum.DETECTED
        assert result.get_edge("P5.1").get_cam("cam2").state == EdgeCamStateEnum.DETECTED
        assert result.get_edge("P5.2").get_cam("cam2").state == EdgeCamStateEnum.DETECTED

    async def test_should_correctly_undo_upper_layer_placed_ply_when_it_covers_expected_ply_from_other_pallet(
            self, mocker):
        # GIVEN
        messaging_wrapper = mocker.patch("app.decision_maker.MessagingWrapper", new_callable=AsyncMock)
        state_plies_mock = StatePliesMock()
        first_ply = state_plies_mock.first_ply_partially_covered
        second_ply = state_plies_mock.second_ply_partially_covered
        third_ply_to_undo = state_plies_mock.third_ply_placed
        fourth_ply = state_plies_mock.fourth_ply_expected
        fifth_ply = state_plies_mock.fifth_ply_expected
        state_plies = {first_ply, second_ply, third_ply_to_undo, fourth_ply, fifth_ply}
        mould_state = MouldState(state_plies)
        graph_data = {
            "plies": {
                "P1": {"previous_plies": [], "edges_covered": [], "edges": ["P1.1", "P1.2"]},
                "P2": {"previous_plies": ["P1"], "edges_covered": ["P1.2"], "edges": ["P2.1", "P2.2"]},
                "P3": {"previous_plies": ["P2"], "edges_covered": ["P2.2", "P5.1"], "edges": ["P3.1", "P3.2"]},
                "P4": {"previous_plies": ["P3"], "edges_covered": [], "edges": ["P4.1", "P4.2"]},
                "P5": {"previous_plies": [], "edges_covered": [], "edges": ["P5.1", "P5.2"]},
            }
        }
        decision_maker = DecisionMaker(Mock(), messaging_wrapper, Mock(), mould_state)
        decision_maker._sub_graph = Graph(graph_data)
        undo_ply_request = create_undo_ply_c2dm_request(ply_id=third_ply_to_undo.id, mould_id="mould_id")

        # AND more methods patched
        process_mould_state_changes = mocker.patch.object(decision_maker, "_process_mould_state_changes")

        # WHEN decision_maker.handle_undo_ply_command is called
        await decision_maker.handle_undo_ply_command(undo_ply_request.payload)

        # THEN DecisionMaker._process_mould_state_changes is called
        assert process_mould_state_changes.call_count == 1
        assert process_mould_state_changes.await_count == 1
        call_args = process_mould_state_changes.call_args.args
        assert call_args[0] == {second_ply, third_ply_to_undo, fourth_ply}

        # AND old expected ply is removed from local mould state
        assert mould_state.find_ply(fourth_ply.id) is None

        # AND first ply is unchanged
        assert mould_state.find_ply(first_ply.id) == StatePliesMock().first_ply_partially_covered

        # AND second ply is correctly reset to placed
        result = mould_state.find_ply(second_ply.id)
        assert result is not None
        assert result.state == PlyStateEnum.PLACED
        assert result.previous_state == PlyStateEnum.PLACED
        assert result.updated_by == "command:undo_ply:force"
        assert result.get_edge("P2.1").state == EdgeStateEnum.DETECTED
        assert result.get_edge("P2.2").state == EdgeStateEnum.DETECTED
        assert result.get_edge("P2.1").get_cam("cam1").state == EdgeCamStateEnum.DETECTED
        assert result.get_edge("P2.2").get_cam("cam1").state == EdgeCamStateEnum.DETECTED
        assert result.get_edge("P2.2").get_cam("cam2").state == EdgeCamStateEnum.NEVER_DETECTED

        # AND third ply is correctly reset to expected
        result = mould_state.find_ply(third_ply_to_undo.id)
        assert result is not None
        assert result.state == PlyStateEnum.EXPECTED
        assert result.previous_state == PlyStateEnum.PLACED
        assert result.updated_by == "command:undo_ply:force"
        assert result.get_edge("P3.1").state == EdgeStateEnum.MISSING
        assert result.get_edge("P3.2").state == EdgeStateEnum.MISSING
        assert result.get_edge("P3.1").get_cam("cam2").state == EdgeCamStateEnum.NEVER_DETECTED
        assert result.get_edge("P3.2").get_cam("cam2").state == EdgeCamStateEnum.NEVER_DETECTED
        assert result.get_edge("P3.2").get_cam("cam3").state == EdgeCamStateEnum.NEVER_DETECTED

        # AND fifth ply is unchanged
        assert mould_state.find_ply(fifth_ply.id) == StatePliesMock().fifth_ply_expected

    async def test_should_correctly_undo_upper_layer_placed_ply_when_its_covered_edges_and_previous_plies_differ(
            self, mocker):
        # GIVEN
        messaging_wrapper = mocker.patch("app.decision_maker.MessagingWrapper", new_callable=AsyncMock)
        state_plies_mock = StatePliesMock()
        first_ply = state_plies_mock.first_ply_partially_covered
        second_ply = state_plies_mock.second_ply_fully_covered
        third_ply = state_plies_mock.third_ply_fully_covered
        fourth_ply_to_undo = state_plies_mock.fourth_ply_placed
        fifth_ply = state_plies_mock.fifth_ply_expected
        state_plies = {first_ply, second_ply, third_ply, fourth_ply_to_undo, fifth_ply}
        mould_state = MouldState(state_plies)
        graph_data = {
            "plies": {
                "P1": {"previous_plies": [], "edges_covered": [], "edges": ["P1.1", "P1.2"]},
                "P2": {"previous_plies": ["P1"], "edges_covered": ["P1.2"], "edges": ["P2.1", "P2.2"]},
                "P3": {"previous_plies": ["P2"], "edges_covered": ["P2.2"], "edges": ["P3.1", "P3.2"]},
                "P4": {"previous_plies": ["P3"], "edges_covered": ["P2.1", "P3.1", "P3.2"], "edges": ["P4.1", "P4.2"]},
                "P5": {"previous_plies": ["P4"], "edges_covered": ["P4.2"], "edges": ["P5.1", "P5.2"]},
            }
        }
        decision_maker = DecisionMaker(Mock(), messaging_wrapper, Mock(), mould_state)
        decision_maker._sub_graph = Graph(graph_data)
        undo_ply_request = create_undo_ply_c2dm_request(ply_id=fourth_ply_to_undo.id, mould_id="mould_id")

        # AND more methods patched
        process_mould_state_changes = mocker.patch.object(decision_maker, "_process_mould_state_changes")

        # WHEN decision_maker.handle_undo_ply_command is called
        await decision_maker.handle_undo_ply_command(undo_ply_request.payload)

        # THEN DecisionMaker._process_mould_state_changes is called
        assert process_mould_state_changes.call_count == 1
        assert process_mould_state_changes.await_count == 1
        call_args = process_mould_state_changes.call_args.args
        assert call_args[0] == {fourth_ply_to_undo, third_ply, second_ply, fifth_ply}

        # AND old expected ply is removed from local mould state
        assert mould_state.find_ply(fifth_ply.id) is None

        # AND first ply is unchanged
        assert mould_state.find_ply(first_ply.id) == StatePliesMock().first_ply_partially_covered

        # AND second ply is correctly reset to placed
        result = mould_state.find_ply(second_ply.id)
        assert result is not None
        assert result.state == PlyStateEnum.PLACED
        assert result.previous_state == PlyStateEnum.COVERED
        assert result.updated_by == "command:undo_ply:force"
        assert result.get_edge("P2.1").state == EdgeStateEnum.DETECTED
        assert result.get_edge("P2.2").state == EdgeStateEnum.COVERED
        assert result.get_edge("P2.1").get_cam("cam1").state == EdgeCamStateEnum.DETECTED
        assert result.get_edge("P2.2").get_cam("cam1").state == EdgeCamStateEnum.DETECTED
        assert result.get_edge("P2.2").get_cam("cam2").state == EdgeCamStateEnum.NEVER_DETECTED

        # AND third ply is correctly reset to placed
        result = mould_state.find_ply(third_ply.id)
        assert result is not None
        assert result.state == PlyStateEnum.PLACED
        assert result.previous_state == PlyStateEnum.COVERED
        assert result.updated_by == "command:undo_ply:force"
        assert result.get_edge("P3.1").state == EdgeStateEnum.DETECTED
        assert result.get_edge("P3.2").state == EdgeStateEnum.DETECTED
        assert result.get_edge("P3.1").get_cam("cam2").state == EdgeCamStateEnum.DETECTED
        assert result.get_edge("P3.2").get_cam("cam2").state == EdgeCamStateEnum.DETECTED
        assert result.get_edge("P3.2").get_cam("cam3").state == EdgeCamStateEnum.NEVER_DETECTED

        # AND fourth ply is correctly reset to expected
        result = mould_state.find_ply(fourth_ply_to_undo.id)
        assert result is not None
        assert result.state == PlyStateEnum.EXPECTED
        assert result.previous_state == PlyStateEnum.PLACED
        assert result.updated_by == "command:undo_ply:force"
        assert result.get_edge("P4.1").state == EdgeStateEnum.MISSING
        assert result.get_edge("P4.2").state == EdgeStateEnum.MISSING
        assert result.get_edge("P4.1").get_cam("cam2").state == EdgeCamStateEnum.NEVER_DETECTED
        assert result.get_edge("P4.2").get_cam("cam2").state == EdgeCamStateEnum.NEVER_DETECTED

    async def test_should_correctly_undo_upper_layer_placed_ply_when_its_covered_edges_and_previous_plies_dont_match(
            self, mocker):
        # GIVEN
        messaging_wrapper = mocker.patch("app.decision_maker.MessagingWrapper", new_callable=AsyncMock)
        state_plies_mock = StatePliesMock()
        first_ply = state_plies_mock.first_ply_fully_covered
        second_ply = state_plies_mock.second_ply_fully_covered
        third_ply = state_plies_mock.third_ply_placed
        fourth_ply_to_undo = state_plies_mock.fourth_ply_placed
        fifth_ply = state_plies_mock.fifth_ply_expected
        state_plies = {first_ply, second_ply, third_ply, fourth_ply_to_undo, fifth_ply}
        mould_state = MouldState(state_plies)
        graph_data = {
            "plies": {
                "P1": {"previous_plies": [], "edges_covered": [], "edges": ["P1.1", "P1.2"]},
                "P2": {"previous_plies": ["P1"], "edges_covered": ["P1.2"], "edges": ["P2.1", "P2.2"]},
                "P3": {"previous_plies": ["P2"], "edges_covered": ["P2.2"], "edges": ["P3.1", "P3.2"]},
                "P4": {"previous_plies": ["P3"], "edges_covered": ["P1.1", "P2.1"], "edges": ["P4.1", "P4.2"]},
                "P5": {"previous_plies": ["P4"], "edges_covered": ["P4.2"], "edges": ["P5.1", "P5.2"]},
            }
        }
        decision_maker = DecisionMaker(Mock(), messaging_wrapper, Mock(), mould_state)
        decision_maker._sub_graph = Graph(graph_data)
        undo_ply_request = create_undo_ply_c2dm_request(ply_id=fourth_ply_to_undo.id, mould_id="mould_id")

        # AND more methods patched
        process_mould_state_changes = mocker.patch.object(decision_maker, "_process_mould_state_changes")

        # WHEN decision_maker.handle_undo_ply_command is called
        await decision_maker.handle_undo_ply_command(undo_ply_request.payload)

        # THEN DecisionMaker._process_mould_state_changes is called
        assert process_mould_state_changes.call_count == 1
        assert process_mould_state_changes.await_count == 1
        call_args = process_mould_state_changes.call_args.args
        assert call_args[0] == {fifth_ply, fourth_ply_to_undo, second_ply, first_ply}

        # AND old expected ply is removed from local mould state
        assert mould_state.find_ply(fifth_ply.id) is None

        # AND first ply is correctly reset to placed
        result = mould_state.find_ply(first_ply.id)
        assert result is not None
        assert result.state == PlyStateEnum.PLACED
        assert result.previous_state == PlyStateEnum.COVERED
        assert result.updated_by == "command:undo_ply:force"
        assert result.get_edge("P1.1").state == EdgeStateEnum.DETECTED
        assert result.get_edge("P1.2").state == EdgeStateEnum.COVERED
        assert result.get_edge("P1.1").get_cam("cam1").state == EdgeCamStateEnum.DETECTED
        assert result.get_edge("P1.2").get_cam("cam1").state == EdgeCamStateEnum.DETECTED

        # AND second ply is correctly reset to placed
        result = mould_state.find_ply(second_ply.id)
        assert result is not None
        assert result.state == PlyStateEnum.PLACED
        assert result.previous_state == PlyStateEnum.COVERED
        assert result.updated_by == "command:undo_ply:force"
        assert result.get_edge("P2.1").state == EdgeStateEnum.DETECTED
        assert result.get_edge("P2.2").state == EdgeStateEnum.COVERED
        assert result.get_edge("P2.1").get_cam("cam1").state == EdgeCamStateEnum.DETECTED
        assert result.get_edge("P2.2").get_cam("cam1").state == EdgeCamStateEnum.DETECTED
        assert result.get_edge("P2.2").get_cam("cam2").state == EdgeCamStateEnum.NEVER_DETECTED

        # AND third ply is unchanged
        assert mould_state.find_ply(third_ply.id) == StatePliesMock().third_ply_placed

        # AND fourth ply is correctly reset to expected
        result = mould_state.find_ply(fourth_ply_to_undo.id)
        assert result is not None
        assert result.state == PlyStateEnum.EXPECTED
        assert result.previous_state == PlyStateEnum.PLACED
        assert result.updated_by == "command:undo_ply:force"
        assert result.get_edge("P4.1").state == EdgeStateEnum.MISSING
        assert result.get_edge("P4.2").state == EdgeStateEnum.MISSING
        assert result.get_edge("P4.1").get_cam("cam2").state == EdgeCamStateEnum.NEVER_DETECTED
        assert result.get_edge("P4.2").get_cam("cam2").state == EdgeCamStateEnum.NEVER_DETECTED

    async def test_should_correctly_undo_placed_ply_when_it_is_in_the_last_correctly_placed_ply_of_the_pallet(
            self, mocker):
        # GIVEN
        messaging_wrapper = mocker.patch("app.decision_maker.MessagingWrapper", new_callable=AsyncMock)
        state_plies_mock = StatePliesMock()
        first_ply = state_plies_mock.first_ply_partially_covered
        second_ply = state_plies_mock.second_ply_partially_covered
        third_ply_to_undo = state_plies_mock.third_ply_placed
        state_plies = {first_ply, second_ply, third_ply_to_undo}
        mould_state = MouldState(state_plies)
        graph_data = {
            "plies": {
                "P1": {"previous_plies": [], "edges_covered": [], "edges": ["P1.1", "P1.2"]},
                "P2": {"previous_plies": ["P1"], "edges_covered": ["P1.2"], "edges": ["P2.1", "P2.2"]},
                "P3": {"previous_plies": ["P2"], "edges_covered": ["P2.2"], "edges": ["P3.1", "P3.2"]},
            }
        }
        decision_maker = DecisionMaker(Mock(), messaging_wrapper, Mock(), mould_state)
        decision_maker._sub_graph = Graph(graph_data)
        undo_ply_request = create_undo_ply_c2dm_request(ply_id=third_ply_to_undo.id, mould_id="mould_id")

        # AND more methods patched
        process_mould_state_changes = mocker.patch.object(decision_maker, "_process_mould_state_changes")

        # WHEN decision_maker.handle_undo_ply_command is called
        await decision_maker.handle_undo_ply_command(undo_ply_request.payload)

        # THEN DecisionMaker._process_mould_state_changes is called
        assert process_mould_state_changes.call_count == 1
        assert process_mould_state_changes.await_count == 1
        call_args = process_mould_state_changes.call_args.args
        assert call_args[0] == {second_ply, third_ply_to_undo}

        # AND first ply is unchanged
        assert mould_state.find_ply(first_ply.id) == StatePliesMock().first_ply_partially_covered

        # AND second ply is correctly reset to placed
        result = mould_state.find_ply(second_ply.id)
        assert result is not None
        assert result.state == PlyStateEnum.PLACED
        assert result.previous_state == PlyStateEnum.PLACED
        assert result.updated_by == "command:undo_ply:force"
        assert result.get_edge("P2.1").state == EdgeStateEnum.DETECTED
        assert result.get_edge("P2.2").state == EdgeStateEnum.DETECTED
        assert result.get_edge("P2.1").get_cam("cam1").state == EdgeCamStateEnum.DETECTED
        assert result.get_edge("P2.2").get_cam("cam1").state == EdgeCamStateEnum.DETECTED
        assert result.get_edge("P2.2").get_cam("cam2").state == EdgeCamStateEnum.NEVER_DETECTED

        # AND third ply is correctly reset to expected
        result = mould_state.find_ply(third_ply_to_undo.id)
        assert result is not None
        assert result.state == PlyStateEnum.EXPECTED
        assert result.previous_state == PlyStateEnum.PLACED
        assert result.updated_by == "command:undo_ply:force"
        assert result.get_edge("P3.1").state == EdgeStateEnum.MISSING
        assert result.get_edge("P3.2").state == EdgeStateEnum.MISSING
        assert result.get_edge("P3.1").get_cam("cam2").state == EdgeCamStateEnum.NEVER_DETECTED
        assert result.get_edge("P3.2").get_cam("cam2").state == EdgeCamStateEnum.NEVER_DETECTED
        assert result.get_edge("P3.2").get_cam("cam3").state == EdgeCamStateEnum.NEVER_DETECTED

    async def test_should_correctly_undo_missing_ply_when_it_is_in_the_last_correctly_placed_ply_of_the_pallet(
            self, mocker):
        # GIVEN
        messaging_wrapper = mocker.patch("app.decision_maker.MessagingWrapper", new_callable=AsyncMock)
        state_plies_mock = StatePliesMock()
        first_ply = state_plies_mock.first_ply_partially_covered
        second_ply = state_plies_mock.second_ply_partially_covered
        third_ply_to_undo = state_plies_mock.third_ply_missing
        state_plies = {first_ply, second_ply, third_ply_to_undo}
        mould_state = MouldState(state_plies)
        graph_data = {
            "plies": {
                "P1": {"previous_plies": [], "edges_covered": [], "edges": ["P1.1", "P1.2"]},
                "P2": {"previous_plies": ["P1"], "edges_covered": ["P1.2"], "edges": ["P2.1", "P2.2"]},
                "P3": {"previous_plies": ["P2"], "edges_covered": ["P2.2"], "edges": ["P3.1", "P3.2"]},
            }
        }
        decision_maker = DecisionMaker(Mock(), messaging_wrapper, Mock(), mould_state)
        decision_maker._sub_graph = Graph(graph_data)
        undo_ply_request = create_undo_ply_c2dm_request(ply_id=third_ply_to_undo.id, mould_id="mould_id")

        # AND more methods patched
        process_mould_state_changes = mocker.patch.object(decision_maker, "_process_mould_state_changes")

        # WHEN decision_maker.handle_undo_ply_command is called
        await decision_maker.handle_undo_ply_command(undo_ply_request.payload)

        # THEN DecisionMaker._process_mould_state_changes is called
        assert process_mould_state_changes.call_count == 1
        assert process_mould_state_changes.await_count == 1
        call_args = process_mould_state_changes.call_args.args
        assert call_args[0] == {second_ply, third_ply_to_undo}

        # AND first ply is unchanged
        assert mould_state.find_ply(first_ply.id) == StatePliesMock().first_ply_partially_covered

        # AND second ply is correctly reset to placed
        result = mould_state.find_ply(second_ply.id)
        assert result is not None
        assert result.state == PlyStateEnum.PLACED
        assert result.previous_state == PlyStateEnum.PLACED
        assert result.updated_by == "command:undo_ply:force"
        assert result.get_edge("P2.1").state == EdgeStateEnum.DETECTED
        assert result.get_edge("P2.2").state == EdgeStateEnum.DETECTED
        assert result.get_edge("P2.1").get_cam("cam1").state == EdgeCamStateEnum.DETECTED
        assert result.get_edge("P2.2").get_cam("cam1").state == EdgeCamStateEnum.DETECTED
        assert result.get_edge("P2.2").get_cam("cam2").state == EdgeCamStateEnum.NEVER_DETECTED

        # AND third ply is correctly reset to expected
        result = mould_state.find_ply(third_ply_to_undo.id)
        assert result is not None
        assert result.state == PlyStateEnum.EXPECTED
        assert result.previous_state == PlyStateEnum.MISSING
        assert result.updated_by == "command:undo_ply:force"
        assert result.get_edge("P3.1").state == EdgeStateEnum.MISSING
        assert result.get_edge("P3.2").state == EdgeStateEnum.MISSING
        assert result.get_edge("P3.1").get_cam("cam2").state == EdgeCamStateEnum.NEVER_DETECTED
        assert result.get_edge("P3.2").get_cam("cam2").state == EdgeCamStateEnum.NEVER_DETECTED
        assert result.get_edge("P3.2").get_cam("cam3").state == EdgeCamStateEnum.NEVER_DETECTED

    async def test_should_correctly_undo_forced_ply_when_it_is_in_the_last_correctly_placed_ply_of_the_pallet(
            self, mocker):
        # GIVEN
        messaging_wrapper = mocker.patch("app.decision_maker.MessagingWrapper", new_callable=AsyncMock)
        state_plies_mock = StatePliesMock()
        first_ply = state_plies_mock.first_ply_partially_covered
        second_ply = state_plies_mock.second_ply_partially_covered
        third_ply_to_undo = state_plies_mock.third_ply_forced_expected
        state_plies = {first_ply, second_ply, third_ply_to_undo}
        mould_state = MouldState(state_plies)
        graph_data = {
            "plies": {
                "P1": {"previous_plies": [], "edges_covered": [], "edges": ["P1.1", "P1.2"]},
                "P2": {"previous_plies": ["P1"], "edges_covered": ["P1.2"], "edges": ["P2.1", "P2.2"]},
                "P3": {"previous_plies": ["P2"], "edges_covered": ["P2.2"], "edges": ["P3.1", "P3.2"]},
            }
        }
        decision_maker = DecisionMaker(Mock(), messaging_wrapper, Mock(), mould_state)
        decision_maker._sub_graph = Graph(graph_data)
        undo_ply_request = create_undo_ply_c2dm_request(ply_id=third_ply_to_undo.id, mould_id="mould_id")

        # AND more methods patched
        process_mould_state_changes = mocker.patch.object(decision_maker, "_process_mould_state_changes")

        # WHEN decision_maker.handle_undo_ply_command is called
        await decision_maker.handle_undo_ply_command(undo_ply_request.payload)

        # THEN DecisionMaker._process_mould_state_changes is called
        assert process_mould_state_changes.call_count == 1
        assert process_mould_state_changes.await_count == 1
        call_args = process_mould_state_changes.call_args.args
        assert call_args[0] == {second_ply, third_ply_to_undo}

        # AND first ply is unchanged
        assert mould_state.find_ply(first_ply.id) == StatePliesMock().first_ply_partially_covered

        # AND second ply is correctly reset to placed
        result = mould_state.find_ply(second_ply.id)
        assert result is not None
        assert result.state == PlyStateEnum.PLACED
        assert result.previous_state == PlyStateEnum.PLACED
        assert result.updated_by == "command:undo_ply:force"
        assert result.get_edge("P2.1").state == EdgeStateEnum.DETECTED
        assert result.get_edge("P2.2").state == EdgeStateEnum.DETECTED
        assert result.get_edge("P2.1").get_cam("cam1").state == EdgeCamStateEnum.DETECTED
        assert result.get_edge("P2.2").get_cam("cam1").state == EdgeCamStateEnum.DETECTED
        assert result.get_edge("P2.2").get_cam("cam2").state == EdgeCamStateEnum.NEVER_DETECTED

        # AND third ply is correctly reset to expected
        result = mould_state.find_ply(third_ply_to_undo.id)
        assert result is not None
        assert result.state == PlyStateEnum.EXPECTED
        assert result.previous_state == PlyStateEnum.FORCED
        assert result.updated_by == "command:undo_ply:force"
        assert result.get_edge("P3.1").state == EdgeStateEnum.MISSING
        assert result.get_edge("P3.2").state == EdgeStateEnum.MISSING
        assert result.get_edge("P3.1").get_cam("cam2").state == EdgeCamStateEnum.NEVER_DETECTED
        assert result.get_edge("P3.2").get_cam("cam2").state == EdgeCamStateEnum.NEVER_DETECTED
        assert result.get_edge("P3.2").get_cam("cam3").state == EdgeCamStateEnum.NEVER_DETECTED

    async def test_should_correctly_undo_forced_phantom_ply_when_it_is_in_the_last_correctly_placed_ply_of_the_pallet(
            self, mocker):
        # GIVEN
        messaging_wrapper = mocker.patch("app.decision_maker.MessagingWrapper", new_callable=AsyncMock)
        state_plies_mock = StatePliesMock()
        first_ply = state_plies_mock.first_ply_partially_covered
        second_ply = state_plies_mock.second_ply_partially_covered
        third_ply_to_undo = state_plies_mock.third_ply_phantom_forced
        state_plies = {first_ply, second_ply, third_ply_to_undo}
        mould_state = MouldState(state_plies)
        graph_data = {
            "plies": {
                "P1": {"previous_plies": [], "edges_covered": [], "edges": ["P1.1", "P1.2"]},
                "P2": {"previous_plies": ["P1"], "edges_covered": ["P1.2"], "edges": ["P2.1", "P2.2"]},
                "P3": {"previous_plies": ["P2"], "edges_covered": ["P2.2"], "edges": []},
            }
        }
        decision_maker = DecisionMaker(Mock(), messaging_wrapper, Mock(), mould_state)
        decision_maker._sub_graph = Graph(graph_data)
        undo_ply_request = create_undo_ply_c2dm_request(ply_id=third_ply_to_undo.id, mould_id="mould_id")

        # AND more methods patched
        process_mould_state_changes = mocker.patch.object(decision_maker, "_process_mould_state_changes")

        # WHEN decision_maker.handle_undo_ply_command is called
        await decision_maker.handle_undo_ply_command(undo_ply_request.payload)

        # THEN DecisionMaker._process_mould_state_changes is called
        assert process_mould_state_changes.call_count == 1
        assert process_mould_state_changes.await_count == 1
        call_args = process_mould_state_changes.call_args.args
        assert call_args[0] == {second_ply, third_ply_to_undo}

        # AND first ply is unchanged
        assert mould_state.find_ply(first_ply.id) == StatePliesMock().first_ply_partially_covered

        # AND second ply is correctly reset to placed
        result = mould_state.find_ply(second_ply.id)
        assert result is not None
        assert result.state == PlyStateEnum.PLACED
        assert result.previous_state == PlyStateEnum.PLACED
        assert result.updated_by == "command:undo_ply:force"
        assert result.get_edge("P2.1").state == EdgeStateEnum.DETECTED
        assert result.get_edge("P2.2").state == EdgeStateEnum.DETECTED
        assert result.get_edge("P2.1").get_cam("cam1").state == EdgeCamStateEnum.DETECTED
        assert result.get_edge("P2.2").get_cam("cam1").state == EdgeCamStateEnum.DETECTED
        assert result.get_edge("P2.2").get_cam("cam2").state == EdgeCamStateEnum.NEVER_DETECTED

        # AND third ply is correctly reset to expected
        result = mould_state.find_ply(third_ply_to_undo.id)
        assert result is not None
        assert result.state == PlyStateEnum.EXPECTED
        assert result.previous_state == PlyStateEnum.FORCED
        assert result.updated_by == "command:undo_ply:force"
        assert result.edges == set()


@pytest.mark.asyncio
@patch("app.config.MOULD_ID", "mould_id")
class HandleRecheckPlyCommandTests:
    @pytest.mark.parametrize("ply_state", [PlyStateEnum.PLACED, PlyStateEnum.MISSING])
    async def test_should_not_abort_recheck_ply_command_handling_when_non_covered_ply_given(self, mocker, ply_state):
        # GIVEN
        messaging_wrapper = mocker.patch("app.decision_maker.MessagingWrapper", new_callable=AsyncMock)
        ply_to_recheck_id = "ply_to_recheck_id"
        state_plies = {PlyState(ply_to_recheck_id, state=ply_state)}
        mould_state = MouldState(copy.deepcopy(state_plies))
        decision_maker = DecisionMaker(Mock(), messaging_wrapper, Mock(), mould_state)
        recheck_ply_request = create_recheck_ply_c2dm_request(ply_id=ply_to_recheck_id, mould_id="mould_id")

        # AND more methods patched
        process_mould_state_changes = mocker.patch.object(decision_maker, "_process_mould_state_changes")
        mocker.patch.object(decision_maker, "_sub_graph", set())

        # WHEN decision_maker.handle_recheck_ply_command is called
        await decision_maker.handle_recheck_ply_command(recheck_ply_request.payload)

        # THEN DecisionMaker._process_mould_state_changes is called, means execution of the process is not aborted
        assert process_mould_state_changes.call_count == 1
        assert process_mould_state_changes.await_count == 1

    @pytest.mark.parametrize("ply_state", [PlyStateEnum.EXPECTED, PlyStateEnum.COVERED])
    async def test_should_raise_exception_and_abort_ply_to_recheck_command_handling_when_covered_ply_given(
            self, mocker, ply_state):
        # GIVEN
        messaging_wrapper = mocker.patch("app.decision_maker.MessagingWrapper", new_callable=AsyncMock)
        ply_to_recheck_id = "ply_to_recheck_id"
        state_plies = {PlyState(ply_to_recheck_id, state=ply_state)}
        mould_state = MouldState(copy.deepcopy(state_plies))
        decision_maker = DecisionMaker(Mock(), messaging_wrapper, Mock(), mould_state)
        ply_to_recheck_request = create_recheck_ply_c2dm_request(ply_id=ply_to_recheck_id, mould_id="mould_id")

        # AND more methods patched
        process_mould_state_changes = mocker.patch.object(decision_maker, "_process_mould_state_changes")

        # WHEN decision_maker.handle_recheck_ply_command is called, assert that an exception is raised
        with pytest.raises(Exception) as exc_info:
            await decision_maker.handle_recheck_ply_command(ply_to_recheck_request.payload)

        # THEN an exception of correct type is raised
        assert exc_info.type is ValueError

        error_message = f"Given ply {ply_to_recheck_id} is not valid ply to recheck, " \
                        f"it must be not {ply_state.name} ply."
        assert exc_info.value.args[0] == error_message

        # AND DecisionMaker._process_mould_state_changes is not called, means execution of the process is aborted
        assert process_mould_state_changes.call_count == 0
        assert process_mould_state_changes.await_count == 0

    async def test_should_raise_exception_and_abort_ply_to_recheck_command_handling_when_non_existing_ply_id_given(
            self, mocker):
        # GIVEN
        messaging_wrapper = mocker.patch("app.decision_maker.MessagingWrapper", new_callable=AsyncMock)
        ply_to_recheck_id = "NON_EXISTING_PLY_ID"
        state_plies = {PlyState("P1", state=PlyStateEnum.PLACED)}
        mould_state = MouldState(copy.deepcopy(state_plies))
        decision_maker = DecisionMaker(Mock(), messaging_wrapper, Mock(), mould_state)
        ply_to_recheck_request = create_recheck_ply_c2dm_request(ply_id=ply_to_recheck_id, mould_id="mould_id")

        # AND more methods patched
        process_mould_state_changes = mocker.patch.object(decision_maker, "_process_mould_state_changes")

        # WHEN decision_maker.handle_recheck_ply_command is called, assert that an exception is raised
        with pytest.raises(Exception) as exc_info:
            await decision_maker.handle_recheck_ply_command(ply_to_recheck_request.payload)

        # THEN an exception of correct type is raised
        assert exc_info.type is ValueError

        error_message = f"Failed to get ply in mould state by given ply_id: {ply_to_recheck_id}"
        assert exc_info.value.args[0] == error_message

        # AND DecisionMaker._process_mould_state_changes is not called, means execution of the process is aborted
        assert process_mould_state_changes.call_count == 0
        assert process_mould_state_changes.await_count == 0

    @pytest.mark.parametrize(
        "edge_1_state, edge_2_state",
        [
            (EdgeStateEnum.DETECTED, EdgeStateEnum.DETECTED),
            (EdgeStateEnum.MISSING, EdgeStateEnum.MISSING),
            (EdgeStateEnum.MISSING, EdgeStateEnum.DETECTED),
            (EdgeStateEnum.DETECTED, EdgeStateEnum.MISSING),
            (EdgeStateEnum.FORCED, EdgeStateEnum.FORCED),
        ]
    )
    async def test_should_correctly_reset_ply_when_both_ply_edges_uncovered(self, mocker, edge_1_state, edge_2_state):
        # GIVEN
        messaging_wrapper = mocker.patch("app.decision_maker.MessagingWrapper", new_callable=AsyncMock)
        ply_to_recheck_id = "P1"
        ply_to_recheck = PlyState(ply_to_recheck_id,
                                  state=PlyStateEnum.PLACED,
                                  edges={EdgeState("P1.1",
                                                   cams={EdgeCamState("cam1", EdgeCamStateEnum.DETECTED)},
                                                   state=edge_1_state),
                                         EdgeState("P1.2",
                                                   cams={EdgeCamState("cam1", EdgeCamStateEnum.DETECTED)},
                                                   state=edge_2_state)})
        state_plies = {ply_to_recheck}
        mould_state = MouldState(state_plies)
        decision_maker = DecisionMaker(Mock(), messaging_wrapper, Mock(), mould_state)
        ply_to_recheck_request = create_recheck_ply_c2dm_request(ply_id=ply_to_recheck_id, mould_id="mould_id")

        # AND more methods patched
        process_mould_state_changes = mocker.patch.object(decision_maker, "_process_mould_state_changes")

        # WHEN decision_maker.handle_recheck_ply_command is called
        await decision_maker.handle_recheck_ply_command(ply_to_recheck_request.payload)

        # THEN
        assert ply_to_recheck.state == PlyStateEnum.MISSING
        assert {edge.state for edge in ply_to_recheck.edges} == {EdgeStateEnum.MISSING}
        cam_states = set()
        for edge in ply_to_recheck.edges:
            for cam in edge.cams:
                cam_states.add(cam.state)
        assert cam_states == {EdgeCamStateEnum.NEVER_DETECTED}
        assert ply_to_recheck.updated_by == "command:recheck_ply:force"

        # AND
        assert process_mould_state_changes.call_count == 1
        assert process_mould_state_changes.await_count == 1

    @pytest.mark.parametrize(
        "edge_1_state, edge_2_state",
        [
            (EdgeStateEnum.DETECTED, EdgeStateEnum.COVERED),
            (EdgeStateEnum.MISSING, EdgeStateEnum.COVERED),
            (EdgeStateEnum.FORCED, EdgeStateEnum.COVERED),
        ]
    )
    async def test_should_correctly_reset_ply_when_one_ply_edge_covered(self, mocker, edge_1_state, edge_2_state):
        # GIVEN
        messaging_wrapper = mocker.patch("app.decision_maker.MessagingWrapper", new_callable=AsyncMock)
        ply_to_recheck_id = "P1"
        ply_to_recheck = PlyState(ply_to_recheck_id,
                                  state=PlyStateEnum.PLACED,
                                  edges={EdgeState("P1.1",
                                                   cams={EdgeCamState("cam1", EdgeCamStateEnum.DETECTED)},
                                                   state=edge_1_state),
                                         EdgeState("P1.2",
                                                   cams={EdgeCamState("cam1", EdgeCamStateEnum.DETECTED)},
                                                   state=edge_2_state)})
        state_plies = {ply_to_recheck}
        mould_state = MouldState(state_plies)
        decision_maker = DecisionMaker(Mock(), messaging_wrapper, Mock(), mould_state)
        ply_to_recheck_request = create_recheck_ply_c2dm_request(ply_id=ply_to_recheck_id, mould_id="mould_id")

        # AND more methods patched
        process_mould_state_changes = mocker.patch.object(decision_maker, "_process_mould_state_changes")

        # WHEN decision_maker.handle_recheck_ply_command is called
        await decision_maker.handle_recheck_ply_command(ply_to_recheck_request.payload)

        # THEN
        assert ply_to_recheck.state == PlyStateEnum.MISSING
        assert {edge.state for edge in ply_to_recheck.edges} == {EdgeStateEnum.MISSING, EdgeStateEnum.COVERED}
        cam_states = set()
        for edge in ply_to_recheck.edges:
            for cam in edge.cams:
                cam_states.add(cam.state)
        assert cam_states == {EdgeCamStateEnum.NEVER_DETECTED, EdgeCamStateEnum.DETECTED}
        assert ply_to_recheck.updated_by == "command:recheck_ply:force"

        # AND
        assert process_mould_state_changes.call_count == 1
        assert process_mould_state_changes.await_count == 1


@pytest.mark.asyncio
class HandleForcePlyCommandTests:
    async def test_should_correctly_process_mould_state_changes_when_expected_ply_forced(
            self, mocker, sample_edge_to_cameras, sample_instructions_data):
        # GIVEN
        shared_storage = mocker.patch("app.decision_maker.SharedStorage")
        messaging_wrapper = mocker.patch("app.decision_maker.MessagingWrapper", new_callable=AsyncMock)
        mould_id = "mould_id"
        mocker.patch("app.decision_maker.cfg.MOULD_ID", mould_id)
        force_ply_id = "P2"
        force_ply_request = create_force_ply_c2dm_request(force_ply_id, mould_id, "correlation_id")
        team_instructions = TeamInstructions(sample_instructions_data)
        state_plies_mock = StatePliesMock()
        state_plies = {state_plies_mock.first_ply_placed, state_plies_mock.second_ply_expected}
        mould_state = MouldState(copy.deepcopy(state_plies))
        decision_maker = DecisionMaker(shared_storage, messaging_wrapper, team_instructions, mould_state)

        # AND more methods patched
        feedback_invoke = mocker.patch("app.decision_maker.LaserFeedback.invoke")
        graph_data = {
            "plies": {
                "P1": static_graph_data["plies"]["P1"],
                "P2": static_graph_data["plies"]["P2"],
                "P3": static_graph_data["plies"]["P3"],
            }
        }
        graph = Graph(graph_data)
        graph._map_and_cache_layer_to_pallets()
        edge_cameras = EdgeCameras(sample_edge_to_cameras)
        decision_maker._sub_graph = graph
        decision_maker._edge_cameras = edge_cameras

        # WHEN decision_maker.handle_edge_verification_message is called
        await decision_maker.handle_force_ply_command(force_ply_request.payload)

        # THEN local mould state is correctly updated
        result_plies = decision_maker._mould_state.plies
        expected_plies = [
            state_plies_mock.first_ply_partially_covered,
            state_plies_mock.second_ply_forced_expected,
            state_plies_mock.third_ply_expected
        ]
        assert len(result_plies) == len(expected_plies)
        expected_state_plies = sorted([ply.serialize() for ply in expected_plies], key=lambda i: i["ply_id"])
        actual_state_plies = sorted([ply.serialize() for ply in result_plies], key=lambda i: i["ply_id"])
        assert actual_state_plies == expected_state_plies

        # AND Feedback().invoke is called and awaited once with correct argument
        assert feedback_invoke.call_count == 1
        assert feedback_invoke.await_count == 1
        call_args = feedback_invoke.call_args.args
        assert call_args[0] == {
            "plies-to-be-placed": {"P3": graph_data["plies"]["P3"]},
            "plies-to-null": {force_ply_id: graph_data["plies"][force_ply_id]}
        }

    async def test_should_correctly_process_mould_state_changes_when_missing_ply_forced(
            self, mocker, sample_edge_to_cameras, sample_instructions_data):
        # GIVEN
        shared_storage = mocker.patch("app.decision_maker.SharedStorage")
        messaging_wrapper = mocker.patch("app.decision_maker.MessagingWrapper", new_callable=AsyncMock)
        mould_id = "mould_id"
        mocker.patch("app.decision_maker.cfg.MOULD_ID", mould_id)
        force_ply_id = "P2"
        force_ply_request = create_force_ply_c2dm_request(force_ply_id, mould_id, "correlation_id")
        team_instructions = TeamInstructions(sample_instructions_data)
        state_plies_mock = StatePliesMock()
        state_plies = {
            state_plies_mock.first_ply_partially_covered,
            state_plies_mock.second_ply_missing_on_partially_covered,
            state_plies_mock.third_ply_placed,
        }
        mould_state = MouldState(copy.deepcopy(state_plies))
        decision_maker = DecisionMaker(shared_storage, messaging_wrapper, team_instructions, mould_state)

        # AND more methods patched
        feedback_invoke = mocker.patch("app.decision_maker.LaserFeedback.invoke")
        graph_data = {
            "plies": {
                "P1": static_graph_data["plies"]["P1"],
                "P2": static_graph_data["plies"]["P2"],
                "P3": static_graph_data["plies"]["P3"],
            }
        }
        graph = Graph(graph_data)
        graph._map_and_cache_layer_to_pallets()
        edge_cameras = EdgeCameras(sample_edge_to_cameras)
        decision_maker._sub_graph = graph
        decision_maker._edge_cameras = edge_cameras

        # WHEN decision_maker.handle_edge_verification_message is called
        await decision_maker.handle_force_ply_command(force_ply_request.payload)

        # THEN local mould state is correctly updated
        result_plies = decision_maker._mould_state.plies
        expected_plies = [
            state_plies_mock.first_ply_partially_covered,
            state_plies_mock.second_ply_forced_missing,
            state_plies_mock.third_ply_placed
        ]
        assert len(result_plies) == len(expected_plies)
        expected_state_plies = sorted([ply.serialize() for ply in expected_plies], key=lambda i: i["ply_id"])
        actual_state_plies = sorted([ply.serialize() for ply in result_plies], key=lambda i: i["ply_id"])
        assert actual_state_plies == expected_state_plies

        # AND Feedback().invoke is called and awaited once with correct argument
        assert feedback_invoke.call_count == 1
        assert feedback_invoke.await_count == 1
        call_args = feedback_invoke.call_args.args
        assert call_args[0] == {
            "last-plies-placed": {},
            "plies-to-null": {force_ply_id: graph_data["plies"][force_ply_id]}
        }

    async def test_should_correctly_process_mould_state_changes_when_partially_detected_ply_forced(
            self, mocker, sample_edge_to_cameras, sample_instructions_data):
        # GIVEN
        shared_storage = mocker.patch("app.decision_maker.SharedStorage")
        messaging_wrapper = mocker.patch("app.decision_maker.MessagingWrapper", new_callable=AsyncMock)
        mould_id = "mould_id"
        mocker.patch("app.decision_maker.cfg.MOULD_ID", mould_id)
        force_ply_id = "P2"
        force_ply_request = create_force_ply_c2dm_request(force_ply_id, mould_id, "correlation_id")
        team_instructions = TeamInstructions(sample_instructions_data)
        state_plies_mock = StatePliesMock()
        state_plies = {state_plies_mock.first_ply_placed, state_plies_mock.second_ply_partially_detected}
        mould_state = MouldState(copy.deepcopy(state_plies))
        decision_maker = DecisionMaker(shared_storage, messaging_wrapper, team_instructions, mould_state)

        # AND more methods patched
        feedback_invoke = mocker.patch("app.decision_maker.LaserFeedback.invoke")
        graph_data = {
            "plies": {
                "P1": static_graph_data["plies"]["P1"],
                "P2": static_graph_data["plies"]["P2"],
                "P3": static_graph_data["plies"]["P3"],
            }
        }
        graph = Graph(graph_data)
        graph._map_and_cache_layer_to_pallets()
        edge_cameras = EdgeCameras(sample_edge_to_cameras)
        decision_maker._sub_graph = graph
        decision_maker._edge_cameras = edge_cameras

        # WHEN decision_maker.handle_edge_verification_message is called
        await decision_maker.handle_force_ply_command(force_ply_request.payload)

        # THEN local mould state is correctly updated
        result_plies = decision_maker._mould_state.plies
        expected_plies = [
            state_plies_mock.first_ply_partially_covered,
            state_plies_mock.second_ply_forced_partially_detected,
            state_plies_mock.third_ply_expected
        ]
        assert len(result_plies) == len(expected_plies)
        expected_state_plies = sorted([ply.serialize() for ply in expected_plies], key=lambda i: i["ply_id"])
        actual_state_plies = sorted([ply.serialize() for ply in result_plies], key=lambda i: i["ply_id"])
        assert actual_state_plies == expected_state_plies

        # AND Feedback().invoke is called and awaited once with correct argument
        assert feedback_invoke.call_count == 1
        assert feedback_invoke.await_count == 1
        call_args = feedback_invoke.call_args.args
        assert call_args[0] == {
            "plies-to-be-placed": {"P3": graph_data["plies"]["P3"]},
            "plies-to-null": {force_ply_id: graph_data["plies"][force_ply_id]}
        }


class ProcessPliesToBePlacedTests:
    def test_should_seperate_phantom_plies_from_placeable_plies_and_assign_to_feedback_data_when_both_types_given(self):
        # GIVEN
        plies = {
            "P1": {"previous_plies": [], "edges_covered": [], "edges": []},
            "N1": {"previous_plies": [], "edges_covered": [], "edges": ["N1.1", "N1.2"]},
            "M2": {"previous_plies": [], "edges_covered": [], "edges": []},
        }
        feedback_to_send = {}
        decision_maker = DecisionMaker(Mock(), Mock(), Mock(), Mock())

        # WHEN decision_maker._process_plies_to_be_placed is called
        decision_maker._process_plies_to_be_placed(plies, feedback_to_send)

        # THEN
        expected_feedback_to_send = {
            "phantom-plies": {
                "P1": plies["P1"],
                "M2": plies["M2"],
            },
            "plies-to-be-placed": {"N1": plies["N1"]},
        }
        assert feedback_to_send == expected_feedback_to_send


class GroupByCamerasTests:
    def test_should_create_correct_payload_when_edges_given(self, sample_edge_to_cameras):
        # GIVEN
        detected_edges_to_verify = {"P1.1", "P2.1", "E1.2", "L1.2"}
        missing_edges_to_verify = {"P2.2", "P3.1", "P3.2"}

        decision_maker = DecisionMaker(Mock(), Mock(), Mock(), Mock())
        decision_maker._edge_cameras = EdgeCameras(sample_edge_to_cameras)

        # WHEN
        result = decision_maker._generate_edge_verification_payload_data(
            detected_edges_to_verify,
            missing_edges_to_verify)

        # THEN result is correct
        assert result == {
            "cam1": {"detectedEdges": ["P1.1", "P2.1"], "missingEdges": ["P2.2"]},
            "cam2": {"missingEdges": ["P2.2", "P3.1", "P3.2"]},
            "cam3": {"missingEdges": ["P3.2"]},
            "cam5": {"detectedEdges": ["E1.2"]},
            "cam6": {"detectedEdges": ["L1.2"]},
        }

    def test_should_create_empty_payload_when_empty_set_given(self, sample_edge_to_cameras):
        # GIVEN
        detected_edges_to_verify = set()
        missing_edges_to_verify = set()

        decision_maker = DecisionMaker(Mock(), Mock(), Mock(), Mock())
        decision_maker._edge_cameras = EdgeCameras(sample_edge_to_cameras)

        # WHEN
        result = decision_maker._generate_edge_verification_payload_data(
            detected_edges_to_verify,
            missing_edges_to_verify)

        # THEN result is correct
        assert result == {}


@pytest.mark.asyncio
@patch("app.dm_helper.image_grabbing.cfg.ACTIVE_EDGE_VERIFICATION_REFRESH_INTERVAL", 5)
@patch("app.dm_helper.image_grabbing.cfg.PASSIVE_EDGE_VERIFICATION_REFRESH_INTERVAL", 60)
class StartImageStreamingOrUpdateImageGrabberRefreshIntervalTests:
    async def test_should_start_image_grabbing_only_with_high_frame_rates_when_only_expected_edges_exist(
            self, mocker, sample_edge_to_cameras):
        # GIVEN
        graph_data = {
            "plies": {
                "P1": {"edges": ["P1.1", "P1.2"], "edges_covered": [], "previous_plies": []},
                "P2": {"edges": ["P2.1", "P2.2"], "edges_covered": ["P1.2"], "previous_plies": ["P1"]},
                "P3": {"edges": ["P3.1", "P3.2"], "edges_covered": ["P2.2"], "previous_plies": ["P2"]}
            }
        }
        graph = Graph(graph_data)
        state_plies_mock = StatePliesMock()
        state_plies = {
            state_plies_mock.first_ply_expected,
        }
        metadata_to_forward = PayloadMetadata()
        mould_state = MouldState(copy.deepcopy(state_plies))
        edge_cameras = EdgeCameras(sample_edge_to_cameras)
        image_grabbing_start = mocker.patch("app.decision_maker.ImageGrabbing.start_update")
        decision_maker = DecisionMaker(Mock(), Mock(), Mock(), mould_state)

        # AND
        recalculate_expected_plies(mould_state, graph, edge_cameras)

        # WHEN
        await decision_maker._start_image_streaming_or_update_image_grabber_refresh_interval(metadata_to_forward)

        # THEN ImageGrabbing.start is called and awaited with correct arguments
        assert image_grabbing_start.call_count == 2
        assert image_grabbing_start.await_count == 2
        actual_calls = image_grabbing_start.call_args_list
        expected_calls = [
            call(set(), 60, metadata_to_forward),
            call({"cam1"}, 5, metadata_to_forward),
        ]
        assert actual_calls == expected_calls

    async def test_should_start_image_grabbing_only_with_high_frame_rates_when_only_missing_edges_exist(
            self, mocker, sample_edge_to_cameras):
        # GIVEN
        graph_data = {
            "plies": {
                "P1": {"edges": ["P1.1", "P1.2"], "edges_covered": [], "previous_plies": []},
                "P2": {"edges": ["P2.1", "P2.2"], "edges_covered": ["P1.2"], "previous_plies": ["P1"]},
                "P3": {"edges": ["P3.1", "P3.2"], "edges_covered": ["P2.2"], "previous_plies": ["P2"]}
            }
        }
        graph = Graph(graph_data)
        state_plies_mock = StatePliesMock()
        state_plies = {
            state_plies_mock.first_ply_missing,
            state_plies_mock.second_ply_missing_on_partially_covered,
            state_plies_mock.third_ply_missing,
        }
        metadata_to_forward = PayloadMetadata()
        mould_state = MouldState(copy.deepcopy(state_plies))
        edge_cameras = EdgeCameras(sample_edge_to_cameras)
        image_grabbing_start = mocker.patch("app.decision_maker.ImageGrabbing.start_update")
        decision_maker = DecisionMaker(Mock(), Mock(), Mock(), mould_state)

        # AND
        recalculate_expected_plies(mould_state, graph, edge_cameras)

        # WHEN
        await decision_maker._start_image_streaming_or_update_image_grabber_refresh_interval(metadata_to_forward)

        # THEN ImageGrabbing.start is called and awaited with correct arguments
        assert image_grabbing_start.call_count == 2
        assert image_grabbing_start.await_count == 2
        actual_calls = image_grabbing_start.call_args_list
        expected_calls = [
            call(set(), 60, metadata_to_forward),
            call({"cam2", "cam1", "cam3"}, 5, metadata_to_forward),
        ]
        assert actual_calls == expected_calls

    async def test_should_start_image_grabbing_only_with_high_frame_rates_when_only_expected_and_missing_edges_exist(
            self, mocker, sample_edge_to_cameras):
        # GIVEN
        graph_data = {
            "plies": {
                "P1": {"edges": ["P1.1", "P1.2"], "edges_covered": [], "previous_plies": []},
                "P2": {"edges": ["P2.1", "P2.2"], "edges_covered": ["P1.2"], "previous_plies": ["P1"]},
                "P3": {"edges": ["P3.1", "P3.2"], "edges_covered": ["P2.2"], "previous_plies": ["P2"]}
            }
        }
        graph = Graph(graph_data)
        state_plies_mock = StatePliesMock()
        state_plies = {
            state_plies_mock.first_ply_missing,
            state_plies_mock.second_ply_expected,
        }
        metadata_to_forward = PayloadMetadata()
        mould_state = MouldState(copy.deepcopy(state_plies))
        edge_cameras = EdgeCameras(sample_edge_to_cameras)
        image_grabbing_start = mocker.patch("app.decision_maker.ImageGrabbing.start_update")
        decision_maker = DecisionMaker(Mock(), Mock(), Mock(), mould_state)

        # AND
        recalculate_expected_plies(mould_state, graph, edge_cameras)

        # WHEN
        await decision_maker._start_image_streaming_or_update_image_grabber_refresh_interval(metadata_to_forward)

        # THEN ImageGrabbing.start is called and awaited with correct arguments
        assert image_grabbing_start.call_count == 2
        assert image_grabbing_start.await_count == 2
        actual_calls = image_grabbing_start.call_args_list
        expected_calls = [
            call(set(), 60, metadata_to_forward),
            call({"cam2", "cam1"}, 5, metadata_to_forward),
        ]
        assert actual_calls == expected_calls

    async def test_should_start_image_grabbing_only_with_high_frame_rates_when_active_and_passive_plies_under_same_cam(
            self, mocker, sample_edge_to_cameras):
        # GIVEN
        graph_data = {
            "plies": {
                "P1": {"edges": ["P1.1", "P1.2"], "edges_covered": [], "previous_plies": []},
                "P2": {"edges": ["P2.1", "P2.2"], "edges_covered": ["P1.2"], "previous_plies": ["P1"]},
                "P3": {"edges": ["P3.1", "P3.2"], "edges_covered": ["P2.2"], "previous_plies": ["P2"]}
            }
        }
        graph = Graph(graph_data)
        state_plies_mock = StatePliesMock()
        state_plies = {
            state_plies_mock.first_ply_placed,
            state_plies_mock.second_ply_expected,
        }
        metadata_to_forward = PayloadMetadata()
        mould_state = MouldState(copy.deepcopy(state_plies))
        edge_cameras = EdgeCameras(sample_edge_to_cameras)
        image_grabbing_start = mocker.patch("app.decision_maker.ImageGrabbing.start_update")
        decision_maker = DecisionMaker(Mock(), Mock(), Mock(), mould_state)

        # AND
        recalculate_expected_plies(mould_state, graph, edge_cameras)

        # WHEN
        await decision_maker._start_image_streaming_or_update_image_grabber_refresh_interval(metadata_to_forward)

        # THEN ImageGrabbing.start is called and awaited with correct arguments
        assert image_grabbing_start.call_count == 2
        assert image_grabbing_start.await_count == 2
        actual_calls = image_grabbing_start.call_args_list
        expected_calls = [
            call(set(), 60, metadata_to_forward),
            call({"cam1", "cam2"}, 5, metadata_to_forward),
        ]
        assert actual_calls == expected_calls

    async def test_should_start_image_grabbing_with_high_and_low_frame_rates_when_visible_expected_missing_edges_exist(
            self, mocker, sample_edge_to_cameras):
        # GIVEN
        graph_data = {
            "plies": {
                "P1": {"edges": ["P1.1", "P1.2"], "edges_covered": [], "previous_plies": []},
                "P2": {"edges": ["P2.1", "P2.2"], "edges_covered": ["P1.2"], "previous_plies": ["P1"]},
                "P3": {"edges": ["P3.1", "P3.2"], "edges_covered": ["P2.2"], "previous_plies": ["P2"]}
            }
        }
        graph = Graph(graph_data)
        state_plies_mock = StatePliesMock()
        state_plies = {
            state_plies_mock.first_ply_partially_covered,
            state_plies_mock.second_ply_placed,
            state_plies_mock.third_ply_expected,
        }
        metadata_to_forward = PayloadMetadata()
        mould_state = MouldState(copy.deepcopy(state_plies))
        edge_cameras = EdgeCameras(sample_edge_to_cameras)
        image_grabbing_start = mocker.patch("app.decision_maker.ImageGrabbing.start_update")
        decision_maker = DecisionMaker(Mock(), Mock(), Mock(), mould_state)

        # AND
        recalculate_expected_plies(mould_state, graph, edge_cameras)

        # WHEN
        await decision_maker._start_image_streaming_or_update_image_grabber_refresh_interval(metadata_to_forward)

        # THEN ImageGrabbing.start is called and awaited with correct arguments
        assert image_grabbing_start.call_count == 2
        assert image_grabbing_start.await_count == 2
        actual_calls = image_grabbing_start.call_args_list
        expected_calls = [
            call({"cam1"}, 60, metadata_to_forward),
            call({"cam2", "cam3"}, 5, metadata_to_forward),
        ]
        assert actual_calls == expected_calls

    async def test_should_start_image_grabbing_only_with_low_frame_rates_when_only_visible_edges_exist(
            self, mocker, sample_edge_to_cameras):
        # GIVEN
        graph_data = {
            "plies": {
                "P1": {"edges": ["P1.1", "P1.2"], "edges_covered": [], "previous_plies": []},
                "P2": {"edges": ["P2.1", "P2.2"], "edges_covered": ["P1.2"], "previous_plies": ["P1"]},
                "P3": {"edges": ["P3.1", "P3.2"], "edges_covered": ["P2.2"], "previous_plies": ["P2"]}
            }
        }
        graph = Graph(graph_data)
        state_plies_mock = StatePliesMock()
        state_plies = {
            state_plies_mock.first_ply_partially_covered,
            state_plies_mock.second_ply_partially_covered,
            state_plies_mock.third_ply_placed,
        }
        metadata_to_forward = PayloadMetadata()
        mould_state = MouldState(copy.deepcopy(state_plies))
        edge_cameras = EdgeCameras(sample_edge_to_cameras)
        image_grabbing_start = mocker.patch("app.decision_maker.ImageGrabbing.start_update")
        decision_maker = DecisionMaker(Mock(), Mock(), Mock(), mould_state)

        # AND
        recalculate_expected_plies(mould_state, graph, edge_cameras)

        # WHEN
        await decision_maker._start_image_streaming_or_update_image_grabber_refresh_interval(metadata_to_forward)

        # THEN ImageGrabbing.start is called and awaited with correct arguments
        assert image_grabbing_start.call_count == 2
        assert image_grabbing_start.await_count == 2
        actual_calls = image_grabbing_start.call_args_list
        expected_calls = [
            call({"cam1", "cam2", "cam3"}, 60, metadata_to_forward),
            call(set(), 5, metadata_to_forward),
        ]
        assert actual_calls == expected_calls

    async def test_should_start_image_grabbing_only_with_high_frame_rates_when_mould_state_empty(
            self, mocker, sample_edge_to_cameras):
        # GIVEN
        graph_data = {
            "plies": {
                "P1": {"edges": ["P1.1", "P1.2"], "edges_covered": [], "previous_plies": []},
                "P2": {"edges": ["P2.1", "P2.2"], "edges_covered": ["P1.2"], "previous_plies": ["P1"]},
                "P3": {"edges": ["P3.1", "P3.2"], "edges_covered": ["P2.2"], "previous_plies": ["P2"]}
            }
        }
        metadata_to_forward = PayloadMetadata()
        graph = Graph(graph_data)
        state_plies = set()
        mould_state = MouldState(copy.deepcopy(state_plies))
        edge_cameras = EdgeCameras(sample_edge_to_cameras)
        image_grabbing_start = mocker.patch("app.decision_maker.ImageGrabbing.start_update")
        decision_maker = DecisionMaker(Mock(), Mock(), Mock(), mould_state)

        # AND
        recalculate_expected_plies(mould_state, graph, edge_cameras)

        # WHEN
        await decision_maker._start_image_streaming_or_update_image_grabber_refresh_interval(metadata_to_forward)

        # THEN ImageGrabbing.start is called and awaited with correct arguments
        assert image_grabbing_start.call_count == 2
        assert image_grabbing_start.await_count == 2
        actual_calls = image_grabbing_start.call_args_list
        expected_calls = [
            call(set(), 60, metadata_to_forward),
            call({"cam1"}, 5, metadata_to_forward),
        ]
        assert actual_calls == expected_calls

    async def test_should_start_image_grabbing_only_with_low_frame_rates_when_all_graph_plies_placed(
            self, mocker, sample_edge_to_cameras):
        # GIVEN
        graph_data = {
            "plies": {
                "P1": {"edges": ["P1.1", "P1.2"], "edges_covered": [], "previous_plies": []},
                "P2": {"edges": ["P2.1", "P2.2"], "edges_covered": ["P1.2"], "previous_plies": ["P1"]},
                "P3": {"edges": ["P3.1", "P3.2"], "edges_covered": ["P2.2"], "previous_plies": ["P2"]}
            }
        }
        metadata_to_forward = PayloadMetadata()
        graph = Graph(graph_data)
        state_plies_mock = StatePliesMock()
        state_plies = {
            state_plies_mock.first_ply_placed,
            state_plies_mock.second_ply_placed,
            state_plies_mock.third_ply_placed,
        }
        mould_state = MouldState(copy.deepcopy(state_plies))
        edge_cameras = EdgeCameras(sample_edge_to_cameras)
        image_grabbing_start = mocker.patch("app.decision_maker.ImageGrabbing.start_update")
        decision_maker = DecisionMaker(Mock(), Mock(), Mock(), mould_state)

        # AND
        recalculate_expected_plies(mould_state, graph, edge_cameras)

        # WHEN
        await decision_maker._start_image_streaming_or_update_image_grabber_refresh_interval(metadata_to_forward)

        # THEN ImageGrabbing.start is called and awaited with correct arguments
        assert image_grabbing_start.call_count == 2
        assert image_grabbing_start.await_count == 2
        actual_calls = image_grabbing_start.call_args_list
        expected_calls = [
            call({"cam1", "cam2", "cam3"}, 60, metadata_to_forward),
            call(set(), 5, metadata_to_forward),
        ]
        assert actual_calls == expected_calls

    async def test_should_not_start_image_grabbing_with_high_frame_rate_when_missing_edges_marked_as_unverifiable(
            self, mocker, sample_edge_to_cameras):
        # GIVEN
        graph_data = {
            "plies": {
                "P1": {"edges": ["P1.1", "P1.2"], "edges_covered": [], "previous_plies": []},
            }
        }
        metadata_to_forward = PayloadMetadata()
        graph = Graph(graph_data)
        state_plies_mock = StatePliesMock()
        state_plies = {
            state_plies_mock.first_ply_forced_expected,
        }
        mould_state = MouldState(copy.deepcopy(state_plies))
        edge_cameras = EdgeCameras(sample_edge_to_cameras)
        image_grabbing_start = mocker.patch("app.decision_maker.ImageGrabbing.start_update")
        decision_maker = DecisionMaker(Mock(), Mock(), Mock(), mould_state)

        # AND
        recalculate_expected_plies(mould_state, graph, edge_cameras)

        # WHEN
        await decision_maker._start_image_streaming_or_update_image_grabber_refresh_interval(metadata_to_forward)

        # THEN ImageGrabbing.start is called and awaited with correct arguments
        assert image_grabbing_start.call_count == 2
        assert image_grabbing_start.await_count == 2
        actual_calls = image_grabbing_start.call_args_list
        expected_calls = [
            call({"cam1"}, 60, metadata_to_forward),
            call(set(), 5, metadata_to_forward),
        ]
        assert actual_calls == expected_calls
