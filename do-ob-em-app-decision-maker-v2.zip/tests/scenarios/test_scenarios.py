# pylint: disable=protected-access, missing-module-docstring, missing-class-docstring, missing-function-docstring, duplicate-code, line-too-long, too-few-public-methods, no-self-use, too-many-locals, too-many-lines
import copy
import json
from unittest.mock import patch, AsyncMock

import nest_asyncio
import pytest

from app.handler.cloud_to_device_method_handler import CloudToDeviceMethodHandler
from app.handler.input_message_handler import InputMessageHandler
from app.logging.logger import yield_logger
from app.message_listener import MessageListener
from tests.scenarios.model.test_scenario import TestScenario
from tests.scenarios.model.test_scenario_entry import TestScenarioEntry
from tests.scenarios.scenarios_collector import ScenariosCollector
from tests.scenarios.test_scenarios_dtos.edge_covered_test_scenarios_dtos import \
    EdgeCoveredTestScenariosDtos
from tests.scenarios.test_scenarios_dtos.etcd_instruction_update_test_scenarios_dtos import \
    EtcdInstructionUpdateTestScenariosDtos
from tests.scenarios.test_scenarios_dtos.etcd_mould_state_update_test_scenarios_dtos import \
    EtcdMouldStateUpdateTestScenariosDtos
from tests.scenarios.test_scenarios_dtos.etcd_ply_update_due_to_recheck_ply_command_test_scenarios_dtos import \
    EtcdPlyUpdateDueToRecheckPlyCommandTestScenariosDtos
from tests.scenarios.test_scenarios_dtos.etcd_ply_update_due_to_undo_ply_command_test_scenarios_dtos import \
    EtcdPlyUpdateDueToUndoPlyCommandTestScenariosDtos
from tests.scenarios.test_scenarios_dtos.etcd_ply_update_test_scenarios_dtos import EtcdPlyUpdateTestScenariosDtos
from tests.scenarios.test_scenarios_dtos.filter_missing_plies_likely_being_covered_test_scenarios_dtos import \
    FilterMissingPliesLikelyBeingCoveredTestScenariosDtos
from tests.scenarios.test_scenarios_dtos.handle_add_team_instruction_command_test_scenarios_dtos import \
    HandleAddTeamInstructionCommandTestScenariosDtos
from tests.scenarios.test_scenarios_dtos.handle_finalise_command_test_scenarios_dtos import \
    HandleFinaliseCommandTestScenariosDtos
from tests.scenarios.test_scenarios_dtos.handle_force_ply_command_test_scenarios_dtos import \
    HandleForcePlyCommandTestScenariosDtos
from tests.scenarios.test_scenarios_dtos.handle_recheck_ply_command_test_scenarios_dtos import \
    HandleRecheckPlyCommandTestScenariosDtos
from tests.scenarios.test_scenarios_dtos.handle_undo_plies_to_command_test_scenarios_dtos import \
    HandleUndoPliesToCommandTestScenariosDtos
from tests.scenarios.test_scenarios_dtos.handle_undo_plies_to_dry_run_command_test_scenarios_dtos import \
    HandleUndoPliesToDryRunCommandTestScenariosDtos
from tests.scenarios.test_scenarios_dtos.handle_undo_ply_command_test_scenarios_dtos import \
    HandleUndoPlyCommandTestScenariosDtos
from tests.scenarios.test_scenarios_dtos.multiple_layers_test_scenarios_dtos import MultipleLayersTestScenariosDtos
from tests.scenarios.test_scenarios_dtos.multiple_placed_plies_to_verify_test_scenarios_dtos import \
    MultiplePlacedPliesToVerifyTestScenariosDtos
from tests.scenarios.test_scenarios_dtos.ply_covered_test_scenarios_dtos import PlyCoveredTestScenariosDtos
from tests.scenarios.test_scenarios_dtos.single_layer_various_test_scenarios_dtos import \
    SingleLayerVariousTestScenariosDtos
from tests.scenarios.test_scenarios_dtos.single_placed_plies_to_verify_test_scenarios_dtos import \
    SinglePlacedPliesToVerifyTestScenariosDtos
from tests.scenarios.test_scenarios_dtos.team_instructions_loaded_on_boot_test_scenarios_dtos import \
    TeamInstructionsLoadedOnBootTestScenariosDtos
from tests.scenarios.test_scenarios_dtos.zero_placed_plies_to_verify_test_scenarios_dtos import \
    ZeroPlacedPliesToVerifyTestScenariosDtos

log = yield_logger()


@pytest.mark.asyncio
@patch("app.config.LOCATION_ID", "location_id")
@patch("app.config.HALL_ID", "hall_id")
@patch("app.config.MOULD_ID", "mould_id")
@patch("app.config.DEVICE_MODULE_ID", "device_module_id")
class ScenariosTests:
    @patch("app.config.FF_FILTER_MISSING_PLIES_LIKELY_BEING_COVERED", False)
    async def test_single_layer_various_test_scenarios(self, mocker):
        scenarios_collector = ScenariosCollector(SingleLayerVariousTestScenariosDtos)
        scenario_list = scenarios_collector.scenario_list
        await ScenariosProcessor._process_test_scenarios(mocker, scenario_list)

    async def test_multiple_layers_test_scenarios(self, mocker):
        scenarios_collector = ScenariosCollector(MultipleLayersTestScenariosDtos)
        scenario_list = scenarios_collector.scenario_list
        await ScenariosProcessor._process_test_scenarios(mocker, scenario_list)

    @patch("app.config.FF_FILTER_MISSING_PLIES_LIKELY_BEING_COVERED", False)
    async def test_edge_covered_test_scenarios(self, mocker):
        scenarios_collector = ScenariosCollector(EdgeCoveredTestScenariosDtos)
        scenario_list = scenarios_collector.scenario_list
        await ScenariosProcessor._process_test_scenarios(mocker, scenario_list)

    @patch("app.config.FF_FILTER_MISSING_PLIES_LIKELY_BEING_COVERED", False)
    @patch("app.config.FF_REMOVE_INVISIBLE_EDGES_ON_GRAPH_LOAD", False)
    async def test_ply_covered_test_scenarios(self, mocker):
        scenarios_collector = ScenariosCollector(PlyCoveredTestScenariosDtos)
        scenario_list = scenarios_collector.scenario_list
        await ScenariosProcessor._process_test_scenarios(mocker, scenario_list)

    @patch("app.config.FF_FILTER_MISSING_PLIES_LIKELY_BEING_COVERED", True)
    async def test_filter_missing_plies_likely_being_covered_test_scenarios(self, mocker):
        scenarios_collector = ScenariosCollector(FilterMissingPliesLikelyBeingCoveredTestScenariosDtos)
        scenario_list = scenarios_collector.scenario_list
        await ScenariosProcessor._process_test_scenarios(mocker, scenario_list)

    async def test_team_instructions_loaded_on_boot_test_scenarios(self, mocker):
        scenarios_collector = ScenariosCollector(TeamInstructionsLoadedOnBootTestScenariosDtos)
        scenario_list = scenarios_collector.scenario_list
        await ScenariosProcessor._process_test_scenarios(mocker, scenario_list)

    async def test_etcd_ply_update_test_scenarios(self, mocker):
        scenarios_collector = ScenariosCollector(EtcdPlyUpdateTestScenariosDtos)
        scenario_list = scenarios_collector.scenario_list
        await ScenariosProcessor._process_test_scenarios(mocker, scenario_list)

    async def test_etcd_instruction_update_test_scenarios(self, mocker):
        scenarios_collector = ScenariosCollector(EtcdInstructionUpdateTestScenariosDtos)
        scenario_list = scenarios_collector.scenario_list
        await ScenariosProcessor._process_test_scenarios(mocker, scenario_list)

    async def test_etcd_mould_state_update_test_scenarios(self, mocker):
        scenarios_collector = ScenariosCollector(EtcdMouldStateUpdateTestScenariosDtos)
        scenario_list = scenarios_collector.scenario_list
        await ScenariosProcessor._process_test_scenarios(mocker, scenario_list)

    @patch("app.config.NUMBER_OF_PLACED_PLIES_TO_VERIFY", 3)
    @patch("app.config.FF_FILTER_MISSING_PLIES_LIKELY_BEING_COVERED", False)
    async def test_ff_multiple_placed_plies_to_verify_test_scenarios(self, mocker):
        scenarios_collector = ScenariosCollector(MultiplePlacedPliesToVerifyTestScenariosDtos)
        scenario_list = scenarios_collector.scenario_list
        await ScenariosProcessor._process_test_scenarios(mocker, scenario_list)

    @patch("app.config.NUMBER_OF_PLACED_PLIES_TO_VERIFY", 1)
    @patch("app.config.FF_FILTER_MISSING_PLIES_LIKELY_BEING_COVERED", False)
    async def test_ff_single_placed_plies_to_verify_test_scenarios(self, mocker):
        scenarios_collector = ScenariosCollector(SinglePlacedPliesToVerifyTestScenariosDtos)
        scenario_list = scenarios_collector.scenario_list
        await ScenariosProcessor._process_test_scenarios(mocker, scenario_list)

    @patch("app.config.NUMBER_OF_PLACED_PLIES_TO_VERIFY", 0)
    @patch("app.config.FF_FILTER_MISSING_PLIES_LIKELY_BEING_COVERED", False)
    async def test_ff_zero_placed_plies_to_verify_test_scenarios(self, mocker):
        scenarios_collector = ScenariosCollector(ZeroPlacedPliesToVerifyTestScenariosDtos)
        scenario_list = scenarios_collector.scenario_list
        await ScenariosProcessor._process_test_scenarios(mocker, scenario_list)

    async def test_handle_add_team_instruction_command_test_scenarios(self, mocker):
        scenarios_collector = ScenariosCollector(HandleAddTeamInstructionCommandTestScenariosDtos)
        scenario_list = scenarios_collector.scenario_list
        await ScenariosProcessor._process_test_scenarios(mocker, scenario_list)

    async def test_handle_force_ply_command_test_scenarios(self, mocker):
        scenarios_collector = ScenariosCollector(HandleForcePlyCommandTestScenariosDtos)
        scenario_list = scenarios_collector.scenario_list
        await ScenariosProcessor._process_test_scenarios(mocker, scenario_list)

    async def test_handle_recheck_ply_command_test_scenarios(self, mocker):
        scenarios_collector = ScenariosCollector(HandleRecheckPlyCommandTestScenariosDtos)
        scenario_list = scenarios_collector.scenario_list
        await ScenariosProcessor._process_test_scenarios(mocker, scenario_list)

    async def test_etcd_ply_update_due_to_recheck_ply_command_test_scenarios(self, mocker):
        scenarios_collector = ScenariosCollector(EtcdPlyUpdateDueToRecheckPlyCommandTestScenariosDtos)
        scenario_list = scenarios_collector.scenario_list
        await ScenariosProcessor._process_test_scenarios(mocker, scenario_list)

    async def test_handle_undo_plies_to_command_test_scenarios(self, mocker):
        scenarios_collector = ScenariosCollector(HandleUndoPliesToCommandTestScenariosDtos)
        scenario_list = scenarios_collector.scenario_list
        await ScenariosProcessor._process_test_scenarios(mocker, scenario_list)

    async def test_handle_undo_plies_to_dry_run_command_test_scenarios(self, mocker):
        scenarios_collector = ScenariosCollector(HandleUndoPliesToDryRunCommandTestScenariosDtos)
        scenario_list = scenarios_collector.scenario_list
        await ScenariosProcessor._process_test_scenarios(mocker, scenario_list)

    async def test_handle_undo_ply_command_test_scenarios(self, mocker):
        scenarios_collector = ScenariosCollector(HandleUndoPlyCommandTestScenariosDtos)
        scenario_list = scenarios_collector.scenario_list
        await ScenariosProcessor._process_test_scenarios(mocker, scenario_list)

    async def test_etcd_ply_update_due_to_undo_ply_command_test_scenarios(self, mocker):
        scenarios_collector = ScenariosCollector(EtcdPlyUpdateDueToUndoPlyCommandTestScenariosDtos)
        scenario_list = scenarios_collector.scenario_list
        await ScenariosProcessor._process_test_scenarios(mocker, scenario_list)

    async def test_handle_finalise_command_test_scenarios(self, mocker):
        scenarios_collector = ScenariosCollector(HandleFinaliseCommandTestScenariosDtos)
        scenario_list = scenarios_collector.scenario_list
        await ScenariosProcessor._process_test_scenarios(mocker, scenario_list)


class ScenariosProcessor:
    # Allows event loop to be nested for input data of etcd inbound event in test scenarios to be mocked
    nest_asyncio.apply()

    @staticmethod
    async def _process_test_scenarios(mocker, scenarios):
        for scenario in scenarios:
            print(f"\nTesting scenario: '{scenario.name}'")
            await ScenariosProcessor._process_test_scenario(mocker, scenario)

    @staticmethod
    async def _process_test_scenario(mocker, test_scenario: TestScenario):
        mocker.patch("app.shared_storage.etcd3")
        mocker.patch("app.file_storage.get_static_graph", return_value=copy.deepcopy(test_scenario.graph))
        mocker.patch("app.file_storage.get_edge_cameras", return_value=copy.deepcopy(test_scenario.edge_to_cameras))
        mocker.patch(
            "app.file_storage.get_feedback_positions", return_value=copy.deepcopy(test_scenario.feedback_positions))
        mocker.patch("app.module_initializer.SharedStorage.get_mould_instructions",
                     return_value=copy.deepcopy(test_scenario.initial_mould_state_instructions_data))
        mocker.patch("app.module_initializer.SharedStorage.get_mould_plies",
                     return_value=copy.deepcopy(test_scenario.initial_mould_state_plies_data))
        mocker.patch("app.module_initializer.SharedStorage.get_mould_state",
                     return_value=copy.deepcopy(test_scenario.initial_mould_state))
        mocker.patch("app.module_initializer.SharedStorage.get_mould_blade_sn",
                     return_value=copy.deepcopy(test_scenario.initial_mould_blade_sn))
        mocker.patch("app.message_listener.IoTHubModuleClient")
        message_listener = MessageListener()

        module_client = message_listener._module_client
        mocker.patch.object(module_client, "connect", new_callable=AsyncMock)
        mocker.patch.object(module_client, "send_message_to_output", new_callable=AsyncMock)
        mocker.patch.object(module_client, "send_method_response", new_callable=AsyncMock)

        # short work around to gracefully close asyncio event loop
        message_listener._empty_listener = None

        decision_maker = message_listener._decision_maker
        messaging_wrapper = message_listener._messaging
        shared_storage = message_listener._decision_maker._shared_storage
        cloud_to_device_method_handler = CloudToDeviceMethodHandler(decision_maker, messaging_wrapper)
        input_message_handler = InputMessageHandler(decision_maker, messaging_wrapper)

        mocker.patch.object(shared_storage, "put_key")
        mocker.patch.object(shared_storage, "delete_prefix")
        mocker.patch.object(shared_storage, "_delete")

        mocker.patch("app.models.payload_metadata.uuid.uuid4", return_value="correlation_id")

        await message_listener.run()

        await ScenariosProcessor._run_test_scenario(
            cloud_to_device_method_handler, input_message_handler, test_scenario, module_client, shared_storage)

    @staticmethod
    async def _run_test_scenario(
            cloud_to_device_method_handler, input_message_handler, test_scenario, module_client, shared_storage):
        entries_iteration_count = 0
        for entry in test_scenario.entries:
            entries_iteration_count += 1
            try:
                if entry.c2dm_request:
                    # WHEN cloud_to_device_method_handler.handle is called
                    await cloud_to_device_method_handler.handle(entry.c2dm_request)
                    # THEN
                    ScenariosProcessor._process_test_scenario_out_calls(entry, module_client, shared_storage)
                elif entry.inbound_ev_message:
                    # WHEN input_message_handler.handle is called
                    await input_message_handler.handle(entry.inbound_ev_message)
                    # THEN
                    ScenariosProcessor._process_test_scenario_out_calls(entry, module_client, shared_storage)
                elif entry.inbound_etcd_event:
                    # WHEN shared_storage._handle_global_mould_change is called
                    shared_storage._handle_global_mould_changes(entry.inbound_etcd_event)
                    # THEN
                    ScenariosProcessor._process_test_scenario_out_calls(entry, module_client, shared_storage)
                elif entry.instructions_loaded_on_boot:
                    # WHEN module loaded TI from ETCD store on boot
                    # THEN
                    ScenariosProcessor._process_test_scenario_out_calls(entry, module_client, shared_storage)
                else:
                    raise AssertionError("Unrecognised entry input data type.")

            except AssertionError as ex:
                error_message = f"Failed test scenario: '{test_scenario.name}'" \
                                f"\n\t on iteration of entry: {entries_iteration_count}" \
                                f"\n\t for given data: {entry}."
                log.error(error_message)
                raise AssertionError(ex)

    @staticmethod
    def _process_test_scenario_out_calls(entry: TestScenarioEntry, module_client, shared_storage) -> None:
        ScenariosProcessor._assert_shared_storage_call_counts(entry, shared_storage)
        ScenariosProcessor._assert_shared_storage_call_arguments(entry, shared_storage)
        ScenariosProcessor._reset_shared_storage_call_counters_and_arguments(shared_storage)

        ScenariosProcessor._assert_messaging_call_counts(entry, module_client)
        ScenariosProcessor._assert_messaging_call_arguments(entry, module_client)
        ScenariosProcessor._reset_messaging_call_counters_and_arguments(module_client)

        ScenariosProcessor._assert_c2dm_response_call_counts(entry, module_client)
        ScenariosProcessor._assert_c2dm_response_call_arguments(entry, module_client)
        ScenariosProcessor._reset_c2dm_response_call_counters_and_arguments(module_client)

    @staticmethod
    def _assert_shared_storage_call_counts(entry, shared_storage):
        if entry.etcd_outputs is not None:
            put_key_call_count = shared_storage.put_key.call_count
            delete_prefix_call_count = shared_storage.delete_prefix.call_count
            delete_call_count = shared_storage._delete.call_count
            actual_etcd_output_calls_count = put_key_call_count + delete_prefix_call_count + delete_call_count
            if entry.etcd_outputs and actual_etcd_output_calls_count != len(entry.etcd_outputs):
                error_message = f"Failed assert scenario entry calls for etcd_outputs: " \
                                f"actual_etcd_output_calls_count != expected_etcd_outputs_count" \
                                f" ({actual_etcd_output_calls_count} != {len(entry.etcd_outputs)})."
                log.error(error_message)
                raise AssertionError(error_message)
            else:
                assert actual_etcd_output_calls_count == len(entry.etcd_outputs)

    @staticmethod
    def _assert_shared_storage_call_arguments(entry, shared_storage):
        if entry.etcd_outputs is not None:
            actual_put_key_calls = shared_storage.put_key.call_args_list
            actual_delete_prefix_calls = shared_storage.delete_prefix.call_args_list
            actual_delete_calls = shared_storage._delete.call_args_list
            expected_etcd_outputs = entry.etcd_outputs

            extracted_actual_put_calls = [{"key": c[0], "value": c[1]} for c, _ in actual_put_key_calls]
            extracted_actual_delete_prefix_calls = [{"key": c[0][0], "value": None} for c in actual_delete_prefix_calls]
            extracted_actual_delete_calls = [{"key": c[0][0], "value": None} for c in actual_delete_calls]
            extracted_expected_etcd_outputs = [{"key": c.key, "value": c.value} for c in expected_etcd_outputs]

            extracted_actual_calls = extracted_actual_put_calls + extracted_actual_delete_prefix_calls + extracted_actual_delete_calls
            sorted_extracted_actual_calls = sorted(extracted_actual_calls, key=lambda x: x["key"])
            sorted_extracted_expected_etcd_outputs = sorted(extracted_expected_etcd_outputs, key=lambda x: x["key"])

            assert sorted_extracted_actual_calls == sorted_extracted_expected_etcd_outputs

    @staticmethod
    def _reset_shared_storage_call_counters_and_arguments(shared_storage):
        shared_storage.put_key.call_count = 0
        shared_storage.put_key.call_args_list = []
        shared_storage.delete_prefix.call_count = 0
        shared_storage.delete_prefix.call_args_list = []
        shared_storage._delete.call_count = 0
        shared_storage._delete.call_args_list = []

    @staticmethod
    def _assert_messaging_call_counts(entry, module_client):
        if entry.messaging_outputs is not None:
            actual_messaging_output_calls_count = module_client.send_message_to_output.call_count
            if actual_messaging_output_calls_count != len(entry.messaging_outputs):
                error_message = f"Failed assert scenario entry calls for messaging_outputs: " \
                                f"actual_messaging_output_calls_count != expected_messaging_outputs_count" \
                                f" ({actual_messaging_output_calls_count} != {len(entry.messaging_outputs)})."
                log.error(error_message)
                raise AssertionError(error_message)
            else:
                assert module_client.send_message_to_output.call_count == len(entry.messaging_outputs)
                assert module_client.send_message_to_output.await_count == len(entry.messaging_outputs)

    @staticmethod
    def _assert_messaging_call_arguments(entry, module_client):
        if entry.messaging_outputs is not None:
            for i in range(len(entry.messaging_outputs)):
                actual_output_calls = module_client.send_message_to_output.call_args_list
                actual_output_call = actual_output_calls[i]
                actual_output_message_data = json.loads(actual_output_call[0][0].data)
                actual_output_name = actual_output_call[0][1]
                expected_output = entry.messaging_outputs[i]
                assert actual_output_message_data == expected_output.message
                assert actual_output_name == expected_output.name

    @staticmethod
    def _reset_messaging_call_counters_and_arguments(module_client):
        module_client.send_message_to_output.call_count = 0
        module_client.send_message_to_output.await_count = 0
        module_client.send_message_to_output.call_args_list = []

    @staticmethod
    def _assert_c2dm_response_call_counts(entry, module_client):
        if entry.c2dm_response_outputs is not None:
            actual_c2dm_response_calls_count = module_client.send_method_response.call_count
            if actual_c2dm_response_calls_count != len(entry.c2dm_response_outputs):
                error_message = f"Failed assert scenario entry calls for c2dm_response_outputs: " \
                                f"actual_c2dm_response_calls_count != c2dm_response_outputs_count" \
                                f" ({actual_c2dm_response_calls_count} != {len(entry.c2dm_response_outputs)})."
                log.error(error_message)
                raise AssertionError(error_message)
            else:
                assert module_client.send_method_response.call_count == len(entry.c2dm_response_outputs)
                assert module_client.send_method_response.await_count == len(entry.c2dm_response_outputs)

    @staticmethod
    def _assert_c2dm_response_call_arguments(entry, module_client):
        if entry.c2dm_response_outputs is not None:
            for i in range(len(entry.c2dm_response_outputs)):
                actual_output_calls = module_client.send_method_response.call_args_list
                actual_output_call = actual_output_calls[i]
                actual_output = actual_output_call[0][0]
                expected_output = entry.c2dm_response_outputs[i]
                actual_output_params = {
                    "status_code": actual_output.status,
                    "payload": actual_output.payload,
                }
                expected_output_params = {
                    "status_code": expected_output.status_code,
                    "payload": expected_output.payload
                }
                assert actual_output_params == expected_output_params

    @staticmethod
    def _reset_c2dm_response_call_counters_and_arguments(module_client):
        module_client.send_method_response.call_count = 0
        module_client.send_method_response.await_count = 0
        module_client.send_method_response.call_args_list = []
