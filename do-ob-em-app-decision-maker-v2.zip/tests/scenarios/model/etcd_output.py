from typing import Union


class EtcdOutput:
    """ Model for storing etcd output data for test scenario entry. """

    def __init__(
            self,
            key: str = None,
            value: Union[dict, str] = None,
    ):
        self._key = key
        self._value = value

    def __str__(self) -> str:
        return str(self.__dict__)

    @property
    def key(self) -> str:
        """ Get key """
        return self._key

    @property
    def value(self) -> Union[dict, str]:
        """ Get value """
        return self._value
