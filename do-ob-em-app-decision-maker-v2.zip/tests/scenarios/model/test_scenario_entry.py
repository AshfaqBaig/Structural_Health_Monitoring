from azure.iot.device import Message, MethodRequest
from etcd3.watch import WatchResponse

from tests.scenarios.model.c2dm_response_output import C2DMResponseOutput
from tests.scenarios.model.etcd_output import EtcdOutput
from tests.scenarios.model.messaging_output import MessagingOutput


class TestScenarioEntry:
    """ Model for storing entry data for test scenario. """

    def __init__(
            self,
            input_data=None,
            etcd_outputs: list[EtcdOutput] = None,
            messaging_outputs: list[MessagingOutput] = None,
            c2dm_response_outputs: list[C2DMResponseOutput] = None
    ):
        self._inbound_ev_message = None
        self._inbound_etcd_event = None
        self._c2dm_request = None
        self._instructions_loaded_on_boot = False

        if isinstance(input_data, Message):
            self._inbound_ev_message = input_data
        elif isinstance(input_data, WatchResponse):
            self._inbound_etcd_event = input_data
        elif isinstance(input_data, MethodRequest):
            self._c2dm_request = input_data
        elif "instructions_loaded_on_boot" in input_data:
            self._instructions_loaded_on_boot = True
        else:
            raise AssertionError("Unrecognised input data type, check your test scenario entry inputs.")

        self._etcd_outputs = etcd_outputs
        self._messaging_outputs = messaging_outputs
        self._c2dm_response_outputs = c2dm_response_outputs

    def __str__(self) -> str:
        return str(self.__dict__)

    @property
    def instructions_loaded_on_boot(self) -> bool:
        """ Get instructions_loaded_on_boot to test """
        return self._instructions_loaded_on_boot

    @property
    def inbound_ev_message(self) -> Message:
        """ Get inbound_ev_message to test """
        return self._inbound_ev_message

    @property
    def inbound_etcd_event(self) -> WatchResponse:
        """ Get inbound_etcd_event to test """
        return self._inbound_etcd_event

    @property
    def c2dm_request(self) -> MethodRequest:
        """ Get _c2dm_request to test """
        return self._c2dm_request

    @property
    def etcd_outputs(self) -> list[EtcdOutput]:
        """ Get etcd outputs to test """
        return self._etcd_outputs

    @property
    def messaging_outputs(self) -> list[MessagingOutput]:
        """ Get messaging outputs to test """
        return self._messaging_outputs

    @property
    def c2dm_response_outputs(self) -> list[C2DMResponseOutput]:
        """ Get c2dm response outputs to test """
        return self._c2dm_response_outputs
