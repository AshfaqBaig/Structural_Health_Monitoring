class C2DMResponseOutput:
    """ Model for storing c2dm response output data for test scenario entry. """

    def __init__(
            self,
            status_code: int,
            payload: dict = None,
    ):
        self._status_code = status_code
        self._payload = payload

    def __str__(self) -> str:
        return str(self.__dict__)

    @property
    def status_code(self) -> int:
        """ Get status_code """
        return self._status_code

    @property
    def payload(self) -> dict:
        """ Get payload """
        return self._payload
