class MessagingOutput:
    """ Model for storing messaging output data for test scenario entry. """

    def __init__(
            self,
            output_message: dict = None,
            output_name: str = None,
    ):
        self._message = output_message
        self._name = output_name

    def __str__(self) -> str:
        return str(self.__dict__)

    @property
    def message(self) -> dict:
        """ Get message """
        return self._message

    @property
    def name(self) -> str:
        """ Get name """
        return self._name
