from collections import namedtuple

from app.global_mould_state_enum import GlobalMouldState
from app.models.edge_cameras import EdgeCameras
from app.models.feedback_positions import FeedbackPositions
from app.models.graph import Graph
from tests.scenarios.model.test_scenario_entry import TestScenarioEntry

ScenarioData = namedtuple(
    "ScenarioData",
    [
        "initial_mould_state_instructions_data",
        "initial_mould_state_plies_data",
        "initial_mould_state",
        "initial_mould_blade_sn",
        "graph_data",
        "edge_to_cameras_data",
        "feedback_positions"
    ]
)


class TestScenario:
    """ Model to store data for edge verification test scenario. """

    def __init__(
            self,
            name: str,
            entries: list[TestScenarioEntry],
            scenario_data: ScenarioData
    ):
        self._name = name
        self._entries = entries
        self._initial_mould_state_instructions_data = scenario_data.initial_mould_state_instructions_data
        self._initial_mould_state_plies_data = scenario_data.initial_mould_state_plies_data
        self._initial_mould_state = scenario_data.initial_mould_state
        self._initial_mould_blade_sn = scenario_data.initial_mould_blade_sn
        self._graph = Graph(scenario_data.graph_data)
        self._edge_to_cameras = EdgeCameras(scenario_data.edge_to_cameras_data)
        self._feedback_positions = FeedbackPositions(scenario_data.feedback_positions)

    def __str__(self) -> str:
        """ Representation of this object with parameters """
        return str(self.__dict__)

    @property
    def name(self) -> str:
        """ Get name """
        return self._name

    @property
    def entries(self) -> list[TestScenarioEntry]:
        """ Get entries """
        return self._entries

    @property
    def initial_mould_state_instructions_data(self) -> dict:
        """ Get initial mould state instructions data """
        return self._initial_mould_state_instructions_data

    @property
    def initial_mould_state_plies_data(self) -> dict:
        """ Get initial mould state plies data """
        return self._initial_mould_state_plies_data

    @property
    def initial_mould_state(self) -> GlobalMouldState:
        """ Get initial global mould state """
        return self._initial_mould_state

    @property
    def initial_mould_blade_sn(self) -> str:
        """ Get initial global mould blade sn """
        return self._initial_mould_blade_sn

    @property
    def graph(self) -> Graph:
        """ Get graph """
        return self._graph

    @property
    def edge_to_cameras(self) -> EdgeCameras:
        """ Get edge_to_cameras """
        return self._edge_to_cameras

    @property
    def feedback_positions(self) -> FeedbackPositions:
        """ Get feedback_positions """
        return self._feedback_positions
