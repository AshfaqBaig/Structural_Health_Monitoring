# pylint: disable=protected-access, missing-module-docstring, missing-class-docstring, missing-function-docstring, duplicate-code, line-too-long, too-few-public-methods, no-self-use, too-many-locals, too-many-lines
from app.models.state.edge_cam_state import EdgeCamState
from app.models.state.edge_cam_state_enum import EdgeCamStateEnum
from app.models.state.edge_state import EdgeState
from app.models.state.edge_state_enum import EdgeStateEnum
from app.models.state.ply_state import PlyState
from app.models.state.ply_state_enum import PlyStateEnum
from tests.scenarios.scenarios_base import replace


class TeamInstructions:
    pallet_P_1: dict = {
        "version": "v1.0.0",
        "mouldId": "mould_id",
        "bladeSn": "blade_sn",
        "bladeRevision": "blade_revision",
        "layerId": "layer_P",
        "palletId": "pallet_1",
        "source_device": "device_module_id"
    }
    pallet_P_2: dict = {
        "version": "v1.0.0",
        "mouldId": "mould_id",
        "bladeSn": "blade_sn",
        "bladeRevision": "blade_revision",
        "layerId": "layer_P",
        "palletId": "pallet_2",
        "source_device": "device_module_id"
    }
    pallet_P_3: dict = {
        "version": "v1.0.0",
        "mouldId": "mould_id",
        "bladeSn": "blade_sn",
        "bladeRevision": "blade_revision",
        "layerId": "layer_P",
        "palletId": "pallet_3",
        "source_device": "device_module_id"
    }

    pallet_U_1: dict = {
        "version": "v1.0.0",
        "mouldId": "mould_id",
        "bladeSn": "blade_sn",
        "bladeRevision": "blade_revision",
        "layerId": "layer_U",
        "palletId": "pallet_1",
        "source_device": "device_module_id"
    }


static_graph_data: dict = {
    "mould_id": "mould_id",
    "blade_revision": "blade_revision",
    "version": "v1.0.0",
    "plies": {
        "P1": {
            "pallet_id": "pallet_1",
            "dxf_id": "dxf_id_P",
            "layer_id": "layer_P",
            "dxf_ply_id": "dxf_ply_id_P1",
            "edges": ["P1.1", "P1.2"],
            "edges_covered": [],
            "previous_plies": [],
            "next_plies": ["P2"],
        },
        "P2": {
            "pallet_id": "pallet_1",
            "dxf_id": "dxf_id_P",
            "layer_id": "layer_P",
            "dxf_ply_id": "dxf_ply_id_P2",
            "edges": ["P2.1", "P2.2"],
            "edges_covered": ["P1.2"],
            "previous_plies": ["P1"],
            "next_plies": ["P3"],
        },
        "P3": {
            "pallet_id": "pallet_1",
            "dxf_id": "dxf_id_P",
            "layer_id": "layer_P",
            "dxf_ply_id": "dxf_ply_id_P3",
            "edges": ["P3.1", "P3.2"],
            "edges_covered": ["P2.2"],
            "previous_plies": ["P2"],
            "next_plies": [],
        },
        "P4": {
            "pallet_id": "pallet_2",
            "dxf_id": "dxf_id_P",
            "layer_id": "layer_P",
            "dxf_ply_id": "dxf_ply_id_P4",
            "edges": ["P4.1", "P4.2"],
            "edges_covered": ["P3.2"],
            "previous_plies": [],
            "next_plies": ["P5"],
        },
        "P5": {
            "pallet_id": "pallet_2",
            "dxf_id": "dxf_id_P",
            "layer_id": "layer_P",
            "dxf_ply_id": "dxf_ply_id_P5",
            "edges": ["P5.1", "P5.2"],
            "edges_covered": ["P4.2"],
            "previous_plies": ["P4"],
            "next_plies": ["P6"],
        },
        "P6": {
            "pallet_id": "pallet_2",
            "dxf_id": "dxf_id_P",
            "layer_id": "layer_P",
            "dxf_ply_id": "dxf_ply_id_P6",
            "edges": ["P6.1", "P6.2"],
            "edges_covered": ["P5.2"],
            "previous_plies": ["P5"],
            "next_plies": [],
        },
        "P7": {
            "pallet_id": "pallet_3",
            "dxf_id": "dxf_id_P",
            "layer_id": "layer_P",
            "dxf_ply_id": "dxf_ply_id_P7",
            "edges": ["P7.1", "P7.2"],
            "edges_covered": ["P6.2"],
            "previous_plies": [],
            "next_plies": ["P8"],
        },
        "P8": {
            "pallet_id": "pallet_3",
            "dxf_id": "dxf_id_P",
            "layer_id": "layer_P",
            "dxf_ply_id": "dxf_ply_id_P8",
            "edges": ["P8.1", "P8.2"],
            "edges_covered": ["P7.2"],
            "previous_plies": ["P7"],
            "next_plies": ["P9"],
        },
        "P9": {
            "pallet_id": "pallet_3",
            "dxf_id": "dxf_id_P",
            "layer_id": "layer_P",
            "dxf_ply_id": "dxf_ply_id_P9",
            "edges": ["P9.1", "P9.2"],
            "edges_covered": ["P8.2"],
            "previous_plies": ["P8"],
            "next_plies": [],
        },

        # supposedly upper layer plies, alike layer UD1 starting at pallet_4
        "U1": {
            "pallet_id": "pallet_1",
            "dxf_id": "dxf_id_U",
            "layer_id": "layer_U",
            "dxf_ply_id": "dxf_ply_id_U1",
            "edges": ["U1.1", "U1.2"],
            "edges_covered": [],
            "previous_plies": [],
            "next_plies": ["U2"],
        },
        "U2": {
            "pallet_id": "pallet_1",
            "dxf_id": "dxf_id_U",
            "layer_id": "layer_U",
            "dxf_ply_id": "dxf_ply_id_U2",
            "edges": ["U2.1", "U2.2"],
            "edges_covered": ["U1.2"],
            "previous_plies": ["U1"],
            "next_plies": ["U3"],
        },
        "U3": {
            "pallet_id": "pallet_1",
            "dxf_id": "dxf_id_U",
            "layer_id": "layer_U",
            "dxf_ply_id": "dxf_ply_id_U3",
            "edges": ["U3.1", "U3.2"],
            "edges_covered": ["U2.2"],
            "previous_plies": ["U2"],
            "next_plies": ["U4"],
        },
        "U4": {
            "pallet_id": "pallet_1",
            "dxf_id": "dxf_id_U",
            "layer_id": "layer_U",
            "dxf_ply_id": "dxf_ply_id_U4",
            "edges": ["U4.1", "U4.2"],
            "edges_covered": ["U3.2"],
            "previous_plies": ["U3"],
            "next_plies": ["U5"],
        },
        "U5": {
            "pallet_id": "pallet_1",
            "dxf_id": "dxf_id_U",
            "layer_id": "layer_U",
            "dxf_ply_id": "dxf_ply_id_U5",
            "edges": ["U5.1", "U5.2"],
            "edges_covered": ["U4.2"],
            "previous_plies": ["U4"],
            "next_plies": ["U6"],
        },
        "U6": {
            "pallet_id": "pallet_1",
            "dxf_id": "dxf_id_U",
            "layer_id": "layer_U",
            "dxf_ply_id": "dxf_ply_id_U6",
            "edges": ["U6.1", "U6.2"],
            "edges_covered": ["U1.1", "U2.1", "U3.1", "U4.1", "U5.1", "U5.2"],
            "previous_plies": ["U1", "U2", "U3", "U4", "U5"],
            "next_plies": ["U7"],
        },
        "U7": {
            "pallet_id": "pallet_1",
            "dxf_id": "dxf_id_U",
            "layer_id": "layer_U",
            "dxf_ply_id": "dxf_ply_id_U7",
            "edges": ["U7.1", "U7.2"],
            "edges_covered": ["U6.2"],
            "previous_plies": ["U6"],
            "next_plies": [],
        },
    }
}


def create_laser_feedback_ply_data(ply_id): # TODO: refactor
    ply_data = {k: v for k, v in static_graph_data.get("plies").get(ply_id).items() if k not in ["edges", "edges_covered"]}
    ply_data["next_plies_pallets"] = [static_graph_data["plies"][ply_id]["pallet_id"] for p in
                                           static_graph_data["plies"][ply_id]["next_plies"]]
    return ply_data


class StaticGraph:
    class FirstPalletP:
        first_ply = {"P1": static_graph_data["plies"]["P1"]}
        first_ply_phantom = replace(first_ply, "edges", [])
        first_ply_invisible_edge_removed = replace(first_ply, "edges", ["P1.2"])
        second_ply = {"P2": static_graph_data["plies"]["P2"]}
        second_ply_phantom = replace(second_ply, "edges", [])
        third_ply = {"P3": static_graph_data["plies"]["P3"]}
        third_ply_phantom = replace(third_ply, "edges", [])
        third_ply_covers_next_pallet_plies = replace(
            replace(third_ply, "edges_covered", ["P2.2", "P4.1", "P5.1"]), "previous_plies", ["P2", "P4", "P5"])
        third_ply_does_not_cover_second_ply = replace(third_ply, "edges_covered", [])

    class SecondPalletP:
        fourth_ply = {"P4": static_graph_data["plies"]["P4"]}
        fourth_ply_does_not_cover_third_ply = replace(fourth_ply, "edges_covered", [])
        fourth_ply_depends_on_second_ply = replace(fourth_ply_does_not_cover_third_ply, "previous_plies", ["P2"])
        fifth_ply = {"P5": static_graph_data["plies"]["P5"]}
        sixth_ply = {"P6": static_graph_data["plies"]["P6"]}

    class ThirdPalletP:
        seventh_ply = {"P7": static_graph_data["plies"]["P7"]}
        eighth_ply = {"P8": static_graph_data["plies"]["P8"]}
        ninth_ply = {"P9": static_graph_data["plies"]["P9"]}
        ninth_ply_invisible_edge_removed = replace(ninth_ply, "edges", ["P9.1"])

    class FirstPalletU:
        first_ply = {"U1": static_graph_data["plies"]["U1"]}
        first_ply_phantom = replace(first_ply, "edges", [])
        second_ply = {"U2": static_graph_data["plies"]["U2"]}
        second_ply_fully_covers_first_ply = replace(second_ply, "edges_covered", ["U1.1", "U1.2"])
        second_ply_phantom_fully_covers_first_ply = replace(
            second_ply_fully_covers_first_ply, "edges", [])
        third_ply = {"U3": static_graph_data["plies"]["U3"]}
        third_ply_fully_covers_second_ply = replace(third_ply, "edges_covered", ["U2.1", "U2.2"])
        third_ply_does_not_cover_second_ply = replace(third_ply, "edges_covered", [])
        fourth_ply = {"U4": static_graph_data["plies"]["U4"]}
        fifth_ply = {"U5": static_graph_data["plies"]["U5"]}
        fifth_ply_fully_covers_fourth_ply = replace(fifth_ply, "edges_covered", ["U4.1", "U4.2"])
        sixth_ply = {"U6": static_graph_data["plies"]["U6"]}
        sixth_ply_phantom = replace(sixth_ply, "edges", [])
        seventh_ply = {"U7": static_graph_data["plies"]["U7"]}


class StaticGraphPlyEdges:
    class FirstPalletP:
        first_ply_edges = static_graph_data["plies"]["P1"]["edges"]
        second_ply_edges = static_graph_data["plies"]["P2"]["edges"]
        third_ply_edges = static_graph_data["plies"]["P3"]["edges"]

    class SecondPalletP:
        fourth_ply_edges = static_graph_data["plies"]["P4"]["edges"]
        fifth_ply_edges = static_graph_data["plies"]["P5"]["edges"]
        sixth_ply_edges = static_graph_data["plies"]["P6"]["edges"]

    class ThirdPalletP:
        seventh_ply_edges = static_graph_data["plies"]["P7"]["edges"]
        eighth_ply_edges = static_graph_data["plies"]["P8"]["edges"]
        ninth_ply_edges = static_graph_data["plies"]["P9"]["edges"]


edge_to_cameras_data: dict = {
    "mould_id": "mould_id",
    "blade_revision": "blade_revision",
    "version": "v1.0.0",
    "edges": {
        "P1.1": [],
        "P1.2": ["cam1"],
        "P2.1": ["cam1", "cam2"],
        "P2.2": ["cam2"],
        "P3.1": ["cam2"],
        "P3.2": ["cam3"],
        "P4.1": ["cam3"],
        "P4.2": ["cam3", "cam4"],
        "P5.1": ["cam4"],
        "P5.2": ["cam4"],
        "P6.1": ["cam4", "cam5"],
        "P6.2": ["cam5"],
        "P7.1": ["cam5"],
        "P7.2": ["cam5", "cam6"],
        "P8.1": ["cam6"],
        "P8.2": ["cam6"],
        "P9.1": ["cam6"],
        "P9.2": [],

        "U1.1": ["cam1"],
        "U1.2": ["cam1"],
        "U2.1": ["cam1"],
        "U2.2": ["cam1", "cam2"],
        "U3.1": ["cam2"],
        "U3.2": ["cam2"],
        "U4.1": ["cam2"],
        "U4.2": ["cam2"],
        "U5.1": ["cam2", "cam3"],
        "U5.2": ["cam2", "cam3"],
        "U6.1": ["cam2", "cam3"],
        "U6.2": ["cam2", "cam3"],
        "U7.1": ["cam2", "cam3"],
        "U7.2": ["cam2", "cam3"],
    }
}

feedback_positions_data: dict = {
    "mould_id": "mould_id",
    "blade_revision": "blade_revision",
    "version": "v1.0.0",
    "plies": {
        "P1": {
            "mid_point": [1, 0, 1]
        },
        "P2": {
            "mid_point": [1, 0, 2]
        },
        "P3": {
            "mid_point": [1, 0, 3]
        },
        "P4": {
            "mid_point": [1, 0, 4]
        },
        "P5": {
            "mid_point": [1, 0, 5]
        },
        "P6": {
            "mid_point": [1, 0, 6]
        },
        "P7": {
            "mid_point": [1, 0, 7]
        },
        "P8": {
            "mid_point": [1, 0, 8]
        },
        "P9": {
            "mid_point": [1, 0, 9]
        },

        "U1": {
            "mid_point": [1, 1, 1]
        },
        "U2": {
            "mid_point": [1, 1, 2]
        },
        "U3": {
            "mid_point": [1, 1, 3]
        },
        "U4": {
            "mid_point": [1, 1, 4]
        },
        "U5": {
            "mid_point": [1, 1, 5]
        },
        "U6": {
            "mid_point": [1, 1, 6]
        },
        "U7": {
            "mid_point": [1, 1, 7]
        },
    }
}


class MouldStatePlies:
    class PalletP:
        first_ply_expected = PlyState(
            "P1",
            edges={
                EdgeState(
                    "P1.1",
                    cams=set(),
                    state=EdgeStateEnum.MISSING
                ),
                EdgeState(
                    "P1.2",
                    cams={
                        EdgeCamState("cam1", EdgeCamStateEnum.NEVER_DETECTED),
                    },
                    state=EdgeStateEnum.MISSING
                ),
            },
            state=PlyStateEnum.EXPECTED,
            previous_state=None,
            updated_by="initial",
            source_device="device_module_id"
        )
        first_ply_phantom_forced_on_expected = PlyState(
            "P1",
            edges=set(),
            state=PlyStateEnum.FORCED,
            previous_state=PlyStateEnum.EXPECTED,
            updated_by="command:force_ply",
            source_device="device_module_id"
        )
        first_ply_placed = PlyState(
            "P1",
            edges={
                EdgeState(
                    "P1.1",
                    cams=set(),
                    state=EdgeStateEnum.DETECTED
                ),
                EdgeState(
                    "P1.2",
                    cams={
                        EdgeCamState("cam1", EdgeCamStateEnum.DETECTED),
                    },
                    state=EdgeStateEnum.DETECTED
                ),
            },
            state=PlyStateEnum.PLACED,
            previous_state=PlyStateEnum.EXPECTED,
            updated_by="cam:cam1",
            source_device="device_module_id"
        )
        first_ply_placed_according_to_other_device = PlyState(
            "P1",
            edges={
                EdgeState(
                    "P1.1",
                    cams=set(),
                    state=EdgeStateEnum.DETECTED
                ),
                EdgeState(
                    "P1.2",
                    cams={
                        EdgeCamState("cam1", EdgeCamStateEnum.DETECTED),
                    },
                    state=EdgeStateEnum.DETECTED
                ),
            },
            state=PlyStateEnum.PLACED,
            previous_state=PlyStateEnum.EXPECTED,
            updated_by="cam:cam1",
            source_device="other_device_module_id"
        )
        first_ply_partially_covered = PlyState(
            "P1",
            edges={
                EdgeState(
                    "P1.1",
                    cams=set(),
                    state=EdgeStateEnum.DETECTED
                ),
                EdgeState(
                    "P1.2",
                    cams={
                        EdgeCamState("cam1", EdgeCamStateEnum.DETECTED),
                    },
                    state=EdgeStateEnum.COVERED
                ),
            },
            state=PlyStateEnum.PLACED,
            previous_state=PlyStateEnum.PLACED,
            updated_by="ply:P2",
            source_device="device_module_id"
        )
        first_ply_expected_without_invisible_edge = PlyState(
            "P1",
            edges={
                EdgeState(
                    "P1.2",
                    cams={
                        EdgeCamState("cam1", EdgeCamStateEnum.NEVER_DETECTED),
                    },
                    state=EdgeStateEnum.MISSING
                ),
            },
            state=PlyStateEnum.EXPECTED,
            previous_state=None,
            updated_by="initial",
            source_device="device_module_id"
        )
        first_ply_placed_without_invisible_edge = PlyState(
            "P1",
            edges={
                EdgeState(
                    "P1.2",
                    cams={
                        EdgeCamState("cam1", EdgeCamStateEnum.DETECTED),
                    },
                    state=EdgeStateEnum.DETECTED
                ),
            },
            state=PlyStateEnum.PLACED,
            previous_state=PlyStateEnum.EXPECTED,
            updated_by="cam:cam1",
            source_device="device_module_id"
        )
        first_ply_placed_without_invisible_edge_on_missing = PlyState(
            "P1",
            edges={
                EdgeState(
                    "P1.2",
                    cams={
                        EdgeCamState("cam1", EdgeCamStateEnum.DETECTED),
                    },
                    state=EdgeStateEnum.DETECTED
                ),
            },
            state=PlyStateEnum.PLACED,
            previous_state=PlyStateEnum.MISSING,
            updated_by="cam:cam1",
            source_device="device_module_id"
        )
        first_ply_phantom_expected = PlyState(
            "P1",
            edges=set(),
            state=PlyStateEnum.EXPECTED,
            previous_state=None,
            updated_by="initial",
            source_device="device_module_id"
        )
        first_ply_placed_without_invisible_edge_reset_due_undo = PlyState(
            "P1",
            edges={
                EdgeState(
                    "P1.2",
                    cams={
                        EdgeCamState("cam1", EdgeCamStateEnum.NEVER_DETECTED),
                    },
                    state=EdgeStateEnum.MISSING
                ),
            },
            state=PlyStateEnum.EXPECTED,
            previous_state=PlyStateEnum.PLACED,
            updated_by="command:undo_ply:force",
            source_device="device_module_id"
        )
        first_ply_placed_without_invisible_edge_reset_due_undo_via_other_device = PlyState(
            "P1",
            edges={
                EdgeState(
                    "P1.2",
                    cams={
                        EdgeCamState("cam1", EdgeCamStateEnum.NEVER_DETECTED),
                    },
                    state=EdgeStateEnum.MISSING
                ),
            },
            state=PlyStateEnum.EXPECTED,
            previous_state=PlyStateEnum.PLACED,
            updated_by="command:undo_ply:force",
            source_device="other_device_module_id"
        )
        first_ply_missing_without_invisible_edge = PlyState(
            "P1",
            edges={
                EdgeState(
                    "P1.2",
                    cams={
                        EdgeCamState("cam1", EdgeCamStateEnum.MISSING),
                    },
                    state=EdgeStateEnum.MISSING
                ),
            },
            state=PlyStateEnum.MISSING,
            previous_state=PlyStateEnum.PLACED,
            updated_by="cam:cam1",
            source_device="device_module_id"
        )
        first_ply_placed_without_invisible_edge_according_to_other_device = PlyState(
            "P1",
            edges={
                EdgeState(
                    "P1.2",
                    cams={
                        EdgeCamState("cam1", EdgeCamStateEnum.DETECTED),
                    },
                    state=EdgeStateEnum.DETECTED
                ),
            },
            state=PlyStateEnum.PLACED,
            previous_state=PlyStateEnum.EXPECTED,
            updated_by="cam:cam1",
            source_device="other_device_module_id"
        )
        first_ply_covered_without_invisible_edge = PlyState(
            "P1",
            edges={
                EdgeState(
                    "P1.2",
                    cams={
                        EdgeCamState("cam1", EdgeCamStateEnum.DETECTED),
                    },
                    state=EdgeStateEnum.COVERED
                ),
            },
            state=PlyStateEnum.COVERED,
            previous_state=PlyStateEnum.PLACED,
            updated_by="ply:P2",
            source_device="device_module_id"
        )
        first_ply_covered_without_invisible_edge_reset_due_undo = PlyState(
            "P1",
            edges={
                EdgeState(
                    "P1.2",
                    cams={
                        EdgeCamState("cam1", EdgeCamStateEnum.DETECTED),
                    },
                    state=EdgeStateEnum.DETECTED
                ),
            },
            state=PlyStateEnum.PLACED,
            previous_state=PlyStateEnum.COVERED,
            updated_by="command:undo_ply:force",
            source_device="device_module_id"
        )
        first_ply_covered_without_invisible_edge_reset_due_undo_via_other_device = PlyState(
            "P1",
            edges={
                EdgeState(
                    "P1.2",
                    cams={
                        EdgeCamState("cam1", EdgeCamStateEnum.DETECTED),
                    },
                    state=EdgeStateEnum.DETECTED
                ),
            },
            state=PlyStateEnum.PLACED,
            previous_state=PlyStateEnum.COVERED,
            updated_by="command:undo_ply:force",
            source_device="other_device_module_id"
        )
        first_ply_covered_on_missing_without_invisible_edge = PlyState(
            "P1",
            edges={
                EdgeState(
                    "P1.2",
                    cams={
                        EdgeCamState("cam1", EdgeCamStateEnum.MISSING),
                    },
                    state=EdgeStateEnum.COVERED
                ),
            },
            state=PlyStateEnum.COVERED,
            previous_state=PlyStateEnum.MISSING,
            updated_by="ply:P2",
            source_device="device_module_id"
        )
        second_ply_expected = PlyState(
            "P2",
            edges={
                EdgeState(
                    "P2.1",
                    cams={
                        EdgeCamState("cam1", EdgeCamStateEnum.NEVER_DETECTED),
                        EdgeCamState("cam2", EdgeCamStateEnum.NEVER_DETECTED),
                    },
                    state=EdgeStateEnum.MISSING
                ),
                EdgeState(
                    "P2.2",
                    cams={
                        EdgeCamState("cam2", EdgeCamStateEnum.NEVER_DETECTED),
                    },
                    state=EdgeStateEnum.MISSING
                ),
            },
            state=PlyStateEnum.EXPECTED,
            previous_state=None,
            updated_by="initial",
            source_device="device_module_id"
        )
        second_ply_phantom_expected = PlyState(
            "P2",
            edges=set(),
            state=PlyStateEnum.EXPECTED,
            previous_state=None,
            updated_by="initial",
            source_device="device_module_id"
        )
        second_ply_forced_on_expected = PlyState(
            "P2",
            edges={
                EdgeState(
                    "P2.1",
                    cams={
                        EdgeCamState("cam1", EdgeCamStateEnum.NEVER_DETECTED),
                        EdgeCamState("cam2", EdgeCamStateEnum.NEVER_DETECTED),
                    },
                    state=EdgeStateEnum.FORCED
                ),
                EdgeState(
                    "P2.2",
                    cams={
                        EdgeCamState("cam2", EdgeCamStateEnum.NEVER_DETECTED),
                    },
                    state=EdgeStateEnum.FORCED
                ),
            },
            state=PlyStateEnum.FORCED,
            previous_state=PlyStateEnum.EXPECTED,
            updated_by="command:force_ply",
            source_device="device_module_id"
        )
        second_ply_partially_covered_on_forced = PlyState(
            "P2",
            edges={
                EdgeState(
                    "P2.1",
                    cams={
                        EdgeCamState("cam1", EdgeCamStateEnum.NEVER_DETECTED),
                        EdgeCamState("cam2", EdgeCamStateEnum.NEVER_DETECTED),
                    },
                    state=EdgeStateEnum.FORCED
                ),
                EdgeState(
                    "P2.2",
                    cams={
                        EdgeCamState("cam2", EdgeCamStateEnum.NEVER_DETECTED),
                    },
                    state=EdgeStateEnum.COVERED
                ),
            },
            state=PlyStateEnum.FORCED,
            previous_state=PlyStateEnum.EXPECTED,
            updated_by="ply:P3",
            source_device="device_module_id"
        )
        second_ply_recheck_on_expected = PlyState(
            "P2",
            edges={
                EdgeState(
                    "P2.1",
                    cams={
                        EdgeCamState("cam1", EdgeCamStateEnum.NEVER_DETECTED),
                        EdgeCamState("cam2", EdgeCamStateEnum.NEVER_DETECTED),
                    },
                    state=EdgeStateEnum.MISSING
                ),
                EdgeState(
                    "P2.2",
                    cams={
                        EdgeCamState("cam2", EdgeCamStateEnum.NEVER_DETECTED),
                    },
                    state=EdgeStateEnum.MISSING
                ),
            },
            state=PlyStateEnum.MISSING,
            previous_state=PlyStateEnum.EXPECTED,
            updated_by="command:recheck_ply:force",
            source_device="device_module_id"
        )
        second_ply_recheck_on_placed = PlyState(
            "P2",
            edges={
                EdgeState(
                    "P2.1",
                    cams={
                        EdgeCamState("cam1", EdgeCamStateEnum.NEVER_DETECTED),
                        EdgeCamState("cam2", EdgeCamStateEnum.NEVER_DETECTED),
                    },
                    state=EdgeStateEnum.MISSING
                ),
                EdgeState(
                    "P2.2",
                    cams={
                        EdgeCamState("cam2", EdgeCamStateEnum.NEVER_DETECTED),
                    },
                    state=EdgeStateEnum.MISSING
                ),
            },
            state=PlyStateEnum.MISSING,
            previous_state=PlyStateEnum.PLACED,
            updated_by="command:recheck_ply:force",
            source_device="device_module_id"
        )
        second_ply_recheck_on_placed_via_other_device = PlyState(
            "P2",
            edges={
                EdgeState(
                    "P2.1",
                    cams={
                        EdgeCamState("cam1", EdgeCamStateEnum.NEVER_DETECTED),
                        EdgeCamState("cam2", EdgeCamStateEnum.NEVER_DETECTED),
                    },
                    state=EdgeStateEnum.MISSING
                ),
                EdgeState(
                    "P2.2",
                    cams={
                        EdgeCamState("cam2", EdgeCamStateEnum.NEVER_DETECTED),
                    },
                    state=EdgeStateEnum.MISSING
                ),
            },
            state=PlyStateEnum.MISSING,
            previous_state=PlyStateEnum.PLACED,
            updated_by="command:recheck_ply:force",
            source_device="other_device_module_id"
        )
        second_ply_recheck_on_forced = PlyState(
            "P2",
            edges={
                EdgeState(
                    "P2.1",
                    cams={
                        EdgeCamState("cam1", EdgeCamStateEnum.NEVER_DETECTED),
                        EdgeCamState("cam2", EdgeCamStateEnum.NEVER_DETECTED),
                    },
                    state=EdgeStateEnum.MISSING
                ),
                EdgeState(
                    "P2.2",
                    cams={
                        EdgeCamState("cam2", EdgeCamStateEnum.NEVER_DETECTED),
                    },
                    state=EdgeStateEnum.MISSING
                ),
            },
            state=PlyStateEnum.MISSING,
            previous_state=PlyStateEnum.FORCED,
            updated_by="command:recheck_ply:force",
            source_device="device_module_id"
        )
        second_ply_recheck_on_forced_via_other_device = PlyState(
            "P2",
            edges={
                EdgeState(
                    "P2.1",
                    cams={
                        EdgeCamState("cam1", EdgeCamStateEnum.NEVER_DETECTED),
                        EdgeCamState("cam2", EdgeCamStateEnum.NEVER_DETECTED),
                    },
                    state=EdgeStateEnum.MISSING
                ),
                EdgeState(
                    "P2.2",
                    cams={
                        EdgeCamState("cam2", EdgeCamStateEnum.NEVER_DETECTED),
                    },
                    state=EdgeStateEnum.MISSING
                ),
            },
            state=PlyStateEnum.MISSING,
            previous_state=PlyStateEnum.FORCED,
            updated_by="command:recheck_ply:force",
            source_device="other_device_module_id"
        )
        second_ply_forced_on_missing = PlyState(
            "P2",
            edges={
                EdgeState(
                    "P2.1",
                    cams={
                        EdgeCamState("cam1", EdgeCamStateEnum.MISSING),
                        EdgeCamState("cam2", EdgeCamStateEnum.MISSING),
                    },
                    state=EdgeStateEnum.FORCED
                ),
                EdgeState(
                    "P2.2",
                    cams={
                        EdgeCamState("cam2", EdgeCamStateEnum.MISSING),
                    },
                    state=EdgeStateEnum.FORCED
                ),
            },
            state=PlyStateEnum.FORCED,
            previous_state=PlyStateEnum.MISSING,
            updated_by="command:force_ply",
            source_device="device_module_id"
        )
        second_ply_recheck_on_missing = PlyState(
            "P2",
            edges={
                EdgeState(
                    "P2.1",
                    cams={
                        EdgeCamState("cam1", EdgeCamStateEnum.NEVER_DETECTED),
                        EdgeCamState("cam2", EdgeCamStateEnum.NEVER_DETECTED),
                    },
                    state=EdgeStateEnum.MISSING
                ),
                EdgeState(
                    "P2.2",
                    cams={
                        EdgeCamState("cam2", EdgeCamStateEnum.NEVER_DETECTED),
                    },
                    state=EdgeStateEnum.MISSING
                ),
            },
            state=PlyStateEnum.MISSING,
            previous_state=PlyStateEnum.MISSING,
            updated_by="command:recheck_ply:force",
            source_device="device_module_id"
        )
        second_ply_partially_covered_recheck_on_missing = PlyState(
            "P2",
            edges={
                EdgeState(
                    "P2.1",
                    cams={
                        EdgeCamState("cam1", EdgeCamStateEnum.NEVER_DETECTED),
                        EdgeCamState("cam2", EdgeCamStateEnum.NEVER_DETECTED),
                    },
                    state=EdgeStateEnum.MISSING
                ),
                EdgeState(
                    "P2.2",
                    cams={
                        EdgeCamState("cam2", EdgeCamStateEnum.MISSING),
                    },
                    state=EdgeStateEnum.COVERED
                ),
            },
            state=PlyStateEnum.MISSING,
            previous_state=PlyStateEnum.MISSING,
            updated_by="command:recheck_ply:force",
            source_device="device_module_id"
        )
        second_ply_partially_covered_recheck_on_missing_via_other_device = PlyState(
            "P2",
            edges={
                EdgeState(
                    "P2.1",
                    cams={
                        EdgeCamState("cam1", EdgeCamStateEnum.NEVER_DETECTED),
                        EdgeCamState("cam2", EdgeCamStateEnum.NEVER_DETECTED),
                    },
                    state=EdgeStateEnum.MISSING
                ),
                EdgeState(
                    "P2.2",
                    cams={
                        EdgeCamState("cam2", EdgeCamStateEnum.MISSING),
                    },
                    state=EdgeStateEnum.COVERED
                ),
            },
            state=PlyStateEnum.MISSING,
            previous_state=PlyStateEnum.MISSING,
            updated_by="command:recheck_ply:force",
            source_device="other_device_module_id"
        )
        second_ply_partially_covered_recheck_on_placed = PlyState(
            "P2",
            edges={
                EdgeState(
                    "P2.1",
                    cams={
                        EdgeCamState("cam1", EdgeCamStateEnum.NEVER_DETECTED),
                        EdgeCamState("cam2", EdgeCamStateEnum.NEVER_DETECTED),
                    },
                    state=EdgeStateEnum.MISSING
                ),
                EdgeState(
                    "P2.2",
                    cams={
                        EdgeCamState("cam2", EdgeCamStateEnum.MISSING),
                    },
                    state=EdgeStateEnum.COVERED
                ),
            },
            state=PlyStateEnum.MISSING,
            previous_state=PlyStateEnum.PLACED,
            updated_by="command:recheck_ply:force",
            source_device="device_module_id"
        )
        second_ply_partially_covered_recheck_on_placed_via_other_device = PlyState(
            "P2",
            edges={
                EdgeState(
                    "P2.1",
                    cams={
                        EdgeCamState("cam1", EdgeCamStateEnum.NEVER_DETECTED),
                        EdgeCamState("cam2", EdgeCamStateEnum.NEVER_DETECTED),
                    },
                    state=EdgeStateEnum.MISSING
                ),
                EdgeState(
                    "P2.2",
                    cams={
                        EdgeCamState("cam2", EdgeCamStateEnum.MISSING),
                    },
                    state=EdgeStateEnum.COVERED
                ),
            },
            state=PlyStateEnum.MISSING,
            previous_state=PlyStateEnum.PLACED,
            updated_by="command:recheck_ply:force",
            source_device="other_device_module_id"
        )
        second_ply_forced_on_partially_detected = PlyState(
            "P2",
            edges={
                EdgeState(
                    "P2.1",
                    cams={
                        EdgeCamState("cam1", EdgeCamStateEnum.NEVER_DETECTED),
                        EdgeCamState("cam2", EdgeCamStateEnum.NEVER_DETECTED),
                    },
                    state=EdgeStateEnum.FORCED
                ),
                EdgeState(
                    "P2.2",
                    cams={
                        EdgeCamState("cam2", EdgeCamStateEnum.DETECTED),
                    },
                    state=EdgeStateEnum.FORCED
                ),
            },
            state=PlyStateEnum.FORCED,
            previous_state=PlyStateEnum.EXPECTED,
            updated_by="command:force_ply",
            source_device="device_module_id"
        )
        second_ply_recheck_on_partially_detected = PlyState(
            "P2",
            edges={
                EdgeState(
                    "P2.1",
                    cams={
                        EdgeCamState("cam1", EdgeCamStateEnum.NEVER_DETECTED),
                        EdgeCamState("cam2", EdgeCamStateEnum.NEVER_DETECTED),
                    },
                    state=EdgeStateEnum.MISSING
                ),
                EdgeState(
                    "P2.2",
                    cams={
                        EdgeCamState("cam2", EdgeCamStateEnum.NEVER_DETECTED),
                    },
                    state=EdgeStateEnum.MISSING
                ),
            },
            state=PlyStateEnum.MISSING,
            previous_state=PlyStateEnum.EXPECTED,
            updated_by="command:recheck_ply:force",
            source_device="device_module_id"
        )
        second_ply_recheck_on_partially_detected_via_other_device = PlyState(
            "P2",
            edges={
                EdgeState(
                    "P2.1",
                    cams={
                        EdgeCamState("cam1", EdgeCamStateEnum.NEVER_DETECTED),
                        EdgeCamState("cam2", EdgeCamStateEnum.NEVER_DETECTED),
                    },
                    state=EdgeStateEnum.MISSING
                ),
                EdgeState(
                    "P2.2",
                    cams={
                        EdgeCamState("cam2", EdgeCamStateEnum.NEVER_DETECTED),
                    },
                    state=EdgeStateEnum.MISSING
                ),
            },
            state=PlyStateEnum.MISSING,
            previous_state=PlyStateEnum.EXPECTED,
            updated_by="command:recheck_ply:force",
            source_device="other_device_module_id"
        )
        second_ply_recheck_on_expected_via_other_device = PlyState(
            "P2",
            edges={
                EdgeState(
                    "P2.1",
                    cams={
                        EdgeCamState("cam1", EdgeCamStateEnum.NEVER_DETECTED),
                        EdgeCamState("cam2", EdgeCamStateEnum.NEVER_DETECTED),
                    },
                    state=EdgeStateEnum.MISSING
                ),
                EdgeState(
                    "P2.2",
                    cams={
                        EdgeCamState("cam2", EdgeCamStateEnum.NEVER_DETECTED),
                    },
                    state=EdgeStateEnum.MISSING
                ),
            },
            state=PlyStateEnum.MISSING,
            previous_state=PlyStateEnum.EXPECTED,
            updated_by="command:recheck_ply:force",
            source_device="other_device_module_id"
        )
        second_ply_recheck_on_missing_via_other_device = PlyState(
            "P2",
            edges={
                EdgeState(
                    "P2.1",
                    cams={
                        EdgeCamState("cam1", EdgeCamStateEnum.NEVER_DETECTED),
                        EdgeCamState("cam2", EdgeCamStateEnum.NEVER_DETECTED),
                    },
                    state=EdgeStateEnum.MISSING
                ),
                EdgeState(
                    "P2.2",
                    cams={
                        EdgeCamState("cam2", EdgeCamStateEnum.NEVER_DETECTED),
                    },
                    state=EdgeStateEnum.MISSING
                ),
            },
            state=PlyStateEnum.MISSING,
            previous_state=PlyStateEnum.MISSING,
            updated_by="command:recheck_ply:force",
            source_device="other_device_module_id"
        )
        second_ply_placed = PlyState(
            "P2",
            edges={
                EdgeState(
                    "P2.1",
                    cams={
                        EdgeCamState("cam1", EdgeCamStateEnum.NEVER_DETECTED),
                        EdgeCamState("cam2", EdgeCamStateEnum.DETECTED),
                    },
                    state=EdgeStateEnum.DETECTED
                ),
                EdgeState(
                    "P2.2",
                    cams={
                        EdgeCamState("cam2", EdgeCamStateEnum.DETECTED),
                    },
                    state=EdgeStateEnum.DETECTED
                ),
            },
            state=PlyStateEnum.PLACED,
            previous_state=PlyStateEnum.EXPECTED,
            updated_by="cam:cam2",
            source_device="device_module_id"
        )
        second_ply_undone_on_placed = PlyState(
            "P2",
            edges={
                EdgeState(
                    "P2.1",
                    cams={
                        EdgeCamState("cam1", EdgeCamStateEnum.NEVER_DETECTED),
                        EdgeCamState("cam2", EdgeCamStateEnum.NEVER_DETECTED),
                    },
                    state=EdgeStateEnum.MISSING
                ),
                EdgeState(
                    "P2.2",
                    cams={
                        EdgeCamState("cam2", EdgeCamStateEnum.NEVER_DETECTED),
                    },
                    state=EdgeStateEnum.MISSING
                ),
            },
            state=PlyStateEnum.EXPECTED,
            previous_state=PlyStateEnum.PLACED,
            updated_by="command:undo_ply:force",
            source_device="device_module_id"
        )
        second_ply_undone_on_placed_via_other_device = PlyState(
            "P2",
            edges={
                EdgeState(
                    "P2.1",
                    cams={
                        EdgeCamState("cam1", EdgeCamStateEnum.NEVER_DETECTED),
                        EdgeCamState("cam2", EdgeCamStateEnum.NEVER_DETECTED),
                    },
                    state=EdgeStateEnum.MISSING
                ),
                EdgeState(
                    "P2.2",
                    cams={
                        EdgeCamState("cam2", EdgeCamStateEnum.NEVER_DETECTED),
                    },
                    state=EdgeStateEnum.MISSING
                ),
            },
            state=PlyStateEnum.EXPECTED,
            previous_state=PlyStateEnum.PLACED,
            updated_by="command:undo_ply:force",
            source_device="other_device_module_id"
        )
        second_ply_undone_on_missing = PlyState(
            "P2",
            edges={
                EdgeState(
                    "P2.1",
                    cams={
                        EdgeCamState("cam1", EdgeCamStateEnum.NEVER_DETECTED),
                        EdgeCamState("cam2", EdgeCamStateEnum.NEVER_DETECTED),
                    },
                    state=EdgeStateEnum.MISSING
                ),
                EdgeState(
                    "P2.2",
                    cams={
                        EdgeCamState("cam2", EdgeCamStateEnum.MISSING),
                    },
                    state=EdgeStateEnum.MISSING
                ),
            },
            state=PlyStateEnum.EXPECTED,
            previous_state=PlyStateEnum.MISSING,
            updated_by="command:undo_ply:force",
            source_device="device_module_id"
        )
        second_ply_undone_on_missing_via_other_device = PlyState(
            "P2",
            edges={
                EdgeState(
                    "P2.1",
                    cams={
                        EdgeCamState("cam1", EdgeCamStateEnum.NEVER_DETECTED),
                        EdgeCamState("cam2", EdgeCamStateEnum.NEVER_DETECTED),
                    },
                    state=EdgeStateEnum.MISSING
                ),
                EdgeState(
                    "P2.2",
                    cams={
                        EdgeCamState("cam2", EdgeCamStateEnum.MISSING),
                    },
                    state=EdgeStateEnum.MISSING
                ),
            },
            state=PlyStateEnum.EXPECTED,
            previous_state=PlyStateEnum.MISSING,
            updated_by="command:undo_ply:force",
            source_device="other_device_module_id"
        )
        second_ply_phantom_forced_reset_due_undo = PlyState(
            "P2",
            edges=set(),
            state=PlyStateEnum.EXPECTED,
            previous_state=PlyStateEnum.FORCED,
            updated_by="command:undo_ply:force",
            source_device="device_module_id"
        )
        second_ply_phantom_forced_reset_due_undo_via_other_device = PlyState(
            "P2",
            edges=set(),
            state=PlyStateEnum.EXPECTED,
            previous_state=PlyStateEnum.FORCED,
            updated_by="command:undo_ply:force",
            source_device="other_device_module_id"
        )
        second_ply_phantom_forced_on_expected = PlyState(
            "P2",
            edges=set(),
            state=PlyStateEnum.FORCED,
            previous_state=PlyStateEnum.EXPECTED,
            updated_by="command:force_ply",
            source_device="device_module_id"
        )
        second_ply_placed_after_missing = PlyState(
            "P2",
            edges={
                EdgeState(
                    "P2.1",
                    cams={
                        EdgeCamState("cam1", EdgeCamStateEnum.NEVER_DETECTED),
                        EdgeCamState("cam2", EdgeCamStateEnum.DETECTED),
                    },
                    state=EdgeStateEnum.DETECTED
                ),
                EdgeState(
                    "P2.2",
                    cams={
                        EdgeCamState("cam2", EdgeCamStateEnum.DETECTED),
                    },
                    state=EdgeStateEnum.DETECTED
                ),
            },
            state=PlyStateEnum.PLACED,
            previous_state=PlyStateEnum.MISSING,
            updated_by="cam:cam2",
            source_device="device_module_id"
        )
        second_ply_placed_reset_due_undo = PlyState(
            "P2",
            edges={
                EdgeState(
                    "P2.1",
                    cams={
                        EdgeCamState("cam1", EdgeCamStateEnum.NEVER_DETECTED),
                        EdgeCamState("cam2", EdgeCamStateEnum.NEVER_DETECTED),
                    },
                    state=EdgeStateEnum.MISSING
                ),
                EdgeState(
                    "P2.2",
                    cams={
                        EdgeCamState("cam2", EdgeCamStateEnum.NEVER_DETECTED),
                    },
                    state=EdgeStateEnum.MISSING
                ),
            },
            state=PlyStateEnum.EXPECTED,
            previous_state=PlyStateEnum.PLACED,
            updated_by="command:undo_ply:force",
            source_device="device_module_id"
        )
        second_ply_partially_detected = PlyState(
            "P2",
            edges={
                EdgeState(
                    "P2.1",
                    cams={
                        EdgeCamState("cam1", EdgeCamStateEnum.NEVER_DETECTED),
                        EdgeCamState("cam2", EdgeCamStateEnum.NEVER_DETECTED),
                    },
                    state=EdgeStateEnum.MISSING
                ),
                EdgeState(
                    "P2.2",
                    cams={
                        EdgeCamState("cam2", EdgeCamStateEnum.DETECTED),
                    },
                    state=EdgeStateEnum.DETECTED
                ),
            },
            state=PlyStateEnum.EXPECTED,
            previous_state=None,
            updated_by="initial",
            source_device="device_module_id"
        )
        second_ply_partially_covered_and_missing_by_both_cams = PlyState(
            "P2",
            edges={
                EdgeState(
                    "P2.1",
                    cams={
                        EdgeCamState("cam1", EdgeCamStateEnum.MISSING),
                        EdgeCamState("cam2", EdgeCamStateEnum.MISSING),
                    },
                    state=EdgeStateEnum.MISSING
                ),
                EdgeState(
                    "P2.2",
                    cams={
                        EdgeCamState("cam2", EdgeCamStateEnum.MISSING),
                    },
                    state=EdgeStateEnum.COVERED
                ),
            },
            state=PlyStateEnum.MISSING,
            previous_state=PlyStateEnum.PLACED,
            updated_by="cam:cam1",
            source_device="device_module_id"
        )
        second_ply_missing_by_cam2 = PlyState(
            "P2",
            edges={
                EdgeState(
                    "P2.1",
                    cams={
                        EdgeCamState("cam1", EdgeCamStateEnum.NEVER_DETECTED),
                        EdgeCamState("cam2", EdgeCamStateEnum.DETECTED),
                    },
                    state=EdgeStateEnum.DETECTED
                ),
                EdgeState(
                    "P2.2",
                    cams={
                        EdgeCamState("cam2", EdgeCamStateEnum.MISSING),
                    },
                    state=EdgeStateEnum.MISSING
                ),
            },
            state=PlyStateEnum.MISSING,
            previous_state=PlyStateEnum.PLACED,
            updated_by="cam:cam2",
            source_device="device_module_id"
        )
        second_ply_missing_1st_edge_by_cam2 = PlyState(
            "P2",
            edges={
                EdgeState(
                    "P2.1",
                    cams={
                        EdgeCamState("cam1", EdgeCamStateEnum.NEVER_DETECTED),
                        EdgeCamState("cam2", EdgeCamStateEnum.MISSING),
                    },
                    state=EdgeStateEnum.MISSING
                ),
                EdgeState(
                    "P2.2",
                    cams={
                        EdgeCamState("cam2", EdgeCamStateEnum.DETECTED),
                    },
                    state=EdgeStateEnum.DETECTED
                ),
            },
            state=PlyStateEnum.MISSING,
            previous_state=PlyStateEnum.PLACED,
            updated_by="cam:cam2",
            source_device="device_module_id"
        )
        second_ply_partially_covered = PlyState(
            "P2",
            edges={
                EdgeState(
                    "P2.1",
                    cams={
                        EdgeCamState("cam1", EdgeCamStateEnum.NEVER_DETECTED),
                        EdgeCamState("cam2", EdgeCamStateEnum.DETECTED),
                    },
                    state=EdgeStateEnum.DETECTED
                ),
                EdgeState(
                    "P2.2",
                    cams={
                        EdgeCamState("cam2", EdgeCamStateEnum.MISSING),
                    },
                    state=EdgeStateEnum.COVERED
                ),
            },
            state=PlyStateEnum.PLACED,
            previous_state=PlyStateEnum.MISSING,
            updated_by="ply:P3",
            source_device="device_module_id"
        )
        second_ply_partially_covered_on_placed = PlyState(
            "P2",
            edges={
                EdgeState(
                    "P2.1",
                    cams={
                        EdgeCamState("cam1", EdgeCamStateEnum.NEVER_DETECTED),
                        EdgeCamState("cam2", EdgeCamStateEnum.DETECTED),
                    },
                    state=EdgeStateEnum.DETECTED
                ),
                EdgeState(
                    "P2.2",
                    cams={
                        EdgeCamState("cam2", EdgeCamStateEnum.DETECTED),
                    },
                    state=EdgeStateEnum.COVERED
                ),
            },
            state=PlyStateEnum.PLACED,
            previous_state=PlyStateEnum.PLACED,
            updated_by="ply:P3",
            source_device="device_module_id"
        )
        second_ply_partially_covered_reset_due_undo = PlyState(
            "P2",
            edges={
                EdgeState(
                    "P2.1",
                    cams={
                        EdgeCamState("cam1", EdgeCamStateEnum.NEVER_DETECTED),
                        EdgeCamState("cam2", EdgeCamStateEnum.DETECTED),
                    },
                    state=EdgeStateEnum.DETECTED
                ),
                EdgeState(
                    "P2.2",
                    cams={
                        EdgeCamState("cam2", EdgeCamStateEnum.DETECTED),
                    },
                    state=EdgeStateEnum.DETECTED
                ),
            },
            state=PlyStateEnum.PLACED,
            previous_state=PlyStateEnum.PLACED,
            updated_by="command:undo_ply:force",
            source_device="device_module_id"
        )
        second_ply_partially_covered_reset_due_undo_via_other_device = PlyState(
            "P2",
            edges={
                EdgeState(
                    "P2.1",
                    cams={
                        EdgeCamState("cam1", EdgeCamStateEnum.NEVER_DETECTED),
                        EdgeCamState("cam2", EdgeCamStateEnum.DETECTED),
                    },
                    state=EdgeStateEnum.DETECTED
                ),
                EdgeState(
                    "P2.2",
                    cams={
                        EdgeCamState("cam2", EdgeCamStateEnum.DETECTED),
                    },
                    state=EdgeStateEnum.DETECTED
                ),
            },
            state=PlyStateEnum.PLACED,
            previous_state=PlyStateEnum.PLACED,
            updated_by="command:undo_ply:force",
            source_device="other_device_module_id"
        )
        second_ply_partially_covered_by_cam2 = PlyState(
            "P2",
            edges={
                EdgeState(
                    "P2.1",
                    cams={
                        EdgeCamState("cam1", EdgeCamStateEnum.NEVER_DETECTED),
                        EdgeCamState("cam2", EdgeCamStateEnum.DETECTED),
                    },
                    state=EdgeStateEnum.DETECTED
                ),
                EdgeState(
                    "P2.2",
                    cams={
                        EdgeCamState("cam2", EdgeCamStateEnum.MISSING),
                    },
                    state=EdgeStateEnum.COVERED
                ),
            },
            state=PlyStateEnum.PLACED,
            previous_state=PlyStateEnum.EXPECTED,
            updated_by="cam:cam2",
            source_device="device_module_id"
        )
        second_ply_partially_covered_by_cam2_after_missing = PlyState(
            "P2",
            edges={
                EdgeState(
                    "P2.1",
                    cams={
                        EdgeCamState("cam1", EdgeCamStateEnum.NEVER_DETECTED),
                        EdgeCamState("cam2", EdgeCamStateEnum.DETECTED),
                    },
                    state=EdgeStateEnum.DETECTED
                ),
                EdgeState(
                    "P2.2",
                    cams={
                        EdgeCamState("cam2", EdgeCamStateEnum.MISSING),
                    },
                    state=EdgeStateEnum.COVERED
                ),
            },
            state=PlyStateEnum.PLACED,
            previous_state=PlyStateEnum.MISSING,
            updated_by="cam:cam2",
            source_device="device_module_id"
        )
        second_ply_partially_covered_detected_by_both_cameras = PlyState(
            "P2",
            edges={
                EdgeState(
                    "P2.1",
                    cams={
                        EdgeCamState("cam1", EdgeCamStateEnum.DETECTED),
                        EdgeCamState("cam2", EdgeCamStateEnum.DETECTED),
                    },
                    state=EdgeStateEnum.DETECTED
                ),
                EdgeState(
                    "P2.2",
                    cams={
                        EdgeCamState("cam2", EdgeCamStateEnum.MISSING),
                    },
                    state=EdgeStateEnum.COVERED
                ),
            },
            state=PlyStateEnum.PLACED,
            previous_state=PlyStateEnum.MISSING,
            updated_by="ply:P3",
            source_device="device_module_id"
        )
        third_ply_expected = PlyState(
            "P3",
            edges={
                EdgeState(
                    "P3.1",
                    cams={
                        EdgeCamState("cam2", EdgeCamStateEnum.NEVER_DETECTED),
                    },
                    state=EdgeStateEnum.MISSING
                ),
                EdgeState(
                    "P3.2",
                    cams={
                        EdgeCamState("cam3", EdgeCamStateEnum.NEVER_DETECTED),
                    },
                    state=EdgeStateEnum.MISSING
                ),
            },
            state=PlyStateEnum.EXPECTED,
            previous_state=None,
            updated_by="initial",
            source_device="device_module_id"
        )
        third_ply_expected_cam2_edge_detected = PlyState(
            "P3",
            edges={
                EdgeState(
                    "P3.1",
                    cams={
                        EdgeCamState("cam2", EdgeCamStateEnum.DETECTED),
                    },
                    state=EdgeStateEnum.DETECTED
                ),
                EdgeState(
                    "P3.2",
                    cams={
                        EdgeCamState("cam3", EdgeCamStateEnum.NEVER_DETECTED),
                    },
                    state=EdgeStateEnum.MISSING
                ),
            },
            state=PlyStateEnum.EXPECTED,
            previous_state=None,
            updated_by="cam:cam2",
            source_device="device_module_id"
        )
        third_ply_expected_cam2_edge_detected_after_reset_on_placed = PlyState(
            "P3",
            edges={
                EdgeState(
                    "P3.1",
                    cams={
                        EdgeCamState("cam2", EdgeCamStateEnum.DETECTED),
                    },
                    state=EdgeStateEnum.DETECTED
                ),
                EdgeState(
                    "P3.2",
                    cams={
                        EdgeCamState("cam3", EdgeCamStateEnum.NEVER_DETECTED),
                    },
                    state=EdgeStateEnum.MISSING
                ),
            },
            state=PlyStateEnum.EXPECTED,
            previous_state=PlyStateEnum.PLACED,
            updated_by="cam:cam2",
            source_device="device_module_id"
        )
        third_ply_expected_cam2_edge_detected_after_reset_on_missing = PlyState(
            "P3",
            edges={
                EdgeState(
                    "P3.1",
                    cams={
                        EdgeCamState("cam2", EdgeCamStateEnum.DETECTED),
                    },
                    state=EdgeStateEnum.DETECTED
                ),
                EdgeState(
                    "P3.2",
                    cams={
                        EdgeCamState("cam3", EdgeCamStateEnum.MISSING),
                    },
                    state=EdgeStateEnum.MISSING
                ),
            },
            state=PlyStateEnum.EXPECTED,
            previous_state=PlyStateEnum.MISSING,
            updated_by="cam:cam2",
            source_device="device_module_id"
        )
        third_ply_phantom_forced_on_expected = PlyState(
            "P3",
            edges=set(),
            state=PlyStateEnum.FORCED,
            previous_state=PlyStateEnum.EXPECTED,
            updated_by="command:force_ply",
            source_device="device_module_id"
        )
        third_ply_phantom_forced_reset_due_undo = PlyState(
            "P3",
            edges=set(),
            state=PlyStateEnum.EXPECTED,
            previous_state=PlyStateEnum.FORCED,
            updated_by="command:undo_ply:force",
            source_device="device_module_id"
        )
        third_ply_phantom_forced_reset_due_undo_via_other_device = PlyState(
            "P3",
            edges=set(),
            state=PlyStateEnum.EXPECTED,
            previous_state=PlyStateEnum.FORCED,
            updated_by="command:undo_ply:force",
            source_device="other_device_module_id"
        )
        third_ply_placed_reset_due_undo = PlyState(
            "P3",
            edges={
                EdgeState(
                    "P3.1",
                    cams={
                        EdgeCamState("cam2", EdgeCamStateEnum.NEVER_DETECTED),
                    },
                    state=EdgeStateEnum.MISSING
                ),
                EdgeState(
                    "P3.2",
                    cams={
                        EdgeCamState("cam3", EdgeCamStateEnum.NEVER_DETECTED),
                    },
                    state=EdgeStateEnum.MISSING
                ),
            },
            state=PlyStateEnum.EXPECTED,
            previous_state=PlyStateEnum.PLACED,
            updated_by="command:undo_ply:force",
            source_device="device_module_id"
        )
        third_ply_placed_updated_by_cam_2 = PlyState(
            "P3",
            edges={
                EdgeState(
                    "P3.1",
                    cams={
                        EdgeCamState("cam2", EdgeCamStateEnum.DETECTED),
                    },
                    state=EdgeStateEnum.DETECTED
                ),
                EdgeState(
                    "P3.2",
                    cams={
                        EdgeCamState("cam3", EdgeCamStateEnum.DETECTED),
                    },
                    state=EdgeStateEnum.DETECTED
                ),
            },
            state=PlyStateEnum.PLACED,
            previous_state=PlyStateEnum.EXPECTED,
            updated_by="cam:cam2",
            source_device="device_module_id"
        )
        third_ply_placed_updated_by_cam_3 = PlyState(
            "P3",
            edges={
                EdgeState(
                    "P3.1",
                    cams={
                        EdgeCamState("cam2", EdgeCamStateEnum.DETECTED),
                    },
                    state=EdgeStateEnum.DETECTED
                ),
                EdgeState(
                    "P3.2",
                    cams={
                        EdgeCamState("cam3", EdgeCamStateEnum.DETECTED),
                    },
                    state=EdgeStateEnum.DETECTED
                ),
            },
            state=PlyStateEnum.PLACED,
            previous_state=PlyStateEnum.EXPECTED,
            updated_by="cam:cam3",
            source_device="device_module_id"
        )
        third_ply_missing_updated_by_cam_3 = PlyState(
            "P3",
            edges={
                EdgeState(
                    "P3.1",
                    cams={
                        EdgeCamState("cam2", EdgeCamStateEnum.DETECTED),
                    },
                    state=EdgeStateEnum.DETECTED
                ),
                EdgeState(
                    "P3.2",
                    cams={
                        EdgeCamState("cam3", EdgeCamStateEnum.MISSING),
                    },
                    state=EdgeStateEnum.MISSING
                ),
            },
            state=PlyStateEnum.MISSING,
            previous_state=PlyStateEnum.PLACED,
            updated_by="cam:cam3",
            source_device="device_module_id"
        )
        third_ply_undone_on_placed = PlyState(
            "P3",
            edges={
                EdgeState(
                    "P3.1",
                    cams={
                        EdgeCamState("cam2", EdgeCamStateEnum.NEVER_DETECTED),
                    },
                    state=EdgeStateEnum.MISSING
                ),
                EdgeState(
                    "P3.2",
                    cams={
                        EdgeCamState("cam3", EdgeCamStateEnum.NEVER_DETECTED),
                    },
                    state=EdgeStateEnum.MISSING
                ),
            },
            state=PlyStateEnum.EXPECTED,
            previous_state=PlyStateEnum.PLACED,
            updated_by="command:undo_ply:force",
            source_device="device_module_id"
        )
        third_ply_undone_on_placed_via_other_device = PlyState(
            "P3",
            edges={
                EdgeState(
                    "P3.1",
                    cams={
                        EdgeCamState("cam2", EdgeCamStateEnum.NEVER_DETECTED),
                    },
                    state=EdgeStateEnum.MISSING
                ),
                EdgeState(
                    "P3.2",
                    cams={
                        EdgeCamState("cam3", EdgeCamStateEnum.NEVER_DETECTED),
                    },
                    state=EdgeStateEnum.MISSING
                ),
            },
            state=PlyStateEnum.EXPECTED,
            previous_state=PlyStateEnum.PLACED,
            updated_by="command:undo_ply:force",
            source_device="other_device_module_id"
        )
        third_ply_undone_on_missing = PlyState(
            "P3",
            edges={
                EdgeState(
                    "P3.1",
                    cams={
                        EdgeCamState("cam2", EdgeCamStateEnum.NEVER_DETECTED),
                    },
                    state=EdgeStateEnum.MISSING
                ),
                EdgeState(
                    "P3.2",
                    cams={
                        EdgeCamState("cam3", EdgeCamStateEnum.MISSING),
                    },
                    state=EdgeStateEnum.MISSING
                ),
            },
            state=PlyStateEnum.EXPECTED,
            previous_state=PlyStateEnum.MISSING,
            updated_by="command:undo_ply:force",
            source_device="device_module_id"
        )
        third_ply_undone_on_missing_via_other_device = PlyState(
            "P3",
            edges={
                EdgeState(
                    "P3.1",
                    cams={
                        EdgeCamState("cam2", EdgeCamStateEnum.NEVER_DETECTED),
                    },
                    state=EdgeStateEnum.MISSING
                ),
                EdgeState(
                    "P3.2",
                    cams={
                        EdgeCamState("cam3", EdgeCamStateEnum.MISSING),
                    },
                    state=EdgeStateEnum.MISSING
                ),
            },
            state=PlyStateEnum.EXPECTED,
            previous_state=PlyStateEnum.MISSING,
            updated_by="command:undo_ply:force",
            source_device="other_device_module_id"
        )
        third_ply_partially_covered = PlyState(
            "P3",
            edges={
                EdgeState(
                    "P3.1",
                    cams={
                        EdgeCamState("cam2", EdgeCamStateEnum.DETECTED),
                    },
                    state=EdgeStateEnum.DETECTED
                ),
                EdgeState(
                    "P3.2",
                    cams={
                        EdgeCamState("cam3", EdgeCamStateEnum.MISSING),
                    },
                    state=EdgeStateEnum.COVERED
                ),
            },
            state=PlyStateEnum.PLACED,
            previous_state=PlyStateEnum.PLACED,
            updated_by="ply:P4",
            source_device="device_module_id"
        )
        third_ply_partially_covered_on_placed = PlyState(
            "P3",
            edges={
                EdgeState(
                    "P3.1",
                    cams={
                        EdgeCamState("cam2", EdgeCamStateEnum.DETECTED),
                    },
                    state=EdgeStateEnum.DETECTED
                ),
                EdgeState(
                    "P3.2",
                    cams={
                        EdgeCamState("cam3", EdgeCamStateEnum.DETECTED),
                    },
                    state=EdgeStateEnum.COVERED
                ),
            },
            state=PlyStateEnum.PLACED,
            previous_state=PlyStateEnum.PLACED,
            updated_by="ply:P4",
            source_device="device_module_id"
        )
        third_ply_partially_covered_reset_due_undo = PlyState(
            "P3",
            edges={
                EdgeState(
                    "P3.1",
                    cams={
                        EdgeCamState("cam2", EdgeCamStateEnum.DETECTED),
                    },
                    state=EdgeStateEnum.DETECTED
                ),
                EdgeState(
                    "P3.2",
                    cams={
                        EdgeCamState("cam3", EdgeCamStateEnum.DETECTED),
                    },
                    state=EdgeStateEnum.DETECTED
                ),
            },
            state=PlyStateEnum.PLACED,
            previous_state=PlyStateEnum.PLACED,
            updated_by="command:undo_ply:force",
            source_device="device_module_id"
        )
        fourth_ply_expected = PlyState(
            "P4",
            edges={
                EdgeState(
                    "P4.1",
                    cams={
                        EdgeCamState("cam3", EdgeCamStateEnum.NEVER_DETECTED),
                    },
                    state=EdgeStateEnum.MISSING
                ),
                EdgeState(
                    "P4.2",
                    cams={
                        EdgeCamState("cam3", EdgeCamStateEnum.NEVER_DETECTED),
                        EdgeCamState("cam4", EdgeCamStateEnum.NEVER_DETECTED),
                    },
                    state=EdgeStateEnum.MISSING
                ),
            },
            state=PlyStateEnum.EXPECTED,
            previous_state=None,
            updated_by="initial",
            source_device="device_module_id"
        )
        fourth_ply_partially_covered_by_third_ply_on_expected = PlyState(
            "P4",
            edges={
                EdgeState(
                    "P4.1",
                    cams={
                        EdgeCamState("cam3", EdgeCamStateEnum.NEVER_DETECTED),
                    },
                    state=EdgeStateEnum.COVERED
                ),
                EdgeState(
                    "P4.2",
                    cams={
                        EdgeCamState("cam3", EdgeCamStateEnum.NEVER_DETECTED),
                        EdgeCamState("cam4", EdgeCamStateEnum.NEVER_DETECTED),
                    },
                    state=EdgeStateEnum.MISSING
                ),
            },
            state=PlyStateEnum.EXPECTED,
            previous_state=PlyStateEnum.EXPECTED,
            updated_by="ply:P3",
            source_device="device_module_id"
        )
        fourth_ply_expected_according_to_other_device = PlyState(
            "P4",
            edges={
                EdgeState(
                    "P4.1",
                    cams={
                        EdgeCamState("cam3", EdgeCamStateEnum.NEVER_DETECTED),
                    },
                    state=EdgeStateEnum.MISSING
                ),
                EdgeState(
                    "P4.2",
                    cams={
                        EdgeCamState("cam3", EdgeCamStateEnum.NEVER_DETECTED),
                        EdgeCamState("cam4", EdgeCamStateEnum.NEVER_DETECTED),
                    },
                    state=EdgeStateEnum.MISSING
                ),
            },
            state=PlyStateEnum.EXPECTED,
            previous_state=None,
            updated_by="initial",
            source_device="other_device_module_id"
        )
        fourth_ply_placed = PlyState(
            "P4",
            edges={
                EdgeState(
                    "P4.1",
                    cams={
                        EdgeCamState("cam3", EdgeCamStateEnum.DETECTED),
                    },
                    state=EdgeStateEnum.DETECTED
                ),
                EdgeState(
                    "P4.2",
                    cams={
                        EdgeCamState("cam3", EdgeCamStateEnum.DETECTED),
                        EdgeCamState("cam4", EdgeCamStateEnum.NEVER_DETECTED),
                    },
                    state=EdgeStateEnum.DETECTED
                ),
            },
            state=PlyStateEnum.PLACED,
            previous_state=PlyStateEnum.EXPECTED,
            updated_by="cam:cam3",
            source_device="device_module_id"
        )
        fourth_ply_placed_reset_due_undo = PlyState(
            "P4",
            edges={
                EdgeState(
                    "P4.1",
                    cams={
                        EdgeCamState("cam3", EdgeCamStateEnum.NEVER_DETECTED),
                    },
                    state=EdgeStateEnum.MISSING
                ),
                EdgeState(
                    "P4.2",
                    cams={
                        EdgeCamState("cam3", EdgeCamStateEnum.NEVER_DETECTED),
                        EdgeCamState("cam4", EdgeCamStateEnum.NEVER_DETECTED),
                    },
                    state=EdgeStateEnum.MISSING
                ),
            },
            state=PlyStateEnum.EXPECTED,
            previous_state=PlyStateEnum.PLACED,
            updated_by="command:undo_ply:force",
            source_device="device_module_id"
        )
        fourth_ply_missing_by_cam3 = PlyState(
            "P4",
            edges={
                EdgeState(
                    "P4.1",
                    cams={
                        EdgeCamState("cam3", EdgeCamStateEnum.DETECTED),
                    },
                    state=EdgeStateEnum.DETECTED
                ),
                EdgeState(
                    "P4.2",
                    cams={
                        EdgeCamState("cam3", EdgeCamStateEnum.MISSING),
                        EdgeCamState("cam4", EdgeCamStateEnum.NEVER_DETECTED),
                    },
                    state=EdgeStateEnum.MISSING
                ),
            },
            state=PlyStateEnum.MISSING,
            previous_state=PlyStateEnum.PLACED,
            updated_by="cam:cam3",
            source_device="device_module_id"
        )
        fourth_ply_missing_by_1st_edge = PlyState(
            "P4",
            edges={
                EdgeState(
                    "P4.1",
                    cams={
                        EdgeCamState("cam3", EdgeCamStateEnum.MISSING),
                    },
                    state=EdgeStateEnum.MISSING
                ),
                EdgeState(
                    "P4.2",
                    cams={
                        EdgeCamState("cam3", EdgeCamStateEnum.DETECTED),
                        EdgeCamState("cam4", EdgeCamStateEnum.NEVER_DETECTED),
                    },
                    state=EdgeStateEnum.DETECTED
                ),
            },
            state=PlyStateEnum.MISSING,
            previous_state=PlyStateEnum.PLACED,
            updated_by="cam:cam3",
            source_device="device_module_id"
        )
        fourth_ply_missing_by_cam3_and_cam4 = PlyState(
            "P4",
            edges={
                EdgeState(
                    "P4.1",
                    cams={
                        EdgeCamState("cam3", EdgeCamStateEnum.DETECTED),
                    },
                    state=EdgeStateEnum.DETECTED
                ),
                EdgeState(
                    "P4.2",
                    cams={
                        EdgeCamState("cam3", EdgeCamStateEnum.MISSING),
                        EdgeCamState("cam4", EdgeCamStateEnum.MISSING),
                    },
                    state=EdgeStateEnum.MISSING
                ),
            },
            state=PlyStateEnum.MISSING,
            previous_state=PlyStateEnum.PLACED,
            updated_by="cam:cam4",
            source_device="device_module_id"
        )
        fourth_ply_partially_covered = PlyState(
            "P4",
            edges={
                EdgeState(
                    "P4.1",
                    cams={
                        EdgeCamState("cam3", EdgeCamStateEnum.DETECTED),
                    },
                    state=EdgeStateEnum.DETECTED
                ),
                EdgeState(
                    "P4.2",
                    cams={
                        EdgeCamState("cam3", EdgeCamStateEnum.DETECTED),
                        EdgeCamState("cam4", EdgeCamStateEnum.NEVER_DETECTED),
                    },
                    state=EdgeStateEnum.COVERED
                ),
            },
            state=PlyStateEnum.PLACED,
            previous_state=PlyStateEnum.PLACED,
            updated_by="ply:P5",
            source_device="device_module_id"
        )
        fourth_ply_fully_covered_by_P3 = PlyState(
            "P4",
            edges={
                EdgeState(
                    "P4.1",
                    cams={
                        EdgeCamState("cam3", EdgeCamStateEnum.DETECTED),
                    },
                    state=EdgeStateEnum.COVERED
                ),
                EdgeState(
                    "P4.2",
                    cams={
                        EdgeCamState("cam3", EdgeCamStateEnum.DETECTED),
                        EdgeCamState("cam4", EdgeCamStateEnum.NEVER_DETECTED),
                    },
                    state=EdgeStateEnum.COVERED
                ),
            },
            state=PlyStateEnum.COVERED,
            previous_state=PlyStateEnum.PLACED,
            updated_by="ply:P3",
            source_device="device_module_id"
        )
        fourth_ply_partially_covered_reset_due_undo = PlyState(
            "P4",
            edges={
                EdgeState(
                    "P4.1",
                    cams={
                        EdgeCamState("cam3", EdgeCamStateEnum.DETECTED),
                    },
                    state=EdgeStateEnum.DETECTED
                ),
                EdgeState(
                    "P4.2",
                    cams={
                        EdgeCamState("cam3", EdgeCamStateEnum.DETECTED),
                        EdgeCamState("cam4", EdgeCamStateEnum.NEVER_DETECTED),
                    },
                    state=EdgeStateEnum.DETECTED
                ),
            },
            state=PlyStateEnum.PLACED,
            previous_state=PlyStateEnum.PLACED,
            updated_by="command:undo_ply:force",
            source_device="device_module_id"
        )
        fourth_ply_partially_covered_reset_due_undo = PlyState(
            "P4",
            edges={
                EdgeState(
                    "P4.1",
                    cams={
                        EdgeCamState("cam3", EdgeCamStateEnum.DETECTED),
                    },
                    state=EdgeStateEnum.DETECTED
                ),
                EdgeState(
                    "P4.2",
                    cams={
                        EdgeCamState("cam3", EdgeCamStateEnum.DETECTED),
                        EdgeCamState("cam4", EdgeCamStateEnum.NEVER_DETECTED),
                    },
                    state=EdgeStateEnum.DETECTED
                ),
            },
            state=PlyStateEnum.PLACED,
            previous_state=PlyStateEnum.PLACED,
            updated_by="command:undo_ply:force",
            source_device="device_module_id"
        )
        fourth_ply_partially_covered_reset_due_undo_after_fully_covered = PlyState(
            "P4",
            edges={
                EdgeState(
                    "P4.1",
                    cams={
                        EdgeCamState("cam3", EdgeCamStateEnum.DETECTED),
                    },
                    state=EdgeStateEnum.DETECTED
                ),
                EdgeState(
                    "P4.2",
                    cams={
                        EdgeCamState("cam3", EdgeCamStateEnum.DETECTED),
                        EdgeCamState("cam4", EdgeCamStateEnum.NEVER_DETECTED),
                    },
                    state=EdgeStateEnum.DETECTED
                ),
            },
            state=PlyStateEnum.PLACED,
            previous_state=PlyStateEnum.COVERED,
            updated_by="command:undo_ply:force",
            source_device="device_module_id"
        )
        fourth_ply_fully_covered_by_P3_reset_due_undo = PlyState(
            "P4",
            edges={
                EdgeState(
                    "P4.1",
                    cams={
                        EdgeCamState("cam3", EdgeCamStateEnum.DETECTED),
                    },
                    state=EdgeStateEnum.DETECTED
                ),
                EdgeState(
                    "P4.2",
                    cams={
                        EdgeCamState("cam3", EdgeCamStateEnum.DETECTED),
                        EdgeCamState("cam4", EdgeCamStateEnum.NEVER_DETECTED),
                    },
                    state=EdgeStateEnum.COVERED
                ),
            },
            state=PlyStateEnum.PLACED,
            previous_state=PlyStateEnum.COVERED,
            updated_by="command:undo_ply:force",
            source_device="device_module_id"
        )
        fourth_ply_partially_covered_with_missing_edge_by_cam4 = PlyState(
            "P4",
            edges={
                EdgeState(
                    "P4.1",
                    cams={
                        EdgeCamState("cam3", EdgeCamStateEnum.DETECTED),
                    },
                    state=EdgeStateEnum.DETECTED
                ),
                EdgeState(
                    "P4.2",
                    cams={
                        EdgeCamState("cam3", EdgeCamStateEnum.DETECTED),
                        EdgeCamState("cam4", EdgeCamStateEnum.MISSING),
                    },
                    state=EdgeStateEnum.COVERED
                ),
            },
            state=PlyStateEnum.PLACED,
            previous_state=PlyStateEnum.PLACED,
            updated_by="ply:P5",
            source_device="device_module_id"
        )
        fourth_ply_partially_covered_with_missing_edge_by_cam3 = PlyState(
            "P4",
            edges={
                EdgeState(
                    "P4.1",
                    cams={
                        EdgeCamState("cam3", EdgeCamStateEnum.DETECTED),
                    },
                    state=EdgeStateEnum.DETECTED
                ),
                EdgeState(
                    "P4.2",
                    cams={
                        EdgeCamState("cam3", EdgeCamStateEnum.MISSING),
                        EdgeCamState("cam4", EdgeCamStateEnum.NEVER_DETECTED),
                    },
                    state=EdgeStateEnum.COVERED
                ),
            },
            state=PlyStateEnum.PLACED,
            previous_state=PlyStateEnum.MISSING,
            updated_by="ply:P5",
            source_device="device_module_id"
        )
        fourth_ply_partially_covered_with_missing_edge_by_both_cams = PlyState(
            "P4",
            edges={
                EdgeState(
                    "P4.1",
                    cams={
                        EdgeCamState("cam3", EdgeCamStateEnum.DETECTED),
                    },
                    state=EdgeStateEnum.DETECTED
                ),
                EdgeState(
                    "P4.2",
                    cams={
                        EdgeCamState("cam3", EdgeCamStateEnum.MISSING),
                        EdgeCamState("cam4", EdgeCamStateEnum.MISSING),
                    },
                    state=EdgeStateEnum.COVERED
                ),
            },
            state=PlyStateEnum.PLACED,
            previous_state=PlyStateEnum.MISSING,
            updated_by="ply:P5",
            source_device="device_module_id"
        )
        fifth_ply_expected = PlyState(
            "P5",
            edges={
                EdgeState(
                    "P5.1",
                    cams={
                        EdgeCamState("cam4", EdgeCamStateEnum.NEVER_DETECTED),
                    },
                    state=EdgeStateEnum.MISSING
                ),
                EdgeState(
                    "P5.2",
                    cams={
                        EdgeCamState("cam4", EdgeCamStateEnum.NEVER_DETECTED),
                    },
                    state=EdgeStateEnum.MISSING
                ),
            },
            state=PlyStateEnum.EXPECTED,
            previous_state=None,
            updated_by="initial",
            source_device="device_module_id"
        )
        fifth_ply_placed_reset_due_undo = PlyState(
            "P5",
            edges={
                EdgeState(
                    "P5.1",
                    cams={
                        EdgeCamState("cam4", EdgeCamStateEnum.NEVER_DETECTED),
                    },
                    state=EdgeStateEnum.MISSING
                ),
                EdgeState(
                    "P5.2",
                    cams={
                        EdgeCamState("cam4", EdgeCamStateEnum.NEVER_DETECTED),
                    },
                    state=EdgeStateEnum.MISSING
                ),
            },
            state=PlyStateEnum.EXPECTED,
            previous_state=PlyStateEnum.PLACED,
            updated_by="command:undo_ply:force",
            source_device="device_module_id"
        )
        fifth_ply_partially_covered_reset_due_undo = PlyState(
            "P5",
            edges={
                EdgeState(
                    "P5.1",
                    cams={
                        EdgeCamState("cam4", EdgeCamStateEnum.DETECTED),
                    },
                    state=EdgeStateEnum.DETECTED
                ),
                EdgeState(
                    "P5.2",
                    cams={
                        EdgeCamState("cam4", EdgeCamStateEnum.DETECTED),
                    },
                    state=EdgeStateEnum.DETECTED
                ),
            },
            state=PlyStateEnum.PLACED,
            previous_state=PlyStateEnum.PLACED,
            updated_by="command:undo_ply:force",
            source_device="device_module_id"
        )
        fifth_ply_placed = PlyState(
            "P5",
            edges={
                EdgeState(
                    "P5.1",
                    cams={
                        EdgeCamState("cam4", EdgeCamStateEnum.DETECTED),
                    },
                    state=EdgeStateEnum.DETECTED
                ),
                EdgeState(
                    "P5.2",
                    cams={
                        EdgeCamState("cam4", EdgeCamStateEnum.DETECTED),
                    },
                    state=EdgeStateEnum.DETECTED
                ),
            },
            state=PlyStateEnum.PLACED,
            previous_state=PlyStateEnum.EXPECTED,
            updated_by="cam:cam4",
            source_device="device_module_id"
        )
        fifth_ply_partially_covered = PlyState(
            "P5",
            edges={
                EdgeState(
                    "P5.1",
                    cams={
                        EdgeCamState("cam4", EdgeCamStateEnum.DETECTED),
                    },
                    state=EdgeStateEnum.DETECTED
                ),
                EdgeState(
                    "P5.2",
                    cams={
                        EdgeCamState("cam4", EdgeCamStateEnum.DETECTED),
                    },
                    state=EdgeStateEnum.COVERED
                ),
            },
            state=PlyStateEnum.PLACED,
            previous_state=PlyStateEnum.PLACED,
            updated_by="ply:P6",
            source_device="device_module_id"
        )
        fifth_ply_partially_covered_by_P3 = PlyState(
            "P5",
            edges={
                EdgeState(
                    "P5.1",
                    cams={
                        EdgeCamState("cam4", EdgeCamStateEnum.DETECTED),
                    },
                    state=EdgeStateEnum.COVERED
                ),
                EdgeState(
                    "P5.2",
                    cams={
                        EdgeCamState("cam4", EdgeCamStateEnum.DETECTED),
                    },
                    state=EdgeStateEnum.DETECTED
                ),
            },
            state=PlyStateEnum.PLACED,
            previous_state=PlyStateEnum.PLACED,
            updated_by="ply:P3",
            source_device="device_module_id"
        )
        fifth_ply_fully_covered = PlyState(
            "P5",
            edges={
                EdgeState(
                    "P5.1",
                    cams={
                        EdgeCamState("cam4", EdgeCamStateEnum.DETECTED),
                    },
                    state=EdgeStateEnum.COVERED
                ),
                EdgeState(
                    "P5.2",
                    cams={
                        EdgeCamState("cam4", EdgeCamStateEnum.DETECTED),
                    },
                    state=EdgeStateEnum.COVERED
                ),
            },
            state=PlyStateEnum.COVERED,
            previous_state=PlyStateEnum.PLACED,
            updated_by="ply:P6",
            source_device="device_module_id"
        )
        sixth_ply_expected = PlyState(
            "P6",
            edges={
                EdgeState(
                    "P6.1",
                    cams={
                        EdgeCamState("cam4", EdgeCamStateEnum.NEVER_DETECTED),
                        EdgeCamState("cam5", EdgeCamStateEnum.NEVER_DETECTED),
                    },
                    state=EdgeStateEnum.MISSING
                ),
                EdgeState(
                    "P6.2",
                    cams={
                        EdgeCamState("cam5", EdgeCamStateEnum.NEVER_DETECTED),
                    },
                    state=EdgeStateEnum.MISSING
                ),
            },
            state=PlyStateEnum.EXPECTED,
            previous_state=None,
            updated_by="initial",
            source_device="device_module_id"
        )
        sixth_ply_placed = PlyState(
            "P6",
            edges={
                EdgeState(
                    "P6.1",
                    cams={
                        EdgeCamState("cam4", EdgeCamStateEnum.NEVER_DETECTED),
                        EdgeCamState("cam5", EdgeCamStateEnum.DETECTED),
                    },
                    state=EdgeStateEnum.DETECTED
                ),
                EdgeState(
                    "P6.2",
                    cams={
                        EdgeCamState("cam5", EdgeCamStateEnum.DETECTED),

                    },
                    state=EdgeStateEnum.DETECTED
                ),
            },
            state=PlyStateEnum.PLACED,
            previous_state=PlyStateEnum.EXPECTED,
            updated_by="cam:cam5",
            source_device="device_module_id"
        )
        sixth_ply_partially_covered = PlyState(
            "P6",
            edges={
                EdgeState(
                    "P6.1",
                    cams={
                        EdgeCamState("cam4", EdgeCamStateEnum.NEVER_DETECTED),
                        EdgeCamState("cam5", EdgeCamStateEnum.DETECTED),
                    },
                    state=EdgeStateEnum.DETECTED
                ),
                EdgeState(
                    "P6.2",
                    cams={
                        EdgeCamState("cam5", EdgeCamStateEnum.MISSING),
                    },
                    state=EdgeStateEnum.COVERED
                ),
            },
            state=PlyStateEnum.PLACED,
            previous_state=PlyStateEnum.MISSING,
            updated_by="ply:P7",
            source_device="device_module_id"
        )
        seventh_ply_expected = PlyState(
            "P7",
            edges={
                EdgeState(
                    "P7.1",
                    cams={
                        EdgeCamState("cam5", EdgeCamStateEnum.NEVER_DETECTED),
                    },
                    state=EdgeStateEnum.MISSING
                ),
                EdgeState(
                    "P7.2",
                    cams={
                        EdgeCamState("cam5", EdgeCamStateEnum.NEVER_DETECTED),
                        EdgeCamState("cam6", EdgeCamStateEnum.NEVER_DETECTED),
                    },
                    state=EdgeStateEnum.MISSING
                ),
            },
            state=PlyStateEnum.EXPECTED,
            previous_state=None,
            updated_by="initial",
            source_device="device_module_id"
        )
        seventh_ply_placed = PlyState(
            "P7",
            edges={
                EdgeState(
                    "P7.1",
                    cams={
                        EdgeCamState("cam5", EdgeCamStateEnum.DETECTED),
                    },
                    state=EdgeStateEnum.DETECTED
                ),
                EdgeState(
                    "P7.2",
                    cams={
                        EdgeCamState("cam5", EdgeCamStateEnum.DETECTED),
                        EdgeCamState("cam6", EdgeCamStateEnum.NEVER_DETECTED),
                    },
                    state=EdgeStateEnum.DETECTED
                ),
            },
            state=PlyStateEnum.PLACED,
            previous_state=PlyStateEnum.EXPECTED,
            updated_by="cam:cam5",
            source_device="device_module_id"
        )
        seventh_ply_partially_covered = PlyState(
            "P7",
            edges={
                EdgeState(
                    "P7.1",
                    cams={
                        EdgeCamState("cam5", EdgeCamStateEnum.DETECTED),
                    },
                    state=EdgeStateEnum.DETECTED
                ),
                EdgeState(
                    "P7.2",
                    cams={
                        EdgeCamState("cam5", EdgeCamStateEnum.DETECTED),
                        EdgeCamState("cam6", EdgeCamStateEnum.NEVER_DETECTED),
                    },
                    state=EdgeStateEnum.COVERED
                ),
            },
            state=PlyStateEnum.PLACED,
            previous_state=PlyStateEnum.PLACED,
            updated_by="ply:P8",
            source_device="device_module_id"
        )
        seventh_ply_partially_covered_according_to_other_device = PlyState(
            "P7",
            edges={
                EdgeState(
                    "P7.1",
                    cams={
                        EdgeCamState("cam5", EdgeCamStateEnum.DETECTED),
                    },
                    state=EdgeStateEnum.DETECTED
                ),
                EdgeState(
                    "P7.2",
                    cams={
                        EdgeCamState("cam5", EdgeCamStateEnum.DETECTED),
                        EdgeCamState("cam6", EdgeCamStateEnum.NEVER_DETECTED),
                    },
                    state=EdgeStateEnum.COVERED
                ),
            },
            state=PlyStateEnum.PLACED,
            previous_state=PlyStateEnum.PLACED,
            updated_by="ply:P8",
            source_device="device_module_id"
        )
        eighth_ply_expected = PlyState(
            "P8",
            edges={
                EdgeState(
                    "P8.1",
                    cams={
                        EdgeCamState("cam6", EdgeCamStateEnum.NEVER_DETECTED),
                    },
                    state=EdgeStateEnum.MISSING
                ),
                EdgeState(
                    "P8.2",
                    cams={
                        EdgeCamState("cam6", EdgeCamStateEnum.NEVER_DETECTED),
                    },
                    state=EdgeStateEnum.MISSING
                ),
            },
            state=PlyStateEnum.EXPECTED,
            previous_state=None,
            updated_by="initial",
            source_device="device_module_id"
        )
        eighth_ply_placed = PlyState(
            "P8",
            edges={
                EdgeState(
                    "P8.1",
                    cams={
                        EdgeCamState("cam6", EdgeCamStateEnum.DETECTED),
                    },
                    state=EdgeStateEnum.DETECTED
                ),
                EdgeState(
                    "P8.2",
                    cams={
                        EdgeCamState("cam6", EdgeCamStateEnum.DETECTED),
                    },
                    state=EdgeStateEnum.DETECTED
                ),
            },
            state=PlyStateEnum.PLACED,
            previous_state=PlyStateEnum.EXPECTED,
            updated_by="cam:cam6",
            source_device="device_module_id"
        )
        eighth_ply_partially_covered = PlyState(
            "P8",
            edges={
                EdgeState(
                    "P8.1",
                    cams={
                        EdgeCamState("cam6", EdgeCamStateEnum.DETECTED),
                    },
                    state=EdgeStateEnum.DETECTED
                ),
                EdgeState(
                    "P8.2",
                    cams={
                        EdgeCamState("cam6", EdgeCamStateEnum.MISSING),
                    },
                    state=EdgeStateEnum.COVERED
                ),
            },
            state=PlyStateEnum.PLACED,
            previous_state=PlyStateEnum.MISSING,
            updated_by="ply:P9",
            source_device="device_module_id"
        )
        eighth_ply_partially_covered_on_expected = PlyState(
            "P8",
            edges={
                EdgeState(
                    "P8.1",
                    cams={
                        EdgeCamState("cam6", EdgeCamStateEnum.DETECTED),
                    },
                    state=EdgeStateEnum.DETECTED
                ),
                EdgeState(
                    "P8.2",
                    cams={
                        EdgeCamState("cam6", EdgeCamStateEnum.DETECTED),
                    },
                    state=EdgeStateEnum.COVERED
                ),
            },
            state=PlyStateEnum.PLACED,
            previous_state=PlyStateEnum.PLACED,
            updated_by="ply:P9",
            source_device="device_module_id"
        )
        ninth_ply_expected = PlyState(
            "P9",
            edges={
                EdgeState(
                    "P9.1",
                    cams={
                        EdgeCamState("cam6", EdgeCamStateEnum.NEVER_DETECTED),
                    },
                    state=EdgeStateEnum.MISSING
                ),
                EdgeState(
                    "P9.2",
                    cams={
                        EdgeCamState("cam6", EdgeCamStateEnum.NEVER_DETECTED),
                    },
                    state=EdgeStateEnum.MISSING
                ),
            },
            state=PlyStateEnum.EXPECTED,
            previous_state=None,
            updated_by="initial",
            source_device="device_module_id"
        )
        ninth_ply_placed = PlyState(
            "P9",
            edges={
                EdgeState(
                    "P9.1",
                    cams={
                        EdgeCamState("cam6", EdgeCamStateEnum.DETECTED),
                    },
                    state=EdgeStateEnum.DETECTED
                ),
                EdgeState(
                    "P9.2",
                    cams={
                        EdgeCamState("cam6", EdgeCamStateEnum.DETECTED),
                    },
                    state=EdgeStateEnum.DETECTED
                ),
            },
            state=PlyStateEnum.PLACED,
            previous_state=PlyStateEnum.EXPECTED,
            updated_by="cam:cam6",
            source_device="device_module_id"
        )
        ninth_ply_expected_without_invisible_edge = PlyState(
            "P9",
            edges={
                EdgeState(
                    "P9.1",
                    cams={
                        EdgeCamState("cam6", EdgeCamStateEnum.NEVER_DETECTED),
                    },
                    state=EdgeStateEnum.MISSING
                ),
            },
            state=PlyStateEnum.EXPECTED,
            previous_state=None,
            updated_by="initial",
            source_device="device_module_id"
        )
        ninth_ply_placed_without_invisible_edge = PlyState(
            "P9",
            edges={
                EdgeState(
                    "P9.1",
                    cams={
                        EdgeCamState("cam6", EdgeCamStateEnum.DETECTED),
                    },
                    state=EdgeStateEnum.DETECTED
                ),
            },
            state=PlyStateEnum.PLACED,
            previous_state=PlyStateEnum.EXPECTED,
            updated_by="cam:cam6",
            source_device="device_module_id"
        )

    class PalletU:
        first_ply_expected = PlyState(
            "U1",
            edges={
                EdgeState(
                    "U1.1",
                    cams={
                        EdgeCamState("cam1", EdgeCamStateEnum.NEVER_DETECTED),
                    },
                    state=EdgeStateEnum.MISSING
                ),
                EdgeState(
                    "U1.2",
                    cams={
                        EdgeCamState("cam1", EdgeCamStateEnum.NEVER_DETECTED),
                    },
                    state=EdgeStateEnum.MISSING
                ),
            },
            state=PlyStateEnum.EXPECTED,
            previous_state=None,
            updated_by="initial",
            source_device="device_module_id"
        )
        first_ply_phantom_expected = PlyState(
            "U1",
            edges=set(),
            state=PlyStateEnum.EXPECTED,
            previous_state=None,
            updated_by="initial",
            source_device="device_module_id"
        )
        first_ply_placed = PlyState(
            "U1",
            edges={
                EdgeState(
                    "U1.1",
                    cams={
                        EdgeCamState("cam1", EdgeCamStateEnum.DETECTED),
                    },
                    state=EdgeStateEnum.DETECTED
                ),
                EdgeState(
                    "U1.2",
                    cams={
                        EdgeCamState("cam1", EdgeCamStateEnum.DETECTED),
                    },
                    state=EdgeStateEnum.DETECTED
                ),
            },
            state=PlyStateEnum.PLACED,
            previous_state=PlyStateEnum.EXPECTED,
            updated_by="cam:cam1",
            source_device="device_module_id"
        )
        first_ply_missing_due_being_covered = PlyState(
            "U1",
            edges={
                EdgeState(
                    "U1.1",
                    cams={
                        EdgeCamState("cam1", EdgeCamStateEnum.MISSING),
                    },
                    state=EdgeStateEnum.MISSING
                ),
                EdgeState(
                    "U1.2",
                    cams={
                        EdgeCamState("cam1", EdgeCamStateEnum.MISSING),
                    },
                    state=EdgeStateEnum.COVERED
                ),
            },
            state=PlyStateEnum.MISSING,
            previous_state=PlyStateEnum.PLACED,
            updated_by="cam:cam1",
            source_device="device_module_id"
        )
        first_ply_missing = PlyState(
            "U1",
            edges={
                EdgeState(
                    "U1.1",
                    cams={
                        EdgeCamState("cam1", EdgeCamStateEnum.MISSING),
                    },
                    state=EdgeStateEnum.MISSING
                ),
                EdgeState(
                    "U1.2",
                    cams={
                        EdgeCamState("cam1", EdgeCamStateEnum.MISSING),
                    },
                    state=EdgeStateEnum.MISSING
                ),
            },
            state=PlyStateEnum.MISSING,
            previous_state=PlyStateEnum.PLACED,
            updated_by="cam:cam1",
            source_device="device_module_id"
        )
        first_ply_missing_2ed_edge = PlyState(
            "U1",
            edges={
                EdgeState(
                    "U1.1",
                    cams={
                        EdgeCamState("cam1", EdgeCamStateEnum.DETECTED),
                    },
                    state=EdgeStateEnum.DETECTED
                ),
                EdgeState(
                    "U1.2",
                    cams={
                        EdgeCamState("cam1", EdgeCamStateEnum.MISSING),
                    },
                    state=EdgeStateEnum.MISSING
                ),
            },
            state=PlyStateEnum.MISSING,
            previous_state=PlyStateEnum.PLACED,
            updated_by="cam:cam1",
            source_device="device_module_id"
        )
        first_ply_phantom_forced_on_expected = PlyState(
            "U1",
            edges=set(),
            state=PlyStateEnum.FORCED,
            previous_state=PlyStateEnum.EXPECTED,
            updated_by="command:force_ply",
            source_device="device_module_id"
        )
        first_ply_partially_covered = PlyState(
            "U1",
            edges={
                EdgeState(
                    "U1.1",
                    cams={
                        EdgeCamState("cam1", EdgeCamStateEnum.DETECTED),
                    },
                    state=EdgeStateEnum.DETECTED
                ),
                EdgeState(
                    "U1.2",
                    cams={
                        EdgeCamState("cam1", EdgeCamStateEnum.MISSING),
                    },
                    state=EdgeStateEnum.COVERED
                ),
            },
            state=PlyStateEnum.PLACED,
            previous_state=PlyStateEnum.PLACED,
            updated_by="ply:U2",
            source_device="device_module_id"
        )
        first_ply_partially_covered_on_missing = PlyState(
            "U1",
            edges={
                EdgeState(
                    "U1.1",
                    cams={
                        EdgeCamState("cam1", EdgeCamStateEnum.DETECTED),
                    },
                    state=EdgeStateEnum.DETECTED
                ),
                EdgeState(
                    "U1.2",
                    cams={
                        EdgeCamState("cam1", EdgeCamStateEnum.MISSING),
                    },
                    state=EdgeStateEnum.COVERED
                ),
            },
            state=PlyStateEnum.PLACED,
            previous_state=PlyStateEnum.MISSING,
            updated_by="cam:cam1",
            source_device="device_module_id"
        )
        first_ply_recheck_on_partially_covered = PlyState(
            "U1",
            edges={
                EdgeState(
                    "U1.1",
                    cams={
                        EdgeCamState("cam1", EdgeCamStateEnum.NEVER_DETECTED),
                    },
                    state=EdgeStateEnum.MISSING
                ),
                EdgeState(
                    "U1.2",
                    cams={
                        EdgeCamState("cam1", EdgeCamStateEnum.MISSING),
                    },
                    state=EdgeStateEnum.COVERED
                ),
            },
            state=PlyStateEnum.MISSING,
            previous_state=PlyStateEnum.PLACED,
            updated_by="command:recheck_ply:force",
            source_device="device_module_id"
        )
        first_ply_partially_covered_after_recheck = PlyState(
            "U1",
            edges={
                EdgeState(
                    "U1.1",
                    cams={
                        EdgeCamState("cam1", EdgeCamStateEnum.DETECTED),
                    },
                    state=EdgeStateEnum.DETECTED
                ),
                EdgeState(
                    "U1.2",
                    cams={
                        EdgeCamState("cam1", EdgeCamStateEnum.MISSING),
                    },
                    state=EdgeStateEnum.COVERED
                ),
            },
            state=PlyStateEnum.PLACED,
            previous_state=PlyStateEnum.MISSING,
            updated_by="cam:cam1",
            source_device="device_module_id"
        )
        first_ply_fully_covered_by_U2_on_force_ply_cmd = PlyState(
            "U1",
            edges={
                EdgeState(
                    "U1.1",
                    cams={
                        EdgeCamState("cam1", EdgeCamStateEnum.DETECTED),
                    },
                    state=EdgeStateEnum.COVERED
                ),
                EdgeState(
                    "U1.2",
                    cams={
                        EdgeCamState("cam1", EdgeCamStateEnum.DETECTED),
                    },
                    state=EdgeStateEnum.COVERED
                ),
            },
            state=PlyStateEnum.COVERED,
            previous_state=PlyStateEnum.PLACED,
            updated_by="ply:U2",
            source_device="device_module_id"
        )
        first_ply_fully_covered_by_U2 = PlyState(
            "U1",
            edges={
                EdgeState(
                    "U1.1",
                    cams={
                        EdgeCamState("cam1", EdgeCamStateEnum.MISSING),
                    },
                    state=EdgeStateEnum.COVERED
                ),
                EdgeState(
                    "U1.2",
                    cams={
                        EdgeCamState("cam1", EdgeCamStateEnum.MISSING),
                    },
                    state=EdgeStateEnum.COVERED
                ),
            },
            state=PlyStateEnum.COVERED,
            previous_state=PlyStateEnum.PLACED,
            updated_by="ply:U2",
            source_device="device_module_id"
        )
        first_ply_fully_covered_by_U2_on_covered = PlyState(
            "U1",
            edges={
                EdgeState(
                    "U1.1",
                    cams={
                        EdgeCamState("cam1", EdgeCamStateEnum.MISSING),
                    },
                    state=EdgeStateEnum.COVERED
                ),
                EdgeState(
                    "U1.2",
                    cams={
                        EdgeCamState("cam1", EdgeCamStateEnum.MISSING),
                    },
                    state=EdgeStateEnum.COVERED
                ),
            },
            state=PlyStateEnum.COVERED,
            previous_state=PlyStateEnum.PLACED,
            updated_by="ply:U2",
            source_device="device_module_id"
        )
        first_ply_fully_covered_by_U2_on_missing = PlyState(
            "U1",
            edges={
                EdgeState(
                    "U1.1",
                    cams={
                        EdgeCamState("cam1", EdgeCamStateEnum.MISSING),
                    },
                    state=EdgeStateEnum.COVERED
                ),
                EdgeState(
                    "U1.2",
                    cams={
                        EdgeCamState("cam1", EdgeCamStateEnum.MISSING),
                    },
                    state=EdgeStateEnum.COVERED
                ),
            },
            state=PlyStateEnum.COVERED,
            previous_state=PlyStateEnum.MISSING,
            updated_by="ply:U2",
            source_device="device_module_id"
        )
        first_ply_fully_covered_by_U6 = PlyState(
            "U1",
            edges={
                EdgeState(
                    "U1.1",
                    cams={
                        EdgeCamState("cam1", EdgeCamStateEnum.DETECTED),
                    },
                    state=EdgeStateEnum.COVERED
                ),
                EdgeState(
                    "U1.2",
                    cams={
                        EdgeCamState("cam1", EdgeCamStateEnum.MISSING),
                    },
                    state=EdgeStateEnum.COVERED
                ),
            },
            state=PlyStateEnum.COVERED,
            previous_state=PlyStateEnum.PLACED,
            updated_by="ply:U6",
            source_device="device_module_id"
        )
        first_ply_fully_covered_by_U6_on_missing = PlyState(
            "U1",
            edges={
                EdgeState(
                    "U1.1",
                    cams={
                        EdgeCamState("cam1", EdgeCamStateEnum.MISSING),
                    },
                    state=EdgeStateEnum.COVERED
                ),
                EdgeState(
                    "U1.2",
                    cams={
                        EdgeCamState("cam1", EdgeCamStateEnum.MISSING),
                    },
                    state=EdgeStateEnum.COVERED
                ),
            },
            state=PlyStateEnum.COVERED,
            previous_state=PlyStateEnum.MISSING,
            updated_by="ply:U6",
            source_device="device_module_id"
        )
        second_ply_expected = PlyState(
            "U2",
            edges={
                EdgeState(
                    "U2.1",
                    cams={
                        EdgeCamState("cam1", EdgeCamStateEnum.NEVER_DETECTED),
                    },
                    state=EdgeStateEnum.MISSING
                ),
                EdgeState(
                    "U2.2",
                    cams={
                        EdgeCamState("cam1", EdgeCamStateEnum.NEVER_DETECTED),
                        EdgeCamState("cam2", EdgeCamStateEnum.NEVER_DETECTED),
                    },
                    state=EdgeStateEnum.MISSING
                ),
            },
            state=PlyStateEnum.EXPECTED,
            previous_state=None,
            updated_by="initial",
            source_device="device_module_id"
        )
        second_ply_phantom_expected = PlyState(
            "U2",
            edges=set(),
            state=PlyStateEnum.EXPECTED,
            previous_state=None,
            updated_by="initial",
            source_device="device_module_id"
        )
        second_ply_phantom_forced_on_expected = PlyState(
            "U2",
            edges=set(),
            state=PlyStateEnum.FORCED,
            previous_state=PlyStateEnum.EXPECTED,
            updated_by="command:force_ply",
            source_device="device_module_id"
        )
        second_ply_placed = PlyState(
            "U2",
            edges={
                EdgeState(
                    "U2.1",
                    cams={
                        EdgeCamState("cam1", EdgeCamStateEnum.DETECTED),
                    },
                    state=EdgeStateEnum.DETECTED
                ),
                EdgeState(
                    "U2.2",
                    cams={
                        EdgeCamState("cam1", EdgeCamStateEnum.DETECTED),
                        EdgeCamState("cam2", EdgeCamStateEnum.NEVER_DETECTED),
                    },
                    state=EdgeStateEnum.DETECTED
                ),
            },
            state=PlyStateEnum.PLACED,
            previous_state=PlyStateEnum.EXPECTED,
            updated_by="cam:cam1",
            source_device="device_module_id"
        )
        second_ply_placed_after_missing = PlyState(
            "U2",
            edges={
                EdgeState(
                    "U2.1",
                    cams={
                        EdgeCamState("cam1", EdgeCamStateEnum.DETECTED),
                    },
                    state=EdgeStateEnum.DETECTED
                ),
                EdgeState(
                    "U2.2",
                    cams={
                        EdgeCamState("cam1", EdgeCamStateEnum.DETECTED),
                        EdgeCamState("cam2", EdgeCamStateEnum.NEVER_DETECTED),
                    },
                    state=EdgeStateEnum.DETECTED
                ),
            },
            state=PlyStateEnum.PLACED,
            previous_state=PlyStateEnum.MISSING,
            updated_by="cam:cam1",
            source_device="device_module_id"
        )
        second_ply_missing = PlyState(
            "U2",
            edges={
                EdgeState(
                    "U2.1",
                    cams={
                        EdgeCamState("cam1", EdgeCamStateEnum.MISSING),
                    },
                    state=EdgeStateEnum.MISSING
                ),
                EdgeState(
                    "U2.2",
                    cams={
                        EdgeCamState("cam1", EdgeCamStateEnum.MISSING),
                        EdgeCamState("cam2", EdgeCamStateEnum.NEVER_DETECTED),
                    },
                    state=EdgeStateEnum.MISSING
                ),
            },
            state=PlyStateEnum.MISSING,
            previous_state=PlyStateEnum.PLACED,
            updated_by="cam:cam1",
            source_device="device_module_id"
        )
        second_ply_missing_due_being_covered = PlyState(
            "U2",
            edges={
                EdgeState(
                    "U2.1",
                    cams={
                        EdgeCamState("cam1", EdgeCamStateEnum.MISSING),
                    },
                    state=EdgeStateEnum.MISSING
                ),
                EdgeState(
                    "U2.2",
                    cams={
                        EdgeCamState("cam1", EdgeCamStateEnum.DETECTED),
                        EdgeCamState("cam2", EdgeCamStateEnum.NEVER_DETECTED),
                    },
                    state=EdgeStateEnum.COVERED
                ),
            },
            state=PlyStateEnum.MISSING,
            previous_state=PlyStateEnum.PLACED,
            updated_by="cam:cam1",
            source_device="device_module_id"
        )
        second_ply_missing_one_edge = PlyState(
            "U2",
            edges={
                EdgeState(
                    "U2.1",
                    cams={
                        EdgeCamState("cam1", EdgeCamStateEnum.DETECTED),
                    },
                    state=EdgeStateEnum.DETECTED
                ),
                EdgeState(
                    "U2.2",
                    cams={
                        EdgeCamState("cam1", EdgeCamStateEnum.MISSING),
                        EdgeCamState("cam2", EdgeCamStateEnum.NEVER_DETECTED),
                    },
                    state=EdgeStateEnum.MISSING
                ),
            },
            state=PlyStateEnum.MISSING,
            previous_state=PlyStateEnum.PLACED,
            updated_by="cam:cam1",
            source_device="device_module_id"
        )
        second_ply_partially_covered = PlyState(
            "U2",
            edges={
                EdgeState(
                    "U2.1",
                    cams={
                        EdgeCamState("cam1", EdgeCamStateEnum.DETECTED),
                    },
                    state=EdgeStateEnum.DETECTED
                ),
                EdgeState(
                    "U2.2",
                    cams={
                        EdgeCamState("cam1", EdgeCamStateEnum.DETECTED),
                        EdgeCamState("cam2", EdgeCamStateEnum.NEVER_DETECTED),
                    },
                    state=EdgeStateEnum.COVERED
                ),
            },
            state=PlyStateEnum.PLACED,
            previous_state=PlyStateEnum.PLACED,
            updated_by="ply:U3",
            source_device="device_module_id"
        )
        second_ply_fully_covered_by_U3 = PlyState(
            "U2",
            edges={
                EdgeState(
                    "U2.1",
                    cams={
                        EdgeCamState("cam1", EdgeCamStateEnum.DETECTED),
                    },
                    state=EdgeStateEnum.COVERED
                ),
                EdgeState(
                    "U2.2",
                    cams={
                        EdgeCamState("cam1", EdgeCamStateEnum.DETECTED),
                        EdgeCamState("cam2", EdgeCamStateEnum.NEVER_DETECTED),
                    },
                    state=EdgeStateEnum.COVERED
                ),
            },
            state=PlyStateEnum.COVERED,
            previous_state=PlyStateEnum.PLACED,
            updated_by="ply:U3",
            source_device="device_module_id"
        )
        second_ply_fully_covered_by_U6 = PlyState(
            "U2",
            edges={
                EdgeState(
                    "U2.1",
                    cams={
                        EdgeCamState("cam1", EdgeCamStateEnum.DETECTED),
                    },
                    state=EdgeStateEnum.COVERED
                ),
                EdgeState(
                    "U2.2",
                    cams={
                        EdgeCamState("cam1", EdgeCamStateEnum.DETECTED),
                        EdgeCamState("cam2", EdgeCamStateEnum.NEVER_DETECTED),
                    },
                    state=EdgeStateEnum.COVERED
                ),
            },
            state=PlyStateEnum.COVERED,
            previous_state=PlyStateEnum.PLACED,
            updated_by="ply:U6",
            source_device="device_module_id"
        )
        second_ply_fully_covered_by_U6_on_missing = PlyState(
            "U2",
            edges={
                EdgeState(
                    "U2.1",
                    cams={
                        EdgeCamState("cam1", EdgeCamStateEnum.MISSING),
                    },
                    state=EdgeStateEnum.COVERED
                ),
                EdgeState(
                    "U2.2",
                    cams={
                        EdgeCamState("cam1", EdgeCamStateEnum.DETECTED),
                        EdgeCamState("cam2", EdgeCamStateEnum.NEVER_DETECTED),
                    },
                    state=EdgeStateEnum.COVERED
                ),
            },
            state=PlyStateEnum.COVERED,
            previous_state=PlyStateEnum.MISSING,
            updated_by="ply:U6",
            source_device="device_module_id"
        )
        second_ply_fully_covered_on_missing = PlyState(
            "U2",
            edges={
                EdgeState(
                    "U2.1",
                    cams={
                        EdgeCamState("cam1", EdgeCamStateEnum.MISSING),
                    },
                    state=EdgeStateEnum.COVERED
                ),
                EdgeState(
                    "U2.2",
                    cams={
                        EdgeCamState("cam1", EdgeCamStateEnum.MISSING),
                        EdgeCamState("cam2", EdgeCamStateEnum.NEVER_DETECTED),
                    },
                    state=EdgeStateEnum.COVERED
                ),
            },
            state=PlyStateEnum.COVERED,
            previous_state=PlyStateEnum.MISSING,
            updated_by="ply:U3",
            source_device="device_module_id"
        )
        second_ply_fully_covered_on_missing_one_edge = PlyState(
            "U2",
            edges={
                EdgeState(
                    "U2.1",
                    cams={
                        EdgeCamState("cam1", EdgeCamStateEnum.DETECTED),
                    },
                    state=EdgeStateEnum.COVERED
                ),
                EdgeState(
                    "U2.2",
                    cams={
                        EdgeCamState("cam1", EdgeCamStateEnum.MISSING),
                        EdgeCamState("cam2", EdgeCamStateEnum.NEVER_DETECTED),
                    },
                    state=EdgeStateEnum.COVERED
                ),
            },
            state=PlyStateEnum.COVERED,
            previous_state=PlyStateEnum.MISSING,
            updated_by="ply:U3",
            source_device="device_module_id"
        )
        third_ply_expected = PlyState(
            "U3",
            edges={
                EdgeState(
                    "U3.1",
                    cams={
                        EdgeCamState("cam2", EdgeCamStateEnum.NEVER_DETECTED),
                    },
                    state=EdgeStateEnum.MISSING
                ),
                EdgeState(
                    "U3.2",
                    cams={
                        EdgeCamState("cam2", EdgeCamStateEnum.NEVER_DETECTED),
                    },
                    state=EdgeStateEnum.MISSING
                ),
            },
            state=PlyStateEnum.EXPECTED,
            previous_state=None,
            updated_by="initial",
            source_device="device_module_id"
        )
        third_ply_placed_updated_by_cam_2 = PlyState(
            "U3",
            edges={
                EdgeState(
                    "U3.1",
                    cams={
                        EdgeCamState("cam2", EdgeCamStateEnum.DETECTED),
                    },
                    state=EdgeStateEnum.DETECTED
                ),
                EdgeState(
                    "U3.2",
                    cams={
                        EdgeCamState("cam2", EdgeCamStateEnum.DETECTED),
                    },
                    state=EdgeStateEnum.DETECTED
                ),
            },
            state=PlyStateEnum.PLACED,
            previous_state=PlyStateEnum.EXPECTED,
            updated_by="cam:cam2",
            source_device="device_module_id"
        )
        third_ply_partially_covered = PlyState(
            "U3",
            edges={
                EdgeState(
                    "U3.1",
                    cams={
                        EdgeCamState("cam2", EdgeCamStateEnum.DETECTED),
                    },
                    state=EdgeStateEnum.DETECTED
                ),
                EdgeState(
                    "U3.2",
                    cams={
                        EdgeCamState("cam2", EdgeCamStateEnum.DETECTED),
                    },
                    state=EdgeStateEnum.COVERED
                ),
            },
            state=PlyStateEnum.PLACED,
            previous_state=PlyStateEnum.PLACED,
            updated_by="ply:U4",
            source_device="device_module_id"
        )
        third_ply_fully_covered_by_U6 = PlyState(
            "U3",
            edges={
                EdgeState(
                    "U3.1",
                    cams={
                        EdgeCamState("cam2", EdgeCamStateEnum.MISSING),
                    },
                    state=EdgeStateEnum.COVERED
                ),
                EdgeState(
                    "U3.2",
                    cams={
                        EdgeCamState("cam2", EdgeCamStateEnum.DETECTED),
                    },
                    state=EdgeStateEnum.COVERED
                ),
            },
            state=PlyStateEnum.COVERED,
            previous_state=PlyStateEnum.PLACED,
            updated_by="ply:U6",
            source_device="device_module_id"
        )
        third_ply_fully_covered_by_U6_on_missing = PlyState(
            "U3",
            edges={
                EdgeState(
                    "U3.1",
                    cams={
                        EdgeCamState("cam2", EdgeCamStateEnum.MISSING),
                    },
                    state=EdgeStateEnum.COVERED
                ),
                EdgeState(
                    "U3.2",
                    cams={
                        EdgeCamState("cam2", EdgeCamStateEnum.DETECTED),
                    },
                    state=EdgeStateEnum.COVERED
                ),
            },
            state=PlyStateEnum.COVERED,
            previous_state=PlyStateEnum.MISSING,
            updated_by="ply:U6",
            source_device="device_module_id"
        )
        third_ply_missing_due_being_covered = PlyState(
            "U3",
            edges={
                EdgeState(
                    "U3.1",
                    cams={
                        EdgeCamState("cam2", EdgeCamStateEnum.MISSING),
                    },
                    state=EdgeStateEnum.MISSING
                ),
                EdgeState(
                    "U3.2",
                    cams={
                        EdgeCamState("cam2", EdgeCamStateEnum.DETECTED),
                    },
                    state=EdgeStateEnum.COVERED
                ),
            },
            state=PlyStateEnum.MISSING,
            previous_state=PlyStateEnum.PLACED,
            updated_by="cam:cam2",
            source_device="device_module_id"
        )
        fourth_ply_expected = PlyState(
            "U4",
            edges={
                EdgeState(
                    "U4.1",
                    cams={
                        EdgeCamState("cam2", EdgeCamStateEnum.NEVER_DETECTED),
                    },
                    state=EdgeStateEnum.MISSING
                ),
                EdgeState(
                    "U4.2",
                    cams={
                        EdgeCamState("cam2", EdgeCamStateEnum.NEVER_DETECTED),
                    },
                    state=EdgeStateEnum.MISSING
                ),
            },
            state=PlyStateEnum.EXPECTED,
            previous_state=None,
            updated_by="initial",
            source_device="device_module_id"
        )
        fourth_ply_placed = PlyState(
            "U4",
            edges={
                EdgeState(
                    "U4.1",
                    cams={
                        EdgeCamState("cam2", EdgeCamStateEnum.DETECTED),
                    },
                    state=EdgeStateEnum.DETECTED
                ),
                EdgeState(
                    "U4.2",
                    cams={
                        EdgeCamState("cam2", EdgeCamStateEnum.DETECTED),
                    },
                    state=EdgeStateEnum.DETECTED
                ),
            },
            state=PlyStateEnum.PLACED,
            previous_state=PlyStateEnum.EXPECTED,
            updated_by="cam:cam2",
            source_device="device_module_id"
        )
        fourth_ply_missing = PlyState(
            "U4",
            edges={
                EdgeState(
                    "U4.1",
                    cams={
                        EdgeCamState("cam2", EdgeCamStateEnum.DETECTED),
                    },
                    state=EdgeStateEnum.DETECTED
                ),
                EdgeState(
                    "U4.2",
                    cams={
                        EdgeCamState("cam2", EdgeCamStateEnum.MISSING),
                    },
                    state=EdgeStateEnum.MISSING
                ),
            },
            state=PlyStateEnum.MISSING,
            previous_state=PlyStateEnum.PLACED,
            updated_by="cam:cam2",
            source_device="device_module_id"
        )
        fourth_ply_missing_due_being_covered = PlyState(
            "U4",
            edges={
                EdgeState(
                    "U4.1",
                    cams={
                        EdgeCamState("cam2", EdgeCamStateEnum.MISSING),
                    },
                    state=EdgeStateEnum.MISSING
                ),
                EdgeState(
                    "U4.2",
                    cams={
                        EdgeCamState("cam2", EdgeCamStateEnum.DETECTED),
                    },
                    state=EdgeStateEnum.COVERED
                ),
            },
            state=PlyStateEnum.MISSING,
            previous_state=PlyStateEnum.PLACED,
            updated_by="cam:cam2",
            source_device="device_module_id"
        )
        fourth_ply_fully_covered_by_U5_on_missing = PlyState(
            "U4",
            edges={
                EdgeState(
                    "U4.1",
                    cams={
                        EdgeCamState("cam2", EdgeCamStateEnum.DETECTED),
                    },
                    state=EdgeStateEnum.COVERED
                ),
                EdgeState(
                    "U4.2",
                    cams={
                        EdgeCamState("cam2", EdgeCamStateEnum.MISSING),
                    },
                    state=EdgeStateEnum.COVERED
                ),
            },
            state=PlyStateEnum.COVERED,
            previous_state=PlyStateEnum.MISSING,
            updated_by="ply:U5",
            source_device="device_module_id"
        )
        fourth_ply_fully_covered_by_U6 = PlyState(
            "U4",
            edges={
                EdgeState(
                    "U4.1",
                    cams={
                        EdgeCamState("cam2", EdgeCamStateEnum.MISSING),
                    },
                    state=EdgeStateEnum.COVERED
                ),
                EdgeState(
                    "U4.2",
                    cams={
                        EdgeCamState("cam2", EdgeCamStateEnum.DETECTED),
                    },
                    state=EdgeStateEnum.COVERED
                ),
            },
            state=PlyStateEnum.COVERED,
            previous_state=PlyStateEnum.PLACED,
            updated_by="ply:U6",
            source_device="device_module_id"
        )
        fourth_ply_fully_covered_by_U6_on_missing = PlyState(
            "U4",
            edges={
                EdgeState(
                    "U4.1",
                    cams={
                        EdgeCamState("cam2", EdgeCamStateEnum.MISSING),
                    },
                    state=EdgeStateEnum.COVERED
                ),
                EdgeState(
                    "U4.2",
                    cams={
                        EdgeCamState("cam2", EdgeCamStateEnum.DETECTED),
                    },
                    state=EdgeStateEnum.COVERED
                ),
            },
            state=PlyStateEnum.COVERED,
            previous_state=PlyStateEnum.MISSING,
            updated_by="ply:U6",
            source_device="device_module_id"
        )
        fourth_ply_partially_covered = PlyState(
            "U4",
            edges={
                EdgeState(
                    "U4.1",
                    cams={
                        EdgeCamState("cam2", EdgeCamStateEnum.DETECTED),
                    },
                    state=EdgeStateEnum.DETECTED
                ),
                EdgeState(
                    "U4.2",
                    cams={
                        EdgeCamState("cam2", EdgeCamStateEnum.DETECTED),
                    },
                    state=EdgeStateEnum.COVERED
                ),
            },
            state=PlyStateEnum.PLACED,
            previous_state=PlyStateEnum.PLACED,
            updated_by="ply:U5",
            source_device="device_module_id"
        )
        fifth_ply_expected = PlyState(
            "U5",
            edges={
                EdgeState(
                    "U5.1",
                    cams={
                        EdgeCamState("cam2", EdgeCamStateEnum.NEVER_DETECTED),
                        EdgeCamState("cam3", EdgeCamStateEnum.NEVER_DETECTED),
                    },
                    state=EdgeStateEnum.MISSING
                ),
                EdgeState(
                    "U5.2",
                    cams={
                        EdgeCamState("cam2", EdgeCamStateEnum.NEVER_DETECTED),
                        EdgeCamState("cam3", EdgeCamStateEnum.NEVER_DETECTED),
                    },
                    state=EdgeStateEnum.MISSING
                ),
            },
            state=PlyStateEnum.EXPECTED,
            previous_state=None,
            updated_by="initial",
            source_device="device_module_id"
        )
        fifth_ply_expected_edge_detected_by_cam2 = PlyState(
            "U5",
            edges={
                EdgeState(
                    "U5.1",
                    cams={
                        EdgeCamState("cam2", EdgeCamStateEnum.DETECTED),
                        EdgeCamState("cam3", EdgeCamStateEnum.NEVER_DETECTED),
                    },
                    state=EdgeStateEnum.DETECTED
                ),
                EdgeState(
                    "U5.2",
                    cams={
                        EdgeCamState("cam2", EdgeCamStateEnum.NEVER_DETECTED),
                        EdgeCamState("cam3", EdgeCamStateEnum.NEVER_DETECTED),
                    },
                    state=EdgeStateEnum.MISSING
                ),
            },
            state=PlyStateEnum.EXPECTED,
            previous_state=None,
            updated_by="cam:cam2",
            source_device="device_module_id"
        )
        fifth_ply_placed_update_by_cam2 = PlyState(
            "U5",
            edges={
                EdgeState(
                    "U5.1",
                    cams={
                        EdgeCamState("cam2", EdgeCamStateEnum.DETECTED),
                        EdgeCamState("cam3", EdgeCamStateEnum.NEVER_DETECTED),
                    },
                    state=EdgeStateEnum.DETECTED
                ),
                EdgeState(
                    "U5.2",
                    cams={
                        EdgeCamState("cam2", EdgeCamStateEnum.DETECTED),
                        EdgeCamState("cam3", EdgeCamStateEnum.NEVER_DETECTED),
                    },
                    state=EdgeStateEnum.DETECTED
                ),
            },
            state=PlyStateEnum.PLACED,
            previous_state=PlyStateEnum.EXPECTED,
            updated_by="cam:cam2",
            source_device="device_module_id"
        )
        fifth_ply_placed_update_by_cam3 = PlyState(
            "U5",
            edges={
                EdgeState(
                    "U5.1",
                    cams={
                        EdgeCamState("cam2", EdgeCamStateEnum.DETECTED),
                        EdgeCamState("cam3", EdgeCamStateEnum.DETECTED),
                    },
                    state=EdgeStateEnum.DETECTED
                ),
                EdgeState(
                    "U5.2",
                    cams={
                        EdgeCamState("cam2", EdgeCamStateEnum.NEVER_DETECTED),
                        EdgeCamState("cam3", EdgeCamStateEnum.DETECTED),
                    },
                    state=EdgeStateEnum.DETECTED
                ),
            },
            state=PlyStateEnum.PLACED,
            previous_state=PlyStateEnum.EXPECTED,
            updated_by="cam:cam3",
            source_device="device_module_id"
        )
        fifth_ply_placed = PlyState(
            "U5",
            edges={
                EdgeState(
                    "U5.1",
                    cams={
                        EdgeCamState("cam2", EdgeCamStateEnum.DETECTED),
                        EdgeCamState("cam3", EdgeCamStateEnum.DETECTED),
                    },
                    state=EdgeStateEnum.DETECTED
                ),
                EdgeState(
                    "U5.2",
                    cams={
                        EdgeCamState("cam2", EdgeCamStateEnum.DETECTED),
                        EdgeCamState("cam3", EdgeCamStateEnum.DETECTED),
                    },
                    state=EdgeStateEnum.DETECTED
                ),
            },
            state=PlyStateEnum.PLACED,
            previous_state=PlyStateEnum.EXPECTED,
            updated_by="cam:cam3",
            source_device="device_module_id"
        )
        fifth_ply_fully_covered_by_U6 = PlyState(
            "U5",
            edges={
                EdgeState(
                    "U5.1",
                    cams={
                        EdgeCamState("cam2", EdgeCamStateEnum.MISSING),
                        EdgeCamState("cam3", EdgeCamStateEnum.NEVER_DETECTED),
                    },
                    state=EdgeStateEnum.COVERED
                ),
                EdgeState(
                    "U5.2",
                    cams={
                        EdgeCamState("cam2", EdgeCamStateEnum.MISSING),
                        EdgeCamState("cam3", EdgeCamStateEnum.NEVER_DETECTED),
                    },
                    state=EdgeStateEnum.COVERED
                ),
            },
            state=PlyStateEnum.COVERED,
            previous_state=PlyStateEnum.PLACED,
            updated_by="ply:U6",
            source_device="device_module_id"
        )
        fifth_ply_fully_covered_by_U6_with_edges_by_cam3_still_detected = PlyState(
            "U5",
            edges={
                EdgeState(
                    "U5.1",
                    cams={
                        EdgeCamState("cam2", EdgeCamStateEnum.MISSING),
                        EdgeCamState("cam3", EdgeCamStateEnum.DETECTED),
                    },
                    state=EdgeStateEnum.COVERED
                ),
                EdgeState(
                    "U5.2",
                    cams={
                        EdgeCamState("cam2", EdgeCamStateEnum.MISSING),
                        EdgeCamState("cam3", EdgeCamStateEnum.DETECTED),
                    },
                    state=EdgeStateEnum.COVERED
                ),
            },
            state=PlyStateEnum.COVERED,
            previous_state=PlyStateEnum.PLACED,
            updated_by="ply:U6",
            source_device="device_module_id"
        )
        fifth_ply_fully_covered_by_U6_on_missing = PlyState(
            "U5",
            edges={
                EdgeState(
                    "U5.1",
                    cams={
                        EdgeCamState("cam2", EdgeCamStateEnum.MISSING),
                        EdgeCamState("cam3", EdgeCamStateEnum.NEVER_DETECTED),
                    },
                    state=EdgeStateEnum.COVERED
                ),
                EdgeState(
                    "U5.2",
                    cams={
                        EdgeCamState("cam2", EdgeCamStateEnum.MISSING),
                        EdgeCamState("cam3", EdgeCamStateEnum.NEVER_DETECTED),
                    },
                    state=EdgeStateEnum.COVERED
                ),
            },
            state=PlyStateEnum.COVERED,
            previous_state=PlyStateEnum.MISSING,
            updated_by="ply:U6",
            source_device="device_module_id"
        )
        fifth_ply_fully_covered_by_U6_on_missing_by_both_cams = PlyState(
            "U5",
            edges={
                EdgeState(
                    "U5.1",
                    cams={
                        EdgeCamState("cam2", EdgeCamStateEnum.MISSING),
                        EdgeCamState("cam3", EdgeCamStateEnum.MISSING),
                    },
                    state=EdgeStateEnum.COVERED
                ),
                EdgeState(
                    "U5.2",
                    cams={
                        EdgeCamState("cam2", EdgeCamStateEnum.MISSING),
                        EdgeCamState("cam3", EdgeCamStateEnum.MISSING),
                    },
                    state=EdgeStateEnum.COVERED
                ),
            },
            state=PlyStateEnum.COVERED,
            previous_state=PlyStateEnum.MISSING,
            updated_by="ply:U6",
            source_device="device_module_id"
        )
        fifth_ply_missing_due_being_covered_update_by_cam2 = PlyState(
            "U5",
            edges={
                EdgeState(
                    "U5.1",
                    cams={
                        EdgeCamState("cam2", EdgeCamStateEnum.MISSING),
                        EdgeCamState("cam3", EdgeCamStateEnum.NEVER_DETECTED),
                    },
                    state=EdgeStateEnum.MISSING
                ),
                EdgeState(
                    "U5.2",
                    cams={
                        EdgeCamState("cam2", EdgeCamStateEnum.MISSING),
                        EdgeCamState("cam3", EdgeCamStateEnum.NEVER_DETECTED),
                    },
                    state=EdgeStateEnum.MISSING
                ),
            },
            state=PlyStateEnum.MISSING,
            previous_state=PlyStateEnum.PLACED,
            updated_by="cam:cam2",
            source_device="device_module_id"
        )
        fifth_ply_missing_due_being_covered_update_by_cam3 = PlyState(
            "U5",
            edges={
                EdgeState(
                    "U5.1",
                    cams={
                        EdgeCamState("cam2", EdgeCamStateEnum.MISSING),
                        EdgeCamState("cam3", EdgeCamStateEnum.MISSING),
                    },
                    state=EdgeStateEnum.MISSING
                ),
                EdgeState(
                    "U5.2",
                    cams={
                        EdgeCamState("cam2", EdgeCamStateEnum.MISSING),
                        EdgeCamState("cam3", EdgeCamStateEnum.MISSING),
                    },
                    state=EdgeStateEnum.MISSING
                ),
            },
            state=PlyStateEnum.MISSING,
            previous_state=PlyStateEnum.PLACED,
            updated_by="cam:cam3",
            source_device="device_module_id"
        )
        sixth_ply_expected = PlyState(
            "U6",
            edges={
                EdgeState(
                    "U6.1",
                    cams={
                        EdgeCamState("cam2", EdgeCamStateEnum.NEVER_DETECTED),
                        EdgeCamState("cam3", EdgeCamStateEnum.NEVER_DETECTED),
                    },
                    state=EdgeStateEnum.MISSING
                ),
                EdgeState(
                    "U6.2",
                    cams={
                        EdgeCamState("cam2", EdgeCamStateEnum.NEVER_DETECTED),
                        EdgeCamState("cam3", EdgeCamStateEnum.NEVER_DETECTED),
                    },
                    state=EdgeStateEnum.MISSING
                ),
            },
            state=PlyStateEnum.EXPECTED,
            previous_state=None,
            updated_by="initial",
            source_device="device_module_id"
        )
        sixth_ply_phantom_forced_on_expected = PlyState(
            "U6",
            edges=set(),
            state=PlyStateEnum.FORCED,
            previous_state=PlyStateEnum.EXPECTED,
            updated_by="command:force_ply",
            source_device="device_module_id"
        )
        sixth_ply_phantom_expected = PlyState(
            "U6",
            edges=set(),
            state=PlyStateEnum.EXPECTED,
            previous_state=None,
            updated_by="initial",
            source_device="device_module_id"
        )
        sixth_ply_placed_by_cam2 = PlyState(
            "U6",
            edges={
                EdgeState(
                    "U6.1",
                    cams={
                        EdgeCamState("cam2", EdgeCamStateEnum.DETECTED),
                        EdgeCamState("cam3", EdgeCamStateEnum.NEVER_DETECTED),
                    },
                    state=EdgeStateEnum.DETECTED
                ),
                EdgeState(
                    "U6.2",
                    cams={
                        EdgeCamState("cam2", EdgeCamStateEnum.DETECTED),
                        EdgeCamState("cam3", EdgeCamStateEnum.NEVER_DETECTED),

                    },
                    state=EdgeStateEnum.DETECTED
                ),
            },
            state=PlyStateEnum.PLACED,
            previous_state=PlyStateEnum.EXPECTED,
            updated_by="cam:cam2",
            source_device="device_module_id"
        )
        sixth_ply_placed_by_cam3 = PlyState(
            "U6",
            edges={
                EdgeState(
                    "U6.1",
                    cams={
                        EdgeCamState("cam2", EdgeCamStateEnum.NEVER_DETECTED),
                        EdgeCamState("cam3", EdgeCamStateEnum.DETECTED),
                    },
                    state=EdgeStateEnum.DETECTED
                ),
                EdgeState(
                    "U6.2",
                    cams={
                        EdgeCamState("cam2", EdgeCamStateEnum.NEVER_DETECTED),
                        EdgeCamState("cam3", EdgeCamStateEnum.DETECTED),

                    },
                    state=EdgeStateEnum.DETECTED
                ),
            },
            state=PlyStateEnum.PLACED,
            previous_state=PlyStateEnum.EXPECTED,
            updated_by="cam:cam3",
            source_device="device_module_id"
        )
        sixth_ply_partially_covered_by_cam2_on_expected = PlyState(
            "U6",
            edges={
                EdgeState(
                    "U6.1",
                    cams={
                        EdgeCamState("cam2", EdgeCamStateEnum.DETECTED),
                        EdgeCamState("cam3", EdgeCamStateEnum.NEVER_DETECTED),
                    },
                    state=EdgeStateEnum.DETECTED
                ),
                EdgeState(
                    "U6.2",
                    cams={
                        EdgeCamState("cam2", EdgeCamStateEnum.DETECTED),
                        EdgeCamState("cam3", EdgeCamStateEnum.NEVER_DETECTED),
                    },
                    state=EdgeStateEnum.COVERED
                ),
            },
            state=PlyStateEnum.PLACED,
            previous_state=PlyStateEnum.PLACED,
            updated_by="ply:U7",
            source_device="device_module_id"
        )
        sixth_ply_partially_covered_by_cam2 = PlyState(
            "U6",
            edges={
                EdgeState(
                    "U6.1",
                    cams={
                        EdgeCamState("cam2", EdgeCamStateEnum.DETECTED),
                        EdgeCamState("cam3", EdgeCamStateEnum.NEVER_DETECTED),
                    },
                    state=EdgeStateEnum.DETECTED
                ),
                EdgeState(
                    "U6.2",
                    cams={
                        EdgeCamState("cam2", EdgeCamStateEnum.MISSING),
                        EdgeCamState("cam3", EdgeCamStateEnum.NEVER_DETECTED),
                    },
                    state=EdgeStateEnum.COVERED
                ),
            },
            state=PlyStateEnum.PLACED,
            previous_state=PlyStateEnum.MISSING,
            updated_by="ply:U7",
            source_device="device_module_id"
        )
        sixth_ply_partially_covered_by_cam3 = PlyState(
            "U6",
            edges={
                EdgeState(
                    "U6.1",
                    cams={
                        EdgeCamState("cam2", EdgeCamStateEnum.NEVER_DETECTED),
                        EdgeCamState("cam3", EdgeCamStateEnum.DETECTED),
                    },
                    state=EdgeStateEnum.DETECTED
                ),
                EdgeState(
                    "U6.2",
                    cams={
                        EdgeCamState("cam2", EdgeCamStateEnum.NEVER_DETECTED),
                        EdgeCamState("cam3", EdgeCamStateEnum.MISSING),
                    },
                    state=EdgeStateEnum.COVERED
                ),
            },
            state=PlyStateEnum.PLACED,
            previous_state=PlyStateEnum.MISSING,
            updated_by="ply:U7",
            source_device="device_module_id"
        )
        seventh_ply_expected = PlyState(
            "U7",
            edges={
                EdgeState(
                    "U7.1",
                    cams={
                        EdgeCamState("cam2", EdgeCamStateEnum.NEVER_DETECTED),
                        EdgeCamState("cam3", EdgeCamStateEnum.NEVER_DETECTED),
                    },
                    state=EdgeStateEnum.MISSING
                ),
                EdgeState(
                    "U7.2",
                    cams={
                        EdgeCamState("cam2", EdgeCamStateEnum.NEVER_DETECTED),
                        EdgeCamState("cam3", EdgeCamStateEnum.NEVER_DETECTED),
                    },
                    state=EdgeStateEnum.MISSING
                ),
            },
            state=PlyStateEnum.EXPECTED,
            previous_state=None,
            updated_by="initial",
            source_device="device_module_id"
        )
        seventh_ply_placed_updated_by_cam2 = PlyState(
            "U7",
            edges={
                EdgeState(
                    "U7.1",
                    cams={
                        EdgeCamState("cam2", EdgeCamStateEnum.DETECTED),
                        EdgeCamState("cam3", EdgeCamStateEnum.NEVER_DETECTED),
                    },
                    state=EdgeStateEnum.DETECTED
                ),
                EdgeState(
                    "U7.2",
                    cams={
                        EdgeCamState("cam2", EdgeCamStateEnum.DETECTED),
                        EdgeCamState("cam3", EdgeCamStateEnum.NEVER_DETECTED),
                    },
                    state=EdgeStateEnum.DETECTED
                ),
            },
            state=PlyStateEnum.PLACED,
            previous_state=PlyStateEnum.EXPECTED,
            updated_by="cam:cam2",
            source_device="device_module_id"
        )
        seventh_ply_placed_updated_by_cam3 = PlyState(
            "U7",
            edges={
                EdgeState(
                    "U7.1",
                    cams={
                        EdgeCamState("cam2", EdgeCamStateEnum.NEVER_DETECTED),
                        EdgeCamState("cam3", EdgeCamStateEnum.DETECTED),
                    },
                    state=EdgeStateEnum.DETECTED
                ),
                EdgeState(
                    "U7.2",
                    cams={
                        EdgeCamState("cam2", EdgeCamStateEnum.NEVER_DETECTED),
                        EdgeCamState("cam3", EdgeCamStateEnum.DETECTED),
                    },
                    state=EdgeStateEnum.DETECTED
                ),
            },
            state=PlyStateEnum.PLACED,
            previous_state=PlyStateEnum.EXPECTED,
            updated_by="cam:cam3",
            source_device="device_module_id"
        )


class LaserFeedbacks:
    class PliesToBePlaced:
        class FirstPalletP:
            first_ply = {
                "metadata": {
                    "session": {
                        "mouldId": "mould_id",
                        "plyId": "P1",
                        "moduleId": "em-decision-maker"
                    },
                    "groundTruthVersion": "v1.0.0",
                    "mouldId": "mould_id",
                    "bladeSn": "blade_sn",
                    "bladeRevision": "blade_revision",
                    "layers": [
                        "layer_P"
                    ]
                },
                "feedback": [
                    {
                        "type": "plies-to-be-placed",
                        "P1": create_laser_feedback_ply_data("P1")
                    }
                ],
                "feedbackType": "plies-to-be-placed"
            }
            first_ply_multi_layers = {
                "metadata": {
                    "session": {
                        "mouldId": "mould_id",
                        "plyId": "P1",
                        "moduleId": "em-decision-maker"
                    },
                    "groundTruthVersion": "v1.0.0",
                    "mouldId": "mould_id",
                    "bladeSn": "blade_sn",
                    "bladeRevision": "blade_revision",
                    "layers": [
                        "layer_P",
                        "layer_U"
                    ]
                },
                "feedback": [
                    {
                        "type": "plies-to-be-placed",
                        "P1": create_laser_feedback_ply_data("P1")
                    }
                ],
                "feedbackType": "plies-to-be-placed"
            }
            second_ply = {
                "metadata": {
                    "session": {
                        "mouldId": "mould_id",
                        "plyId": "P2",
                        "moduleId": "em-decision-maker"
                    },
                    "groundTruthVersion": "v1.0.0",
                    "mouldId": "mould_id",
                    "bladeSn": "blade_sn",
                    "bladeRevision": "blade_revision",
                    "layers": [
                        "layer_P"
                    ]
                },
                "feedback": [
                    {
                        "type": "plies-to-be-placed",
                        "P2": create_laser_feedback_ply_data("P2")
                    }
                ],
                "feedbackType": "plies-to-be-placed"
            }
            second_ply_multi_layers = {
                "metadata": {
                    "session": {
                        "mouldId": "mould_id",
                        "plyId": "P2",
                        "moduleId": "em-decision-maker"
                    },
                    "groundTruthVersion": "v1.0.0",
                    "mouldId": "mould_id",
                    "bladeSn": "blade_sn",
                    "bladeRevision": "blade_revision",
                    "layers": [
                        "layer_P",
                        "layer_U"
                    ]
                },
                "feedback": [
                    {
                        "type": "plies-to-be-placed",
                        "P2": create_laser_feedback_ply_data("P2")
                    }
                ],
                "feedbackType": "plies-to-be-placed"
            }
            third_ply = {
                "metadata": {
                    "session": {
                        "mouldId": "mould_id",
                        "plyId": "P3",
                        "moduleId": "em-decision-maker"
                    },
                    "groundTruthVersion": "v1.0.0",
                    "mouldId": "mould_id",
                    "bladeSn": "blade_sn",
                    "bladeRevision": "blade_revision",
                    "layers": [
                        "layer_P"
                    ]
                },
                "feedback": [
                    {
                        "type": "plies-to-be-placed",
                        "P3": create_laser_feedback_ply_data("P3")
                    }
                ],
                "feedbackType": "plies-to-be-placed"
            }
            third_ply_covers_next_pallet_plies = {
                "metadata": {
                    "session": {
                        "mouldId": "mould_id",
                        "plyId": "P3",
                        "moduleId": "em-decision-maker"
                    },
                    "groundTruthVersion": "v1.0.0",
                    "mouldId": "mould_id",
                    "bladeSn": "blade_sn",
                    "bladeRevision": "blade_revision",
                    "layers": [
                        "layer_P"
                    ]
                },
                "feedback": [
                    {
                        "type": "plies-to-be-placed",
                        "P3": {"dxf_id": "dxf_id_P",
                               "dxf_ply_id": "dxf_ply_id_P3",
                               "layer_id": "layer_P",
                               "next_plies": [],
                               "next_plies_pallets": [],
                               "pallet_id": "pallet_1",
                               "previous_plies": ["P2", "P4", "P5"]}
                    }
                ],
                "feedbackType": "plies-to-be-placed"
            }
            third_ply_multi_layers = {
                "metadata": {
                    "session": {
                        "mouldId": "mould_id",
                        "plyId": "P3",
                        "moduleId": "em-decision-maker"
                    },
                    "groundTruthVersion": "v1.0.0",
                    "mouldId": "mould_id",
                    "bladeSn": "blade_sn",
                    "bladeRevision": "blade_revision",
                    "layers": [
                        "layer_P",
                        "layer_U"
                    ]
                },
                "feedback": [
                    {
                        "type": "plies-to-be-placed",
                        "P3": create_laser_feedback_ply_data("P3")
                    }
                ],
                "feedbackType": "plies-to-be-placed"
            }

        class SecondPalletP:
            fourth_ply = {
                "metadata": {
                    "session": {
                        "mouldId": "mould_id",
                        "plyId": "P4",
                        "moduleId": "em-decision-maker"
                    },
                    "groundTruthVersion": "v1.0.0",
                    "mouldId": "mould_id",
                    "bladeSn": "blade_sn",
                    "bladeRevision": "blade_revision",
                    "layers": [
                        "layer_P"
                    ]
                },
                "feedback": [
                    {
                        "type": "plies-to-be-placed",
                        "P4": create_laser_feedback_ply_data("P4")
                    }
                ],
                "feedbackType": "plies-to-be-placed"
            }
            fourth_ply_depends_on_second_ply = {
                "metadata": {
                    "session": {
                        "mouldId": "mould_id",
                        "plyId": "P4",
                        "moduleId": "em-decision-maker"
                    },
                    "groundTruthVersion": "v1.0.0",
                    "mouldId": "mould_id",
                    "bladeSn": "blade_sn",
                    "bladeRevision": "blade_revision",
                    "layers": [
                        "layer_P"
                    ]
                },
                "feedback": [{"P4": {"dxf_id": "dxf_id_P",
                                     "dxf_ply_id": "dxf_ply_id_P4",
                                     "layer_id": "layer_P",
                                     "next_plies": ["P5"],
                                     "next_plies_pallets": ["pallet_2"],
                                     "pallet_id": "pallet_2",
                                     "previous_plies": ["P2"]},
                              "type": "plies-to-be-placed"}],
                "feedbackType": "plies-to-be-placed"
            }
            fourth_ply_multi_layers = {
                "metadata": {
                    "session": {
                        "mouldId": "mould_id",
                        "plyId": "P4",
                        "moduleId": "em-decision-maker"
                    },
                    "groundTruthVersion": "v1.0.0",
                    "mouldId": "mould_id",
                    "bladeSn": "blade_sn",
                    "bladeRevision": "blade_revision",
                    "layers": [
                        "layer_P",
                        "layer_U"
                    ]
                },
                "feedback": [
                    {
                        "type": "plies-to-be-placed",
                        "P4": create_laser_feedback_ply_data("P4")
                    }
                ],
                "feedbackType": "plies-to-be-placed"
            }
            fifth_ply = {
                "metadata": {
                    "session": {
                        "mouldId": "mould_id",
                        "plyId": "P5",
                        "moduleId": "em-decision-maker"
                    },
                    "groundTruthVersion": "v1.0.0",
                    "mouldId": "mould_id",
                    "bladeSn": "blade_sn",
                    "bladeRevision": "blade_revision",
                    "layers": [
                        "layer_P"
                    ]
                },
                "feedback": [
                    {
                        "type": "plies-to-be-placed",
                        "P5": create_laser_feedback_ply_data("P5")
                    }
                ],
                "feedbackType": "plies-to-be-placed"
            }
            fifth_ply_multi_layers = {
                "metadata": {
                    "session": {
                        "mouldId": "mould_id",
                        "plyId": "P5",
                        "moduleId": "em-decision-maker"
                    },
                    "groundTruthVersion": "v1.0.0",
                    "mouldId": "mould_id",
                    "bladeSn": "blade_sn",
                    "bladeRevision": "blade_revision",
                    "layers": [
                        "layer_P",
                        "layer_U"
                    ]
                },
                "feedback": [
                    {
                        "type": "plies-to-be-placed",
                        "P5": create_laser_feedback_ply_data("P5")
                    }
                ],
                "feedbackType": "plies-to-be-placed"
            }
            sixth_ply = {
                "metadata": {
                    "session": {
                        "mouldId": "mould_id",
                        "plyId": "P6",
                        "moduleId": "em-decision-maker"
                    },
                    "groundTruthVersion": "v1.0.0",
                    "mouldId": "mould_id",
                    "bladeSn": "blade_sn",
                    "bladeRevision": "blade_revision",
                    "layers": [
                        "layer_P"
                    ]
                },
                "feedback": [
                    {
                        "type": "plies-to-be-placed",
                        "P6": create_laser_feedback_ply_data("P6")
                    }
                ],
                "feedbackType": "plies-to-be-placed"
            }
            sixth_ply_multi_layers = {
                "metadata": {
                    "session": {
                        "mouldId": "mould_id",
                        "plyId": "P6",
                        "moduleId": "em-decision-maker"
                    },
                    "groundTruthVersion": "v1.0.0",
                    "mouldId": "mould_id",
                    "bladeSn": "blade_sn",
                    "bladeRevision": "blade_revision",
                    "layers": [
                        "layer_P",
                        "layer_U"
                    ]
                },
                "feedback": [
                    {
                        "type": "plies-to-be-placed",
                        "P6": create_laser_feedback_ply_data("P6")
                    }
                ],
                "feedbackType": "plies-to-be-placed"
            }

        class ThirdPalletP:
            seventh_ply = {
                "metadata": {
                    "session": {
                        "mouldId": "mould_id",
                        "plyId": "P7",
                        "moduleId": "em-decision-maker"
                    },
                    "groundTruthVersion": "v1.0.0",
                    "mouldId": "mould_id",
                    "bladeSn": "blade_sn",
                    "bladeRevision": "blade_revision",
                    "layers": [
                        "layer_P"
                    ]
                },
                "feedback": [
                    {
                        "type": "plies-to-be-placed",
                        "P7": create_laser_feedback_ply_data("P7")
                    }
                ],
                "feedbackType": "plies-to-be-placed"
            }
            eighth_ply = {
                "metadata": {
                    "session": {
                        "mouldId": "mould_id",
                        "plyId": "P8",
                        "moduleId": "em-decision-maker"
                    },
                    "groundTruthVersion": "v1.0.0",
                    "mouldId": "mould_id",
                    "bladeSn": "blade_sn",
                    "bladeRevision": "blade_revision",
                    "layers": [
                        "layer_P"
                    ]
                },
                "feedback": [
                    {
                        "type": "plies-to-be-placed",
                        "P8": create_laser_feedback_ply_data("P8")
                    }
                ],
                "feedbackType": "plies-to-be-placed"
            }
            eighth_ply_multi_layers = {
                "metadata": {
                    "session": {
                        "mouldId": "mould_id",
                        "plyId": "P8",
                        "moduleId": "em-decision-maker"
                    },
                    "groundTruthVersion": "v1.0.0",
                    "mouldId": "mould_id",
                    "bladeSn": "blade_sn",
                    "bladeRevision": "blade_revision",
                    "layers": [
                        "layer_P",
                        "layer_U"
                    ]
                },
                "feedback": [
                    {
                        "type": "plies-to-be-placed",
                        "P8": create_laser_feedback_ply_data("P8")
                    }
                ],
                "feedbackType": "plies-to-be-placed"
            }
            ninth_ply = {
                "metadata": {
                    "session": {
                        "mouldId": "mould_id",
                        "plyId": "P9",
                        "moduleId": "em-decision-maker"
                    },
                    "groundTruthVersion": "v1.0.0",
                    "mouldId": "mould_id",
                    "bladeSn": "blade_sn",
                    "bladeRevision": "blade_revision",
                    "layers": [
                        "layer_P"
                    ]
                },
                "feedback": [
                    {
                        "type": "plies-to-be-placed",
                        "P9": create_laser_feedback_ply_data("P9")
                    }
                ],
                "feedbackType": "plies-to-be-placed"
            }
            ninth_ply_multi_layers = {
                "metadata": {
                    "session": {
                        "mouldId": "mould_id",
                        "plyId": "P9",
                        "moduleId": "em-decision-maker"
                    },
                    "groundTruthVersion": "v1.0.0",
                    "mouldId": "mould_id",
                    "bladeSn": "blade_sn",
                    "bladeRevision": "blade_revision",
                    "layers": [
                        "layer_P",
                        "layer_U"
                    ]
                },
                "feedback": [
                    {
                        "type": "plies-to-be-placed",
                        "P9": create_laser_feedback_ply_data("P9")
                    }
                ],
                "feedbackType": "plies-to-be-placed"
            }

        class FirstPalletU:
            first_ply = {
                "metadata": {
                    "session": {
                        "mouldId": "mould_id",
                        "plyId": "U1",
                        "moduleId": "em-decision-maker"
                    },
                    "groundTruthVersion": "v1.0.0",
                    "mouldId": "mould_id",
                    "bladeSn": "blade_sn",
                    "bladeRevision": "blade_revision",
                    "layers": [
                        "layer_U"
                    ]
                },
                "feedback": [
                    {
                        "type": "plies-to-be-placed",
                        "U1": create_laser_feedback_ply_data("U1")
                    }
                ],
                "feedbackType": "plies-to-be-placed"
            }
            first_ply_multi_layers = {
                "metadata": {
                    "session": {
                        "mouldId": "mould_id",
                        "plyId": "U1",
                        "moduleId": "em-decision-maker"
                    },
                    "groundTruthVersion": "v1.0.0",
                    "mouldId": "mould_id",
                    "bladeSn": "blade_sn",
                    "bladeRevision": "blade_revision",
                    "layers": [
                        "layer_P",
                        "layer_U"
                    ]
                },
                "feedback": [
                    {
                        "type": "plies-to-be-placed",
                        "U1": create_laser_feedback_ply_data("U1")
                    }
                ],
                "feedbackType": "plies-to-be-placed"
            }
            second_ply = {
                "metadata": {
                    "session": {
                        "mouldId": "mould_id",
                        "plyId": "U2",
                        "moduleId": "em-decision-maker"
                    },
                    "groundTruthVersion": "v1.0.0",
                    "mouldId": "mould_id",
                    "bladeSn": "blade_sn",
                    "bladeRevision": "blade_revision",
                    "layers": [
                        "layer_U"
                    ]
                },
                "feedback": [
                    {
                        "type": "plies-to-be-placed",
                        "U2": create_laser_feedback_ply_data("U2")
                    }
                ],
                "feedbackType": "plies-to-be-placed"
            }
            second_ply_multi_layers = {
                "metadata": {
                    "session": {
                        "mouldId": "mould_id",
                        "plyId": "U2",
                        "moduleId": "em-decision-maker"
                    },
                    "groundTruthVersion": "v1.0.0",
                    "mouldId": "mould_id",
                    "bladeSn": "blade_sn",
                    "bladeRevision": "blade_revision",
                    "layers": [
                        "layer_P",
                        "layer_U"
                    ]
                },
                "feedback": [
                    {
                        "type": "plies-to-be-placed",
                        "U2": create_laser_feedback_ply_data("U2")
                    }
                ],
                "feedbackType": "plies-to-be-placed"
            }
            third_ply = {
                "metadata": {
                    "session": {
                        "mouldId": "mould_id",
                        "plyId": "U3",
                        "moduleId": "em-decision-maker"
                    },
                    "groundTruthVersion": "v1.0.0",
                    "mouldId": "mould_id",
                    "bladeSn": "blade_sn",
                    "bladeRevision": "blade_revision",
                    "layers": [
                        "layer_U"
                    ]
                },
                "feedback": [
                    {
                        "type": "plies-to-be-placed",
                        "U3": create_laser_feedback_ply_data("U3")
                    }
                ],
                "feedbackType": "plies-to-be-placed"
            }
            third_ply_multi_layers = {
                "metadata": {
                    "session": {
                        "mouldId": "mould_id",
                        "plyId": "U3",
                        "moduleId": "em-decision-maker"
                    },
                    "groundTruthVersion": "v1.0.0",
                    "mouldId": "mould_id",
                    "bladeSn": "blade_sn",
                    "bladeRevision": "blade_revision",
                    "layers": [
                        "layer_P",
                        "layer_U"
                    ]
                },
                "feedback": [
                    {
                        "type": "plies-to-be-placed",
                        "U3": create_laser_feedback_ply_data("U3")
                    }
                ],
                "feedbackType": "plies-to-be-placed"
            }
            fourth_ply = {
                "metadata": {
                    "session": {
                        "mouldId": "mould_id",
                        "plyId": "U4",
                        "moduleId": "em-decision-maker"
                    },
                    "groundTruthVersion": "v1.0.0",
                    "mouldId": "mould_id",
                    "bladeSn": "blade_sn",
                    "bladeRevision": "blade_revision",
                    "layers": [
                        "layer_U"
                    ]
                },
                "feedback": [
                    {
                        "type": "plies-to-be-placed",
                        "U4": create_laser_feedback_ply_data("U4")
                    }
                ],
                "feedbackType": "plies-to-be-placed"
            }
            fifth_ply = {
                "metadata": {
                    "session": {
                        "mouldId": "mould_id",
                        "plyId": "U5",
                        "moduleId": "em-decision-maker"
                    },
                    "groundTruthVersion": "v1.0.0",
                    "mouldId": "mould_id",
                    "bladeSn": "blade_sn",
                    "bladeRevision": "blade_revision",
                    "layers": [
                        "layer_U"
                    ]
                },
                "feedback": [
                    {
                        "type": "plies-to-be-placed",
                        "U5": create_laser_feedback_ply_data("U5")
                    }
                ],
                "feedbackType": "plies-to-be-placed"
            }
            sixth_ply = {
                "metadata": {
                    "session": {
                        "mouldId": "mould_id",
                        "plyId": "U6",
                        "moduleId": "em-decision-maker"
                    },
                    "groundTruthVersion": "v1.0.0",
                    "mouldId": "mould_id",
                    "bladeSn": "blade_sn",
                    "bladeRevision": "blade_revision",
                    "layers": [
                        "layer_U"
                    ]
                },
                "feedback": [
                    {
                        "type": "plies-to-be-placed",
                        "U6": create_laser_feedback_ply_data("U6")
                    }
                ],
                "feedbackType": "plies-to-be-placed"
            }
            sixth_ply_multi_layers = {
                "metadata": {
                    "session": {
                        "mouldId": "mould_id",
                        "plyId": "U6",
                        "moduleId": "em-decision-maker"
                    },
                    "groundTruthVersion": "v1.0.0",
                    "mouldId": "mould_id",
                    "bladeSn": "blade_sn",
                    "bladeRevision": "blade_revision",
                    "layers": [
                        "layer_P",
                        "layer_U"
                    ]
                },
                "feedback": [
                    {
                        "type": "plies-to-be-placed",
                        "U6": create_laser_feedback_ply_data("U6")
                    }
                ],
                "feedbackType": "plies-to-be-placed"
            }
            seventh_ply = {
                "metadata": {
                    "session": {
                        "mouldId": "mould_id",
                        "plyId": "U7",
                        "moduleId": "em-decision-maker"
                    },
                    "groundTruthVersion": "v1.0.0",
                    "mouldId": "mould_id",
                    "bladeSn": "blade_sn",
                    "bladeRevision": "blade_revision",
                    "layers": [
                        "layer_U"
                    ]
                },
                "feedback": [
                    {
                        "type": "plies-to-be-placed",
                        "U7": create_laser_feedback_ply_data("U7")
                    }
                ],
                "feedbackType": "plies-to-be-placed"
            }
            seventh_ply_multi_layers = {
                "metadata": {
                    "session": {
                        "mouldId": "mould_id",
                        "plyId": "U7",
                        "moduleId": "em-decision-maker"
                    },
                    "groundTruthVersion": "v1.0.0",
                    "mouldId": "mould_id",
                    "bladeSn": "blade_sn",
                    "bladeRevision": "blade_revision",
                    "layers": [
                        "layer_P",
                        "layer_U"
                    ]
                },
                "feedback": [
                    {
                        "type": "plies-to-be-placed",
                        "U7": create_laser_feedback_ply_data("U7")
                    }
                ],
                "feedbackType": "plies-to-be-placed"
            }

    class PhantomPlies:
        class FirstPalletP:
            first_ply = {
                "metadata": {
                    "session": {
                        "mouldId": "mould_id",
                        "plyId": "P1",
                        "moduleId": "em-decision-maker"
                    },
                    "groundTruthVersion": "v1.0.0",
                    "mouldId": "mould_id",
                    "bladeSn": "blade_sn",
                    "bladeRevision": "blade_revision",
                    "layers": [
                        "layer_P"
                    ]
                },
                "feedback": [
                    {
                        "type": "phantom-plies",
                        "P1": create_laser_feedback_ply_data("P1")
                    }
                ],
                "feedbackType": "phantom-plies"
            }
            second_ply = {
                "metadata": {
                    "session": {
                        "mouldId": "mould_id",
                        "plyId": "P2",
                        "moduleId": "em-decision-maker"
                    },
                    "groundTruthVersion": "v1.0.0",
                    "mouldId": "mould_id",
                    "bladeSn": "blade_sn",
                    "bladeRevision": "blade_revision",
                    "layers": [
                        "layer_P"
                    ]
                },
                "feedback": [
                    {
                        "type": "phantom-plies",
                        "P2": create_laser_feedback_ply_data("P2")
                    }
                ],
                "feedbackType": "phantom-plies"
            }
            third_ply = {
                "metadata": {
                    "session": {
                        "mouldId": "mould_id",
                        "plyId": "P3",
                        "moduleId": "em-decision-maker"
                    },
                    "groundTruthVersion": "v1.0.0",
                    "mouldId": "mould_id",
                    "bladeSn": "blade_sn",
                    "bladeRevision": "blade_revision",
                    "layers": [
                        "layer_P"
                    ]
                },
                "feedback": [
                    {
                        "type": "phantom-plies",
                        "P3": create_laser_feedback_ply_data("P3")
                    }
                ],
                "feedbackType": "phantom-plies"
            }

        class SecondPalletP:
            fourth_ply = {
                "metadata": {
                    "session": {
                        "mouldId": "mould_id",
                        "plyId": "P4",
                        "moduleId": "em-decision-maker"
                    },
                    "groundTruthVersion": "v1.0.0",
                    "mouldId": "mould_id",
                    "bladeSn": "blade_sn",
                    "bladeRevision": "blade_revision",
                    "layers": [
                        "layer_P"
                    ]
                },
                "feedback": [
                    {
                        "type": "phantom-plies",
                        "P4": create_laser_feedback_ply_data("P4")
                    }
                ],
                "feedbackType": "phantom-plies"
            }
            fifth_ply = {
                "metadata": {
                    "session": {
                        "mouldId": "mould_id",
                        "plyId": "P5",
                        "moduleId": "em-decision-maker"
                    },
                    "groundTruthVersion": "v1.0.0",
                    "mouldId": "mould_id",
                    "bladeSn": "blade_sn",
                    "bladeRevision": "blade_revision",
                    "layers": [
                        "layer_P"
                    ]
                },
                "feedback": [
                    {
                        "type": "phantom-plies",
                        "P5": create_laser_feedback_ply_data("P5")
                    }
                ],
                "feedbackType": "phantom-plies"
            }
            sixth_ply = {
                "metadata": {
                    "session": {
                        "mouldId": "mould_id",
                        "plyId": "P6",
                        "moduleId": "em-decision-maker"
                    },
                    "groundTruthVersion": "v1.0.0",
                    "mouldId": "mould_id",
                    "bladeSn": "blade_sn",
                    "bladeRevision": "blade_revision",
                    "layers": [
                        "layer_P"
                    ]
                },
                "feedback": [
                    {
                        "type": "phantom-plies",
                        "P6": create_laser_feedback_ply_data("P6")
                    }
                ],
                "feedbackType": "phantom-plies"
            }

        class ThirdPalletP:
            seventh_ply = {
                "metadata": {
                    "session": {
                        "mouldId": "mould_id",
                        "plyId": "P7",
                        "moduleId": "em-decision-maker"
                    },
                    "groundTruthVersion": "v1.0.0",
                    "mouldId": "mould_id",
                    "bladeSn": "blade_sn",
                    "bladeRevision": "blade_revision",
                    "layers": [
                        "layer_P"
                    ]
                },
                "feedback": [
                    {
                        "type": "phantom-plies",
                        "P7": create_laser_feedback_ply_data("P7")
                    }
                ],
                "feedbackType": "phantom-plies"
            }
            eighth_ply = {
                "metadata": {
                    "session": {
                        "mouldId": "mould_id",
                        "plyId": "P8",
                        "moduleId": "em-decision-maker"
                    },
                    "groundTruthVersion": "v1.0.0",
                    "mouldId": "mould_id",
                    "bladeSn": "blade_sn",
                    "bladeRevision": "blade_revision",
                    "layers": [
                        "layer_P"
                    ]
                },
                "feedback": [
                    {
                        "type": "phantom-plies",
                        "P8": create_laser_feedback_ply_data("P8")
                    }
                ],
                "feedbackType": "phantom-plies"
            }
            ninth_ply = {
                "metadata": {
                    "session": {
                        "mouldId": "mould_id",
                        "plyId": "P9",
                        "moduleId": "em-decision-maker"
                    },
                    "groundTruthVersion": "v1.0.0",
                    "mouldId": "mould_id",
                    "bladeSn": "blade_sn",
                    "bladeRevision": "blade_revision",
                    "layers": [
                        "layer_P"
                    ]
                },
                "feedback": [
                    {
                        "type": "phantom-plies",
                        "P9": create_laser_feedback_ply_data("P9")
                    }
                ],
                "feedbackType": "phantom-plies"
            }

        class FirstPalletU:
            first_ply = {
                "metadata": {
                    "session": {
                        "mouldId": "mould_id",
                        "plyId": "U1",
                        "moduleId": "em-decision-maker"
                    },
                    "groundTruthVersion": "v1.0.0",
                    "mouldId": "mould_id",
                    "bladeSn": "blade_sn",
                    "bladeRevision": "blade_revision",
                    "layers": [
                        "layer_U"
                    ]
                },
                "feedback": [
                    {
                        "type": "phantom-plies",
                        "U1": create_laser_feedback_ply_data("U1")
                    }
                ],
                "feedbackType": "phantom-plies"
            }
            second_ply = {
                "metadata": {
                    "session": {
                        "mouldId": "mould_id",
                        "plyId": "U2",
                        "moduleId": "em-decision-maker"
                    },
                    "groundTruthVersion": "v1.0.0",
                    "mouldId": "mould_id",
                    "bladeSn": "blade_sn",
                    "bladeRevision": "blade_revision",
                    "layers": [
                        "layer_U"
                    ]
                },
                "feedback": [
                    {
                        "type": "phantom-plies",
                        "U2": create_laser_feedback_ply_data("U2")
                    }
                ],
                "feedbackType": "phantom-plies"
            }
            third_ply = {
                "metadata": {
                    "session": {
                        "mouldId": "mould_id",
                        "plyId": "U3",
                        "moduleId": "em-decision-maker"
                    },
                    "groundTruthVersion": "v1.0.0",
                    "mouldId": "mould_id",
                    "bladeSn": "blade_sn",
                    "bladeRevision": "blade_revision",
                    "layers": [
                        "layer_U"
                    ]
                },
                "feedback": [
                    {
                        "type": "phantom-plies",
                        "U3": create_laser_feedback_ply_data("U3")
                    }
                ],
                "feedbackType": "phantom-plies"
            }
            fourth_ply = {
                "metadata": {
                    "session": {
                        "mouldId": "mould_id",
                        "plyId": "U4",
                        "moduleId": "em-decision-maker"
                    },
                    "groundTruthVersion": "v1.0.0",
                    "mouldId": "mould_id",
                    "bladeSn": "blade_sn",
                    "bladeRevision": "blade_revision",
                    "layers": [
                        "layer_U"
                    ]
                },
                "feedback": [
                    {
                        "type": "phantom-plies",
                        "U4": create_laser_feedback_ply_data("U4")
                    }
                ],
                "feedbackType": "phantom-plies"
            }
            fifth_ply = {
                "metadata": {
                    "session": {
                        "mouldId": "mould_id",
                        "plyId": "U5",
                        "moduleId": "em-decision-maker"
                    },
                    "groundTruthVersion": "v1.0.0",
                    "mouldId": "mould_id",
                    "bladeSn": "blade_sn",
                    "bladeRevision": "blade_revision",
                    "layers": [
                        "layer_U"
                    ]
                },
                "feedback": [
                    {
                        "type": "phantom-plies",
                        "U5": create_laser_feedback_ply_data("U5")
                    }
                ],
                "feedbackType": "phantom-plies"
            }
            sixth_ply = {
                "metadata": {
                    "session": {
                        "mouldId": "mould_id",
                        "plyId": "U6",
                        "moduleId": "em-decision-maker"
                    },
                    "groundTruthVersion": "v1.0.0",
                    "mouldId": "mould_id",
                    "bladeSn": "blade_sn",
                    "bladeRevision": "blade_revision",
                    "layers": [
                        "layer_U"
                    ]
                },
                "feedback": [
                    {
                        "type": "phantom-plies",
                        "U6": create_laser_feedback_ply_data("U6")
                    }
                ],
                "feedbackType": "phantom-plies"
            }
            seventh_ply = {
                "metadata": {
                    "session": {
                        "mouldId": "mould_id",
                        "plyId": "U7",
                        "moduleId": "em-decision-maker"
                    },
                    "groundTruthVersion": "v1.0.0",
                    "mouldId": "mould_id",
                    "bladeSn": "blade_sn",
                    "bladeRevision": "blade_revision",
                    "layers": [
                        "layer_U"
                    ]
                },
                "feedback": [
                    {
                        "type": "phantom-plies",
                        "U7": create_laser_feedback_ply_data("U7")
                    }
                ],
                "feedbackType": "phantom-plies"
            }

    class CorrectlyPlacedPlies:
        class FirstPalletP:
            first_ply = {
                "metadata": {
                    "session": {
                        "mouldId": "mould_id",
                        "plyId": "P1",
                        "moduleId": "em-decision-maker"
                    },
                    "groundTruthVersion": "v1.0.0",
                    "mouldId": "mould_id",
                    "bladeSn": "blade_sn",
                    "bladeRevision": "blade_revision",
                    "layers": [
                        "layer_P"
                    ]
                },
                "feedback": [
                    {
                        "type": "correctly-placed-plies",
                        "P1": create_laser_feedback_ply_data("P1")
                    }
                ],
                "feedbackType": "correctly-placed-plies"
            }
            first_ply_multi_layers = {
                "metadata": {
                    "session": {
                        "mouldId": "mould_id",
                        "plyId": "P1",
                        "moduleId": "em-decision-maker"
                    },
                    "groundTruthVersion": "v1.0.0",
                    "mouldId": "mould_id",
                    "bladeSn": "blade_sn",
                    "bladeRevision": "blade_revision",
                    "layers": [
                        "layer_P",
                        "layer_U"
                    ]
                },
                "feedback": [
                    {
                        "type": "correctly-placed-plies",
                        "P1": create_laser_feedback_ply_data("P1")
                    }
                ],
                "feedbackType": "correctly-placed-plies"
            }
            second_ply = {
                "metadata": {
                    "session": {
                        "mouldId": "mould_id",
                        "plyId": "P2",
                        "moduleId": "em-decision-maker"
                    },
                    "groundTruthVersion": "v1.0.0",
                    "mouldId": "mould_id",
                    "bladeSn": "blade_sn",
                    "bladeRevision": "blade_revision",
                    "layers": [
                        "layer_P"
                    ]
                },
                "feedback": [
                    {
                        "type": "correctly-placed-plies",
                        "P2": create_laser_feedback_ply_data("P2")
                    }
                ],
                "feedbackType": "correctly-placed-plies"
            }
            third_ply = {
                "metadata": {
                    "session": {
                        "mouldId": "mould_id",
                        "plyId": "P3",
                        "moduleId": "em-decision-maker"
                    },
                    "groundTruthVersion": "v1.0.0",
                    "mouldId": "mould_id",
                    "bladeSn": "blade_sn",
                    "bladeRevision": "blade_revision",
                    "layers": [
                        "layer_P",
                    ]
                },
                "feedback": [
                    {
                        "type": "correctly-placed-plies",
                        "P3": create_laser_feedback_ply_data("P3")
                    }
                ],
                "feedbackType": "correctly-placed-plies"
            }
            third_ply_covers_next_pallet_plies = {
                "metadata": {
                    "session": {
                        "mouldId": "mould_id",
                        "plyId": "P3",
                        "moduleId": "em-decision-maker"
                    },
                    "groundTruthVersion": "v1.0.0",
                    "mouldId": "mould_id",
                    "bladeSn": "blade_sn",
                    "bladeRevision": "blade_revision",
                    "layers": [
                        "layer_P",
                    ]
                },
                "feedback": [
                    {
                        "type": "correctly-placed-plies",
                        "P3": {"dxf_id": "dxf_id_P",
                               "dxf_ply_id": "dxf_ply_id_P3",
                               "layer_id": "layer_P",
                               "next_plies": [],
                               "next_plies_pallets": [],
                               "pallet_id": "pallet_1",
                               "previous_plies": ["P2", "P4", "P5"]}
                    }
                ],
                "feedbackType": "correctly-placed-plies"
            }
            third_ply_multi_layers = {
                "metadata": {
                    "session": {
                        "mouldId": "mould_id",
                        "plyId": "P3",
                        "moduleId": "em-decision-maker"
                    },
                    "groundTruthVersion": "v1.0.0",
                    "mouldId": "mould_id",
                    "bladeSn": "blade_sn",
                    "bladeRevision": "blade_revision",
                    "layers": [
                        "layer_P",
                        "layer_U"
                    ]
                },
                "feedback": [
                    {
                        "type": "correctly-placed-plies",
                        "P3": create_laser_feedback_ply_data("P3")
                    }
                ],
                "feedbackType": "correctly-placed-plies"
            }

        class SecondPalletP:
            fourth_ply = {
                "metadata": {
                    "session": {
                        "mouldId": "mould_id",
                        "plyId": "P4",
                        "moduleId": "em-decision-maker"
                    },
                    "groundTruthVersion": "v1.0.0",
                    "mouldId": "mould_id",
                    "bladeSn": "blade_sn",
                    "bladeRevision": "blade_revision",
                    "layers": [
                        "layer_P"
                    ]
                },
                "feedback": [
                    {
                        "type": "correctly-placed-plies",
                        "P4": create_laser_feedback_ply_data("P4")
                    }
                ],
                "feedbackType": "correctly-placed-plies"
            }
            fourth_ply_depends_on_second_ply = {
                "metadata": {
                    "session": {
                        "mouldId": "mould_id",
                        "plyId": "P4",
                        "moduleId": "em-decision-maker"
                    },
                    "groundTruthVersion": "v1.0.0",
                    "mouldId": "mould_id",
                    "bladeSn": "blade_sn",
                    "bladeRevision": "blade_revision",
                    "layers": [
                        "layer_P"
                    ]
                },
                "feedback": [{"P4": {"dxf_id": "dxf_id_P",
                                     "dxf_ply_id": "dxf_ply_id_P4",
                                     "layer_id": "layer_P",
                                     "next_plies": ["P5"],
                                     "next_plies_pallets": ["pallet_2"],
                                     "pallet_id": "pallet_2",
                                     "previous_plies": ["P2"]},
                              "type": "correctly-placed-plies"}],
                "feedbackType": "correctly-placed-plies"
            }
            fourth_ply_multi_layers = {
                "metadata": {
                    "session": {
                        "mouldId": "mould_id",
                        "plyId": "P4",
                        "moduleId": "em-decision-maker"
                    },
                    "groundTruthVersion": "v1.0.0",
                    "mouldId": "mould_id",
                    "bladeSn": "blade_sn",
                    "bladeRevision": "blade_revision",
                    "layers": [
                        "layer_P",
                        "layer_U"
                    ]
                },
                "feedback": [
                    {
                        "type": "correctly-placed-plies",
                        "P4": create_laser_feedback_ply_data("P4")
                    }
                ],
                "feedbackType": "correctly-placed-plies"
            }
            fifth_ply = {
                "metadata": {
                    "session": {
                        "mouldId": "mould_id",
                        "plyId": "P5",
                        "moduleId": "em-decision-maker"
                    },
                    "groundTruthVersion": "v1.0.0",
                    "mouldId": "mould_id",
                    "bladeSn": "blade_sn",
                    "bladeRevision": "blade_revision",
                    "layers": [
                        "layer_P"
                    ]
                },
                "feedback": [
                    {
                        "type": "correctly-placed-plies",
                        "P5": create_laser_feedback_ply_data("P5")
                    }
                ],
                "feedbackType": "correctly-placed-plies"
            }
            sixth_ply = {
                "metadata": {
                    "session": {
                        "mouldId": "mould_id",
                        "plyId": "P6",
                        "moduleId": "em-decision-maker"
                    },
                    "groundTruthVersion": "v1.0.0",
                    "mouldId": "mould_id",
                    "bladeSn": "blade_sn",
                    "bladeRevision": "blade_revision",
                    "layers": [
                        "layer_P"
                    ]
                },
                "feedback": [
                    {
                        "type": "correctly-placed-plies",
                        "P6": create_laser_feedback_ply_data("P6")
                    }
                ],
                "feedbackType": "correctly-placed-plies"
            }

        class ThirdPalletP:
            seventh_ply = {
                "metadata": {
                    "session": {
                        "mouldId": "mould_id",
                        "plyId": "P7",
                        "moduleId": "em-decision-maker"
                    },
                    "groundTruthVersion": "v1.0.0",
                    "mouldId": "mould_id",
                    "bladeSn": "blade_sn",
                    "bladeRevision": "blade_revision",
                    "layers": [
                        "layer_P"
                    ]
                },
                "feedback": [
                    {
                        "type": "correctly-placed-plies",
                        "P7": create_laser_feedback_ply_data("P7")
                    }
                ],
                "feedbackType": "correctly-placed-plies"
            }
            eighth_ply = {
                "metadata": {
                    "session": {
                        "mouldId": "mould_id",
                        "plyId": "P8",
                        "moduleId": "em-decision-maker"
                    },
                    "groundTruthVersion": "v1.0.0",
                    "mouldId": "mould_id",
                    "bladeSn": "blade_sn",
                    "bladeRevision": "blade_revision",
                    "layers": [
                        "layer_P"
                    ]
                },
                "feedback": [
                    {
                        "type": "correctly-placed-plies",
                        "P8": create_laser_feedback_ply_data("P8")
                    }
                ],
                "feedbackType": "correctly-placed-plies"
            }
            eighth_ply_multi_layers = {
                "metadata": {
                    "session": {
                        "mouldId": "mould_id",
                        "plyId": "P8",
                        "moduleId": "em-decision-maker"
                    },
                    "groundTruthVersion": "v1.0.0",
                    "mouldId": "mould_id",
                    "bladeSn": "blade_sn",
                    "bladeRevision": "blade_revision",
                    "layers": [
                        "layer_P",
                        "layer_U"
                    ]
                },
                "feedback": [
                    {
                        "type": "correctly-placed-plies",
                        "P8": create_laser_feedback_ply_data("P8")
                    }
                ],
                "feedbackType": "correctly-placed-plies"
            }
            ninth_ply = {
                "metadata": {
                    "session": {
                        "mouldId": "mould_id",
                        "plyId": "P9",
                        "moduleId": "em-decision-maker"
                    },
                    "groundTruthVersion": "v1.0.0",
                    "mouldId": "mould_id",
                    "bladeSn": "blade_sn",
                    "bladeRevision": "blade_revision",
                    "layers": [
                        "layer_P"
                    ]
                },
                "feedback": [
                    {
                        "type": "correctly-placed-plies",
                        "P9": create_laser_feedback_ply_data("P9")
                    }
                ],
                "feedbackType": "correctly-placed-plies"
            }
            ninth_ply_multi_layers = {
                "metadata": {
                    "session": {
                        "mouldId": "mould_id",
                        "plyId": "P9",
                        "moduleId": "em-decision-maker"
                    },
                    "groundTruthVersion": "v1.0.0",
                    "mouldId": "mould_id",
                    "bladeSn": "blade_sn",
                    "bladeRevision": "blade_revision",
                    "layers": [
                        "layer_P",
                        "layer_U"
                    ]
                },
                "feedback": [
                    {
                        "type": "correctly-placed-plies",
                        "P9": create_laser_feedback_ply_data("P9")
                    }
                ],
                "feedbackType": "correctly-placed-plies"
            }

        class FirstPalletU:
            first_ply = {
                "metadata": {
                    "session": {
                        "mouldId": "mould_id",
                        "plyId": "U1",
                        "moduleId": "em-decision-maker"
                    },
                    "groundTruthVersion": "v1.0.0",
                    "mouldId": "mould_id",
                    "bladeSn": "blade_sn",
                    "bladeRevision": "blade_revision",
                    "layers": [
                        "layer_U"
                    ]
                },
                "feedback": [
                    {
                        "type": "correctly-placed-plies",
                        "U1": create_laser_feedback_ply_data("U1")
                    }
                ],
                "feedbackType": "correctly-placed-plies"
            }
            first_ply_multi_layers = {
                "metadata": {
                    "session": {
                        "mouldId": "mould_id",
                        "plyId": "U1",
                        "moduleId": "em-decision-maker"
                    },
                    "groundTruthVersion": "v1.0.0",
                    "mouldId": "mould_id",
                    "bladeSn": "blade_sn",
                    "bladeRevision": "blade_revision",
                    "layers": [
                        "layer_P",
                        "layer_U"
                    ]
                },
                "feedback": [
                    {
                        "type": "correctly-placed-plies",
                        "U1": create_laser_feedback_ply_data("U1")
                    }
                ],
                "feedbackType": "correctly-placed-plies"
            }
            second_ply = {
                "metadata": {
                    "session": {
                        "mouldId": "mould_id",
                        "plyId": "U2",
                        "moduleId": "em-decision-maker"
                    },
                    "groundTruthVersion": "v1.0.0",
                    "mouldId": "mould_id",
                    "bladeSn": "blade_sn",
                    "bladeRevision": "blade_revision",
                    "layers": [
                        "layer_U"
                    ]
                },
                "feedback": [
                    {
                        "type": "correctly-placed-plies",
                        "U2": create_laser_feedback_ply_data("U2")
                    }
                ],
                "feedbackType": "correctly-placed-plies"
            }
            second_ply_multi_layers = {
                "metadata": {
                    "session": {
                        "mouldId": "mould_id",
                        "plyId": "U2",
                        "moduleId": "em-decision-maker"
                    },
                    "groundTruthVersion": "v1.0.0",
                    "mouldId": "mould_id",
                    "bladeSn": "blade_sn",
                    "bladeRevision": "blade_revision",
                    "layers": [
                        "layer_P",
                        "layer_U"
                    ]
                },
                "feedback": [
                    {
                        "type": "correctly-placed-plies",
                        "U2": create_laser_feedback_ply_data("U2")
                    }
                ],
                "feedbackType": "correctly-placed-plies"
            }
            third_ply = {
                "metadata": {
                    "session": {
                        "mouldId": "mould_id",
                        "plyId": "U3",
                        "moduleId": "em-decision-maker"
                    },
                    "groundTruthVersion": "v1.0.0",
                    "mouldId": "mould_id",
                    "bladeSn": "blade_sn",
                    "bladeRevision": "blade_revision",
                    "layers": [
                        "layer_U"
                    ]
                },
                "feedback": [
                    {
                        "type": "correctly-placed-plies",
                        "U3": create_laser_feedback_ply_data("U3")
                    }
                ],
                "feedbackType": "correctly-placed-plies"
            }
            fourth_ply = {
                "metadata": {
                    "session": {
                        "mouldId": "mould_id",
                        "plyId": "U4",
                        "moduleId": "em-decision-maker"
                    },
                    "groundTruthVersion": "v1.0.0",
                    "mouldId": "mould_id",
                    "bladeSn": "blade_sn",
                    "bladeRevision": "blade_revision",
                    "layers": [
                        "layer_U"
                    ]
                },
                "feedback": [
                    {
                        "type": "correctly-placed-plies",
                        "U4": create_laser_feedback_ply_data("U4")
                    }
                ],
                "feedbackType": "correctly-placed-plies"
            }
            fifth_ply = {
                "metadata": {
                    "session": {
                        "mouldId": "mould_id",
                        "plyId": "U5",
                        "moduleId": "em-decision-maker"
                    },
                    "groundTruthVersion": "v1.0.0",
                    "mouldId": "mould_id",
                    "bladeSn": "blade_sn",
                    "bladeRevision": "blade_revision",
                    "layers": [
                        "layer_U"
                    ]
                },
                "feedback": [
                    {
                        "type": "correctly-placed-plies",
                        "U5": create_laser_feedback_ply_data("U5")
                    }
                ],
                "feedbackType": "correctly-placed-plies"
            }
            sixth_ply = {
                "metadata": {
                    "session": {
                        "mouldId": "mould_id",
                        "plyId": "U6",
                        "moduleId": "em-decision-maker"
                    },
                    "groundTruthVersion": "v1.0.0",
                    "mouldId": "mould_id",
                    "bladeSn": "blade_sn",
                    "bladeRevision": "blade_revision",
                    "layers": [
                        "layer_U"
                    ]
                },
                "feedback": [
                    {
                        "type": "correctly-placed-plies",
                        "U6": create_laser_feedback_ply_data("U6")
                    }
                ],
                "feedbackType": "correctly-placed-plies"
            }
            sixth_ply_multi_layers = {
                "metadata": {
                    "session": {
                        "mouldId": "mould_id",
                        "plyId": "U6",
                        "moduleId": "em-decision-maker"
                    },
                    "groundTruthVersion": "v1.0.0",
                    "mouldId": "mould_id",
                    "bladeSn": "blade_sn",
                    "bladeRevision": "blade_revision",
                    "layers": [
                        "layer_P",
                        "layer_U"
                    ]
                },
                "feedback": [
                    {
                        "type": "correctly-placed-plies",
                        "U6": create_laser_feedback_ply_data("U6")
                    }
                ],
                "feedbackType": "correctly-placed-plies"
            }
            seventh_ply = {
                "metadata": {
                    "session": {
                        "mouldId": "mould_id",
                        "plyId": "U7",
                        "moduleId": "em-decision-maker"
                    },
                    "groundTruthVersion": "v1.0.0",
                    "mouldId": "mould_id",
                    "bladeSn": "blade_sn",
                    "bladeRevision": "blade_revision",
                    "layers": [
                        "layer_U"
                    ]
                },
                "feedback": [
                    {
                        "type": "correctly-placed-plies",
                        "U7": create_laser_feedback_ply_data("U7")
                    }
                ],
                "feedbackType": "correctly-placed-plies"
            }

    class LastPliesPlaced:
        class FirstPalletP:
            second_ply = {
                "metadata": {
                    "session": {
                        "mouldId": "mould_id",
                        "plyId": "P2",
                        "moduleId": "em-decision-maker"
                    },
                    "groundTruthVersion": "v1.0.0",
                    "mouldId": "mould_id",
                    "bladeSn": "blade_sn",
                    "bladeRevision": "blade_revision",
                    "layers": [
                        "layer_P"
                    ]
                },
                "feedback": [
                    {
                        "type": "last-plies-placed",
                        "P2": create_laser_feedback_ply_data("P2")
                    }
                ],
                "feedbackType": "last-plies-placed"
            }

            third_ply = {
                "metadata": {
                    "session": {
                        "mouldId": "mould_id",
                        "plyId": "P3",
                        "moduleId": "em-decision-maker"
                    },
                    "groundTruthVersion": "v1.0.0",
                    "mouldId": "mould_id",
                    "bladeSn": "blade_sn",
                    "bladeRevision": "blade_revision",
                    "layers": [
                        "layer_P"
                    ]
                },
                "feedback": [
                    {
                        "type": "last-plies-placed",
                        "P3": create_laser_feedback_ply_data("P3")
                    }
                ],
                "feedbackType": "last-plies-placed"
            }

        class SecondPalletP:
            sixth_ply = {
                "metadata": {
                    "session": {
                        "mouldId": "mould_id",
                        "plyId": "P6",
                        "moduleId": "em-decision-maker"
                    },
                    "groundTruthVersion": "v1.0.0",
                    "mouldId": "mould_id",
                    "bladeSn": "blade_sn",
                    "bladeRevision": "blade_revision",
                    "layers": [
                        "layer_P"
                    ]
                },
                "feedback": [
                    {
                        "type": "last-plies-placed",
                        "P6": create_laser_feedback_ply_data("P6")
                    }
                ],
                "feedbackType": "last-plies-placed"
            }

        class ThirdPalletP:
            ninth_ply = {
                "metadata": {
                    "session": {
                        "mouldId": "mould_id",
                        "plyId": "P9",
                        "moduleId": "em-decision-maker"
                    },
                    "groundTruthVersion": "v1.0.0",
                    "mouldId": "mould_id",
                    "bladeSn": "blade_sn",
                    "bladeRevision": "blade_revision",
                    "layers": [
                        "layer_P"
                    ]
                },
                "feedback": [
                    {
                        "type": "last-plies-placed",
                        "P9": create_laser_feedback_ply_data("P9")
                    }
                ],
                "feedbackType": "last-plies-placed"
            }

        class FirstPalletU:
            seventh_ply = {
                "metadata": {
                    "session": {
                        "mouldId": "mould_id",
                        "plyId": "U7",
                        "moduleId": "em-decision-maker"
                    },
                    "groundTruthVersion": "v1.0.0",
                    "mouldId": "mould_id",
                    "bladeSn": "blade_sn",
                    "bladeRevision": "blade_revision",
                    "layers": [
                        "layer_U"
                    ]
                },
                "feedback": [
                    {
                        "type": "last-plies-placed",
                        "U7": create_laser_feedback_ply_data("U7")
                    }
                ],
                "feedbackType": "last-plies-placed"
            }

            seventh_ply_multi_layers = {
                "metadata": {
                    "session": {
                        "mouldId": "mould_id",
                        "plyId": "U7",
                        "moduleId": "em-decision-maker"
                    },
                    "groundTruthVersion": "v1.0.0",
                    "mouldId": "mould_id",
                    "bladeSn": "blade_sn",
                    "bladeRevision": "blade_revision",
                    "layers": [
                        "layer_P",
                        "layer_U"
                    ]
                },
                "feedback": [
                    {
                        "type": "last-plies-placed",
                        "U7": create_laser_feedback_ply_data("U7")
                    }
                ],
                "feedbackType": "last-plies-placed"
            }

    class MissingPlies:
        class FirstPalletP:
            first_ply = {
                "metadata": {
                    "session": {
                        "mouldId": "mould_id",
                        "plyId": "P1",
                        "moduleId": "em-decision-maker"
                    },
                    "groundTruthVersion": "v1.0.0",
                    "mouldId": "mould_id",
                    "bladeSn": "blade_sn",
                    "bladeRevision": "blade_revision",
                    "layers": [
                        "layer_P"
                    ]
                },
                "feedback": [
                    {
                        "type": "missing-plies",
                        "P1": create_laser_feedback_ply_data("P1")
                    }
                ],
                "feedbackType": "missing-plies"
            }
            second_ply = {
                "metadata": {
                    "session": {
                        "mouldId": "mould_id",
                        "plyId": "P2",
                        "moduleId": "em-decision-maker"
                    },
                    "groundTruthVersion": "v1.0.0",
                    "mouldId": "mould_id",
                    "bladeSn": "blade_sn",
                    "bladeRevision": "blade_revision",
                    "layers": [
                        "layer_P"
                    ]
                },
                "feedback": [
                    {
                        "type": "missing-plies",
                        "P2": create_laser_feedback_ply_data("P2")
                    }
                ],
                "feedbackType": "missing-plies"
            }
            third_ply = {
                "metadata": {
                    "session": {
                        "mouldId": "mould_id",
                        "plyId": "P3",
                        "moduleId": "em-decision-maker"
                    },
                    "groundTruthVersion": "v1.0.0",
                    "mouldId": "mould_id",
                    "bladeSn": "blade_sn",
                    "bladeRevision": "blade_revision",
                    "layers": [
                        "layer_P"
                    ]
                },
                "feedback": [
                    {
                        "type": "missing-plies",
                        "P3": create_laser_feedback_ply_data("P3")
                    }
                ],
                "feedbackType": "missing-plies"
            }

        class SecondPalletP:
            fourth_ply = {
                "metadata": {
                    "session": {
                        "mouldId": "mould_id",
                        "plyId": "P4",
                        "moduleId": "em-decision-maker"
                    },
                    "groundTruthVersion": "v1.0.0",
                    "mouldId": "mould_id",
                    "bladeSn": "blade_sn",
                    "bladeRevision": "blade_revision",
                    "layers": [
                        "layer_P"
                    ]
                },
                "feedback": [
                    {
                        "type": "missing-plies",
                        "P4": create_laser_feedback_ply_data("P4")
                    }
                ],
                "feedbackType": "missing-plies"
            }
            fifth_ply = {
                "metadata": {
                    "session": {
                        "mouldId": "mould_id",
                        "plyId": "P5",
                        "moduleId": "em-decision-maker"
                    },
                    "groundTruthVersion": "v1.0.0",
                    "mouldId": "mould_id",
                    "bladeSn": "blade_sn",
                    "bladeRevision": "blade_revision",
                    "layers": [
                        "layer_P"
                    ]
                },
                "feedback": [
                    {
                        "type": "missing-plies",
                        "P5": create_laser_feedback_ply_data("P5")
                    }
                ],
                "feedbackType": "missing-plies"
            }
            sixth_ply = {
                "metadata": {
                    "session": {
                        "mouldId": "mould_id",
                        "plyId": "P6",
                        "moduleId": "em-decision-maker"
                    },
                    "groundTruthVersion": "v1.0.0",
                    "mouldId": "mould_id",
                    "bladeSn": "blade_sn",
                    "bladeRevision": "blade_revision",
                    "layers": [
                        "layer_P"
                    ]
                },
                "feedback": [
                    {
                        "type": "missing-plies",
                        "P6": create_laser_feedback_ply_data("P6")
                    }
                ],
                "feedbackType": "missing-plies"
            }

        class ThirdPalletP:
            seventh_ply = {
                "metadata": {
                    "session": {
                        "mouldId": "mould_id",
                        "plyId": "P7",
                        "moduleId": "em-decision-maker"
                    },
                    "groundTruthVersion": "v1.0.0",
                    "mouldId": "mould_id",
                    "bladeSn": "blade_sn",
                    "bladeRevision": "blade_revision",
                    "layers": [
                        "layer_P"
                    ]
                },
                "feedback": [
                    {
                        "type": "missing-plies",
                        "P7": create_laser_feedback_ply_data("P7")
                    }
                ],
                "feedbackType": "missing-plies"
            }
            eighth_ply = {
                "metadata": {
                    "session": {
                        "mouldId": "mould_id",
                        "plyId": "P8",
                        "moduleId": "em-decision-maker"
                    },
                    "groundTruthVersion": "v1.0.0",
                    "mouldId": "mould_id",
                    "bladeSn": "blade_sn",
                    "bladeRevision": "blade_revision",
                    "layers": [
                        "layer_P"
                    ]
                },
                "feedback": [
                    {
                        "type": "missing-plies",
                        "P8": create_laser_feedback_ply_data("P8")
                    }
                ],
                "feedbackType": "missing-plies"
            }
            ninth_ply = {
                "metadata": {
                    "session": {
                        "mouldId": "mould_id",
                        "plyId": "P9",
                        "moduleId": "em-decision-maker"
                    },
                    "groundTruthVersion": "v1.0.0",
                    "mouldId": "mould_id",
                    "bladeSn": "blade_sn",
                    "bladeRevision": "blade_revision",
                    "layers": [
                        "layer_P"
                    ]
                },
                "feedback": [
                    {
                        "type": "missing-plies",
                        "P9": create_laser_feedback_ply_data("P9")
                    }
                ],
                "feedbackType": "missing-plies"
            }

        class FirstPalletU:
            first_ply = {
                "metadata": {
                    "session": {
                        "mouldId": "mould_id",
                        "plyId": "U1",
                        "moduleId": "em-decision-maker"
                    },
                    "groundTruthVersion": "v1.0.0",
                    "mouldId": "mould_id",
                    "bladeSn": "blade_sn",
                    "bladeRevision": "blade_revision",
                    "layers": [
                        "layer_U"
                    ]
                },
                "feedback": [
                    {
                        "type": "missing-plies",
                        "U1": create_laser_feedback_ply_data("U1")
                    }
                ],
                "feedbackType": "missing-plies"
            }
            second_ply = {
                "metadata": {
                    "session": {
                        "mouldId": "mould_id",
                        "plyId": "U2",
                        "moduleId": "em-decision-maker"
                    },
                    "groundTruthVersion": "v1.0.0",
                    "mouldId": "mould_id",
                    "bladeSn": "blade_sn",
                    "bladeRevision": "blade_revision",
                    "layers": [
                        "layer_U"
                    ]
                },
                "feedback": [
                    {
                        "type": "missing-plies",
                        "U2": create_laser_feedback_ply_data("U2")
                    }
                ],
                "feedbackType": "missing-plies"
            }
            second_ply_multi_layers = {
                "metadata": {
                    "session": {
                        "mouldId": "mould_id",
                        "plyId": "U2",
                        "moduleId": "em-decision-maker"
                    },
                    "groundTruthVersion": "v1.0.0",
                    "mouldId": "mould_id",
                    "bladeSn": "blade_sn",
                    "bladeRevision": "blade_revision",
                    "layers": [
                        "layer_P",
                        "layer_U"
                    ]
                },
                "feedback": [
                    {
                        "type": "missing-plies",
                        "U2": create_laser_feedback_ply_data("U2")
                    }
                ],
                "feedbackType": "missing-plies"
            }
            third_ply = {
                "metadata": {
                    "session": {
                        "mouldId": "mould_id",
                        "plyId": "U3",
                        "moduleId": "em-decision-maker"
                    },
                    "groundTruthVersion": "v1.0.0",
                    "mouldId": "mould_id",
                    "bladeSn": "blade_sn",
                    "bladeRevision": "blade_revision",
                    "layers": [
                        "layer_U"
                    ]
                },
                "feedback": [
                    {
                        "type": "missing-plies",
                        "U3": create_laser_feedback_ply_data("U3")
                    }
                ],
                "feedbackType": "missing-plies"
            }
            fourth_ply = {
                "metadata": {
                    "session": {
                        "mouldId": "mould_id",
                        "plyId": "U4",
                        "moduleId": "em-decision-maker"
                    },
                    "groundTruthVersion": "v1.0.0",
                    "mouldId": "mould_id",
                    "bladeSn": "blade_sn",
                    "bladeRevision": "blade_revision",
                    "layers": [
                        "layer_U"
                    ]
                },
                "feedback": [
                    {
                        "type": "missing-plies",
                        "U4": create_laser_feedback_ply_data("U4")
                    }
                ],
                "feedbackType": "missing-plies"
            }
            fifth_ply = {
                "metadata": {
                    "session": {
                        "mouldId": "mould_id",
                        "plyId": "U5",
                        "moduleId": "em-decision-maker"
                    },
                    "groundTruthVersion": "v1.0.0",
                    "mouldId": "mould_id",
                    "bladeSn": "blade_sn",
                    "bladeRevision": "blade_revision",
                    "layers": [
                        "layer_U"
                    ]
                },
                "feedback": [
                    {
                        "type": "missing-plies",
                        "U5": create_laser_feedback_ply_data("U5")
                    }
                ],
                "feedbackType": "missing-plies"
            }
            sixth_ply = {
                "metadata": {
                    "session": {
                        "mouldId": "mould_id",
                        "plyId": "U6",
                        "moduleId": "em-decision-maker"
                    },
                    "groundTruthVersion": "v1.0.0",
                    "mouldId": "mould_id",
                    "bladeSn": "blade_sn",
                    "bladeRevision": "blade_revision",
                    "layers": [
                        "layer_U"
                    ]
                },
                "feedback": [
                    {
                        "type": "missing-plies",
                        "U6": create_laser_feedback_ply_data("U6")
                    }
                ],
                "feedbackType": "missing-plies"
            }
            seventh_ply = {
                "metadata": {
                    "session": {
                        "mouldId": "mould_id",
                        "plyId": "U7",
                        "moduleId": "em-decision-maker"
                    },
                    "groundTruthVersion": "v1.0.0",
                    "mouldId": "mould_id",
                    "bladeSn": "blade_sn",
                    "bladeRevision": "blade_revision",
                    "layers": [
                        "layer_U"
                    ]
                },
                "feedback": [
                    {
                        "type": "missing-plies",
                        "U7": create_laser_feedback_ply_data("U7")
                    }
                ],
                "feedbackType": "missing-plies"
            }

    class PliesToNull:
        class FirstPalletP:
            first_ply = {
                "metadata": {
                    "session": {
                        "mouldId": "mould_id",
                        "plyId": "P1",
                        "moduleId": "em-decision-maker"
                    },
                    "groundTruthVersion": "v1.0.0",
                    "mouldId": "mould_id",
                    "bladeSn": "blade_sn",
                    "bladeRevision": "blade_revision",
                    "layers": [
                        "layer_P"
                    ]
                },
                "feedback": [
                    {
                        "type": "plies-to-null",
                        "P1": create_laser_feedback_ply_data("P1")
                    }
                ],
                "feedbackType": "plies-to-null"
            }
            second_ply = {
                "metadata": {
                    "session": {
                        "mouldId": "mould_id",
                        "plyId": "P2",
                        "moduleId": "em-decision-maker"
                    },
                    "groundTruthVersion": "v1.0.0",
                    "mouldId": "mould_id",
                    "bladeSn": "blade_sn",
                    "bladeRevision": "blade_revision",
                    "layers": [
                        "layer_P"
                    ]
                },
                "feedback": [
                    {
                        "type": "plies-to-null",
                        "P2": create_laser_feedback_ply_data("P2")
                    }
                ],
                "feedbackType": "plies-to-null"
            }
            second_ply_multi_layers = {
                "metadata": {
                    "session": {
                        "mouldId": "mould_id",
                        "plyId": "P2",
                        "moduleId": "em-decision-maker"
                    },
                    "groundTruthVersion": "v1.0.0",
                    "mouldId": "mould_id",
                    "bladeSn": "blade_sn",
                    "bladeRevision": "blade_revision",
                    "layers": [
                        "layer_P",
                        "layer_U"
                    ]
                },
                "feedback": [
                    {
                        "type": "plies-to-null",
                        "P2": create_laser_feedback_ply_data("P2")
                    }
                ],
                "feedbackType": "plies-to-null"
            }
            third_ply = {
                "metadata": {
                    "session": {
                        "mouldId": "mould_id",
                        "plyId": "P3",
                        "moduleId": "em-decision-maker"
                    },
                    "groundTruthVersion": "v1.0.0",
                    "mouldId": "mould_id",
                    "bladeSn": "blade_sn",
                    "bladeRevision": "blade_revision",
                    "layers": [
                        "layer_P"
                    ]
                },
                "feedback": [
                    {
                        "type": "plies-to-null",
                        "P3": create_laser_feedback_ply_data("P3")
                    }
                ],
                "feedbackType": "plies-to-null"
            }
            third_ply_covers_next_pallet_plies = {
                "metadata": {
                    "session": {
                        "mouldId": "mould_id",
                        "plyId": "P3",
                        "moduleId": "em-decision-maker"
                    },
                    "groundTruthVersion": "v1.0.0",
                    "mouldId": "mould_id",
                    "bladeSn": "blade_sn",
                    "bladeRevision": "blade_revision",
                    "layers": [
                        "layer_P"
                    ]
                },
                "feedback": [
                    {
                        "type": "plies-to-null",
                        "P3": {"dxf_id": "dxf_id_P",
                               "dxf_ply_id": "dxf_ply_id_P3",
                               "layer_id": "layer_P",
                               "next_plies": [],
                               "next_plies_pallets": [],
                               "pallet_id": "pallet_1",
                               "previous_plies": ["P2", "P4", "P5"]}
                    }
                ],
                "feedbackType": "plies-to-null"
            }

        class SecondPalletP:
            fourth_ply = {
                "metadata": {
                    "session": {
                        "mouldId": "mould_id",
                        "plyId": "P4",
                        "moduleId": "em-decision-maker"
                    },
                    "groundTruthVersion": "v1.0.0",
                    "mouldId": "mould_id",
                    "bladeSn": "blade_sn",
                    "bladeRevision": "blade_revision",
                    "layers": [
                        "layer_P"
                    ]
                },
                "feedback": [
                    {
                        "type": "plies-to-null",
                        "P4": create_laser_feedback_ply_data("P4")
                    }
                ],
                "feedbackType": "plies-to-null"
            }
            fourth_ply_depends_on_second_ply = {
                "metadata": {
                    "session": {
                        "mouldId": "mould_id",
                        "plyId": "P4",
                        "moduleId": "em-decision-maker"
                    },
                    "groundTruthVersion": "v1.0.0",
                    "mouldId": "mould_id",
                    "bladeSn": "blade_sn",
                    "bladeRevision": "blade_revision",
                    "layers": [
                        "layer_P"
                    ]
                },
                "feedback": [{"P4": {"dxf_id": "dxf_id_P",
                                     "dxf_ply_id": "dxf_ply_id_P4",
                                     "layer_id": "layer_P",
                                     "next_plies": ["P5"],
                                     "next_plies_pallets": ["pallet_2"],
                                     "pallet_id": "pallet_2",
                                     "previous_plies": ["P2"]},
                              "type": "plies-to-null"}],
                "feedbackType": "plies-to-null"
            }
            fifth_ply = {
                "metadata": {
                    "session": {
                        "mouldId": "mould_id",
                        "plyId": "P5",
                        "moduleId": "em-decision-maker"
                    },
                    "groundTruthVersion": "v1.0.0",
                    "mouldId": "mould_id",
                    "bladeSn": "blade_sn",
                    "bladeRevision": "blade_revision",
                    "layers": [
                        "layer_P"
                    ]
                },
                "feedback": [
                    {
                        "type": "plies-to-null",
                        "P5": create_laser_feedback_ply_data("P5")
                    }
                ],
                "feedbackType": "plies-to-null"
            }
            sixth_ply = {
                "metadata": {
                    "session": {
                        "mouldId": "mould_id",
                        "plyId": "P6",
                        "moduleId": "em-decision-maker"
                    },
                    "groundTruthVersion": "v1.0.0",
                    "mouldId": "mould_id",
                    "bladeSn": "blade_sn",
                    "bladeRevision": "blade_revision",
                    "layers": [
                        "layer_P"
                    ]
                },
                "feedback": [
                    {
                        "type": "plies-to-null",
                        "P6": create_laser_feedback_ply_data("P6")
                    }
                ],
                "feedbackType": "plies-to-null"
            }

        class ThirdPalletP:
            seventh_ply = {
                "metadata": {
                    "session": {
                        "mouldId": "mould_id",
                        "plyId": "P7",
                        "moduleId": "em-decision-maker"
                    },
                    "groundTruthVersion": "v1.0.0",
                    "mouldId": "mould_id",
                    "bladeSn": "blade_sn",
                    "bladeRevision": "blade_revision",
                    "layers": [
                        "layer_P"
                    ]
                },
                "feedback": [
                    {
                        "type": "plies-to-null",
                        "P7": create_laser_feedback_ply_data("P7")
                    }
                ],
                "feedbackType": "plies-to-null"
            }
            eighth_ply = {
                "metadata": {
                    "session": {
                        "mouldId": "mould_id",
                        "plyId": "P8",
                        "moduleId": "em-decision-maker"
                    },
                    "groundTruthVersion": "v1.0.0",
                    "mouldId": "mould_id",
                    "bladeSn": "blade_sn",
                    "bladeRevision": "blade_revision",
                    "layers": [
                        "layer_P"
                    ]
                },
                "feedback": [
                    {
                        "type": "plies-to-null",
                        "P8": create_laser_feedback_ply_data("P8")
                    }
                ],
                "feedbackType": "plies-to-null"
            }
            ninth_ply = {
                "metadata": {
                    "session": {
                        "mouldId": "mould_id",
                        "plyId": "P9",
                        "moduleId": "em-decision-maker"
                    },
                    "groundTruthVersion": "v1.0.0",
                    "mouldId": "mould_id",
                    "bladeSn": "blade_sn",
                    "bladeRevision": "blade_revision",
                    "layers": [
                        "layer_P"
                    ]
                },
                "feedback": [
                    {
                        "type": "plies-to-null",
                        "P9": create_laser_feedback_ply_data("P9")
                    }
                ],
                "feedbackType": "plies-to-null"
            }

        class FirstPalletU:
            first_ply = {
                "metadata": {
                    "session": {
                        "mouldId": "mould_id",
                        "plyId": "U1",
                        "moduleId": "em-decision-maker"
                    },
                    "groundTruthVersion": "v1.0.0",
                    "mouldId": "mould_id",
                    "bladeSn": "blade_sn",
                    "bladeRevision": "blade_revision",
                    "layers": [
                        "layer_U"
                    ]
                },
                "feedback": [
                    {
                        "type": "plies-to-null",
                        "U1": create_laser_feedback_ply_data("U1")
                    }
                ],
                "feedbackType": "plies-to-null"
            }
            first_ply_multi_layers = {

                "metadata": {
                    "session": {
                        "mouldId": "mould_id",
                        "plyId": "U1",
                        "moduleId": "em-decision-maker"
                    },
                    "groundTruthVersion": "v1.0.0",
                    "mouldId": "mould_id",
                    "bladeSn": "blade_sn",
                    "bladeRevision": "blade_revision",
                    "layers": [
                        "layer_P",
                        "layer_U"
                    ]
                },
                "feedback": [
                    {
                        "type": "plies-to-null",
                        "U1": create_laser_feedback_ply_data("U1")
                    }
                ],
                "feedbackType": "plies-to-null"
            }
            second_ply = {
                "metadata": {
                    "session": {
                        "mouldId": "mould_id",
                        "plyId": "U2",
                        "moduleId": "em-decision-maker"
                    },
                    "groundTruthVersion": "v1.0.0",
                    "mouldId": "mould_id",
                    "bladeSn": "blade_sn",
                    "bladeRevision": "blade_revision",
                    "layers": [
                        "layer_U"
                    ]
                },
                "feedback": [
                    {
                        "type": "plies-to-null",
                        "U2": create_laser_feedback_ply_data("U2")
                    }
                ],
                "feedbackType": "plies-to-null"
            }
            third_ply = {
                "metadata": {
                    "session": {
                        "mouldId": "mould_id",
                        "plyId": "U3",
                        "moduleId": "em-decision-maker"
                    },
                    "groundTruthVersion": "v1.0.0",
                    "mouldId": "mould_id",
                    "bladeSn": "blade_sn",
                    "bladeRevision": "blade_revision",
                    "layers": [
                        "layer_U"
                    ]
                },
                "feedback": [
                    {
                        "type": "plies-to-null",
                        "U3": create_laser_feedback_ply_data("U3")
                    }
                ],
                "feedbackType": "plies-to-null"
            }
            fourth_ply = {
                "metadata": {
                    "session": {
                        "mouldId": "mould_id",
                        "plyId": "U4",
                        "moduleId": "em-decision-maker"
                    },
                    "groundTruthVersion": "v1.0.0",
                    "mouldId": "mould_id",
                    "bladeSn": "blade_sn",
                    "bladeRevision": "blade_revision",
                    "layers": [
                        "layer_U"
                    ]
                },
                "feedback": [
                    {
                        "type": "plies-to-null",
                        "U4": create_laser_feedback_ply_data("U4")
                    }
                ],
                "feedbackType": "plies-to-null"
            }
            fifth_ply = {
                "metadata": {
                    "session": {
                        "mouldId": "mould_id",
                        "plyId": "U5",
                        "moduleId": "em-decision-maker"
                    },
                    "groundTruthVersion": "v1.0.0",
                    "mouldId": "mould_id",
                    "bladeSn": "blade_sn",
                    "bladeRevision": "blade_revision",
                    "layers": [
                        "layer_U"
                    ]
                },
                "feedback": [
                    {
                        "type": "plies-to-null",
                        "U5": create_laser_feedback_ply_data("U5")
                    }
                ],
                "feedbackType": "plies-to-null"
            }
            sixth_ply = {
                "metadata": {
                    "session": {
                        "mouldId": "mould_id",
                        "plyId": "U6",
                        "moduleId": "em-decision-maker"
                    },
                    "groundTruthVersion": "v1.0.0",
                    "mouldId": "mould_id",
                    "bladeSn": "blade_sn",
                    "bladeRevision": "blade_revision",
                    "layers": [
                        "layer_U"
                    ]
                },
                "feedback": [
                    {
                        "type": "plies-to-null",
                        "U6": create_laser_feedback_ply_data("U6")
                    }
                ],
                "feedbackType": "plies-to-null"
            }
            seventh_ply = {
                "metadata": {
                    "session": {
                        "mouldId": "mould_id",
                        "plyId": "U7",
                        "moduleId": "em-decision-maker"
                    },
                    "groundTruthVersion": "v1.0.0",
                    "mouldId": "mould_id",
                    "bladeSn": "blade_sn",
                    "bladeRevision": "blade_revision",
                    "layers": [
                        "layer_U"
                    ]
                },
                "feedback": [
                    {
                        "type": "plies-to-null",
                        "U7": create_laser_feedback_ply_data("U7")
                    }
                ],
                "feedbackType": "plies-to-null"
            }
