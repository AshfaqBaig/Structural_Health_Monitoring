# pylint: disable=protected-access, missing-module-docstring, missing-class-docstring, missing-function-docstring, duplicate-code, line-too-long, too-few-public-methods, no-self-use, too-many-locals, too-many-lines, too-many-lines
import tests.scenarios.mock_data as mock_data
from app.global_mould_state_enum import GlobalMouldState
from tests.scenarios.model.test_scenario_entry import TestScenarioEntry
from tests.scenarios.scenarios_base import add_team_instruction_c2dm_request, etcd_ply_out, etcd_instruction_out, \
    etcd_mould_state_out, etcd_mould_blade_sn_out


class HandleAddTeamInstructionCommandTestScenariosDtos:
    @staticmethod
    def should_set_blade_sn_and_global_state_to_production_when_global_state_in_etcd_empty_and_team_instruction_given():
        entries = [
            TestScenarioEntry(
                input_data=add_team_instruction_c2dm_request(instruction=mock_data.TeamInstructions.pallet_P_1),
                etcd_outputs=[
                    etcd_instruction_out(instruction=mock_data.TeamInstructions.pallet_P_1),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.first_ply_expected_without_invisible_edge),
                    etcd_mould_state_out(state=GlobalMouldState.PRODUCTION),
                    etcd_mould_blade_sn_out(blade_sn="blade_sn"),
                ],
            ),
        ]
        return {
            "entries": entries,
            "initial_mould_state": None,
            "initial_mould_blade_sn": None,
        }

    @staticmethod
    def should_set_blade_sn_and_global_state_to_production_when_global_state_finalised_and_team_instruction_with_new_blade_sn_given():
        entries = [
            TestScenarioEntry(
                input_data=add_team_instruction_c2dm_request(instruction=mock_data.TeamInstructions.pallet_P_1),
                etcd_outputs=[
                    etcd_instruction_out(instruction=mock_data.TeamInstructions.pallet_P_1),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.first_ply_expected_without_invisible_edge),
                    etcd_mould_state_out(state=GlobalMouldState.PRODUCTION),
                    etcd_mould_blade_sn_out(blade_sn="blade_sn"),
                ],
            ),
        ]
        return {
            "entries": entries,
            "initial_mould_state": GlobalMouldState.FINALISED,
            "initial_mould_blade_sn": "finalised_blade_sn",
        }

    @staticmethod
    def should_not_set_blade_sn_nor_global_state_to_production_when_global_state_finalised_and_team_instruction_with_same_blade_sn_given():
        entries = [
            TestScenarioEntry(
                input_data=add_team_instruction_c2dm_request(instruction=mock_data.TeamInstructions.pallet_P_1),
                etcd_outputs=[],
            ),
        ]
        return {
            "entries": entries,
            "initial_mould_state": GlobalMouldState.FINALISED,
            "initial_mould_blade_sn": "blade_sn",
        }
