# pylint: disable=protected-access, missing-module-docstring, missing-class-docstring, missing-function-docstring, duplicate-code, line-too-long, too-few-public-methods, no-self-use, too-many-locals, too-many-lines, too-many-lines
import app.config as cfg
import tests.scenarios.mock_data as mock_data
from app.global_mould_state_enum import GlobalMouldState
from tests.scenarios.model.test_scenario_entry import TestScenarioEntry
from tests.scenarios.scenarios_base import add_team_instruction_c2dm_request, ev_message_in, edge_verification_out, \
    camera_out, laser_out, trace_out, etcd_ply_out, ev_message_session, mould_state_plies_data, etcd_instruction_out, \
    mould_state_instructions_data, instructions_loaded_on_boot, trace_out_metadata, \
    etcd_mould_state_out, etcd_mould_blade_sn_out, stats_out


class EdgeCoveredTestScenariosDtos:
    @staticmethod
    def single_edge_ply_is_partially_covered_when_next_ply_both_edges_detected_at_same_time_and_without_missing_edges_for_covered_ply():
        entries = [
            # on TI C2DM request first ply for pallet_P_1 is expected
            TestScenarioEntry(
                input_data=add_team_instruction_c2dm_request(instruction=mock_data.TeamInstructions.pallet_P_1),
                etcd_outputs=[
                    etcd_instruction_out(instruction=mock_data.TeamInstructions.pallet_P_1),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.first_ply_expected_without_invisible_edge),
                    etcd_mould_state_out(state=GlobalMouldState.PRODUCTION),
                    etcd_mould_blade_sn_out(blade_sn="blade_sn"),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam1": {"missingEdges": ["P1.2"]}},
                    ),
                    camera_out(
                        camera_ids={"cam1"},
                        command="start_capture",
                        refresh_interval=cfg.ACTIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_P": {"pallets": {"pallet_1": {"missingPlies": 0,
                                                                                       "placedPlies": 0,
                                                                                       "totalPlies": 3}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_P_1
                        ]),
                        "correctlyPlacedPlies": {},
                        "pliesToBePlaced": {
                            **mock_data.StaticGraph.FirstPalletP.first_ply_invisible_edge_removed,
                        },
                        "newMissingPlies": {},
                        "noLongerMissingPlies": {},
                        "forcedPlies": {},
                        "removedPlies": {}
                    }),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.FirstPalletP.first_ply),
                ]
            ),
            # on EV msg first ply is detected, second ply is expected
            TestScenarioEntry(
                input_data=ev_message_in(
                    camera_id="cam1",
                    detected_edges={"P1.2"},
                    missing_edges=set()
                ),
                etcd_outputs=[
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.first_ply_placed_without_invisible_edge),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.second_ply_expected),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam1": {"detectedEdges": ["P1.2"], "missingEdges": ["P2.1"]},
                        "cam2": {"missingEdges": ["P2.1", "P2.2"]}},
                        session_cam_id="cam1"
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_P": {"pallets": {"pallet_1": {"missingPlies": 0,
                                                                                       "placedPlies": 1,
                                                                                       "totalPlies": 3}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_P_1
                        ],
                            session=ev_message_session("cam1")
                        ),
                        "correctlyPlacedPlies": {
                            **mock_data.StaticGraph.FirstPalletP.first_ply_invisible_edge_removed,
                        },
                        "pliesToBePlaced": {
                            **mock_data.StaticGraph.FirstPalletP.second_ply,
                        },
                        "newMissingPlies": {},
                        "noLongerMissingPlies": {},
                        "forcedPlies": {},
                        "removedPlies": {}
                    }),
                    laser_out(payload=mock_data.LaserFeedbacks.CorrectlyPlacedPlies.FirstPalletP.first_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.FirstPalletP.second_ply),
                    camera_out(
                        camera_ids={"cam1", "cam2"},
                        command="start_capture",
                        refresh_interval=cfg.ACTIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                ]
            ),
            # on EV msg second ply is detected, first ply partially covered, third ply is expected
            TestScenarioEntry(
                input_data=ev_message_in(
                    camera_id="cam2",
                    detected_edges={"P2.1", "P2.2"},
                    missing_edges=set()
                ),
                etcd_outputs=[
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.first_ply_covered_without_invisible_edge),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.second_ply_placed),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.third_ply_expected),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam1": {"detectedEdges": ["P2.1"]},
                        "cam2": {"detectedEdges": ["P2.1", "P2.2"], "missingEdges": ["P3.1"]},
                        "cam3": {"missingEdges": ["P3.2"]}},
                        session_cam_id="cam2"
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_P": {"pallets": {"pallet_1": {"missingPlies": 0,
                                                                                       "placedPlies": 2,
                                                                                       "totalPlies": 3}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_P_1
                        ],
                            session=ev_message_session("cam2")
                        ),
                        "correctlyPlacedPlies": {
                            **mock_data.StaticGraph.FirstPalletP.second_ply,
                        },
                        "pliesToBePlaced": {
                            **mock_data.StaticGraph.FirstPalletP.third_ply,
                        },
                        "newMissingPlies": {},
                        "noLongerMissingPlies": {},
                        "forcedPlies": {},
                        "removedPlies": {}
                    }),
                    laser_out(payload=mock_data.LaserFeedbacks.CorrectlyPlacedPlies.FirstPalletP.second_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.FirstPalletP.third_ply),
                    camera_out(
                        camera_ids={"cam1"},
                        command="start_capture",
                        refresh_interval=cfg.PASSIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                    camera_out(
                        camera_ids={"cam2", "cam3"},
                        command="start_capture",
                        refresh_interval=cfg.ACTIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                ]
            ),
        ]
        return {
            "entries": entries,
        }

    @staticmethod
    def ply_is_partially_covered_when_next_ply_both_edges_detected_at_same_time_and_without_missing_edges_for_covered_ply():
        entries = [
            # on TI C2DM request third ply for pallet_P_2 is expected
            TestScenarioEntry(
                input_data=add_team_instruction_c2dm_request(instruction=mock_data.TeamInstructions.pallet_P_2),
                etcd_outputs=[
                    etcd_instruction_out(instruction=mock_data.TeamInstructions.pallet_P_2),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.fourth_ply_expected),
                    etcd_mould_state_out(state=GlobalMouldState.PRODUCTION),
                    etcd_mould_blade_sn_out(blade_sn="blade_sn"),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam3": {"missingEdges": ["P4.1", "P4.2"]},
                        "cam4": {"missingEdges": ["P4.2"]}},
                    ),
                    camera_out(
                        camera_ids={"cam3", "cam4"},
                        command="start_capture",
                        refresh_interval=cfg.ACTIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_P": {"pallets": {"pallet_2": {"missingPlies": 0,
                                                                                       "placedPlies": 0,
                                                                                       "totalPlies": 3}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_P_2,
                        ]),
                        "correctlyPlacedPlies": {},
                        "pliesToBePlaced": {
                            **mock_data.StaticGraph.SecondPalletP.fourth_ply,
                        },
                        "newMissingPlies": {},
                        "noLongerMissingPlies": {},
                        "forcedPlies": {},
                        "removedPlies": {}
                    }),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.SecondPalletP.fourth_ply),
                ]
            ),
            # on EV msg fourth ply is detected, fifth ply is expected
            TestScenarioEntry(
                input_data=ev_message_in(
                    camera_id="cam3",
                    detected_edges={"P4.1", "P4.2"},
                    missing_edges=set()
                ),
                etcd_outputs=[
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.fourth_ply_placed),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.fifth_ply_expected),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam3": {"detectedEdges": ["P4.1", "P4.2"]},
                        "cam4": {"detectedEdges": ["P4.2"],
                                 "missingEdges": ["P5.1", "P5.2"]}},
                        session_cam_id="cam3"
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_P": {"pallets": {"pallet_2": {"missingPlies": 0,
                                                                                       "placedPlies": 1,
                                                                                       "totalPlies": 3}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_P_2,
                        ],
                            session=ev_message_session("cam3")
                        ),
                        "correctlyPlacedPlies": {
                            **mock_data.StaticGraph.SecondPalletP.fourth_ply,
                        },
                        "pliesToBePlaced": {
                            **mock_data.StaticGraph.SecondPalletP.fifth_ply,
                        },
                        "newMissingPlies": {},
                        "noLongerMissingPlies": {},
                        "forcedPlies": {},
                        "removedPlies": {}
                    }),
                    laser_out(payload=mock_data.LaserFeedbacks.CorrectlyPlacedPlies.SecondPalletP.fourth_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.SecondPalletP.fifth_ply),
                    camera_out(
                        camera_ids={"cam3"},
                        command="start_capture",
                        refresh_interval=cfg.PASSIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                    camera_out(
                        camera_ids={"cam4"},
                        command="start_capture",
                        refresh_interval=cfg.ACTIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                ]
            ),
            # on EV msg fifth ply is detected, fourth ply partially covered, sixth ply is expected
            TestScenarioEntry(
                input_data=ev_message_in(
                    camera_id="cam4",
                    detected_edges={"P5.1", "P5.2"},
                    missing_edges=set()
                ),
                etcd_outputs=[
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.fourth_ply_partially_covered),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.fifth_ply_placed),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.sixth_ply_expected),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam3": {"detectedEdges": ["P4.1"]},
                        "cam4": {"detectedEdges": ["P5.1", "P5.2"], "missingEdges": ["P6.1"]},
                        "cam5": {"missingEdges": ["P6.1", "P6.2"]}},
                        session_cam_id="cam4"
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_P": {"pallets": {"pallet_2": {"missingPlies": 0,
                                                                                       "placedPlies": 2,
                                                                                       "totalPlies": 3}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_P_2,
                        ],
                            session=ev_message_session("cam4")
                        ),
                        "correctlyPlacedPlies": {
                            **mock_data.StaticGraph.SecondPalletP.fifth_ply,
                        },
                        "pliesToBePlaced": {
                            **mock_data.StaticGraph.SecondPalletP.sixth_ply,
                        },
                        "newMissingPlies": {},
                        "noLongerMissingPlies": {},
                        "forcedPlies": {},
                        "removedPlies": {}
                    }),
                    laser_out(payload=mock_data.LaserFeedbacks.CorrectlyPlacedPlies.SecondPalletP.fifth_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.SecondPalletP.sixth_ply),
                    camera_out(
                        camera_ids={"cam3"},
                        command="start_capture",
                        refresh_interval=cfg.PASSIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                    camera_out(
                        camera_ids={"cam4", "cam5"},
                        command="start_capture",
                        refresh_interval=cfg.ACTIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                ]
            ),
        ]
        return {
            "entries": entries,
        }

    # partially missing edge have two cam states, only one is missing edge
    @staticmethod
    def ply_is_partially_covered_when_next_ply_both_edges_detected_at_same_time_and_partially_missing_edge_for_covered_ply_by_same_cam():
        entries = [
            TestScenarioEntry(
                input_data=add_team_instruction_c2dm_request(instruction=mock_data.TeamInstructions.pallet_P_2),
                etcd_outputs=[
                    etcd_instruction_out(instruction=mock_data.TeamInstructions.pallet_P_2),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.fourth_ply_expected),
                    etcd_mould_state_out(state=GlobalMouldState.PRODUCTION),
                    etcd_mould_blade_sn_out(blade_sn="blade_sn"),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam3": {"missingEdges": ["P4.1", "P4.2"]},
                        "cam4": {"missingEdges": ["P4.2"]}},
                    ),
                    camera_out(
                        camera_ids={"cam3", "cam4"},
                        command="start_capture",
                        refresh_interval=cfg.ACTIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_P": {"pallets": {"pallet_2": {"missingPlies": 0,
                                                                                       "placedPlies": 0,
                                                                                       "totalPlies": 3}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_P_2,
                        ]),
                        "correctlyPlacedPlies": {},
                        "pliesToBePlaced": {
                            **mock_data.StaticGraph.SecondPalletP.fourth_ply,
                        },
                        "newMissingPlies": {},
                        "noLongerMissingPlies": {},
                        "forcedPlies": {},
                        "removedPlies": {}
                    }),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.SecondPalletP.fourth_ply),
                ]
            ),
            TestScenarioEntry(
                input_data=ev_message_in(
                    camera_id="cam3",
                    detected_edges={"P4.1", "P4.2"},
                    missing_edges=set()
                ),
                etcd_outputs=[
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.fourth_ply_placed),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.fifth_ply_expected),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam3": {"detectedEdges": ["P4.1", "P4.2"]},
                        "cam4": {"detectedEdges": ["P4.2"],
                                 "missingEdges": ["P5.1", "P5.2"]}},
                        session_cam_id="cam3"
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_P": {"pallets": {"pallet_2": {"missingPlies": 0,
                                                                                       "placedPlies": 1,
                                                                                       "totalPlies": 3}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_P_2,
                        ],
                            session=ev_message_session("cam3")
                        ),
                        "correctlyPlacedPlies": {
                            **mock_data.StaticGraph.SecondPalletP.fourth_ply,
                        },
                        "pliesToBePlaced": {
                            **mock_data.StaticGraph.SecondPalletP.fifth_ply,
                        },
                        "newMissingPlies": {},
                        "noLongerMissingPlies": {},
                        "forcedPlies": {},
                        "removedPlies": {}
                    }),
                    laser_out(payload=mock_data.LaserFeedbacks.CorrectlyPlacedPlies.SecondPalletP.fourth_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.SecondPalletP.fifth_ply),
                    camera_out(
                        camera_ids={"cam3"},
                        command="start_capture",
                        refresh_interval=cfg.PASSIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                    camera_out(
                        camera_ids={"cam4"},
                        command="start_capture",
                        refresh_interval=cfg.ACTIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                ]
            ),
            TestScenarioEntry(
                input_data=ev_message_in(
                    camera_id="cam4",
                    detected_edges={"P5.1", "P5.2"},
                    missing_edges={"P4.2"}
                ),
                etcd_outputs=[
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.fourth_ply_partially_covered),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.fifth_ply_placed),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.sixth_ply_expected),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam3": {"detectedEdges": ["P4.1"]},
                        "cam4": {"detectedEdges": ["P5.1", "P5.2"], "missingEdges": ["P6.1"]},
                        "cam5": {"missingEdges": ["P6.1", "P6.2"]}},
                        session_cam_id="cam4"
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_P": {"pallets": {"pallet_2": {"missingPlies": 0,
                                                                                       "placedPlies": 2,
                                                                                       "totalPlies": 3}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_P_2,
                        ],
                            session=ev_message_session("cam4")
                        ),
                        "correctlyPlacedPlies": {
                            **mock_data.StaticGraph.SecondPalletP.fifth_ply,
                        },
                        "pliesToBePlaced": {
                            **mock_data.StaticGraph.SecondPalletP.sixth_ply,
                        },
                        "newMissingPlies": {},
                        "noLongerMissingPlies": {},
                        "forcedPlies": {},
                        "removedPlies": {}
                    }),
                    laser_out(payload=mock_data.LaserFeedbacks.CorrectlyPlacedPlies.SecondPalletP.fifth_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.SecondPalletP.sixth_ply),
                    camera_out(
                        camera_ids={"cam3"},
                        command="start_capture",
                        refresh_interval=cfg.PASSIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                    camera_out(
                        camera_ids={"cam4", "cam5"},
                        command="start_capture",
                        refresh_interval=cfg.ACTIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                ]
            ),
        ]
        return {
            "entries": entries,
        }

    # missing edge has only single cam state
    @staticmethod
    def ply_is_partially_covered_when_next_ply_both_edges_detected_at_same_time_and_missing_edge_for_covered_ply_by_same_cam():
        entries = [
            # 1 On DM boot team instructions are preloaded from ETCD store, no input data
            TestScenarioEntry(
                input_data=instructions_loaded_on_boot(),
                etcd_outputs=[],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam1": {"detectedEdges": ["P2.1"]},
                        "cam2": {"detectedEdges": ["P2.1", "P3.1"]},
                        "cam3": {"detectedEdges": ["P4.1"]},
                        "cam4": {"detectedEdges": ["P5.1", "P6.1"]},
                        "cam5": {"detectedEdges": ["P6.1", "P6.2"]}},
                    ),
                    camera_out(
                        camera_ids={"cam1", "cam2", "cam3", "cam4", "cam5"},
                        command="start_capture",
                        refresh_interval=cfg.PASSIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_P": {"pallets": {"pallet_1": {"missingPlies": 0,
                                                                                       "placedPlies": 3,
                                                                                       "totalPlies": 3},
                                                                          "pallet_2": {"missingPlies": 0,
                                                                                       "placedPlies": 3,
                                                                                       "totalPlies": 3}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_P_1,
                            mock_data.TeamInstructions.pallet_P_2
                        ]),
                        "correctlyPlacedPlies": {},
                        "pliesToBePlaced": {},
                        "newMissingPlies": {},
                        "noLongerMissingPlies": {},
                        "forcedPlies": {},
                        "removedPlies": {}
                    }),
                ]
            ),
            TestScenarioEntry(
                input_data=add_team_instruction_c2dm_request(mock_data.TeamInstructions.pallet_P_3),
                etcd_outputs=[
                    etcd_instruction_out(instruction=mock_data.TeamInstructions.pallet_P_3),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.seventh_ply_expected),
                    etcd_mould_state_out(state=GlobalMouldState.PRODUCTION),
                    etcd_mould_blade_sn_out(blade_sn="blade_sn"),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam1": {"detectedEdges": ["P2.1"]},
                        "cam2": {"detectedEdges": ["P2.1", "P3.1"]},
                        "cam3": {"detectedEdges": ["P4.1"]},
                        "cam4": {"detectedEdges": ["P5.1", "P6.1"]},
                        "cam5": {"detectedEdges": ["P6.1", "P6.2"], "missingEdges": ["P7.1", "P7.2"]},
                        "cam6": {"missingEdges": ["P7.2"]}},
                    ),
                    camera_out(
                        camera_ids={"cam1", "cam2", "cam3", "cam4"},
                        command="start_capture",
                        refresh_interval=cfg.PASSIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                    camera_out(
                        camera_ids={"cam5", "cam6"},
                        command="start_capture",
                        refresh_interval=cfg.ACTIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_P": {"pallets": {"pallet_1": {"missingPlies": 0,
                                                                                       "placedPlies": 3,
                                                                                       "totalPlies": 3},
                                                                          "pallet_2": {"missingPlies": 0,
                                                                                       "placedPlies": 3,
                                                                                       "totalPlies": 3},
                                                                          "pallet_3": {"missingPlies": 0,
                                                                                       "placedPlies": 0,
                                                                                       "totalPlies": 3}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_P_1,
                            mock_data.TeamInstructions.pallet_P_2,
                            mock_data.TeamInstructions.pallet_P_3,
                        ]),
                        "correctlyPlacedPlies": {},
                        "pliesToBePlaced": {
                            **mock_data.StaticGraph.ThirdPalletP.seventh_ply,
                        },
                        "newMissingPlies": {},
                        "noLongerMissingPlies": {},
                        "forcedPlies": {},
                        "removedPlies": {}
                    }),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.ThirdPalletP.seventh_ply),
                ]
            ),
            TestScenarioEntry(
                input_data=ev_message_in(
                    camera_id="cam5",
                    # TODO: how come P6 stays "previous_state": "EXPECTED" if no P6.1 is sent as detected?
                    #  but with "P6.1" detected it previous state changes two times, from expected to missing, to placed
                    #  We probably want to fix this to avoid temporal ply state missing in case "P6.2" is sent.
                    detected_edges={"P6.1", "P7.1", "P7.2"},
                    missing_edges={"P6.2"}
                ),
                etcd_outputs=[
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.sixth_ply_partially_covered),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.seventh_ply_placed),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.eighth_ply_expected),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam1": {"detectedEdges": ["P2.1"]},
                        "cam2": {"detectedEdges": ["P2.1", "P3.1"]},
                        "cam3": {"detectedEdges": ["P4.1"]},
                        "cam4": {"detectedEdges": ["P5.1", "P6.1"]},
                        "cam5": {"detectedEdges": ["P6.1", "P7.1", "P7.2"]},
                        "cam6": {"detectedEdges": ["P7.2"], "missingEdges": ["P8.1", "P8.2"]}},
                        session_cam_id="cam5"
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_P": {"pallets": {"pallet_1": {"missingPlies": 0,
                                                                                       "placedPlies": 3,
                                                                                       "totalPlies": 3},
                                                                          "pallet_2": {"missingPlies": 0,
                                                                                       "placedPlies": 3,
                                                                                       "totalPlies": 3},
                                                                          "pallet_3": {"missingPlies": 0,
                                                                                       "placedPlies": 1,
                                                                                       "totalPlies": 3}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_P_1,
                            mock_data.TeamInstructions.pallet_P_2,
                            mock_data.TeamInstructions.pallet_P_3,
                        ],
                            session=ev_message_session("cam5")
                        ),
                        "correctlyPlacedPlies": {
                            **mock_data.StaticGraph.ThirdPalletP.seventh_ply,
                        },
                        "pliesToBePlaced": {
                            **mock_data.StaticGraph.ThirdPalletP.eighth_ply,
                        },
                        "newMissingPlies": {},
                        # TODO: should we fix redundant ply nulling when ply state changes two times on ev message?
                        "noLongerMissingPlies": {
                            **mock_data.StaticGraph.SecondPalletP.sixth_ply,
                        },
                        "forcedPlies": {},
                        "removedPlies": {}
                    }),
                    laser_out(payload=mock_data.LaserFeedbacks.CorrectlyPlacedPlies.ThirdPalletP.seventh_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.ThirdPalletP.eighth_ply),
                    # TODO: should we fix redundant ply nulling when ply state changes two times on ev message?
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToNull.SecondPalletP.sixth_ply),
                    camera_out(
                        camera_ids={"cam1", "cam2", "cam3", "cam4", "cam5"},
                        command="start_capture",
                        refresh_interval=cfg.PASSIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                    camera_out(
                        camera_ids={"cam6"},
                        command="start_capture",
                        refresh_interval=cfg.ACTIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                ]
            ),
            TestScenarioEntry(
                input_data=ev_message_in(
                    camera_id="cam5",
                    detected_edges={"P6.1", "P7.1", "P7.2"},
                    missing_edges=set()
                ),
                etcd_outputs=[],
                messaging_outputs=[]
            ),
        ]
        return {
            "entries": entries,
            "initial_mould_state_plies_data": mould_state_plies_data([
                mock_data.MouldStatePlies.PalletP.first_ply_covered_without_invisible_edge,
                mock_data.MouldStatePlies.PalletP.second_ply_partially_covered,
                mock_data.MouldStatePlies.PalletP.third_ply_partially_covered,
                mock_data.MouldStatePlies.PalletP.fourth_ply_partially_covered,
                mock_data.MouldStatePlies.PalletP.fifth_ply_partially_covered,
                mock_data.MouldStatePlies.PalletP.sixth_ply_placed,
            ]),
            "initial_mould_state_instructions_data": mould_state_instructions_data([
                mock_data.TeamInstructions.pallet_P_1,
                mock_data.TeamInstructions.pallet_P_2,
            ]),
            "initial_mould_state": GlobalMouldState.PRODUCTION,
            "initial_mould_blade_sn": "blade_sn",
        }

    @staticmethod
    def ply_is_partially_covered_when_next_ply_both_edges_detected_at_same_time_and_one_of_cam_states_missing_for_covered_ply_edge_by_same_cam():
        entries = [
            TestScenarioEntry(
                input_data=add_team_instruction_c2dm_request(instruction=mock_data.TeamInstructions.pallet_P_2),
                etcd_outputs=[
                    etcd_instruction_out(instruction=mock_data.TeamInstructions.pallet_P_2),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.fourth_ply_expected),
                    etcd_mould_state_out(state=GlobalMouldState.PRODUCTION),
                    etcd_mould_blade_sn_out(blade_sn="blade_sn"),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam3": {"missingEdges": ["P4.1", "P4.2"]},
                        "cam4": {"missingEdges": ["P4.2"]}},
                    ),
                    camera_out(
                        camera_ids={"cam3", "cam4"},
                        command="start_capture",
                        refresh_interval=cfg.ACTIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_P": {"pallets": {"pallet_2": {"missingPlies": 0,
                                                                                       "placedPlies": 0,
                                                                                       "totalPlies": 3}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_P_2,
                        ]),
                        "correctlyPlacedPlies": {},
                        "pliesToBePlaced": {
                            **mock_data.StaticGraph.SecondPalletP.fourth_ply,
                        },
                        "newMissingPlies": {},
                        "noLongerMissingPlies": {},
                        "forcedPlies": {},
                        "removedPlies": {}
                    }),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.SecondPalletP.fourth_ply),
                ]
            ),
            TestScenarioEntry(
                input_data=ev_message_in(
                    camera_id="cam3",
                    detected_edges={"P4.1", "P4.2"},
                    missing_edges=set()
                ),
                etcd_outputs=[
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.fourth_ply_placed),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.fifth_ply_expected),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam3": {"detectedEdges": ["P4.1", "P4.2"]},
                        "cam4": {"detectedEdges": ["P4.2"],
                                 "missingEdges": ["P5.1", "P5.2"]}},
                        session_cam_id="cam3"
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_P": {"pallets": {"pallet_2": {"missingPlies": 0,
                                                                                       "placedPlies": 1,
                                                                                       "totalPlies": 3}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_P_2,
                        ],
                            session=ev_message_session("cam3")
                        ),
                        "correctlyPlacedPlies": {
                            **mock_data.StaticGraph.SecondPalletP.fourth_ply,
                        },
                        "pliesToBePlaced": {
                            **mock_data.StaticGraph.SecondPalletP.fifth_ply,
                        },
                        "newMissingPlies": {},
                        "noLongerMissingPlies": {},
                        "forcedPlies": {},
                        "removedPlies": {}
                    }),
                    laser_out(payload=mock_data.LaserFeedbacks.CorrectlyPlacedPlies.SecondPalletP.fourth_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.SecondPalletP.fifth_ply),
                    camera_out(
                        camera_ids={"cam3"},
                        command="start_capture",
                        refresh_interval=cfg.PASSIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                    camera_out(
                        camera_ids={"cam4"},
                        command="start_capture",
                        refresh_interval=cfg.ACTIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                ]
            ),
            # on EV msg fourth ply edge is detected by other cam;
            # fifth ply is still expected
            # TODO: ask Grigori, if we want to update etcd when only cam state changed? because on this EV input
            #  mould state actually changed, but we ignore when comes to send to etcd
            TestScenarioEntry(
                input_data=ev_message_in(
                    camera_id="cam4",
                    # NOTE: this edge is detected first time by cam4 so it should send update to etcd?
                    detected_edges={"P4.2"},
                    missing_edges=set()
                ),
                etcd_outputs=[],
                messaging_outputs=[]
            ),
            # on EV msg fourth ply edge is detected by other cam;
            # fifth ply is still expected
            TestScenarioEntry(
                input_data=ev_message_in(
                    camera_id="cam4",
                    detected_edges={"P4.2"},
                    missing_edges={"P5.1", "P5.2"}
                ),
                etcd_outputs=[],
                messaging_outputs=[]
            ),
            # on EV msg fifth ply is detected;
            # fourth ply partially covered with missing edge because for it is not first EV message from cam4 for "P4.2"
            # sixth ply is expected
            TestScenarioEntry(
                input_data=ev_message_in(
                    camera_id="cam4",
                    detected_edges={"P5.1", "P5.2"},
                    missing_edges={"P4.2"}
                ),
                etcd_outputs=[
                    etcd_ply_out(
                        ply=mock_data.MouldStatePlies.PalletP.fourth_ply_partially_covered_with_missing_edge_by_cam4),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.fifth_ply_placed),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.sixth_ply_expected),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam3": {"detectedEdges": ["P4.1"]},
                        "cam4": {"detectedEdges": ["P5.1", "P5.2"], "missingEdges": ["P6.1"]},
                        "cam5": {"missingEdges": ["P6.1", "P6.2"]}},
                        session_cam_id="cam4"
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_P": {"pallets": {"pallet_2": {"missingPlies": 0,
                                                                                       "placedPlies": 2,
                                                                                       "totalPlies": 3}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_P_2,
                        ],
                            session=ev_message_session("cam4")
                        ),
                        "correctlyPlacedPlies": {
                            **mock_data.StaticGraph.SecondPalletP.fifth_ply,
                        },
                        "pliesToBePlaced": {
                            **mock_data.StaticGraph.SecondPalletP.sixth_ply,
                        },
                        "newMissingPlies": {},
                        "noLongerMissingPlies": {},
                        "forcedPlies": {},
                        "removedPlies": {}
                    }),
                    laser_out(payload=mock_data.LaserFeedbacks.CorrectlyPlacedPlies.SecondPalletP.fifth_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.SecondPalletP.sixth_ply),
                    camera_out(
                        camera_ids={"cam3"},
                        command="start_capture",
                        refresh_interval=cfg.PASSIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                    camera_out(
                        camera_ids={"cam4", "cam5"},
                        command="start_capture",
                        refresh_interval=cfg.ACTIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                ]
            ),
        ]
        return {
            "entries": entries,
        }

    @staticmethod
    def ply_is_partially_covered_when_next_ply_both_edges_detected_at_same_time_and_one_cam_state_missing_other_never_detected_for_covered_ply_edge_by_same_cam():
        entries = [
            TestScenarioEntry(
                input_data=add_team_instruction_c2dm_request(instruction=mock_data.TeamInstructions.pallet_P_2),
                etcd_outputs=[
                    etcd_instruction_out(instruction=mock_data.TeamInstructions.pallet_P_2),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.fourth_ply_expected),
                    etcd_mould_state_out(state=GlobalMouldState.PRODUCTION),
                    etcd_mould_blade_sn_out(blade_sn="blade_sn"),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam3": {"missingEdges": ["P4.1", "P4.2"]},
                        "cam4": {"missingEdges": ["P4.2"]}},
                    ),
                    camera_out(
                        camera_ids={"cam3", "cam4"},
                        command="start_capture",
                        refresh_interval=cfg.ACTIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_P": {"pallets": {"pallet_2": {"missingPlies": 0,
                                                                                       "placedPlies": 0,
                                                                                       "totalPlies": 3}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_P_2,
                        ]),
                        "correctlyPlacedPlies": {},
                        "pliesToBePlaced": {
                            **mock_data.StaticGraph.SecondPalletP.fourth_ply,
                        },
                        "newMissingPlies": {},
                        "noLongerMissingPlies": {},
                        "forcedPlies": {},
                        "removedPlies": {}
                    }),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.SecondPalletP.fourth_ply),
                ]
            ),
            TestScenarioEntry(
                input_data=ev_message_in(
                    camera_id="cam3",
                    detected_edges={"P4.1", "P4.2"},
                    missing_edges=set()
                ),
                etcd_outputs=[
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.fourth_ply_placed),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.fifth_ply_expected),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam3": {"detectedEdges": ["P4.1", "P4.2"]},
                        "cam4": {"detectedEdges": ["P4.2"],
                                 "missingEdges": ["P5.1", "P5.2"]}},
                        session_cam_id="cam3"
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_P": {"pallets": {"pallet_2": {"missingPlies": 0,
                                                                                       "placedPlies": 1,
                                                                                       "totalPlies": 3}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_P_2,
                        ],
                            session=ev_message_session("cam3")
                        ),
                        "correctlyPlacedPlies": {
                            **mock_data.StaticGraph.SecondPalletP.fourth_ply,
                        },
                        "pliesToBePlaced": {
                            **mock_data.StaticGraph.SecondPalletP.fifth_ply,
                        },
                        "newMissingPlies": {},
                        "noLongerMissingPlies": {},
                        "forcedPlies": {},
                        "removedPlies": {}
                    }),
                    laser_out(payload=mock_data.LaserFeedbacks.CorrectlyPlacedPlies.SecondPalletP.fourth_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.SecondPalletP.fifth_ply),
                    camera_out(
                        camera_ids={"cam3"},
                        command="start_capture",
                        refresh_interval=cfg.PASSIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                    camera_out(
                        camera_ids={"cam4"},
                        command="start_capture",
                        refresh_interval=cfg.ACTIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                ]
            ),
            TestScenarioEntry(
                input_data=ev_message_in(
                    camera_id="cam3",
                    detected_edges={"P4.1"},
                    missing_edges={"P4.2"}
                ),
                etcd_outputs=[
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.fourth_ply_missing_by_cam3),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.fifth_ply_expected),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam3": {"detectedEdges": ["P4.1"], "missingEdges": ["P4.2"]},
                        "cam4": {"missingEdges": ["P4.2", "P5.1", "P5.2"]}},
                        session_cam_id="cam3"
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_P": {"pallets": {"pallet_2": {"missingPlies": 1,
                                                                                       "placedPlies": 1,
                                                                                       "totalPlies": 3}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_P_2,
                        ],
                            session=ev_message_session("cam3")
                        ),
                        "correctlyPlacedPlies": {},
                        "pliesToBePlaced": {
                            **mock_data.StaticGraph.SecondPalletP.fifth_ply,
                        },
                        "newMissingPlies": {
                            **mock_data.StaticGraph.SecondPalletP.fourth_ply,
                        },
                        "noLongerMissingPlies": {},
                        "forcedPlies": {},
                        "removedPlies": {}
                    }),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.SecondPalletP.fifth_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.MissingPlies.SecondPalletP.fourth_ply),
                    camera_out(
                        camera_ids={"cam3", "cam4"},
                        command="start_capture",
                        refresh_interval=cfg.ACTIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                ]
            ),
            # could skip this entry, but for consistency between tests let it be here
            TestScenarioEntry(
                input_data=ev_message_in(
                    camera_id="cam4",
                    detected_edges=set(),
                    missing_edges={"P4.2", "P5.1", "P5.2"}
                ),
                etcd_outputs=[],
                messaging_outputs=[]
            ),
            # on EV msg fifth ply is detected;
            TestScenarioEntry(
                input_data=ev_message_in(
                    camera_id="cam4",
                    detected_edges={"P5.1", "P5.2"},
                    missing_edges={"P4.2"}
                ),
                etcd_outputs=[
                    etcd_ply_out(
                        ply=mock_data.MouldStatePlies.PalletP.fourth_ply_partially_covered_with_missing_edge_by_cam3),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.fifth_ply_placed),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.sixth_ply_expected),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam3": {"detectedEdges": ["P4.1"]},
                        "cam4": {"detectedEdges": ["P5.1", "P5.2"], "missingEdges": ["P6.1"]},
                        "cam5": {"missingEdges": ["P6.1", "P6.2"]}},
                        session_cam_id="cam4"
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_P": {"pallets": {"pallet_2": {"missingPlies": 0,
                                                                                       "placedPlies": 2,
                                                                                       "totalPlies": 3}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_P_2,
                        ],
                            session=ev_message_session("cam4")
                        ),
                        "correctlyPlacedPlies": {
                            **mock_data.StaticGraph.SecondPalletP.fifth_ply,
                        },
                        "pliesToBePlaced": {
                            **mock_data.StaticGraph.SecondPalletP.sixth_ply,
                        },
                        "newMissingPlies": {},
                        "noLongerMissingPlies": {
                            **mock_data.StaticGraph.SecondPalletP.fourth_ply,
                        },
                        "forcedPlies": {},
                        "removedPlies": {}
                    }),
                    laser_out(payload=mock_data.LaserFeedbacks.CorrectlyPlacedPlies.SecondPalletP.fifth_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.SecondPalletP.sixth_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToNull.SecondPalletP.fourth_ply),
                    camera_out(
                        camera_ids={"cam3"},
                        command="start_capture",
                        refresh_interval=cfg.PASSIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                    camera_out(
                        camera_ids={"cam4", "cam5"},
                        command="start_capture",
                        refresh_interval=cfg.ACTIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                ]
            ),
        ]
        return {
            "entries": entries,
        }

    @staticmethod
    def ply_is_partially_covered_when_next_ply_both_edges_detected_at_same_time_and_both_cam_states_missing_for_covered_ply_edge_by_same_cam():
        entries = [
            TestScenarioEntry(
                input_data=add_team_instruction_c2dm_request(instruction=mock_data.TeamInstructions.pallet_P_2),
                etcd_outputs=[
                    etcd_instruction_out(instruction=mock_data.TeamInstructions.pallet_P_2),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.fourth_ply_expected),
                    etcd_mould_state_out(state=GlobalMouldState.PRODUCTION),
                    etcd_mould_blade_sn_out(blade_sn="blade_sn"),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam3": {"missingEdges": ["P4.1", "P4.2"]},
                        "cam4": {"missingEdges": ["P4.2"]}},
                    ),
                    camera_out(
                        camera_ids={"cam3", "cam4"},
                        command="start_capture",
                        refresh_interval=cfg.ACTIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_P": {"pallets": {"pallet_2": {"missingPlies": 0,
                                                                                       "placedPlies": 0,
                                                                                       "totalPlies": 3}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_P_2,
                        ]),
                        "correctlyPlacedPlies": {},
                        "pliesToBePlaced": {
                            **mock_data.StaticGraph.SecondPalletP.fourth_ply,
                        },
                        "newMissingPlies": {},
                        "noLongerMissingPlies": {},
                        "forcedPlies": {},
                        "removedPlies": {}
                    }),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.SecondPalletP.fourth_ply),
                ]
            ),
            TestScenarioEntry(
                input_data=ev_message_in(
                    camera_id="cam3",
                    detected_edges={"P4.1", "P4.2"},
                    missing_edges=set()
                ),
                etcd_outputs=[
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.fourth_ply_placed),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.fifth_ply_expected),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam3": {"detectedEdges": ["P4.1", "P4.2"]},
                        "cam4": {"detectedEdges": ["P4.2"],
                                 "missingEdges": ["P5.1", "P5.2"]}},
                        session_cam_id="cam3"
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_P": {"pallets": {"pallet_2": {"missingPlies": 0,
                                                                                       "placedPlies": 1,
                                                                                       "totalPlies": 3}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_P_2,
                        ],
                            session=ev_message_session("cam3")
                        ),
                        "correctlyPlacedPlies": {
                            **mock_data.StaticGraph.SecondPalletP.fourth_ply,
                        },
                        "pliesToBePlaced": {
                            **mock_data.StaticGraph.SecondPalletP.fifth_ply,
                        },
                        "newMissingPlies": {},
                        "noLongerMissingPlies": {},
                        "forcedPlies": {},
                        "removedPlies": {}
                    }),
                    laser_out(payload=mock_data.LaserFeedbacks.CorrectlyPlacedPlies.SecondPalletP.fourth_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.SecondPalletP.fifth_ply),
                    camera_out(
                        camera_ids={"cam3"},
                        command="start_capture",
                        refresh_interval=cfg.PASSIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                    camera_out(
                        camera_ids={"cam4"},
                        command="start_capture",
                        refresh_interval=cfg.ACTIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                ]
            ),
            # other cam also detected P4.2 edge
            TestScenarioEntry(
                input_data=ev_message_in(
                    camera_id="cam4",
                    detected_edges={"P4.2"},
                    missing_edges={"P5.1", "P5.2"}
                ),
                etcd_outputs=[],
                messaging_outputs=[]
            ),
            # now both cameras will loss detection on edge P4.2
            TestScenarioEntry(
                input_data=ev_message_in(
                    camera_id="cam3",
                    detected_edges={"P4.1"},
                    missing_edges={"P4.2"}
                ),
                etcd_outputs=[
                    # TODO: should we not send update to etcd about changes to one of edge cam state?
                    # etcd_out(ply=mock_data.MouldStatePlies.PalletP.fourth_ply_missing_by_cam3),
                    # etcd_out(ply=mock_data.MouldStatePlies.PalletP.fifth_ply_expected),
                ],
                messaging_outputs=[]
            ),
            TestScenarioEntry(
                input_data=ev_message_in(
                    camera_id="cam4",
                    detected_edges=set(),
                    missing_edges={"P4.2", "P5.1", "P5.2"}
                ),
                etcd_outputs=[
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.fourth_ply_missing_by_cam3_and_cam4),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.fifth_ply_expected),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam3": {"detectedEdges": ["P4.1"], "missingEdges": ["P4.2"]},
                        "cam4": {"missingEdges": ["P4.2", "P5.1", "P5.2"]}},
                        session_cam_id="cam4"
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_P": {"pallets": {"pallet_2": {"missingPlies": 1,
                                                                                       "placedPlies": 1,
                                                                                       "totalPlies": 3}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_P_2,
                        ],
                            session=ev_message_session("cam4")
                        ),
                        "correctlyPlacedPlies": {},
                        "pliesToBePlaced": {
                            **mock_data.StaticGraph.SecondPalletP.fifth_ply,
                        },
                        "newMissingPlies": {
                            **mock_data.StaticGraph.SecondPalletP.fourth_ply,
                        },
                        "noLongerMissingPlies": {},
                        "forcedPlies": {},
                        "removedPlies": {}
                    }),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.SecondPalletP.fifth_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.MissingPlies.SecondPalletP.fourth_ply),
                    camera_out(
                        camera_ids={"cam3", "cam4"},
                        command="start_capture",
                        refresh_interval=cfg.ACTIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                ]
            ),
            # on EV msg fifth ply is detected;
            TestScenarioEntry(
                input_data=ev_message_in(
                    camera_id="cam4",
                    detected_edges={"P5.1", "P5.2"},
                    missing_edges={"P4.2"}
                ),
                etcd_outputs=[
                    etcd_ply_out(
                        ply=mock_data.MouldStatePlies.PalletP.fourth_ply_partially_covered_with_missing_edge_by_both_cams),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.fifth_ply_placed),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.sixth_ply_expected),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam3": {"detectedEdges": ["P4.1"]},
                        "cam4": {"detectedEdges": ["P5.1", "P5.2"], "missingEdges": ["P6.1"]},
                        "cam5": {"missingEdges": ["P6.1", "P6.2"]}},
                        session_cam_id="cam4"
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_P": {"pallets": {"pallet_2": {"missingPlies": 0,
                                                                                       "placedPlies": 2,
                                                                                       "totalPlies": 3}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_P_2,
                        ],
                            session=ev_message_session("cam4")
                        ),
                        "correctlyPlacedPlies": {
                            **mock_data.StaticGraph.SecondPalletP.fifth_ply,
                        },
                        "pliesToBePlaced": {
                            **mock_data.StaticGraph.SecondPalletP.sixth_ply,
                        },
                        "newMissingPlies": {},
                        "noLongerMissingPlies": {
                            **mock_data.StaticGraph.SecondPalletP.fourth_ply,
                        },
                        "forcedPlies": {},
                        "removedPlies": {}
                    }),
                    laser_out(payload=mock_data.LaserFeedbacks.CorrectlyPlacedPlies.SecondPalletP.fifth_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.SecondPalletP.sixth_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToNull.SecondPalletP.fourth_ply),
                    camera_out(
                        camera_ids={"cam3"},
                        command="start_capture",
                        refresh_interval=cfg.PASSIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                    camera_out(
                        camera_ids={"cam4", "cam5"},
                        command="start_capture",
                        refresh_interval=cfg.ACTIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                ]
            ),
        ]
        return {
            "entries": entries,
        }
