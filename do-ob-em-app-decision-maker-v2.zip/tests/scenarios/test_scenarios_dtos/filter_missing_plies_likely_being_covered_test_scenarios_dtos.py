# pylint: disable=protected-access, missing-module-docstring, missing-class-docstring, missing-function-docstring, duplicate-code, line-too-long, too-few-public-methods, no-self-use, too-many-locals, too-many-lines, too-many-lines
import app.config as cfg
import tests.scenarios.mock_data as mock_data
from tests.scenarios.model.test_scenario_entry import TestScenarioEntry
from tests.scenarios.scenarios_base import add_team_instruction_c2dm_request, ev_message_in, edge_verification_out, \
    camera_out, laser_out, trace_out, etcd_ply_out, ev_message_session, trace_out_metadata, stats_out


class FilterMissingPliesLikelyBeingCoveredTestScenariosDtos:
    @staticmethod
    def should_filter_missing_ply_when_1_of_1_edge_is_missing_and_is_coverable_by_plies_to_be_placed():
        entries = [
            # on TI C2DM request first ply for pallet_P_1 is expected
            TestScenarioEntry(
                input_data=add_team_instruction_c2dm_request(instruction=mock_data.TeamInstructions.pallet_P_1),
            ),
            # on EV msg first ply is still being expected
            TestScenarioEntry(
                input_data=ev_message_in(
                    camera_id="cam1",
                    detected_edges=set(),
                    missing_edges={"P1.2"}
                ),
                etcd_outputs=[],
                messaging_outputs=[]
            ),
            # on EV msg first ply is detected, second ply is expected
            TestScenarioEntry(
                input_data=ev_message_in(
                    camera_id="cam1",
                    detected_edges={"P1.2"},
                    missing_edges=set()
                ),
                etcd_outputs=[
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.first_ply_placed_without_invisible_edge),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.second_ply_expected),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam1": {"detectedEdges": ["P1.2"], "missingEdges": ["P2.1"]},
                        "cam2": {"missingEdges": ["P2.1", "P2.2"]}},
                        session_cam_id="cam1"
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_P": {"pallets": {"pallet_1": {"missingPlies": 0,
                                                                                       "placedPlies": 1,
                                                                                       "totalPlies": 3}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_P_1
                        ],
                            session=ev_message_session("cam1")
                        ),
                        "correctlyPlacedPlies": {
                            **mock_data.StaticGraph.FirstPalletP.first_ply_invisible_edge_removed,
                        },
                        "pliesToBePlaced": {
                            **mock_data.StaticGraph.FirstPalletP.second_ply,
                        },
                        "newMissingPlies": {},
                        "noLongerMissingPlies": {},
                        "forcedPlies": {},
                        "removedPlies": {}
                    }),
                    laser_out(payload=mock_data.LaserFeedbacks.CorrectlyPlacedPlies.FirstPalletP.first_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.FirstPalletP.second_ply),
                    camera_out(
                        camera_ids={"cam1", "cam2"},
                        command="start_capture",
                        refresh_interval=cfg.ACTIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                ]
            ),
            # on EV msg first ply becomes missing in state, but that change is not passed to laser_out and trace_out
            TestScenarioEntry(
                input_data=ev_message_in(
                    camera_id="cam1",
                    detected_edges=set(),
                    missing_edges={"P1.2", "P2.1", "P2.2"}
                ),
                etcd_outputs=[
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.first_ply_missing_without_invisible_edge),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.second_ply_expected),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam1": {"missingEdges": ["P1.2", "P2.1"]},
                        "cam2": {"missingEdges": ["P2.1", "P2.2"]}},
                        session_cam_id="cam1"
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_P": {"pallets": {"pallet_1": {"missingPlies": 1,
                                                                                       "placedPlies": 1,
                                                                                       "totalPlies": 3}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_P_1
                        ],
                            session=ev_message_session("cam1")
                        ),
                        "correctlyPlacedPlies": {},
                        "pliesToBePlaced": {
                            **mock_data.StaticGraph.FirstPalletP.second_ply,
                        },
                        "newMissingPlies": {},
                        "noLongerMissingPlies": {},
                        "forcedPlies": {},
                        "removedPlies": {}
                    }),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.FirstPalletP.second_ply),
                    camera_out(
                        camera_ids={"cam1", "cam2"},
                        command="start_capture",
                        refresh_interval=cfg.ACTIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                ]
            ),
            # on EV msg second ply is detected, first ply partially covered, third ply is expected
            TestScenarioEntry(
                input_data=ev_message_in(
                    camera_id="cam2",
                    detected_edges={"P2.1", "P2.2"},
                    missing_edges={"P1.2"}
                ),
                etcd_outputs=[
                    etcd_ply_out(
                        ply=mock_data.MouldStatePlies.PalletP.first_ply_covered_on_missing_without_invisible_edge),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.second_ply_placed),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.third_ply_expected),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam1": {"detectedEdges": ["P2.1"]},
                        "cam2": {"detectedEdges": ["P2.1", "P2.2"], "missingEdges": ["P3.1"]},
                        "cam3": {"missingEdges": ["P3.2"]}},
                        session_cam_id="cam2"
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_P": {"pallets": {"pallet_1": {"missingPlies": 0,
                                                                                       "placedPlies": 2,
                                                                                       "totalPlies": 3}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_P_1
                        ],
                            session=ev_message_session("cam2")
                        ),
                        "correctlyPlacedPlies": {
                            **mock_data.StaticGraph.FirstPalletP.second_ply,
                        },
                        "pliesToBePlaced": {
                            **mock_data.StaticGraph.FirstPalletP.third_ply,
                        },
                        "newMissingPlies": {},
                        "noLongerMissingPlies": {
                            **mock_data.StaticGraph.FirstPalletP.first_ply_invisible_edge_removed,
                        },
                        "forcedPlies": {},
                        "removedPlies": {}
                    }),
                    laser_out(payload=mock_data.LaserFeedbacks.CorrectlyPlacedPlies.FirstPalletP.second_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.FirstPalletP.third_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToNull.FirstPalletP.first_ply),
                    camera_out(
                        camera_ids={"cam1"},
                        command="start_capture",
                        refresh_interval=cfg.PASSIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                    camera_out(
                        camera_ids={"cam2", "cam3"},
                        command="start_capture",
                        refresh_interval=cfg.ACTIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                ]
            ),
        ]
        return {
            "entries": entries,
        }

    @staticmethod
    def should_filter_missing_ply_when_1_of_2_edge_is_missing_and_it_is_coverable_by_plies_to_be_placed():
        entries = [
            # on TI C2DM request first ply for pallet_P_1 is expected
            TestScenarioEntry(
                input_data=add_team_instruction_c2dm_request(instruction=mock_data.TeamInstructions.pallet_P_1),
            ),
            # on EV msg first ply is detected, second ply is expected
            TestScenarioEntry(
                input_data=ev_message_in(
                    camera_id="cam1",
                    detected_edges={"P1.2"},
                    missing_edges=set()
                ),
            ),
            # on EV msg second ply is detected, first ply partially covered, third ply is expected
            TestScenarioEntry(
                input_data=ev_message_in(
                    camera_id="cam2",
                    detected_edges={"P2.1", "P2.2"},
                    missing_edges={"P1.2"}
                ),
            ),
            # on EV msg second ply becomes missing in state, but that change is not passed to laser_out and trace_out
            TestScenarioEntry(
                input_data=ev_message_in(
                    camera_id="cam2",
                    detected_edges={"P2.1"},
                    missing_edges={"P2.2", "P3.1"}
                ),
                etcd_outputs=[
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.second_ply_missing_by_cam2),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.third_ply_expected),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam1": {"detectedEdges": ["P2.1"]},
                        "cam2": {"detectedEdges": ["P2.1"], "missingEdges": ["P2.2", "P3.1"]},
                        "cam3": {"missingEdges": ["P3.2"]}},
                        session_cam_id="cam2"
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_P": {"pallets": {"pallet_1": {"missingPlies": 1,
                                                                                       "placedPlies": 2,
                                                                                       "totalPlies": 3}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_P_1
                        ],
                            session=ev_message_session("cam2")
                        ),
                        "correctlyPlacedPlies": {},
                        "pliesToBePlaced": {
                            **mock_data.StaticGraph.FirstPalletP.third_ply,
                        },
                        "newMissingPlies": {},
                        "noLongerMissingPlies": {},
                        "forcedPlies": {},
                        "removedPlies": {}
                    }),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.FirstPalletP.third_ply),
                    camera_out(
                        camera_ids={"cam1", "cam2", "cam3"},
                        command="start_capture",
                        refresh_interval=cfg.ACTIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                ]
            ),
            # on EV msg second ply still missing in state, but that is not reflected to laser_out and trace_out
            TestScenarioEntry(
                input_data=ev_message_in(
                    camera_id="cam2",
                    detected_edges={"P2.1", "P3.1"},
                    missing_edges={"P2.2"}
                ),
                etcd_outputs=[
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.third_ply_expected_cam2_edge_detected),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam1": {"detectedEdges": ["P2.1"]},
                        "cam2": {"detectedEdges": ["P2.1", "P3.1"], "missingEdges": ["P2.2"]},
                        "cam3": {"missingEdges": ["P3.2"]}},
                        session_cam_id="cam2"
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_P": {"pallets": {"pallet_1": {"missingPlies": 1,
                                                                                       "placedPlies": 2,
                                                                                       "totalPlies": 3}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_P_1
                        ],
                            session=ev_message_session("cam2")
                        ),
                        "correctlyPlacedPlies": {},
                        "pliesToBePlaced": {
                            **mock_data.StaticGraph.FirstPalletP.third_ply,
                        },
                        "newMissingPlies": {},
                        "noLongerMissingPlies": {},
                        "forcedPlies": {},
                        "removedPlies": {}
                    }),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.FirstPalletP.third_ply),
                    camera_out(
                        camera_ids={"cam1", "cam2", "cam3"},
                        command="start_capture",
                        refresh_interval=cfg.ACTIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                ]
            ),
            # on EV msg second ply is covered, redundant plies-to-null is sent but should not be an issue
            TestScenarioEntry(
                input_data=ev_message_in(
                    camera_id="cam3",
                    detected_edges={"P3.2"},
                    missing_edges=set()
                ),
                etcd_outputs=[
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.second_ply_partially_covered),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.third_ply_placed_updated_by_cam_3),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam1": {"detectedEdges": ["P2.1"]},
                        "cam2": {"detectedEdges": ["P2.1", "P3.1"]},
                        "cam3": {"detectedEdges": ["P3.2"]}},
                        session_cam_id="cam3"
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_P": {"pallets": {"pallet_1": {"missingPlies": 0,
                                                                                       "placedPlies": 3,
                                                                                       "totalPlies": 3}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_P_1
                        ],
                            session=ev_message_session("cam3")
                        ),
                        "correctlyPlacedPlies": {
                            **mock_data.StaticGraph.FirstPalletP.third_ply,
                        },
                        "pliesToBePlaced": {},
                        "newMissingPlies": {},
                        "noLongerMissingPlies": {
                            **mock_data.StaticGraph.FirstPalletP.second_ply,
                        },
                        "forcedPlies": {},
                        "removedPlies": {}
                    }),
                    laser_out(payload=mock_data.LaserFeedbacks.LastPliesPlaced.FirstPalletP.third_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToNull.FirstPalletP.second_ply),
                    camera_out(
                        camera_ids={"cam1", "cam2", "cam3"},
                        command="start_capture",
                        refresh_interval=cfg.PASSIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                ]
            ),
        ]
        return {
            "entries": entries,
        }

    @staticmethod
    def should_filter_missing_ply_when_1_of_2_edge_is_missing_and_both_are_coverable_by_plies_to_be_placed():
        entries = [
            # on TI C2DM request first ply for pallet_U_1 is expected
            TestScenarioEntry(
                input_data=add_team_instruction_c2dm_request(instruction=mock_data.TeamInstructions.pallet_U_1),
            ),
            # on EV msg first ply is detected, second ply is expected
            TestScenarioEntry(
                input_data=ev_message_in(
                    camera_id="cam1",
                    detected_edges={"U1.1", "U1.2"},
                    missing_edges=set()
                ),
            ),
            # on EV msg first ply becomes missing in state, but that change is not passed to laser_out and trace_out
            TestScenarioEntry(
                input_data=ev_message_in(
                    camera_id="cam1",
                    detected_edges={"U1.1"},
                    missing_edges={"U1.2", "U2.1", "U2.2"}
                ),
                etcd_outputs=[
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.first_ply_missing_2ed_edge),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.second_ply_expected),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam1": {"detectedEdges": ["U1.1"], "missingEdges": ["U1.2", "U2.1", "U2.2"]},
                        "cam2": {"missingEdges": ["U2.2"]}},
                        session_cam_id="cam1",
                        layers=["layer_U"],
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_U": {"pallets": {"pallet_1": {"missingPlies": 1,
                                                                                       "placedPlies": 1,
                                                                                       "totalPlies": 4}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_U_1,
                        ],
                            session=ev_message_session("cam1")
                        ),
                        "correctlyPlacedPlies": {},
                        "pliesToBePlaced": {
                            **mock_data.StaticGraph.FirstPalletU.second_ply_fully_covers_first_ply,
                        },
                        "newMissingPlies": {},
                        "noLongerMissingPlies": {},
                        "forcedPlies": {},
                        "removedPlies": {}
                    }),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.FirstPalletU.second_ply),
                    camera_out(
                        camera_ids={"cam1", "cam2"},
                        command="start_capture",
                        refresh_interval=cfg.ACTIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                ]
            ),
            # on EV msg first ply is covered, redundant plies-to-null is sent but should not be an issue
            TestScenarioEntry(
                input_data=ev_message_in(
                    camera_id="cam1",
                    detected_edges={"U2.1", "U2.2"},
                    missing_edges={"U1.1", "U1.2"}
                ),
                etcd_outputs=[
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.first_ply_fully_covered_by_U2_on_missing),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.second_ply_placed),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.third_ply_expected),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam1": {"detectedEdges": ["U2.1", "U2.2"]},
                        "cam2": {"detectedEdges": ["U2.2"],
                                 "missingEdges": ["U3.1", "U3.2"]}},
                        session_cam_id="cam1",
                        layers=["layer_U"],
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_U": {"pallets": {"pallet_1": {"missingPlies": 0,
                                                                                       "placedPlies": 2,
                                                                                       "totalPlies": 4}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_U_1,
                        ],
                            session=ev_message_session("cam1")
                        ),
                        "correctlyPlacedPlies": {
                            **mock_data.StaticGraph.FirstPalletU.second_ply_fully_covers_first_ply,
                        },
                        "pliesToBePlaced": {
                            **mock_data.StaticGraph.FirstPalletU.third_ply,
                        },
                        "newMissingPlies": {},
                        "noLongerMissingPlies": {
                            **mock_data.StaticGraph.FirstPalletU.first_ply,
                        },
                        "forcedPlies": {},
                        "removedPlies": {}
                    }),
                    laser_out(payload=mock_data.LaserFeedbacks.CorrectlyPlacedPlies.FirstPalletU.second_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.FirstPalletU.third_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToNull.FirstPalletU.first_ply),
                    camera_out(
                        camera_ids={"cam1"},
                        command="start_capture",
                        refresh_interval=cfg.PASSIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                    camera_out(
                        camera_ids={"cam2"},
                        command="start_capture",
                        refresh_interval=cfg.ACTIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                ]
            ),
            # 5 EV - the flow continues...
            TestScenarioEntry(
                input_data=ev_message_in(
                    camera_id="cam2",
                    detected_edges={"U3.1", "U3.2"},
                    missing_edges={"U2.2"}
                ),
                etcd_outputs=[
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.second_ply_partially_covered),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.third_ply_placed_updated_by_cam_2),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.fourth_ply_expected),
                ],
            ),
        ]
        return {
            "entries": entries,
            "graph_data": {
                "mould_id": "mould_id",
                "blade_revision": "blade_revision",
                "version": "v1.0.0",
                "plies": {
                    **mock_data.StaticGraph.FirstPalletU.first_ply,
                    **mock_data.StaticGraph.FirstPalletU.second_ply_fully_covers_first_ply,
                    **mock_data.StaticGraph.FirstPalletU.third_ply,
                    **mock_data.StaticGraph.FirstPalletU.fourth_ply,
                }
            },
        }

    @staticmethod
    def should_filter_missing_ply_when_2_of_2_edges_ar_missing_and_both_are_coverable_by_plies_to_be_placed():
        entries = [
            # on TI C2DM request first ply for pallet_U_1 is expected
            TestScenarioEntry(
                input_data=add_team_instruction_c2dm_request(instruction=mock_data.TeamInstructions.pallet_U_1),
            ),
            # on EV msg first ply is detected, second ply is expected
            TestScenarioEntry(
                input_data=ev_message_in(
                    camera_id="cam1",
                    detected_edges={"U1.1", "U1.2"},
                    missing_edges=set()
                ),
            ),
            # on EV msg first ply becomes missing in state, but that change is not passed to laser_out and trace_out
            TestScenarioEntry(
                input_data=ev_message_in(
                    camera_id="cam1",
                    detected_edges=set(),
                    missing_edges={"U1.1", "U1.2", "U2.1", "U2.2"}
                ),
                etcd_outputs=[
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.first_ply_missing),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.second_ply_expected),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam1": {"missingEdges": ["U1.1", "U1.2", "U2.1", "U2.2"]},
                        "cam2": {"missingEdges": ["U2.2"]}},
                        session_cam_id="cam1",
                        layers=["layer_U"],
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_U": {"pallets": {"pallet_1": {"missingPlies": 1,
                                                                                       "placedPlies": 1,
                                                                                       "totalPlies": 4}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_U_1,
                        ],
                            session=ev_message_session("cam1")
                        ),
                        "correctlyPlacedPlies": {},
                        "pliesToBePlaced": {
                            **mock_data.StaticGraph.FirstPalletU.second_ply_fully_covers_first_ply,
                        },
                        "newMissingPlies": {},
                        "noLongerMissingPlies": {},
                        "forcedPlies": {},
                        "removedPlies": {}
                    }),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.FirstPalletU.second_ply),
                    camera_out(
                        camera_ids={"cam1", "cam2"},
                        command="start_capture",
                        refresh_interval=cfg.ACTIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                ]
            ),
            # on EV msg first ply is covered, redundant plies-to-null is sent but should not be an issue
            TestScenarioEntry(
                input_data=ev_message_in(
                    camera_id="cam1",
                    detected_edges={"U2.1", "U2.2"},
                    missing_edges={"U1.1", "U1.2"}
                ),
                etcd_outputs=[
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.first_ply_fully_covered_by_U2_on_missing),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.second_ply_placed),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.third_ply_expected),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam1": {"detectedEdges": ["U2.1", "U2.2"]},
                        "cam2": {"detectedEdges": ["U2.2"],
                                 "missingEdges": ["U3.1", "U3.2"]}},
                        session_cam_id="cam1",
                        layers=["layer_U"],
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_U": {"pallets": {"pallet_1": {"missingPlies": 0,
                                                                                       "placedPlies": 2,
                                                                                       "totalPlies": 4}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_U_1,
                        ],
                            session=ev_message_session("cam1")
                        ),
                        "correctlyPlacedPlies": {
                            **mock_data.StaticGraph.FirstPalletU.second_ply_fully_covers_first_ply,
                        },
                        "pliesToBePlaced": {
                            **mock_data.StaticGraph.FirstPalletU.third_ply,
                        },
                        "newMissingPlies": {},
                        "noLongerMissingPlies": {
                            **mock_data.StaticGraph.FirstPalletU.first_ply,
                        },
                        "forcedPlies": {},
                        "removedPlies": {}
                    }),
                    laser_out(payload=mock_data.LaserFeedbacks.CorrectlyPlacedPlies.FirstPalletU.second_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.FirstPalletU.third_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToNull.FirstPalletU.first_ply),
                    camera_out(
                        camera_ids={"cam1"},
                        command="start_capture",
                        refresh_interval=cfg.PASSIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                    camera_out(
                        camera_ids={"cam2"},
                        command="start_capture",
                        refresh_interval=cfg.ACTIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                ]
            ),
            # 5 EV - the flow continues...
            TestScenarioEntry(
                input_data=ev_message_in(
                    camera_id="cam2",
                    detected_edges={"U3.1", "U3.2"},
                    missing_edges={"U2.2"}
                ),
                etcd_outputs=[
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.second_ply_partially_covered),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.third_ply_placed_updated_by_cam_2),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.fourth_ply_expected),
                ],
            ),
        ]
        return {
            "entries": entries,
            "graph_data": {
                "mould_id": "mould_id",
                "blade_revision": "blade_revision",
                "version": "v1.0.0",
                "plies": {
                    **mock_data.StaticGraph.FirstPalletU.first_ply,
                    **mock_data.StaticGraph.FirstPalletU.second_ply_fully_covers_first_ply,
                    **mock_data.StaticGraph.FirstPalletU.third_ply,
                    **mock_data.StaticGraph.FirstPalletU.fourth_ply,
                }
            },
        }

    @staticmethod
    def should_not_filter_missing_ply_when_1_of_2_edge_is_missing_but_not_a_coverable_by_plies_to_be_placed():
        entries = [
            # on TI C2DM request first ply for pallet_P_1 is expected
            TestScenarioEntry(
                input_data=add_team_instruction_c2dm_request(instruction=mock_data.TeamInstructions.pallet_P_1),
            ),
            # on EV msg first ply is detected, second ply is expected
            TestScenarioEntry(
                input_data=ev_message_in(
                    camera_id="cam1",
                    detected_edges={"P1.2"},
                    missing_edges=set()
                ),
            ),
            # on EV msg second ply is detected, first ply partially covered, third ply is expected
            TestScenarioEntry(
                input_data=ev_message_in(
                    camera_id="cam2",
                    detected_edges={"P2.1", "P2.2"},
                    missing_edges={"P1.2"}
                ),
            ),
            # on EV msg second ply becomes missing but not by a coverable edge so is not filtered from outputs
            TestScenarioEntry(
                input_data=ev_message_in(
                    camera_id="cam2",
                    detected_edges={"P2.2"},
                    missing_edges={"P2.1", "P3.1"}
                ),
                etcd_outputs=[
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.second_ply_missing_1st_edge_by_cam2),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.third_ply_expected),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam1": {"missingEdges": ["P2.1"]},
                        "cam2": {"detectedEdges": ["P2.2"], "missingEdges": ["P2.1", "P3.1"]},
                        "cam3": {"missingEdges": ["P3.2"]}},
                        session_cam_id="cam2"
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_P": {"pallets": {"pallet_1": {"missingPlies": 1,
                                                                                       "placedPlies": 2,
                                                                                       "totalPlies": 3}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_P_1
                        ],
                            session=ev_message_session("cam2")
                        ),
                        "correctlyPlacedPlies": {},
                        "pliesToBePlaced": {
                            **mock_data.StaticGraph.FirstPalletP.third_ply,
                        },
                        "newMissingPlies": {
                            **mock_data.StaticGraph.FirstPalletP.second_ply,
                        },
                        "noLongerMissingPlies": {},
                        "forcedPlies": {},
                        "removedPlies": {}
                    }),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.FirstPalletP.third_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.MissingPlies.FirstPalletP.second_ply),
                    camera_out(
                        camera_ids={"cam1", "cam2", "cam3"},
                        command="start_capture",
                        refresh_interval=cfg.ACTIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                ]
            ),
            # on EV msg second ply becomes no longer missing, the flow continues as normal...
            TestScenarioEntry(
                input_data=ev_message_in(
                    camera_id="cam2",
                    detected_edges={"P2.1", "P2.2"},
                    missing_edges={"P3.1"}
                ),
                etcd_outputs=[
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.second_ply_placed_after_missing),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.third_ply_expected),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam1": {"detectedEdges": ["P2.1"]},
                        "cam2": {"detectedEdges": ["P2.1", "P2.2"], "missingEdges": ["P3.1"]},
                        "cam3": {"missingEdges": ["P3.2"]}},
                        session_cam_id="cam2"
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_P": {"pallets": {"pallet_1": {"missingPlies": 0,
                                                                                       "placedPlies": 2,
                                                                                       "totalPlies": 3}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_P_1
                        ],
                            session=ev_message_session("cam2")
                        ),
                        "correctlyPlacedPlies": {},
                        "pliesToBePlaced": {
                            **mock_data.StaticGraph.FirstPalletP.third_ply,
                        },
                        "newMissingPlies": {},
                        "noLongerMissingPlies": {
                            **mock_data.StaticGraph.FirstPalletP.second_ply,
                        },
                        "forcedPlies": {},
                        "removedPlies": {}
                    }),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.FirstPalletP.third_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToNull.FirstPalletP.second_ply),
                    camera_out(
                        camera_ids={"cam1"},
                        command="start_capture",
                        refresh_interval=cfg.PASSIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                    camera_out(
                        camera_ids={"cam2", "cam3"},
                        command="start_capture",
                        refresh_interval=cfg.ACTIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                ]
            ),
        ]
        return {
            "entries": entries,
        }

    @staticmethod
    def should_not_filter_missing_ply_when_1_of_2_edge_is_missing_but_ply_is_not_coverable_by_plies_to_be_placed():
        entries = [
            # on TI C2DM request first ply for pallet_U_1 is expected
            TestScenarioEntry(
                input_data=add_team_instruction_c2dm_request(instruction=mock_data.TeamInstructions.pallet_U_1),
            ),
            # on EV msg first ply is detected, second ply is expected
            TestScenarioEntry(
                input_data=ev_message_in(
                    camera_id="cam1",
                    detected_edges={"U1.1", "U1.2"},
                    missing_edges=set()
                ),
            ),
            # on EV msg second ply is detected, third ply is expected
            TestScenarioEntry(
                input_data=ev_message_in(
                    camera_id="cam1",
                    detected_edges={"U2.1", "U2.2"},
                    missing_edges={"U1.2"}
                ),
                etcd_outputs=[
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.first_ply_partially_covered),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.second_ply_placed),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.third_ply_expected),
                ],
            ),
            # on EV msg first ply becomes missing but not by a coverable edge so is not filtered from outputs
            TestScenarioEntry(
                input_data=ev_message_in(
                    camera_id="cam1",
                    detected_edges={"U2.1", "U2.2"},
                    missing_edges={"U1.1"}
                ),
                etcd_outputs=[
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.first_ply_missing_due_being_covered),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.third_ply_expected),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam1": {"detectedEdges": ["U2.1", "U2.2"], "missingEdges": ["U1.1"]},
                        "cam2": {"detectedEdges": ["U2.2"], "missingEdges": ["U3.1", "U3.2"]}},
                        session_cam_id="cam1",
                        layers=["layer_U"],
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_U": {"pallets": {"pallet_1": {"missingPlies": 1,
                                                                                       "placedPlies": 2,
                                                                                       "totalPlies": 4}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_U_1,
                        ],
                            session=ev_message_session("cam1")
                        ),
                        "correctlyPlacedPlies": {},
                        "pliesToBePlaced": {
                            **mock_data.StaticGraph.FirstPalletU.third_ply,
                        },
                        "newMissingPlies": {
                            **mock_data.StaticGraph.FirstPalletU.first_ply,
                        },
                        "noLongerMissingPlies": {},
                        "forcedPlies": {},
                        "removedPlies": {}
                    }),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.FirstPalletU.third_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.MissingPlies.FirstPalletU.first_ply),
                    camera_out(
                        camera_ids={"cam1", "cam2"},
                        command="start_capture",
                        refresh_interval=cfg.ACTIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                ]
            ),
            # 5 EV - the flow continues...
            TestScenarioEntry(
                input_data=ev_message_in(
                    camera_id="cam2",
                    detected_edges={"U3.1", "U3.2"},
                    missing_edges={"U2.2"}
                ),
                etcd_outputs=[
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.second_ply_partially_covered),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.third_ply_placed_updated_by_cam_2),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.fourth_ply_expected),
                ],
            ),
        ]
        return {
            "entries": entries,
            "graph_data": {
                "mould_id": "mould_id",
                "blade_revision": "blade_revision",
                "version": "v1.0.0",
                "plies": {
                    **mock_data.StaticGraph.FirstPalletU.first_ply,
                    **mock_data.StaticGraph.FirstPalletU.second_ply,
                    **mock_data.StaticGraph.FirstPalletU.third_ply,
                    **mock_data.StaticGraph.FirstPalletU.fourth_ply,
                }
            },
        }

    @staticmethod
    def should_not_filter_missing_ply_when_2_of_2_edge_are_missing_but_none_of_are_coverable_by_plies_to_be_placed():
        entries = [
            # on TI C2DM request first ply for pallet_U_1 is expected
            TestScenarioEntry(
                input_data=add_team_instruction_c2dm_request(instruction=mock_data.TeamInstructions.pallet_U_1),
            ),
            # on EV msg first ply is detected, second ply is expected
            TestScenarioEntry(
                input_data=ev_message_in(
                    camera_id="cam1",
                    detected_edges={"U1.1", "U1.2"},
                    missing_edges=set()
                ),
            ),
            # on EV msg second ply is detected, third ply is expected
            TestScenarioEntry(
                input_data=ev_message_in(
                    camera_id="cam1",
                    detected_edges={"U2.1", "U2.2"},
                    missing_edges={"U1.2"}
                ),
                etcd_outputs=[
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.first_ply_partially_covered),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.second_ply_placed),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.third_ply_expected),
                ],
            ),
            # on EV msg second ply becomes missing on both edges but both are not by a coverable so is not filtered
            TestScenarioEntry(
                input_data=ev_message_in(
                    camera_id="cam1",
                    detected_edges={"U1.1"},
                    missing_edges={"U2.1", "U2.2"}
                ),
                etcd_outputs=[
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.second_ply_missing),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.third_ply_expected),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam1": {"detectedEdges": ["U1.1"], "missingEdges": ["U2.1", "U2.2"]},
                        "cam2": {"missingEdges": ["U2.2", "U3.1", "U3.2"]}},
                        session_cam_id="cam1",
                        layers=["layer_U"],
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_U": {"pallets": {"pallet_1": {"missingPlies": 1,
                                                                                       "placedPlies": 2,
                                                                                       "totalPlies": 4}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_U_1,
                        ],
                            session=ev_message_session("cam1")
                        ),
                        "correctlyPlacedPlies": {},
                        "pliesToBePlaced": {
                            **mock_data.StaticGraph.FirstPalletU.third_ply_does_not_cover_second_ply,
                        },
                        "newMissingPlies": {
                            **mock_data.StaticGraph.FirstPalletU.second_ply,
                        },
                        "noLongerMissingPlies": {},
                        "forcedPlies": {},
                        "removedPlies": {}
                    }),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.FirstPalletU.third_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.MissingPlies.FirstPalletU.second_ply),
                    camera_out(
                        camera_ids={"cam1", "cam2"},
                        command="start_capture",
                        refresh_interval=cfg.ACTIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                ]
            ),
            # on EV msg second ply again is detected
            TestScenarioEntry(
                input_data=ev_message_in(
                    camera_id="cam1",
                    detected_edges={"U1.1", "U2.1", "U2.2"},
                    missing_edges=set()
                ),
                etcd_outputs=[
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.second_ply_placed_after_missing),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.third_ply_expected),
                ],
            ),
            # 5 EV - the flow continues...
            TestScenarioEntry(
                input_data=ev_message_in(
                    camera_id="cam2",
                    detected_edges={"U3.1", "U3.2"},
                    missing_edges={"U2.2"}
                ),
                etcd_outputs=[
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.third_ply_placed_updated_by_cam_2),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.fourth_ply_expected),
                ],
            ),
        ]
        return {
            "entries": entries,
            "graph_data": {
                "mould_id": "mould_id",
                "blade_revision": "blade_revision",
                "version": "v1.0.0",
                "plies": {
                    **mock_data.StaticGraph.FirstPalletU.first_ply,
                    **mock_data.StaticGraph.FirstPalletU.second_ply,
                    **mock_data.StaticGraph.FirstPalletU.third_ply_does_not_cover_second_ply,
                    **mock_data.StaticGraph.FirstPalletU.fourth_ply,
                }
            },
        }

    @staticmethod
    def should_filter_missing_plies_when_different_plies_are_missing_and_they_are_coverable_by_plies_to_be_placed():
        entries = [
            # 1 on TI C2DM request first ply for pallet_P_1 is expected
            TestScenarioEntry(
                input_data=add_team_instruction_c2dm_request(instruction=mock_data.TeamInstructions.pallet_P_1),
            ),
            # 2 on TI C2DM request first ply for pallet_P_2 is expected
            TestScenarioEntry(
                input_data=add_team_instruction_c2dm_request(instruction=mock_data.TeamInstructions.pallet_P_2),
            ),
            # 3
            TestScenarioEntry(
                input_data=ev_message_in(
                    camera_id="cam1",
                    detected_edges={"P1.2"},
                    missing_edges=set()
                ),
            ),
            # 4
            TestScenarioEntry(
                input_data=ev_message_in(
                    camera_id="cam3",
                    detected_edges={"P4.1", "P4.2"},
                    missing_edges=set()
                ),
            ),
            # 5
            TestScenarioEntry(
                input_data=ev_message_in(
                    camera_id="cam2",
                    detected_edges={"P2.1", "P2.2"},
                    missing_edges={"P1.2"}
                ),
            ),
            # 6 on EV msg second ply becomes missing in state, but that change is not passed to laser_out and trace_out
            TestScenarioEntry(
                input_data=ev_message_in(
                    camera_id="cam2",
                    detected_edges={"P2.1"},
                    missing_edges={"P2.2", "P3.1"}
                ),
                etcd_outputs=[
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.second_ply_missing_by_cam2),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.third_ply_expected),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.fifth_ply_expected),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam1": {"detectedEdges": ["P2.1"]},
                        "cam2": {"detectedEdges": ["P2.1"], "missingEdges": ["P2.2", "P3.1"]},
                        "cam3": {"detectedEdges": ["P4.1", "P4.2"], "missingEdges": ["P3.2"]},
                        "cam4": {"detectedEdges": ["P4.2"], "missingEdges": ["P5.1", "P5.2"]}},
                        session_cam_id="cam2"
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_P": {"pallets": {"pallet_1": {"missingPlies": 1,
                                                                                       "placedPlies": 2,
                                                                                       "totalPlies": 3},
                                                                          "pallet_2": {"missingPlies": 0,
                                                                                       "placedPlies": 1,
                                                                                       "totalPlies": 3}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_P_1,
                            mock_data.TeamInstructions.pallet_P_2
                        ],
                            session=ev_message_session("cam2")
                        ),
                        "correctlyPlacedPlies": {},
                        "pliesToBePlaced": {
                            **mock_data.StaticGraph.FirstPalletP.third_ply,
                            **mock_data.StaticGraph.SecondPalletP.fifth_ply,
                        },
                        "newMissingPlies": {},
                        "noLongerMissingPlies": {},
                        "forcedPlies": {},
                        "removedPlies": {}
                    }),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.FirstPalletP.third_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.SecondPalletP.fifth_ply),
                    camera_out(
                        camera_ids={"cam1", "cam2", "cam3", "cam4"},
                        command="start_capture",
                        refresh_interval=cfg.ACTIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                ]
            ),
            # 7 on EV msg fourth ply becomes missing in state, but that change is not passed to laser_out and trace_out
            TestScenarioEntry(
                input_data=ev_message_in(
                    camera_id="cam3",
                    detected_edges={"P4.1"},
                    missing_edges={"P4.2"}
                ),
                etcd_outputs=[
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.third_ply_expected),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.fourth_ply_missing_by_cam3),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.fifth_ply_expected),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam1": {"detectedEdges": ["P2.1"]},
                        "cam2": {"detectedEdges": ["P2.1"], "missingEdges": ["P2.2", "P3.1"]},
                        "cam3": {"detectedEdges": ["P4.1"], "missingEdges": ["P3.2", "P4.2"]},
                        "cam4": {"missingEdges": ["P4.2", "P5.1", "P5.2"]}},
                        session_cam_id="cam3"
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_P": {"pallets": {"pallet_1": {"missingPlies": 1,
                                                                                       "placedPlies": 2,
                                                                                       "totalPlies": 3},
                                                                          "pallet_2": {"missingPlies": 1,
                                                                                       "placedPlies": 1,
                                                                                       "totalPlies": 3}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_P_1,
                            mock_data.TeamInstructions.pallet_P_2
                        ],
                            session=ev_message_session("cam3")
                        ),
                        "correctlyPlacedPlies": {},
                        "pliesToBePlaced": {
                            **mock_data.StaticGraph.FirstPalletP.third_ply,
                            **mock_data.StaticGraph.SecondPalletP.fifth_ply,
                        },
                        "newMissingPlies": {},
                        "noLongerMissingPlies": {},
                        "forcedPlies": {},
                        "removedPlies": {}
                    }),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.FirstPalletP.third_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.SecondPalletP.fifth_ply),
                    camera_out(
                        camera_ids={"cam1", "cam2", "cam3", "cam4"},
                        command="start_capture",
                        refresh_interval=cfg.ACTIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                ]
            ),
            # 8 on EV msg fourth ply is covered, redundant plies-to-null is sent but should not be an issue
            TestScenarioEntry(
                input_data=ev_message_in(
                    camera_id="cam4",
                    detected_edges={"P5.1", "P5.2"},
                    missing_edges={"P4.2"}
                ),
                etcd_outputs=[
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.third_ply_expected),
                    etcd_ply_out(
                        ply=mock_data.MouldStatePlies.PalletP.fourth_ply_partially_covered_with_missing_edge_by_cam3),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.fifth_ply_placed),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.sixth_ply_expected),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam1": {"detectedEdges": ["P2.1"]},
                        "cam2": {"detectedEdges": ["P2.1"], "missingEdges": ["P2.2", "P3.1"]},
                        "cam3": {"detectedEdges": ["P4.1"], "missingEdges": ["P3.2"]},
                        "cam4": {"detectedEdges": ["P5.1", "P5.2"], "missingEdges": ["P6.1"]},
                        "cam5": {"missingEdges": ["P6.1", "P6.2"]}},
                        session_cam_id="cam4"
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_P": {"pallets": {"pallet_1": {"missingPlies": 1,
                                                                                       "placedPlies": 2,
                                                                                       "totalPlies": 3},
                                                                          "pallet_2": {"missingPlies": 0,
                                                                                       "placedPlies": 2,
                                                                                       "totalPlies": 3}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_P_1,
                            mock_data.TeamInstructions.pallet_P_2
                        ],
                            session=ev_message_session("cam4")
                        ),
                        "correctlyPlacedPlies": {
                            **mock_data.StaticGraph.SecondPalletP.fifth_ply,
                        },
                        "pliesToBePlaced": {
                            **mock_data.StaticGraph.FirstPalletP.third_ply,
                            **mock_data.StaticGraph.SecondPalletP.sixth_ply,
                        },
                        "newMissingPlies": {},
                        "noLongerMissingPlies": {
                            **mock_data.StaticGraph.SecondPalletP.fourth_ply,
                        },
                        "forcedPlies": {},
                        "removedPlies": {}
                    }),
                    laser_out(payload=mock_data.LaserFeedbacks.CorrectlyPlacedPlies.SecondPalletP.fifth_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.FirstPalletP.third_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.SecondPalletP.sixth_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToNull.SecondPalletP.fourth_ply),
                    camera_out(
                        camera_ids={"cam1", "cam2", "cam3", "cam4", "cam5"},
                        command="start_capture",
                        refresh_interval=cfg.ACTIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                ]
            ),
            # 9 on TI C2DM request first ply for pallet_U_1 is expected
            TestScenarioEntry(
                input_data=add_team_instruction_c2dm_request(instruction=mock_data.TeamInstructions.pallet_U_1),
            ),
            # 10
            TestScenarioEntry(
                input_data=ev_message_in(
                    camera_id="cam1",
                    detected_edges={"U1.1", "U1.2"},
                    missing_edges=set()
                ),
            ),
            # 11 on EV msg ply becomes missing in state, but that change is not passed to laser_out and trace_out
            TestScenarioEntry(
                input_data=ev_message_in(
                    camera_id="cam1",
                    detected_edges={"P2.1", "U1.1"},
                    missing_edges={"U1.2", "U2.1", "U2.2"}
                ),
                etcd_outputs=[
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.third_ply_expected),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.sixth_ply_expected),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.first_ply_missing_2ed_edge),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.second_ply_expected),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam1": {"detectedEdges": ["P2.1", "U1.1"], "missingEdges": ["U1.2", "U2.1", "U2.2"]},
                        "cam2": {"detectedEdges": ["P2.1"], "missingEdges": ["P2.2", "P3.1", "U2.2"]},
                        "cam3": {"detectedEdges": ["P4.1"], "missingEdges": ["P3.2"]},
                        "cam4": {"detectedEdges": ["P5.1", "P5.2"], "missingEdges": ["P6.1"]},
                        "cam5": {"missingEdges": ["P6.1", "P6.2"]}},
                        session_cam_id="cam1",
                        layers=["layer_P", "layer_U"],
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_P": {"pallets": {"pallet_1": {"missingPlies": 1,
                                                                                       "placedPlies": 2,
                                                                                       "totalPlies": 3},
                                                                          "pallet_2": {"missingPlies": 0,
                                                                                       "placedPlies": 2,
                                                                                       "totalPlies": 3}}},
                                                  "layer_U": {"pallets": {"pallet_1": {"missingPlies": 1,
                                                                                       "placedPlies": 1,
                                                                                       "totalPlies": 4}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_P_1,
                            mock_data.TeamInstructions.pallet_P_2,
                            mock_data.TeamInstructions.pallet_U_1,
                        ],
                            session=ev_message_session("cam1")
                        ),
                        "correctlyPlacedPlies": {},
                        "pliesToBePlaced": {
                            **mock_data.StaticGraph.FirstPalletP.third_ply,
                            **mock_data.StaticGraph.SecondPalletP.sixth_ply,
                            **mock_data.StaticGraph.FirstPalletU.second_ply_fully_covers_first_ply,
                        },
                        "newMissingPlies": {},
                        "noLongerMissingPlies": {},
                        "forcedPlies": {},
                        "removedPlies": {}
                    }),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.FirstPalletP.third_ply_multi_layers),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.SecondPalletP.sixth_ply_multi_layers),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.FirstPalletU.second_ply_multi_layers),
                    camera_out(
                        camera_ids={"cam1", "cam2", "cam3", "cam4", "cam5"},
                        command="start_capture",
                        refresh_interval=cfg.ACTIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                ]
            ),
            # 12 on EV msg ply becomes missing on both edges, but that is still not reflected to laser_out and trace_out
            TestScenarioEntry(
                input_data=ev_message_in(
                    camera_id="cam1",
                    detected_edges={"P2.1"},
                    missing_edges={"U1.1", "U1.2", "U2.1", "U2.2"}
                ),
                etcd_outputs=[
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.third_ply_expected),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.sixth_ply_expected),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.first_ply_missing),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.second_ply_expected),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam1": {"detectedEdges": ["P2.1"], "missingEdges": ["U1.1", "U1.2", "U2.1", "U2.2"]},
                        "cam2": {"detectedEdges": ["P2.1"], "missingEdges": ["P2.2", "P3.1", "U2.2"]},
                        "cam3": {"detectedEdges": ["P4.1"], "missingEdges": ["P3.2"]},
                        "cam4": {"detectedEdges": ["P5.1", "P5.2"], "missingEdges": ["P6.1"]},
                        "cam5": {"missingEdges": ["P6.1", "P6.2"]}},
                        session_cam_id="cam1",
                        layers=["layer_P", "layer_U"],
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_P": {"pallets": {"pallet_1": {"missingPlies": 1,
                                                                                       "placedPlies": 2,
                                                                                       "totalPlies": 3},
                                                                          "pallet_2": {"missingPlies": 0,
                                                                                       "placedPlies": 2,
                                                                                       "totalPlies": 3}}},
                                                  "layer_U": {"pallets": {"pallet_1": {"missingPlies": 1,
                                                                                       "placedPlies": 1,
                                                                                       "totalPlies": 4}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_P_1,
                            mock_data.TeamInstructions.pallet_P_2,
                            mock_data.TeamInstructions.pallet_U_1,
                        ],
                            session=ev_message_session("cam1")
                        ),
                        "correctlyPlacedPlies": {},
                        "pliesToBePlaced": {
                            **mock_data.StaticGraph.FirstPalletP.third_ply,
                            **mock_data.StaticGraph.SecondPalletP.sixth_ply,
                            **mock_data.StaticGraph.FirstPalletU.second_ply_fully_covers_first_ply,
                        },
                        "newMissingPlies": {},
                        "noLongerMissingPlies": {},
                        "forcedPlies": {},
                        "removedPlies": {}
                    }),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.FirstPalletP.third_ply_multi_layers),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.SecondPalletP.sixth_ply_multi_layers),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.FirstPalletU.second_ply_multi_layers),
                    camera_out(
                        camera_ids={"cam1", "cam2", "cam3", "cam4", "cam5"},
                        command="start_capture",
                        refresh_interval=cfg.ACTIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                ]
            ),
            # 13 on EV msg U layer first ply is covered, redundant plies-to-null is sent but should not be an issue
            TestScenarioEntry(
                input_data=ev_message_in(
                    camera_id="cam1",
                    detected_edges={"P2.1", "U2.1", "U2.2"},
                    missing_edges={"U1.1", "U1.2"}
                ),
                etcd_outputs=[
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.third_ply_expected),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.sixth_ply_expected),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.first_ply_fully_covered_by_U2_on_missing),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.second_ply_placed),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.third_ply_expected),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam1": {"detectedEdges": ["P2.1", "U2.1", "U2.2"]},
                        "cam2": {"detectedEdges": ["P2.1", "U2.2"], "missingEdges": ["P2.2", "P3.1", "U3.1", "U3.2"]},
                        "cam3": {"detectedEdges": ["P4.1"], "missingEdges": ["P3.2"]},
                        "cam4": {"detectedEdges": ["P5.1", "P5.2"], "missingEdges": ["P6.1"]},
                        "cam5": {"missingEdges": ["P6.1", "P6.2"]}},
                        session_cam_id="cam1",
                        layers=["layer_P", "layer_U"],
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_P": {"pallets": {"pallet_1": {"missingPlies": 1,
                                                                                       "placedPlies": 2,
                                                                                       "totalPlies": 3},
                                                                          "pallet_2": {"missingPlies": 0,
                                                                                       "placedPlies": 2,
                                                                                       "totalPlies": 3}}},
                                                  "layer_U": {"pallets": {"pallet_1": {"missingPlies": 0,
                                                                                       "placedPlies": 2,
                                                                                       "totalPlies": 4}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_P_1,
                            mock_data.TeamInstructions.pallet_P_2,
                            mock_data.TeamInstructions.pallet_U_1,
                        ],
                            session=ev_message_session("cam1")
                        ),
                        "correctlyPlacedPlies": {
                            **mock_data.StaticGraph.FirstPalletU.second_ply_fully_covers_first_ply,
                        },
                        "pliesToBePlaced": {
                            **mock_data.StaticGraph.FirstPalletP.third_ply,
                            **mock_data.StaticGraph.SecondPalletP.sixth_ply,
                            **mock_data.StaticGraph.FirstPalletU.third_ply,
                        },
                        "newMissingPlies": {},
                        "noLongerMissingPlies": {
                            **mock_data.StaticGraph.FirstPalletU.first_ply,
                        },
                        "forcedPlies": {},
                        "removedPlies": {}
                    }),
                    laser_out(payload=mock_data.LaserFeedbacks.CorrectlyPlacedPlies.FirstPalletU.second_ply_multi_layers),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.FirstPalletP.third_ply_multi_layers),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.SecondPalletP.sixth_ply_multi_layers),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.FirstPalletU.third_ply_multi_layers),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToNull.FirstPalletU.first_ply_multi_layers),
                    camera_out(
                        camera_ids={"cam1", "cam2", "cam3", "cam4", "cam5"},
                        command="start_capture",
                        refresh_interval=cfg.ACTIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                ]
            ),
            # 14 on EV msg P2 ply still missing in state, but that is not reflected to laser_out and trace_out
            TestScenarioEntry(
                input_data=ev_message_in(
                    camera_id="cam2",
                    detected_edges={"P2.1", "P3.1", "U2.2"},
                    missing_edges={"P2.2"}
                ),
                etcd_outputs=[
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.third_ply_expected_cam2_edge_detected),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.sixth_ply_expected),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.third_ply_expected),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam1": {"detectedEdges": ["P2.1", "U2.1", "U2.2"]},
                        "cam2": {"detectedEdges": ["P2.1", "P3.1", "U2.2"], "missingEdges": ["P2.2", "U3.1", "U3.2"]},
                        "cam3": {"detectedEdges": ["P4.1"], "missingEdges": ["P3.2"]},
                        "cam4": {"detectedEdges": ["P5.1", "P5.2"], "missingEdges": ["P6.1"]},
                        "cam5": {"missingEdges": ["P6.1", "P6.2"]}},
                        session_cam_id="cam2",
                        layers=["layer_P", "layer_U"],
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_P": {"pallets": {"pallet_1": {"missingPlies": 1,
                                                                                       "placedPlies": 2,
                                                                                       "totalPlies": 3},
                                                                          "pallet_2": {"missingPlies": 0,
                                                                                       "placedPlies": 2,
                                                                                       "totalPlies": 3}}},
                                                  "layer_U": {"pallets": {"pallet_1": {"missingPlies": 0,
                                                                                       "placedPlies": 2,
                                                                                       "totalPlies": 4}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_P_1,
                            mock_data.TeamInstructions.pallet_P_2,
                            mock_data.TeamInstructions.pallet_U_1,
                        ],
                            session=ev_message_session("cam2")
                        ),
                        "correctlyPlacedPlies": {},
                        "pliesToBePlaced": {
                            **mock_data.StaticGraph.FirstPalletP.third_ply,
                            **mock_data.StaticGraph.SecondPalletP.sixth_ply,
                            **mock_data.StaticGraph.FirstPalletU.third_ply,
                        },
                        "newMissingPlies": {},
                        "noLongerMissingPlies": {},
                        "forcedPlies": {},
                        "removedPlies": {}
                    }),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.FirstPalletP.third_ply_multi_layers),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.SecondPalletP.sixth_ply_multi_layers),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.FirstPalletU.third_ply_multi_layers),
                    camera_out(
                        camera_ids={"cam1", "cam2", "cam3", "cam4", "cam5"},
                        command="start_capture",
                        refresh_interval=cfg.ACTIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                ]
            ),
            # 15 on EV msg P2 ply is covered, redundant plies-to-null is sent but should not be an issue
            TestScenarioEntry(
                input_data=ev_message_in(
                    camera_id="cam3",
                    detected_edges={"P3.2", "P4.1"},
                    missing_edges=set()
                ),
                etcd_outputs=[
                    etcd_ply_out(
                        ply=mock_data.MouldStatePlies.PalletP.second_ply_partially_covered_detected_by_both_cameras),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.third_ply_placed_updated_by_cam_3),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.sixth_ply_expected),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.third_ply_expected),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam1": {"detectedEdges": ["P2.1", "U2.1", "U2.2"]},
                        "cam2": {"detectedEdges": ["P2.1", "P3.1", "U2.2"], "missingEdges": ["U3.1", "U3.2"]},
                        "cam3": {"detectedEdges": ["P3.2", "P4.1"]},
                        "cam4": {"detectedEdges": ["P5.1", "P5.2"], "missingEdges": ["P6.1"]},
                        "cam5": {"missingEdges": ["P6.1", "P6.2"]}},
                        session_cam_id="cam3",
                        layers=["layer_P", "layer_U"],
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_P": {"pallets": {"pallet_1": {"missingPlies": 0,
                                                                                       "placedPlies": 3,
                                                                                       "totalPlies": 3},
                                                                          "pallet_2": {"missingPlies": 0,
                                                                                       "placedPlies": 2,
                                                                                       "totalPlies": 3}}},
                                                  "layer_U": {"pallets": {"pallet_1": {"missingPlies": 0,
                                                                                       "placedPlies": 2,
                                                                                       "totalPlies": 4}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_P_1,
                            mock_data.TeamInstructions.pallet_P_2,
                            mock_data.TeamInstructions.pallet_U_1,
                        ],
                            session=ev_message_session("cam3")
                        ),
                        "correctlyPlacedPlies": {
                            **mock_data.StaticGraph.FirstPalletP.third_ply,
                        },
                        "pliesToBePlaced": {
                            **mock_data.StaticGraph.SecondPalletP.sixth_ply,
                            **mock_data.StaticGraph.FirstPalletU.third_ply,
                        },
                        "newMissingPlies": {},
                        "noLongerMissingPlies": {
                            **mock_data.StaticGraph.FirstPalletP.second_ply,
                        },
                        "forcedPlies": {},
                        "removedPlies": {}
                    }),
                    laser_out(payload=mock_data.LaserFeedbacks.CorrectlyPlacedPlies.FirstPalletP.third_ply_multi_layers),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.SecondPalletP.sixth_ply_multi_layers),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.FirstPalletU.third_ply_multi_layers),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToNull.FirstPalletP.second_ply_multi_layers),
                    camera_out(
                        camera_ids={"cam1", "cam3"},
                        command="start_capture",
                        refresh_interval=cfg.PASSIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                    camera_out(
                        camera_ids={"cam2", "cam4", "cam5"},
                        command="start_capture",
                        refresh_interval=cfg.ACTIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                ]
            ),
        ]
        return {
            "entries": entries,
            "graph_data": {
                "mould_id": "mould_id",
                "blade_revision": "blade_revision",
                "version": "v1.0.0",
                "plies": {
                    **mock_data.StaticGraph.FirstPalletP.first_ply,
                    **mock_data.StaticGraph.FirstPalletP.second_ply,
                    **mock_data.StaticGraph.FirstPalletP.third_ply,
                    **mock_data.StaticGraph.SecondPalletP.fourth_ply,
                    **mock_data.StaticGraph.SecondPalletP.fifth_ply,
                    **mock_data.StaticGraph.SecondPalletP.sixth_ply,
                    **mock_data.StaticGraph.FirstPalletU.first_ply,
                    **mock_data.StaticGraph.FirstPalletU.second_ply_fully_covers_first_ply,
                    **mock_data.StaticGraph.FirstPalletU.third_ply,
                    **mock_data.StaticGraph.FirstPalletU.fourth_ply,
                }
            },
        }

    @staticmethod
    def should_not_filter_missing_plies_when_different_plies_are_missing_but_not_coverable_by_plies_to_be_placed():
        entries = [
            # 1 on TI C2DM request first ply for pallet_P_1 is expected
            TestScenarioEntry(
                input_data=add_team_instruction_c2dm_request(instruction=mock_data.TeamInstructions.pallet_P_1),
            ),
            # 2 on TI C2DM request first ply for pallet_P_2 is expected
            TestScenarioEntry(
                input_data=add_team_instruction_c2dm_request(instruction=mock_data.TeamInstructions.pallet_P_2),
            ),
            # 3
            TestScenarioEntry(
                input_data=ev_message_in(
                    camera_id="cam1",
                    detected_edges={"P1.2"},
                    missing_edges=set()
                ),
            ),
            # 4
            TestScenarioEntry(
                input_data=ev_message_in(
                    camera_id="cam3",
                    detected_edges={"P4.1", "P4.2"},
                    missing_edges=set()
                ),
            ),
            # 5
            TestScenarioEntry(
                input_data=ev_message_in(
                    camera_id="cam2",
                    detected_edges={"P2.1", "P2.2"},
                    missing_edges={"P1.2"}
                ),
            ),
            # 6 on EV msg P2 ply becomes missing but not by a coverable edge so is not filtered from outputs
            TestScenarioEntry(
                input_data=ev_message_in(
                    camera_id="cam2",
                    detected_edges={"P2.2"},
                    missing_edges={"P2.1", "P3.1"}
                ),
                etcd_outputs=[
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.second_ply_missing_1st_edge_by_cam2),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.third_ply_expected),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.fifth_ply_expected),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam1": {"missingEdges": ["P2.1"]},
                        "cam2": {"detectedEdges": ["P2.2"], "missingEdges": ["P2.1", "P3.1"]},
                        "cam3": {"detectedEdges": ["P4.1", "P4.2"], "missingEdges": ["P3.2"]},
                        "cam4": {"detectedEdges": ["P4.2"], "missingEdges": ["P5.1", "P5.2"]}},
                        session_cam_id="cam2"
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_P": {"pallets": {"pallet_1": {"missingPlies": 1,
                                                                                       "placedPlies": 2,
                                                                                       "totalPlies": 3},
                                                                          "pallet_2": {"missingPlies": 0,
                                                                                       "placedPlies": 1,
                                                                                       "totalPlies": 3}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_P_1,
                            mock_data.TeamInstructions.pallet_P_2,
                        ],
                            session=ev_message_session("cam2")
                        ),
                        "correctlyPlacedPlies": {},
                        "pliesToBePlaced": {
                            **mock_data.StaticGraph.FirstPalletP.third_ply,
                            **mock_data.StaticGraph.SecondPalletP.fifth_ply,
                        },
                        "newMissingPlies": {
                            **mock_data.StaticGraph.FirstPalletP.second_ply,
                        },
                        "noLongerMissingPlies": {},
                        "forcedPlies": {},
                        "removedPlies": {}
                    }),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.FirstPalletP.third_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.SecondPalletP.fifth_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.MissingPlies.FirstPalletP.second_ply),
                    camera_out(
                        camera_ids={"cam1", "cam2", "cam3", "cam4"},
                        command="start_capture",
                        refresh_interval=cfg.ACTIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                ]
            ),
            # 7 on EV msg P4 ply becomes missing but not by a coverable edge so is not filtered from outputs
            TestScenarioEntry(
                input_data=ev_message_in(
                    camera_id="cam3",
                    detected_edges={"P4.2"},
                    missing_edges={"P4.1"}
                ),
                etcd_outputs=[
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.third_ply_expected),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.fourth_ply_missing_by_1st_edge),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.fifth_ply_expected),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam1": {"missingEdges": ["P2.1"]},
                        "cam2": {"detectedEdges": ["P2.2"], "missingEdges": ["P2.1", "P3.1"]},
                        "cam3": {"detectedEdges": ["P4.2"], "missingEdges": ["P3.2", "P4.1"]},
                        "cam4": {"detectedEdges": ["P4.2"], "missingEdges": ["P5.1", "P5.2"]}},
                        session_cam_id="cam3"
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_P": {"pallets": {"pallet_1": {"missingPlies": 1,
                                                                                       "placedPlies": 2,
                                                                                       "totalPlies": 3},
                                                                          "pallet_2": {"missingPlies": 1,
                                                                                       "placedPlies": 1,
                                                                                       "totalPlies": 3}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_P_1,
                            mock_data.TeamInstructions.pallet_P_2
                        ],
                            session=ev_message_session("cam3")
                        ),
                        "correctlyPlacedPlies": {},
                        "pliesToBePlaced": {
                            **mock_data.StaticGraph.FirstPalletP.third_ply,
                            **mock_data.StaticGraph.SecondPalletP.fifth_ply,
                        },
                        "newMissingPlies": {
                            **mock_data.StaticGraph.SecondPalletP.fourth_ply,
                        },
                        "noLongerMissingPlies": {},
                        "forcedPlies": {},
                        "removedPlies": {}
                    }),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.FirstPalletP.third_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.SecondPalletP.fifth_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.MissingPlies.SecondPalletP.fourth_ply),
                    camera_out(
                        camera_ids={"cam1", "cam2", "cam3", "cam4"},
                        command="start_capture",
                        refresh_interval=cfg.ACTIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                ]
            ),
            # 8 on TI C2DM request first ply for pallet_U_1 is expected
            TestScenarioEntry(
                input_data=add_team_instruction_c2dm_request(instruction=mock_data.TeamInstructions.pallet_U_1),
            ),
            # 9
            TestScenarioEntry(
                input_data=ev_message_in(
                    camera_id="cam1",
                    detected_edges={"U1.1", "U1.2"},
                    missing_edges=set()
                ),
            ),
            # 10 on EV msg U1 ply is covered
            TestScenarioEntry(
                input_data=ev_message_in(
                    camera_id="cam1",
                    detected_edges={"U2.1", "U2.2"},
                    missing_edges={"U1.2", "P2.1"}
                ),
                etcd_outputs=[
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.third_ply_expected),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.fifth_ply_expected),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.first_ply_partially_covered),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.second_ply_placed),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.third_ply_expected),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam1": {"detectedEdges": ["U1.1", "U2.1", "U2.2"], "missingEdges": ["P2.1"]},
                        "cam2": {"detectedEdges": ["P2.2", "U2.2"], "missingEdges": ["P2.1", "P3.1", "U3.1", "U3.2"]},
                        "cam3": {"detectedEdges": ["P4.2"], "missingEdges": ["P3.2", "P4.1"]},
                        "cam4": {"detectedEdges": ["P4.2"], "missingEdges": ["P5.1", "P5.2"]}},
                        session_cam_id="cam1",
                        layers=["layer_P", "layer_U"],
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_P": {"pallets": {"pallet_1": {"missingPlies": 1,
                                                                                       "placedPlies": 2,
                                                                                       "totalPlies": 3},
                                                                          "pallet_2": {"missingPlies": 1,
                                                                                       "placedPlies": 1,
                                                                                       "totalPlies": 3}}},
                                                  "layer_U": {"pallets": {"pallet_1": {"missingPlies": 0,
                                                                                       "placedPlies": 2,
                                                                                       "totalPlies": 4}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_P_1,
                            mock_data.TeamInstructions.pallet_P_2,
                            mock_data.TeamInstructions.pallet_U_1,
                        ],
                            session=ev_message_session("cam1")
                        ),
                        "correctlyPlacedPlies": {
                            **mock_data.StaticGraph.FirstPalletU.second_ply,
                        },
                        "pliesToBePlaced": {
                            **mock_data.StaticGraph.FirstPalletP.third_ply,
                            **mock_data.StaticGraph.SecondPalletP.fifth_ply,
                            **mock_data.StaticGraph.FirstPalletU.third_ply_does_not_cover_second_ply,
                        },
                        "newMissingPlies": {},
                        "noLongerMissingPlies": {},
                        "forcedPlies": {},
                        "removedPlies": {}
                    }),
                    laser_out(payload=mock_data.LaserFeedbacks.CorrectlyPlacedPlies.FirstPalletU.second_ply_multi_layers),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.FirstPalletP.third_ply_multi_layers),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.SecondPalletP.fifth_ply_multi_layers),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.FirstPalletU.third_ply_multi_layers),
                    camera_out(
                        camera_ids={"cam1", "cam2", "cam3", "cam4"},
                        command="start_capture",
                        refresh_interval=cfg.ACTIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                ]
            ),
            # 11 on EV msg U2 ply becomes missing by both edges but it is not coverable ply so not filtered from outputs
            TestScenarioEntry(
                input_data=ev_message_in(
                    camera_id="cam1",
                    detected_edges=set(),
                    missing_edges={"U2.1", "U2.2", "P2.1"}
                ),
                etcd_outputs=[
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.third_ply_expected),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.fifth_ply_expected),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.second_ply_missing),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.third_ply_expected),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam1": {"detectedEdges": ["U1.1"], "missingEdges": ["P2.1", "U2.1", "U2.2"]},
                        "cam2": {"detectedEdges": ["P2.2"], "missingEdges": ["P2.1", "P3.1", "U2.2", "U3.1", "U3.2"]},
                        "cam3": {"detectedEdges": ["P4.2"], "missingEdges": ["P3.2", "P4.1"]},
                        "cam4": {"detectedEdges": ["P4.2"], "missingEdges": ["P5.1", "P5.2"]}},
                        session_cam_id="cam1",
                        layers=["layer_P", "layer_U"],
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_P": {"pallets": {"pallet_1": {"missingPlies": 1,
                                                                                       "placedPlies": 2,
                                                                                       "totalPlies": 3},
                                                                          "pallet_2": {"missingPlies": 1,
                                                                                       "placedPlies": 1,
                                                                                       "totalPlies": 3}}},
                                                  "layer_U": {"pallets": {"pallet_1": {"missingPlies": 1,
                                                                                       "placedPlies": 2,
                                                                                       "totalPlies": 4}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_P_1,
                            mock_data.TeamInstructions.pallet_P_2,
                            mock_data.TeamInstructions.pallet_U_1,
                        ],
                            session=ev_message_session("cam1")
                        ),
                        "correctlyPlacedPlies": {},
                        "pliesToBePlaced": {
                            **mock_data.StaticGraph.FirstPalletP.third_ply,
                            **mock_data.StaticGraph.SecondPalletP.fifth_ply,
                            **mock_data.StaticGraph.FirstPalletU.third_ply_does_not_cover_second_ply,
                        },
                        "newMissingPlies": {
                            **mock_data.StaticGraph.FirstPalletU.second_ply,
                        },
                        "noLongerMissingPlies": {},
                        "forcedPlies": {},
                        "removedPlies": {}
                    }),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.FirstPalletP.third_ply_multi_layers),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.SecondPalletP.fifth_ply_multi_layers),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.FirstPalletU.third_ply_multi_layers),
                    laser_out(payload=mock_data.LaserFeedbacks.MissingPlies.FirstPalletU.second_ply_multi_layers),
                    camera_out(
                        camera_ids={"cam1", "cam2", "cam3", "cam4"},
                        command="start_capture",
                        refresh_interval=cfg.ACTIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                ]
            ),
            # 12 on EV msg P2 ply becomes no longer missing, the flow continues as normal...
            TestScenarioEntry(
                input_data=ev_message_in(
                    camera_id="cam2",
                    detected_edges={"P2.1", "P2.2"},
                    missing_edges={"P3.1"}
                ),
                etcd_outputs=[
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.second_ply_placed_after_missing),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.third_ply_expected),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.fifth_ply_expected),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.third_ply_expected),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam1": {"detectedEdges": ["P2.1", "U1.1"], "missingEdges": ["U2.1", "U2.2"]},
                        "cam2": {"detectedEdges": ["P2.1", "P2.2"], "missingEdges": ["P3.1", "U2.2", "U3.1", "U3.2"]},
                        "cam3": {"detectedEdges": ["P4.2"], "missingEdges": ["P3.2", "P4.1"]},
                        "cam4": {"detectedEdges": ["P4.2"], "missingEdges": ["P5.1", "P5.2"]}},
                        session_cam_id="cam2",
                        layers=["layer_P", "layer_U"],
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_P": {"pallets": {"pallet_1": {"missingPlies": 0,
                                                                                       "placedPlies": 2,
                                                                                       "totalPlies": 3},
                                                                          "pallet_2": {"missingPlies": 1,
                                                                                       "placedPlies": 1,
                                                                                       "totalPlies": 3}}},
                                                  "layer_U": {"pallets": {"pallet_1": {"missingPlies": 1,
                                                                                       "placedPlies": 2,
                                                                                       "totalPlies": 4}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_P_1,
                            mock_data.TeamInstructions.pallet_P_2,
                            mock_data.TeamInstructions.pallet_U_1,
                        ],
                            session=ev_message_session("cam2")
                        ),
                        "correctlyPlacedPlies": {},
                        "pliesToBePlaced": {
                            **mock_data.StaticGraph.FirstPalletP.third_ply,
                            **mock_data.StaticGraph.SecondPalletP.fifth_ply,
                            **mock_data.StaticGraph.FirstPalletU.third_ply_does_not_cover_second_ply,
                        },
                        "newMissingPlies": {},
                        "noLongerMissingPlies": {
                            **mock_data.StaticGraph.FirstPalletP.second_ply,
                        },
                        "forcedPlies": {},
                        "removedPlies": {}
                    }),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.FirstPalletP.third_ply_multi_layers),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.SecondPalletP.fifth_ply_multi_layers),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.FirstPalletU.third_ply_multi_layers),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToNull.FirstPalletP.second_ply_multi_layers),
                    camera_out(
                        camera_ids={"cam1", "cam2", "cam3", "cam4"},
                        command="start_capture",
                        refresh_interval=cfg.ACTIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                ]
            ),
        ]
        return {
            "entries": entries,
            "graph_data": {
                "mould_id": "mould_id",
                "blade_revision": "blade_revision",
                "version": "v1.0.0",
                "plies": {
                    **mock_data.StaticGraph.FirstPalletP.first_ply,
                    **mock_data.StaticGraph.FirstPalletP.second_ply,
                    **mock_data.StaticGraph.FirstPalletP.third_ply,
                    **mock_data.StaticGraph.SecondPalletP.fourth_ply,
                    **mock_data.StaticGraph.SecondPalletP.fifth_ply,
                    **mock_data.StaticGraph.SecondPalletP.sixth_ply,
                    **mock_data.StaticGraph.FirstPalletU.first_ply,
                    **mock_data.StaticGraph.FirstPalletU.second_ply,
                    **mock_data.StaticGraph.FirstPalletU.third_ply_does_not_cover_second_ply,
                    **mock_data.StaticGraph.FirstPalletU.fourth_ply,
                }
            },
        }
