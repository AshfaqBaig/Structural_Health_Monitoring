# pylint: disable=protected-access, missing-module-docstring, missing-class-docstring, missing-function-docstring, duplicate-code, line-too-long, too-few-public-methods, no-self-use, too-many-locals, too-many-lines
import tests.scenarios.mock_data as mock_data
from tests.scenarios.model.test_scenario_entry import TestScenarioEntry
from tests.scenarios.scenarios_base import mould_state_plies_data, add_team_instruction_c2dm_request, \
    undo_plies_to_dry_run_c2dm_request, c2dm_response_out


class HandleUndoPliesToDryRunCommandTestScenariosDtos:
    @staticmethod
    def should_return_only_initial_ply_when_only_initial_ply_placed():
        entries = [
            # TI 1
            TestScenarioEntry(
                input_data=add_team_instruction_c2dm_request(instruction=mock_data.TeamInstructions.pallet_U_1),
                # etcd_outputs=[], - ignoring, do not assert
                # messaging_outputs=[], - ignoring, do not assert
            ),
            # 2 undo_plies_to_dry_run command
            TestScenarioEntry(
                input_data=undo_plies_to_dry_run_c2dm_request("U1"),
                etcd_outputs=[],
                messaging_outputs=[],
                c2dm_response_outputs=[
                    c2dm_response_out(status_code=200, payload=["U1"])
                ]
            ),
        ]
        return {
            "entries": entries,
            "initial_mould_state_plies_data": mould_state_plies_data([
                mock_data.MouldStatePlies.PalletU.first_ply_placed,
                mock_data.MouldStatePlies.PalletU.second_ply_expected,
            ]),
            "graph_data": {
                "mould_id": "mould_id",
                "blade_revision": "blade_revision",
                "version": "v1.0.0",
                "plies": {
                    **mock_data.StaticGraph.FirstPalletU.first_ply,
                    **mock_data.StaticGraph.FirstPalletU.second_ply_fully_covers_first_ply,
                    **mock_data.StaticGraph.FirstPalletU.third_ply,
                    **mock_data.StaticGraph.FirstPalletU.fourth_ply,
                    **mock_data.StaticGraph.FirstPalletU.fifth_ply,
                }
            },
        }

    @staticmethod
    def should_return_correct_plies_and_in_correct_order_when_initial_ply_given():
        entries = [
            # TI 1
            TestScenarioEntry(
                input_data=add_team_instruction_c2dm_request(instruction=mock_data.TeamInstructions.pallet_U_1),
                # etcd_outputs=[], - ignoring, do not assert
                # messaging_outputs=[], - ignoring, do not assert
            ),
            # 2 undo_plies_to_dry_run command
            TestScenarioEntry(
                input_data=undo_plies_to_dry_run_c2dm_request("U1"),
                etcd_outputs=[],
                messaging_outputs=[],
                c2dm_response_outputs=[
                    c2dm_response_out(status_code=200, payload=["U1", "U2", "U3", "U4", "U5"])
                ]
            ),
        ]
        return {
            "entries": entries,
            "initial_mould_state_plies_data": mould_state_plies_data([
                mock_data.MouldStatePlies.PalletU.first_ply_partially_covered,
                mock_data.MouldStatePlies.PalletU.second_ply_fully_covered_by_U3,
                mock_data.MouldStatePlies.PalletU.third_ply_partially_covered,
                mock_data.MouldStatePlies.PalletU.fourth_ply_partially_covered,
                mock_data.MouldStatePlies.PalletU.fifth_ply_placed,
            ]),
            "graph_data": {
                "mould_id": "mould_id",
                "blade_revision": "blade_revision",
                "version": "v1.0.0",
                "plies": {
                    **mock_data.StaticGraph.FirstPalletU.first_ply,
                    **mock_data.StaticGraph.FirstPalletU.second_ply,
                    **mock_data.StaticGraph.FirstPalletU.third_ply_fully_covers_second_ply,
                    **mock_data.StaticGraph.FirstPalletU.fourth_ply,
                    **mock_data.StaticGraph.FirstPalletU.fifth_ply,
                }
            },
        }

    @staticmethod
    def should_return_correct_plies_and_in_correct_order_when_middle_ply_given():
        entries = [
            # TI 1
            TestScenarioEntry(
                input_data=add_team_instruction_c2dm_request(instruction=mock_data.TeamInstructions.pallet_U_1),
                # etcd_outputs=[], - ignoring, do not assert
                # messaging_outputs=[], - ignoring, do not assert
            ),
            # 2 undo_plies_to_dry_run command
            TestScenarioEntry(
                input_data=undo_plies_to_dry_run_c2dm_request("U3"),
                etcd_outputs=[],
                messaging_outputs=[],
                c2dm_response_outputs=[
                    c2dm_response_out(status_code=200, payload=["U3", "U4", "U5"])
                ]
            ),
        ]
        return {
            "entries": entries,
            "initial_mould_state_plies_data": mould_state_plies_data([
                mock_data.MouldStatePlies.PalletU.first_ply_partially_covered,
                mock_data.MouldStatePlies.PalletU.second_ply_fully_covered_by_U3,
                mock_data.MouldStatePlies.PalletU.third_ply_partially_covered,
                mock_data.MouldStatePlies.PalletU.fourth_ply_partially_covered,
                mock_data.MouldStatePlies.PalletU.fifth_ply_placed,
            ]),
            "graph_data": {
                "mould_id": "mould_id",
                "blade_revision": "blade_revision",
                "version": "v1.0.0",
                "plies": {
                    **mock_data.StaticGraph.FirstPalletU.first_ply,
                    **mock_data.StaticGraph.FirstPalletU.second_ply,
                    **mock_data.StaticGraph.FirstPalletU.third_ply_fully_covers_second_ply,
                    **mock_data.StaticGraph.FirstPalletU.fourth_ply,
                    **mock_data.StaticGraph.FirstPalletU.fifth_ply,
                }
            },
        }

    @staticmethod
    def should_return_correct_plies_and_in_correct_order_when_last_ply_given():
        entries = [
            # TI 1
            TestScenarioEntry(
                input_data=add_team_instruction_c2dm_request(instruction=mock_data.TeamInstructions.pallet_U_1),
                # etcd_outputs=[], - ignoring, do not assert
                # messaging_outputs=[], - ignoring, do not assert
            ),
            # 2 undo_plies_to_dry_run command
            TestScenarioEntry(
                input_data=undo_plies_to_dry_run_c2dm_request("U5"),
                etcd_outputs=[],
                messaging_outputs=[],
                c2dm_response_outputs=[
                    c2dm_response_out(status_code=200, payload=["U5"])
                ]
            ),
        ]
        return {
            "entries": entries,
            "initial_mould_state_plies_data": mould_state_plies_data([
                mock_data.MouldStatePlies.PalletU.first_ply_partially_covered,
                mock_data.MouldStatePlies.PalletU.second_ply_fully_covered_by_U3,
                mock_data.MouldStatePlies.PalletU.third_ply_partially_covered,
                mock_data.MouldStatePlies.PalletU.fourth_ply_partially_covered,
                mock_data.MouldStatePlies.PalletU.fifth_ply_placed,
            ]),
            "graph_data": {
                "mould_id": "mould_id",
                "blade_revision": "blade_revision",
                "version": "v1.0.0",
                "plies": {
                    **mock_data.StaticGraph.FirstPalletU.first_ply,
                    **mock_data.StaticGraph.FirstPalletU.second_ply,
                    **mock_data.StaticGraph.FirstPalletU.third_ply_fully_covers_second_ply,
                    **mock_data.StaticGraph.FirstPalletU.fourth_ply,
                    **mock_data.StaticGraph.FirstPalletU.fifth_ply,
                }
            },
        }

    @staticmethod
    def should_return_correct_plies_and_in_correct_order_when_some_plies_are_missing_and_forced_type():
        entries = [
            # TI 1
            TestScenarioEntry(
                input_data=add_team_instruction_c2dm_request(instruction=mock_data.TeamInstructions.pallet_U_1),
                # etcd_outputs=[], - ignoring, do not assert
                # messaging_outputs=[], - ignoring, do not assert
            ),
            # 2 undo_plies_to_dry_run command
            TestScenarioEntry(
                input_data=undo_plies_to_dry_run_c2dm_request("U1"),
                etcd_outputs=[],
                messaging_outputs=[],
                c2dm_response_outputs=[
                    c2dm_response_out(status_code=200, payload=["U1", "U2", "U3", "U4"])
                ]
            ),
        ]
        return {
            "entries": entries,
            "initial_mould_state_plies_data": mould_state_plies_data([
                mock_data.MouldStatePlies.PalletU.first_ply_partially_covered,
                mock_data.MouldStatePlies.PalletU.second_ply_phantom_forced_on_expected,
                mock_data.MouldStatePlies.PalletU.third_ply_partially_covered,
                mock_data.MouldStatePlies.PalletU.fourth_ply_missing,
                mock_data.MouldStatePlies.PalletU.fifth_ply_expected,
            ]),
            "graph_data": {
                "mould_id": "mould_id",
                "blade_revision": "blade_revision",
                "version": "v1.0.0",
                "plies": {
                    **mock_data.StaticGraph.FirstPalletU.first_ply,
                    **mock_data.StaticGraph.FirstPalletU.second_ply,
                    **mock_data.StaticGraph.FirstPalletU.third_ply,
                    **mock_data.StaticGraph.FirstPalletU.fourth_ply,
                    **mock_data.StaticGraph.FirstPalletU.fifth_ply,
                }
            },
        }
