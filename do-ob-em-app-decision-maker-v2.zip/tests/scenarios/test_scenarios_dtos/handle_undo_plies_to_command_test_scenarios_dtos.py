# pylint: disable=protected-access, missing-module-docstring, missing-class-docstring, missing-function-docstring, duplicate-code, line-too-long, too-few-public-methods, no-self-use, too-many-locals, too-many-lines
import app.config as cfg
import tests.scenarios.mock_data as mock_data
from tests.scenarios.model.test_scenario_entry import TestScenarioEntry
from tests.scenarios.scenarios_base import mould_state_plies_data, add_team_instruction_c2dm_request, \
    undo_plies_to_c2dm_request, etcd_ply_out, edge_verification_out, camera_out, stats_out, \
    trace_out, trace_out_metadata, laser_out, etcd_ply_delete_out, ev_message_in, ev_message_session


class HandleUndoPliesToCommandTestScenariosDtos:
    @staticmethod
    def should_correctly_undo_single_placed_ply_when_initial_ply_given():
        entries = [
            # TI 1
            TestScenarioEntry(
                input_data=add_team_instruction_c2dm_request(instruction=mock_data.TeamInstructions.pallet_P_1),
                # etcd_outputs=[], - ignoring, do not assert
                # messaging_outputs=[], - ignoring, do not assert
            ),
            # 2 undo_plies_to_dry_run command
            TestScenarioEntry(
                input_data=undo_plies_to_c2dm_request("P1"),
                etcd_outputs=[
                    etcd_ply_out(
                        ply=mock_data.MouldStatePlies.PalletP.first_ply_placed_without_invisible_edge_reset_due_undo),
                    etcd_ply_delete_out("P2"),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam1": {"missingEdges": ["P1.2"]}},
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_P": {"pallets": {"pallet_1": {"missingPlies": 0,
                                                                                       "placedPlies": 0,
                                                                                       "totalPlies": 3}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_P_1
                        ]),
                        "correctlyPlacedPlies": {},
                        "pliesToBePlaced": {
                            **mock_data.StaticGraph.FirstPalletP.first_ply_invisible_edge_removed,
                        },
                        "newMissingPlies": {},
                        "noLongerMissingPlies": {},
                        "forcedPlies": {},
                        "removedPlies": {
                            **mock_data.StaticGraph.FirstPalletP.second_ply,
                        }
                    }),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.FirstPalletP.first_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToNull.FirstPalletP.second_ply),
                    camera_out(
                        camera_ids={"cam1"},
                        command="start_capture",
                        refresh_interval=cfg.ACTIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                ],
            ),
            # 3 on EV msg new expected ply is detected and becomes placed
            TestScenarioEntry(
                input_data=ev_message_in(
                    camera_id="cam1",
                    detected_edges={"P1.2"},
                    missing_edges=set()
                ),
                etcd_outputs=[
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.first_ply_placed_without_invisible_edge),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.second_ply_expected),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam1": {"detectedEdges": ["P1.2"], "missingEdges": ["P2.1"]},
                        "cam2": {"missingEdges": ["P2.1", "P2.2"]}},
                        session_cam_id="cam1"
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_P": {"pallets": {"pallet_1": {"missingPlies": 0,
                                                                                       "placedPlies": 1,
                                                                                       "totalPlies": 3}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_P_1,
                        ],
                            session=ev_message_session("cam1")
                        ),
                        "correctlyPlacedPlies": {
                            **mock_data.StaticGraph.FirstPalletP.first_ply_invisible_edge_removed,
                        },
                        "pliesToBePlaced": {
                            **mock_data.StaticGraph.FirstPalletP.second_ply,
                        },
                        "newMissingPlies": {},
                        "noLongerMissingPlies": {},
                        "forcedPlies": {},
                        "removedPlies": {}
                    }),
                    laser_out(payload=mock_data.LaserFeedbacks.CorrectlyPlacedPlies.FirstPalletP.first_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.FirstPalletP.second_ply),
                    camera_out(
                        camera_ids={"cam1", "cam2"},
                        command="start_capture",
                        refresh_interval=cfg.ACTIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                ]
            ),
            # 4 EV - the flow continues...
            TestScenarioEntry(
                input_data=ev_message_in(
                    camera_id="cam2",
                    detected_edges={"P2.1", "P2.2"},
                    missing_edges=set()
                ),
                etcd_outputs=[
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.first_ply_covered_without_invisible_edge),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.second_ply_placed),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.third_ply_expected),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam1": {"detectedEdges": ["P2.1"]},
                        "cam2": {"detectedEdges": ["P2.1", "P2.2"], "missingEdges": ["P3.1"]},
                        "cam3": {"missingEdges": ["P3.2"]}},
                        session_cam_id="cam2"
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_P": {"pallets": {"pallet_1": {"missingPlies": 0,
                                                                                       "placedPlies": 2,
                                                                                       "totalPlies": 3}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_P_1,
                        ],
                            session=ev_message_session("cam2")
                        ),
                        "correctlyPlacedPlies": {
                            **mock_data.StaticGraph.FirstPalletP.second_ply,
                        },
                        "pliesToBePlaced": {
                            **mock_data.StaticGraph.FirstPalletP.third_ply,
                        },
                        "newMissingPlies": {},
                        "noLongerMissingPlies": {},
                        "forcedPlies": {},
                        "removedPlies": {}
                    }),
                    laser_out(payload=mock_data.LaserFeedbacks.CorrectlyPlacedPlies.FirstPalletP.second_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.FirstPalletP.third_ply),
                    camera_out(
                        camera_ids={"cam1"},
                        command="start_capture",
                        refresh_interval=cfg.PASSIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                    camera_out(
                        camera_ids={"cam2", "cam3"},
                        command="start_capture",
                        refresh_interval=cfg.ACTIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                ]
            ),
        ]
        return {
            "entries": entries,
            "initial_mould_state_plies_data": mould_state_plies_data([
                mock_data.MouldStatePlies.PalletP.first_ply_placed_without_invisible_edge,
                mock_data.MouldStatePlies.PalletP.second_ply_expected,
            ]),
        }

    @staticmethod
    def test_should_correctly_undo_multiple_placed_plies_when_initial_ply_given():
        entries = [
            # 1 TI - to initialise mould state
            TestScenarioEntry(
                input_data=add_team_instruction_c2dm_request(instruction=mock_data.TeamInstructions.pallet_P_1),
                # etcd_outputs=[], - ignoring, do not assert
                # messaging_outputs=[], - ignoring, do not assert
            ),
            # 2 undo_plies_to command
            TestScenarioEntry(
                input_data=undo_plies_to_c2dm_request("P1"),
                etcd_outputs=[
                    etcd_ply_out(
                        ply=mock_data.MouldStatePlies.PalletP.first_ply_covered_without_invisible_edge_reset_due_undo),
                    etcd_ply_out(
                        ply=mock_data.MouldStatePlies.PalletP.first_ply_placed_without_invisible_edge_reset_due_undo),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.second_ply_partially_covered_reset_due_undo),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.second_ply_placed_reset_due_undo),
                    etcd_ply_delete_out("P2"),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.third_ply_placed_reset_due_undo),
                    etcd_ply_delete_out("P3"),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam1": {"missingEdges": ["P1.2"]}},
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_P": {"pallets": {"pallet_1": {"missingPlies": 0,
                                                                                       "placedPlies": 0,
                                                                                       "totalPlies": 3}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_P_1
                        ]),
                        "correctlyPlacedPlies": {},
                        "pliesToBePlaced": {
                            **mock_data.StaticGraph.FirstPalletP.first_ply_invisible_edge_removed,
                        },
                        "newMissingPlies": {},
                        "noLongerMissingPlies": {},
                        "forcedPlies": {},
                        "removedPlies": {
                            **mock_data.StaticGraph.FirstPalletP.second_ply,
                            **mock_data.StaticGraph.FirstPalletP.third_ply,

                        }
                    }),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.FirstPalletP.first_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToNull.FirstPalletP.second_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToNull.FirstPalletP.third_ply),
                    camera_out(
                        camera_ids={"cam1"},
                        command="start_capture",
                        refresh_interval=cfg.ACTIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                ]
            ),
            # 3 on EV msg new expected ply is detected and becomes placed
            TestScenarioEntry(
                input_data=ev_message_in(
                    camera_id="cam1",
                    detected_edges={"P1.2"},
                    missing_edges=set()
                ),
                etcd_outputs=[
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.first_ply_placed_without_invisible_edge),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.second_ply_expected),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam1": {"detectedEdges": ["P1.2"], "missingEdges": ["P2.1"]},
                        "cam2": {"missingEdges": ["P2.1", "P2.2"]}},
                        session_cam_id="cam1"
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_P": {"pallets": {"pallet_1": {"missingPlies": 0,
                                                                                       "placedPlies": 1,
                                                                                       "totalPlies": 3}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_P_1,
                        ],
                            session=ev_message_session("cam1")
                        ),
                        "correctlyPlacedPlies": {
                            **mock_data.StaticGraph.FirstPalletP.first_ply_invisible_edge_removed,
                        },
                        "pliesToBePlaced": {
                            **mock_data.StaticGraph.FirstPalletP.second_ply,
                        },
                        "newMissingPlies": {},
                        "noLongerMissingPlies": {},
                        "forcedPlies": {},
                        "removedPlies": {}
                    }),
                    laser_out(payload=mock_data.LaserFeedbacks.CorrectlyPlacedPlies.FirstPalletP.first_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.FirstPalletP.second_ply),
                    camera_out(
                        camera_ids={"cam1", "cam2"},
                        command="start_capture",
                        refresh_interval=cfg.ACTIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                ]
            ),
            # 4 EV - the flow continues...
            TestScenarioEntry(
                input_data=ev_message_in(
                    camera_id="cam2",
                    detected_edges={"P2.1", "P2.2"},
                    missing_edges=set()
                ),
                etcd_outputs=[
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.first_ply_covered_without_invisible_edge),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.second_ply_placed),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.third_ply_expected),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam1": {"detectedEdges": ["P2.1"]},
                        "cam2": {"detectedEdges": ["P2.1", "P2.2"], "missingEdges": ["P3.1"]},
                        "cam3": {"missingEdges": ["P3.2"]}},
                        session_cam_id="cam2"
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_P": {"pallets": {"pallet_1": {"missingPlies": 0,
                                                                                       "placedPlies": 2,
                                                                                       "totalPlies": 3}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_P_1,
                        ],
                            session=ev_message_session("cam2")
                        ),
                        "correctlyPlacedPlies": {
                            **mock_data.StaticGraph.FirstPalletP.second_ply,
                        },
                        "pliesToBePlaced": {
                            **mock_data.StaticGraph.FirstPalletP.third_ply,
                        },
                        "newMissingPlies": {},
                        "noLongerMissingPlies": {},
                        "forcedPlies": {},
                        "removedPlies": {}
                    }),
                    laser_out(payload=mock_data.LaserFeedbacks.CorrectlyPlacedPlies.FirstPalletP.second_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.FirstPalletP.third_ply),
                    camera_out(
                        camera_ids={"cam1"},
                        command="start_capture",
                        refresh_interval=cfg.PASSIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                    camera_out(
                        camera_ids={"cam2", "cam3"},
                        command="start_capture",
                        refresh_interval=cfg.ACTIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                ]
            ),
        ]
        return {
            "entries": entries,
            "initial_mould_state_plies_data": mould_state_plies_data([
                mock_data.MouldStatePlies.PalletP.first_ply_covered_without_invisible_edge,
                mock_data.MouldStatePlies.PalletP.second_ply_partially_covered_on_placed,
                mock_data.MouldStatePlies.PalletP.third_ply_placed_updated_by_cam_3,
            ]),
        }

    @staticmethod
    def test_should_correctly_undo_few_placed_plies_when_middle_ply_given():
        entries = [
            # 1 TI - to initialise mould state
            TestScenarioEntry(
                input_data=add_team_instruction_c2dm_request(instruction=mock_data.TeamInstructions.pallet_P_1),
                # etcd_outputs=[], - ignoring, do not assert
                # messaging_outputs=[], - ignoring, do not assert
            ),
            # 2 undo_plies_to command
            TestScenarioEntry(
                input_data=undo_plies_to_c2dm_request("P2"),
                etcd_outputs=[
                    etcd_ply_out(
                        ply=mock_data.MouldStatePlies.PalletP.first_ply_covered_without_invisible_edge_reset_due_undo),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.second_ply_partially_covered_reset_due_undo),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.second_ply_placed_reset_due_undo),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.third_ply_placed_reset_due_undo),
                    etcd_ply_delete_out("P3"),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam1": {"detectedEdges": ["P1.2"], "missingEdges": ["P2.1"]},
                        "cam2": {"missingEdges": ["P2.1", "P2.2"]}},
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_P": {"pallets": {"pallet_1": {"missingPlies": 0,
                                                                                       "placedPlies": 1,
                                                                                       "totalPlies": 3}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_P_1
                        ]),
                        "correctlyPlacedPlies": {},
                        "pliesToBePlaced": {
                            **mock_data.StaticGraph.FirstPalletP.second_ply,
                        },
                        "newMissingPlies": {},
                        "noLongerMissingPlies": {},
                        "forcedPlies": {},
                        "removedPlies": {
                            **mock_data.StaticGraph.FirstPalletP.third_ply,
                        }
                    }),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.FirstPalletP.second_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToNull.FirstPalletP.third_ply),
                    camera_out(
                        camera_ids={"cam1", "cam2"},
                        command="start_capture",
                        refresh_interval=cfg.ACTIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                ]
            ),
            # 3 EV - the flow continues...
            TestScenarioEntry(
                input_data=ev_message_in(
                    camera_id="cam2",
                    detected_edges={"P2.1", "P2.2"},
                    missing_edges=set()
                ),
                etcd_outputs=[
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.first_ply_covered_without_invisible_edge),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.second_ply_placed),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.third_ply_expected),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam1": {"detectedEdges": ["P2.1"]},
                        "cam2": {"detectedEdges": ["P2.1", "P2.2"], "missingEdges": ["P3.1"]},
                        "cam3": {"missingEdges": ["P3.2"]}},
                        session_cam_id="cam2"
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_P": {"pallets": {"pallet_1": {"missingPlies": 0,
                                                                                       "placedPlies": 2,
                                                                                       "totalPlies": 3}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_P_1,
                        ],
                            session=ev_message_session("cam2")
                        ),
                        "correctlyPlacedPlies": {
                            **mock_data.StaticGraph.FirstPalletP.second_ply,
                        },
                        "pliesToBePlaced": {
                            **mock_data.StaticGraph.FirstPalletP.third_ply,
                        },
                        "newMissingPlies": {},
                        "noLongerMissingPlies": {},
                        "forcedPlies": {},
                        "removedPlies": {}
                    }),
                    laser_out(payload=mock_data.LaserFeedbacks.CorrectlyPlacedPlies.FirstPalletP.second_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.FirstPalletP.third_ply),
                    camera_out(
                        camera_ids={"cam1"},
                        command="start_capture",
                        refresh_interval=cfg.PASSIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                    camera_out(
                        camera_ids={"cam2", "cam3"},
                        command="start_capture",
                        refresh_interval=cfg.ACTIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                ]
            ),
        ]
        return {
            "entries": entries,
            "initial_mould_state_plies_data": mould_state_plies_data([
                mock_data.MouldStatePlies.PalletP.first_ply_covered_without_invisible_edge,
                mock_data.MouldStatePlies.PalletP.second_ply_partially_covered_on_placed,
                mock_data.MouldStatePlies.PalletP.third_ply_placed_updated_by_cam_3,
            ]),
        }

    @staticmethod
    def test_should_correctly_undo_single_placed_ply_when_last_ply_given():
        entries = [
            # 1 TI - to initialise mould state
            TestScenarioEntry(
                input_data=add_team_instruction_c2dm_request(instruction=mock_data.TeamInstructions.pallet_P_1),
                # etcd_outputs=[], - ignoring, do not assert
                # messaging_outputs=[], - ignoring, do not assert
            ),
            # 2 undo_plies_to command
            TestScenarioEntry(
                input_data=undo_plies_to_c2dm_request("P3"),
                etcd_outputs=[
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.second_ply_partially_covered_reset_due_undo),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.third_ply_placed_reset_due_undo),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam1": {"detectedEdges": ["P2.1"]},
                        "cam2": {"detectedEdges": ["P2.1", "P2.2"], "missingEdges": ["P3.1"]},
                        "cam3": {"missingEdges": ["P3.2"]}},
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_P": {"pallets": {"pallet_1": {"missingPlies": 0,
                                                                                       "placedPlies": 2,
                                                                                       "totalPlies": 3}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_P_1
                        ]),
                        "correctlyPlacedPlies": {},
                        "pliesToBePlaced": {
                            **mock_data.StaticGraph.FirstPalletP.third_ply,
                        },
                        "newMissingPlies": {},
                        "noLongerMissingPlies": {},
                        "forcedPlies": {},
                        "removedPlies": {}
                    }),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.FirstPalletP.third_ply),
                    camera_out(
                        camera_ids={"cam1"},
                        command="start_capture",
                        refresh_interval=cfg.PASSIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                    camera_out(
                        camera_ids={"cam2", "cam3"},
                        command="start_capture",
                        refresh_interval=cfg.ACTIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                ]
            ),
            # 3 the flow continuous...
            TestScenarioEntry(
                input_data=ev_message_in(
                    camera_id="cam2",
                    detected_edges={"P3.1"},
                    missing_edges=set(),
                ),
                etcd_outputs=[
                    etcd_ply_out(
                        ply=mock_data.MouldStatePlies.PalletP.third_ply_expected_cam2_edge_detected_after_reset_on_placed),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam1": {"detectedEdges": ["P2.1"]},
                        "cam2": {"detectedEdges": ["P2.1", "P2.2", "P3.1"]},
                        "cam3": {"missingEdges": ["P3.2"]}},
                        session_cam_id="cam2"
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_P": {"pallets": {"pallet_1": {"missingPlies": 0,
                                                                                       "placedPlies": 2,
                                                                                       "totalPlies": 3}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_P_1,
                        ],
                            session=ev_message_session("cam2")
                        ),
                        "correctlyPlacedPlies": {},
                        "pliesToBePlaced": {
                            **mock_data.StaticGraph.FirstPalletP.third_ply,
                        },
                        "newMissingPlies": {},
                        "noLongerMissingPlies": {},
                        "forcedPlies": {},
                        "removedPlies": {}
                    }),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.FirstPalletP.third_ply),
                    camera_out(
                        camera_ids={"cam1"},
                        command="start_capture",
                        refresh_interval=cfg.PASSIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                    camera_out(
                        camera_ids={"cam2", "cam3"},
                        command="start_capture",
                        refresh_interval=cfg.ACTIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                ]
            ),
            # 4 EV
            TestScenarioEntry(
                input_data=ev_message_in(
                    camera_id="cam3",
                    detected_edges={"P3.2"},
                    missing_edges=set(),
                ),
                etcd_outputs=[
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.second_ply_partially_covered_on_placed),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.third_ply_placed_updated_by_cam_3),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam1": {"detectedEdges": ["P2.1"]},
                        "cam2": {"detectedEdges": ["P2.1", "P3.1"]},
                        "cam3": {"detectedEdges": ["P3.2"]}},
                        session_cam_id="cam3"
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_P": {"pallets": {"pallet_1": {"missingPlies": 0,
                                                                                       "placedPlies": 3,
                                                                                       "totalPlies": 3}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_P_1,
                        ],
                            session=ev_message_session("cam3")
                        ),
                        "correctlyPlacedPlies": {
                            **mock_data.StaticGraph.FirstPalletP.third_ply,
                        },
                        "pliesToBePlaced": {},
                        "newMissingPlies": {},
                        "noLongerMissingPlies": {},
                        "forcedPlies": {},
                        "removedPlies": {}
                    }),
                    laser_out(payload=mock_data.LaserFeedbacks.LastPliesPlaced.FirstPalletP.third_ply),
                    camera_out(
                        camera_ids={"cam1", "cam2", "cam3"},
                        command="start_capture",
                        refresh_interval=cfg.PASSIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                ]
            ),
        ]
        return {
            "entries": entries,
            "initial_mould_state_plies_data": mould_state_plies_data([
                mock_data.MouldStatePlies.PalletP.first_ply_covered_without_invisible_edge,
                mock_data.MouldStatePlies.PalletP.second_ply_partially_covered_on_placed,
                mock_data.MouldStatePlies.PalletP.third_ply_placed_updated_by_cam_3,
            ]),
        }

    @staticmethod
    def test_should_correctly_undo_some_plies_when_initial_ply_and_graph_with_multiple_independent_plies_given():
        entries = [
            # 1 TI - to initialise mould state
            TestScenarioEntry(
                input_data=add_team_instruction_c2dm_request(instruction=mock_data.TeamInstructions.pallet_P_1),
            ),
            # 2
            TestScenarioEntry(
                input_data=add_team_instruction_c2dm_request(instruction=mock_data.TeamInstructions.pallet_P_2),
            ),
            # 3 undo_plies_to command
            TestScenarioEntry(
                input_data=undo_plies_to_c2dm_request("P1"),
                etcd_outputs=[
                    etcd_ply_out(
                        ply=mock_data.MouldStatePlies.PalletP.first_ply_covered_without_invisible_edge_reset_due_undo),
                    etcd_ply_out(
                        ply=mock_data.MouldStatePlies.PalletP.first_ply_placed_without_invisible_edge_reset_due_undo),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.second_ply_partially_covered_reset_due_undo),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.second_ply_placed_reset_due_undo),
                    etcd_ply_delete_out("P2"),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.third_ply_placed_reset_due_undo),
                    etcd_ply_delete_out("P3"),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam1": {"missingEdges": ["P1.2"]},
                        "cam3": {"detectedEdges": ["P4.1"]},
                        "cam4": {"detectedEdges": ["P5.1", "P5.2"], "missingEdges": ["P6.1"]},
                        "cam5": {"missingEdges": ["P6.1", "P6.2"]}},
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_P": {"pallets": {"pallet_1": {"missingPlies": 0,
                                                                                       "placedPlies": 0,
                                                                                       "totalPlies": 3},
                                                                          "pallet_2": {"missingPlies": 0,
                                                                                       "placedPlies": 2,
                                                                                       "totalPlies": 3}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_P_1,
                            mock_data.TeamInstructions.pallet_P_2
                        ]),
                        "correctlyPlacedPlies": {},
                        "pliesToBePlaced": {
                            **mock_data.StaticGraph.FirstPalletP.first_ply_invisible_edge_removed,
                            **mock_data.StaticGraph.SecondPalletP.sixth_ply,
                        },
                        "newMissingPlies": {},
                        "noLongerMissingPlies": {},
                        "forcedPlies": {},
                        "removedPlies": {
                            **mock_data.StaticGraph.FirstPalletP.second_ply,
                            **mock_data.StaticGraph.FirstPalletP.third_ply,

                        }
                    }),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.FirstPalletP.first_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.SecondPalletP.sixth_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToNull.FirstPalletP.second_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToNull.FirstPalletP.third_ply),
                    camera_out(
                        camera_ids={"cam3"},
                        command="start_capture",
                        refresh_interval=cfg.PASSIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                    camera_out(
                        camera_ids={"cam1", "cam4", "cam5"},
                        command="start_capture",
                        refresh_interval=cfg.ACTIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                ]
            ),
            # 4 on EV msg new expected ply is detected and becomes placed
            TestScenarioEntry(
                input_data=ev_message_in(
                    camera_id="cam1",
                    detected_edges={"P1.2"},
                    missing_edges=set()
                ),
                etcd_outputs=[
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.first_ply_placed_without_invisible_edge),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.second_ply_expected),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.sixth_ply_expected),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam1": {"detectedEdges": ["P1.2"], "missingEdges": ["P2.1"]},
                        "cam2": {"missingEdges": ["P2.1", "P2.2"]},
                        "cam3": {"detectedEdges": ["P4.1"]},
                        "cam4": {"detectedEdges": ["P5.1", "P5.2"], "missingEdges": ["P6.1"]},
                        "cam5": {"missingEdges": ["P6.1", "P6.2"]}},
                        session_cam_id="cam1"
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_P": {"pallets": {"pallet_1": {"missingPlies": 0,
                                                                                       "placedPlies": 1,
                                                                                       "totalPlies": 3},
                                                                          "pallet_2": {"missingPlies": 0,
                                                                                       "placedPlies": 2,
                                                                                       "totalPlies": 3}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_P_1,
                            mock_data.TeamInstructions.pallet_P_2,
                        ],
                            session=ev_message_session("cam1")
                        ),
                        "correctlyPlacedPlies": {
                            **mock_data.StaticGraph.FirstPalletP.first_ply_invisible_edge_removed,
                        },
                        "pliesToBePlaced": {
                            **mock_data.StaticGraph.FirstPalletP.second_ply,
                            **mock_data.StaticGraph.SecondPalletP.sixth_ply,
                        },
                        "newMissingPlies": {},
                        "noLongerMissingPlies": {},
                        "forcedPlies": {},
                        "removedPlies": {}
                    }),
                    laser_out(payload=mock_data.LaserFeedbacks.CorrectlyPlacedPlies.FirstPalletP.first_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.FirstPalletP.second_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.SecondPalletP.sixth_ply),
                    camera_out(
                        camera_ids={"cam3"},
                        command="start_capture",
                        refresh_interval=cfg.PASSIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                    camera_out(
                        command="start_capture",
                        camera_ids={"cam1", "cam2", "cam4", "cam5"},
                        refresh_interval=cfg.ACTIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                ]
            ),
            # 5 EV - the flow continues...
            TestScenarioEntry(
                input_data=ev_message_in(
                    camera_id="cam2",
                    detected_edges={"P2.1", "P2.2"},
                    missing_edges=set()
                ),
                etcd_outputs=[
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.first_ply_covered_without_invisible_edge),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.second_ply_placed),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.third_ply_expected),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.sixth_ply_expected),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam1": {"detectedEdges": ["P2.1"]},
                        "cam2": {"detectedEdges": ["P2.1", "P2.2"], "missingEdges": ["P3.1"]},
                        "cam3": {"detectedEdges": ["P4.1"], "missingEdges": ["P3.2"]},
                        "cam4": {"detectedEdges": ["P5.1", "P5.2"], "missingEdges": ["P6.1"]},
                        "cam5": {"missingEdges": ["P6.1", "P6.2"]}},
                        session_cam_id="cam2"
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_P": {"pallets": {"pallet_1": {"missingPlies": 0,
                                                                                       "placedPlies": 2,
                                                                                       "totalPlies": 3},
                                                                          "pallet_2": {"missingPlies": 0,
                                                                                       "placedPlies": 2,
                                                                                       "totalPlies": 3}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_P_1,
                            mock_data.TeamInstructions.pallet_P_2,
                        ],
                            session=ev_message_session("cam2")
                        ),
                        "correctlyPlacedPlies": {
                            **mock_data.StaticGraph.FirstPalletP.second_ply,
                        },
                        "pliesToBePlaced": {
                            **mock_data.StaticGraph.FirstPalletP.third_ply,
                            **mock_data.StaticGraph.SecondPalletP.sixth_ply,
                        },
                        "newMissingPlies": {},
                        "noLongerMissingPlies": {},
                        "forcedPlies": {},
                        "removedPlies": {}
                    }),
                    laser_out(payload=mock_data.LaserFeedbacks.CorrectlyPlacedPlies.FirstPalletP.second_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.FirstPalletP.third_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.SecondPalletP.sixth_ply),
                    camera_out(
                        camera_ids={"cam1"},
                        command="start_capture",
                        refresh_interval=cfg.PASSIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                    camera_out(
                        camera_ids={"cam2", "cam3", "cam4", "cam5"},
                        command="start_capture",
                        refresh_interval=cfg.ACTIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                ]
            ),
            TestScenarioEntry(
                input_data=ev_message_in(
                    camera_id="cam5",
                    detected_edges={"P6.1", "P6.2"},
                    missing_edges=set()
                ),
                etcd_outputs=[
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.third_ply_expected),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.fifth_ply_partially_covered),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.sixth_ply_placed),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam1": {"detectedEdges": ["P2.1"]},
                        "cam2": {"detectedEdges": ["P2.1", "P2.2"], "missingEdges": ["P3.1"]},
                        "cam3": {"detectedEdges": ["P4.1"], "missingEdges": ["P3.2"]},
                        "cam4": {"detectedEdges": ["P5.1", "P6.1"]},
                        "cam5": {"detectedEdges": ["P6.1", "P6.2"]}},
                        session_cam_id="cam5"
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_P": {"pallets": {"pallet_1": {"missingPlies": 0,
                                                                                       "placedPlies": 2,
                                                                                       "totalPlies": 3},
                                                                          "pallet_2": {"missingPlies": 0,
                                                                                       "placedPlies": 3,
                                                                                       "totalPlies": 3}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_P_1,
                            mock_data.TeamInstructions.pallet_P_2,
                        ],
                            session=ev_message_session("cam5")
                        ),
                        "correctlyPlacedPlies": {
                            **mock_data.StaticGraph.SecondPalletP.sixth_ply,
                        },
                        "pliesToBePlaced": {
                            **mock_data.StaticGraph.FirstPalletP.third_ply,
                        },
                        "newMissingPlies": {},
                        "noLongerMissingPlies": {},
                        "forcedPlies": {},
                        "removedPlies": {}
                    }),
                    laser_out(payload=mock_data.LaserFeedbacks.CorrectlyPlacedPlies.SecondPalletP.sixth_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.FirstPalletP.third_ply),
                    camera_out(
                        camera_ids={"cam1", "cam4", "cam5"},
                        command="start_capture",
                        refresh_interval=cfg.PASSIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                    camera_out(
                        camera_ids={"cam2", "cam3"},
                        command="start_capture",
                        refresh_interval=cfg.ACTIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                ]
            ),
        ]
        return {
            "entries": entries,
            "initial_mould_state_plies_data": mould_state_plies_data([
                mock_data.MouldStatePlies.PalletP.first_ply_covered_without_invisible_edge,
                mock_data.MouldStatePlies.PalletP.second_ply_partially_covered_on_placed,
                mock_data.MouldStatePlies.PalletP.third_ply_placed_updated_by_cam_3,
                mock_data.MouldStatePlies.PalletP.fourth_ply_partially_covered,
                mock_data.MouldStatePlies.PalletP.fifth_ply_placed,
                mock_data.MouldStatePlies.PalletP.sixth_ply_expected,
            ]),
        }

    @staticmethod
    def test_should_correctly_undo_only_middle_ply_when_middle_ply_and_graph_with_multiple_independent_plies_given():
        entries = [
            # 1 TI - to initialise mould state
            TestScenarioEntry(
                input_data=add_team_instruction_c2dm_request(instruction=mock_data.TeamInstructions.pallet_P_1),
            ),
            # 2
            TestScenarioEntry(
                input_data=add_team_instruction_c2dm_request(instruction=mock_data.TeamInstructions.pallet_P_2),
            ),
            # 3 undo_plies_to command
            TestScenarioEntry(
                input_data=undo_plies_to_c2dm_request("P3"),
                etcd_outputs=[
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.second_ply_partially_covered_reset_due_undo),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.third_ply_placed_reset_due_undo),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam1": {"detectedEdges": ["P2.1"]},
                        "cam2": {"detectedEdges": ["P2.1", "P2.2"], "missingEdges": ["P3.1"]},
                        "cam3": {"detectedEdges": ["P4.1"], "missingEdges": ["P3.2"]},
                        "cam4": {"detectedEdges": ["P5.1", "P5.2"], "missingEdges": ["P6.1"]},
                        "cam5": {"missingEdges": ["P6.1", "P6.2"]}},
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_P": {"pallets": {"pallet_1": {"missingPlies": 0,
                                                                                       "placedPlies": 2,
                                                                                       "totalPlies": 3},
                                                                          "pallet_2": {"missingPlies": 0,
                                                                                       "placedPlies": 2,
                                                                                       "totalPlies": 3}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_P_1,
                            mock_data.TeamInstructions.pallet_P_2
                        ]),
                        "correctlyPlacedPlies": {},
                        "pliesToBePlaced": {
                            **mock_data.StaticGraph.FirstPalletP.third_ply,
                            **mock_data.StaticGraph.SecondPalletP.sixth_ply,
                        },
                        "newMissingPlies": {},
                        "noLongerMissingPlies": {},
                        "forcedPlies": {},
                        "removedPlies": {}
                    }),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.FirstPalletP.third_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.SecondPalletP.sixth_ply),
                    camera_out(
                        camera_ids={"cam1"},
                        command="start_capture",
                        refresh_interval=cfg.PASSIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                    camera_out(
                        camera_ids={"cam2", "cam3", "cam4", "cam5"},
                        command="start_capture",
                        refresh_interval=cfg.ACTIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                ]
            ),
            # 4 the flow continuous...
            TestScenarioEntry(
                input_data=ev_message_in(
                    camera_id="cam2",
                    detected_edges={"P3.1"},
                    missing_edges=set(),
                ),
                etcd_outputs=[
                    etcd_ply_out(
                        ply=mock_data.MouldStatePlies.PalletP.third_ply_expected_cam2_edge_detected_after_reset_on_placed),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.sixth_ply_expected),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam1": {"detectedEdges": ["P2.1"]},
                        "cam2": {"detectedEdges": ["P2.1", "P2.2", "P3.1"]},
                        "cam3": {"detectedEdges": ["P4.1"], "missingEdges": ["P3.2"]},
                        "cam4": {"detectedEdges": ["P5.1", "P5.2"], "missingEdges": ["P6.1"]},
                        "cam5": {"missingEdges": ["P6.1", "P6.2"]}},
                        session_cam_id="cam2"
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_P": {"pallets": {"pallet_1": {"missingPlies": 0,
                                                                                       "placedPlies": 2,
                                                                                       "totalPlies": 3},
                                                                          "pallet_2": {"missingPlies": 0,
                                                                                       "placedPlies": 2,
                                                                                       "totalPlies": 3}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_P_1,
                            mock_data.TeamInstructions.pallet_P_2,
                        ],
                            session=ev_message_session("cam2")
                        ),
                        "correctlyPlacedPlies": {},
                        "pliesToBePlaced": {
                            **mock_data.StaticGraph.FirstPalletP.third_ply,
                            **mock_data.StaticGraph.SecondPalletP.sixth_ply,
                        },
                        "newMissingPlies": {},
                        "noLongerMissingPlies": {},
                        "forcedPlies": {},
                        "removedPlies": {}
                    }),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.FirstPalletP.third_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.SecondPalletP.sixth_ply),
                    camera_out(
                        camera_ids={"cam1"},
                        command="start_capture",
                        refresh_interval=cfg.PASSIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                    camera_out(
                        camera_ids={"cam2", "cam3", "cam4", "cam5"},
                        command="start_capture",
                        refresh_interval=cfg.ACTIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                ]
            ),
            # 5 EV
            TestScenarioEntry(
                input_data=ev_message_in(
                    camera_id="cam3",
                    detected_edges={"P3.2"},
                    missing_edges=set(),
                ),
                etcd_outputs=[
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.second_ply_partially_covered_on_placed),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.third_ply_placed_updated_by_cam_3),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.sixth_ply_expected),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam1": {"detectedEdges": ["P2.1"]},
                        "cam2": {"detectedEdges": ["P2.1", "P3.1"]},
                        "cam3": {"detectedEdges": ["P3.2", "P4.1"]},
                        "cam4": {"detectedEdges": ["P5.1", "P5.2"], "missingEdges": ["P6.1"]},
                        "cam5": {"missingEdges": ["P6.1", "P6.2"]}},
                        session_cam_id="cam3"
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_P": {"pallets": {"pallet_1": {"missingPlies": 0,
                                                                                       "placedPlies": 3,
                                                                                       "totalPlies": 3},
                                                                          "pallet_2": {"missingPlies": 0,
                                                                                       "placedPlies": 2,
                                                                                       "totalPlies": 3}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_P_1,
                            mock_data.TeamInstructions.pallet_P_2,
                        ],
                            session=ev_message_session("cam3")
                        ),
                        "correctlyPlacedPlies": {
                            **mock_data.StaticGraph.FirstPalletP.third_ply,
                        },
                        "pliesToBePlaced": {
                            **mock_data.StaticGraph.SecondPalletP.sixth_ply,
                        },
                        "newMissingPlies": {},
                        "noLongerMissingPlies": {},
                        "forcedPlies": {},
                        "removedPlies": {}
                    }),
                    laser_out(payload=mock_data.LaserFeedbacks.CorrectlyPlacedPlies.FirstPalletP.third_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.SecondPalletP.sixth_ply),
                    camera_out(
                        camera_ids={"cam1", "cam2", "cam3"},
                        command="start_capture",
                        refresh_interval=cfg.PASSIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                    camera_out(
                        camera_ids={"cam4", "cam5"},
                        command="start_capture",
                        refresh_interval=cfg.ACTIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                ]
            ),
            # 6 EV
            TestScenarioEntry(
                input_data=ev_message_in(
                    camera_id="cam5",
                    detected_edges={"P6.1", "P6.2"},
                    missing_edges=set()
                ),
                etcd_outputs=[
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.fifth_ply_partially_covered),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.sixth_ply_placed),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam1": {"detectedEdges": ["P2.1"]},
                        "cam2": {"detectedEdges": ["P2.1", "P3.1"]},
                        "cam3": {"detectedEdges": ["P3.2", "P4.1"]},
                        "cam4": {"detectedEdges": ["P5.1", "P6.1"]},
                        "cam5": {"detectedEdges": ["P6.1", "P6.2"]}},
                        session_cam_id="cam5"
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_P": {"pallets": {"pallet_1": {"missingPlies": 0,
                                                                                       "placedPlies": 3,
                                                                                       "totalPlies": 3},
                                                                          "pallet_2": {"missingPlies": 0,
                                                                                       "placedPlies": 3,
                                                                                       "totalPlies": 3}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_P_1,
                            mock_data.TeamInstructions.pallet_P_2,
                        ],
                            session=ev_message_session("cam5")
                        ),
                        "correctlyPlacedPlies": {
                            **mock_data.StaticGraph.SecondPalletP.sixth_ply,
                        },
                        "pliesToBePlaced": {},
                        "newMissingPlies": {},
                        "noLongerMissingPlies": {},
                        "forcedPlies": {},
                        "removedPlies": {}
                    }),
                    laser_out(payload=mock_data.LaserFeedbacks.LastPliesPlaced.SecondPalletP.sixth_ply),
                    camera_out(
                        camera_ids={"cam1", "cam2", "cam3", "cam4", "cam5"},
                        command="start_capture",
                        refresh_interval=cfg.PASSIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                ]
            ),
        ]
        return {
            "entries": entries,
            "initial_mould_state_plies_data": mould_state_plies_data([
                mock_data.MouldStatePlies.PalletP.first_ply_covered_without_invisible_edge,
                mock_data.MouldStatePlies.PalletP.second_ply_partially_covered_on_placed,
                mock_data.MouldStatePlies.PalletP.third_ply_placed_updated_by_cam_3,
                mock_data.MouldStatePlies.PalletP.fourth_ply_partially_covered,
                mock_data.MouldStatePlies.PalletP.fifth_ply_placed,
                mock_data.MouldStatePlies.PalletP.sixth_ply_expected,
            ]),
        }

    @staticmethod
    def test_should_correctly_undo_some_ply_when_middle_initial_ply_and_graph_with_multiple_independent_plies_given():
        entries = [
            # 1 TI - to initialise mould state
            TestScenarioEntry(
                input_data=add_team_instruction_c2dm_request(instruction=mock_data.TeamInstructions.pallet_P_1),
            ),
            # 2
            TestScenarioEntry(
                input_data=add_team_instruction_c2dm_request(instruction=mock_data.TeamInstructions.pallet_P_2),
            ),
            # 3 undo_plies_to command
            TestScenarioEntry(
                input_data=undo_plies_to_c2dm_request("P4"),
                etcd_outputs=[
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.third_ply_partially_covered_reset_due_undo),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.fourth_ply_partially_covered_reset_due_undo),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.fourth_ply_placed_reset_due_undo),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.fifth_ply_placed_reset_due_undo),
                    etcd_ply_delete_out("P5"),
                    etcd_ply_delete_out("P6"),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam1": {"detectedEdges": ["P2.1"]},
                        "cam2": {"detectedEdges": ["P2.1", "P3.1"]},
                        "cam3": {"detectedEdges": ["P3.2"], "missingEdges": ["P4.1", "P4.2"]},
                        "cam4": {"missingEdges": ["P4.2"]}},
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_P": {"pallets": {"pallet_1": {"missingPlies": 0,
                                                                                       "placedPlies": 3,
                                                                                       "totalPlies": 3},
                                                                          "pallet_2": {"missingPlies": 0,
                                                                                       "placedPlies": 0,
                                                                                       "totalPlies": 3}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_P_1,
                            mock_data.TeamInstructions.pallet_P_2
                        ]),
                        "correctlyPlacedPlies": {},
                        "pliesToBePlaced": {
                            **mock_data.StaticGraph.SecondPalletP.fourth_ply,
                        },
                        "newMissingPlies": {},
                        "noLongerMissingPlies": {},
                        "forcedPlies": {},
                        "removedPlies": {
                            **mock_data.StaticGraph.SecondPalletP.fifth_ply,
                            **mock_data.StaticGraph.SecondPalletP.sixth_ply,
                        }
                    }),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.SecondPalletP.fourth_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToNull.SecondPalletP.fifth_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToNull.SecondPalletP.sixth_ply),
                    camera_out(
                        camera_ids={"cam1", "cam2"},
                        command="start_capture",
                        refresh_interval=cfg.PASSIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                    camera_out(
                        camera_ids={"cam3", "cam4"},
                        command="start_capture",
                        refresh_interval=cfg.ACTIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                ]
            ),
            # 4 the flow continuous...
            TestScenarioEntry(
                input_data=ev_message_in(
                    camera_id="cam3",
                    detected_edges={"P4.1", "P4.2"},
                    missing_edges=set()
                ),
                etcd_outputs=[
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.third_ply_partially_covered_on_placed),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.fourth_ply_placed),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.fifth_ply_expected),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam1": {"detectedEdges": ["P2.1"]},
                        "cam2": {"detectedEdges": ["P2.1", "P3.1"]},
                        "cam3": {"detectedEdges": ["P4.1", "P4.2"]},
                        "cam4": {"detectedEdges": ["P4.2"],
                                 "missingEdges": ["P5.1", "P5.2"]}},
                        session_cam_id="cam3",
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_P": {"pallets": {"pallet_1": {"missingPlies": 0,
                                                                                       "placedPlies": 3,
                                                                                       "totalPlies": 3},
                                                                          "pallet_2": {"missingPlies": 0,
                                                                                       "placedPlies": 1,
                                                                                       "totalPlies": 3}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_P_1,
                            mock_data.TeamInstructions.pallet_P_2,
                        ],
                            session=ev_message_session("cam3")
                        ),
                        "correctlyPlacedPlies": {
                            **mock_data.StaticGraph.SecondPalletP.fourth_ply,
                        },
                        "pliesToBePlaced": {
                            **mock_data.StaticGraph.SecondPalletP.fifth_ply,
                        },
                        "newMissingPlies": {},
                        "noLongerMissingPlies": {},
                        "forcedPlies": {},
                        "removedPlies": {}
                    }),
                    laser_out(
                        payload=mock_data.LaserFeedbacks.CorrectlyPlacedPlies.SecondPalletP.fourth_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.SecondPalletP.fifth_ply),
                    camera_out(
                        camera_ids={"cam1", "cam2", "cam3"},
                        command="start_capture",
                        refresh_interval=cfg.PASSIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                    camera_out(
                        camera_ids={"cam4"},
                        command="start_capture",
                        refresh_interval=cfg.ACTIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                ]
            ),
        ]
        return {
            "entries": entries,
            "initial_mould_state_plies_data": mould_state_plies_data([
                mock_data.MouldStatePlies.PalletP.first_ply_covered_without_invisible_edge,
                mock_data.MouldStatePlies.PalletP.second_ply_partially_covered_on_placed,
                mock_data.MouldStatePlies.PalletP.third_ply_partially_covered,
                mock_data.MouldStatePlies.PalletP.fourth_ply_partially_covered,
                mock_data.MouldStatePlies.PalletP.fifth_ply_placed,
                mock_data.MouldStatePlies.PalletP.sixth_ply_expected,
            ]),
        }

    @staticmethod
    def test_should_correctly_undo_some_plies_when_initial_ply_and_graph_plies_with_multiple_dependents_given():
        entries = [
            # 1 TI - to initialise mould state
            TestScenarioEntry(
                input_data=add_team_instruction_c2dm_request(instruction=mock_data.TeamInstructions.pallet_P_1),
            ),
            # 2
            TestScenarioEntry(
                input_data=add_team_instruction_c2dm_request(instruction=mock_data.TeamInstructions.pallet_P_2),
            ),
            # 3 undo_plies_to command
            TestScenarioEntry(
                input_data=undo_plies_to_c2dm_request("P1"),
                etcd_outputs=[
                    etcd_ply_out(
                        ply=mock_data.MouldStatePlies.PalletP.first_ply_covered_without_invisible_edge_reset_due_undo),
                    etcd_ply_out(
                        ply=mock_data.MouldStatePlies.PalletP.first_ply_placed_without_invisible_edge_reset_due_undo),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.second_ply_partially_covered_reset_due_undo),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.second_ply_placed_reset_due_undo),
                    etcd_ply_delete_out("P2"),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.third_ply_placed_reset_due_undo),
                    etcd_ply_delete_out("P3"),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.fourth_ply_fully_covered_by_P3_reset_due_undo),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.fifth_ply_partially_covered_reset_due_undo),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam1": {"missingEdges": ["P1.2"]},
                        "cam3": {"detectedEdges": ["P4.1"]},
                        "cam4": {"detectedEdges": ["P5.1", "P5.2"], "missingEdges": ["P6.1"]},
                        "cam5": {"missingEdges": ["P6.1", "P6.2"]}},
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_P": {"pallets": {"pallet_1": {"missingPlies": 0,
                                                                                       "placedPlies": 0,
                                                                                       "totalPlies": 3},
                                                                          "pallet_2": {"missingPlies": 0,
                                                                                       "placedPlies": 2,
                                                                                       "totalPlies": 3}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_P_1,
                            mock_data.TeamInstructions.pallet_P_2
                        ]),
                        "correctlyPlacedPlies": {},
                        "pliesToBePlaced": {
                            **mock_data.StaticGraph.FirstPalletP.first_ply_invisible_edge_removed,
                            **mock_data.StaticGraph.SecondPalletP.sixth_ply,
                        },
                        "newMissingPlies": {},
                        "noLongerMissingPlies": {},
                        "forcedPlies": {},
                        "removedPlies": {
                            **mock_data.StaticGraph.FirstPalletP.second_ply,
                            **mock_data.StaticGraph.FirstPalletP.third_ply_covers_next_pallet_plies,
                        }
                    }),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.FirstPalletP.first_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.SecondPalletP.sixth_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToNull.FirstPalletP.second_ply),
                    laser_out(
                        payload=mock_data.LaserFeedbacks.PliesToNull.FirstPalletP.third_ply_covers_next_pallet_plies),
                    camera_out(
                        camera_ids={"cam3"},
                        command="start_capture",
                        refresh_interval=cfg.PASSIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                    camera_out(
                        camera_ids={"cam1", "cam4", "cam5"},
                        command="start_capture",
                        refresh_interval=cfg.ACTIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                ]
            ),
            # 4 on EV msg new expected ply is detected and becomes placed
            TestScenarioEntry(
                input_data=ev_message_in(
                    camera_id="cam1",
                    detected_edges={"P1.2"},
                    missing_edges=set()
                ),
                etcd_outputs=[
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.first_ply_placed_without_invisible_edge),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.second_ply_expected),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.sixth_ply_expected),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam1": {"detectedEdges": ["P1.2"], "missingEdges": ["P2.1"]},
                        "cam2": {"missingEdges": ["P2.1", "P2.2"]},
                        "cam3": {"detectedEdges": ["P4.1"]},
                        "cam4": {"detectedEdges": ["P5.1", "P5.2"], "missingEdges": ["P6.1"]},
                        "cam5": {"missingEdges": ["P6.1", "P6.2"]}},
                        session_cam_id="cam1"
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_P": {"pallets": {"pallet_1": {"missingPlies": 0,
                                                                                       "placedPlies": 1,
                                                                                       "totalPlies": 3},
                                                                          "pallet_2": {"missingPlies": 0,
                                                                                       "placedPlies": 2,
                                                                                       "totalPlies": 3}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_P_1,
                            mock_data.TeamInstructions.pallet_P_2,
                        ],
                            session=ev_message_session("cam1")
                        ),
                        "correctlyPlacedPlies": {
                            **mock_data.StaticGraph.FirstPalletP.first_ply_invisible_edge_removed,
                        },
                        "pliesToBePlaced": {
                            **mock_data.StaticGraph.FirstPalletP.second_ply,
                            **mock_data.StaticGraph.SecondPalletP.sixth_ply,
                        },
                        "newMissingPlies": {},
                        "noLongerMissingPlies": {},
                        "forcedPlies": {},
                        "removedPlies": {}
                    }),
                    laser_out(payload=mock_data.LaserFeedbacks.CorrectlyPlacedPlies.FirstPalletP.first_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.FirstPalletP.second_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.SecondPalletP.sixth_ply),
                    camera_out(
                        camera_ids={"cam3"},
                        command="start_capture",
                        refresh_interval=cfg.PASSIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                    camera_out(
                        camera_ids={"cam1", "cam2", "cam4", "cam5"},
                        command="start_capture",
                        refresh_interval=cfg.ACTIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                ]
            ),
            # 5 EV - the flow continues...
            TestScenarioEntry(
                input_data=ev_message_in(
                    camera_id="cam2",
                    detected_edges={"P2.1", "P2.2"},
                    missing_edges=set()
                ),
                etcd_outputs=[
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.first_ply_covered_without_invisible_edge),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.second_ply_placed),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.third_ply_expected),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.sixth_ply_expected),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam1": {"detectedEdges": ["P2.1"]},
                        "cam2": {"detectedEdges": ["P2.1", "P2.2"], "missingEdges": ["P3.1"]},
                        "cam3": {"detectedEdges": ["P4.1"], "missingEdges": ["P3.2"]},
                        "cam4": {"detectedEdges": ["P5.1", "P5.2"], "missingEdges": ["P6.1"]},
                        "cam5": {"missingEdges": ["P6.1", "P6.2"]}},
                        session_cam_id="cam2"
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_P": {"pallets": {"pallet_1": {"missingPlies": 0,
                                                                                       "placedPlies": 2,
                                                                                       "totalPlies": 3},
                                                                          "pallet_2": {"missingPlies": 0,
                                                                                       "placedPlies": 2,
                                                                                       "totalPlies": 3}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_P_1,
                            mock_data.TeamInstructions.pallet_P_2,
                        ],
                            session=ev_message_session("cam2")
                        ),
                        "correctlyPlacedPlies": {
                            **mock_data.StaticGraph.FirstPalletP.second_ply,
                        },
                        "pliesToBePlaced": {
                            **mock_data.StaticGraph.FirstPalletP.third_ply_covers_next_pallet_plies,
                            **mock_data.StaticGraph.SecondPalletP.sixth_ply,
                        },
                        "newMissingPlies": {},
                        "noLongerMissingPlies": {},
                        "forcedPlies": {},
                        "removedPlies": {}
                    }),
                    laser_out(payload=mock_data.LaserFeedbacks.CorrectlyPlacedPlies.FirstPalletP.second_ply),
                    laser_out(
                        payload=mock_data.LaserFeedbacks.PliesToBePlaced.FirstPalletP.third_ply_covers_next_pallet_plies),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.SecondPalletP.sixth_ply),
                    camera_out(
                        camera_ids={"cam1"},
                        command="start_capture",
                        refresh_interval=cfg.PASSIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                    camera_out(
                        camera_ids={"cam2", "cam3", "cam4", "cam5"},
                        command="start_capture",
                        refresh_interval=cfg.ACTIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                ]
            ),
            # 6 EV
            TestScenarioEntry(
                input_data=ev_message_in(
                    camera_id="cam5",
                    detected_edges={"P6.1", "P6.2"},
                    missing_edges=set()
                ),
                etcd_outputs=[
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.third_ply_expected),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.fifth_ply_partially_covered),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.sixth_ply_placed),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam1": {"detectedEdges": ["P2.1"]},
                        "cam2": {"detectedEdges": ["P2.1", "P2.2"], "missingEdges": ["P3.1"]},
                        "cam3": {"detectedEdges": ["P4.1"], "missingEdges": ["P3.2"]},
                        "cam4": {"detectedEdges": ["P5.1", "P6.1"]},
                        "cam5": {"detectedEdges": ["P6.1", "P6.2"]}},
                        session_cam_id="cam5"
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_P": {"pallets": {"pallet_1": {"missingPlies": 0,
                                                                                       "placedPlies": 2,
                                                                                       "totalPlies": 3},
                                                                          "pallet_2": {"missingPlies": 0,
                                                                                       "placedPlies": 3,
                                                                                       "totalPlies": 3}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_P_1,
                            mock_data.TeamInstructions.pallet_P_2,
                        ],
                            session=ev_message_session("cam5")
                        ),
                        "correctlyPlacedPlies": {
                            **mock_data.StaticGraph.SecondPalletP.sixth_ply,
                        },
                        "pliesToBePlaced": {
                            **mock_data.StaticGraph.FirstPalletP.third_ply_covers_next_pallet_plies,
                        },
                        "newMissingPlies": {},
                        "noLongerMissingPlies": {},
                        "forcedPlies": {},
                        "removedPlies": {}
                    }),
                    laser_out(payload=mock_data.LaserFeedbacks.CorrectlyPlacedPlies.SecondPalletP.sixth_ply),
                    laser_out(
                        payload=mock_data.LaserFeedbacks.PliesToBePlaced.FirstPalletP.third_ply_covers_next_pallet_plies),
                    camera_out(
                        camera_ids={"cam1", "cam4", "cam5"},
                        command="start_capture",
                        refresh_interval=cfg.PASSIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                    camera_out(
                        camera_ids={"cam2", "cam3"},
                        command="start_capture",
                        refresh_interval=cfg.ACTIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                ]
            ),
        ]
        return {
            "entries": entries,
            "initial_mould_state_plies_data": mould_state_plies_data([
                mock_data.MouldStatePlies.PalletP.first_ply_covered_without_invisible_edge,
                mock_data.MouldStatePlies.PalletP.second_ply_partially_covered_on_placed,
                mock_data.MouldStatePlies.PalletP.third_ply_placed_updated_by_cam_3,
                mock_data.MouldStatePlies.PalletP.fourth_ply_fully_covered_by_P3,
                mock_data.MouldStatePlies.PalletP.fifth_ply_partially_covered_by_P3,
                mock_data.MouldStatePlies.PalletP.sixth_ply_expected,
            ]),
            "graph_data": {
                "mould_id": "mould_id",
                "blade_revision": "blade_revision",
                "version": "v1.0.0",
                "plies": {
                    **mock_data.StaticGraph.FirstPalletP.first_ply,
                    **mock_data.StaticGraph.FirstPalletP.second_ply,
                    **mock_data.StaticGraph.FirstPalletP.third_ply_covers_next_pallet_plies,
                    **mock_data.StaticGraph.SecondPalletP.fourth_ply_does_not_cover_third_ply,
                    **mock_data.StaticGraph.SecondPalletP.fifth_ply,
                    **mock_data.StaticGraph.SecondPalletP.sixth_ply,
                }
            },
        }

    @staticmethod
    def test_should_correctly_undo_some_plies_when_middle_ply_and_graph_plies_with_multiple_dependents_given():
        entries = [
            # 1 TI - to initialise mould state
            TestScenarioEntry(
                input_data=add_team_instruction_c2dm_request(instruction=mock_data.TeamInstructions.pallet_P_1),
            ),
            # 2
            TestScenarioEntry(
                input_data=add_team_instruction_c2dm_request(instruction=mock_data.TeamInstructions.pallet_P_2),
            ),
            # 3 undo_plies_to command
            TestScenarioEntry(
                input_data=undo_plies_to_c2dm_request("P3"),
                etcd_outputs=[
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.second_ply_partially_covered_reset_due_undo),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.third_ply_placed_reset_due_undo),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.fourth_ply_fully_covered_by_P3_reset_due_undo),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.fifth_ply_partially_covered_reset_due_undo),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam1": {"detectedEdges": ["P2.1"]},
                        "cam2": {"detectedEdges": ["P2.1", "P2.2"], "missingEdges": ["P3.1"]},
                        "cam3": {"detectedEdges": ["P4.1"], "missingEdges": ["P3.2"]},
                        "cam4": {"detectedEdges": ["P5.1", "P5.2"], "missingEdges": ["P6.1"]},
                        "cam5": {"missingEdges": ["P6.1", "P6.2"]}},
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_P": {"pallets": {"pallet_1": {"missingPlies": 0,
                                                                                       "placedPlies": 2,
                                                                                       "totalPlies": 3},
                                                                          "pallet_2": {"missingPlies": 0,
                                                                                       "placedPlies": 2,
                                                                                       "totalPlies": 3}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_P_1,
                            mock_data.TeamInstructions.pallet_P_2
                        ]),
                        "correctlyPlacedPlies": {},
                        "pliesToBePlaced": {
                            **mock_data.StaticGraph.FirstPalletP.third_ply_covers_next_pallet_plies,
                            **mock_data.StaticGraph.SecondPalletP.sixth_ply,
                        },
                        "newMissingPlies": {},
                        "noLongerMissingPlies": {},
                        "forcedPlies": {},
                        "removedPlies": {}
                    }),
                    laser_out(
                        payload=mock_data.LaserFeedbacks.PliesToBePlaced.FirstPalletP.third_ply_covers_next_pallet_plies),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.SecondPalletP.sixth_ply),
                    camera_out(
                        camera_ids={"cam1"},
                        command="start_capture",
                        refresh_interval=cfg.PASSIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                    camera_out(
                        camera_ids={"cam2", "cam3", "cam4", "cam5"},
                        command="start_capture",
                        refresh_interval=cfg.ACTIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                ]
            ),
            # 4 the flow continuous...
            TestScenarioEntry(
                input_data=ev_message_in(
                    camera_id="cam2",
                    detected_edges={"P3.1"},
                    missing_edges=set(),
                ),
                etcd_outputs=[
                    etcd_ply_out(
                        ply=mock_data.MouldStatePlies.PalletP.third_ply_expected_cam2_edge_detected_after_reset_on_placed),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.sixth_ply_expected),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam1": {"detectedEdges": ["P2.1"]},
                        "cam2": {"detectedEdges": ["P2.1", "P2.2", "P3.1"]},
                        "cam3": {"detectedEdges": ["P4.1"], "missingEdges": ["P3.2"]},
                        "cam4": {"detectedEdges": ["P5.1", "P5.2"], "missingEdges": ["P6.1"]},
                        "cam5": {"missingEdges": ["P6.1", "P6.2"]}},
                        session_cam_id="cam2"
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_P": {"pallets": {"pallet_1": {"missingPlies": 0,
                                                                                       "placedPlies": 2,
                                                                                       "totalPlies": 3},
                                                                          "pallet_2": {"missingPlies": 0,
                                                                                       "placedPlies": 2,
                                                                                       "totalPlies": 3}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_P_1,
                            mock_data.TeamInstructions.pallet_P_2,
                        ],
                            session=ev_message_session("cam2")
                        ),
                        "correctlyPlacedPlies": {},
                        "pliesToBePlaced": {
                            **mock_data.StaticGraph.FirstPalletP.third_ply_covers_next_pallet_plies,
                            **mock_data.StaticGraph.SecondPalletP.sixth_ply,
                        },
                        "newMissingPlies": {},
                        "noLongerMissingPlies": {},
                        "forcedPlies": {},
                        "removedPlies": {}
                    }),
                    laser_out(
                        payload=mock_data.LaserFeedbacks.PliesToBePlaced.FirstPalletP.third_ply_covers_next_pallet_plies),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.SecondPalletP.sixth_ply),
                    camera_out(
                        camera_ids={"cam1"},
                        command="start_capture",
                        refresh_interval=cfg.PASSIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                    camera_out(
                        camera_ids={"cam2", "cam3", "cam4", "cam5"},
                        command="start_capture",
                        refresh_interval=cfg.ACTIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                ]
            ),
            # 5 EV
            TestScenarioEntry(
                input_data=ev_message_in(
                    camera_id="cam3",
                    detected_edges={"P3.2"},
                    missing_edges=set(),
                ),
                etcd_outputs=[
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.second_ply_partially_covered_on_placed),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.third_ply_placed_updated_by_cam_3),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.fourth_ply_fully_covered_by_P3),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.fifth_ply_partially_covered_by_P3),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.sixth_ply_expected),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam1": {"detectedEdges": ["P2.1"]},
                        "cam2": {"detectedEdges": ["P2.1", "P3.1"]},
                        "cam3": {"detectedEdges": ["P3.2"]},
                        "cam4": {"detectedEdges": ["P5.2"], "missingEdges": ["P6.1"]},
                        "cam5": {"missingEdges": ["P6.1", "P6.2"]}},
                        session_cam_id="cam3"
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_P": {"pallets": {"pallet_1": {"missingPlies": 0,
                                                                                       "placedPlies": 3,
                                                                                       "totalPlies": 3},
                                                                          "pallet_2": {"missingPlies": 0,
                                                                                       "placedPlies": 2,
                                                                                       "totalPlies": 3}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_P_1,
                            mock_data.TeamInstructions.pallet_P_2,
                        ],
                            session=ev_message_session("cam3")
                        ),
                        "correctlyPlacedPlies": {
                            **mock_data.StaticGraph.FirstPalletP.third_ply_covers_next_pallet_plies,
                        },
                        "pliesToBePlaced": {
                            **mock_data.StaticGraph.SecondPalletP.sixth_ply,
                        },
                        "newMissingPlies": {},
                        "noLongerMissingPlies": {},
                        "forcedPlies": {},
                        "removedPlies": {}
                    }),
                    laser_out(
                        payload=mock_data.LaserFeedbacks.CorrectlyPlacedPlies.FirstPalletP.third_ply_covers_next_pallet_plies),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.SecondPalletP.sixth_ply),
                    camera_out(
                        camera_ids={"cam1", "cam2", "cam3"},
                        command="start_capture",
                        refresh_interval=cfg.PASSIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                    camera_out(
                        camera_ids={"cam4", "cam5"},
                        command="start_capture",
                        refresh_interval=cfg.ACTIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                ]
            ),
            # 6 EV
            TestScenarioEntry(
                input_data=ev_message_in(
                    camera_id="cam5",
                    detected_edges={"P6.1", "P6.2"},
                    missing_edges=set()
                ),
                etcd_outputs=[
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.fifth_ply_fully_covered),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.sixth_ply_placed),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam1": {"detectedEdges": ["P2.1"]},
                        "cam2": {"detectedEdges": ["P2.1", "P3.1"]},
                        "cam3": {"detectedEdges": ["P3.2"]},
                        "cam4": {"detectedEdges": ["P6.1"]},
                        "cam5": {"detectedEdges": ["P6.1", "P6.2"]}},
                        session_cam_id="cam5"
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_P": {"pallets": {"pallet_1": {"missingPlies": 0,
                                                                                       "placedPlies": 3,
                                                                                       "totalPlies": 3},
                                                                          "pallet_2": {"missingPlies": 0,
                                                                                       "placedPlies": 3,
                                                                                       "totalPlies": 3}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_P_1,
                            mock_data.TeamInstructions.pallet_P_2,
                        ],
                            session=ev_message_session("cam5")
                        ),
                        "correctlyPlacedPlies": {
                            **mock_data.StaticGraph.SecondPalletP.sixth_ply,
                        },
                        "pliesToBePlaced": {},
                        "newMissingPlies": {},
                        "noLongerMissingPlies": {},
                        "forcedPlies": {},
                        "removedPlies": {}
                    }),
                    laser_out(payload=mock_data.LaserFeedbacks.LastPliesPlaced.SecondPalletP.sixth_ply),
                    camera_out(
                        camera_ids={"cam1", "cam2", "cam3", "cam4", "cam5"},
                        command="start_capture",
                        refresh_interval=cfg.PASSIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                ]
            ),
        ]
        return {
            "entries": entries,
            "initial_mould_state_plies_data": mould_state_plies_data([
                mock_data.MouldStatePlies.PalletP.first_ply_covered_without_invisible_edge,
                mock_data.MouldStatePlies.PalletP.second_ply_partially_covered_on_placed,
                mock_data.MouldStatePlies.PalletP.third_ply_placed_updated_by_cam_3,
                mock_data.MouldStatePlies.PalletP.fourth_ply_fully_covered_by_P3,
                mock_data.MouldStatePlies.PalletP.fifth_ply_partially_covered_by_P3,
                mock_data.MouldStatePlies.PalletP.sixth_ply_expected,
            ]),
            "graph_data": {
                "mould_id": "mould_id",
                "blade_revision": "blade_revision",
                "version": "v1.0.0",
                "plies": {
                    **mock_data.StaticGraph.FirstPalletP.first_ply,
                    **mock_data.StaticGraph.FirstPalletP.second_ply,
                    **mock_data.StaticGraph.FirstPalletP.third_ply_covers_next_pallet_plies,
                    **mock_data.StaticGraph.SecondPalletP.fourth_ply_does_not_cover_third_ply,
                    **mock_data.StaticGraph.SecondPalletP.fifth_ply,
                    **mock_data.StaticGraph.SecondPalletP.sixth_ply,
                }
            },
        }

    @staticmethod
    def test_should_correctly_undo_all_plies_when_initial_ply_and_graph_plies_with_multiple_dependents_between_pallets_given():
        entries = [
            # 1 TI - to initialise mould state
            TestScenarioEntry(
                input_data=add_team_instruction_c2dm_request(instruction=mock_data.TeamInstructions.pallet_P_1),
            ),
            # 2
            TestScenarioEntry(
                input_data=add_team_instruction_c2dm_request(instruction=mock_data.TeamInstructions.pallet_P_2),
            ),
            # 3 undo_plies_to command
            TestScenarioEntry(
                input_data=undo_plies_to_c2dm_request("P1"),
                etcd_outputs=[
                    etcd_ply_out(
                        ply=mock_data.MouldStatePlies.PalletP.first_ply_covered_without_invisible_edge_reset_due_undo),
                    etcd_ply_out(
                        ply=mock_data.MouldStatePlies.PalletP.first_ply_placed_without_invisible_edge_reset_due_undo),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.second_ply_partially_covered_reset_due_undo),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.second_ply_placed_reset_due_undo),
                    etcd_ply_delete_out("P2"),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.third_ply_placed_reset_due_undo),
                    etcd_ply_delete_out("P3"),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.fourth_ply_fully_covered_by_P3_reset_due_undo),
                    etcd_ply_out(
                        ply=mock_data.MouldStatePlies.PalletP.fourth_ply_partially_covered_reset_due_undo_after_fully_covered),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.fourth_ply_placed_reset_due_undo),
                    etcd_ply_delete_out("P4"),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.fifth_ply_partially_covered_reset_due_undo),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.fifth_ply_placed_reset_due_undo),
                    etcd_ply_delete_out("P5"),
                    etcd_ply_delete_out("P6"),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam1": {"missingEdges": ["P1.2"]}},
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_P": {"pallets": {"pallet_1": {"missingPlies": 0,
                                                                                       "placedPlies": 0,
                                                                                       "totalPlies": 3},
                                                                          "pallet_2": {"missingPlies": 0,
                                                                                       "placedPlies": 0,
                                                                                       "totalPlies": 3}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_P_1,
                            mock_data.TeamInstructions.pallet_P_2
                        ]),
                        "correctlyPlacedPlies": {},
                        "pliesToBePlaced": {
                            **mock_data.StaticGraph.FirstPalletP.first_ply_invisible_edge_removed,
                        },
                        "newMissingPlies": {},
                        "noLongerMissingPlies": {},
                        "forcedPlies": {},
                        "removedPlies": {
                            **mock_data.StaticGraph.FirstPalletP.second_ply,
                            **mock_data.StaticGraph.FirstPalletP.third_ply_covers_next_pallet_plies,
                            **mock_data.StaticGraph.SecondPalletP.fourth_ply_depends_on_second_ply,
                            **mock_data.StaticGraph.SecondPalletP.fifth_ply,
                            **mock_data.StaticGraph.SecondPalletP.sixth_ply,
                        }
                    }),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.FirstPalletP.first_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToNull.FirstPalletP.second_ply),
                    laser_out(
                        payload=mock_data.LaserFeedbacks.PliesToNull.FirstPalletP.third_ply_covers_next_pallet_plies),
                    laser_out(
                        payload=mock_data.LaserFeedbacks.PliesToNull.SecondPalletP.fourth_ply_depends_on_second_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToNull.SecondPalletP.fifth_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToNull.SecondPalletP.sixth_ply),
                    camera_out(
                        camera_ids={"cam1"},
                        command="start_capture",
                        refresh_interval=cfg.ACTIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                ]
            ),
            # 4 on EV msg new expected ply is detected and becomes placed
            TestScenarioEntry(
                input_data=ev_message_in(
                    camera_id="cam1",
                    detected_edges={"P1.2"},
                    missing_edges=set()
                ),
                etcd_outputs=[
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.first_ply_placed_without_invisible_edge),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.second_ply_expected),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam1": {"detectedEdges": ["P1.2"], "missingEdges": ["P2.1"]},
                        "cam2": {"missingEdges": ["P2.1", "P2.2"]}},
                        session_cam_id="cam1"
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_P": {"pallets": {"pallet_1": {"missingPlies": 0,
                                                                                       "placedPlies": 1,
                                                                                       "totalPlies": 3},
                                                                          "pallet_2": {"missingPlies": 0,
                                                                                       "placedPlies": 0,
                                                                                       "totalPlies": 3}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_P_1,
                            mock_data.TeamInstructions.pallet_P_2,
                        ],
                            session=ev_message_session("cam1")
                        ),
                        "correctlyPlacedPlies": {
                            **mock_data.StaticGraph.FirstPalletP.first_ply_invisible_edge_removed,
                        },
                        "pliesToBePlaced": {
                            **mock_data.StaticGraph.FirstPalletP.second_ply,
                        },
                        "newMissingPlies": {},
                        "noLongerMissingPlies": {},
                        "forcedPlies": {},
                        "removedPlies": {}
                    }),
                    laser_out(payload=mock_data.LaserFeedbacks.CorrectlyPlacedPlies.FirstPalletP.first_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.FirstPalletP.second_ply),
                    camera_out(
                        camera_ids={"cam1", "cam2"},
                        command="start_capture",
                        refresh_interval=cfg.ACTIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                ]
            ),
            # 5 EV - the flow continues...
            TestScenarioEntry(
                input_data=ev_message_in(
                    camera_id="cam2",
                    detected_edges={"P2.1", "P2.2"},
                    missing_edges=set()
                ),
                etcd_outputs=[
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.first_ply_covered_without_invisible_edge),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.second_ply_placed),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.fourth_ply_expected),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam1": {"detectedEdges": ["P2.1"]},
                        "cam2": {"detectedEdges": ["P2.1", "P2.2"]},
                        "cam3": {"missingEdges": ["P4.1", "P4.2"]},
                        "cam4": {"missingEdges": ["P4.2"]}},
                        session_cam_id="cam2"
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_P": {"pallets": {"pallet_1": {"missingPlies": 0,
                                                                                       "placedPlies": 2,
                                                                                       "totalPlies": 3},
                                                                          "pallet_2": {"missingPlies": 0,
                                                                                       "placedPlies": 0,
                                                                                       "totalPlies": 3}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_P_1,
                            mock_data.TeamInstructions.pallet_P_2,
                        ],
                            session=ev_message_session("cam2")
                        ),
                        "correctlyPlacedPlies": {
                            **mock_data.StaticGraph.FirstPalletP.second_ply,
                        },
                        "pliesToBePlaced": {
                            **mock_data.StaticGraph.SecondPalletP.fourth_ply_depends_on_second_ply,
                        },
                        "newMissingPlies": {},
                        "noLongerMissingPlies": {},
                        "forcedPlies": {},
                        "removedPlies": {}
                    }),
                    laser_out(payload=mock_data.LaserFeedbacks.CorrectlyPlacedPlies.FirstPalletP.second_ply),
                    laser_out(
                        payload=mock_data.LaserFeedbacks.PliesToBePlaced.SecondPalletP.fourth_ply_depends_on_second_ply),
                    camera_out(
                        camera_ids={"cam2", "cam1"},
                        command="start_capture",
                        refresh_interval=cfg.PASSIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                    camera_out(
                        camera_ids={"cam3", "cam4"},
                        command="start_capture",
                        refresh_interval=cfg.ACTIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                ]
            ),
            # 6 EV
            TestScenarioEntry(
                input_data=ev_message_in(
                    camera_id="cam3",
                    detected_edges={"P4.1", "P4.2"},
                    missing_edges=set()
                ),
                etcd_outputs=[
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.fourth_ply_placed),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.fifth_ply_expected),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam1": {"detectedEdges": ["P2.1"]},
                        "cam2": {"detectedEdges": ["P2.1", "P2.2"]},
                        "cam3": {"detectedEdges": ["P4.1", "P4.2"]},
                        "cam4": {"detectedEdges": ["P4.2"],
                                 "missingEdges": ["P5.1", "P5.2"]}},
                        session_cam_id="cam3"
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_P": {"pallets": {"pallet_1": {"missingPlies": 0,
                                                                                       "placedPlies": 2,
                                                                                       "totalPlies": 3},
                                                                          "pallet_2": {"missingPlies": 0,
                                                                                       "placedPlies": 1,
                                                                                       "totalPlies": 3}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_P_1,
                            mock_data.TeamInstructions.pallet_P_2,
                        ],
                            session=ev_message_session("cam3")
                        ),
                        "correctlyPlacedPlies": {
                            **mock_data.StaticGraph.SecondPalletP.fourth_ply_depends_on_second_ply,
                        },
                        "pliesToBePlaced": {
                            **mock_data.StaticGraph.SecondPalletP.fifth_ply,
                        },
                        "newMissingPlies": {},
                        "noLongerMissingPlies": {},
                        "forcedPlies": {},
                        "removedPlies": {}
                    }),
                    laser_out(
                        payload=mock_data.LaserFeedbacks.CorrectlyPlacedPlies.SecondPalletP.fourth_ply_depends_on_second_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.SecondPalletP.fifth_ply),
                    camera_out(
                        camera_ids={"cam2", "cam1", "cam3"},
                        command="start_capture",
                        refresh_interval=cfg.PASSIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                    camera_out(
                        camera_ids={"cam4"},
                        command="start_capture",
                        refresh_interval=cfg.ACTIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                ]
            ),
            # 7 EV
            TestScenarioEntry(
                input_data=ev_message_in(
                    camera_id="cam4",
                    detected_edges={"P5.1", "P5.2"},
                    missing_edges=set()
                ),
                etcd_outputs=[
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.fourth_ply_partially_covered),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.fifth_ply_placed),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.third_ply_expected),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.sixth_ply_expected),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam1": {"detectedEdges": ["P2.1"]},
                        "cam2": {"detectedEdges": ["P2.1", "P2.2"], "missingEdges": ["P3.1"]},
                        "cam3": {"detectedEdges": ["P4.1"], "missingEdges": ["P3.2"]},
                        "cam4": {"detectedEdges": ["P5.1", "P5.2"], "missingEdges": ["P6.1"]},
                        "cam5": {"missingEdges": ["P6.1", "P6.2"]}},
                        session_cam_id="cam4"
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_P": {"pallets": {"pallet_1": {"missingPlies": 0,
                                                                                       "placedPlies": 2,
                                                                                       "totalPlies": 3},
                                                                          "pallet_2": {"missingPlies": 0,
                                                                                       "placedPlies": 2,
                                                                                       "totalPlies": 3}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_P_1,
                            mock_data.TeamInstructions.pallet_P_2,
                        ],
                            session=ev_message_session("cam4")
                        ),
                        "correctlyPlacedPlies": {
                            **mock_data.StaticGraph.SecondPalletP.fifth_ply,
                        },
                        "pliesToBePlaced": {
                            **mock_data.StaticGraph.FirstPalletP.third_ply_covers_next_pallet_plies,
                            **mock_data.StaticGraph.SecondPalletP.sixth_ply,
                        },
                        "newMissingPlies": {},
                        "noLongerMissingPlies": {},
                        "forcedPlies": {},
                        "removedPlies": {}
                    }),
                    laser_out(payload=mock_data.LaserFeedbacks.CorrectlyPlacedPlies.SecondPalletP.fifth_ply),
                    laser_out(
                        payload=mock_data.LaserFeedbacks.PliesToBePlaced.FirstPalletP.third_ply_covers_next_pallet_plies),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.SecondPalletP.sixth_ply),
                    camera_out(
                        camera_ids={"cam1"},
                        command="start_capture",
                        refresh_interval=cfg.PASSIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                    camera_out(
                        camera_ids={"cam2", "cam3", "cam4", "cam5"},
                        command="start_capture",
                        refresh_interval=cfg.ACTIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                ]
            ),
            # EV 8
            TestScenarioEntry(
                input_data=ev_message_in(
                    camera_id="cam2",
                    detected_edges={"P3.1"},
                    missing_edges=set(),
                ),
                etcd_outputs=[
                    etcd_ply_out(
                        ply=mock_data.MouldStatePlies.PalletP.third_ply_expected_cam2_edge_detected),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.sixth_ply_expected),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam1": {"detectedEdges": ["P2.1"]},
                        "cam2": {"detectedEdges": ["P2.1", "P2.2", "P3.1"]},
                        "cam3": {"detectedEdges": ["P4.1"], "missingEdges": ["P3.2"]},
                        "cam4": {"detectedEdges": ["P5.1", "P5.2"], "missingEdges": ["P6.1"]},
                        "cam5": {"missingEdges": ["P6.1", "P6.2"]}},
                        session_cam_id="cam2"
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_P": {"pallets": {"pallet_1": {"missingPlies": 0,
                                                                                       "placedPlies": 2,
                                                                                       "totalPlies": 3},
                                                                          "pallet_2": {"missingPlies": 0,
                                                                                       "placedPlies": 2,
                                                                                       "totalPlies": 3}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_P_1,
                            mock_data.TeamInstructions.pallet_P_2,
                        ],
                            session=ev_message_session("cam2")
                        ),
                        "correctlyPlacedPlies": {},
                        "pliesToBePlaced": {
                            **mock_data.StaticGraph.FirstPalletP.third_ply_covers_next_pallet_plies,
                            **mock_data.StaticGraph.SecondPalletP.sixth_ply,
                        },
                        "newMissingPlies": {},
                        "noLongerMissingPlies": {},
                        "forcedPlies": {},
                        "removedPlies": {}
                    }),
                    laser_out(
                        payload=mock_data.LaserFeedbacks.PliesToBePlaced.FirstPalletP.third_ply_covers_next_pallet_plies),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.SecondPalletP.sixth_ply),
                    camera_out(
                        camera_ids={"cam1"},
                        command="start_capture",
                        refresh_interval=cfg.PASSIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                    camera_out(
                        camera_ids={"cam2", "cam3", "cam4", "cam5"},
                        command="start_capture",
                        refresh_interval=cfg.ACTIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                ]
            ),
            # 9 EV
            TestScenarioEntry(
                input_data=ev_message_in(
                    camera_id="cam3",
                    detected_edges={"P3.2"},
                    missing_edges=set(),
                ),
                etcd_outputs=[
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.second_ply_partially_covered_on_placed),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.third_ply_placed_updated_by_cam_3),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.fourth_ply_fully_covered_by_P3),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.fifth_ply_partially_covered_by_P3),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.sixth_ply_expected),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam1": {"detectedEdges": ["P2.1"]},
                        "cam2": {"detectedEdges": ["P2.1", "P3.1"]},
                        "cam3": {"detectedEdges": ["P3.2"]},
                        "cam4": {"detectedEdges": ["P5.2"], "missingEdges": ["P6.1"]},
                        "cam5": {"missingEdges": ["P6.1", "P6.2"]}},
                        session_cam_id="cam3"
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_P": {"pallets": {"pallet_1": {"missingPlies": 0,
                                                                                       "placedPlies": 3,
                                                                                       "totalPlies": 3},
                                                                          "pallet_2": {"missingPlies": 0,
                                                                                       "placedPlies": 2,
                                                                                       "totalPlies": 3}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_P_1,
                            mock_data.TeamInstructions.pallet_P_2,
                        ],
                            session=ev_message_session("cam3")
                        ),
                        "correctlyPlacedPlies": {
                            **mock_data.StaticGraph.FirstPalletP.third_ply_covers_next_pallet_plies,
                        },
                        "pliesToBePlaced": {
                            **mock_data.StaticGraph.SecondPalletP.sixth_ply,
                        },
                        "newMissingPlies": {},
                        "noLongerMissingPlies": {},
                        "forcedPlies": {},
                        "removedPlies": {}
                    }),
                    laser_out(
                        payload=mock_data.LaserFeedbacks.CorrectlyPlacedPlies.FirstPalletP.third_ply_covers_next_pallet_plies),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.SecondPalletP.sixth_ply),
                    camera_out(
                        camera_ids={"cam1", "cam2", "cam3"},
                        command="start_capture",
                        refresh_interval=cfg.PASSIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                    camera_out(
                        camera_ids={"cam4", "cam5"},
                        command="start_capture",
                        refresh_interval=cfg.ACTIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                ]
            ),
            # EV 10
            TestScenarioEntry(
                input_data=ev_message_in(
                    camera_id="cam5",
                    detected_edges={"P6.1", "P6.2"},
                    missing_edges=set()
                ),
                etcd_outputs=[
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.fifth_ply_fully_covered),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.sixth_ply_placed),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam1": {"detectedEdges": ["P2.1"]},
                        "cam2": {"detectedEdges": ["P2.1", "P3.1"]},
                        "cam3": {"detectedEdges": ["P3.2"]},
                        "cam4": {"detectedEdges": ["P6.1"]},
                        "cam5": {"detectedEdges": ["P6.1", "P6.2"]}},
                        session_cam_id="cam5"
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_P": {"pallets": {"pallet_1": {"missingPlies": 0,
                                                                                       "placedPlies": 3,
                                                                                       "totalPlies": 3},
                                                                          "pallet_2": {"missingPlies": 0,
                                                                                       "placedPlies": 3,
                                                                                       "totalPlies": 3}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_P_1,
                            mock_data.TeamInstructions.pallet_P_2,
                        ],
                            session=ev_message_session("cam5")
                        ),
                        "correctlyPlacedPlies": {
                            **mock_data.StaticGraph.SecondPalletP.sixth_ply,
                        },
                        "pliesToBePlaced": {},
                        "newMissingPlies": {},
                        "noLongerMissingPlies": {},
                        "forcedPlies": {},
                        "removedPlies": {}
                    }),
                    laser_out(payload=mock_data.LaserFeedbacks.LastPliesPlaced.SecondPalletP.sixth_ply),
                    camera_out(
                        camera_ids={"cam1", "cam2", "cam3", "cam4", "cam5"},
                        command="start_capture",
                        refresh_interval=cfg.PASSIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                ]
            ),
        ]
        return {
            "entries": entries,
            "initial_mould_state_plies_data": mould_state_plies_data([
                mock_data.MouldStatePlies.PalletP.first_ply_covered_without_invisible_edge,
                mock_data.MouldStatePlies.PalletP.second_ply_partially_covered_on_placed,
                mock_data.MouldStatePlies.PalletP.third_ply_placed_updated_by_cam_3,
                mock_data.MouldStatePlies.PalletP.fourth_ply_fully_covered_by_P3,
                mock_data.MouldStatePlies.PalletP.fifth_ply_partially_covered_by_P3,
                mock_data.MouldStatePlies.PalletP.sixth_ply_expected,
            ]),
            "graph_data": {
                "mould_id": "mould_id",
                "blade_revision": "blade_revision",
                "version": "v1.0.0",
                "plies": {
                    **mock_data.StaticGraph.FirstPalletP.first_ply,
                    **mock_data.StaticGraph.FirstPalletP.second_ply,
                    **mock_data.StaticGraph.FirstPalletP.third_ply_covers_next_pallet_plies,
                    **mock_data.StaticGraph.SecondPalletP.fourth_ply_depends_on_second_ply,
                    **mock_data.StaticGraph.SecondPalletP.fifth_ply,
                    **mock_data.StaticGraph.SecondPalletP.sixth_ply,
                }
            },
        }
