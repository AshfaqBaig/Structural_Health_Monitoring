# pylint: disable=protected-access, missing-module-docstring, missing-class-docstring, missing-function-docstring, duplicate-code, line-too-long, too-few-public-methods, no-self-use, too-many-locals, too-many-lines
import tests.scenarios.mock_data as mock_data
from app.global_mould_state_enum import GlobalMouldState
from tests.scenarios.model.test_scenario_entry import TestScenarioEntry
from tests.scenarios.scenarios_base import add_team_instruction_c2dm_request, edge_verification_out, \
    camera_out, laser_out, etcd_remove_instructions, \
    etcd_remove_plies, ev_message_in, finalise_etcd_event_in, etcd_instruction_out, etcd_ply_out, etcd_mould_state_out, \
    etcd_mould_blade_sn_out


class EtcdMouldStateUpdateTestScenariosDtos:
    @staticmethod
    def should_finalise_when_in_production_and_finalised_state_received_via_etcd_update_event():
        entries = [
            # 1
            TestScenarioEntry(
                input_data=add_team_instruction_c2dm_request(instruction=mock_data.TeamInstructions.pallet_P_1),
                etcd_outputs=[
                    etcd_instruction_out(instruction=mock_data.TeamInstructions.pallet_P_1),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.first_ply_expected_without_invisible_edge),
                    etcd_mould_state_out(state=GlobalMouldState.PRODUCTION),
                    etcd_mould_blade_sn_out(blade_sn="blade_sn"),
                ],
            ),
            # 2
            TestScenarioEntry(
                input_data=ev_message_in(
                    camera_id="cam1",
                    detected_edges={"P1.2"},
                    missing_edges=set(),
                ),
            ),
            # 3
            TestScenarioEntry(
                input_data=ev_message_in(
                    camera_id="cam2",
                    detected_edges={"P2.1", "P2.2"},
                    missing_edges=set(),
                ),
            ),
            # 4
            TestScenarioEntry(
                input_data=add_team_instruction_c2dm_request(instruction=mock_data.TeamInstructions.pallet_P_2),
            ),
            # 5
            TestScenarioEntry(
                input_data=ev_message_in(
                    camera_id="cam3",
                    detected_edges={"P4.1", "P4.2"},
                    missing_edges=set(),
                ),
            ),
            # 6
            TestScenarioEntry(
                input_data=finalise_etcd_event_in(),
                etcd_outputs=[
                    etcd_remove_instructions(),
                    etcd_remove_plies(),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam1": {"detectedEdges": [], "missingEdges": []},
                        "cam2": {"detectedEdges": [], "missingEdges": []},
                        "cam3": {"detectedEdges": [], "missingEdges": []},
                        "cam4": {"detectedEdges": [], "missingEdges": []}},
                    ),
                    camera_out(
                        camera_ids={"cam1", "cam2", "cam3", "cam4"},
                        command="stop_capture",
                    ),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToNull.FirstPalletP.first_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToNull.FirstPalletP.second_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToNull.FirstPalletP.third_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToNull.SecondPalletP.fourth_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToNull.SecondPalletP.fifth_ply),
                ]
            ),
        ]
        return {
            "entries": entries,
        }

    @staticmethod
    def should_not_finalise_when_not_in_production_and_finalised_state_received_via_etcd_update_event():
        entries = [
            TestScenarioEntry(
                input_data=finalise_etcd_event_in(),
                etcd_outputs=[],
                messaging_outputs=[]
            ),
        ]
        return {
            "entries": entries,
        }

    @staticmethod
    def should_not_finalise_when_finalised_state_received_second_times_in_a_row_via_etcd_update_event():
        entries = [
            TestScenarioEntry(
                input_data=add_team_instruction_c2dm_request(instruction=mock_data.TeamInstructions.pallet_P_1),
                etcd_outputs=[
                    etcd_instruction_out(instruction=mock_data.TeamInstructions.pallet_P_1),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.first_ply_expected_without_invisible_edge),
                    etcd_mould_state_out(state=GlobalMouldState.PRODUCTION),
                    etcd_mould_blade_sn_out(blade_sn="blade_sn"),
                ],
            ),
            TestScenarioEntry(
                input_data=ev_message_in(
                    camera_id="cam1",
                    detected_edges={"P1.2"},
                    missing_edges=set(),
                ),
            ),
            TestScenarioEntry(
                input_data=ev_message_in(
                    camera_id="cam2",
                    detected_edges={"P2.1", "P2.2"},
                    missing_edges=set(),
                ),
            ),
            TestScenarioEntry(
                input_data=add_team_instruction_c2dm_request(instruction=mock_data.TeamInstructions.pallet_P_2),
            ),
            TestScenarioEntry(
                input_data=ev_message_in(
                    camera_id="cam3",
                    detected_edges={"P4.1", "P4.2"},
                    missing_edges=set(),
                ),
            ),
            # When state update to FINALISED received first time
            TestScenarioEntry(
                input_data=finalise_etcd_event_in(),
                etcd_outputs=[
                    etcd_remove_instructions(),
                    etcd_remove_plies(),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam1": {"detectedEdges": [], "missingEdges": []},
                        "cam2": {"detectedEdges": [], "missingEdges": []},
                        "cam3": {"detectedEdges": [], "missingEdges": []},
                        "cam4": {"detectedEdges": [], "missingEdges": []}},
                    ),
                    camera_out(
                        camera_ids={"cam1", "cam2", "cam3", "cam4"},
                        command="stop_capture",
                    ),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToNull.FirstPalletP.first_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToNull.FirstPalletP.second_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToNull.FirstPalletP.third_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToNull.SecondPalletP.fourth_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToNull.SecondPalletP.fifth_ply),
                ]
            ),
            # When state update to FINALISED received second time in a row
            TestScenarioEntry(
                input_data=finalise_etcd_event_in(),
                etcd_outputs=[],
                messaging_outputs=[]
            ),
        ]
        return {
            "entries": entries,
        }
