# pylint: disable=protected-access, missing-module-docstring, missing-class-docstring, missing-function-docstring, duplicate-code, line-too-long, too-few-public-methods, no-self-use, too-many-locals, too-many-lines
import app.config as cfg
import tests.scenarios.mock_data as mock_data
from tests.scenarios.model.test_scenario_entry import TestScenarioEntry
from tests.scenarios.scenarios_base import add_team_instruction_c2dm_request, ev_message_in, edge_verification_out, \
    camera_out, laser_out, trace_out, etcd_ply_out, ev_message_session, etcd_ply_in, trace_out_metadata, \
    mould_state_plies_data, stats_out


class EtcdPlyUpdateDueToRecheckPlyCommandTestScenariosDtos:
    @staticmethod
    def should_correctly_handle_recheck_ply_update_when_missing_ply_rechecked():
        entries = [
            # 1 TI - to initialise mould state
            TestScenarioEntry(
                input_data=add_team_instruction_c2dm_request(instruction=mock_data.TeamInstructions.pallet_P_1),
                # etcd_outputs=[], - ignoring, do not assert
                # messaging_outputs=[], - ignoring, do not assert
            ),
            # 2 rechecked ply received via ETCD due to recheck_ply command
            TestScenarioEntry(
                input_data=etcd_ply_in(
                    mock_data.MouldStatePlies.PalletP.second_ply_recheck_on_missing_via_other_device),
                etcd_outputs=[],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam1": {"missingEdges": ["P2.1"]},
                        "cam2": {"missingEdges": ["P2.1", "P2.2", "P3.1"]},
                        "cam3": {"missingEdges": ["P3.2"]}},
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_P": {"pallets": {"pallet_1": {"missingPlies": 1,
                                                                                       "placedPlies": 2,
                                                                                       "totalPlies": 3}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_P_1
                        ]),
                        "correctlyPlacedPlies": {},
                        "pliesToBePlaced": {
                            **mock_data.StaticGraph.FirstPalletP.third_ply,
                        },
                        "newMissingPlies": {
                            **mock_data.StaticGraph.FirstPalletP.second_ply,
                        },
                        "noLongerMissingPlies": {},
                        "forcedPlies": {},
                        "removedPlies": {}
                    }),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.FirstPalletP.third_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.MissingPlies.FirstPalletP.second_ply),
                    camera_out(
                        camera_ids={"cam1", "cam2", "cam3"},
                        command="start_capture",
                        refresh_interval=cfg.ACTIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                ]
            ),
            # 3 on EV msg rechecked ply is detected and becomes placed
            TestScenarioEntry(
                input_data=ev_message_in(
                    camera_id="cam2",
                    detected_edges={"P2.1", "P2.2"},
                    missing_edges=set()
                ),
                etcd_outputs=[
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.second_ply_placed_after_missing),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.third_ply_expected),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam1": {"detectedEdges": ["P2.1"]},
                        "cam2": {"detectedEdges": ["P2.1", "P2.2"], "missingEdges": ["P3.1"]},
                        "cam3": {"missingEdges": ["P3.2"]}},
                        session_cam_id="cam2"
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_P": {"pallets": {"pallet_1": {"missingPlies": 0,
                                                                                       "placedPlies": 2,
                                                                                       "totalPlies": 3}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_P_1,
                        ],
                            session=ev_message_session("cam2")
                        ),
                        "correctlyPlacedPlies": {},
                        "pliesToBePlaced": {
                            **mock_data.StaticGraph.FirstPalletP.third_ply,
                        },
                        "newMissingPlies": {},
                        "noLongerMissingPlies": {
                            **mock_data.StaticGraph.FirstPalletP.second_ply,
                        },
                        "forcedPlies": {},
                        "removedPlies": {}
                    }),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.FirstPalletP.third_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToNull.FirstPalletP.second_ply),
                    camera_out(
                        camera_ids={"cam1"},
                        command="start_capture",
                        refresh_interval=cfg.PASSIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                    camera_out(
                        camera_ids={"cam2", "cam3"},
                        command="start_capture",
                        refresh_interval=cfg.ACTIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                ]
            ),
        ]
        return {
            "entries": entries,
            "initial_mould_state_plies_data": mould_state_plies_data([
                mock_data.MouldStatePlies.PalletP.first_ply_covered_without_invisible_edge,
                mock_data.MouldStatePlies.PalletP.second_ply_missing_by_cam2,
                mock_data.MouldStatePlies.PalletP.third_ply_expected,
            ]),
        }

    @staticmethod
    def should_correctly_handle_recheck_ply_update_when_partially_covered_and_missing_ply_recheck():
        entries = [
            # 1 TI - to initialise mould state
            TestScenarioEntry(
                input_data=add_team_instruction_c2dm_request(instruction=mock_data.TeamInstructions.pallet_P_1),
                # etcd_outputs=[], - ignoring, do not assert
                # messaging_outputs=[], - ignoring, do not assert
            ),
            # 2 rechecked ply received via ETCD due to recheck_ply command
            TestScenarioEntry(
                input_data=etcd_ply_in(
                    mock_data.MouldStatePlies.PalletP.second_ply_partially_covered_recheck_on_missing_via_other_device),
                etcd_outputs=[],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam1": {"missingEdges": ["P2.1"]},
                        "cam2": {"detectedEdges": ["P3.1"], "missingEdges": ["P2.1"]},
                        "cam3": {"detectedEdges": ["P3.2"]}},
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_P": {"pallets": {"pallet_1": {"missingPlies": 1,
                                                                                       "placedPlies": 3,
                                                                                       "totalPlies": 3}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_P_1
                        ]),
                        "correctlyPlacedPlies": {},
                        "pliesToBePlaced": {},
                        "newMissingPlies": {
                            **mock_data.StaticGraph.FirstPalletP.second_ply,
                        },
                        "noLongerMissingPlies": {},
                        "forcedPlies": {},
                        "removedPlies": {}
                    }),
                    laser_out(payload=mock_data.LaserFeedbacks.MissingPlies.FirstPalletP.second_ply),
                    camera_out(
                        camera_ids={"cam3"},
                        command="start_capture",
                        refresh_interval=cfg.PASSIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                    camera_out(
                        camera_ids={"cam1", "cam2"},
                        command="start_capture",
                        refresh_interval=cfg.ACTIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                ]
            ),
            # 3 on EV msg rechecked ply is detected and becomes placed
            TestScenarioEntry(
                input_data=ev_message_in(
                    camera_id="cam2",
                    detected_edges={"P2.1"},
                    missing_edges=set()
                ),
                etcd_outputs=[
                    etcd_ply_out(
                        ply=mock_data.MouldStatePlies.PalletP.second_ply_partially_covered_by_cam2_after_missing),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam1": {"detectedEdges": ["P2.1"]},
                        "cam2": {"detectedEdges": ["P2.1", "P3.1"]},
                        "cam3": {"detectedEdges": ["P3.2"]}},
                        session_cam_id="cam2"
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_P": {"pallets": {"pallet_1": {"missingPlies": 0,
                                                                                       "placedPlies": 3,
                                                                                       "totalPlies": 3}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_P_1,
                        ],
                            session=ev_message_session("cam2")
                        ),
                        "correctlyPlacedPlies": {},
                        "pliesToBePlaced": {},
                        "newMissingPlies": {},
                        "noLongerMissingPlies": {
                            **mock_data.StaticGraph.FirstPalletP.second_ply,
                        },
                        "forcedPlies": {},
                        "removedPlies": {}
                    }),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToNull.FirstPalletP.second_ply),
                    camera_out(
                        camera_ids={"cam1", "cam2", "cam3"},
                        command="start_capture",
                        refresh_interval=cfg.PASSIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                ]
            ),
        ]
        return {
            "entries": entries,
            "initial_mould_state_plies_data": mould_state_plies_data([
                mock_data.MouldStatePlies.PalletP.first_ply_covered_without_invisible_edge,
                mock_data.MouldStatePlies.PalletP.second_ply_partially_covered_and_missing_by_both_cams,
                mock_data.MouldStatePlies.PalletP.third_ply_placed_updated_by_cam_2,
            ]),
        }

    @staticmethod
    def should_correctly_handle_recheck_ply_update_when_partially_covered_ply_recheck():
        entries = [
            # 1 TI - to initialise mould state
            TestScenarioEntry(
                input_data=add_team_instruction_c2dm_request(instruction=mock_data.TeamInstructions.pallet_P_1),
                # etcd_outputs=[], - ignoring, do not assert
                # messaging_outputs=[], - ignoring, do not assert
            ),

            # 2 rechecked ply received via ETCD due to recheck_ply command
            TestScenarioEntry(
                input_data=etcd_ply_in(
                    mock_data.MouldStatePlies.PalletP.second_ply_partially_covered_recheck_on_placed_via_other_device),
                etcd_outputs=[],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam1": {"missingEdges": ["P2.1"]},
                        "cam2": {"detectedEdges": ["P3.1"], "missingEdges": ["P2.1"]},
                        "cam3": {"detectedEdges": ["P3.2"]}},
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_P": {"pallets": {"pallet_1": {"missingPlies": 1,
                                                                                       "placedPlies": 3,
                                                                                       "totalPlies": 3}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_P_1
                        ]),
                        "correctlyPlacedPlies": {},
                        "pliesToBePlaced": {},
                        "newMissingPlies": {
                            **mock_data.StaticGraph.FirstPalletP.second_ply,
                        },
                        "noLongerMissingPlies": {},
                        "forcedPlies": {},
                        "removedPlies": {}
                    }),
                    laser_out(payload=mock_data.LaserFeedbacks.MissingPlies.FirstPalletP.second_ply),
                    camera_out(
                        camera_ids={"cam3"},
                        command="start_capture",
                        refresh_interval=cfg.PASSIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                    camera_out(
                        camera_ids={"cam1", "cam2"},
                        command="start_capture",
                        refresh_interval=cfg.ACTIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                ]
            ),
            # 3 on EV msg rechecked ply is detected and becomes placed
            TestScenarioEntry(
                input_data=ev_message_in(
                    camera_id="cam2",
                    detected_edges={"P2.1"},
                    missing_edges=set()
                ),
                etcd_outputs=[
                    etcd_ply_out(
                        ply=mock_data.MouldStatePlies.PalletP.second_ply_partially_covered_by_cam2_after_missing),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam1": {"detectedEdges": ["P2.1"]},
                        "cam2": {"detectedEdges": ["P2.1", "P3.1"]},
                        "cam3": {"detectedEdges": ["P3.2"]}},
                        session_cam_id="cam2"
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_P": {"pallets": {"pallet_1": {"missingPlies": 0,
                                                                                       "placedPlies": 3,
                                                                                       "totalPlies": 3}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_P_1,
                        ],
                            session=ev_message_session("cam2")
                        ),
                        "correctlyPlacedPlies": {},
                        "pliesToBePlaced": {},
                        "newMissingPlies": {},
                        "noLongerMissingPlies": {
                            **mock_data.StaticGraph.FirstPalletP.second_ply,
                        },
                        "forcedPlies": {},
                        "removedPlies": {}
                    }),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToNull.FirstPalletP.second_ply),
                    camera_out(
                        camera_ids={"cam1", "cam2", "cam3"},
                        command="start_capture",
                        refresh_interval=cfg.PASSIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                ]
            ),
        ]
        return {
            "entries": entries,
            "initial_mould_state_plies_data": mould_state_plies_data([
                mock_data.MouldStatePlies.PalletP.first_ply_covered_without_invisible_edge,
                mock_data.MouldStatePlies.PalletP.second_ply_partially_covered,
                mock_data.MouldStatePlies.PalletP.third_ply_placed_updated_by_cam_2,
            ]),
        }

    @staticmethod
    def should_correctly_handle_recheck_ply_update_when_placed_ply_rechecked():
        entries = [
            # 1 TI - to initialise mould state
            TestScenarioEntry(
                input_data=add_team_instruction_c2dm_request(instruction=mock_data.TeamInstructions.pallet_P_1),
                # etcd_outputs=[], - ignoring, do not assert
                # messaging_outputs=[], - ignoring, do not assert
            ),
            # 2 rechecked ply received via ETCD due to recheck_ply command
            TestScenarioEntry(
                input_data=etcd_ply_in(mock_data.MouldStatePlies.PalletP.second_ply_recheck_on_placed_via_other_device),
                etcd_outputs=[],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam1": {"missingEdges": ["P2.1"]},
                        "cam2": {"missingEdges": ["P2.1", "P2.2", "P3.1"]},
                        "cam3": {"missingEdges": ["P3.2"]}},
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_P": {"pallets": {"pallet_1": {"missingPlies": 1,
                                                                                       "placedPlies": 2,
                                                                                       "totalPlies": 3}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_P_1
                        ]),
                        "correctlyPlacedPlies": {},
                        "pliesToBePlaced": {
                            **mock_data.StaticGraph.FirstPalletP.third_ply,
                        },
                        "newMissingPlies": {
                            **mock_data.StaticGraph.FirstPalletP.second_ply,
                        },
                        "noLongerMissingPlies": {},
                        "forcedPlies": {},
                        "removedPlies": {}
                    }),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.FirstPalletP.third_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.MissingPlies.FirstPalletP.second_ply),
                    camera_out(
                        camera_ids={"cam1", "cam2", "cam3"},
                        command="start_capture",
                        refresh_interval=cfg.ACTIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                ]
            ),
            # 3 on EV msg rechecked ply is detected and becomes placed
            TestScenarioEntry(
                input_data=ev_message_in(
                    camera_id="cam2",
                    detected_edges={"P2.1", "P2.2"},
                    missing_edges=set()
                ),
                etcd_outputs=[
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.second_ply_placed_after_missing),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.third_ply_expected),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam1": {"detectedEdges": ["P2.1"]},
                        "cam2": {"detectedEdges": ["P2.1", "P2.2"], "missingEdges": ["P3.1"]},
                        "cam3": {"missingEdges": ["P3.2"]}},
                        session_cam_id="cam2"
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_P": {"pallets": {"pallet_1": {"missingPlies": 0,
                                                                                       "placedPlies": 2,
                                                                                       "totalPlies": 3}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_P_1,
                        ],
                            session=ev_message_session("cam2")
                        ),
                        "correctlyPlacedPlies": {},
                        "pliesToBePlaced": {
                            **mock_data.StaticGraph.FirstPalletP.third_ply,
                        },
                        "newMissingPlies": {},
                        "noLongerMissingPlies": {
                            **mock_data.StaticGraph.FirstPalletP.second_ply,
                        },
                        "forcedPlies": {},
                        "removedPlies": {}
                    }),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.FirstPalletP.third_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToNull.FirstPalletP.second_ply),
                    camera_out(
                        camera_ids={"cam1"},
                        command="start_capture",
                        refresh_interval=cfg.PASSIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                    camera_out(
                        camera_ids={"cam2", "cam3"},
                        command="start_capture",
                        refresh_interval=cfg.ACTIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                ]
            ),
        ]
        return {
            "entries": entries,
            "initial_mould_state_plies_data": mould_state_plies_data([
                mock_data.MouldStatePlies.PalletP.first_ply_covered_without_invisible_edge,
                mock_data.MouldStatePlies.PalletP.second_ply_placed,
                mock_data.MouldStatePlies.PalletP.third_ply_expected,
            ]),
        }

    @staticmethod
    def should_correctly_handle_recheck_ply_update_when_forced_ply_rechecked():
        entries = [
            # 1 TI - to initialise mould state
            TestScenarioEntry(
                input_data=add_team_instruction_c2dm_request(instruction=mock_data.TeamInstructions.pallet_P_1),
                # etcd_outputs=[], - ignoring, do not assert
                # messaging_outputs=[], - ignoring, do not assert
            ),
            # 2 rechecked ply received via ETCD due to recheck_ply command
            TestScenarioEntry(
                input_data=etcd_ply_in(mock_data.MouldStatePlies.PalletP.second_ply_recheck_on_forced_via_other_device),
                etcd_outputs=[],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam1": {"missingEdges": ["P2.1"]},
                        "cam2": {"missingEdges": ["P2.1", "P2.2", "P3.1"]},
                        "cam3": {"missingEdges": ["P3.2"]}},
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_P": {"pallets": {"pallet_1": {"missingPlies": 1,
                                                                                       "placedPlies": 2,
                                                                                       "totalPlies": 3}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_P_1
                        ]),
                        "correctlyPlacedPlies": {},
                        "pliesToBePlaced": {
                            **mock_data.StaticGraph.FirstPalletP.third_ply,
                        },
                        "newMissingPlies": {
                            **mock_data.StaticGraph.FirstPalletP.second_ply,
                        },
                        "noLongerMissingPlies": {},
                        "forcedPlies": {},
                        "removedPlies": {}
                    }),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.FirstPalletP.third_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.MissingPlies.FirstPalletP.second_ply),
                    camera_out(
                        camera_ids={"cam1", "cam2", "cam3"},
                        command="start_capture",
                        refresh_interval=cfg.ACTIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                ]
            ),
            # 3 on EV msg rechecked ply is detected and becomes placed
            TestScenarioEntry(
                input_data=ev_message_in(
                    camera_id="cam2",
                    detected_edges={"P2.1", "P2.2"},
                    missing_edges=set()
                ),
                etcd_outputs=[
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.second_ply_placed_after_missing),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.third_ply_expected),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam1": {"detectedEdges": ["P2.1"]},
                        "cam2": {"detectedEdges": ["P2.1", "P2.2"], "missingEdges": ["P3.1"]},
                        "cam3": {"missingEdges": ["P3.2"]}},
                        session_cam_id="cam2"
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_P": {"pallets": {"pallet_1": {"missingPlies": 0,
                                                                                       "placedPlies": 2,
                                                                                       "totalPlies": 3}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_P_1,
                        ],
                            session=ev_message_session("cam2")
                        ),
                        "correctlyPlacedPlies": {},
                        "pliesToBePlaced": {
                            **mock_data.StaticGraph.FirstPalletP.third_ply,
                        },
                        "newMissingPlies": {},
                        "noLongerMissingPlies": {
                            **mock_data.StaticGraph.FirstPalletP.second_ply,
                        },
                        "forcedPlies": {},
                        "removedPlies": {}
                    }),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.FirstPalletP.third_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToNull.FirstPalletP.second_ply),
                    camera_out(
                        camera_ids={"cam1"},
                        command="start_capture",
                        refresh_interval=cfg.PASSIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                    camera_out(
                        camera_ids={"cam2", "cam3"},
                        command="start_capture",
                        refresh_interval=cfg.ACTIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                ]
            ),
        ]
        return {
            "entries": entries,
            "initial_mould_state_plies_data": mould_state_plies_data([
                mock_data.MouldStatePlies.PalletP.first_ply_covered_without_invisible_edge,
                mock_data.MouldStatePlies.PalletP.second_ply_forced_on_expected,
                mock_data.MouldStatePlies.PalletP.third_ply_expected,
            ]),
        }
