# pylint: disable=protected-access, missing-module-docstring, missing-class-docstring, missing-function-docstring, duplicate-code, line-too-long, too-few-public-methods, no-self-use, too-many-locals, too-many-lines
import app.config as cfg
import tests.scenarios.mock_data as mock_data
from app.global_mould_state_enum import GlobalMouldState
from tests.scenarios.model.test_scenario_entry import TestScenarioEntry
from tests.scenarios.scenarios_base import add_team_instruction_c2dm_request, ev_message_in, edge_verification_out, \
    camera_out, laser_out, trace_out, etcd_ply_out, etcd_instruction_out, trace_out_metadata, ev_message_session, \
    etcd_mould_state_out, \
    etcd_mould_blade_sn_out, stats_out, instructions_loaded_on_boot, mould_state_plies_data, \
    mould_state_instructions_data


class MultipleLayersTestScenariosDtos:
    @staticmethod
    def multiple_initial_plies_from_multiple_layers_are_placed():
        entries = [
            # 1 TI for layer U
            TestScenarioEntry(
                input_data=add_team_instruction_c2dm_request(instruction=mock_data.TeamInstructions.pallet_U_1),
                etcd_outputs=[
                    etcd_instruction_out(instruction=mock_data.TeamInstructions.pallet_U_1),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.first_ply_expected),
                    etcd_mould_state_out(state=GlobalMouldState.PRODUCTION),
                    etcd_mould_blade_sn_out(blade_sn="blade_sn"),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam1": {"missingEdges": ["U1.1", "U1.2"]}},
                        layers=["layer_U"],
                    ),
                    camera_out(
                        camera_ids={"cam1"},
                        command="start_capture",
                        refresh_interval=cfg.ACTIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_U": {"pallets": {"pallet_1": {"missingPlies": 0,
                                                                                       "placedPlies": 0,
                                                                                       "totalPlies": 7}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_U_1,
                        ]),
                        "correctlyPlacedPlies": {},
                        "pliesToBePlaced": {
                            **mock_data.StaticGraph.FirstPalletU.first_ply,
                        },
                        "newMissingPlies": {},
                        "noLongerMissingPlies": {},
                        "forcedPlies": {},
                        "removedPlies": {}
                    }),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.FirstPalletU.first_ply),
                ]
            ),
            # 2 TI for layer P
            TestScenarioEntry(
                input_data=add_team_instruction_c2dm_request(mock_data.TeamInstructions.pallet_P_2),
                etcd_outputs=[
                    etcd_instruction_out(instruction=mock_data.TeamInstructions.pallet_P_2),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.first_ply_expected),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.fourth_ply_expected),
                    etcd_mould_state_out(state=GlobalMouldState.PRODUCTION),
                    etcd_mould_blade_sn_out(blade_sn="blade_sn"),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam1": {"missingEdges": ["U1.1", "U1.2"]},
                        "cam3": {"missingEdges": ["P4.1", "P4.2"]},
                        "cam4": {"missingEdges": ["P4.2"]}},
                        layers=["layer_P", "layer_U"],
                    ),
                    camera_out(
                        camera_ids={"cam1", "cam3", "cam4"},
                        command="start_capture",
                        refresh_interval=cfg.ACTIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_P": {"pallets": {"pallet_2": {"missingPlies": 0,
                                                                                       "placedPlies": 0,
                                                                                       "totalPlies": 3}}},
                                                  "layer_U": {"pallets": {"pallet_1": {"missingPlies": 0,
                                                                                       "placedPlies": 0,
                                                                                       "totalPlies": 7}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_U_1,
                            mock_data.TeamInstructions.pallet_P_2
                        ]),
                        "correctlyPlacedPlies": {},
                        "pliesToBePlaced": {
                            **mock_data.StaticGraph.FirstPalletU.first_ply,
                            **mock_data.StaticGraph.SecondPalletP.fourth_ply,
                        },
                        "newMissingPlies": {},
                        "noLongerMissingPlies": {},
                        "forcedPlies": {},
                        "removedPlies": {}
                    }),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.SecondPalletP.fourth_ply_multi_layers),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.FirstPalletU.first_ply_multi_layers),
                ]
            ),
            # 3 EV message in for layer U
            TestScenarioEntry(
                input_data=ev_message_in(
                    camera_id="cam1",
                    detected_edges={"U1.1", "U1.2"},
                    missing_edges=set(),
                ),
                etcd_outputs=[
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.first_ply_placed),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.second_ply_expected),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.fourth_ply_expected),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam1": {"detectedEdges": ["U1.1", "U1.2"],
                                 "missingEdges": ["U2.1", "U2.2"]},
                        "cam2": {"missingEdges": ["U2.2"]},
                        "cam3": {"missingEdges": ["P4.1", "P4.2"]},
                        "cam4": {"missingEdges": ["P4.2"]}},
                        session_cam_id="cam1",
                        layers=["layer_P", "layer_U"],
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_P": {"pallets": {"pallet_2": {"missingPlies": 0,
                                                                                       "placedPlies": 0,
                                                                                       "totalPlies": 3}}},
                                                  "layer_U": {"pallets": {"pallet_1": {"missingPlies": 0,
                                                                                       "placedPlies": 1,
                                                                                       "totalPlies": 7}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_U_1,
                            mock_data.TeamInstructions.pallet_P_2,
                        ],
                            session=ev_message_session("cam1")
                        ),
                        "correctlyPlacedPlies": {
                            **mock_data.StaticGraph.FirstPalletU.first_ply,
                        },
                        "pliesToBePlaced": {
                            **mock_data.StaticGraph.FirstPalletU.second_ply,
                            **mock_data.StaticGraph.SecondPalletP.fourth_ply,
                        },
                        "newMissingPlies": {},
                        "noLongerMissingPlies": {},
                        "forcedPlies": {},
                        "removedPlies": {}
                    }),
                    laser_out(
                        payload=mock_data.LaserFeedbacks.CorrectlyPlacedPlies.FirstPalletU.first_ply_multi_layers),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.SecondPalletP.fourth_ply_multi_layers),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.FirstPalletU.second_ply_multi_layers),
                    camera_out(
                        camera_ids={"cam1", "cam2", "cam3", "cam4"},
                        command="start_capture",
                        refresh_interval=cfg.ACTIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                ]
            ),
            # 4 EV message in for layer P
            TestScenarioEntry(
                input_data=ev_message_in(
                    camera_id="cam3",
                    detected_edges={"P4.1", "P4.2"},
                    missing_edges=set()
                ),
                etcd_outputs=[
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.second_ply_expected),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.fourth_ply_placed),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.fifth_ply_expected),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam1": {"detectedEdges": ["U1.1", "U1.2"],
                                 "missingEdges": ["U2.1", "U2.2"]},
                        "cam2": {"missingEdges": ["U2.2"]},
                        "cam3": {"detectedEdges": ["P4.1", "P4.2"]},
                        "cam4": {"detectedEdges": ["P4.2"],
                                 "missingEdges": ["P5.1", "P5.2"]}},
                        session_cam_id="cam3",
                        layers=["layer_P", "layer_U"],
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_P": {"pallets": {"pallet_2": {"missingPlies": 0,
                                                                                       "placedPlies": 1,
                                                                                       "totalPlies": 3}}},
                                                  "layer_U": {"pallets": {"pallet_1": {"missingPlies": 0,
                                                                                       "placedPlies": 1,
                                                                                       "totalPlies": 7}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_U_1,
                            mock_data.TeamInstructions.pallet_P_2,
                        ],
                            session=ev_message_session("cam3")
                        ),
                        "correctlyPlacedPlies": {
                            **mock_data.StaticGraph.SecondPalletP.fourth_ply,
                        },
                        "pliesToBePlaced": {
                            **mock_data.StaticGraph.FirstPalletU.second_ply,
                            **mock_data.StaticGraph.SecondPalletP.fifth_ply,
                        },
                        "newMissingPlies": {},
                        "noLongerMissingPlies": {},
                        "forcedPlies": {},
                        "removedPlies": {}
                    }),
                    laser_out(
                        payload=mock_data.LaserFeedbacks.CorrectlyPlacedPlies.SecondPalletP.fourth_ply_multi_layers),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.SecondPalletP.fifth_ply_multi_layers),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.FirstPalletU.second_ply_multi_layers),
                    camera_out(
                        camera_ids={"cam3"},
                        command="start_capture",
                        refresh_interval=cfg.PASSIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                    camera_out(
                        camera_ids={"cam1", "cam2", "cam4"},
                        command="start_capture",
                        refresh_interval=cfg.ACTIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                ]
            ),
        ]
        return {
            "entries": entries,
        }

    @staticmethod
    def multiple_initial_plies_from_multiple_layers_are_placed_not_in_sequential_order():
        entries = [
            # 1 TI for layer P
            TestScenarioEntry(
                input_data=add_team_instruction_c2dm_request(mock_data.TeamInstructions.pallet_P_2),
                etcd_outputs=[
                    etcd_instruction_out(instruction=mock_data.TeamInstructions.pallet_P_2),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.fourth_ply_expected),
                    etcd_mould_state_out(state=GlobalMouldState.PRODUCTION),
                    etcd_mould_blade_sn_out(blade_sn="blade_sn"),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam3": {"missingEdges": ["P4.1", "P4.2"]},
                        "cam4": {"missingEdges": ["P4.2"]}},
                        layers=["layer_P"],
                    ),
                    camera_out(
                        camera_ids={"cam3", "cam4"},
                        command="start_capture",
                        refresh_interval=cfg.ACTIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_P": {"pallets": {"pallet_2": {"missingPlies": 0,
                                                                                       "placedPlies": 0,
                                                                                       "totalPlies": 3}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_P_2
                        ]),
                        "correctlyPlacedPlies": {},
                        "pliesToBePlaced": {
                            **mock_data.StaticGraph.SecondPalletP.fourth_ply,
                        },
                        "newMissingPlies": {},
                        "noLongerMissingPlies": {},
                        "forcedPlies": {},
                        "removedPlies": {}
                    }),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.SecondPalletP.fourth_ply),
                ]
            ),
            # 2 EV message in for layer P
            TestScenarioEntry(
                input_data=ev_message_in(
                    camera_id="cam3",
                    detected_edges={"P4.1", "P4.2"},
                    missing_edges=set()
                ),
                etcd_outputs=[
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.fourth_ply_placed),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.fifth_ply_expected),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam3": {"detectedEdges": ["P4.1", "P4.2"]},
                        "cam4": {"detectedEdges": ["P4.2"],
                                 "missingEdges": ["P5.1", "P5.2"]}},
                        session_cam_id="cam3",
                        layers=["layer_P"],
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_P": {"pallets": {"pallet_2": {"missingPlies": 0,
                                                                                       "placedPlies": 1,
                                                                                       "totalPlies": 3}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_P_2,
                        ],
                            session=ev_message_session("cam3")
                        ),
                        "correctlyPlacedPlies": {
                            **mock_data.StaticGraph.SecondPalletP.fourth_ply,
                        },
                        "pliesToBePlaced": {
                            **mock_data.StaticGraph.SecondPalletP.fifth_ply,
                        },
                        "newMissingPlies": {},
                        "noLongerMissingPlies": {},
                        "forcedPlies": {},
                        "removedPlies": {}
                    }),
                    laser_out(payload=mock_data.LaserFeedbacks.CorrectlyPlacedPlies.SecondPalletP.fourth_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.SecondPalletP.fifth_ply),
                    camera_out(
                        camera_ids={"cam3"},
                        command="start_capture",
                        refresh_interval=cfg.PASSIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                    camera_out(
                        camera_ids={"cam4"},
                        command="start_capture",
                        refresh_interval=cfg.ACTIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                ]
            ),
            # 3 TI for layer U
            TestScenarioEntry(
                input_data=add_team_instruction_c2dm_request(instruction=mock_data.TeamInstructions.pallet_U_1),
                etcd_outputs=[
                    etcd_instruction_out(instruction=mock_data.TeamInstructions.pallet_U_1),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.first_ply_expected),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.fifth_ply_expected),
                    etcd_mould_state_out(state=GlobalMouldState.PRODUCTION),
                    etcd_mould_blade_sn_out(blade_sn="blade_sn"),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam1": {"missingEdges": ["U1.1", "U1.2"]},
                        "cam3": {"detectedEdges": ["P4.1", "P4.2"]},
                        "cam4": {"detectedEdges": ["P4.2"],
                                 "missingEdges": ["P5.1", "P5.2"]}},
                        layers=["layer_P", "layer_U"],
                    ),
                    camera_out(
                        camera_ids={"cam3"},
                        command="start_capture",
                        refresh_interval=cfg.PASSIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                    camera_out(
                        camera_ids={"cam1", "cam4"},
                        command="start_capture",
                        refresh_interval=cfg.ACTIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_P": {"pallets": {"pallet_2": {"missingPlies": 0,
                                                                                       "placedPlies": 1,
                                                                                       "totalPlies": 3}}},
                                                  "layer_U": {"pallets": {"pallet_1": {"missingPlies": 0,
                                                                                       "placedPlies": 0,
                                                                                       "totalPlies": 7}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_P_2,
                            mock_data.TeamInstructions.pallet_U_1,
                        ]),
                        "correctlyPlacedPlies": {},
                        "pliesToBePlaced": {
                            **mock_data.StaticGraph.FirstPalletU.first_ply,
                            **mock_data.StaticGraph.SecondPalletP.fifth_ply,
                        },
                        "newMissingPlies": {},
                        "noLongerMissingPlies": {},
                        "forcedPlies": {},
                        "removedPlies": {}
                    }),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.SecondPalletP.fifth_ply_multi_layers),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.FirstPalletU.first_ply_multi_layers),
                ]
            ),
            # 4 EV message in for layer U
            TestScenarioEntry(
                input_data=ev_message_in(
                    camera_id="cam1",
                    detected_edges={"U1.1", "U1.2"},
                    missing_edges=set(),
                ),
                etcd_outputs=[
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.first_ply_placed),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.second_ply_expected),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.fifth_ply_expected),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam1": {"detectedEdges": ["U1.1", "U1.2"],
                                 "missingEdges": ["U2.1", "U2.2"]},
                        "cam2": {"missingEdges": ["U2.2"]},
                        "cam3": {"detectedEdges": ["P4.1", "P4.2"]},
                        "cam4": {"detectedEdges": ["P4.2"],
                                 "missingEdges": ["P5.1", "P5.2"]}},
                        session_cam_id="cam1",
                        layers=["layer_P", "layer_U"],
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_P": {"pallets": {"pallet_2": {"missingPlies": 0,
                                                                                       "placedPlies": 1,
                                                                                       "totalPlies": 3}}},
                                                  "layer_U": {"pallets": {"pallet_1": {"missingPlies": 0,
                                                                                       "placedPlies": 1,
                                                                                       "totalPlies": 7}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_P_2,
                            mock_data.TeamInstructions.pallet_U_1,
                        ],
                            session=ev_message_session("cam1")
                        ),
                        "correctlyPlacedPlies": {
                            **mock_data.StaticGraph.FirstPalletU.first_ply,
                        },
                        "pliesToBePlaced": {
                            **mock_data.StaticGraph.FirstPalletU.second_ply,
                            **mock_data.StaticGraph.SecondPalletP.fifth_ply,
                        },
                        "newMissingPlies": {},
                        "noLongerMissingPlies": {},
                        "forcedPlies": {},
                        "removedPlies": {}
                    }),
                    laser_out(
                        payload=mock_data.LaserFeedbacks.CorrectlyPlacedPlies.FirstPalletU.first_ply_multi_layers),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.SecondPalletP.fifth_ply_multi_layers),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.FirstPalletU.second_ply_multi_layers),
                    camera_out(
                        camera_ids={"cam3"},
                        command="start_capture",
                        refresh_interval=cfg.PASSIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                    camera_out(
                        camera_ids={"cam1", "cam2", "cam4"},
                        command="start_capture",
                        refresh_interval=cfg.ACTIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                ]
            ),
        ]
        return {
            "entries": entries,
        }

    @staticmethod
    def multiple_initial_plies_from_multiple_layers_are_placed_under_the_same_camera():
        entries = [
            # 1 TI for layer P
            TestScenarioEntry(
                input_data=add_team_instruction_c2dm_request(mock_data.TeamInstructions.pallet_P_1),
                etcd_outputs=[
                    etcd_instruction_out(instruction=mock_data.TeamInstructions.pallet_P_1),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.first_ply_expected_without_invisible_edge),
                    etcd_mould_state_out(state=GlobalMouldState.PRODUCTION),
                    etcd_mould_blade_sn_out(blade_sn="blade_sn"),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam1": {"missingEdges": ["P1.2"]}},
                    ),
                    camera_out(
                        camera_ids={"cam1"},
                        command="start_capture",
                        refresh_interval=cfg.ACTIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_P": {"pallets": {"pallet_1": {"missingPlies": 0,
                                                                                       "placedPlies": 0,
                                                                                       "totalPlies": 3}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_P_1
                        ]),
                        "correctlyPlacedPlies": {},
                        "pliesToBePlaced": {
                            **mock_data.StaticGraph.FirstPalletP.first_ply_invisible_edge_removed,
                        },
                        "newMissingPlies": {},
                        "noLongerMissingPlies": {},
                        "forcedPlies": {},
                        "removedPlies": {}
                    }),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.FirstPalletP.first_ply),
                ]
            ),
            # 2 TI for layer U
            TestScenarioEntry(
                input_data=add_team_instruction_c2dm_request(instruction=mock_data.TeamInstructions.pallet_U_1),
                etcd_outputs=[
                    etcd_instruction_out(instruction=mock_data.TeamInstructions.pallet_U_1),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.first_ply_expected_without_invisible_edge),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.first_ply_expected),
                    etcd_mould_state_out(state=GlobalMouldState.PRODUCTION),
                    etcd_mould_blade_sn_out(blade_sn="blade_sn"),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam1": {"missingEdges": ["P1.2", "U1.1", "U1.2"]}},
                        layers=["layer_P", "layer_U"],
                    ),
                    camera_out(
                        camera_ids={"cam1"},
                        command="start_capture",
                        refresh_interval=cfg.ACTIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_P": {"pallets": {"pallet_1": {"missingPlies": 0,
                                                                                       "placedPlies": 0,
                                                                                       "totalPlies": 3}}},
                                                  "layer_U": {"pallets": {"pallet_1": {"missingPlies": 0,
                                                                                       "placedPlies": 0,
                                                                                       "totalPlies": 7}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_P_1,
                            mock_data.TeamInstructions.pallet_U_1,
                        ]),
                        "correctlyPlacedPlies": {},
                        "pliesToBePlaced": {
                            **mock_data.StaticGraph.FirstPalletP.first_ply_invisible_edge_removed,
                            **mock_data.StaticGraph.FirstPalletU.first_ply,
                        },
                        "newMissingPlies": {},
                        "noLongerMissingPlies": {},
                        "forcedPlies": {},
                        "removedPlies": {}
                    }),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.FirstPalletP.first_ply_multi_layers),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.FirstPalletU.first_ply_multi_layers),
                ]
            ),
            # 3 EV message in for layer P
            TestScenarioEntry(
                input_data=ev_message_in(
                    camera_id="cam1",
                    detected_edges={"P1.2"},
                    missing_edges=set()
                ),
                etcd_outputs=[
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.first_ply_placed_without_invisible_edge),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.second_ply_expected),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.first_ply_expected),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam1": {"detectedEdges": ["P1.2"],
                                 "missingEdges": ["P2.1", "U1.1", "U1.2"]},
                        "cam2": {"missingEdges": ["P2.1", "P2.2"]}},
                        session_cam_id="cam1",
                        layers=["layer_P", "layer_U"],
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_P": {"pallets": {"pallet_1": {"missingPlies": 0,
                                                                                       "placedPlies": 1,
                                                                                       "totalPlies": 3}}},
                                                  "layer_U": {"pallets": {"pallet_1": {"missingPlies": 0,
                                                                                       "placedPlies": 0,
                                                                                       "totalPlies": 7}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_P_1,
                            mock_data.TeamInstructions.pallet_U_1,
                        ],
                            session=ev_message_session("cam1")
                        ),
                        "correctlyPlacedPlies": {
                            **mock_data.StaticGraph.FirstPalletP.first_ply_invisible_edge_removed,
                        },
                        "pliesToBePlaced": {
                            **mock_data.StaticGraph.FirstPalletP.second_ply,
                            **mock_data.StaticGraph.FirstPalletU.first_ply,
                        },
                        "newMissingPlies": {},
                        "noLongerMissingPlies": {},
                        "forcedPlies": {},
                        "removedPlies": {}
                    }),
                    laser_out(
                        payload=mock_data.LaserFeedbacks.CorrectlyPlacedPlies.FirstPalletP.first_ply_multi_layers),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.FirstPalletP.second_ply_multi_layers),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.FirstPalletU.first_ply_multi_layers),
                    camera_out(
                        camera_ids={"cam1", "cam2"},
                        command="start_capture",
                        refresh_interval=cfg.ACTIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                ]
            ),
            # 4 EV message in for layer U
            TestScenarioEntry(
                input_data=ev_message_in(
                    camera_id="cam1",
                    detected_edges={"U1.1", "U1.2"},
                    missing_edges=set(),
                ),
                etcd_outputs=[
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.second_ply_expected),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.first_ply_placed),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.second_ply_expected),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam1": {"detectedEdges": ["P1.2", "U1.1", "U1.2"],
                                 "missingEdges": ["P2.1", "U2.1", "U2.2"]},
                        "cam2": {"missingEdges": ["P2.1", "P2.2", "U2.2"]}},
                        session_cam_id="cam1",
                        layers=["layer_P", "layer_U"],
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_P": {"pallets": {"pallet_1": {"missingPlies": 0,
                                                                                       "placedPlies": 1,
                                                                                       "totalPlies": 3}}},
                                                  "layer_U": {"pallets": {"pallet_1": {"missingPlies": 0,
                                                                                       "placedPlies": 1,
                                                                                       "totalPlies": 7}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_P_1,
                            mock_data.TeamInstructions.pallet_U_1,
                        ],
                            session=ev_message_session("cam1")
                        ),
                        "correctlyPlacedPlies": {
                            **mock_data.StaticGraph.FirstPalletU.first_ply,
                        },
                        "pliesToBePlaced": {
                            **mock_data.StaticGraph.FirstPalletU.second_ply,
                            **mock_data.StaticGraph.FirstPalletP.second_ply,
                        },
                        "newMissingPlies": {},
                        "noLongerMissingPlies": {},
                        "forcedPlies": {},
                        "removedPlies": {}
                    }),
                    laser_out(
                        payload=mock_data.LaserFeedbacks.CorrectlyPlacedPlies.FirstPalletU.first_ply_multi_layers),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.FirstPalletP.second_ply_multi_layers),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.FirstPalletU.second_ply_multi_layers),
                    camera_out(
                        camera_ids={"cam1", "cam2"},
                        command="start_capture",
                        refresh_interval=cfg.ACTIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                ]
            ),
        ]
        return {
            "entries": entries,
        }

    @staticmethod
    def all_plies_from_multiple_pallets_and_layers_are_completely_placed():
        entries = [
            # 1 On DM boot team instructions are preloaded from ETCD store, no input data
            TestScenarioEntry(
                input_data=instructions_loaded_on_boot(),
                etcd_outputs=[
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.eighth_ply_expected),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.sixth_ply_expected),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam1": {"detectedEdges": ["P2.1", "U1.1", "U2.1"]},
                        "cam2": {"detectedEdges": ["P2.1", "P3.1", "U3.1", "U4.1", "U5.1", "U5.2"],
                                 "missingEdges": ["U6.1", "U6.2"]},
                        "cam3": {"detectedEdges": ["P4.1", "U5.1", "U5.2"],
                                 "missingEdges": ["U6.1", "U6.2"]},
                        "cam4": {"detectedEdges": ["P5.1", "P6.1"]},
                        "cam5": {"detectedEdges": ["P6.1", "P7.1", "P7.2"]},
                        "cam6": {"detectedEdges": ["P7.2"],
                                 "missingEdges": ["P8.1", "P8.2"]}},
                        layers=["layer_P", "layer_U"],
                    ),
                    camera_out(
                        camera_ids={"cam1", "cam4", "cam5"},
                        command="start_capture",
                        refresh_interval=cfg.PASSIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                    camera_out(
                        camera_ids={"cam2", "cam3", "cam6"},
                        command="start_capture",
                        refresh_interval=cfg.ACTIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_P": {"pallets": {"pallet_1": {"missingPlies": 0,
                                                                                       "placedPlies": 3,
                                                                                       "totalPlies": 3},
                                                                          "pallet_2": {"missingPlies": 0,
                                                                                       "placedPlies": 3,
                                                                                       "totalPlies": 3},
                                                                          "pallet_3": {"missingPlies": 0,
                                                                                       "placedPlies": 1,
                                                                                       "totalPlies": 3}}},
                                                  "layer_U": {"pallets": {"pallet_1": {"missingPlies": 0,
                                                                                       "placedPlies": 5,
                                                                                       "totalPlies": 7}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_P_1,
                            mock_data.TeamInstructions.pallet_P_2,
                            mock_data.TeamInstructions.pallet_P_3,
                            mock_data.TeamInstructions.pallet_U_1,
                        ]),
                        "correctlyPlacedPlies": {},
                        "pliesToBePlaced": {
                            **mock_data.StaticGraph.FirstPalletU.sixth_ply,
                            **mock_data.StaticGraph.ThirdPalletP.eighth_ply,
                        },
                        "newMissingPlies": {},
                        "noLongerMissingPlies": {},
                        "forcedPlies": {},
                        "removedPlies": {}
                    }),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.ThirdPalletP.eighth_ply_multi_layers),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.FirstPalletU.sixth_ply_multi_layers),
                ]
            ),
            # 2 EV message in for layer P
            TestScenarioEntry(
                input_data=ev_message_in(
                    camera_id="cam6",
                    detected_edges={"P8.1", "P8.2"},
                    missing_edges=set()
                ),
                etcd_outputs=[
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.seventh_ply_partially_covered),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.eighth_ply_placed),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.ninth_ply_expected_without_invisible_edge),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.sixth_ply_expected),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam1": {"detectedEdges": ["P2.1", "U1.1", "U2.1"]},
                        "cam2": {"detectedEdges": ["P2.1", "P3.1", "U3.1", "U4.1", "U5.1", "U5.2"],
                                 "missingEdges": ["U6.1", "U6.2"]},
                        "cam3": {"detectedEdges": ["P4.1", "U5.1", "U5.2"],
                                 "missingEdges": ["U6.1", "U6.2"]},
                        "cam4": {"detectedEdges": ["P5.1", "P6.1"]},
                        "cam5": {"detectedEdges": ["P6.1", "P7.1"]},
                        "cam6": {"detectedEdges": ["P8.1", "P8.2"],
                                 "missingEdges": ["P9.1"]}},
                        session_cam_id="cam6",
                        layers=["layer_P", "layer_U"]
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_P": {"pallets": {"pallet_1": {"missingPlies": 0,
                                                                                       "placedPlies": 3,
                                                                                       "totalPlies": 3},
                                                                          "pallet_2": {"missingPlies": 0,
                                                                                       "placedPlies": 3,
                                                                                       "totalPlies": 3},
                                                                          "pallet_3": {"missingPlies": 0,
                                                                                       "placedPlies": 2,
                                                                                       "totalPlies": 3}}},
                                                  "layer_U": {"pallets": {"pallet_1": {"missingPlies": 0,
                                                                                       "placedPlies": 5,
                                                                                       "totalPlies": 7}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_P_1,
                            mock_data.TeamInstructions.pallet_P_2,
                            mock_data.TeamInstructions.pallet_P_3,
                            mock_data.TeamInstructions.pallet_U_1,
                        ],
                            session=ev_message_session("cam6")
                        ),
                        "correctlyPlacedPlies": {
                            **mock_data.StaticGraph.ThirdPalletP.eighth_ply,
                        },
                        "pliesToBePlaced": {
                            **mock_data.StaticGraph.FirstPalletU.sixth_ply,
                            **mock_data.StaticGraph.ThirdPalletP.ninth_ply_invisible_edge_removed,
                        },
                        "newMissingPlies": {},
                        "noLongerMissingPlies": {},
                        "forcedPlies": {},
                        "removedPlies": {}
                    }),
                    laser_out(
                        payload=mock_data.LaserFeedbacks.CorrectlyPlacedPlies.ThirdPalletP.eighth_ply_multi_layers),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.ThirdPalletP.ninth_ply_multi_layers),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.FirstPalletU.sixth_ply_multi_layers),
                    camera_out(
                        camera_ids={"cam1", "cam4", "cam5"},
                        command="start_capture",
                        refresh_interval=cfg.PASSIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                    camera_out(
                        camera_ids={"cam2", "cam3", "cam6"},
                        command="start_capture",
                        refresh_interval=cfg.ACTIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                ]
            ),
            # 3 EV message in for layer U
            TestScenarioEntry(
                input_data=ev_message_in(
                    camera_id="cam2",
                    detected_edges={"U6.1", "U6.2"},
                    missing_edges={"U3.1", "U4.1", "U5.1", "U5.2"},
                ),
                etcd_outputs=[
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.ninth_ply_expected_without_invisible_edge),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.first_ply_fully_covered_by_U6),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.second_ply_fully_covered_by_U6),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.third_ply_fully_covered_by_U6),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.fourth_ply_fully_covered_by_U6),
                    etcd_ply_out(
                        ply=mock_data.MouldStatePlies.PalletU.fifth_ply_fully_covered_by_U6_with_edges_by_cam3_still_detected),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.sixth_ply_placed_by_cam2),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.seventh_ply_expected),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam1": {"detectedEdges": ["P2.1"]},
                        "cam2": {"detectedEdges": ["P2.1", "P3.1", "U6.1", "U6.2"],
                                 "missingEdges": ["U7.1", "U7.2"]},
                        "cam3": {"detectedEdges": ["P4.1", "U6.1", "U6.2"],
                                 "missingEdges": ["U7.1", "U7.2"]},
                        "cam4": {"detectedEdges": ["P5.1", "P6.1"]},
                        "cam5": {"detectedEdges": ["P6.1", "P7.1"]},
                        "cam6": {"detectedEdges": ["P8.1", "P8.2"],
                                 "missingEdges": ["P9.1"]}},
                        session_cam_id="cam2",
                        layers=["layer_P", "layer_U"],
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_P": {"pallets": {"pallet_1": {"missingPlies": 0,
                                                                                       "placedPlies": 3,
                                                                                       "totalPlies": 3},
                                                                          "pallet_2": {"missingPlies": 0,
                                                                                       "placedPlies": 3,
                                                                                       "totalPlies": 3},
                                                                          "pallet_3": {"missingPlies": 0,
                                                                                       "placedPlies": 2,
                                                                                       "totalPlies": 3}}},
                                                  "layer_U": {"pallets": {"pallet_1": {"missingPlies": 0,
                                                                                       "placedPlies": 6,
                                                                                       "totalPlies": 7}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_P_1,
                            mock_data.TeamInstructions.pallet_P_2,
                            mock_data.TeamInstructions.pallet_P_3,
                            mock_data.TeamInstructions.pallet_U_1,
                        ],
                            session=ev_message_session("cam2")
                        ),
                        "correctlyPlacedPlies": {
                            **mock_data.StaticGraph.FirstPalletU.sixth_ply,
                        },
                        "pliesToBePlaced": {
                            **mock_data.StaticGraph.ThirdPalletP.ninth_ply_invisible_edge_removed,
                            **mock_data.StaticGraph.FirstPalletU.seventh_ply,
                        },
                        "newMissingPlies": {},
                        "noLongerMissingPlies": {},
                        "forcedPlies": {},
                        "removedPlies": {}
                    }),
                    laser_out(
                        payload=mock_data.LaserFeedbacks.CorrectlyPlacedPlies.FirstPalletU.sixth_ply_multi_layers),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.ThirdPalletP.ninth_ply_multi_layers),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.FirstPalletU.seventh_ply_multi_layers),
                    camera_out(
                        camera_ids={"cam1", "cam4", "cam5"},
                        command="start_capture",
                        refresh_interval=cfg.PASSIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                    camera_out(
                        camera_ids={"cam2", "cam3", "cam6"},
                        command="start_capture",
                        refresh_interval=cfg.ACTIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                ]
            ),
            # 4 EV message in for layer P
            TestScenarioEntry(
                input_data=ev_message_in(
                    camera_id="cam6",
                    detected_edges={"P8.1", "P9.1"},
                    missing_edges=set(),
                ),
                etcd_outputs=[
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.eighth_ply_partially_covered_on_expected),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.ninth_ply_placed_without_invisible_edge),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.seventh_ply_expected),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam1": {"detectedEdges": ["P2.1"]},
                        "cam2": {"detectedEdges": ["P2.1", "P3.1", "U6.1", "U6.2"],
                                 "missingEdges": ["U7.1", "U7.2"]},
                        "cam3": {"detectedEdges": ["P4.1", "U6.1", "U6.2"],
                                 "missingEdges": ["U7.1", "U7.2"]},
                        "cam4": {"detectedEdges": ["P5.1", "P6.1"]},
                        "cam5": {"detectedEdges": ["P6.1", "P7.1"]},
                        "cam6": {"detectedEdges": ["P8.1", "P9.1"]}},
                        session_cam_id="cam6",
                        layers=["layer_P", "layer_U"]
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_P": {"pallets": {"pallet_1": {"missingPlies": 0,
                                                                                       "placedPlies": 3,
                                                                                       "totalPlies": 3},
                                                                          "pallet_2": {"missingPlies": 0,
                                                                                       "placedPlies": 3,
                                                                                       "totalPlies": 3},
                                                                          "pallet_3": {"missingPlies": 0,
                                                                                       "placedPlies": 3,
                                                                                       "totalPlies": 3}}},
                                                  "layer_U": {"pallets": {"pallet_1": {"missingPlies": 0,
                                                                                       "placedPlies": 6,
                                                                                       "totalPlies": 7}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_P_1,
                            mock_data.TeamInstructions.pallet_P_2,
                            mock_data.TeamInstructions.pallet_P_3,
                            mock_data.TeamInstructions.pallet_U_1,
                        ],
                            session=ev_message_session("cam6")
                        ),
                        "correctlyPlacedPlies": {
                            **mock_data.StaticGraph.ThirdPalletP.ninth_ply_invisible_edge_removed,
                        },
                        "pliesToBePlaced": {
                            **mock_data.StaticGraph.FirstPalletU.seventh_ply,
                        },
                        "newMissingPlies": {},
                        "noLongerMissingPlies": {},
                        "forcedPlies": {},
                        "removedPlies": {}
                    }),
                    laser_out(
                        payload=mock_data.LaserFeedbacks.CorrectlyPlacedPlies.ThirdPalletP.ninth_ply_multi_layers),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.FirstPalletU.seventh_ply_multi_layers),
                    camera_out(
                        camera_ids={"cam1", "cam4", "cam5", "cam6"},
                        command="start_capture",
                        refresh_interval=cfg.PASSIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                    camera_out(
                        camera_ids={"cam2", "cam3"},
                        command="start_capture",
                        refresh_interval=cfg.ACTIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                ]
            ),
            # 5 EV message in for layer U
            TestScenarioEntry(
                input_data=ev_message_in(
                    camera_id="cam2",
                    detected_edges={"U6.1", "U7.1", "U7.2"},
                    missing_edges=set(),
                ),
                etcd_outputs=[
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.sixth_ply_partially_covered_by_cam2_on_expected),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.seventh_ply_placed_updated_by_cam2),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam1": {"detectedEdges": ["P2.1"]},
                        "cam2": {"detectedEdges": ["P2.1", "P3.1", "U6.1", "U7.1", "U7.2"]},
                        "cam3": {"detectedEdges": ["P4.1", "U6.1", "U7.1", "U7.2"]},
                        "cam4": {"detectedEdges": ["P5.1", "P6.1"]},
                        "cam5": {"detectedEdges": ["P6.1", "P7.1"]},
                        "cam6": {"detectedEdges": ["P8.1", "P9.1"]}},
                        session_cam_id="cam2",
                        layers=["layer_P", "layer_U"],
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_P": {"pallets": {"pallet_1": {"missingPlies": 0,
                                                                                       "placedPlies": 3,
                                                                                       "totalPlies": 3},
                                                                          "pallet_2": {"missingPlies": 0,
                                                                                       "placedPlies": 3,
                                                                                       "totalPlies": 3},
                                                                          "pallet_3": {"missingPlies": 0,
                                                                                       "placedPlies": 3,
                                                                                       "totalPlies": 3}}},
                                                  "layer_U": {"pallets": {"pallet_1": {"missingPlies": 0,
                                                                                       "placedPlies": 7,
                                                                                       "totalPlies": 7}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_P_1,
                            mock_data.TeamInstructions.pallet_P_2,
                            mock_data.TeamInstructions.pallet_P_3,
                            mock_data.TeamInstructions.pallet_U_1,
                        ],
                            session=ev_message_session("cam2")
                        ),
                        "correctlyPlacedPlies": {
                            **mock_data.StaticGraph.FirstPalletU.seventh_ply,
                        },
                        "pliesToBePlaced": {},
                        "newMissingPlies": {},
                        "noLongerMissingPlies": {},
                        "forcedPlies": {},
                        "removedPlies": {}
                    }),
                    laser_out(payload=mock_data.LaserFeedbacks.LastPliesPlaced.FirstPalletU.seventh_ply_multi_layers),
                    camera_out(
                        camera_ids={"cam1", "cam4", "cam5", "cam2", "cam3", "cam6"},
                        command="start_capture",
                        refresh_interval=cfg.PASSIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                ]
            ),
        ]
        return {
            "entries": entries,
            "initial_mould_state_instructions_data": mould_state_instructions_data([
                mock_data.TeamInstructions.pallet_P_1,
                mock_data.TeamInstructions.pallet_P_2,
                mock_data.TeamInstructions.pallet_P_3,
                mock_data.TeamInstructions.pallet_U_1,
            ]),
            "initial_mould_state_plies_data": mould_state_plies_data([
                mock_data.MouldStatePlies.PalletP.first_ply_covered_without_invisible_edge,
                mock_data.MouldStatePlies.PalletP.second_ply_partially_covered,
                mock_data.MouldStatePlies.PalletP.third_ply_partially_covered,
                # pallet_1 is completed for layer P
                mock_data.MouldStatePlies.PalletP.fourth_ply_partially_covered,
                mock_data.MouldStatePlies.PalletP.fifth_ply_partially_covered,
                mock_data.MouldStatePlies.PalletP.sixth_ply_partially_covered,
                # pallet_2 is completed for layer P
                mock_data.MouldStatePlies.PalletP.seventh_ply_placed,
                mock_data.MouldStatePlies.PalletP.eighth_ply_expected,
                # two more plies for pallet_3 of layer P to place
                mock_data.MouldStatePlies.PalletU.first_ply_partially_covered,
                mock_data.MouldStatePlies.PalletU.second_ply_partially_covered,
                mock_data.MouldStatePlies.PalletU.third_ply_partially_covered,
                mock_data.MouldStatePlies.PalletU.fourth_ply_partially_covered,
                mock_data.MouldStatePlies.PalletU.fifth_ply_placed,
                mock_data.MouldStatePlies.PalletU.sixth_ply_expected,
                # two more plies for pallet_1 of layer U to place
            ]),
            "initial_mould_state": GlobalMouldState.PRODUCTION,
            "initial_mould_blade_sn": "blade_sn",
        }
