# pylint: disable=protected-access, missing-module-docstring, missing-class-docstring, missing-function-docstring, duplicate-code, line-too-long, too-few-public-methods, no-self-use, too-many-locals, too-many-lines
import app.config as cfg
import tests.scenarios.mock_data as mock_data
from app.global_mould_state_enum import GlobalMouldState
from tests.scenarios.model.test_scenario_entry import TestScenarioEntry
from tests.scenarios.scenarios_base import add_team_instruction_c2dm_request, ev_message_in, edge_verification_out, \
    camera_out, laser_out, trace_out, etcd_ply_out, ev_message_session, etcd_instruction_out, mould_state_plies_data, \
    mould_state_instructions_data, instructions_loaded_on_boot, trace_out_metadata, etcd_mould_state_out, \
    etcd_mould_blade_sn_out, recheck_ply_c2dm_request, stats_out


class SinglePlacedPliesToVerifyTestScenariosDtos:
    @staticmethod
    def plies_placed_one_by_one_and_one_ply_with_dependency_on_multiple_previous_plies():
        entries = [
            # TI 1
            TestScenarioEntry(
                input_data=add_team_instruction_c2dm_request(instruction=mock_data.TeamInstructions.pallet_U_1),
                etcd_outputs=[
                    etcd_instruction_out(instruction=mock_data.TeamInstructions.pallet_U_1),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.first_ply_expected),
                    etcd_mould_state_out(state=GlobalMouldState.PRODUCTION),
                    etcd_mould_blade_sn_out(blade_sn="blade_sn"),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam1": {"missingEdges": ["U1.1", "U1.2"]}},
                        layers=["layer_U"],
                    ),
                    camera_out(
                        camera_ids={"cam1"},
                        command="start_capture",
                        refresh_interval=cfg.ACTIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_U": {"pallets": {"pallet_1": {"missingPlies": 0,
                                                                                       "placedPlies": 0,
                                                                                       "totalPlies": 7}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_U_1,
                        ]),
                        "correctlyPlacedPlies": {},
                        "pliesToBePlaced": {
                            **mock_data.StaticGraph.FirstPalletU.first_ply,
                        },
                        "newMissingPlies": {},
                        "noLongerMissingPlies": {},
                        "forcedPlies": {},
                        "removedPlies": {}
                    }),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.FirstPalletU.first_ply),
                ]
            ),
            TestScenarioEntry(
                input_data=ev_message_in(
                    camera_id="cam1",
                    detected_edges={"U1.1", "U1.2"},
                    missing_edges=set(),
                ),
                etcd_outputs=[
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.first_ply_placed),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.second_ply_expected),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam1": {"detectedEdges": ["U1.1", "U1.2"],
                                 "missingEdges": ["U2.1", "U2.2"]},
                        "cam2": {"missingEdges": ["U2.2"]}},
                        session_cam_id="cam1",
                        layers=["layer_U"],
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_U": {"pallets": {"pallet_1": {"missingPlies": 0,
                                                                                       "placedPlies": 1,
                                                                                       "totalPlies": 7}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_U_1,
                        ],
                            session=ev_message_session("cam1")
                        ),
                        "correctlyPlacedPlies": {
                            **mock_data.StaticGraph.FirstPalletU.first_ply,
                        },
                        "pliesToBePlaced": {
                            **mock_data.StaticGraph.FirstPalletU.second_ply,
                        },
                        "newMissingPlies": {},
                        "noLongerMissingPlies": {},
                        "forcedPlies": {},
                        "removedPlies": {}
                    }),
                    laser_out(payload=mock_data.LaserFeedbacks.CorrectlyPlacedPlies.FirstPalletU.first_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.FirstPalletU.second_ply),
                    camera_out(
                        camera_ids={"cam1", "cam2"},
                        command="start_capture",
                        refresh_interval=cfg.ACTIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                ]
            ),
            TestScenarioEntry(
                input_data=ev_message_in(
                    camera_id="cam1",
                    detected_edges={"U2.1", "U2.2"},
                    missing_edges={"U1.2"},
                ),
                etcd_outputs=[
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.first_ply_partially_covered),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.second_ply_placed),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.third_ply_expected),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam1": {"detectedEdges": ["U2.1", "U2.2"]},
                        "cam2": {"detectedEdges": ["U2.2"],
                                 "missingEdges": ["U3.1", "U3.2"]}},
                        session_cam_id="cam1",
                        layers=["layer_U"],
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_U": {"pallets": {"pallet_1": {"missingPlies": 0,
                                                                                       "placedPlies": 2,
                                                                                       "totalPlies": 7}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_U_1,
                        ],
                            session=ev_message_session("cam1")
                        ),
                        "correctlyPlacedPlies": {
                            **mock_data.StaticGraph.FirstPalletU.second_ply,
                        },
                        "pliesToBePlaced": {
                            **mock_data.StaticGraph.FirstPalletU.third_ply,
                        },
                        "newMissingPlies": {},
                        "noLongerMissingPlies": {},
                        "forcedPlies": {},
                        "removedPlies": {}
                    }),
                    laser_out(payload=mock_data.LaserFeedbacks.CorrectlyPlacedPlies.FirstPalletU.second_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.FirstPalletU.third_ply),
                    camera_out(
                        camera_ids={"cam1"},
                        command="start_capture",
                        refresh_interval=cfg.PASSIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                    camera_out(
                        camera_ids={"cam2"},
                        command="start_capture",
                        refresh_interval=cfg.ACTIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                ]
            ),
            TestScenarioEntry(
                input_data=ev_message_in(
                    camera_id="cam2",
                    detected_edges={"U3.1", "U3.2"},
                    missing_edges={"U2.2"},
                ),
                etcd_outputs=[
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.second_ply_partially_covered),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.third_ply_placed_updated_by_cam_2),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.fourth_ply_expected),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam2": {"detectedEdges": ["U3.1", "U3.2"],
                                 "missingEdges": ["U4.1", "U4.2"]}},
                        session_cam_id="cam2",
                        layers=["layer_U"],
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_U": {"pallets": {"pallet_1": {"missingPlies": 0,
                                                                                       "placedPlies": 3,
                                                                                       "totalPlies": 7}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_U_1,
                        ],
                            session=ev_message_session("cam2")
                        ),
                        "correctlyPlacedPlies": {
                            **mock_data.StaticGraph.FirstPalletU.third_ply,
                        },
                        "pliesToBePlaced": {
                            **mock_data.StaticGraph.FirstPalletU.fourth_ply,
                        },
                        "newMissingPlies": {},
                        "noLongerMissingPlies": {},
                        "forcedPlies": {},
                        "removedPlies": {}
                    }),
                    laser_out(payload=mock_data.LaserFeedbacks.CorrectlyPlacedPlies.FirstPalletU.third_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.FirstPalletU.fourth_ply),
                    camera_out(
                        camera_ids={"cam1"},
                        command="start_capture",
                        refresh_interval=cfg.PASSIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                    camera_out(
                        camera_ids={"cam2"},
                        command="start_capture",
                        refresh_interval=cfg.ACTIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                ]
            ),
            TestScenarioEntry(
                input_data=ev_message_in(
                    camera_id="cam2",
                    detected_edges={"U4.1", "U4.2"},
                    missing_edges=set()
                ),
                etcd_outputs=[
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.third_ply_partially_covered),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.fourth_ply_placed),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.fifth_ply_expected),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam2": {"detectedEdges": ["U4.1", "U4.2"],
                                 "missingEdges": ["U5.1", "U5.2"]},
                        "cam3": {"missingEdges": ["U5.1", "U5.2"]}},
                        session_cam_id="cam2",
                        layers=["layer_U"],
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_U": {"pallets": {"pallet_1": {"missingPlies": 0,
                                                                                       "placedPlies": 4,
                                                                                       "totalPlies": 7}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_U_1,
                        ],
                            session=ev_message_session("cam2")
                        ),
                        "correctlyPlacedPlies": {
                            **mock_data.StaticGraph.FirstPalletU.fourth_ply,
                        },
                        "pliesToBePlaced": {
                            **mock_data.StaticGraph.FirstPalletU.fifth_ply,
                        },
                        "newMissingPlies": {},
                        "noLongerMissingPlies": {},
                        "forcedPlies": {},
                        "removedPlies": {}
                    }),
                    laser_out(payload=mock_data.LaserFeedbacks.CorrectlyPlacedPlies.FirstPalletU.fourth_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.FirstPalletU.fifth_ply),
                    camera_out(
                        camera_ids={"cam1"},
                        command="start_capture",
                        refresh_interval=cfg.PASSIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                    camera_out(
                        camera_ids={"cam2", "cam3"},
                        command="start_capture",
                        refresh_interval=cfg.ACTIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                ]
            ),
            TestScenarioEntry(
                input_data=ev_message_in(
                    camera_id="cam2",
                    detected_edges={"U5.1", "U5.2"},
                    missing_edges=set(),
                ),
                etcd_outputs=[
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.fourth_ply_partially_covered),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.fifth_ply_placed_update_by_cam2),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.sixth_ply_expected),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam1": {"detectedEdges": ["U1.1", "U2.1"]},
                        "cam2": {"detectedEdges": ["U3.1", "U4.1", "U5.1", "U5.2"],
                                 "missingEdges": ["U6.1", "U6.2"]},
                        "cam3": {"detectedEdges": ["U5.1", "U5.2"],
                                 "missingEdges": ["U6.1", "U6.2"]}},
                        session_cam_id="cam2",
                        layers=["layer_U"],
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_U": {"pallets": {"pallet_1": {"missingPlies": 0,
                                                                                       "placedPlies": 5,
                                                                                       "totalPlies": 7}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_U_1,
                        ],
                            session=ev_message_session("cam2")
                        ),
                        "correctlyPlacedPlies": {
                            **mock_data.StaticGraph.FirstPalletU.fifth_ply,
                        },
                        "pliesToBePlaced": {
                            **mock_data.StaticGraph.FirstPalletU.sixth_ply,
                        },
                        "newMissingPlies": {},
                        "noLongerMissingPlies": {},
                        "forcedPlies": {},
                        "removedPlies": {}
                    }),
                    laser_out(payload=mock_data.LaserFeedbacks.CorrectlyPlacedPlies.FirstPalletU.fifth_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.FirstPalletU.sixth_ply),
                    camera_out(
                        camera_ids={"cam1"},
                        command="start_capture",
                        refresh_interval=cfg.PASSIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                    camera_out(
                        camera_ids={"cam2", "cam3"},
                        command="start_capture",
                        refresh_interval=cfg.ACTIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                ]
            ),
            # on EV msg sixth ply fully covers multiple plies
            TestScenarioEntry(
                input_data=ev_message_in(
                    camera_id="cam2",
                    detected_edges={"U6.1", "U6.2"},
                    missing_edges={"U3.1", "U4.1", "U5.1", "U5.2"},
                ),
                etcd_outputs=[
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.first_ply_fully_covered_by_U6),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.second_ply_fully_covered_by_U6),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.third_ply_fully_covered_by_U6),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.fourth_ply_fully_covered_by_U6),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.fifth_ply_fully_covered_by_U6),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.sixth_ply_placed_by_cam2),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.seventh_ply_expected),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam2": {"detectedEdges": ["U6.1", "U6.2"],
                                 "missingEdges": ["U7.1", "U7.2"]},
                        "cam3": {"detectedEdges": ["U6.1", "U6.2"],
                                 "missingEdges": ["U7.1", "U7.2"]}},
                        session_cam_id="cam2",
                        layers=["layer_U"],
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_U": {"pallets": {"pallet_1": {"missingPlies": 0,
                                                                                       "placedPlies": 6,
                                                                                       "totalPlies": 7}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_U_1,
                        ],
                            session=ev_message_session("cam2")
                        ),
                        "correctlyPlacedPlies": {
                            **mock_data.StaticGraph.FirstPalletU.sixth_ply,
                        },
                        "pliesToBePlaced": {
                            **mock_data.StaticGraph.FirstPalletU.seventh_ply,
                        },
                        "newMissingPlies": {},
                        "noLongerMissingPlies": {},
                        "forcedPlies": {},
                        "removedPlies": {}
                    }),
                    laser_out(payload=mock_data.LaserFeedbacks.CorrectlyPlacedPlies.FirstPalletU.sixth_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.FirstPalletU.seventh_ply),
                    camera_out(
                        camera_ids={"cam1"},
                        command="start_capture",
                        refresh_interval=cfg.PASSIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                    camera_out(
                        camera_ids={"cam2", "cam3"},
                        command="start_capture",
                        refresh_interval=cfg.ACTIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                ]
            ),
            # the last ply placed
            TestScenarioEntry(
                input_data=ev_message_in(
                    camera_id="cam2",
                    detected_edges={"U6.1", "U7.1", "U7.2"},
                    missing_edges={"U6.2"}
                ),
                etcd_outputs=[
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.sixth_ply_partially_covered_by_cam2),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.seventh_ply_placed_updated_by_cam2),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                    },
                        session_cam_id="cam2",
                        layers=["layer_U"],
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_U": {"pallets": {"pallet_1": {"missingPlies": 0,
                                                                                       "placedPlies": 7,
                                                                                       "totalPlies": 7}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_U_1,
                        ],
                            session=ev_message_session("cam2")
                        ),
                        "correctlyPlacedPlies": {
                            **mock_data.StaticGraph.FirstPalletU.seventh_ply,
                        },
                        "pliesToBePlaced": {},
                        "newMissingPlies": {},
                        "noLongerMissingPlies": {
                            **mock_data.StaticGraph.FirstPalletU.sixth_ply,
                        },
                        "forcedPlies": {},
                        "removedPlies": {}
                    }),
                    laser_out(payload=mock_data.LaserFeedbacks.LastPliesPlaced.FirstPalletU.seventh_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToNull.FirstPalletU.sixth_ply),
                    camera_out(
                        camera_ids={"cam2", "cam3", "cam1"},
                        command="start_capture",
                        refresh_interval=cfg.PASSIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                ]
            ),
        ]
        return {
            "entries": entries,
            "graph_data": {
                "mould_id": "mould_id",
                "blade_revision": "blade_revision",
                "version": "v1.0.0",
                "plies": {
                    **mock_data.StaticGraph.FirstPalletU.first_ply,
                    **mock_data.StaticGraph.FirstPalletU.second_ply,
                    **mock_data.StaticGraph.FirstPalletU.third_ply,
                    **mock_data.StaticGraph.FirstPalletU.fourth_ply,
                    **mock_data.StaticGraph.FirstPalletU.fifth_ply,
                    **mock_data.StaticGraph.FirstPalletU.sixth_ply,
                    **mock_data.StaticGraph.FirstPalletU.seventh_ply,
                }
            },
            "edge_to_cameras_data": {
                "mould_id": "mould_id",
                "blade_revision": "blade_revision",
                "version": "v1.0.0",
                "edges": {
                    "U1.1": ["cam1"],
                    "U1.2": ["cam1"],
                    "U2.1": ["cam1"],
                    "U2.2": ["cam1", "cam2"],
                    "U3.1": ["cam2"],
                    "U3.2": ["cam2"],
                    "U4.1": ["cam2"],
                    "U4.2": ["cam2"],
                    "U5.1": ["cam2", "cam3"],
                    "U5.2": ["cam2", "cam3"],
                    "U6.1": ["cam2", "cam3"],
                    "U6.2": ["cam2", "cam3"],
                    "U7.1": ["cam2", "cam3"],
                    "U7.2": ["cam2", "cam3"],
                }
            },
        }

    @staticmethod
    def multiple_plies_by_multiple_teams_are_placed_one_by_one():
        entries = [
            TestScenarioEntry(
                input_data=add_team_instruction_c2dm_request(mock_data.TeamInstructions.pallet_P_1),
                etcd_outputs=[
                    etcd_instruction_out(instruction=mock_data.TeamInstructions.pallet_P_1),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.first_ply_expected_without_invisible_edge),
                    etcd_mould_state_out(state=GlobalMouldState.PRODUCTION),
                    etcd_mould_blade_sn_out(blade_sn="blade_sn"),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam1": {"missingEdges": ["P1.2"]}},
                    ),
                    camera_out(
                        camera_ids={"cam1"},
                        command="start_capture",
                        refresh_interval=cfg.ACTIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_P": {"pallets": {"pallet_1": {"missingPlies": 0,
                                                                                       "placedPlies": 0,
                                                                                       "totalPlies": 3}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_P_1
                        ]),
                        "correctlyPlacedPlies": {},
                        "pliesToBePlaced": {
                            **mock_data.StaticGraph.FirstPalletP.first_ply_invisible_edge_removed,
                        },
                        "newMissingPlies": {},
                        "noLongerMissingPlies": {},
                        "forcedPlies": {},
                        "removedPlies": {}
                    }),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.FirstPalletP.first_ply),
                ]
            ),
            TestScenarioEntry(
                input_data=add_team_instruction_c2dm_request(mock_data.TeamInstructions.pallet_P_2),
                etcd_outputs=[
                    etcd_instruction_out(instruction=mock_data.TeamInstructions.pallet_P_2),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.first_ply_expected_without_invisible_edge),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.fourth_ply_expected),
                    etcd_mould_state_out(state=GlobalMouldState.PRODUCTION),
                    etcd_mould_blade_sn_out(blade_sn="blade_sn"),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam1": {"missingEdges": ["P1.2"]},
                        "cam3": {"missingEdges": ["P4.1", "P4.2"]},
                        "cam4": {"missingEdges": ["P4.2"]}},
                    ),
                    camera_out(
                        camera_ids={"cam1", "cam3", "cam4"},
                        command="start_capture",
                        refresh_interval=cfg.ACTIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_P": {"pallets": {"pallet_1": {"missingPlies": 0,
                                                                                       "placedPlies": 0,
                                                                                       "totalPlies": 3},
                                                                          "pallet_2": {"missingPlies": 0,
                                                                                       "placedPlies": 0,
                                                                                       "totalPlies": 3}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_P_1,
                            mock_data.TeamInstructions.pallet_P_2
                        ]),
                        "correctlyPlacedPlies": {},
                        "pliesToBePlaced": {
                            **mock_data.StaticGraph.FirstPalletP.first_ply_invisible_edge_removed,
                            **mock_data.StaticGraph.SecondPalletP.fourth_ply,
                        },
                        "newMissingPlies": {},
                        "noLongerMissingPlies": {},
                        "forcedPlies": {},
                        "removedPlies": {}
                    }),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.FirstPalletP.first_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.SecondPalletP.fourth_ply),
                ]
            ),
            TestScenarioEntry(
                input_data=add_team_instruction_c2dm_request(mock_data.TeamInstructions.pallet_P_3),
                etcd_outputs=[
                    etcd_instruction_out(instruction=mock_data.TeamInstructions.pallet_P_3),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.first_ply_expected_without_invisible_edge),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.fourth_ply_expected),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.seventh_ply_expected),
                    etcd_mould_state_out(state=GlobalMouldState.PRODUCTION),
                    etcd_mould_blade_sn_out(blade_sn="blade_sn"),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam1": {"missingEdges": ["P1.2"]},
                        "cam3": {"missingEdges": ["P4.1", "P4.2"]},
                        "cam4": {"missingEdges": ["P4.2"]},
                        "cam5": {"missingEdges": ["P7.1", "P7.2"]},
                        "cam6": {"missingEdges": ["P7.2"]}},
                    ),
                    camera_out(
                        camera_ids={"cam1", "cam3", "cam4", "cam5", "cam6"},
                        command="start_capture",
                        refresh_interval=cfg.ACTIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_P": {"pallets": {"pallet_1": {"missingPlies": 0,
                                                                                       "placedPlies": 0,
                                                                                       "totalPlies": 3},
                                                                          "pallet_2": {"missingPlies": 0,
                                                                                       "placedPlies": 0,
                                                                                       "totalPlies": 3},
                                                                          "pallet_3": {"missingPlies": 0,
                                                                                       "placedPlies": 0,
                                                                                       "totalPlies": 3}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_P_1,
                            mock_data.TeamInstructions.pallet_P_2,
                            mock_data.TeamInstructions.pallet_P_3,
                        ]),
                        "correctlyPlacedPlies": {},
                        "pliesToBePlaced": {
                            **mock_data.StaticGraph.FirstPalletP.first_ply_invisible_edge_removed,
                            **mock_data.StaticGraph.SecondPalletP.fourth_ply,
                            **mock_data.StaticGraph.ThirdPalletP.seventh_ply,
                        },
                        "newMissingPlies": {},
                        "noLongerMissingPlies": {},
                        "forcedPlies": {},
                        "removedPlies": {}
                    }),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.FirstPalletP.first_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.SecondPalletP.fourth_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.ThirdPalletP.seventh_ply),
                ]
            ),
            TestScenarioEntry(
                input_data=ev_message_in(
                    camera_id="cam1",
                    detected_edges={"P1.2"},
                    missing_edges=set()
                ),
                etcd_outputs=[
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.first_ply_placed_without_invisible_edge),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.second_ply_expected),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.fourth_ply_expected),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.seventh_ply_expected),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam1": {"detectedEdges": ["P1.2"], "missingEdges": ["P2.1"]},
                        "cam2": {"missingEdges": ["P2.1", "P2.2"]},
                        "cam3": {"missingEdges": ["P4.1", "P4.2"]},
                        "cam4": {"missingEdges": ["P4.2"]},
                        "cam5": {"missingEdges": ["P7.1", "P7.2"]},
                        "cam6": {"missingEdges": ["P7.2"]}},
                        session_cam_id="cam1"
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_P": {"pallets": {"pallet_1": {"missingPlies": 0,
                                                                                       "placedPlies": 1,
                                                                                       "totalPlies": 3},
                                                                          "pallet_2": {"missingPlies": 0,
                                                                                       "placedPlies": 0,
                                                                                       "totalPlies": 3},
                                                                          "pallet_3": {"missingPlies": 0,
                                                                                       "placedPlies": 0,
                                                                                       "totalPlies": 3}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_P_1,
                            mock_data.TeamInstructions.pallet_P_2,
                            mock_data.TeamInstructions.pallet_P_3,
                        ],
                            session=ev_message_session("cam1")
                        ),
                        "correctlyPlacedPlies": {
                            **mock_data.StaticGraph.FirstPalletP.first_ply_invisible_edge_removed,
                        },
                        "pliesToBePlaced": {
                            **mock_data.StaticGraph.FirstPalletP.second_ply,
                            **mock_data.StaticGraph.SecondPalletP.fourth_ply,
                            **mock_data.StaticGraph.ThirdPalletP.seventh_ply,
                        },
                        "newMissingPlies": {},
                        "noLongerMissingPlies": {},
                        "forcedPlies": {},
                        "removedPlies": {}
                    }),
                    laser_out(payload=mock_data.LaserFeedbacks.CorrectlyPlacedPlies.FirstPalletP.first_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.FirstPalletP.second_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.SecondPalletP.fourth_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.ThirdPalletP.seventh_ply),
                    camera_out(
                        camera_ids={"cam1", "cam2", "cam3", "cam4", "cam5", "cam6"},
                        command="start_capture",
                        refresh_interval=cfg.ACTIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                ]
            ),
            TestScenarioEntry(
                input_data=ev_message_in(
                    camera_id="cam3",
                    detected_edges={"P4.1", "P4.2"},
                    missing_edges=set()
                ),
                etcd_outputs=[
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.second_ply_expected),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.fourth_ply_placed),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.fifth_ply_expected),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.seventh_ply_expected),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam1": {"detectedEdges": ["P1.2"], "missingEdges": ["P2.1"]},
                        "cam2": {"missingEdges": ["P2.1", "P2.2"]},
                        "cam3": {"detectedEdges": ["P4.1", "P4.2"]},
                        "cam4": {"detectedEdges": ["P4.2"], "missingEdges": ["P5.1", "P5.2"]},
                        "cam5": {"missingEdges": ["P7.1", "P7.2"]},
                        "cam6": {"missingEdges": ["P7.2"]}},
                        session_cam_id="cam3"
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_P": {"pallets": {"pallet_1": {"missingPlies": 0,
                                                                                       "placedPlies": 1,
                                                                                       "totalPlies": 3},
                                                                          "pallet_2": {"missingPlies": 0,
                                                                                       "placedPlies": 1,
                                                                                       "totalPlies": 3},
                                                                          "pallet_3": {"missingPlies": 0,
                                                                                       "placedPlies": 0,
                                                                                       "totalPlies": 3}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_P_1,
                            mock_data.TeamInstructions.pallet_P_2,
                            mock_data.TeamInstructions.pallet_P_3,
                        ],
                            session=ev_message_session("cam3")
                        ),
                        "correctlyPlacedPlies": {
                            **mock_data.StaticGraph.SecondPalletP.fourth_ply,
                        },
                        "pliesToBePlaced": {
                            **mock_data.StaticGraph.FirstPalletP.second_ply,
                            **mock_data.StaticGraph.SecondPalletP.fifth_ply,
                            **mock_data.StaticGraph.ThirdPalletP.seventh_ply,
                        },
                        "newMissingPlies": {},
                        "noLongerMissingPlies": {},
                        "forcedPlies": {},
                        "removedPlies": {}
                    }),
                    laser_out(payload=mock_data.LaserFeedbacks.CorrectlyPlacedPlies.SecondPalletP.fourth_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.FirstPalletP.second_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.SecondPalletP.fifth_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.ThirdPalletP.seventh_ply),
                    camera_out(
                        camera_ids={"cam3"},
                        command="start_capture",
                        refresh_interval=cfg.PASSIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                    camera_out(
                        camera_ids={"cam2", "cam1", "cam4", "cam5", "cam6"},
                        command="start_capture",
                        refresh_interval=cfg.ACTIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                ]
            ),
            TestScenarioEntry(
                input_data=ev_message_in(
                    camera_id="cam5",
                    detected_edges={"P7.1", "P7.2"},
                    missing_edges=set()
                ),
                etcd_outputs=[
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.second_ply_expected),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.fifth_ply_expected),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.seventh_ply_placed),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.eighth_ply_expected),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam1": {"detectedEdges": ["P1.2"], "missingEdges": ["P2.1"]},
                        "cam2": {"missingEdges": ["P2.1", "P2.2"]},
                        "cam3": {"detectedEdges": ["P4.1", "P4.2"]},
                        "cam4": {"detectedEdges": ["P4.2"], "missingEdges": ["P5.1", "P5.2"]},
                        "cam5": {"detectedEdges": ["P7.1", "P7.2"]},
                        "cam6": {"detectedEdges": ["P7.2"],
                                 "missingEdges": ["P8.1", "P8.2"]}},
                        session_cam_id="cam5"
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_P": {"pallets": {"pallet_1": {"missingPlies": 0,
                                                                                       "placedPlies": 1,
                                                                                       "totalPlies": 3},
                                                                          "pallet_2": {"missingPlies": 0,
                                                                                       "placedPlies": 1,
                                                                                       "totalPlies": 3},
                                                                          "pallet_3": {"missingPlies": 0,
                                                                                       "placedPlies": 1,
                                                                                       "totalPlies": 3}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_P_1,
                            mock_data.TeamInstructions.pallet_P_2,
                            mock_data.TeamInstructions.pallet_P_3,
                        ],
                            session=ev_message_session("cam5")
                        ),
                        "correctlyPlacedPlies": {
                            **mock_data.StaticGraph.ThirdPalletP.seventh_ply,
                        },
                        "pliesToBePlaced": {
                            **mock_data.StaticGraph.FirstPalletP.second_ply,
                            **mock_data.StaticGraph.SecondPalletP.fifth_ply,
                            **mock_data.StaticGraph.ThirdPalletP.eighth_ply,
                        },
                        "newMissingPlies": {},
                        "noLongerMissingPlies": {},
                        "forcedPlies": {},
                        "removedPlies": {}
                    }),
                    laser_out(payload=mock_data.LaserFeedbacks.CorrectlyPlacedPlies.ThirdPalletP.seventh_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.FirstPalletP.second_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.SecondPalletP.fifth_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.ThirdPalletP.eighth_ply),
                    camera_out(
                        camera_ids={"cam3", "cam5"},
                        command="start_capture",
                        refresh_interval=cfg.PASSIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                    camera_out(
                        camera_ids={"cam1", "cam2", "cam4", "cam6"},
                        command="start_capture",
                        refresh_interval=cfg.ACTIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                ]
            ),
            TestScenarioEntry(
                input_data=ev_message_in(
                    camera_id="cam2",
                    detected_edges={"P2.1", "P2.2"},
                    missing_edges=set()
                ),
                etcd_outputs=[
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.first_ply_covered_without_invisible_edge),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.second_ply_placed),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.third_ply_expected),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.fifth_ply_expected),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.eighth_ply_expected),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam1": {"detectedEdges": ["P2.1"]},
                        "cam2": {"detectedEdges": ["P2.1", "P2.2"], "missingEdges": ["P3.1"]},
                        "cam3": {"detectedEdges": ["P4.1", "P4.2"], "missingEdges": ["P3.2"]},
                        "cam4": {"detectedEdges": ["P4.2"], "missingEdges": ["P5.1", "P5.2"]},
                        "cam5": {"detectedEdges": ["P7.1", "P7.2"]},
                        "cam6": {"detectedEdges": ["P7.2"],
                                 "missingEdges": ["P8.1", "P8.2"]}},
                        session_cam_id="cam2"
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_P": {"pallets": {"pallet_1": {"missingPlies": 0,
                                                                                       "placedPlies": 2,
                                                                                       "totalPlies": 3},
                                                                          "pallet_2": {"missingPlies": 0,
                                                                                       "placedPlies": 1,
                                                                                       "totalPlies": 3},
                                                                          "pallet_3": {"missingPlies": 0,
                                                                                       "placedPlies": 1,
                                                                                       "totalPlies": 3}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_P_1,
                            mock_data.TeamInstructions.pallet_P_2,
                            mock_data.TeamInstructions.pallet_P_3,
                        ],
                            session=ev_message_session("cam2")
                        ),
                        "correctlyPlacedPlies": {
                            **mock_data.StaticGraph.FirstPalletP.second_ply,
                        },
                        "pliesToBePlaced": {
                            **mock_data.StaticGraph.FirstPalletP.third_ply,
                            **mock_data.StaticGraph.SecondPalletP.fifth_ply,
                            **mock_data.StaticGraph.ThirdPalletP.eighth_ply,
                        },
                        "newMissingPlies": {},
                        "noLongerMissingPlies": {},
                        "forcedPlies": {},
                        "removedPlies": {}
                    }),
                    laser_out(payload=mock_data.LaserFeedbacks.CorrectlyPlacedPlies.FirstPalletP.second_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.FirstPalletP.third_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.SecondPalletP.fifth_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.ThirdPalletP.eighth_ply),
                    camera_out(
                        camera_ids={"cam1", "cam5"},
                        command="start_capture",
                        refresh_interval=cfg.PASSIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                    camera_out(
                        camera_ids={"cam3", "cam2", "cam4", "cam6"},
                        command="start_capture",
                        refresh_interval=cfg.ACTIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                ]
            ),
            TestScenarioEntry(
                input_data=ev_message_in(
                    camera_id="cam4",
                    detected_edges={"P5.1", "P5.2"},
                    missing_edges=set()
                ),
                etcd_outputs=[
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.third_ply_expected),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.fourth_ply_partially_covered),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.fifth_ply_placed),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.sixth_ply_expected),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.eighth_ply_expected),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam1": {"detectedEdges": ["P2.1"]},
                        "cam2": {"detectedEdges": ["P2.1", "P2.2"], "missingEdges": ["P3.1"]},
                        "cam3": {"missingEdges": ["P3.2"]},
                        "cam4": {"detectedEdges": ["P5.1", "P5.2"], "missingEdges": ["P6.1"]},
                        "cam5": {"detectedEdges": ["P7.1", "P7.2"],
                                 "missingEdges": ["P6.1", "P6.2"]},
                        "cam6": {"detectedEdges": ["P7.2"],
                                 "missingEdges": ["P8.1", "P8.2"]}},
                        session_cam_id="cam4"
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_P": {"pallets": {"pallet_1": {"missingPlies": 0,
                                                                                       "placedPlies": 2,
                                                                                       "totalPlies": 3},
                                                                          "pallet_2": {"missingPlies": 0,
                                                                                       "placedPlies": 2,
                                                                                       "totalPlies": 3},
                                                                          "pallet_3": {"missingPlies": 0,
                                                                                       "placedPlies": 1,
                                                                                       "totalPlies": 3}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_P_1,
                            mock_data.TeamInstructions.pallet_P_2,
                            mock_data.TeamInstructions.pallet_P_3,
                        ],
                            session=ev_message_session("cam4")
                        ),
                        "correctlyPlacedPlies": {
                            **mock_data.StaticGraph.SecondPalletP.fifth_ply,
                        },
                        "pliesToBePlaced": {
                            **mock_data.StaticGraph.FirstPalletP.third_ply,
                            **mock_data.StaticGraph.SecondPalletP.sixth_ply,
                            **mock_data.StaticGraph.ThirdPalletP.eighth_ply,
                        },
                        "newMissingPlies": {},
                        "noLongerMissingPlies": {},
                        "forcedPlies": {},
                        "removedPlies": {}
                    }),
                    laser_out(payload=mock_data.LaserFeedbacks.CorrectlyPlacedPlies.SecondPalletP.fifth_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.FirstPalletP.third_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.SecondPalletP.sixth_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.ThirdPalletP.eighth_ply),
                    camera_out(
                        camera_ids={"cam1"},
                        command="start_capture",
                        refresh_interval=cfg.PASSIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                    camera_out(
                        camera_ids={"cam3", "cam2", "cam4", "cam5", "cam6"},
                        command="start_capture",
                        refresh_interval=cfg.ACTIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                ]
            ),
            TestScenarioEntry(
                input_data=ev_message_in(
                    camera_id="cam6",
                    detected_edges={"P8.1", "P8.2"},
                    missing_edges={"P7.2"}
                ),
                etcd_outputs=[
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.third_ply_expected),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.sixth_ply_expected),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.seventh_ply_partially_covered),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.eighth_ply_placed),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.ninth_ply_expected_without_invisible_edge),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam1": {"detectedEdges": ["P2.1"]},
                        "cam2": {"detectedEdges": ["P2.1", "P2.2"], "missingEdges": ["P3.1"]},
                        "cam3": {"missingEdges": ["P3.2"]},
                        "cam4": {"detectedEdges": ["P5.1", "P5.2"], "missingEdges": ["P6.1"]},
                        "cam5": {"missingEdges": ["P6.1", "P6.2"]},
                        "cam6": {"detectedEdges": ["P8.1", "P8.2"],
                                 "missingEdges": ["P9.1"]}},
                        session_cam_id="cam6"
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_P": {"pallets": {"pallet_1": {"missingPlies": 0,
                                                                                       "placedPlies": 2,
                                                                                       "totalPlies": 3},
                                                                          "pallet_2": {"missingPlies": 0,
                                                                                       "placedPlies": 2,
                                                                                       "totalPlies": 3},
                                                                          "pallet_3": {"missingPlies": 0,
                                                                                       "placedPlies": 2,
                                                                                       "totalPlies": 3}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_P_1,
                            mock_data.TeamInstructions.pallet_P_2,
                            mock_data.TeamInstructions.pallet_P_3,
                        ],
                            session=ev_message_session("cam6")
                        ),
                        "correctlyPlacedPlies": {
                            **mock_data.StaticGraph.ThirdPalletP.eighth_ply,
                        },
                        "pliesToBePlaced": {
                            **mock_data.StaticGraph.FirstPalletP.third_ply,
                            **mock_data.StaticGraph.SecondPalletP.sixth_ply,
                            **mock_data.StaticGraph.ThirdPalletP.ninth_ply_invisible_edge_removed,
                        },
                        "newMissingPlies": {},
                        "noLongerMissingPlies": {},
                        "forcedPlies": {},
                        "removedPlies": {}
                    }),
                    laser_out(payload=mock_data.LaserFeedbacks.CorrectlyPlacedPlies.ThirdPalletP.eighth_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.FirstPalletP.third_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.SecondPalletP.sixth_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.ThirdPalletP.ninth_ply),
                    camera_out(
                        camera_ids={"cam1"},
                        command="start_capture",
                        refresh_interval=cfg.PASSIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                    camera_out(
                        camera_ids={"cam3", "cam2", "cam4", "cam5", "cam6"},
                        command="start_capture",
                        refresh_interval=cfg.ACTIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                ]
            ),
            TestScenarioEntry(
                input_data=ev_message_in(
                    camera_id="cam2",
                    detected_edges={"P3.1"},
                    missing_edges={"P2.2"},
                ),
                etcd_outputs=[
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.second_ply_missing_by_cam2),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.third_ply_expected_cam2_edge_detected),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.sixth_ply_expected),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.ninth_ply_expected_without_invisible_edge),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam1": {"detectedEdges": ["P2.1"]},
                        "cam2": {"detectedEdges": ["P2.1", "P3.1"], "missingEdges": ["P2.2"]},
                        "cam3": {"missingEdges": ["P3.2"]},
                        "cam4": {"detectedEdges": ["P5.1", "P5.2"], "missingEdges": ["P6.1"]},
                        "cam5": {"missingEdges": ["P6.1", "P6.2"]},
                        "cam6": {"detectedEdges": ["P8.1", "P8.2"], "missingEdges": ["P9.1"]}},
                        session_cam_id="cam2"
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_P": {"pallets": {"pallet_1": {"missingPlies": 1,
                                                                                       "placedPlies": 2,
                                                                                       "totalPlies": 3},
                                                                          "pallet_2": {"missingPlies": 0,
                                                                                       "placedPlies": 2,
                                                                                       "totalPlies": 3},
                                                                          "pallet_3": {"missingPlies": 0,
                                                                                       "placedPlies": 2,
                                                                                       "totalPlies": 3}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_P_1,
                            mock_data.TeamInstructions.pallet_P_2,
                            mock_data.TeamInstructions.pallet_P_3,
                        ],
                            session=ev_message_session("cam2")
                        ),
                        "correctlyPlacedPlies": {},
                        "pliesToBePlaced": {
                            **mock_data.StaticGraph.FirstPalletP.third_ply,
                            **mock_data.StaticGraph.SecondPalletP.sixth_ply,
                            **mock_data.StaticGraph.ThirdPalletP.ninth_ply_invisible_edge_removed,
                        },
                        "newMissingPlies": {
                            **mock_data.StaticGraph.FirstPalletP.second_ply,
                        },
                        "noLongerMissingPlies": {},
                        "forcedPlies": {},
                        "removedPlies": {}
                    }),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.FirstPalletP.third_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.SecondPalletP.sixth_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.ThirdPalletP.ninth_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.MissingPlies.FirstPalletP.second_ply),
                    camera_out(
                        camera_ids={"cam1", "cam3", "cam2", "cam4", "cam5", "cam6"},
                        command="start_capture",
                        refresh_interval=cfg.ACTIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                ]
            ),
            TestScenarioEntry(
                input_data=ev_message_in(
                    camera_id="cam3",
                    detected_edges={"P3.2"},
                    missing_edges=set()
                ),
                etcd_outputs=[
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.second_ply_partially_covered),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.third_ply_placed_updated_by_cam_3),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.sixth_ply_expected),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.ninth_ply_expected_without_invisible_edge),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam4": {"detectedEdges": ["P5.1", "P5.2"], "missingEdges": ["P6.1"]},
                        "cam5": {"missingEdges": ["P6.1", "P6.2"]},
                        "cam6": {"detectedEdges": ["P8.1", "P8.2"],
                                 "missingEdges": ["P9.1"]}},
                        session_cam_id="cam3"
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_P": {"pallets": {"pallet_1": {"missingPlies": 0,
                                                                                       "placedPlies": 3,
                                                                                       "totalPlies": 3},
                                                                          "pallet_2": {"missingPlies": 0,
                                                                                       "placedPlies": 2,
                                                                                       "totalPlies": 3},
                                                                          "pallet_3": {"missingPlies": 0,
                                                                                       "placedPlies": 2,
                                                                                       "totalPlies": 3}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_P_1,
                            mock_data.TeamInstructions.pallet_P_2,
                            mock_data.TeamInstructions.pallet_P_3,
                        ],
                            session=ev_message_session("cam3")
                        ),
                        "correctlyPlacedPlies": {
                            **mock_data.StaticGraph.FirstPalletP.third_ply,
                        },
                        "pliesToBePlaced": {
                            **mock_data.StaticGraph.SecondPalletP.sixth_ply,
                            **mock_data.StaticGraph.ThirdPalletP.ninth_ply_invisible_edge_removed,
                        },
                        "newMissingPlies": {},
                        "noLongerMissingPlies": {
                            **mock_data.StaticGraph.FirstPalletP.second_ply,
                        },
                        "forcedPlies": {},
                        "removedPlies": {}
                    }),
                    laser_out(payload=mock_data.LaserFeedbacks.CorrectlyPlacedPlies.FirstPalletP.third_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.SecondPalletP.sixth_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.ThirdPalletP.ninth_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToNull.FirstPalletP.second_ply),
                    camera_out(
                        camera_ids={"cam3", "cam2", "cam1"},
                        command="start_capture",
                        refresh_interval=cfg.PASSIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                    camera_out(
                        camera_ids={"cam4", "cam5", "cam6"},
                        command="start_capture",
                        refresh_interval=cfg.ACTIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                ]
            ),
            TestScenarioEntry(
                input_data=ev_message_in(
                    camera_id="cam5",
                    detected_edges={"P6.1", "P6.2"},
                    missing_edges=set()
                ),
                etcd_outputs=[
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.fifth_ply_partially_covered),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.sixth_ply_placed),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.ninth_ply_expected_without_invisible_edge),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam6": {"detectedEdges": ["P8.1", "P8.2"],
                                 "missingEdges": ["P9.1"]}},
                        session_cam_id="cam5"
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_P": {"pallets": {"pallet_1": {"missingPlies": 0,
                                                                                       "placedPlies": 3,
                                                                                       "totalPlies": 3},
                                                                          "pallet_2": {"missingPlies": 0,
                                                                                       "placedPlies": 3,
                                                                                       "totalPlies": 3},
                                                                          "pallet_3": {"missingPlies": 0,
                                                                                       "placedPlies": 2,
                                                                                       "totalPlies": 3}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_P_1,
                            mock_data.TeamInstructions.pallet_P_2,
                            mock_data.TeamInstructions.pallet_P_3,
                        ],
                            session=ev_message_session("cam5")
                        ),
                        "correctlyPlacedPlies": {
                            **mock_data.StaticGraph.SecondPalletP.sixth_ply,
                        },
                        "pliesToBePlaced": {
                            **mock_data.StaticGraph.ThirdPalletP.ninth_ply_invisible_edge_removed,
                        },
                        "newMissingPlies": {},
                        "noLongerMissingPlies": {},
                        "forcedPlies": {},
                        "removedPlies": {}
                    }),
                    laser_out(payload=mock_data.LaserFeedbacks.CorrectlyPlacedPlies.SecondPalletP.sixth_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.ThirdPalletP.ninth_ply),
                    camera_out(
                        camera_ids={"cam3", "cam2", "cam4", "cam5", "cam1"},
                        command="start_capture",
                        refresh_interval=cfg.PASSIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                    camera_out(
                        camera_ids={"cam6"},
                        command="start_capture",
                        refresh_interval=cfg.ACTIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                ]
            ),
            TestScenarioEntry(
                input_data=ev_message_in(
                    camera_id="cam6",
                    detected_edges={"P8.1", "P9.1"},
                    missing_edges={"P8.2"},
                ),
                etcd_outputs=[
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.eighth_ply_partially_covered),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.ninth_ply_placed_without_invisible_edge),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={},
                                          session_cam_id="cam6"
                                          ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_P": {"pallets": {"pallet_1": {"missingPlies": 0,
                                                                                       "placedPlies": 3,
                                                                                       "totalPlies": 3},
                                                                          "pallet_2": {"missingPlies": 0,
                                                                                       "placedPlies": 3,
                                                                                       "totalPlies": 3},
                                                                          "pallet_3": {"missingPlies": 0,
                                                                                       "placedPlies": 3,
                                                                                       "totalPlies": 3}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_P_1,
                            mock_data.TeamInstructions.pallet_P_2,
                            mock_data.TeamInstructions.pallet_P_3,
                        ],
                            session=ev_message_session("cam6")
                        ),
                        "correctlyPlacedPlies": {
                            **mock_data.StaticGraph.ThirdPalletP.ninth_ply_invisible_edge_removed,
                        },
                        "pliesToBePlaced": {},
                        "newMissingPlies": {},
                        "noLongerMissingPlies": {
                            **mock_data.StaticGraph.ThirdPalletP.eighth_ply,
                        },
                        "forcedPlies": {},
                        "removedPlies": {}
                    }),
                    laser_out(payload=mock_data.LaserFeedbacks.LastPliesPlaced.ThirdPalletP.ninth_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToNull.ThirdPalletP.eighth_ply),
                    camera_out(
                        camera_ids={"cam3", "cam1", "cam2", "cam4", "cam5", "cam6"},
                        command="start_capture",
                        refresh_interval=cfg.PASSIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                ]
            ),
        ]
        return {
            "entries": entries,
        }

    @staticmethod
    def multiple_sub_graph_plies_from_multiple_pallets_are_already_placed_on_boot():
        entries = [
            # 1 On DM boot team instructions are preloaded from ETCD store, no input data
            TestScenarioEntry(
                input_data=instructions_loaded_on_boot(),
                etcd_outputs=[
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.sixth_ply_expected),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.ninth_ply_expected_without_invisible_edge),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam4": {"detectedEdges": ["P5.1"], "missingEdges": ["P6.1"]},
                        "cam5": {"missingEdges": ["P6.1", "P6.2"]},
                        "cam6": {"detectedEdges": ["P8.1", "P8.2"],
                                 "missingEdges": ["P9.1"]}},
                    ),
                    camera_out(
                        camera_ids={"cam1", "cam2", "cam3"},
                        command="start_capture",
                        refresh_interval=cfg.PASSIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                    camera_out(
                        camera_ids={"cam4", "cam5", "cam6"},
                        command="start_capture",
                        refresh_interval=cfg.ACTIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_P": {"pallets": {"pallet_1": {"missingPlies": 0,
                                                                                       "placedPlies": 3,
                                                                                       "totalPlies": 3},
                                                                          "pallet_2": {"missingPlies": 0,
                                                                                       "placedPlies": 2,
                                                                                       "totalPlies": 3},
                                                                          "pallet_3": {"missingPlies": 0,
                                                                                       "placedPlies": 2,
                                                                                       "totalPlies": 3}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_P_1,
                            mock_data.TeamInstructions.pallet_P_2,
                            mock_data.TeamInstructions.pallet_P_3,
                        ]),
                        "correctlyPlacedPlies": {},
                        "pliesToBePlaced": {
                            **mock_data.StaticGraph.SecondPalletP.sixth_ply,
                            **mock_data.StaticGraph.ThirdPalletP.ninth_ply_invisible_edge_removed,
                        },
                        "newMissingPlies": {},
                        "noLongerMissingPlies": {},
                        "forcedPlies": {},
                        "removedPlies": {}
                    }),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.SecondPalletP.sixth_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.ThirdPalletP.ninth_ply),
                ]
            ),
            # Third pallet"s last ply is detected and third pallet is completed
            TestScenarioEntry(
                input_data=ev_message_in(
                    camera_id="cam6",
                    detected_edges={"P8.1", "P9.1"},
                    missing_edges={"P8.2"}
                ),
                etcd_outputs=[
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.sixth_ply_expected),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.eighth_ply_partially_covered),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.ninth_ply_placed_without_invisible_edge),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam4": {"detectedEdges": ["P5.1"], "missingEdges": ["P6.1"]},
                        "cam5": {"missingEdges": ["P6.1", "P6.2"]}},
                        session_cam_id="cam6"
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_P": {"pallets": {"pallet_1": {"missingPlies": 0,
                                                                                       "placedPlies": 3,
                                                                                       "totalPlies": 3},
                                                                          "pallet_2": {"missingPlies": 0,
                                                                                       "placedPlies": 2,
                                                                                       "totalPlies": 3},
                                                                          "pallet_3": {"missingPlies": 0,
                                                                                       "placedPlies": 3,
                                                                                       "totalPlies": 3}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_P_1,
                            mock_data.TeamInstructions.pallet_P_2,
                            mock_data.TeamInstructions.pallet_P_3,
                        ],
                            session=ev_message_session("cam6")
                        ),
                        "correctlyPlacedPlies": {
                            **mock_data.StaticGraph.ThirdPalletP.ninth_ply_invisible_edge_removed,
                        },
                        "pliesToBePlaced": {
                            **mock_data.StaticGraph.SecondPalletP.sixth_ply,
                        },
                        "newMissingPlies": {},
                        "noLongerMissingPlies": {
                            **mock_data.StaticGraph.ThirdPalletP.eighth_ply,
                        },
                        "forcedPlies": {},
                        "removedPlies": {}
                    }),
                    laser_out(payload=mock_data.LaserFeedbacks.CorrectlyPlacedPlies.ThirdPalletP.ninth_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.SecondPalletP.sixth_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToNull.ThirdPalletP.eighth_ply),
                    camera_out(
                        camera_ids={"cam1", "cam2", "cam3", "cam6"},
                        command="start_capture",
                        refresh_interval=cfg.PASSIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                    camera_out(
                        camera_ids={"cam4", "cam5"},
                        command="start_capture",
                        refresh_interval=cfg.ACTIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                ]
            ),
        ]
        return {
            "entries": entries,
            "initial_mould_state_instructions_data": mould_state_instructions_data([
                mock_data.TeamInstructions.pallet_P_1,
                mock_data.TeamInstructions.pallet_P_2,
                mock_data.TeamInstructions.pallet_P_3,
            ]),
            "initial_mould_state_plies_data": mould_state_plies_data([
                mock_data.MouldStatePlies.PalletP.first_ply_covered_without_invisible_edge,
                mock_data.MouldStatePlies.PalletP.second_ply_partially_covered,
                mock_data.MouldStatePlies.PalletP.third_ply_partially_covered,
                mock_data.MouldStatePlies.PalletP.fourth_ply_partially_covered,
                mock_data.MouldStatePlies.PalletP.fifth_ply_partially_covered,
                mock_data.MouldStatePlies.PalletP.sixth_ply_expected,
                mock_data.MouldStatePlies.PalletP.seventh_ply_partially_covered,
                mock_data.MouldStatePlies.PalletP.eighth_ply_placed,
            ]),
            "initial_mould_state": GlobalMouldState.PRODUCTION,
            "initial_mould_blade_sn": "blade_sn",
        }

    @staticmethod
    def should_not_filter_missing_ply_when_1_of_2_edge_is_missing():
        entries = [
            # 1 on TI C2DM request first ply for pallet_U_1 is expected
            TestScenarioEntry(
                input_data=add_team_instruction_c2dm_request(instruction=mock_data.TeamInstructions.pallet_U_1),
            ),
            # 2 on EV msg first ply is detected, second ply is expected
            TestScenarioEntry(
                input_data=ev_message_in(
                    camera_id="cam1",
                    detected_edges={"U1.1", "U1.2"},
                    missing_edges=set()
                ),
            ),
            # 3 on EV msg second ply is detected, third ply is expected
            TestScenarioEntry(
                input_data=ev_message_in(
                    camera_id="cam1",
                    detected_edges={"U2.1", "U2.2"},
                    missing_edges={"U1.2"}
                ),
                etcd_outputs=[
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.first_ply_partially_covered),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.second_ply_placed),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.third_ply_expected),
                ],
            ),
            # 4 on EV msg first ply becomes missing but not by a coverable edge so is not filtered from outputs
            TestScenarioEntry(
                input_data=ev_message_in(
                    camera_id="cam1",
                    detected_edges={"U2.1", "U2.2"},
                    missing_edges={"U1.1"}
                ),
                etcd_outputs=[
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.first_ply_missing_due_being_covered),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.third_ply_expected),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam1": {"detectedEdges": ["U2.1", "U2.2"], "missingEdges": ["U1.1"]},
                        "cam2": {"detectedEdges": ["U2.2"], "missingEdges": ["U3.1", "U3.2"]}},
                        session_cam_id="cam1",
                        layers=["layer_U"],
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_U": {"pallets": {"pallet_1": {"missingPlies": 1,
                                                                                       "placedPlies": 2,
                                                                                       "totalPlies": 4}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_U_1,
                        ],
                            session=ev_message_session("cam1")
                        ),
                        "correctlyPlacedPlies": {},
                        "pliesToBePlaced": {
                            **mock_data.StaticGraph.FirstPalletU.third_ply,
                        },
                        "newMissingPlies": {
                            **mock_data.StaticGraph.FirstPalletU.first_ply,
                        },
                        "noLongerMissingPlies": {},
                        "forcedPlies": {},
                        "removedPlies": {}
                    }),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.FirstPalletU.third_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.MissingPlies.FirstPalletU.first_ply),
                    camera_out(
                        camera_ids={"cam1", "cam2"},
                        command="start_capture",
                        refresh_interval=cfg.ACTIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                ]
            ),
            # 5 on EV msg thirst ply is detected and becomes placed
            TestScenarioEntry(
                input_data=ev_message_in(
                    camera_id="cam1",
                    detected_edges={"U1.1"},
                    missing_edges=set(),
                ),
                etcd_outputs=[
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.first_ply_partially_covered_on_missing),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.third_ply_expected),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam1": {"detectedEdges": ["U2.1", "U2.2"]},
                        "cam2": {"detectedEdges": ["U2.2"], "missingEdges": ["U3.1", "U3.2"]}},
                        session_cam_id="cam1",
                        layers=["layer_U"],
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_U": {"pallets": {"pallet_1": {"missingPlies": 0,
                                                                                       "placedPlies": 2,
                                                                                       "totalPlies": 4}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_U_1,
                        ],
                            session=ev_message_session("cam1")
                        ),
                        "correctlyPlacedPlies": {},
                        "pliesToBePlaced": {
                            **mock_data.StaticGraph.FirstPalletU.third_ply,
                        },
                        "newMissingPlies": {},
                        "noLongerMissingPlies": {
                            **mock_data.StaticGraph.FirstPalletU.first_ply,
                        },
                        "forcedPlies": {},
                        "removedPlies": {}
                    }),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.FirstPalletU.third_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToNull.FirstPalletU.first_ply),
                    camera_out(
                        camera_ids={"cam1"},
                        command="start_capture",
                        refresh_interval=cfg.PASSIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                    camera_out(
                        camera_ids={"cam2"},
                        command="start_capture",
                        refresh_interval=cfg.ACTIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                ]
            ),
            # 6 EV - the flow continues...
            TestScenarioEntry(
                input_data=ev_message_in(
                    camera_id="cam2",
                    detected_edges={"U3.1", "U3.2"},
                    missing_edges={"U2.2"}
                ),
                etcd_outputs=[
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.second_ply_partially_covered),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.third_ply_placed_updated_by_cam_2),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.fourth_ply_expected),
                ],
            ),
        ]
        return {
            "entries": entries,
            "graph_data": {
                "mould_id": "mould_id",
                "blade_revision": "blade_revision",
                "version": "v1.0.0",
                "plies": {
                    **mock_data.StaticGraph.FirstPalletU.first_ply,
                    **mock_data.StaticGraph.FirstPalletU.second_ply,
                    **mock_data.StaticGraph.FirstPalletU.third_ply,
                    **mock_data.StaticGraph.FirstPalletU.fourth_ply,
                }
            },
        }

    @staticmethod
    def should_not_filter_missing_ply_when_2_of_2_edge_are_missing():
        entries = [
            # on TI C2DM request first ply for pallet_U_1 is expected
            TestScenarioEntry(
                input_data=add_team_instruction_c2dm_request(instruction=mock_data.TeamInstructions.pallet_U_1),
            ),
            # on EV msg first ply is detected, second ply is expected
            TestScenarioEntry(
                input_data=ev_message_in(
                    camera_id="cam1",
                    detected_edges={"U1.1", "U1.2"},
                    missing_edges=set()
                ),
            ),
            # on EV msg second ply is detected, third ply is expected
            TestScenarioEntry(
                input_data=ev_message_in(
                    camera_id="cam1",
                    detected_edges={"U2.1", "U2.2"},
                    missing_edges={"U1.2"}
                ),
                etcd_outputs=[
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.first_ply_partially_covered),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.second_ply_placed),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.third_ply_expected),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam1": {"detectedEdges": ["U2.1", "U2.2"]},
                        "cam2": {"detectedEdges": ["U2.2"], "missingEdges": ["U3.1", "U3.2"]}},
                        session_cam_id="cam1",
                        layers=["layer_U"],
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_U": {"pallets": {"pallet_1": {"missingPlies": 0,
                                                                                       "placedPlies": 2,
                                                                                       "totalPlies": 4}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_U_1,
                        ],
                            session=ev_message_session("cam1")
                        ),
                        "correctlyPlacedPlies": {
                            **mock_data.StaticGraph.FirstPalletU.second_ply,
                        },
                        "pliesToBePlaced": {
                            **mock_data.StaticGraph.FirstPalletU.third_ply_does_not_cover_second_ply,
                        },
                        "newMissingPlies": {},
                        "noLongerMissingPlies": {},
                        "forcedPlies": {},
                        "removedPlies": {}
                    }),
                    laser_out(payload=mock_data.LaserFeedbacks.CorrectlyPlacedPlies.FirstPalletU.second_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.FirstPalletU.third_ply),
                    camera_out(
                        camera_ids={"cam1"},
                        command="start_capture",
                        refresh_interval=cfg.PASSIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                    camera_out(
                        camera_ids={"cam2"},
                        command="start_capture",
                        refresh_interval=cfg.ACTIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                ]
            ),
            # on EV msg second ply becomes missing on both edges but both are not by a coverable so is not filtered
            TestScenarioEntry(
                input_data=ev_message_in(
                    camera_id="cam1",
                    detected_edges={"U1.1"},
                    missing_edges={"U2.1", "U2.2"}
                ),
                etcd_outputs=[
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.second_ply_missing),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.third_ply_expected),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam1": {"missingEdges": ["U2.1", "U2.2"]},
                        "cam2": {"missingEdges": ["U2.2", "U3.1", "U3.2"]}},
                        session_cam_id="cam1",
                        layers=["layer_U"],
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_U": {"pallets": {"pallet_1": {"missingPlies": 1,
                                                                                       "placedPlies": 2,
                                                                                       "totalPlies": 4}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_U_1,
                        ],
                            session=ev_message_session("cam1")
                        ),
                        "correctlyPlacedPlies": {},
                        "pliesToBePlaced": {
                            **mock_data.StaticGraph.FirstPalletU.third_ply_does_not_cover_second_ply,
                        },
                        "newMissingPlies": {
                            **mock_data.StaticGraph.FirstPalletU.second_ply,
                        },
                        "noLongerMissingPlies": {},
                        "forcedPlies": {},
                        "removedPlies": {}
                    }),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.FirstPalletU.third_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.MissingPlies.FirstPalletU.second_ply),
                    camera_out(
                        camera_ids={"cam1", "cam2"},
                        command="start_capture",
                        refresh_interval=cfg.ACTIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                ]
            ),
            # on EV msg second ply again is detected
            TestScenarioEntry(
                input_data=ev_message_in(
                    camera_id="cam1",
                    detected_edges={"U1.1", "U2.1", "U2.2"},
                    missing_edges=set()
                ),
                etcd_outputs=[
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.second_ply_placed_after_missing),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.third_ply_expected),
                ],
            ),
            # 5 EV - the flow continues...
            TestScenarioEntry(
                input_data=ev_message_in(
                    camera_id="cam2",
                    detected_edges={"U3.1", "U3.2"},
                    missing_edges={"U2.2"}
                ),
                etcd_outputs=[
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.third_ply_placed_updated_by_cam_2),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.fourth_ply_expected),
                ],
            ),
        ]
        return {
            "entries": entries,
            "graph_data": {
                "mould_id": "mould_id",
                "blade_revision": "blade_revision",
                "version": "v1.0.0",
                "plies": {
                    **mock_data.StaticGraph.FirstPalletU.first_ply,
                    **mock_data.StaticGraph.FirstPalletU.second_ply,
                    **mock_data.StaticGraph.FirstPalletU.third_ply_does_not_cover_second_ply,
                    **mock_data.StaticGraph.FirstPalletU.fourth_ply,
                }
            },
        }

    @staticmethod
    def should_not_filter_rechecked_ply_when_1_of_2_edge_is_missing():
        entries = [
            # 1 on TI C2DM request first ply for pallet_U_1 is expected
            TestScenarioEntry(
                input_data=add_team_instruction_c2dm_request(instruction=mock_data.TeamInstructions.pallet_U_1),
            ),
            # 2 on EV msg first ply is detected, second ply is expected
            TestScenarioEntry(
                input_data=ev_message_in(
                    camera_id="cam1",
                    detected_edges={"U1.1", "U1.2"},
                    missing_edges=set()
                ),
            ),
            # 3 on EV msg second ply is detected, third ply is expected
            TestScenarioEntry(
                input_data=ev_message_in(
                    camera_id="cam1",
                    detected_edges={"U2.1", "U2.2"},
                    missing_edges={"U1.2"}
                ),
                etcd_outputs=[
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.first_ply_partially_covered),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.second_ply_placed),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.third_ply_expected),
                ],
            ),
            # 4 recheck_ply command
            TestScenarioEntry(
                input_data=recheck_ply_c2dm_request("U1"),
                etcd_outputs=[
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.first_ply_recheck_on_partially_covered),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.third_ply_expected),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam1": {"detectedEdges": ["U2.1", "U2.2"], "missingEdges": ["U1.1"]},
                        "cam2": {"detectedEdges": ["U2.2"], "missingEdges": ["U3.1", "U3.2"]}},
                        layers=["layer_U"],
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_U": {"pallets": {"pallet_1": {"missingPlies": 1,
                                                                                       "placedPlies": 2,
                                                                                       "totalPlies": 4}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_U_1,
                        ]),
                        "correctlyPlacedPlies": {},
                        "pliesToBePlaced": {
                            **mock_data.StaticGraph.FirstPalletU.third_ply,
                        },
                        "newMissingPlies": {
                            **mock_data.StaticGraph.FirstPalletU.first_ply, },
                        "noLongerMissingPlies": {},
                        "forcedPlies": {},
                        "removedPlies": {}
                    }),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.FirstPalletU.third_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.MissingPlies.FirstPalletU.first_ply),
                    camera_out(
                        camera_ids={"cam1", "cam2"},
                        command="start_capture",
                        refresh_interval=cfg.ACTIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                ]
            ),
            # 5 EV on EV msg rechecked ply is detected and becomes placed
            TestScenarioEntry(
                input_data=ev_message_in(
                    camera_id="cam1",
                    detected_edges={"U1.1"},
                    missing_edges=set(),
                ),
                etcd_outputs=[
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.first_ply_partially_covered_after_recheck),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.third_ply_expected),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam1": {"detectedEdges": ["U2.1", "U2.2"]},
                        "cam2": {"detectedEdges": ["U2.2"], "missingEdges": ["U3.1", "U3.2"]}},
                        session_cam_id="cam1",
                        layers=["layer_U"],
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_U": {"pallets": {"pallet_1": {"missingPlies": 0,
                                                                                       "placedPlies": 2,
                                                                                       "totalPlies": 4}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_U_1,
                        ],
                            session=ev_message_session("cam1")
                        ),
                        "correctlyPlacedPlies": {},
                        "pliesToBePlaced": {
                            **mock_data.StaticGraph.FirstPalletU.third_ply,
                        },
                        "newMissingPlies": {},
                        "noLongerMissingPlies": {
                            **mock_data.StaticGraph.FirstPalletU.first_ply,
                        },
                        "forcedPlies": {},
                        "removedPlies": {}
                    }),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.FirstPalletU.third_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToNull.FirstPalletU.first_ply),
                    camera_out(
                        camera_ids={"cam1"},
                        command="start_capture",
                        refresh_interval=cfg.PASSIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                    camera_out(
                        camera_ids={"cam2"},
                        command="start_capture",
                        refresh_interval=cfg.ACTIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                ]
            ),
            # 6 EV - the flow continues...
            TestScenarioEntry(
                input_data=ev_message_in(
                    camera_id="cam2",
                    detected_edges={"U3.1", "U3.2"},
                    missing_edges={"U2.2"}
                ),
                etcd_outputs=[
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.second_ply_partially_covered),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.third_ply_placed_updated_by_cam_2),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.fourth_ply_expected),
                ],
            ),
        ]
        return {
            "entries": entries,
            "graph_data": {
                "mould_id": "mould_id",
                "blade_revision": "blade_revision",
                "version": "v1.0.0",
                "plies": {
                    **mock_data.StaticGraph.FirstPalletU.first_ply,
                    **mock_data.StaticGraph.FirstPalletU.second_ply,
                    **mock_data.StaticGraph.FirstPalletU.third_ply,
                    **mock_data.StaticGraph.FirstPalletU.fourth_ply,
                }
            },
        }
