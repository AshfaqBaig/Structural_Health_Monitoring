# pylint: disable=protected-access, missing-module-docstring, missing-class-docstring, missing-function-docstring, duplicate-code, line-too-long, too-few-public-methods, no-self-use, too-many-locals, too-many-lines
import app.config as cfg
import tests.scenarios.mock_data as mock_data
from app.global_mould_state_enum import GlobalMouldState
from tests.scenarios.model.test_scenario_entry import TestScenarioEntry
from tests.scenarios.scenarios_base import ev_message_in, edge_verification_out, \
    camera_out, laser_out, trace_out, etcd_ply_out, ev_message_session, mould_state_plies_data, etcd_instruction_out, \
    mould_state_instructions_data, instructions_loaded_on_boot, add_team_instruction_c2dm_request, trace_out_metadata, \
    etcd_mould_state_out, etcd_mould_blade_sn_out, stats_out


class TeamInstructionsLoadedOnBootTestScenariosDtos:
    @staticmethod
    def previously_expected_ply_and_new_instruction_update_received_after_ply_is_placed_when_pallet_instructions_preloaded_on_boot():
        entries = [
            # 1 On DM boot team instructions are preloaded from ETCD store, no input data
            TestScenarioEntry(
                input_data=instructions_loaded_on_boot(),
                etcd_outputs=[
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.first_ply_expected_without_invisible_edge),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam1": {"missingEdges": ["P1.2"]}},
                    ),
                    camera_out(
                        camera_ids={"cam1"},
                        command="start_capture",
                        refresh_interval=cfg.ACTIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_P": {"pallets": {"pallet_1": {"missingPlies": 0,
                                                                                       "placedPlies": 0,
                                                                                       "totalPlies": 3}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_P_1
                        ]),
                        "correctlyPlacedPlies": {},
                        "pliesToBePlaced": {
                            **mock_data.StaticGraph.FirstPalletP.first_ply_invisible_edge_removed,
                        },
                        "newMissingPlies": {},
                        "noLongerMissingPlies": {},
                        "forcedPlies": {},
                        "removedPlies": {}
                    }),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.FirstPalletP.first_ply),
                ]
            ),
            # 2 If TI preloaded on boot successfully then on EV msg first ply is detected, second ply is expected
            TestScenarioEntry(
                input_data=ev_message_in(
                    camera_id="cam1",
                    detected_edges={"P1.2"},
                    missing_edges=set()
                ),
                etcd_outputs=[
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.first_ply_placed_without_invisible_edge),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.second_ply_expected),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam1": {"detectedEdges": ["P1.2"], "missingEdges": ["P2.1"]},
                        "cam2": {"missingEdges": ["P2.1", "P2.2"]}},
                        session_cam_id="cam1"
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_P": {"pallets": {"pallet_1": {"missingPlies": 0,
                                                                                       "placedPlies": 1,
                                                                                       "totalPlies": 3}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_P_1
                        ],
                            session=ev_message_session("cam1")
                        ),
                        "correctlyPlacedPlies": {
                            **mock_data.StaticGraph.FirstPalletP.first_ply_invisible_edge_removed,
                        },
                        "pliesToBePlaced": {
                            **mock_data.StaticGraph.FirstPalletP.second_ply,
                        },
                        "newMissingPlies": {},
                        "noLongerMissingPlies": {},
                        "forcedPlies": {},
                        "removedPlies": {}
                    }),
                    laser_out(payload=mock_data.LaserFeedbacks.CorrectlyPlacedPlies.FirstPalletP.first_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.FirstPalletP.second_ply),
                    camera_out(
                        camera_ids={"cam1", "cam2"},
                        command="start_capture",
                        refresh_interval=cfg.ACTIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                ]
            ),
            # 3 TI update received
            TestScenarioEntry(
                input_data=add_team_instruction_c2dm_request(mock_data.TeamInstructions.pallet_P_2),
                etcd_outputs=[
                    etcd_instruction_out(instruction=mock_data.TeamInstructions.pallet_P_2),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.second_ply_expected),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.fourth_ply_expected),
                    etcd_mould_state_out(state=GlobalMouldState.PRODUCTION),
                    etcd_mould_blade_sn_out(blade_sn="blade_sn"),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam1": {"detectedEdges": ["P1.2"], "missingEdges": ["P2.1"]},
                        "cam2": {"missingEdges": ["P2.1", "P2.2"]},
                        "cam3": {"missingEdges": ["P4.1", "P4.2"]},
                        "cam4": {"missingEdges": ["P4.2"]}},
                    ),
                    camera_out(
                        camera_ids={"cam1", "cam2", "cam3", "cam4"},
                        command="start_capture",
                        refresh_interval=cfg.ACTIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_P": {"pallets": {"pallet_1": {"missingPlies": 0,
                                                                                       "placedPlies": 1,
                                                                                       "totalPlies": 3},
                                                                          "pallet_2": {"missingPlies": 0,
                                                                                       "placedPlies": 0,
                                                                                       "totalPlies": 3}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_P_1,
                            mock_data.TeamInstructions.pallet_P_2
                        ]),
                        "correctlyPlacedPlies": {},
                        "pliesToBePlaced": {
                            **mock_data.StaticGraph.FirstPalletP.second_ply,
                            **mock_data.StaticGraph.SecondPalletP.fourth_ply,
                        },
                        "newMissingPlies": {},
                        "noLongerMissingPlies": {},
                        "forcedPlies": {},
                        "removedPlies": {}
                    }),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.FirstPalletP.second_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.SecondPalletP.fourth_ply),
                ]
            ),
            # 4 on EV previously expected ply for initial pallet is placed
            TestScenarioEntry(
                input_data=ev_message_in(
                    camera_id="cam2",
                    detected_edges={"P2.1", "P2.2"},
                    missing_edges=set()
                ),
                etcd_outputs=[
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.first_ply_covered_without_invisible_edge),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.second_ply_placed),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.third_ply_expected),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.fourth_ply_expected),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam1": {"detectedEdges": ["P2.1"]},
                        "cam2": {"detectedEdges": ["P2.1", "P2.2"], "missingEdges": ["P3.1"]},
                        "cam3": {"missingEdges": ["P3.2", "P4.1", "P4.2"]},
                        "cam4": {"missingEdges": ["P4.2"]}},
                        session_cam_id="cam2"
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_P": {"pallets": {"pallet_1": {"missingPlies": 0,
                                                                                       "placedPlies": 2,
                                                                                       "totalPlies": 3},
                                                                          "pallet_2": {"missingPlies": 0,
                                                                                       "placedPlies": 0,
                                                                                       "totalPlies": 3}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_P_1,
                            mock_data.TeamInstructions.pallet_P_2
                        ],
                            session=ev_message_session("cam2")
                        ),
                        "correctlyPlacedPlies": {
                            **mock_data.StaticGraph.FirstPalletP.second_ply,
                        },
                        "pliesToBePlaced": {
                            **mock_data.StaticGraph.FirstPalletP.third_ply,
                            **mock_data.StaticGraph.SecondPalletP.fourth_ply,
                        },
                        "newMissingPlies": {},
                        "noLongerMissingPlies": {},
                        "forcedPlies": {},
                        "removedPlies": {}
                    }),
                    laser_out(payload=mock_data.LaserFeedbacks.CorrectlyPlacedPlies.FirstPalletP.second_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.FirstPalletP.third_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.SecondPalletP.fourth_ply),
                    camera_out(
                        camera_ids={"cam1"},
                        command="start_capture",
                        refresh_interval=cfg.PASSIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                    camera_out(
                        camera_ids={"cam2", "cam3", "cam4"},
                        command="start_capture",
                        refresh_interval=cfg.ACTIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                ]
            ),
        ]
        return {
            "entries": entries,
            "initial_mould_state_instructions_data": mould_state_instructions_data([
                mock_data.TeamInstructions.pallet_P_1,
            ]),
            "initial_mould_state": GlobalMouldState.PRODUCTION,
            "initial_mould_blade_sn": "blade_sn",
        }

    @staticmethod
    def new_expected_ply_and_instruction_update_received_after_ply_is_placed_when_pallet_instructions_preloaded_on_boot():
        entries = [
            # 1 On DM boot team instructions are preloaded from ETCD store, no input data
            TestScenarioEntry(
                input_data=instructions_loaded_on_boot(),
                etcd_outputs=[
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.first_ply_expected_without_invisible_edge),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam1": {"missingEdges": ["P1.2"]}},
                    ),
                    camera_out(
                        camera_ids={"cam1"},
                        command="start_capture",
                        refresh_interval=cfg.ACTIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_P": {"pallets": {"pallet_1": {"missingPlies": 0,
                                                                                       "placedPlies": 0,
                                                                                       "totalPlies": 3}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_P_1
                        ]),
                        "correctlyPlacedPlies": {},
                        "pliesToBePlaced": {
                            **mock_data.StaticGraph.FirstPalletP.first_ply_invisible_edge_removed,
                        },
                        "newMissingPlies": {},
                        "noLongerMissingPlies": {},
                        "forcedPlies": {},
                        "removedPlies": {}
                    }),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.FirstPalletP.first_ply),
                ]
            ),
            # 2 If TI preloaded on boot successfully then on EV msg first ply is detected, second ply is expected
            TestScenarioEntry(
                input_data=ev_message_in(
                    camera_id="cam1",
                    detected_edges={"P1.2"},
                    missing_edges=set()
                ),
                etcd_outputs=[
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.first_ply_placed_without_invisible_edge),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.second_ply_expected),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam1": {"detectedEdges": ["P1.2"], "missingEdges": ["P2.1"]},
                        "cam2": {"missingEdges": ["P2.1", "P2.2"]}},
                        session_cam_id="cam1"
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_P": {"pallets": {"pallet_1": {"missingPlies": 0,
                                                                                       "placedPlies": 1,
                                                                                       "totalPlies": 3}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_P_1
                        ],
                            session=ev_message_session("cam1")
                        ),
                        "correctlyPlacedPlies": {
                            **mock_data.StaticGraph.FirstPalletP.first_ply_invisible_edge_removed,
                        },
                        "pliesToBePlaced": {
                            **mock_data.StaticGraph.FirstPalletP.second_ply,
                        },
                        "newMissingPlies": {},
                        "noLongerMissingPlies": {},
                        "forcedPlies": {},
                        "removedPlies": {}
                    }),
                    laser_out(payload=mock_data.LaserFeedbacks.CorrectlyPlacedPlies.FirstPalletP.first_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.FirstPalletP.second_ply),
                    camera_out(
                        camera_ids={"cam2", "cam1"},
                        command="start_capture",
                        refresh_interval=cfg.ACTIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                ]
            ),
            # 3 TI update received
            TestScenarioEntry(
                input_data=add_team_instruction_c2dm_request(mock_data.TeamInstructions.pallet_P_2),
                etcd_outputs=[
                    etcd_instruction_out(instruction=mock_data.TeamInstructions.pallet_P_2),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.second_ply_expected),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.fourth_ply_expected),
                    etcd_mould_state_out(state=GlobalMouldState.PRODUCTION),
                    etcd_mould_blade_sn_out(blade_sn="blade_sn"),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam1": {"detectedEdges": ["P1.2"], "missingEdges": ["P2.1"]},
                        "cam2": {"missingEdges": ["P2.1", "P2.2"]},
                        "cam3": {"missingEdges": ["P4.1", "P4.2"]},
                        "cam4": {"missingEdges": ["P4.2"]}},
                    ),
                    camera_out(
                        camera_ids={"cam1", "cam2", "cam3", "cam4"},
                        command="start_capture",
                        refresh_interval=cfg.ACTIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_P": {"pallets": {"pallet_1": {"missingPlies": 0,
                                                                                       "placedPlies": 1,
                                                                                       "totalPlies": 3},
                                                                          "pallet_2": {"missingPlies": 0,
                                                                                       "placedPlies": 0,
                                                                                       "totalPlies": 3}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_P_1,
                            mock_data.TeamInstructions.pallet_P_2
                        ]),
                        "correctlyPlacedPlies": {},
                        "pliesToBePlaced": {
                            **mock_data.StaticGraph.FirstPalletP.second_ply,
                            **mock_data.StaticGraph.SecondPalletP.fourth_ply,
                        },
                        "newMissingPlies": {},
                        "noLongerMissingPlies": {},
                        "forcedPlies": {},
                        "removedPlies": {}
                    }),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.FirstPalletP.second_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.SecondPalletP.fourth_ply),
                ]
            ),
            # 4 on EV new expected ply for new pallet is placed
            TestScenarioEntry(
                input_data=ev_message_in(
                    camera_id="cam3",
                    detected_edges={"P4.1", "P4.2"},
                    missing_edges=set()
                ),
                etcd_outputs=[
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.second_ply_expected),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.fourth_ply_placed),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.fifth_ply_expected),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam1": {"detectedEdges": ["P1.2"], "missingEdges": ["P2.1"]},
                        "cam2": {"missingEdges": ["P2.1", "P2.2"]},
                        "cam3": {"detectedEdges": ["P4.1", "P4.2"]},
                        "cam4": {"detectedEdges": ["P4.2"],
                                 "missingEdges": ["P5.1", "P5.2"]}},
                        session_cam_id="cam3"
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_P": {"pallets": {"pallet_1": {"missingPlies": 0,
                                                                                       "placedPlies": 1,
                                                                                       "totalPlies": 3},
                                                                          "pallet_2": {"missingPlies": 0,
                                                                                       "placedPlies": 1,
                                                                                       "totalPlies": 3}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_P_1,
                            mock_data.TeamInstructions.pallet_P_2
                        ],
                            session=ev_message_session("cam3")
                        ),
                        "correctlyPlacedPlies": {
                            **mock_data.StaticGraph.SecondPalletP.fourth_ply,
                        },
                        "pliesToBePlaced": {
                            **mock_data.StaticGraph.FirstPalletP.second_ply,
                            **mock_data.StaticGraph.SecondPalletP.fifth_ply,
                        },
                        "newMissingPlies": {},
                        "noLongerMissingPlies": {},
                        "forcedPlies": {},
                        "removedPlies": {}
                    }),
                    laser_out(payload=mock_data.LaserFeedbacks.CorrectlyPlacedPlies.SecondPalletP.fourth_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.FirstPalletP.second_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.SecondPalletP.fifth_ply),
                    camera_out(
                        camera_ids={"cam3"},
                        command="start_capture",
                        refresh_interval=cfg.PASSIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                    camera_out(
                        camera_ids={"cam2", "cam1", "cam4"},
                        command="start_capture",
                        refresh_interval=cfg.ACTIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                ]
            ),
        ]
        return {
            "entries": entries,
            "initial_mould_state_instructions_data": mould_state_instructions_data([
                mock_data.TeamInstructions.pallet_P_1,
            ]),
            "initial_mould_state": GlobalMouldState.PRODUCTION,
            "initial_mould_blade_sn": "blade_sn",
        }

    @staticmethod
    def previously_expected_ply_and_new_instruction_update_received_when_pallet_instructions_preloaded_on_boot():
        entries = [
            # 1 On DM boot team instructions are preloaded from ETCD store, no input data
            TestScenarioEntry(
                input_data=instructions_loaded_on_boot(),
                etcd_outputs=[
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.first_ply_expected_without_invisible_edge),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam1": {"missingEdges": ["P1.2"]}},
                    ),
                    camera_out(
                        camera_ids={"cam1"},
                        command="start_capture",
                        refresh_interval=cfg.ACTIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_P": {"pallets": {"pallet_1": {"missingPlies": 0,
                                                                                       "placedPlies": 0,
                                                                                       "totalPlies": 3}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_P_1
                        ]),
                        "correctlyPlacedPlies": {},
                        "pliesToBePlaced": {
                            **mock_data.StaticGraph.FirstPalletP.first_ply_invisible_edge_removed,
                        },
                        "newMissingPlies": {},
                        "noLongerMissingPlies": {},
                        "forcedPlies": {},
                        "removedPlies": {}
                    }),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.FirstPalletP.first_ply),
                ]
            ),
            # 2 TI update received
            TestScenarioEntry(
                input_data=add_team_instruction_c2dm_request(mock_data.TeamInstructions.pallet_P_2),
                etcd_outputs=[
                    etcd_instruction_out(instruction=mock_data.TeamInstructions.pallet_P_2),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.first_ply_expected_without_invisible_edge),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.fourth_ply_expected),
                    etcd_mould_state_out(state=GlobalMouldState.PRODUCTION),
                    etcd_mould_blade_sn_out(blade_sn="blade_sn"),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam1": {"missingEdges": ["P1.2"]},
                        "cam3": {"missingEdges": ["P4.1", "P4.2"]},
                        "cam4": {"missingEdges": ["P4.2"]}},
                    ),
                    camera_out(
                        camera_ids={"cam1", "cam3", "cam4"},
                        command="start_capture",
                        refresh_interval=cfg.ACTIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_P": {"pallets": {"pallet_1": {"missingPlies": 0,
                                                                                       "placedPlies": 0,
                                                                                       "totalPlies": 3},
                                                                          "pallet_2": {"missingPlies": 0,
                                                                                       "placedPlies": 0,
                                                                                       "totalPlies": 3}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_P_1,
                            mock_data.TeamInstructions.pallet_P_2
                        ]),
                        "correctlyPlacedPlies": {},
                        "pliesToBePlaced": {
                            **mock_data.StaticGraph.FirstPalletP.first_ply_invisible_edge_removed,
                            **mock_data.StaticGraph.SecondPalletP.fourth_ply,
                        },
                        "newMissingPlies": {},
                        "noLongerMissingPlies": {},
                        "forcedPlies": {},
                        "removedPlies": {}
                    }),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.FirstPalletP.first_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.SecondPalletP.fourth_ply),
                ]
            ),
            # 3 If TI preloaded on boot successfully then on EV msg first ply is detected, second ply is expected
            TestScenarioEntry(
                input_data=ev_message_in(
                    camera_id="cam1",
                    detected_edges={"P1.2"},
                    missing_edges=set()
                ),
                etcd_outputs=[
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.first_ply_placed_without_invisible_edge),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.second_ply_expected),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.fourth_ply_expected),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam1": {"detectedEdges": ["P1.2"], "missingEdges": ["P2.1"]},
                        "cam2": {"missingEdges": ["P2.1", "P2.2"]},
                        "cam3": {"missingEdges": ["P4.1", "P4.2"]},
                        "cam4": {"missingEdges": ["P4.2"]}},
                        session_cam_id="cam1"
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_P": {"pallets": {"pallet_1": {"missingPlies": 0,
                                                                                       "placedPlies": 1,
                                                                                       "totalPlies": 3},
                                                                          "pallet_2": {"missingPlies": 0,
                                                                                       "placedPlies": 0,
                                                                                       "totalPlies": 3}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_P_1,
                            mock_data.TeamInstructions.pallet_P_2
                        ],
                            session=ev_message_session("cam1")
                        ),
                        "correctlyPlacedPlies": {
                            **mock_data.StaticGraph.FirstPalletP.first_ply_invisible_edge_removed,
                        },
                        "pliesToBePlaced": {
                            **mock_data.StaticGraph.FirstPalletP.second_ply,
                            **mock_data.StaticGraph.SecondPalletP.fourth_ply,
                        },
                        "newMissingPlies": {},
                        "noLongerMissingPlies": {},
                        "forcedPlies": {},
                        "removedPlies": {}
                    }),
                    laser_out(payload=mock_data.LaserFeedbacks.CorrectlyPlacedPlies.FirstPalletP.first_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.FirstPalletP.second_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.SecondPalletP.fourth_ply),
                    camera_out(
                        camera_ids={"cam1", "cam2", "cam3", "cam4"},
                        command="start_capture",
                        refresh_interval=cfg.ACTIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                ]
            ),
            # 4 If TIs updated successfully after boot then on EV msg fourth ply is detected and fifth ply is expected
            TestScenarioEntry(
                input_data=ev_message_in(
                    camera_id="cam3",
                    detected_edges={"P4.1", "P4.2"},
                    missing_edges=set()
                ),
                etcd_outputs=[
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.second_ply_expected),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.fourth_ply_placed),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.fifth_ply_expected),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam1": {"detectedEdges": ["P1.2"], "missingEdges": ["P2.1"]},
                        "cam2": {"missingEdges": ["P2.1", "P2.2"]},
                        "cam3": {"detectedEdges": ["P4.1", "P4.2"]},
                        "cam4": {"detectedEdges": ["P4.2"],
                                 "missingEdges": ["P5.1", "P5.2"]}},
                        session_cam_id="cam3"
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_P": {"pallets": {"pallet_1": {"missingPlies": 0,
                                                                                       "placedPlies": 1,
                                                                                       "totalPlies": 3},
                                                                          "pallet_2": {"missingPlies": 0,
                                                                                       "placedPlies": 1,
                                                                                       "totalPlies": 3}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_P_1,
                            mock_data.TeamInstructions.pallet_P_2
                        ],
                            session=ev_message_session("cam3")
                        ),
                        "correctlyPlacedPlies": {
                            **mock_data.StaticGraph.SecondPalletP.fourth_ply,
                        },
                        "pliesToBePlaced": {
                            **mock_data.StaticGraph.FirstPalletP.second_ply,
                            **mock_data.StaticGraph.SecondPalletP.fifth_ply,
                        },
                        "newMissingPlies": {},
                        "noLongerMissingPlies": {},
                        "forcedPlies": {},
                        "removedPlies": {}
                    }),
                    laser_out(payload=mock_data.LaserFeedbacks.CorrectlyPlacedPlies.SecondPalletP.fourth_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.FirstPalletP.second_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.SecondPalletP.fifth_ply),
                    camera_out(
                        camera_ids={"cam3"},
                        command="start_capture",
                        refresh_interval=cfg.PASSIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                    camera_out(
                        camera_ids={"cam2", "cam1", "cam4"},
                        command="start_capture",
                        refresh_interval=cfg.ACTIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                ]
            ),
        ]
        return {
            "entries": entries,
            "initial_mould_state_instructions_data": mould_state_instructions_data([
                mock_data.TeamInstructions.pallet_P_1,
            ]),
            "initial_mould_state": GlobalMouldState.PRODUCTION,
            "initial_mould_blade_sn": "blade_sn",
        }

    @staticmethod
    def new_expected_ply_and_new_instruction_update_received_when_pallet_instructions_preloaded_on_boot():
        entries = [
            # 1 On DM boot team instructions are preloaded from ETCD store, no input data
            TestScenarioEntry(
                input_data=instructions_loaded_on_boot(),
                etcd_outputs=[
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.first_ply_expected_without_invisible_edge),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam1": {"missingEdges": ["P1.2"]}},
                    ),
                    camera_out(
                        camera_ids={"cam1"},
                        command="start_capture",
                        refresh_interval=cfg.ACTIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_P": {"pallets": {"pallet_1": {"missingPlies": 0,
                                                                                       "placedPlies": 0,
                                                                                       "totalPlies": 3}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_P_1
                        ]),
                        "correctlyPlacedPlies": {},
                        "pliesToBePlaced": {
                            **mock_data.StaticGraph.FirstPalletP.first_ply_invisible_edge_removed,
                        },
                        "newMissingPlies": {},
                        "noLongerMissingPlies": {},
                        "forcedPlies": {},
                        "removedPlies": {}
                    }),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.FirstPalletP.first_ply),
                ]
            ),
            # 2 TI update received
            TestScenarioEntry(
                input_data=add_team_instruction_c2dm_request(mock_data.TeamInstructions.pallet_P_2),
                etcd_outputs=[
                    etcd_instruction_out(instruction=mock_data.TeamInstructions.pallet_P_2),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.first_ply_expected_without_invisible_edge),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.fourth_ply_expected),
                    etcd_mould_state_out(state=GlobalMouldState.PRODUCTION),
                    etcd_mould_blade_sn_out(blade_sn="blade_sn"),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam1": {"missingEdges": ["P1.2"]},
                        "cam3": {"missingEdges": ["P4.1", "P4.2"]},
                        "cam4": {"missingEdges": ["P4.2"]}},
                    ),
                    camera_out(
                        camera_ids={"cam1", "cam3", "cam4"},
                        command="start_capture",
                        refresh_interval=cfg.ACTIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_P": {"pallets": {"pallet_1": {"missingPlies": 0,
                                                                                       "placedPlies": 0,
                                                                                       "totalPlies": 3},
                                                                          "pallet_2": {"missingPlies": 0,
                                                                                       "placedPlies": 0,
                                                                                       "totalPlies": 3}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_P_1,
                            mock_data.TeamInstructions.pallet_P_2
                        ]),
                        "correctlyPlacedPlies": {},
                        "pliesToBePlaced": {
                            **mock_data.StaticGraph.FirstPalletP.first_ply_invisible_edge_removed,
                            **mock_data.StaticGraph.SecondPalletP.fourth_ply,
                        },
                        "newMissingPlies": {},
                        "noLongerMissingPlies": {},
                        "forcedPlies": {},
                        "removedPlies": {}
                    }),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.FirstPalletP.first_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.SecondPalletP.fourth_ply),
                ]
            ),
            # 3 If TIs updated successfully after boot then on EV msg fourth ply is detected and fifth ply is expected
            TestScenarioEntry(
                input_data=ev_message_in(
                    camera_id="cam3",
                    detected_edges={"P4.1", "P4.2"},
                    missing_edges=set()
                ),
                etcd_outputs=[
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.first_ply_expected_without_invisible_edge),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.fourth_ply_placed),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.fifth_ply_expected),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam1": {"missingEdges": ["P1.2"]},
                        "cam3": {"detectedEdges": ["P4.1", "P4.2"]},
                        "cam4": {"detectedEdges": ["P4.2"],
                                 "missingEdges": ["P5.1", "P5.2"]}},
                        session_cam_id="cam3"
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_P": {"pallets": {"pallet_1": {"missingPlies": 0,
                                                                                       "placedPlies": 0,
                                                                                       "totalPlies": 3},
                                                                          "pallet_2": {"missingPlies": 0,
                                                                                       "placedPlies": 1,
                                                                                       "totalPlies": 3}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_P_1,
                            mock_data.TeamInstructions.pallet_P_2
                        ],
                            session=ev_message_session("cam3")
                        ),
                        "correctlyPlacedPlies": {
                            **mock_data.StaticGraph.SecondPalletP.fourth_ply,
                        },
                        "pliesToBePlaced": {
                            **mock_data.StaticGraph.FirstPalletP.first_ply_invisible_edge_removed,
                            **mock_data.StaticGraph.SecondPalletP.fifth_ply,
                        },
                        "newMissingPlies": {},
                        "noLongerMissingPlies": {},
                        "forcedPlies": {},
                        "removedPlies": {}
                    }),
                    laser_out(payload=mock_data.LaserFeedbacks.CorrectlyPlacedPlies.SecondPalletP.fourth_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.FirstPalletP.first_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.SecondPalletP.fifth_ply),
                    camera_out(
                        camera_ids={"cam3"},
                        command="start_capture",
                        refresh_interval=cfg.PASSIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                    camera_out(
                        camera_ids={"cam1", "cam4"},
                        command="start_capture",
                        refresh_interval=cfg.ACTIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                ]
            ),
            # 4 If TI preloaded on boot successfully then on EV msg first ply is detected, second ply is expected
            TestScenarioEntry(
                input_data=ev_message_in(
                    camera_id="cam1",
                    detected_edges={"P1.2"},
                    missing_edges=set()
                ),
                etcd_outputs=[
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.first_ply_placed_without_invisible_edge),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.second_ply_expected),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.fifth_ply_expected),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam1": {"detectedEdges": ["P1.2"], "missingEdges": ["P2.1"]},
                        "cam2": {"missingEdges": ["P2.1", "P2.2"]},
                        "cam3": {"detectedEdges": ["P4.1", "P4.2"]},
                        "cam4": {"detectedEdges": ["P4.2"],
                                 "missingEdges": ["P5.1", "P5.2"]}},
                        session_cam_id="cam1"
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_P": {"pallets": {"pallet_1": {"missingPlies": 0,
                                                                                       "placedPlies": 1,
                                                                                       "totalPlies": 3},
                                                                          "pallet_2": {"missingPlies": 0,
                                                                                       "placedPlies": 1,
                                                                                       "totalPlies": 3}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_P_1,
                            mock_data.TeamInstructions.pallet_P_2
                        ],
                            session=ev_message_session("cam1")
                        ),
                        "correctlyPlacedPlies": {
                            **mock_data.StaticGraph.FirstPalletP.first_ply_invisible_edge_removed,
                        },
                        "pliesToBePlaced": {
                            **mock_data.StaticGraph.FirstPalletP.second_ply,
                            **mock_data.StaticGraph.SecondPalletP.fifth_ply,
                        },
                        "newMissingPlies": {},
                        "noLongerMissingPlies": {},
                        "forcedPlies": {},
                        "removedPlies": {}
                    }),
                    laser_out(payload=mock_data.LaserFeedbacks.CorrectlyPlacedPlies.FirstPalletP.first_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.FirstPalletP.second_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.SecondPalletP.fifth_ply),
                    camera_out(
                        camera_ids={"cam3"},
                        command="start_capture",
                        refresh_interval=cfg.PASSIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                    camera_out(
                        camera_ids={"cam2", "cam1", "cam4"},
                        command="start_capture",
                        refresh_interval=cfg.ACTIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                ]
            ),
        ]
        return {
            "entries": entries,
            "initial_mould_state_instructions_data": mould_state_instructions_data([
                mock_data.TeamInstructions.pallet_P_1,
            ]),
            "initial_mould_state": GlobalMouldState.PRODUCTION,
            "initial_mould_blade_sn": "blade_sn",
        }

    @staticmethod
    def initial_ply_is_not_yet_placed_when_on_boot_second_pallet_instruction_preloaded():
        entries = [
            # 1 On DM boot team instructions are preloaded from ETCD store, no input data
            TestScenarioEntry(
                input_data=instructions_loaded_on_boot(),
                etcd_outputs=[
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.fourth_ply_expected),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam3": {"missingEdges": ["P4.1", "P4.2"]},
                        "cam4": {"missingEdges": ["P4.2"]}},
                    ),
                    camera_out(
                        camera_ids={"cam3", "cam4"},
                        command="start_capture",
                        refresh_interval=cfg.ACTIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_P": {"pallets": {"pallet_2": {"missingPlies": 0,
                                                                                       "placedPlies": 0,
                                                                                       "totalPlies": 3}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_P_2,
                        ]),
                        "correctlyPlacedPlies": {},
                        "pliesToBePlaced": {
                            **mock_data.StaticGraph.SecondPalletP.fourth_ply,
                        },
                        "newMissingPlies": {},
                        "noLongerMissingPlies": {},
                        "forcedPlies": {},
                        "removedPlies": {}
                    }),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.SecondPalletP.fourth_ply),
                ]
            ),
            # 2 If TI preloaded on boot successfully then on EV msg fourth ply is expected
            TestScenarioEntry(
                input_data=ev_message_in(
                    camera_id="cam3",
                    detected_edges=set(),
                    missing_edges={"P4.1", "P4.2"}
                ),
                etcd_outputs=[],
                messaging_outputs=[]
            ),
            # 3 The flow continuous...
            TestScenarioEntry(
                input_data=ev_message_in(
                    camera_id="cam3",
                    detected_edges={"P4.1", "P4.2"},
                    missing_edges=set()
                ),
                etcd_outputs=[
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.fourth_ply_placed),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.fifth_ply_expected),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam3": {"detectedEdges": ["P4.1", "P4.2"]},
                        "cam4": {"detectedEdges": ["P4.2"],
                                 "missingEdges": ["P5.1", "P5.2"]}},
                        session_cam_id="cam3"
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_P": {"pallets": {"pallet_2": {"missingPlies": 0,
                                                                                       "placedPlies": 1,
                                                                                       "totalPlies": 3}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_P_2,
                        ],
                            session=ev_message_session("cam3")
                        ),
                        "correctlyPlacedPlies": {
                            **mock_data.StaticGraph.SecondPalletP.fourth_ply,
                        },
                        "pliesToBePlaced": {
                            **mock_data.StaticGraph.SecondPalletP.fifth_ply,
                        },
                        "newMissingPlies": {},
                        "noLongerMissingPlies": {},
                        "forcedPlies": {},
                        "removedPlies": {}
                    }),
                    laser_out(payload=mock_data.LaserFeedbacks.CorrectlyPlacedPlies.SecondPalletP.fourth_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.SecondPalletP.fifth_ply),
                    camera_out(
                        camera_ids={"cam3"},
                        command="start_capture",
                        refresh_interval=cfg.PASSIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                    camera_out(
                        camera_ids={"cam4"},
                        command="start_capture",
                        refresh_interval=cfg.ACTIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                ]
            ),
        ]
        return {
            "entries": entries,
            "initial_mould_state_instructions_data": mould_state_instructions_data([
                mock_data.TeamInstructions.pallet_P_2,
            ]),
            "initial_mould_state": GlobalMouldState.PRODUCTION,
            "initial_mould_blade_sn": "blade_sn",
        }

    @staticmethod
    def initial_ply_is_placed_when_on_boot_second_pallet_instruction_preloaded():
        entries = [
            # 1 On DM boot team instructions are preloaded from ETCD store, no input data
            TestScenarioEntry(
                input_data=instructions_loaded_on_boot(),
                etcd_outputs=[
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.fourth_ply_expected),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam3": {"missingEdges": ["P4.1", "P4.2"]},
                        "cam4": {"missingEdges": ["P4.2"]}},
                    ),
                    camera_out(
                        camera_ids={"cam3", "cam4"},
                        command="start_capture",
                        refresh_interval=cfg.ACTIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_P": {"pallets": {"pallet_2": {"missingPlies": 0,
                                                                                       "placedPlies": 0,
                                                                                       "totalPlies": 3}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_P_2,
                        ]),
                        "correctlyPlacedPlies": {},
                        "pliesToBePlaced": {
                            **mock_data.StaticGraph.SecondPalletP.fourth_ply,
                        },
                        "newMissingPlies": {},
                        "noLongerMissingPlies": {},
                        "forcedPlies": {},
                        "removedPlies": {}
                    }),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.SecondPalletP.fourth_ply),
                ]
            ),
            # 2 If TI preloaded on boot successfully then on EV msg fourth ply is detected, fifth ply is expected
            TestScenarioEntry(
                input_data=ev_message_in(
                    camera_id="cam3",
                    detected_edges={"P4.1", "P4.2"},
                    missing_edges=set()
                ),
                etcd_outputs=[
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.fourth_ply_placed),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.fifth_ply_expected),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam3": {"detectedEdges": ["P4.1", "P4.2"]},
                        "cam4": {"detectedEdges": ["P4.2"],
                                 "missingEdges": ["P5.1", "P5.2"]}},
                        session_cam_id="cam3"
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_P": {"pallets": {"pallet_2": {"missingPlies": 0,
                                                                                       "placedPlies": 1,
                                                                                       "totalPlies": 3}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_P_2,
                        ],
                            session=ev_message_session("cam3")
                        ),
                        "correctlyPlacedPlies": {
                            **mock_data.StaticGraph.SecondPalletP.fourth_ply,
                        },
                        "pliesToBePlaced": {
                            **mock_data.StaticGraph.SecondPalletP.fifth_ply,
                        },
                        "newMissingPlies": {},
                        "noLongerMissingPlies": {},
                        "forcedPlies": {},
                        "removedPlies": {}
                    }),
                    laser_out(payload=mock_data.LaserFeedbacks.CorrectlyPlacedPlies.SecondPalletP.fourth_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.SecondPalletP.fifth_ply),
                    camera_out(
                        camera_ids={"cam3"},
                        command="start_capture",
                        refresh_interval=cfg.PASSIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                    camera_out(
                        camera_ids={"cam4"},
                        command="start_capture",
                        refresh_interval=cfg.ACTIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                ]
            ),
            # 3 The flow continuous...
            TestScenarioEntry(
                input_data=ev_message_in(
                    camera_id="cam4",
                    detected_edges={"P5.1", "P5.2"},
                    missing_edges=set()
                ),
                etcd_outputs=[
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.fourth_ply_partially_covered),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.fifth_ply_placed),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.sixth_ply_expected),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam3": {"detectedEdges": ["P4.1"]},
                        "cam4": {"detectedEdges": ["P5.1", "P5.2"], "missingEdges": ["P6.1"]},
                        "cam5": {"missingEdges": ["P6.1", "P6.2"]}},
                        session_cam_id="cam4"
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_P": {"pallets": {"pallet_2": {"missingPlies": 0,
                                                                                       "placedPlies": 2,
                                                                                       "totalPlies": 3}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_P_2,
                        ],
                            session=ev_message_session("cam4")
                        ),
                        "correctlyPlacedPlies": {
                            **mock_data.StaticGraph.SecondPalletP.fifth_ply,
                        },
                        "pliesToBePlaced": {
                            **mock_data.StaticGraph.SecondPalletP.sixth_ply,
                        },
                        "newMissingPlies": {},
                        "noLongerMissingPlies": {},
                        "forcedPlies": {},
                        "removedPlies": {}
                    }),
                    laser_out(payload=mock_data.LaserFeedbacks.CorrectlyPlacedPlies.SecondPalletP.fifth_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.SecondPalletP.sixth_ply),
                    camera_out(
                        camera_ids={"cam3"},
                        command="start_capture",
                        refresh_interval=cfg.PASSIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                    camera_out(
                        camera_ids={"cam5", "cam4"},
                        command="start_capture",
                        refresh_interval=cfg.ACTIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                ]
            ),
        ]
        return {
            "entries": entries,
            "initial_mould_state_instructions_data": mould_state_instructions_data([
                mock_data.TeamInstructions.pallet_P_2,
            ]),
            "initial_mould_state": GlobalMouldState.PRODUCTION,
            "initial_mould_blade_sn": "blade_sn",
        }

    @staticmethod
    def non_initial_ply_is_not_yet_placed_when_on_boot_second_pallet_instruction_and_some_plies_preloaded():
        entries = [
            # 1 On DM boot team instructions are preloaded from ETCD store, no input data
            TestScenarioEntry(
                input_data=instructions_loaded_on_boot(),
                etcd_outputs=[
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.fourth_ply_expected),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam1": {"detectedEdges": ["P2.1"]},
                        "cam2": {"detectedEdges": ["P2.1", "P3.1"]},
                        "cam3": {"detectedEdges": ["P3.2"], "missingEdges": ["P4.1", "P4.2"]},
                        "cam4": {"missingEdges": ["P4.2"]}},
                    ),
                    camera_out(
                        camera_ids={"cam1", "cam2"},
                        command="start_capture",
                        refresh_interval=cfg.PASSIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                    camera_out(
                        camera_ids={"cam3", "cam4"},
                        command="start_capture",
                        refresh_interval=cfg.ACTIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_P": {"pallets": {"pallet_1": {"missingPlies": 0,
                                                                                       "placedPlies": 3,
                                                                                       "totalPlies": 3},
                                                                          "pallet_2": {"missingPlies": 0,
                                                                                       "placedPlies": 0,
                                                                                       "totalPlies": 3}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_P_1,
                            mock_data.TeamInstructions.pallet_P_2
                        ]),
                        "correctlyPlacedPlies": {},
                        "pliesToBePlaced": {
                            **mock_data.StaticGraph.SecondPalletP.fourth_ply,
                        },
                        "newMissingPlies": {},
                        "noLongerMissingPlies": {},
                        "forcedPlies": {},
                        "removedPlies": {}
                    }),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.SecondPalletP.fourth_ply),
                ]
            ),
            # 2 If TI preloaded on boot successfully then on EV msg fourth ply is expected
            TestScenarioEntry(
                input_data=ev_message_in(
                    camera_id="cam3",
                    detected_edges={"P3.2"},
                    missing_edges={"P4.1", "P4.2"}
                ),
                etcd_outputs=[],
                messaging_outputs=[]
            ),
            # 3 The flow continuous...
            TestScenarioEntry(
                input_data=ev_message_in(
                    camera_id="cam3",
                    detected_edges={"P4.1", "P4.2"},
                    missing_edges={"P3.2"}
                ),
                etcd_outputs=[
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.third_ply_partially_covered),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.fourth_ply_placed),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.fifth_ply_expected),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam1": {"detectedEdges": ["P2.1"]},
                        "cam2": {"detectedEdges": ["P2.1", "P3.1"]},
                        "cam3": {"detectedEdges": ["P4.1", "P4.2"]},
                        "cam4": {"detectedEdges": ["P4.2"],
                                 "missingEdges": ["P5.1", "P5.2"]}},
                        session_cam_id="cam3"
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_P": {"pallets": {"pallet_1": {"missingPlies": 0,
                                                                                       "placedPlies": 3,
                                                                                       "totalPlies": 3},
                                                                          "pallet_2": {"missingPlies": 0,
                                                                                       "placedPlies": 1,
                                                                                       "totalPlies": 3}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_P_1,
                            mock_data.TeamInstructions.pallet_P_2
                        ],
                            session=ev_message_session("cam3")
                        ),
                        "correctlyPlacedPlies": {
                            **mock_data.StaticGraph.SecondPalletP.fourth_ply,
                        },
                        "pliesToBePlaced": {
                            **mock_data.StaticGraph.SecondPalletP.fifth_ply,
                        },
                        "newMissingPlies": {},
                        "noLongerMissingPlies": {},
                        "forcedPlies": {},
                        "removedPlies": {}
                    }),
                    laser_out(payload=mock_data.LaserFeedbacks.CorrectlyPlacedPlies.SecondPalletP.fourth_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.SecondPalletP.fifth_ply),
                    camera_out(
                        camera_ids={"cam2", "cam1", "cam3"},
                        command="start_capture",
                        refresh_interval=cfg.PASSIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                    camera_out(
                        camera_ids={"cam4"},
                        command="start_capture",
                        refresh_interval=cfg.ACTIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                ]
            ),
        ]
        return {
            "entries": entries,
            "initial_mould_state_instructions_data": mould_state_instructions_data([
                mock_data.TeamInstructions.pallet_P_1,
                mock_data.TeamInstructions.pallet_P_2,
            ]),
            "initial_mould_state_plies_data": mould_state_plies_data([
                mock_data.MouldStatePlies.PalletP.first_ply_covered_without_invisible_edge,
                mock_data.MouldStatePlies.PalletP.second_ply_partially_covered,
                mock_data.MouldStatePlies.PalletP.third_ply_placed_updated_by_cam_3,
            ]),
            "initial_mould_state": GlobalMouldState.PRODUCTION,
            "initial_mould_blade_sn": "blade_sn",
        }

    @staticmethod
    def non_initial_ply_is_placed_when_on_boot_second_pallet_instruction_and_some_plies_preloaded():
        entries = [
            # 1 On DM boot team instructions are preloaded from ETCD store, no input data
            TestScenarioEntry(
                input_data=instructions_loaded_on_boot(),
                etcd_outputs=[
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.fourth_ply_expected),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam1": {"detectedEdges": ["P2.1"]},
                        "cam2": {"detectedEdges": ["P2.1", "P3.1"]},
                        "cam3": {"detectedEdges": ["P3.2"], "missingEdges": ["P4.1", "P4.2"]},
                        "cam4": {"missingEdges": ["P4.2"]}},
                    ),
                    camera_out(
                        camera_ids={"cam2", "cam1"},
                        command="start_capture",
                        refresh_interval=cfg.PASSIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                    camera_out(
                        camera_ids={"cam3", "cam4"},
                        command="start_capture",
                        refresh_interval=cfg.ACTIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_P": {"pallets": {"pallet_1": {"missingPlies": 0,
                                                                                       "placedPlies": 3,
                                                                                       "totalPlies": 3},
                                                                          "pallet_2": {"missingPlies": 0,
                                                                                       "placedPlies": 0,
                                                                                       "totalPlies": 3}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_P_1,
                            mock_data.TeamInstructions.pallet_P_2
                        ]),
                        "correctlyPlacedPlies": {},
                        "pliesToBePlaced": {
                            **mock_data.StaticGraph.SecondPalletP.fourth_ply,
                        },
                        "newMissingPlies": {},
                        "noLongerMissingPlies": {},
                        "forcedPlies": {},
                        "removedPlies": {}
                    }),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.SecondPalletP.fourth_ply),
                ]
            ),
            # 2 If TI preloaded on boot successfully then on EV msg fourth ply is detected, fifth ply is expected
            TestScenarioEntry(
                input_data=ev_message_in(
                    camera_id="cam3",
                    detected_edges={"P4.1", "P4.2"},
                    missing_edges={"P3.2"}
                ),
                etcd_outputs=[
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.third_ply_partially_covered),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.fourth_ply_placed),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.fifth_ply_expected),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam1": {"detectedEdges": ["P2.1"]},
                        "cam2": {"detectedEdges": ["P2.1", "P3.1"]},
                        "cam3": {"detectedEdges": ["P4.1", "P4.2"]},
                        "cam4": {"detectedEdges": ["P4.2"],
                                 "missingEdges": ["P5.1", "P5.2"]}},
                        session_cam_id="cam3"
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_P": {"pallets": {"pallet_1": {"missingPlies": 0,
                                                                                       "placedPlies": 3,
                                                                                       "totalPlies": 3},
                                                                          "pallet_2": {"missingPlies": 0,
                                                                                       "placedPlies": 1,
                                                                                       "totalPlies": 3}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_P_1,
                            mock_data.TeamInstructions.pallet_P_2
                        ],
                            session=ev_message_session("cam3")
                        ),
                        "correctlyPlacedPlies": {
                            **mock_data.StaticGraph.SecondPalletP.fourth_ply,
                        },
                        "pliesToBePlaced": {
                            **mock_data.StaticGraph.SecondPalletP.fifth_ply,
                        },
                        "newMissingPlies": {},
                        "noLongerMissingPlies": {},
                        "forcedPlies": {},
                        "removedPlies": {}
                    }),
                    laser_out(payload=mock_data.LaserFeedbacks.CorrectlyPlacedPlies.SecondPalletP.fourth_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.SecondPalletP.fifth_ply),
                    camera_out(
                        camera_ids={"cam2", "cam1", "cam3"},
                        command="start_capture",
                        refresh_interval=cfg.PASSIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                    camera_out(
                        camera_ids={"cam4"},
                        command="start_capture",
                        refresh_interval=cfg.ACTIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                ]
            ),
            # 3 The flow continuous...
            TestScenarioEntry(
                input_data=ev_message_in(
                    camera_id="cam4",
                    detected_edges={"P5.1", "P5.2"},
                    missing_edges=set()
                ),
                etcd_outputs=[
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.fourth_ply_partially_covered),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.fifth_ply_placed),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.sixth_ply_expected),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam1": {"detectedEdges": ["P2.1"]},
                        "cam2": {"detectedEdges": ["P2.1", "P3.1"]},
                        "cam3": {"detectedEdges": ["P4.1"]},
                        "cam4": {"detectedEdges": ["P5.1", "P5.2"], "missingEdges": ["P6.1"]},
                        "cam5": {"missingEdges": ["P6.1", "P6.2"]}},
                        session_cam_id="cam4"
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_P": {"pallets": {"pallet_1": {"missingPlies": 0,
                                                                                       "placedPlies": 3,
                                                                                       "totalPlies": 3},
                                                                          "pallet_2": {"missingPlies": 0,
                                                                                       "placedPlies": 2,
                                                                                       "totalPlies": 3}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_P_1,
                            mock_data.TeamInstructions.pallet_P_2
                        ],
                            session=ev_message_session("cam4")
                        ),
                        "correctlyPlacedPlies": {
                            **mock_data.StaticGraph.SecondPalletP.fifth_ply,
                        },
                        "pliesToBePlaced": {
                            **mock_data.StaticGraph.SecondPalletP.sixth_ply,
                        },
                        "newMissingPlies": {},
                        "noLongerMissingPlies": {},
                        "forcedPlies": {},
                        "removedPlies": {}
                    }),
                    laser_out(payload=mock_data.LaserFeedbacks.CorrectlyPlacedPlies.SecondPalletP.fifth_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.SecondPalletP.sixth_ply),
                    camera_out(
                        camera_ids={"cam2", "cam1", "cam3"},
                        command="start_capture",
                        refresh_interval=cfg.PASSIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                    camera_out(
                        camera_ids={"cam4", "cam5"},
                        command="start_capture",
                        refresh_interval=cfg.ACTIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                ]
            ),
        ]
        return {
            "entries": entries,
            "initial_mould_state_instructions_data": mould_state_instructions_data([
                mock_data.TeamInstructions.pallet_P_1,
                mock_data.TeamInstructions.pallet_P_2,
            ]),
            "initial_mould_state_plies_data": mould_state_plies_data([
                mock_data.MouldStatePlies.PalletP.first_ply_covered_without_invisible_edge,
                mock_data.MouldStatePlies.PalletP.second_ply_partially_covered,
                mock_data.MouldStatePlies.PalletP.third_ply_placed_updated_by_cam_3,
            ]),
            "initial_mould_state": GlobalMouldState.PRODUCTION,
            "initial_mould_blade_sn": "blade_sn",
        }

    @staticmethod
    def multiple_initial_plies_are_not_yet_placed_when_multiple_initial_pallet_instructions_preloaded_on_boot():
        entries = [
            # 1 On DM boot team instructions are preloaded from ETCD store, no input data
            TestScenarioEntry(
                input_data=instructions_loaded_on_boot(),
                etcd_outputs=[
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.first_ply_expected_without_invisible_edge),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.fourth_ply_expected),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.seventh_ply_expected),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam1": {"missingEdges": ["P1.2"]},
                        "cam3": {"missingEdges": ["P4.1", "P4.2"]},
                        "cam4": {"missingEdges": ["P4.2"]},
                        "cam5": {"missingEdges": ["P7.1", "P7.2"]},
                        "cam6": {"missingEdges": ["P7.2"]}},
                    ),
                    camera_out(
                        camera_ids={"cam1", "cam3", "cam4", "cam5", "cam6"},
                        command="start_capture",
                        refresh_interval=cfg.ACTIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_P": {"pallets": {"pallet_1": {"missingPlies": 0,
                                                                                       "placedPlies": 0,
                                                                                       "totalPlies": 3},
                                                                          "pallet_2": {"missingPlies": 0,
                                                                                       "placedPlies": 0,
                                                                                       "totalPlies": 3},
                                                                          "pallet_3": {"missingPlies": 0,
                                                                                       "placedPlies": 0,
                                                                                       "totalPlies": 3}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_P_1,
                            mock_data.TeamInstructions.pallet_P_2,
                            mock_data.TeamInstructions.pallet_P_3,
                        ]),
                        "correctlyPlacedPlies": {},
                        "pliesToBePlaced": {
                            **mock_data.StaticGraph.FirstPalletP.first_ply_invisible_edge_removed,
                            **mock_data.StaticGraph.SecondPalletP.fourth_ply,
                            **mock_data.StaticGraph.ThirdPalletP.seventh_ply,
                        },
                        "newMissingPlies": {},
                        "noLongerMissingPlies": {},
                        "forcedPlies": {},
                        "removedPlies": {}
                    }),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.FirstPalletP.first_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.SecondPalletP.fourth_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.ThirdPalletP.seventh_ply),
                ]
            ),
            # 2 If TI preloaded on boot successfully then on EV msg first ply is expected
            TestScenarioEntry(
                input_data=ev_message_in(
                    camera_id="cam1",
                    detected_edges=set(),
                    missing_edges={"P1.2"},
                ),
                etcd_outputs=[],
                messaging_outputs=[]
            ),
            TestScenarioEntry(
                input_data=ev_message_in(
                    camera_id="cam3",
                    detected_edges=set(),
                    missing_edges={"P4.1", "P4.2"},
                ),
                etcd_outputs=[],
                messaging_outputs=[]
            ),
            TestScenarioEntry(
                input_data=ev_message_in(
                    camera_id="cam5",
                    detected_edges=set(),
                    missing_edges={"P7.1", "P7.2"},
                ),
                etcd_outputs=[],
                messaging_outputs=[]
            ),
            # 5 on EV msg first ply is detected
            TestScenarioEntry(
                input_data=ev_message_in(
                    camera_id="cam1",
                    detected_edges={"P1.2"},
                    missing_edges=set()
                ),
                etcd_outputs=[
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.first_ply_placed_without_invisible_edge),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.second_ply_expected),
                    # TODO: i believe this problem is known, we probably don"t want fourth and seventh to be sent here
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.fourth_ply_expected),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.seventh_ply_expected),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam1": {"detectedEdges": ["P1.2"], "missingEdges": ["P2.1"]},
                        "cam2": {"missingEdges": ["P2.1", "P2.2"]},
                        "cam3": {"missingEdges": ["P4.1", "P4.2"]},
                        "cam4": {"missingEdges": ["P4.2"]},
                        "cam5": {"missingEdges": ["P7.1", "P7.2"]},
                        "cam6": {"missingEdges": ["P7.2"]}},
                        session_cam_id="cam1"
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_P": {"pallets": {"pallet_1": {"missingPlies": 0,
                                                                                       "placedPlies": 1,
                                                                                       "totalPlies": 3},
                                                                          "pallet_2": {"missingPlies": 0,
                                                                                       "placedPlies": 0,
                                                                                       "totalPlies": 3},
                                                                          "pallet_3": {"missingPlies": 0,
                                                                                       "placedPlies": 0,
                                                                                       "totalPlies": 3}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_P_1,
                            mock_data.TeamInstructions.pallet_P_2,
                            mock_data.TeamInstructions.pallet_P_3,
                        ],
                            session=ev_message_session("cam1")
                        ),
                        "correctlyPlacedPlies": {
                            **mock_data.StaticGraph.FirstPalletP.first_ply_invisible_edge_removed,
                        },
                        "pliesToBePlaced": {
                            **mock_data.StaticGraph.FirstPalletP.second_ply,
                            **mock_data.StaticGraph.SecondPalletP.fourth_ply,
                            **mock_data.StaticGraph.ThirdPalletP.seventh_ply,
                        },
                        "newMissingPlies": {},
                        "noLongerMissingPlies": {},
                        "forcedPlies": {},
                        "removedPlies": {}
                    }),
                    laser_out(payload=mock_data.LaserFeedbacks.CorrectlyPlacedPlies.FirstPalletP.first_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.FirstPalletP.second_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.SecondPalletP.fourth_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.ThirdPalletP.seventh_ply),
                    camera_out(
                        camera_ids={"cam1", "cam2", "cam3", "cam4", "cam5", "cam6"},
                        command="start_capture",
                        refresh_interval=cfg.ACTIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                ]
            ),
            # 6 on EV msg fourth ply is detected
            TestScenarioEntry(
                input_data=ev_message_in(
                    camera_id="cam3",
                    detected_edges={"P4.1", "P4.2"},
                    missing_edges=set()
                ),
                etcd_outputs=[
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.second_ply_expected),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.fourth_ply_placed),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.fifth_ply_expected),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.seventh_ply_expected),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam1": {"detectedEdges": ["P1.2"], "missingEdges": ["P2.1"]},
                        "cam2": {"missingEdges": ["P2.1", "P2.2"]},
                        "cam3": {"detectedEdges": ["P4.1", "P4.2"]},
                        "cam4": {"detectedEdges": ["P4.2"], "missingEdges": ["P5.1", "P5.2"]},
                        "cam5": {"missingEdges": ["P7.1", "P7.2"]},
                        "cam6": {"missingEdges": ["P7.2"]}},
                        session_cam_id="cam3"
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_P": {"pallets": {"pallet_1": {"missingPlies": 0,
                                                                                       "placedPlies": 1,
                                                                                       "totalPlies": 3},
                                                                          "pallet_2": {"missingPlies": 0,
                                                                                       "placedPlies": 1,
                                                                                       "totalPlies": 3},
                                                                          "pallet_3": {"missingPlies": 0,
                                                                                       "placedPlies": 0,
                                                                                       "totalPlies": 3}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_P_1,
                            mock_data.TeamInstructions.pallet_P_2,
                            mock_data.TeamInstructions.pallet_P_3,
                        ],
                            session=ev_message_session("cam3")
                        ),
                        "correctlyPlacedPlies": {
                            **mock_data.StaticGraph.SecondPalletP.fourth_ply,
                        },
                        "pliesToBePlaced": {
                            **mock_data.StaticGraph.FirstPalletP.second_ply,
                            **mock_data.StaticGraph.SecondPalletP.fifth_ply,
                            **mock_data.StaticGraph.ThirdPalletP.seventh_ply,
                        },
                        "newMissingPlies": {},
                        "noLongerMissingPlies": {},
                        "forcedPlies": {},
                        "removedPlies": {}
                    }),
                    laser_out(payload=mock_data.LaserFeedbacks.CorrectlyPlacedPlies.SecondPalletP.fourth_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.FirstPalletP.second_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.SecondPalletP.fifth_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.ThirdPalletP.seventh_ply),
                    camera_out(
                        camera_ids={"cam3"},
                        command="start_capture",
                        refresh_interval=cfg.PASSIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                    camera_out(
                        camera_ids={"cam1", "cam2", "cam4", "cam5", "cam6"},
                        command="start_capture",
                        refresh_interval=cfg.ACTIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                ]
            ),
            # 7 on EV msg seventh ply is detected
            TestScenarioEntry(
                input_data=ev_message_in(
                    camera_id="cam5",
                    detected_edges={"P7.1", "P7.2"},
                    missing_edges=set()
                ),
                etcd_outputs=[
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.second_ply_expected),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.fifth_ply_expected),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.seventh_ply_placed),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.eighth_ply_expected),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam1": {"detectedEdges": ["P1.2"], "missingEdges": ["P2.1"]},
                        "cam2": {"missingEdges": ["P2.1", "P2.2"]},
                        "cam3": {"detectedEdges": ["P4.1", "P4.2"]},
                        "cam4": {"detectedEdges": ["P4.2"], "missingEdges": ["P5.1", "P5.2"]},
                        "cam5": {"detectedEdges": ["P7.1", "P7.2"]},
                        "cam6": {"detectedEdges": ["P7.2"],
                                 "missingEdges": ["P8.1", "P8.2"]}},
                        session_cam_id="cam5"
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_P": {"pallets": {"pallet_1": {"missingPlies": 0,
                                                                                       "placedPlies": 1,
                                                                                       "totalPlies": 3},
                                                                          "pallet_2": {"missingPlies": 0,
                                                                                       "placedPlies": 1,
                                                                                       "totalPlies": 3},
                                                                          "pallet_3": {"missingPlies": 0,
                                                                                       "placedPlies": 1,
                                                                                       "totalPlies": 3}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_P_1,
                            mock_data.TeamInstructions.pallet_P_2,
                            mock_data.TeamInstructions.pallet_P_3,
                        ],
                            session=ev_message_session("cam5")
                        ),
                        "correctlyPlacedPlies": {
                            **mock_data.StaticGraph.ThirdPalletP.seventh_ply,
                        },
                        "pliesToBePlaced": {
                            **mock_data.StaticGraph.FirstPalletP.second_ply,
                            **mock_data.StaticGraph.SecondPalletP.fifth_ply,
                            **mock_data.StaticGraph.ThirdPalletP.eighth_ply,
                        },
                        "newMissingPlies": {},
                        "noLongerMissingPlies": {},
                        "forcedPlies": {},
                        "removedPlies": {}
                    }),
                    laser_out(payload=mock_data.LaserFeedbacks.CorrectlyPlacedPlies.ThirdPalletP.seventh_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.FirstPalletP.second_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.SecondPalletP.fifth_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.ThirdPalletP.eighth_ply),
                    camera_out(
                        camera_ids={"cam3", "cam5"},
                        command="start_capture",
                        refresh_interval=cfg.PASSIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                    camera_out(
                        camera_ids={"cam1", "cam2", "cam4", "cam6"},
                        command="start_capture",
                        refresh_interval=cfg.ACTIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                ]
            ),
        ]
        return {
            "entries": entries,
            "initial_mould_state_instructions_data": mould_state_instructions_data([
                mock_data.TeamInstructions.pallet_P_1,
                mock_data.TeamInstructions.pallet_P_2,
                mock_data.TeamInstructions.pallet_P_3,
            ]),
            "initial_mould_state": GlobalMouldState.PRODUCTION,
            "initial_mould_blade_sn": "blade_sn",
        }

    @staticmethod
    def multiple_initial_plies_are_placed_when_multiple_initial_pallet_instructions_preloaded_on_boot():
        entries = [
            # 1 On DM boot team instructions are preloaded from ETCD store, no input data
            TestScenarioEntry(
                input_data=instructions_loaded_on_boot(),
                etcd_outputs=[
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.first_ply_expected_without_invisible_edge),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.fourth_ply_expected),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.seventh_ply_expected),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam1": {"missingEdges": ["P1.2"]},
                        "cam3": {"missingEdges": ["P4.1", "P4.2"]},
                        "cam4": {"missingEdges": ["P4.2"]},
                        "cam5": {"missingEdges": ["P7.1", "P7.2"]},
                        "cam6": {"missingEdges": ["P7.2"]}},
                    ),
                    camera_out(
                        camera_ids={"cam1", "cam3", "cam4", "cam5", "cam6"},
                        command="start_capture",
                        refresh_interval=cfg.ACTIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_P": {"pallets": {"pallet_1": {"missingPlies": 0,
                                                                                       "placedPlies": 0,
                                                                                       "totalPlies": 3},
                                                                          "pallet_2": {"missingPlies": 0,
                                                                                       "placedPlies": 0,
                                                                                       "totalPlies": 3},
                                                                          "pallet_3": {"missingPlies": 0,
                                                                                       "placedPlies": 0,
                                                                                       "totalPlies": 3}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_P_1,
                            mock_data.TeamInstructions.pallet_P_2,
                            mock_data.TeamInstructions.pallet_P_3,
                        ]),
                        "correctlyPlacedPlies": {},
                        "pliesToBePlaced": {
                            **mock_data.StaticGraph.FirstPalletP.first_ply_invisible_edge_removed,
                            **mock_data.StaticGraph.SecondPalletP.fourth_ply,
                            **mock_data.StaticGraph.ThirdPalletP.seventh_ply,
                        },
                        "newMissingPlies": {},
                        "noLongerMissingPlies": {},
                        "forcedPlies": {},
                        "removedPlies": {}
                    }),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.FirstPalletP.first_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.SecondPalletP.fourth_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.ThirdPalletP.seventh_ply),
                ]
            ),
            # 2 If TIs preloaded on boot successfully then on EV msg 1 ply is detected, 4,5 and 7th plies is expected
            TestScenarioEntry(
                input_data=ev_message_in(
                    camera_id="cam1",
                    detected_edges={"P1.2"},
                    missing_edges=set()
                ),
                etcd_outputs=[
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.first_ply_placed_without_invisible_edge),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.second_ply_expected),
                    # TODO: i believe this problem is known, we probably don"t want fourth and seventh to be sent here
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.fourth_ply_expected),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.seventh_ply_expected),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam1": {"detectedEdges": ["P1.2"], "missingEdges": ["P2.1"]},
                        "cam2": {"missingEdges": ["P2.1", "P2.2"]},
                        "cam3": {"missingEdges": ["P4.1", "P4.2"]},
                        "cam4": {"missingEdges": ["P4.2"]},
                        "cam5": {"missingEdges": ["P7.1", "P7.2"]},
                        "cam6": {"missingEdges": ["P7.2"]}},
                        session_cam_id="cam1"
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_P": {"pallets": {"pallet_1": {"missingPlies": 0,
                                                                                       "placedPlies": 1,
                                                                                       "totalPlies": 3},
                                                                          "pallet_2": {"missingPlies": 0,
                                                                                       "placedPlies": 0,
                                                                                       "totalPlies": 3},
                                                                          "pallet_3": {"missingPlies": 0,
                                                                                       "placedPlies": 0,
                                                                                       "totalPlies": 3}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_P_1,
                            mock_data.TeamInstructions.pallet_P_2,
                            mock_data.TeamInstructions.pallet_P_3,
                        ],
                            session=ev_message_session("cam1")
                        ),
                        "correctlyPlacedPlies": {
                            **mock_data.StaticGraph.FirstPalletP.first_ply_invisible_edge_removed,
                        },
                        "pliesToBePlaced": {
                            **mock_data.StaticGraph.FirstPalletP.second_ply,
                            **mock_data.StaticGraph.SecondPalletP.fourth_ply,
                            **mock_data.StaticGraph.ThirdPalletP.seventh_ply,
                        },
                        "newMissingPlies": {},
                        "noLongerMissingPlies": {},
                        "forcedPlies": {},
                        "removedPlies": {}
                    }),
                    laser_out(payload=mock_data.LaserFeedbacks.CorrectlyPlacedPlies.FirstPalletP.first_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.FirstPalletP.second_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.SecondPalletP.fourth_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.ThirdPalletP.seventh_ply),
                    camera_out(
                        camera_ids={"cam1", "cam2", "cam3", "cam4", "cam5", "cam6"},
                        command="start_capture",
                        refresh_interval=cfg.ACTIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                ]
            ),
            # 3 on EV msg fourth ply is detected
            TestScenarioEntry(
                input_data=ev_message_in(
                    camera_id="cam3",
                    detected_edges={"P4.1", "P4.2"},
                    missing_edges=set()
                ),
                etcd_outputs=[
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.second_ply_expected),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.fourth_ply_placed),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.fifth_ply_expected),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.seventh_ply_expected),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam1": {"detectedEdges": ["P1.2"], "missingEdges": ["P2.1"]},
                        "cam2": {"missingEdges": ["P2.1", "P2.2"]},
                        "cam3": {"detectedEdges": ["P4.1", "P4.2"]},
                        "cam4": {"detectedEdges": ["P4.2"], "missingEdges": ["P5.1", "P5.2"]},
                        "cam5": {"missingEdges": ["P7.1", "P7.2"]},
                        "cam6": {"missingEdges": ["P7.2"]}},
                        session_cam_id="cam3"
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_P": {"pallets": {"pallet_1": {"missingPlies": 0,
                                                                                       "placedPlies": 1,
                                                                                       "totalPlies": 3},
                                                                          "pallet_2": {"missingPlies": 0,
                                                                                       "placedPlies": 1,
                                                                                       "totalPlies": 3},
                                                                          "pallet_3": {"missingPlies": 0,
                                                                                       "placedPlies": 0,
                                                                                       "totalPlies": 3}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_P_1,
                            mock_data.TeamInstructions.pallet_P_2,
                            mock_data.TeamInstructions.pallet_P_3,
                        ],
                            session=ev_message_session("cam3")
                        ),
                        "correctlyPlacedPlies": {
                            **mock_data.StaticGraph.SecondPalletP.fourth_ply,
                        },
                        "pliesToBePlaced": {
                            **mock_data.StaticGraph.FirstPalletP.second_ply,
                            **mock_data.StaticGraph.SecondPalletP.fifth_ply,
                            **mock_data.StaticGraph.ThirdPalletP.seventh_ply,
                        },
                        "newMissingPlies": {},
                        "noLongerMissingPlies": {},
                        "forcedPlies": {},
                        "removedPlies": {}
                    }),
                    laser_out(payload=mock_data.LaserFeedbacks.CorrectlyPlacedPlies.SecondPalletP.fourth_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.FirstPalletP.second_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.SecondPalletP.fifth_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.ThirdPalletP.seventh_ply),
                    camera_out(
                        camera_ids={"cam3"},
                        command="start_capture",
                        refresh_interval=cfg.PASSIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                    camera_out(
                        camera_ids={"cam1", "cam2", "cam4", "cam5", "cam6"},
                        command="start_capture",
                        refresh_interval=cfg.ACTIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                ]
            ),
            # 4 on EV msg seventh ply is detected
            TestScenarioEntry(
                input_data=ev_message_in(
                    camera_id="cam5",
                    detected_edges={"P7.1", "P7.2"},
                    missing_edges=set()
                ),
                etcd_outputs=[
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.second_ply_expected),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.fifth_ply_expected),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.seventh_ply_placed),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.eighth_ply_expected),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam1": {"detectedEdges": ["P1.2"], "missingEdges": ["P2.1"]},
                        "cam2": {"missingEdges": ["P2.1", "P2.2"]},
                        "cam3": {"detectedEdges": ["P4.1", "P4.2"]},
                        "cam4": {"detectedEdges": ["P4.2"], "missingEdges": ["P5.1", "P5.2"]},
                        "cam5": {"detectedEdges": ["P7.1", "P7.2"]},
                        "cam6": {"detectedEdges": ["P7.2"],
                                 "missingEdges": ["P8.1", "P8.2"]}},
                        session_cam_id="cam5"
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_P": {"pallets": {"pallet_1": {"missingPlies": 0,
                                                                                       "placedPlies": 1,
                                                                                       "totalPlies": 3},
                                                                          "pallet_2": {"missingPlies": 0,
                                                                                       "placedPlies": 1,
                                                                                       "totalPlies": 3},
                                                                          "pallet_3": {"missingPlies": 0,
                                                                                       "placedPlies": 1,
                                                                                       "totalPlies": 3}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_P_1,
                            mock_data.TeamInstructions.pallet_P_2,
                            mock_data.TeamInstructions.pallet_P_3,
                        ],
                            session=ev_message_session("cam5")
                        ),
                        "correctlyPlacedPlies": {
                            **mock_data.StaticGraph.ThirdPalletP.seventh_ply,
                        },
                        "pliesToBePlaced": {
                            **mock_data.StaticGraph.FirstPalletP.second_ply,
                            **mock_data.StaticGraph.SecondPalletP.fifth_ply,
                            **mock_data.StaticGraph.ThirdPalletP.eighth_ply,
                        },
                        "newMissingPlies": {},
                        "noLongerMissingPlies": {},
                        "forcedPlies": {},
                        "removedPlies": {}
                    }),
                    laser_out(payload=mock_data.LaserFeedbacks.CorrectlyPlacedPlies.ThirdPalletP.seventh_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.FirstPalletP.second_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.SecondPalletP.fifth_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.ThirdPalletP.eighth_ply),
                    camera_out(
                        camera_ids={"cam3", "cam5"},
                        command="start_capture",
                        refresh_interval=cfg.PASSIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                    camera_out(
                        camera_ids={"cam1", "cam2", "cam4", "cam6"},
                        command="start_capture",
                        refresh_interval=cfg.ACTIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                ]
            ),
            # 5 The flow continuous...
            TestScenarioEntry(
                input_data=ev_message_in(
                    camera_id="cam4",
                    detected_edges={"P5.1", "P5.2"},
                    missing_edges=set()
                ),
                etcd_outputs=[
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.second_ply_expected),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.fourth_ply_partially_covered),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.fifth_ply_placed),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.sixth_ply_expected),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletP.eighth_ply_expected),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam1": {"detectedEdges": ["P1.2"], "missingEdges": ["P2.1"]},
                        "cam2": {"missingEdges": ["P2.1", "P2.2"]},
                        "cam3": {"detectedEdges": ["P4.1"]},
                        "cam4": {"detectedEdges": ["P5.1", "P5.2"], "missingEdges": ["P6.1"]},
                        "cam5": {"detectedEdges": ["P7.1", "P7.2"],
                                 "missingEdges": ["P6.1", "P6.2"]},
                        "cam6": {"detectedEdges": ["P7.2"],
                                 "missingEdges": ["P8.1", "P8.2"]}},
                        session_cam_id="cam4"
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_P": {"pallets": {"pallet_1": {"missingPlies": 0,
                                                                                       "placedPlies": 1,
                                                                                       "totalPlies": 3},
                                                                          "pallet_2": {"missingPlies": 0,
                                                                                       "placedPlies": 2,
                                                                                       "totalPlies": 3},
                                                                          "pallet_3": {"missingPlies": 0,
                                                                                       "placedPlies": 1,
                                                                                       "totalPlies": 3}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_P_1,
                            mock_data.TeamInstructions.pallet_P_2,
                            mock_data.TeamInstructions.pallet_P_3,
                        ],
                            session=ev_message_session("cam4")
                        ),
                        "correctlyPlacedPlies": {
                            **mock_data.StaticGraph.SecondPalletP.fifth_ply,
                        },
                        "pliesToBePlaced": {
                            **mock_data.StaticGraph.FirstPalletP.second_ply,
                            **mock_data.StaticGraph.SecondPalletP.sixth_ply,
                            **mock_data.StaticGraph.ThirdPalletP.eighth_ply,
                        },
                        "newMissingPlies": {},
                        "noLongerMissingPlies": {},
                        "forcedPlies": {},
                        "removedPlies": {}
                    }),
                    laser_out(payload=mock_data.LaserFeedbacks.CorrectlyPlacedPlies.SecondPalletP.fifth_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.FirstPalletP.second_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.SecondPalletP.sixth_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.ThirdPalletP.eighth_ply),
                    camera_out(
                        camera_ids={"cam3"},
                        command="start_capture",
                        refresh_interval=cfg.PASSIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                    camera_out(
                        camera_ids={"cam1", "cam2", "cam4", "cam5", "cam6"},
                        command="start_capture",
                        refresh_interval=cfg.ACTIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                ]
            ),
        ]
        return {
            "entries": entries,
            "initial_mould_state_instructions_data": mould_state_instructions_data([
                mock_data.TeamInstructions.pallet_P_1,
                mock_data.TeamInstructions.pallet_P_2,
                mock_data.TeamInstructions.pallet_P_3,
            ]),
            "initial_mould_state": GlobalMouldState.PRODUCTION,
            "initial_mould_blade_sn": "blade_sn",
        }
