# pylint: disable=protected-access,missing-module-docstring, missing-class-docstring, missing-function-docstring, duplicate-code

import app.config as cfg
from app.global_mould_state_enum import GlobalMouldState
from tests.scenarios import mock_data
from tests.scenarios.model.test_scenario_entry import TestScenarioEntry
from tests.scenarios.scenarios_base import add_team_instruction_c2dm_request, etcd_ply_out, edge_verification_out, \
    camera_out, \
    trace_out, \
    laser_out, ev_message_in, ev_message_session, force_ply_c2dm_request, etcd_instruction_out, \
    trace_out_metadata, etcd_mould_state_out, etcd_mould_blade_sn_out, stats_out, mould_state_plies_data


class PlyCoveredTestScenariosDtos:
    @staticmethod
    def should_cover_when_single_ply_missing_at_same_time_new_ply_detected():
        entries = [
            # TI 1
            TestScenarioEntry(
                input_data=add_team_instruction_c2dm_request(instruction=mock_data.TeamInstructions.pallet_U_1),
                etcd_outputs=[
                    etcd_instruction_out(instruction=mock_data.TeamInstructions.pallet_U_1),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.first_ply_expected),
                    etcd_mould_state_out(state=GlobalMouldState.PRODUCTION),
                    etcd_mould_blade_sn_out(blade_sn="blade_sn"),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam1": {"missingEdges": ["U1.1", "U1.2"]}},
                        layers=["layer_U"],
                    ),
                    camera_out(
                        camera_ids={"cam1"},
                        command="start_capture",
                        refresh_interval=cfg.ACTIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_U": {"pallets": {"pallet_1": {"missingPlies": 0,
                                                                                       "placedPlies": 0,
                                                                                       "totalPlies": 5}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_U_1,
                        ]),
                        "correctlyPlacedPlies": {},
                        "pliesToBePlaced": {
                            **mock_data.StaticGraph.FirstPalletU.first_ply,
                        },
                        "newMissingPlies": {},
                        "noLongerMissingPlies": {},
                        "forcedPlies": {},
                        "removedPlies": {}
                    }),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.FirstPalletU.first_ply),
                ]
            ),
            # 2
            TestScenarioEntry(
                input_data=ev_message_in(
                    camera_id="cam1",
                    detected_edges={"U1.1", "U1.2"},
                    missing_edges=set()
                ),
                etcd_outputs=[
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.first_ply_placed),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.second_ply_expected),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam1": {"detectedEdges": ["U1.1", "U1.2"],
                                 "missingEdges": ["U2.1", "U2.2"]},
                        "cam2": {"missingEdges": ["U2.2"]}},
                        session_cam_id="cam1",
                        layers=["layer_U"],
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_U": {"pallets": {"pallet_1": {"missingPlies": 0,
                                                                                       "placedPlies": 1,
                                                                                       "totalPlies": 5}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_U_1,
                        ],
                            session=ev_message_session("cam1")
                        ),
                        "correctlyPlacedPlies": {
                            **mock_data.StaticGraph.FirstPalletU.first_ply,
                        },
                        "pliesToBePlaced": {
                            **mock_data.StaticGraph.FirstPalletU.second_ply_fully_covers_first_ply,
                        },
                        "newMissingPlies": {},
                        "noLongerMissingPlies": {},
                        "forcedPlies": {},
                        "removedPlies": {}
                    }),
                    laser_out(payload=mock_data.LaserFeedbacks.CorrectlyPlacedPlies.FirstPalletU.first_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.FirstPalletU.second_ply),
                    camera_out(
                        camera_ids={"cam2", "cam1"},
                        command="start_capture",
                        refresh_interval=cfg.ACTIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                ]
            ),
            # 3 on EV msg second ply fully covers first ply
            TestScenarioEntry(
                input_data=ev_message_in(
                    camera_id="cam1",
                    detected_edges={"U2.1", "U2.2"},
                    missing_edges={"U1.1", "U1.2"}
                ),
                etcd_outputs=[
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.first_ply_fully_covered_by_U2),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.second_ply_placed),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.third_ply_expected),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam1": {"detectedEdges": ["U2.1", "U2.2"]},
                        "cam2": {"detectedEdges": ["U2.2"],
                                 "missingEdges": ["U3.1", "U3.2"]}},
                        session_cam_id="cam1",
                        layers=["layer_U"],
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_U": {"pallets": {"pallet_1": {"missingPlies": 0,
                                                                                       "placedPlies": 2,
                                                                                       "totalPlies": 5}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_U_1,
                        ],
                            session=ev_message_session("cam1")
                        ),
                        "correctlyPlacedPlies": {
                            **mock_data.StaticGraph.FirstPalletU.second_ply_fully_covers_first_ply,
                        },
                        "pliesToBePlaced": {
                            **mock_data.StaticGraph.FirstPalletU.third_ply,
                        },
                        "newMissingPlies": {},
                        "noLongerMissingPlies": {},
                        "forcedPlies": {},
                        "removedPlies": {}
                    }),
                    laser_out(payload=mock_data.LaserFeedbacks.CorrectlyPlacedPlies.FirstPalletU.second_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.FirstPalletU.third_ply),
                    camera_out(
                        camera_ids={"cam1"},
                        command="start_capture",
                        refresh_interval=cfg.PASSIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                    camera_out(
                        camera_ids={"cam2"},
                        command="start_capture",
                        refresh_interval=cfg.ACTIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                ]
            ),
            # 4 EV - the flow continuous...
            TestScenarioEntry(
                input_data=ev_message_in(
                    camera_id="cam2",
                    detected_edges={"U3.1", "U3.2"},
                    missing_edges={"U2.2"}
                ),
                etcd_outputs=[
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.second_ply_partially_covered),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.third_ply_placed_updated_by_cam_2),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.fourth_ply_expected),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam1": {"detectedEdges": ["U2.1"]},
                        "cam2": {"detectedEdges": ["U3.1", "U3.2"],
                                 "missingEdges": ["U4.1", "U4.2"]}},
                        session_cam_id="cam2",
                        layers=["layer_U"],
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_U": {"pallets": {"pallet_1": {"missingPlies": 0,
                                                                                       "placedPlies": 3,
                                                                                       "totalPlies": 5}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_U_1,
                        ],
                            session=ev_message_session("cam2")
                        ),
                        "correctlyPlacedPlies": {
                            **mock_data.StaticGraph.FirstPalletU.third_ply,
                        },
                        "pliesToBePlaced": {
                            **mock_data.StaticGraph.FirstPalletU.fourth_ply,
                        },
                        "newMissingPlies": {},
                        "noLongerMissingPlies": {},
                        "forcedPlies": {},
                        "removedPlies": {}
                    }),
                    laser_out(payload=mock_data.LaserFeedbacks.CorrectlyPlacedPlies.FirstPalletU.third_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.FirstPalletU.fourth_ply),
                    camera_out(
                        camera_ids={"cam1"},
                        command="start_capture",
                        refresh_interval=cfg.PASSIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                    camera_out(
                        camera_ids={"cam2"},
                        command="start_capture",
                        refresh_interval=cfg.ACTIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                ]
            ),
        ]
        return {
            "entries": entries,
            "graph_data": {
                "mould_id": "mould_id",
                "blade_revision": "blade_revision",
                "version": "v1.0.0",
                "plies": {
                    **mock_data.StaticGraph.FirstPalletU.first_ply,
                    **mock_data.StaticGraph.FirstPalletU.second_ply_fully_covers_first_ply,
                    **mock_data.StaticGraph.FirstPalletU.third_ply,
                    **mock_data.StaticGraph.FirstPalletU.fourth_ply,
                    **mock_data.StaticGraph.FirstPalletU.fifth_ply,
                }
            },
        }

    @staticmethod
    def should_cover_when_single_ply_phantom_forced_before_new_ply_detected():
        entries = [
            # TI 1
            TestScenarioEntry(
                input_data=add_team_instruction_c2dm_request(instruction=mock_data.TeamInstructions.pallet_U_1),
                etcd_outputs=[
                    etcd_instruction_out(instruction=mock_data.TeamInstructions.pallet_U_1),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.first_ply_phantom_expected),
                    etcd_mould_state_out(state=GlobalMouldState.PRODUCTION),
                    etcd_mould_blade_sn_out(blade_sn="blade_sn"),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={},
                                          layers=["layer_U"],
                                          ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_U": {"pallets": {"pallet_1": {"missingPlies": 0,
                                                                                       "placedPlies": 0,
                                                                                       "totalPlies": 5}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_U_1,
                        ]),
                        "correctlyPlacedPlies": {},
                        "pliesToBePlaced": {
                            **mock_data.StaticGraph.FirstPalletU.first_ply_phantom,
                        },
                        "newMissingPlies": {},
                        "noLongerMissingPlies": {},
                        "forcedPlies": {},
                        "removedPlies": {}
                    }),
                    laser_out(payload=mock_data.LaserFeedbacks.PhantomPlies.FirstPalletU.first_ply),
                ]
            ),
            # 2 force_ply command
            TestScenarioEntry(
                input_data=force_ply_c2dm_request("U1"),
                etcd_outputs=[
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.first_ply_phantom_forced_on_expected),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.second_ply_expected),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam1": {"missingEdges": ["U2.1", "U2.2"]},
                        "cam2": {"missingEdges": ["U2.2"]}},
                        layers=["layer_U"],
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_U": {"pallets": {"pallet_1": {"missingPlies": 0,
                                                                                       "placedPlies": 1,
                                                                                       "totalPlies": 5}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_U_1,
                        ]),
                        "correctlyPlacedPlies": {},
                        "pliesToBePlaced": {
                            **mock_data.StaticGraph.FirstPalletU.second_ply_fully_covers_first_ply,
                        },
                        "newMissingPlies": {},
                        "noLongerMissingPlies": {},
                        "forcedPlies": {
                            **mock_data.StaticGraph.FirstPalletU.first_ply_phantom,
                        },
                        "removedPlies": {}
                    }),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.FirstPalletU.second_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToNull.FirstPalletU.first_ply),
                    camera_out(
                        camera_ids={"cam2", "cam1"},
                        command="start_capture",
                        refresh_interval=cfg.ACTIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                ]
            ),
            # 3 on EV msg second ply fully covers first ply
            TestScenarioEntry(
                input_data=ev_message_in(
                    camera_id="cam1",
                    detected_edges={"U2.1", "U2.2"},
                    missing_edges=set()
                ),
                etcd_outputs=[
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.second_ply_placed),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.third_ply_expected),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam1": {"detectedEdges": ["U2.1", "U2.2"]},
                        "cam2": {"detectedEdges": ["U2.2"],
                                 "missingEdges": ["U3.1", "U3.2"]}},
                        session_cam_id="cam1",
                        layers=["layer_U"],
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_U": {"pallets": {"pallet_1": {"missingPlies": 0,
                                                                                       "placedPlies": 2,
                                                                                       "totalPlies": 5}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_U_1,
                        ],
                            session=ev_message_session("cam1")
                        ),
                        "correctlyPlacedPlies": {
                            **mock_data.StaticGraph.FirstPalletU.second_ply_fully_covers_first_ply,
                        },
                        "pliesToBePlaced": {
                            **mock_data.StaticGraph.FirstPalletU.third_ply,
                        },
                        "newMissingPlies": {},
                        "noLongerMissingPlies": {},
                        "forcedPlies": {},
                        "removedPlies": {}
                    }),
                    laser_out(payload=mock_data.LaserFeedbacks.CorrectlyPlacedPlies.FirstPalletU.second_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.FirstPalletU.third_ply),
                    camera_out(
                        camera_ids={"cam1"},
                        command="start_capture",
                        refresh_interval=cfg.PASSIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                    camera_out(
                        camera_ids={"cam2"},
                        command="start_capture",
                        refresh_interval=cfg.ACTIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                ]
            ),
            # 4 EV - the flow continuous...
            TestScenarioEntry(
                input_data=ev_message_in(
                    camera_id="cam2",
                    detected_edges={"U3.1", "U3.2"},
                    missing_edges={"U2.2"}
                ),
                etcd_outputs=[
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.second_ply_partially_covered),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.third_ply_placed_updated_by_cam_2),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.fourth_ply_expected),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam1": {"detectedEdges": ["U2.1"]},
                        "cam2": {"detectedEdges": ["U3.1", "U3.2"],
                                 "missingEdges": ["U4.1", "U4.2"]}},
                        session_cam_id="cam2",
                        layers=["layer_U"],
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_U": {"pallets": {"pallet_1": {"missingPlies": 0,
                                                                                       "placedPlies": 3,
                                                                                       "totalPlies": 5}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_U_1,
                        ],
                            session=ev_message_session("cam2")
                        ),
                        "correctlyPlacedPlies": {
                            **mock_data.StaticGraph.FirstPalletU.third_ply,
                        },
                        "pliesToBePlaced": {
                            **mock_data.StaticGraph.FirstPalletU.fourth_ply,
                        },
                        "newMissingPlies": {},
                        "noLongerMissingPlies": {},
                        "forcedPlies": {},
                        "removedPlies": {}
                    }),
                    laser_out(payload=mock_data.LaserFeedbacks.CorrectlyPlacedPlies.FirstPalletU.third_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.FirstPalletU.fourth_ply),
                    camera_out(
                        camera_ids={"cam1"},
                        command="start_capture",
                        refresh_interval=cfg.PASSIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                    camera_out(
                        camera_ids={"cam2"},
                        command="start_capture",
                        refresh_interval=cfg.ACTIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                ]
            ),
        ]
        return {
            "entries": entries,
            "graph_data": {
                "mould_id": "mould_id",
                "blade_revision": "blade_revision",
                "version": "v1.0.0",
                "plies": {
                    **mock_data.StaticGraph.FirstPalletU.first_ply_phantom,
                    **mock_data.StaticGraph.FirstPalletU.second_ply_fully_covers_first_ply,
                    **mock_data.StaticGraph.FirstPalletU.third_ply,
                    **mock_data.StaticGraph.FirstPalletU.fourth_ply,
                    **mock_data.StaticGraph.FirstPalletU.fifth_ply,
                }
            },
        }

    @staticmethod
    def should_cover_when_phantom_forced_to_cover_single_ply():
        entries = [
            # TI 1
            TestScenarioEntry(
                input_data=add_team_instruction_c2dm_request(instruction=mock_data.TeamInstructions.pallet_U_1),
                etcd_outputs=[
                    etcd_instruction_out(instruction=mock_data.TeamInstructions.pallet_U_1),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.first_ply_expected),
                    etcd_mould_state_out(state=GlobalMouldState.PRODUCTION),
                    etcd_mould_blade_sn_out(blade_sn="blade_sn"),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam1": {"missingEdges": ["U1.1", "U1.2"]}},
                        layers=["layer_U"],
                    ),
                    camera_out(
                        camera_ids={"cam1"},
                        command="start_capture",
                        refresh_interval=cfg.ACTIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_U": {"pallets": {"pallet_1": {"missingPlies": 0,
                                                                                       "placedPlies": 0,
                                                                                       "totalPlies": 5}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_U_1,
                        ]),
                        "correctlyPlacedPlies": {},
                        "pliesToBePlaced": {
                            **mock_data.StaticGraph.FirstPalletU.first_ply,
                        },
                        "newMissingPlies": {},
                        "noLongerMissingPlies": {},
                        "forcedPlies": {},
                        "removedPlies": {}
                    }),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.FirstPalletU.first_ply),
                ]
            ),
            # 2
            TestScenarioEntry(
                input_data=ev_message_in(
                    camera_id="cam1",
                    detected_edges={"U1.1", "U1.2"},
                    missing_edges=set()
                ),
                etcd_outputs=[
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.first_ply_placed),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.second_ply_phantom_expected),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam1": {"detectedEdges": ["U1.1", "U1.2"]}},
                        session_cam_id="cam1",
                        layers=["layer_U"],
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_U": {"pallets": {"pallet_1": {"missingPlies": 0,
                                                                                       "placedPlies": 1,
                                                                                       "totalPlies": 5}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_U_1,
                        ],
                            session=ev_message_session("cam1")
                        ),
                        "correctlyPlacedPlies": {
                            **mock_data.StaticGraph.FirstPalletU.first_ply,
                        },
                        "pliesToBePlaced": {
                            **mock_data.StaticGraph.FirstPalletU.second_ply_phantom_fully_covers_first_ply,
                        },
                        "newMissingPlies": {},
                        "noLongerMissingPlies": {},
                        "forcedPlies": {},
                        "removedPlies": {}
                    }),
                    laser_out(payload=mock_data.LaserFeedbacks.CorrectlyPlacedPlies.FirstPalletU.first_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.PhantomPlies.FirstPalletU.second_ply),
                    camera_out(
                        camera_ids={"cam1"},
                        command="start_capture",
                        refresh_interval=cfg.PASSIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                ]
            ),
            # 3 force_ply command, fully covers first ply
            TestScenarioEntry(
                input_data=force_ply_c2dm_request("U2"),
                etcd_outputs=[
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.first_ply_fully_covered_by_U2_on_force_ply_cmd),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.second_ply_phantom_forced_on_expected),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.third_ply_expected),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam2": {"missingEdges": ["U3.1", "U3.2"]}},
                        layers=["layer_U"],
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_U": {"pallets": {"pallet_1": {"missingPlies": 0,
                                                                                       "placedPlies": 2,
                                                                                       "totalPlies": 5}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_U_1,
                        ]),
                        "correctlyPlacedPlies": {},
                        "pliesToBePlaced": {
                            **mock_data.StaticGraph.FirstPalletU.third_ply,
                        },
                        "newMissingPlies": {},
                        "noLongerMissingPlies": {},
                        "forcedPlies": {
                            **mock_data.StaticGraph.FirstPalletU.second_ply_phantom_fully_covers_first_ply,
                        },
                        "removedPlies": {}
                    }),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.FirstPalletU.third_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToNull.FirstPalletU.second_ply),
                    camera_out(
                        camera_ids={"cam1"},
                        command="start_capture",
                        refresh_interval=cfg.PASSIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                    camera_out(
                        camera_ids={"cam2"},
                        command="start_capture",
                        refresh_interval=cfg.ACTIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                ]
            ),
            # 4 EV - the flow continuous...
            TestScenarioEntry(
                input_data=ev_message_in(
                    camera_id="cam2",
                    detected_edges={"U3.1", "U3.2"},
                    missing_edges=set()
                ),
                etcd_outputs=[
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.third_ply_placed_updated_by_cam_2),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.fourth_ply_expected),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam2": {"detectedEdges": ["U3.1", "U3.2"],
                                 "missingEdges": ["U4.1", "U4.2"]}},
                        session_cam_id="cam2",
                        layers=["layer_U"],
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_U": {"pallets": {"pallet_1": {"missingPlies": 0,
                                                                                       "placedPlies": 3,
                                                                                       "totalPlies": 5}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_U_1,
                        ],
                            session=ev_message_session("cam2")
                        ),
                        "correctlyPlacedPlies": {
                            **mock_data.StaticGraph.FirstPalletU.third_ply,
                        },
                        "pliesToBePlaced": {
                            **mock_data.StaticGraph.FirstPalletU.fourth_ply,
                        },
                        "newMissingPlies": {},
                        "noLongerMissingPlies": {},
                        "forcedPlies": {},
                        "removedPlies": {}
                    }),
                    laser_out(payload=mock_data.LaserFeedbacks.CorrectlyPlacedPlies.FirstPalletU.third_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.FirstPalletU.fourth_ply),
                    camera_out(
                        camera_ids={"cam1"},
                        command="start_capture",
                        refresh_interval=cfg.PASSIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                    camera_out(
                        camera_ids={"cam2"},
                        command="start_capture",
                        refresh_interval=cfg.ACTIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                ]
            ),
        ]
        return {
            "entries": entries,
            "graph_data": {
                "mould_id": "mould_id",
                "blade_revision": "blade_revision",
                "version": "v1.0.0",
                "plies": {
                    **mock_data.StaticGraph.FirstPalletU.first_ply,
                    **mock_data.StaticGraph.FirstPalletU.second_ply_phantom_fully_covers_first_ply,
                    **mock_data.StaticGraph.FirstPalletU.third_ply,
                    **mock_data.StaticGraph.FirstPalletU.fourth_ply,
                    **mock_data.StaticGraph.FirstPalletU.fifth_ply,
                }
            },
        }

    @staticmethod
    def should_cover_when_phantom_forced_to_cover_other_phantom():
        entries = [
            # TI 1
            TestScenarioEntry(
                input_data=add_team_instruction_c2dm_request(instruction=mock_data.TeamInstructions.pallet_U_1),
                etcd_outputs=[
                    etcd_instruction_out(instruction=mock_data.TeamInstructions.pallet_U_1),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.first_ply_phantom_expected),
                    etcd_mould_state_out(state=GlobalMouldState.PRODUCTION),
                    etcd_mould_blade_sn_out(blade_sn="blade_sn"),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={},
                                          layers=["layer_U"],
                                          ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_U": {"pallets": {"pallet_1": {"missingPlies": 0,
                                                                                       "placedPlies": 0,
                                                                                       "totalPlies": 5}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_U_1,
                        ]),
                        "correctlyPlacedPlies": {},
                        "pliesToBePlaced": {
                            **mock_data.StaticGraph.FirstPalletU.first_ply_phantom,
                        },
                        "newMissingPlies": {},
                        "noLongerMissingPlies": {},
                        "forcedPlies": {},
                        "removedPlies": {}
                    }),
                    laser_out(payload=mock_data.LaserFeedbacks.PhantomPlies.FirstPalletU.first_ply),
                ]
            ),
            # 2 force_ply command
            TestScenarioEntry(
                input_data=force_ply_c2dm_request("U1"),
                etcd_outputs=[
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.first_ply_phantom_forced_on_expected),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.second_ply_phantom_expected),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={},
                                          layers=["layer_U"],
                                          ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_U": {"pallets": {"pallet_1": {"missingPlies": 0,
                                                                                       "placedPlies": 1,
                                                                                       "totalPlies": 5}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_U_1,
                        ]),
                        "correctlyPlacedPlies": {},
                        "pliesToBePlaced": {
                            **mock_data.StaticGraph.FirstPalletU.second_ply_phantom_fully_covers_first_ply,
                        },
                        "newMissingPlies": {},
                        "noLongerMissingPlies": {},
                        "forcedPlies": {
                            **mock_data.StaticGraph.FirstPalletU.first_ply_phantom,
                        },
                        "removedPlies": {}
                    }),
                    laser_out(payload=mock_data.LaserFeedbacks.PhantomPlies.FirstPalletU.second_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToNull.FirstPalletU.first_ply),
                ]
            ),
            # 3 force_ply command, fully covers first ply
            TestScenarioEntry(
                input_data=force_ply_c2dm_request("U2"),
                etcd_outputs=[
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.second_ply_phantom_forced_on_expected),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.third_ply_expected),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam2": {"missingEdges": ["U3.1", "U3.2"]}},
                        layers=["layer_U"],
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_U": {"pallets": {"pallet_1": {"missingPlies": 0,
                                                                                       "placedPlies": 2,
                                                                                       "totalPlies": 5}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_U_1,
                        ]),
                        "correctlyPlacedPlies": {},
                        "pliesToBePlaced": {
                            **mock_data.StaticGraph.FirstPalletU.third_ply,
                        },
                        "newMissingPlies": {},
                        "noLongerMissingPlies": {},
                        "forcedPlies": {
                            **mock_data.StaticGraph.FirstPalletU.second_ply_phantom_fully_covers_first_ply,
                        },
                        "removedPlies": {}
                    }),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.FirstPalletU.third_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToNull.FirstPalletU.second_ply),
                    camera_out(
                        camera_ids={"cam2"},
                        command="start_capture",
                        refresh_interval=cfg.ACTIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                ]
            ),
            # 4 EV - the flow continuous...
            TestScenarioEntry(
                input_data=ev_message_in(
                    camera_id="cam2",
                    detected_edges={"U3.1", "U3.2"},
                    missing_edges=set()
                ),
                etcd_outputs=[
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.third_ply_placed_updated_by_cam_2),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.fourth_ply_expected),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam2": {"detectedEdges": ["U3.1", "U3.2"],
                                 "missingEdges": ["U4.1", "U4.2"]}},
                        session_cam_id="cam2",
                        layers=["layer_U"],
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_U": {"pallets": {"pallet_1": {"missingPlies": 0,
                                                                                       "placedPlies": 3,
                                                                                       "totalPlies": 5}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_U_1,
                        ],
                            session=ev_message_session("cam2")
                        ),
                        "correctlyPlacedPlies": {
                            **mock_data.StaticGraph.FirstPalletU.third_ply,
                        },
                        "pliesToBePlaced": {
                            **mock_data.StaticGraph.FirstPalletU.fourth_ply,
                        },
                        "newMissingPlies": {},
                        "noLongerMissingPlies": {},
                        "forcedPlies": {},
                        "removedPlies": {}
                    }),
                    laser_out(payload=mock_data.LaserFeedbacks.CorrectlyPlacedPlies.FirstPalletU.third_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.FirstPalletU.fourth_ply),
                    camera_out(
                        camera_ids={"cam2"},
                        command="start_capture",
                        refresh_interval=cfg.ACTIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                ]
            ),
        ]
        return {
            "entries": entries,
            "graph_data": {
                "mould_id": "mould_id",
                "blade_revision": "blade_revision",
                "version": "v1.0.0",
                "plies": {
                    **mock_data.StaticGraph.FirstPalletU.first_ply_phantom,
                    **mock_data.StaticGraph.FirstPalletU.second_ply_phantom_fully_covers_first_ply,
                    **mock_data.StaticGraph.FirstPalletU.third_ply,
                    **mock_data.StaticGraph.FirstPalletU.fourth_ply,
                    **mock_data.StaticGraph.FirstPalletU.fifth_ply,
                }
            },
        }

    @staticmethod
    def should_cover_when_single_ply_missing_one_edge_at_same_time_new_ply_detected():
        entries = [
            # TI 1
            TestScenarioEntry(
                input_data=add_team_instruction_c2dm_request(instruction=mock_data.TeamInstructions.pallet_U_1),
                etcd_outputs=[
                    etcd_instruction_out(instruction=mock_data.TeamInstructions.pallet_U_1),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.first_ply_expected),
                    etcd_mould_state_out(state=GlobalMouldState.PRODUCTION),
                    etcd_mould_blade_sn_out(blade_sn="blade_sn"),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam1": {"missingEdges": ["U1.1", "U1.2"]}},
                        layers=["layer_U"],
                    ),
                    camera_out(
                        camera_ids={"cam1"},
                        command="start_capture",
                        refresh_interval=cfg.ACTIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_U": {"pallets": {"pallet_1": {"missingPlies": 0,
                                                                                       "placedPlies": 0,
                                                                                       "totalPlies": 6}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_U_1,
                        ]),
                        "correctlyPlacedPlies": {},
                        "pliesToBePlaced": {
                            **mock_data.StaticGraph.FirstPalletU.first_ply,
                        },
                        "newMissingPlies": {},
                        "noLongerMissingPlies": {},
                        "forcedPlies": {},
                        "removedPlies": {}
                    }),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.FirstPalletU.first_ply),
                ]
            ),
            # 2
            TestScenarioEntry(
                input_data=ev_message_in(
                    camera_id="cam1",
                    detected_edges={"U1.1", "U1.2"},
                    missing_edges=set()
                ),
                etcd_outputs=[
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.first_ply_placed),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.second_ply_expected),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam1": {"detectedEdges": ["U1.1", "U1.2"],
                                 "missingEdges": ["U2.1", "U2.2"]},
                        "cam2": {"missingEdges": ["U2.2"]}},
                        session_cam_id="cam1",
                        layers=["layer_U"],
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_U": {"pallets": {"pallet_1": {"missingPlies": 0,
                                                                                       "placedPlies": 1,
                                                                                       "totalPlies": 6}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_U_1,
                        ],
                            session=ev_message_session("cam1")
                        ),
                        "correctlyPlacedPlies": {
                            **mock_data.StaticGraph.FirstPalletU.first_ply,
                        },
                        "pliesToBePlaced": {
                            **mock_data.StaticGraph.FirstPalletU.second_ply,
                        },
                        "newMissingPlies": {},
                        "noLongerMissingPlies": {},
                        "forcedPlies": {},
                        "removedPlies": {}
                    }),
                    laser_out(payload=mock_data.LaserFeedbacks.CorrectlyPlacedPlies.FirstPalletU.first_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.FirstPalletU.second_ply),
                    camera_out(
                        camera_ids={"cam2", "cam1"},
                        command="start_capture",
                        refresh_interval=cfg.ACTIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                ]
            ),
            # 3
            TestScenarioEntry(
                input_data=ev_message_in(
                    camera_id="cam1",
                    detected_edges={"U2.1", "U2.2"},
                    missing_edges={"U1.2"}
                ),
                etcd_outputs=[
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.first_ply_partially_covered),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.second_ply_placed),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.third_ply_expected),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam1": {"detectedEdges": ["U1.1", "U2.1", "U2.2"]},
                        "cam2": {"detectedEdges": ["U2.2"],
                                 "missingEdges": ["U3.1", "U3.2"]}},
                        session_cam_id="cam1",
                        layers=["layer_U"],
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_U": {"pallets": {"pallet_1": {"missingPlies": 0,
                                                                                       "placedPlies": 2,
                                                                                       "totalPlies": 6}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_U_1,
                        ],
                            session=ev_message_session("cam1")
                        ),
                        "correctlyPlacedPlies": {
                            **mock_data.StaticGraph.FirstPalletU.second_ply,
                        },
                        "pliesToBePlaced": {
                            **mock_data.StaticGraph.FirstPalletU.third_ply_fully_covers_second_ply,
                        },
                        "newMissingPlies": {},
                        "noLongerMissingPlies": {},
                        "forcedPlies": {},
                        "removedPlies": {}
                    }),
                    laser_out(payload=mock_data.LaserFeedbacks.CorrectlyPlacedPlies.FirstPalletU.second_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.FirstPalletU.third_ply),
                    camera_out(
                        camera_ids={"cam1"},
                        command="start_capture",
                        refresh_interval=cfg.PASSIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                    camera_out(
                        camera_ids={"cam2"},
                        command="start_capture",
                        refresh_interval=cfg.ACTIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                ]
            ),
            # 4 on EV msg third ply fully covers second ply
            TestScenarioEntry(
                input_data=ev_message_in(
                    camera_id="cam2",
                    detected_edges={"U3.1", "U3.2"},
                    missing_edges={"U2.2"}
                ),
                etcd_outputs=[
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.second_ply_fully_covered_by_U3),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.third_ply_placed_updated_by_cam_2),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.fourth_ply_expected),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam1": {"detectedEdges": ["U1.1"]},
                        "cam2": {"detectedEdges": ["U3.1", "U3.2"],
                                 "missingEdges": ["U4.1", "U4.2"]}},
                        session_cam_id="cam2",
                        layers=["layer_U"],
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_U": {"pallets": {"pallet_1": {"missingPlies": 0,
                                                                                       "placedPlies": 3,
                                                                                       "totalPlies": 6}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_U_1,
                        ],
                            session=ev_message_session("cam2")
                        ),
                        "correctlyPlacedPlies": {
                            **mock_data.StaticGraph.FirstPalletU.third_ply_fully_covers_second_ply,
                        },
                        "pliesToBePlaced": {
                            **mock_data.StaticGraph.FirstPalletU.fourth_ply,
                        },
                        "newMissingPlies": {},
                        "noLongerMissingPlies": {},
                        "forcedPlies": {},
                        "removedPlies": {}
                    }),
                    laser_out(payload=mock_data.LaserFeedbacks.CorrectlyPlacedPlies.FirstPalletU.third_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.FirstPalletU.fourth_ply),
                    camera_out(
                        camera_ids={"cam1"},
                        command="start_capture",
                        refresh_interval=cfg.PASSIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                    camera_out(
                        camera_ids={"cam2"},
                        command="start_capture",
                        refresh_interval=cfg.ACTIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                ]
            ),
            # 5 EV - the flow continuous...
            TestScenarioEntry(
                input_data=ev_message_in(
                    camera_id="cam2",
                    detected_edges={"U4.1", "U4.2"},
                    missing_edges=set()
                ),
                etcd_outputs=[
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.third_ply_partially_covered),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.fourth_ply_placed),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.fifth_ply_expected),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam1": {"detectedEdges": ["U1.1"]},
                        "cam2": {"detectedEdges": ["U3.1", "U4.1", "U4.2"],
                                 "missingEdges": ["U5.1", "U5.2"]},
                        "cam3": {"missingEdges": ["U5.1", "U5.2"]}},
                        session_cam_id="cam2",
                        layers=["layer_U"],
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_U": {"pallets": {"pallet_1": {"missingPlies": 0,
                                                                                       "placedPlies": 4,
                                                                                       "totalPlies": 6}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_U_1,
                        ],
                            session=ev_message_session("cam2")
                        ),
                        "correctlyPlacedPlies": {
                            **mock_data.StaticGraph.FirstPalletU.fourth_ply,
                        },
                        "pliesToBePlaced": {
                            **mock_data.StaticGraph.FirstPalletU.fifth_ply,
                        },
                        "newMissingPlies": {},
                        "noLongerMissingPlies": {},
                        "forcedPlies": {},
                        "removedPlies": {}
                    }),
                    laser_out(payload=mock_data.LaserFeedbacks.CorrectlyPlacedPlies.FirstPalletU.fourth_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.FirstPalletU.fifth_ply),
                    camera_out(
                        camera_ids={"cam1"},
                        command="start_capture",
                        refresh_interval=cfg.PASSIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                    camera_out(
                        camera_ids={"cam2", "cam3"},
                        command="start_capture",
                        refresh_interval=cfg.ACTIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                ]
            ),
        ]
        return {
            "entries": entries,
            "graph_data": {
                "mould_id": "mould_id",
                "blade_revision": "blade_revision",
                "version": "v1.0.0",
                "plies": {
                    **mock_data.StaticGraph.FirstPalletU.first_ply,
                    **mock_data.StaticGraph.FirstPalletU.second_ply,
                    **mock_data.StaticGraph.FirstPalletU.third_ply_fully_covers_second_ply,
                    **mock_data.StaticGraph.FirstPalletU.fourth_ply,
                    **mock_data.StaticGraph.FirstPalletU.fifth_ply,
                    **mock_data.StaticGraph.FirstPalletU.sixth_ply,
                }
            },
        }

    @staticmethod
    def should_cover_when_single_ply_missing_one_edge_before_new_ply_detected():
        entries = [
            # TI 1
            TestScenarioEntry(
                input_data=add_team_instruction_c2dm_request(instruction=mock_data.TeamInstructions.pallet_U_1),
                etcd_outputs=[
                    etcd_instruction_out(instruction=mock_data.TeamInstructions.pallet_U_1),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.first_ply_expected),
                    etcd_mould_state_out(state=GlobalMouldState.PRODUCTION),
                    etcd_mould_blade_sn_out(blade_sn="blade_sn"),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam1": {"missingEdges": ["U1.1", "U1.2"]}},
                        layers=["layer_U"],
                    ),
                    camera_out(
                        camera_ids={"cam1"},
                        command="start_capture",
                        refresh_interval=cfg.ACTIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_U": {"pallets": {"pallet_1": {"missingPlies": 0,
                                                                                       "placedPlies": 0,
                                                                                       "totalPlies": 6}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_U_1,
                        ]),
                        "correctlyPlacedPlies": {},
                        "pliesToBePlaced": {
                            **mock_data.StaticGraph.FirstPalletU.first_ply,
                        },
                        "newMissingPlies": {},
                        "noLongerMissingPlies": {},
                        "forcedPlies": {},
                        "removedPlies": {}
                    }),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.FirstPalletU.first_ply),
                ]
            ),
            # 2
            TestScenarioEntry(
                input_data=ev_message_in(
                    camera_id="cam1",
                    detected_edges={"U1.1", "U1.2"},
                    missing_edges=set()
                ),
                etcd_outputs=[
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.first_ply_placed),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.second_ply_expected),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam1": {"detectedEdges": ["U1.1", "U1.2"],
                                 "missingEdges": ["U2.1", "U2.2"]},
                        "cam2": {"missingEdges": ["U2.2"]}},
                        session_cam_id="cam1",
                        layers=["layer_U"],
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_U": {"pallets": {"pallet_1": {"missingPlies": 0,
                                                                                       "placedPlies": 1,
                                                                                       "totalPlies": 6}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_U_1,
                        ],
                            session=ev_message_session("cam1")
                        ),
                        "correctlyPlacedPlies": {
                            **mock_data.StaticGraph.FirstPalletU.first_ply,
                        },
                        "pliesToBePlaced": {
                            **mock_data.StaticGraph.FirstPalletU.second_ply,
                        },
                        "newMissingPlies": {},
                        "noLongerMissingPlies": {},
                        "forcedPlies": {},
                        "removedPlies": {}
                    }),
                    laser_out(payload=mock_data.LaserFeedbacks.CorrectlyPlacedPlies.FirstPalletU.first_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.FirstPalletU.second_ply),
                    camera_out(
                        camera_ids={"cam1", "cam2"},
                        command="start_capture",
                        refresh_interval=cfg.ACTIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                ]
            ),
            # 3
            TestScenarioEntry(
                input_data=ev_message_in(
                    camera_id="cam1",
                    detected_edges={"U2.1", "U2.2"},
                    missing_edges={"U1.2"}
                ),
                etcd_outputs=[
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.first_ply_partially_covered),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.second_ply_placed),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.third_ply_expected),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam1": {"detectedEdges": ["U1.1", "U2.1", "U2.2"]},
                        "cam2": {"detectedEdges": ["U2.2"],
                                 "missingEdges": ["U3.1", "U3.2"]}},
                        session_cam_id="cam1",
                        layers=["layer_U"],
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_U": {"pallets": {"pallet_1": {"missingPlies": 0,
                                                                                       "placedPlies": 2,
                                                                                       "totalPlies": 6}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_U_1,
                        ],
                            session=ev_message_session("cam1")
                        ),
                        "correctlyPlacedPlies": {
                            **mock_data.StaticGraph.FirstPalletU.second_ply,
                        },
                        "pliesToBePlaced": {
                            **mock_data.StaticGraph.FirstPalletU.third_ply_fully_covers_second_ply,
                        },
                        "newMissingPlies": {},
                        "noLongerMissingPlies": {},
                        "forcedPlies": {},
                        "removedPlies": {}
                    }),
                    laser_out(payload=mock_data.LaserFeedbacks.CorrectlyPlacedPlies.FirstPalletU.second_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.FirstPalletU.third_ply),
                    camera_out(
                        camera_ids={"cam1"},
                        command="start_capture",
                        refresh_interval=cfg.PASSIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                    camera_out(
                        camera_ids={"cam2"},
                        command="start_capture",
                        refresh_interval=cfg.ACTIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                ]
            ),
            # 4
            TestScenarioEntry(
                input_data=ev_message_in(
                    camera_id="cam1",
                    detected_edges=set(),
                    missing_edges={"U2.2"},
                ),
                etcd_outputs=[
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.second_ply_missing_one_edge),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.third_ply_expected),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam1": {"detectedEdges": ["U1.1", "U2.1"], "missingEdges": ["U2.2"]},
                        "cam2": {"missingEdges": ["U2.2", "U3.1", "U3.2"]}},
                        session_cam_id="cam1",
                        layers=["layer_U"],
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_U": {"pallets": {"pallet_1": {"missingPlies": 1,
                                                                                       "placedPlies": 2,
                                                                                       "totalPlies": 6}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_U_1,
                        ],
                            session=ev_message_session("cam1")
                        ),
                        "correctlyPlacedPlies": {},
                        "pliesToBePlaced": {
                            **mock_data.StaticGraph.FirstPalletU.third_ply_fully_covers_second_ply,
                        },
                        "newMissingPlies": {
                            **mock_data.StaticGraph.FirstPalletU.second_ply,
                        },
                        "noLongerMissingPlies": {},
                        "forcedPlies": {},
                        "removedPlies": {}
                    }),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.FirstPalletU.third_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.MissingPlies.FirstPalletU.second_ply),
                    camera_out(
                        camera_ids={"cam2", "cam1"},
                        command="start_capture",
                        refresh_interval=cfg.ACTIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                ]
            ),
            # 5 on EV msg third ply fully covers second ply
            TestScenarioEntry(
                input_data=ev_message_in(
                    camera_id="cam2",
                    detected_edges={"U3.1", "U3.2"},
                    missing_edges={"U2.2"}
                ),
                etcd_outputs=[
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.second_ply_fully_covered_on_missing_one_edge),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.third_ply_placed_updated_by_cam_2),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.fourth_ply_expected),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam1": {"detectedEdges": ["U1.1"]},
                        "cam2": {"detectedEdges": ["U3.1", "U3.2"],
                                 "missingEdges": ["U4.1", "U4.2"]}},
                        session_cam_id="cam2",
                        layers=["layer_U"],
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_U": {"pallets": {"pallet_1": {"missingPlies": 0,
                                                                                       "placedPlies": 3,
                                                                                       "totalPlies": 6}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_U_1,
                        ],
                            session=ev_message_session("cam2")
                        ),
                        "correctlyPlacedPlies": {
                            **mock_data.StaticGraph.FirstPalletU.third_ply_fully_covers_second_ply,
                        },
                        "pliesToBePlaced": {
                            **mock_data.StaticGraph.FirstPalletU.fourth_ply,
                        },
                        "newMissingPlies": {},
                        "noLongerMissingPlies": {
                            **mock_data.StaticGraph.FirstPalletU.second_ply,
                        },
                        "forcedPlies": {},
                        "removedPlies": {}
                    }),
                    laser_out(payload=mock_data.LaserFeedbacks.CorrectlyPlacedPlies.FirstPalletU.third_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.FirstPalletU.fourth_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToNull.FirstPalletU.second_ply),
                    camera_out(
                        camera_ids={"cam1"},
                        command="start_capture",
                        refresh_interval=cfg.PASSIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                    camera_out(
                        camera_ids={"cam2"},
                        command="start_capture",
                        refresh_interval=cfg.ACTIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                ]
            ),
            # 6 EV - the flow continuous...
            TestScenarioEntry(
                input_data=ev_message_in(
                    camera_id="cam2",
                    detected_edges={"U4.1", "U4.2"},
                    missing_edges=set()
                ),
                etcd_outputs=[
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.third_ply_partially_covered),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.fourth_ply_placed),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.fifth_ply_expected),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam1": {"detectedEdges": ["U1.1"]},
                        "cam2": {"detectedEdges": ["U3.1", "U4.1", "U4.2"],
                                 "missingEdges": ["U5.1", "U5.2"]},
                        "cam3": {"missingEdges": ["U5.1", "U5.2"]}},
                        session_cam_id="cam2",
                        layers=["layer_U"],
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_U": {"pallets": {"pallet_1": {"missingPlies": 0,
                                                                                       "placedPlies": 4,
                                                                                       "totalPlies": 6}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_U_1,
                        ],
                            session=ev_message_session("cam2")
                        ),
                        "correctlyPlacedPlies": {
                            **mock_data.StaticGraph.FirstPalletU.fourth_ply,
                        },
                        "pliesToBePlaced": {
                            **mock_data.StaticGraph.FirstPalletU.fifth_ply,
                        },
                        "newMissingPlies": {},
                        "noLongerMissingPlies": {},
                        "forcedPlies": {},
                        "removedPlies": {}
                    }),
                    laser_out(payload=mock_data.LaserFeedbacks.CorrectlyPlacedPlies.FirstPalletU.fourth_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.FirstPalletU.fifth_ply),
                    camera_out(
                        camera_ids={"cam1"},
                        command="start_capture",
                        refresh_interval=cfg.PASSIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                    camera_out(
                        camera_ids={"cam2", "cam3"},
                        command="start_capture",
                        refresh_interval=cfg.ACTIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                ]
            ),
        ]
        return {
            "entries": entries,
            "graph_data": {
                "mould_id": "mould_id",
                "blade_revision": "blade_revision",
                "version": "v1.0.0",
                "plies": {
                    **mock_data.StaticGraph.FirstPalletU.first_ply,
                    **mock_data.StaticGraph.FirstPalletU.second_ply,
                    **mock_data.StaticGraph.FirstPalletU.third_ply_fully_covers_second_ply,
                    **mock_data.StaticGraph.FirstPalletU.fourth_ply,
                    **mock_data.StaticGraph.FirstPalletU.fifth_ply,
                    **mock_data.StaticGraph.FirstPalletU.sixth_ply,
                }
            },
        }

    @staticmethod
    def should_cover_when_single_ply_missing_both_edges_before_new_ply_detected():
        entries = [
            # TI 1
            TestScenarioEntry(
                input_data=add_team_instruction_c2dm_request(instruction=mock_data.TeamInstructions.pallet_U_1),
                etcd_outputs=[
                    etcd_instruction_out(instruction=mock_data.TeamInstructions.pallet_U_1),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.first_ply_expected),
                    etcd_mould_state_out(state=GlobalMouldState.PRODUCTION),
                    etcd_mould_blade_sn_out(blade_sn="blade_sn"),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam1": {"missingEdges": ["U1.1", "U1.2"]}},
                        layers=["layer_U"],
                    ),
                    camera_out(
                        camera_ids={"cam1"},
                        command="start_capture",
                        refresh_interval=cfg.ACTIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_U": {"pallets": {"pallet_1": {"missingPlies": 0,
                                                                                       "placedPlies": 0,
                                                                                       "totalPlies": 6}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_U_1,
                        ]),
                        "correctlyPlacedPlies": {},
                        "pliesToBePlaced": {
                            **mock_data.StaticGraph.FirstPalletU.first_ply,
                        },
                        "newMissingPlies": {},
                        "noLongerMissingPlies": {},
                        "forcedPlies": {},
                        "removedPlies": {}
                    }),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.FirstPalletU.first_ply),
                ]
            ),
            # 2
            TestScenarioEntry(
                input_data=ev_message_in(
                    camera_id="cam1",
                    detected_edges={"U1.1", "U1.2"},
                    missing_edges=set()
                ),
                etcd_outputs=[
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.first_ply_placed),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.second_ply_expected),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam1": {"detectedEdges": ["U1.1", "U1.2"],
                                 "missingEdges": ["U2.1", "U2.2"]},
                        "cam2": {"missingEdges": ["U2.2"]}},
                        session_cam_id="cam1",
                        layers=["layer_U"],
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_U": {"pallets": {"pallet_1": {"missingPlies": 0,
                                                                                       "placedPlies": 1,
                                                                                       "totalPlies": 6}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_U_1,
                        ],
                            session=ev_message_session("cam1")
                        ),
                        "correctlyPlacedPlies": {
                            **mock_data.StaticGraph.FirstPalletU.first_ply,
                        },
                        "pliesToBePlaced": {
                            **mock_data.StaticGraph.FirstPalletU.second_ply,
                        },
                        "newMissingPlies": {},
                        "noLongerMissingPlies": {},
                        "forcedPlies": {},
                        "removedPlies": {}
                    }),
                    laser_out(payload=mock_data.LaserFeedbacks.CorrectlyPlacedPlies.FirstPalletU.first_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.FirstPalletU.second_ply),
                    camera_out(
                        camera_ids={"cam2", "cam1"},
                        command="start_capture",
                        refresh_interval=cfg.ACTIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                ]
            ),
            # 3
            TestScenarioEntry(
                input_data=ev_message_in(
                    camera_id="cam1",
                    detected_edges={"U2.1", "U2.2"},
                    missing_edges={"U1.2"}
                ),
                etcd_outputs=[
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.first_ply_partially_covered),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.second_ply_placed),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.third_ply_expected),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam1": {"detectedEdges": ["U1.1", "U2.1", "U2.2"]},
                        "cam2": {"detectedEdges": ["U2.2"],
                                 "missingEdges": ["U3.1", "U3.2"]}},
                        session_cam_id="cam1",
                        layers=["layer_U"],
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_U": {"pallets": {"pallet_1": {"missingPlies": 0,
                                                                                       "placedPlies": 2,
                                                                                       "totalPlies": 6}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_U_1,
                        ],
                            session=ev_message_session("cam1")
                        ),
                        "correctlyPlacedPlies": {
                            **mock_data.StaticGraph.FirstPalletU.second_ply,
                        },
                        "pliesToBePlaced": {
                            **mock_data.StaticGraph.FirstPalletU.third_ply_fully_covers_second_ply,
                        },
                        "newMissingPlies": {},
                        "noLongerMissingPlies": {},
                        "forcedPlies": {},
                        "removedPlies": {}
                    }),
                    laser_out(payload=mock_data.LaserFeedbacks.CorrectlyPlacedPlies.FirstPalletU.second_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.FirstPalletU.third_ply),
                    camera_out(
                        camera_ids={"cam1"},
                        command="start_capture",
                        refresh_interval=cfg.PASSIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                    camera_out(
                        camera_ids={"cam2"},
                        command="start_capture",
                        refresh_interval=cfg.ACTIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                ]
            ),
            # 4
            TestScenarioEntry(
                input_data=ev_message_in(
                    camera_id="cam1",
                    detected_edges=set(),
                    missing_edges={"U2.1", "U2.2"},
                ),
                etcd_outputs=[
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.second_ply_missing),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.third_ply_expected),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam1": {"detectedEdges": ["U1.1"], "missingEdges": ["U2.1", "U2.2"]},
                        "cam2": {"missingEdges": ["U2.2", "U3.1", "U3.2"]}},
                        session_cam_id="cam1",
                        layers=["layer_U"],
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_U": {"pallets": {"pallet_1": {"missingPlies": 1,
                                                                                       "placedPlies": 2,
                                                                                       "totalPlies": 6}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_U_1,
                        ],
                            session=ev_message_session("cam1")
                        ),
                        "correctlyPlacedPlies": {},
                        "pliesToBePlaced": {
                            **mock_data.StaticGraph.FirstPalletU.third_ply_fully_covers_second_ply,
                        },
                        "newMissingPlies": {
                            **mock_data.StaticGraph.FirstPalletU.second_ply,
                        },
                        "noLongerMissingPlies": {},
                        "forcedPlies": {},
                        "removedPlies": {}
                    }),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.FirstPalletU.third_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.MissingPlies.FirstPalletU.second_ply),
                    camera_out(
                        camera_ids={"cam2", "cam1"},
                        command="start_capture",
                        refresh_interval=cfg.ACTIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                ]
            ),
            # 5 on EV msg third ply fully covers second ply
            TestScenarioEntry(
                input_data=ev_message_in(
                    camera_id="cam2",
                    detected_edges={"U3.1", "U3.2"},
                    missing_edges={"U2.2"},
                ),
                etcd_outputs=[
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.second_ply_fully_covered_on_missing),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.third_ply_placed_updated_by_cam_2),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.fourth_ply_expected),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam1": {"detectedEdges": ["U1.1"]},
                        "cam2": {"detectedEdges": ["U3.1", "U3.2"],
                                 "missingEdges": ["U4.1", "U4.2"]}},
                        session_cam_id="cam2",
                        layers=["layer_U"],
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_U": {"pallets": {"pallet_1": {"missingPlies": 0,
                                                                                       "placedPlies": 3,
                                                                                       "totalPlies": 6}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_U_1,
                        ],
                            session=ev_message_session("cam2")
                        ),
                        "correctlyPlacedPlies": {
                            **mock_data.StaticGraph.FirstPalletU.third_ply_fully_covers_second_ply,
                        },
                        "pliesToBePlaced": {
                            **mock_data.StaticGraph.FirstPalletU.fourth_ply,
                        },
                        "newMissingPlies": {},
                        "noLongerMissingPlies": {
                            **mock_data.StaticGraph.FirstPalletU.second_ply,
                        },
                        "forcedPlies": {},
                        "removedPlies": {}
                    }),
                    laser_out(payload=mock_data.LaserFeedbacks.CorrectlyPlacedPlies.FirstPalletU.third_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.FirstPalletU.fourth_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToNull.FirstPalletU.second_ply),
                    camera_out(
                        camera_ids={"cam1"},
                        command="start_capture",
                        refresh_interval=cfg.PASSIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                    camera_out(
                        camera_ids={"cam2"},
                        command="start_capture",
                        refresh_interval=cfg.ACTIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                ]
            ),
            # 6 EV - the flow continuous...
            TestScenarioEntry(
                input_data=ev_message_in(
                    camera_id="cam2",
                    detected_edges={"U4.1", "U4.2"},
                    missing_edges=set()
                ),
                etcd_outputs=[
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.third_ply_partially_covered),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.fourth_ply_placed),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.fifth_ply_expected),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam1": {"detectedEdges": ["U1.1"]},
                        "cam2": {"detectedEdges": ["U3.1", "U4.1", "U4.2"],
                                 "missingEdges": ["U5.1", "U5.2"]},
                        "cam3": {"missingEdges": ["U5.1", "U5.2"]}},
                        session_cam_id="cam2",
                        layers=["layer_U"],
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_U": {"pallets": {"pallet_1": {"missingPlies": 0,
                                                                                       "placedPlies": 4,
                                                                                       "totalPlies": 6}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_U_1,
                        ],
                            session=ev_message_session("cam2")
                        ),
                        "correctlyPlacedPlies": {
                            **mock_data.StaticGraph.FirstPalletU.fourth_ply,
                        },
                        "pliesToBePlaced": {
                            **mock_data.StaticGraph.FirstPalletU.fifth_ply,
                        },
                        "newMissingPlies": {},
                        "noLongerMissingPlies": {},
                        "forcedPlies": {},
                        "removedPlies": {}
                    }),
                    laser_out(payload=mock_data.LaserFeedbacks.CorrectlyPlacedPlies.FirstPalletU.fourth_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.FirstPalletU.fifth_ply),
                    camera_out(
                        camera_ids={"cam1"},
                        command="start_capture",
                        refresh_interval=cfg.PASSIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                    camera_out(
                        camera_ids={"cam2", "cam3"},
                        command="start_capture",
                        refresh_interval=cfg.ACTIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                ]
            ),
        ]
        return {
            "entries": entries,
            "graph_data": {
                "mould_id": "mould_id",
                "blade_revision": "blade_revision",
                "version": "v1.0.0",
                "plies": {
                    **mock_data.StaticGraph.FirstPalletU.first_ply,
                    **mock_data.StaticGraph.FirstPalletU.second_ply,
                    **mock_data.StaticGraph.FirstPalletU.third_ply_fully_covers_second_ply,
                    **mock_data.StaticGraph.FirstPalletU.fourth_ply,
                    **mock_data.StaticGraph.FirstPalletU.fifth_ply,
                    **mock_data.StaticGraph.FirstPalletU.sixth_ply,
                }
            },
        }

    @staticmethod
    def should_cover_when_single_ply_missing_one_of_the_edge_before_and_other_edge_at_same_time_new_ply_detected():
        entries = [
            # TI 1
            TestScenarioEntry(
                input_data=add_team_instruction_c2dm_request(instruction=mock_data.TeamInstructions.pallet_U_1),
                etcd_outputs=[
                    etcd_instruction_out(instruction=mock_data.TeamInstructions.pallet_U_1),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.fifth_ply_expected),
                    etcd_mould_state_out(state=GlobalMouldState.PRODUCTION),
                    etcd_mould_blade_sn_out(blade_sn="blade_sn"),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam1": {"detectedEdges": ["U1.1", "U2.1"]},
                        "cam2": {"detectedEdges": ["U3.1", "U4.1", "U4.2"],
                                 "missingEdges": ["U5.1", "U5.2"]},
                        "cam3": {"missingEdges": ["U5.1", "U5.2"]}},
                        layers=["layer_U"],
                    ),
                    camera_out(
                        camera_ids={"cam1"},
                        command="start_capture",
                        refresh_interval=cfg.PASSIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                    camera_out(
                        camera_ids={"cam2", "cam3"},
                        command="start_capture",
                        refresh_interval=cfg.ACTIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_U": {"pallets": {"pallet_1": {"missingPlies": 0,
                                                                                       "placedPlies": 4,
                                                                                       "totalPlies": 7}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_U_1,
                        ]),
                        "correctlyPlacedPlies": {},
                        "pliesToBePlaced": {
                            **mock_data.StaticGraph.FirstPalletU.fifth_ply_fully_covers_fourth_ply,
                        },
                        "newMissingPlies": {},
                        "noLongerMissingPlies": {},
                        "forcedPlies": {},
                        "removedPlies": {}
                    }),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.FirstPalletU.fifth_ply),
                ]
            ),
            # 2
            TestScenarioEntry(
                input_data=ev_message_in(
                    camera_id="cam2",
                    detected_edges={"U3.1", "U4.1", "U5.1"},
                    missing_edges={"U4.2"},
                ),
                etcd_outputs=[
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.fourth_ply_missing),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.fifth_ply_expected_edge_detected_by_cam2),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam1": {"detectedEdges": ["U1.1", "U2.1"]},
                        "cam2": {"detectedEdges": ["U3.1", "U4.1", "U5.1"], "missingEdges": ["U4.2", "U5.2"]},
                        "cam3": {"detectedEdges": ["U5.1"], "missingEdges": ["U5.2"]}},
                        session_cam_id="cam2",
                        layers=["layer_U"],
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_U": {"pallets": {"pallet_1": {"missingPlies": 1,
                                                                                       "placedPlies": 4,
                                                                                       "totalPlies": 7}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_U_1,
                        ],
                            session=ev_message_session("cam2")
                        ),
                        "correctlyPlacedPlies": {},
                        "pliesToBePlaced": {
                            **mock_data.StaticGraph.FirstPalletU.fifth_ply_fully_covers_fourth_ply,
                        },
                        "newMissingPlies": {
                            **mock_data.StaticGraph.FirstPalletU.fourth_ply,
                        },
                        "noLongerMissingPlies": {},
                        "forcedPlies": {},
                        "removedPlies": {}
                    }),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.FirstPalletU.fifth_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.MissingPlies.FirstPalletU.fourth_ply),
                    camera_out(
                        camera_ids={"cam1"},
                        command="start_capture",
                        refresh_interval=cfg.PASSIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                    camera_out(
                        camera_ids={"cam2", "cam3"},
                        command="start_capture",
                        refresh_interval=cfg.ACTIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                ]
            ),
            # 3
            TestScenarioEntry(
                input_data=ev_message_in(
                    camera_id="cam3",
                    detected_edges={"U5.1", "U5.2"},
                    missing_edges=set()
                ),
                etcd_outputs=[
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.fourth_ply_fully_covered_by_U5_on_missing),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.fifth_ply_placed_update_by_cam3),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.sixth_ply_expected),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam1": {"detectedEdges": ["U1.1", "U2.1"]},
                        "cam2": {"detectedEdges": ["U3.1", "U5.1", "U5.2"],
                                 "missingEdges": ["U6.1", "U6.2"]},
                        "cam3": {"detectedEdges": ["U5.1", "U5.2"],
                                 "missingEdges": ["U6.1", "U6.2"]}},
                        session_cam_id="cam3",
                        layers=["layer_U"],
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_U": {"pallets": {"pallet_1": {"missingPlies": 0,
                                                                                       "placedPlies": 5,
                                                                                       "totalPlies": 7}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_U_1,
                        ],
                            session=ev_message_session("cam3")
                        ),
                        "correctlyPlacedPlies": {
                            **mock_data.StaticGraph.FirstPalletU.fifth_ply_fully_covers_fourth_ply,
                        },
                        "pliesToBePlaced": {
                            **mock_data.StaticGraph.FirstPalletU.sixth_ply,
                        },
                        "newMissingPlies": {},
                        "noLongerMissingPlies": {
                            **mock_data.StaticGraph.FirstPalletU.fourth_ply,
                        },
                        "forcedPlies": {},
                        "removedPlies": {}
                    }),
                    laser_out(payload=mock_data.LaserFeedbacks.CorrectlyPlacedPlies.FirstPalletU.fifth_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.FirstPalletU.sixth_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToNull.FirstPalletU.fourth_ply),
                    camera_out(
                        camera_ids={"cam1"},
                        command="start_capture",
                        refresh_interval=cfg.PASSIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                    camera_out(
                        camera_ids={"cam2", "cam3"},
                        command="start_capture",
                        refresh_interval=cfg.ACTIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                ]
            ),
        ]
        return {
            "entries": entries,
            "initial_mould_state_plies_data": mould_state_plies_data([
                mock_data.MouldStatePlies.PalletU.first_ply_partially_covered,
                mock_data.MouldStatePlies.PalletU.second_ply_partially_covered,
                mock_data.MouldStatePlies.PalletU.third_ply_partially_covered,
                mock_data.MouldStatePlies.PalletU.fourth_ply_placed,
            ]),
            "graph_data": {
                "mould_id": "mould_id",
                "blade_revision": "blade_revision",
                "version": "v1.0.0",
                "plies": {
                    **mock_data.StaticGraph.FirstPalletU.first_ply,
                    **mock_data.StaticGraph.FirstPalletU.second_ply,
                    **mock_data.StaticGraph.FirstPalletU.third_ply,
                    **mock_data.StaticGraph.FirstPalletU.fourth_ply,
                    **mock_data.StaticGraph.FirstPalletU.fifth_ply_fully_covers_fourth_ply,
                    **mock_data.StaticGraph.FirstPalletU.sixth_ply,
                    **mock_data.StaticGraph.FirstPalletU.seventh_ply,
                }
            },
        }

    @staticmethod
    def should_cover_multiple_plies_when_multiple_plies_missing_at_same_time_new_ply_detected_by_same_cam():
        entries = [
            # TI 1
            TestScenarioEntry(
                input_data=add_team_instruction_c2dm_request(instruction=mock_data.TeamInstructions.pallet_U_1),
                etcd_outputs=[
                    etcd_instruction_out(instruction=mock_data.TeamInstructions.pallet_U_1),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.sixth_ply_expected),
                    etcd_mould_state_out(state=GlobalMouldState.PRODUCTION),
                    etcd_mould_blade_sn_out(blade_sn="blade_sn"),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam1": {"detectedEdges": ["U1.1", "U2.1"]},
                        "cam2": {"detectedEdges": ["U3.1", "U4.1", "U5.1", "U5.2"],
                                 "missingEdges": ["U6.1", "U6.2"]},
                        "cam3": {"detectedEdges": ["U5.1", "U5.2"],
                                 "missingEdges": ["U6.1", "U6.2"]}},
                        layers=["layer_U"],
                    ),
                    camera_out(
                        camera_ids={"cam1"},
                        command="start_capture",
                        refresh_interval=cfg.PASSIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                    camera_out(
                        camera_ids={"cam2", "cam3"},
                        command="start_capture",
                        refresh_interval=cfg.ACTIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_U": {"pallets": {"pallet_1": {"missingPlies": 0,
                                                                                       "placedPlies": 5,
                                                                                       "totalPlies": 7}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_U_1,
                        ]),
                        "correctlyPlacedPlies": {},
                        "pliesToBePlaced": {
                            **mock_data.StaticGraph.FirstPalletU.sixth_ply,
                        },
                        "newMissingPlies": {},
                        "noLongerMissingPlies": {},
                        "forcedPlies": {},
                        "removedPlies": {}
                    }),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.FirstPalletU.sixth_ply),
                ]
            ),
            # 2 on EV msg sixth ply fully covers multiple plies
            TestScenarioEntry(
                input_data=ev_message_in(
                    camera_id="cam2",
                    detected_edges={"U6.1", "U6.2"},
                    missing_edges={"U3.1", "U4.1", "U5.1", "U5.2"},
                ),
                etcd_outputs=[
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.first_ply_fully_covered_by_U6),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.second_ply_fully_covered_by_U6),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.third_ply_fully_covered_by_U6),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.fourth_ply_fully_covered_by_U6),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.fifth_ply_fully_covered_by_U6),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.sixth_ply_placed_by_cam2),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.seventh_ply_expected),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam2": {"detectedEdges": ["U6.1", "U6.2"],
                                 "missingEdges": ["U7.1", "U7.2"]},
                        "cam3": {"detectedEdges": ["U6.1", "U6.2"],
                                 "missingEdges": ["U7.1", "U7.2"]}},
                        session_cam_id="cam2",
                        layers=["layer_U"],
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_U": {"pallets": {"pallet_1": {"missingPlies": 0,
                                                                                       "placedPlies": 6,
                                                                                       "totalPlies": 7}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_U_1,
                        ],
                            session=ev_message_session("cam2")
                        ),
                        "correctlyPlacedPlies": {
                            **mock_data.StaticGraph.FirstPalletU.sixth_ply,
                        },
                        "pliesToBePlaced": {
                            **mock_data.StaticGraph.FirstPalletU.seventh_ply,
                        },
                        "newMissingPlies": {},
                        "noLongerMissingPlies": {},
                        "forcedPlies": {},
                        "removedPlies": {}
                    }),
                    laser_out(payload=mock_data.LaserFeedbacks.CorrectlyPlacedPlies.FirstPalletU.sixth_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.FirstPalletU.seventh_ply),
                    camera_out(
                        camera_ids={"cam1"},
                        command="start_capture",
                        refresh_interval=cfg.PASSIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                    camera_out(
                        camera_ids={"cam2", "cam3"},
                        command="start_capture",
                        refresh_interval=cfg.ACTIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                ]
            ),
            # 3 EV - the flow continuous...
            TestScenarioEntry(
                input_data=ev_message_in(
                    camera_id="cam2",
                    detected_edges={"U6.1", "U7.1", "U7.2"},
                    missing_edges={"U6.2"}
                ),
                etcd_outputs=[
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.sixth_ply_partially_covered_by_cam2),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.seventh_ply_placed_updated_by_cam2),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam2": {"detectedEdges": ["U6.1", "U7.1", "U7.2"]},
                        "cam3": {"detectedEdges": ["U6.1", "U7.1", "U7.2"]}},
                        session_cam_id="cam2",
                        layers=["layer_U"],
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_U": {"pallets": {"pallet_1": {"missingPlies": 0,
                                                                                       "placedPlies": 7,
                                                                                       "totalPlies": 7}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_U_1,
                        ],
                            session=ev_message_session("cam2")
                        ),
                        "correctlyPlacedPlies": {
                            **mock_data.StaticGraph.FirstPalletU.seventh_ply,
                        },
                        "pliesToBePlaced": {},
                        "newMissingPlies": {},
                        "noLongerMissingPlies": {
                            # TODO: known issue, not critical but would be nice if we could avoid unnecessary nulling
                            **mock_data.StaticGraph.FirstPalletU.sixth_ply,
                        },
                        "forcedPlies": {},
                        "removedPlies": {}
                    }),
                    laser_out(payload=mock_data.LaserFeedbacks.LastPliesPlaced.FirstPalletU.seventh_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToNull.FirstPalletU.sixth_ply),
                    camera_out(
                        camera_ids={"cam1", "cam2", "cam3"},
                        command="start_capture",
                        refresh_interval=cfg.PASSIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                ]
            ),
        ]
        return {
            "entries": entries,
            "initial_mould_state_plies_data": mould_state_plies_data([
                mock_data.MouldStatePlies.PalletU.first_ply_partially_covered,
                mock_data.MouldStatePlies.PalletU.second_ply_partially_covered,
                mock_data.MouldStatePlies.PalletU.third_ply_partially_covered,
                mock_data.MouldStatePlies.PalletU.fourth_ply_partially_covered,
                mock_data.MouldStatePlies.PalletU.fifth_ply_placed_update_by_cam2,
            ]),
            "graph_data": {
                "mould_id": "mould_id",
                "blade_revision": "blade_revision",
                "version": "v1.0.0",
                "plies": {
                    **mock_data.StaticGraph.FirstPalletU.first_ply,
                    **mock_data.StaticGraph.FirstPalletU.second_ply,
                    **mock_data.StaticGraph.FirstPalletU.third_ply,
                    **mock_data.StaticGraph.FirstPalletU.fourth_ply,
                    **mock_data.StaticGraph.FirstPalletU.fifth_ply,
                    **mock_data.StaticGraph.FirstPalletU.sixth_ply,
                    **mock_data.StaticGraph.FirstPalletU.seventh_ply,
                }
            },
        }

    @staticmethod
    def should_cover_multiple_plies_when_multiple_plies_missing_before_new_ply_detected_by_same_cam():
        entries = [
            # TI 1
            TestScenarioEntry(
                input_data=add_team_instruction_c2dm_request(instruction=mock_data.TeamInstructions.pallet_U_1),
                etcd_outputs=[
                    etcd_instruction_out(instruction=mock_data.TeamInstructions.pallet_U_1),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.sixth_ply_expected),
                    etcd_mould_state_out(state=GlobalMouldState.PRODUCTION),
                    etcd_mould_blade_sn_out(blade_sn="blade_sn"),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam1": {"detectedEdges": ["U1.1", "U2.1"]},
                        "cam2": {"detectedEdges": ["U3.1", "U4.1", "U5.1", "U5.2"],
                                 "missingEdges": ["U6.1", "U6.2"]},
                        "cam3": {"detectedEdges": ["U5.1", "U5.2"],
                                 "missingEdges": ["U6.1", "U6.2"]}},
                        layers=["layer_U"],
                    ),
                    camera_out(
                        camera_ids={"cam1"},
                        command="start_capture",
                        refresh_interval=cfg.PASSIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                    camera_out(
                        camera_ids={"cam2", "cam3"},
                        command="start_capture",
                        refresh_interval=cfg.ACTIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_U": {"pallets": {"pallet_1": {"missingPlies": 0,
                                                                                       "placedPlies": 5,
                                                                                       "totalPlies": 7}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_U_1,
                        ]),
                        "correctlyPlacedPlies": {},
                        "pliesToBePlaced": {
                            **mock_data.StaticGraph.FirstPalletU.sixth_ply,
                        },
                        "newMissingPlies": {},
                        "noLongerMissingPlies": {},
                        "forcedPlies": {},
                        "removedPlies": {}
                    }),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.FirstPalletU.sixth_ply),
                ]
            ),
            # 2 on EV multiple plies missing due being covered
            TestScenarioEntry(
                input_data=ev_message_in(
                    camera_id="cam2",
                    detected_edges=set(),
                    missing_edges={"U3.1", "U4.1", "U5.1", "U5.2", "U6.1", "U6.2"},
                ),
                etcd_outputs=[
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.third_ply_missing_due_being_covered),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.fourth_ply_missing_due_being_covered),
                    etcd_ply_out(
                        ply=mock_data.MouldStatePlies.PalletU.fifth_ply_missing_due_being_covered_update_by_cam2),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.sixth_ply_expected),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam1": {"detectedEdges": ["U1.1", "U2.1"]},
                        "cam2": {"missingEdges": ["U3.1",
                                                  "U4.1",
                                                  "U5.1",
                                                  "U5.2",
                                                  "U6.1",
                                                  "U6.2"]},
                        "cam3": {"missingEdges": ["U5.1", "U5.2", "U6.1", "U6.2"]}},
                        session_cam_id="cam2",
                        layers=["layer_U"],
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_U": {"pallets": {"pallet_1": {"missingPlies": 3,
                                                                                       "placedPlies": 5,
                                                                                       "totalPlies": 7}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_U_1,
                        ],
                            session=ev_message_session("cam2")
                        ),
                        "correctlyPlacedPlies": {
                        },
                        "pliesToBePlaced": {
                            **mock_data.StaticGraph.FirstPalletU.sixth_ply,
                        },
                        "newMissingPlies": {
                            **mock_data.StaticGraph.FirstPalletU.third_ply,
                            **mock_data.StaticGraph.FirstPalletU.fourth_ply,
                            **mock_data.StaticGraph.FirstPalletU.fifth_ply,
                        },
                        "noLongerMissingPlies": {},
                        "forcedPlies": {},
                        "removedPlies": {}
                    }),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.FirstPalletU.sixth_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.MissingPlies.FirstPalletU.third_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.MissingPlies.FirstPalletU.fourth_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.MissingPlies.FirstPalletU.fifth_ply),
                    camera_out(
                        camera_ids={"cam1"},
                        command="start_capture",
                        refresh_interval=cfg.PASSIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                    camera_out(
                        camera_ids={"cam2", "cam3"},
                        command="start_capture",
                        refresh_interval=cfg.ACTIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                ]
            ),
            # 3 on EV msg sixth ply fully covers multiple missing plies
            TestScenarioEntry(
                input_data=ev_message_in(
                    camera_id="cam2",
                    detected_edges={"U6.1", "U6.2"},
                    missing_edges={"U3.1", "U4.1", "U5.1", "U5.2"},
                ),
                etcd_outputs=[
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.first_ply_fully_covered_by_U6),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.second_ply_fully_covered_by_U6),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.third_ply_fully_covered_by_U6_on_missing),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.fourth_ply_fully_covered_by_U6_on_missing),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.fifth_ply_fully_covered_by_U6_on_missing),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.sixth_ply_placed_by_cam2),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.seventh_ply_expected),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam2": {"detectedEdges": ["U6.1", "U6.2"],
                                 "missingEdges": ["U7.1", "U7.2"]},
                        "cam3": {"detectedEdges": ["U6.1", "U6.2"],
                                 "missingEdges": ["U7.1", "U7.2"]}},
                        session_cam_id="cam2",
                        layers=["layer_U"],
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_U": {"pallets": {"pallet_1": {"missingPlies": 0,
                                                                                       "placedPlies": 6,
                                                                                       "totalPlies": 7}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_U_1,
                        ],
                            session=ev_message_session("cam2")
                        ),
                        "correctlyPlacedPlies": {
                            **mock_data.StaticGraph.FirstPalletU.sixth_ply,
                        },
                        "pliesToBePlaced": {
                            **mock_data.StaticGraph.FirstPalletU.seventh_ply,
                        },
                        "newMissingPlies": {},
                        "noLongerMissingPlies": {
                            **mock_data.StaticGraph.FirstPalletU.third_ply,
                            **mock_data.StaticGraph.FirstPalletU.fourth_ply,
                            **mock_data.StaticGraph.FirstPalletU.fifth_ply,
                        },
                        "forcedPlies": {},
                        "removedPlies": {}
                    }),
                    laser_out(payload=mock_data.LaserFeedbacks.CorrectlyPlacedPlies.FirstPalletU.sixth_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.FirstPalletU.seventh_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToNull.FirstPalletU.third_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToNull.FirstPalletU.fourth_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToNull.FirstPalletU.fifth_ply),
                    camera_out(
                        camera_ids={"cam1"},
                        command="start_capture",
                        refresh_interval=cfg.PASSIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                    camera_out(
                        camera_ids={"cam2", "cam3"},
                        command="start_capture",
                        refresh_interval=cfg.ACTIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                ]
            ),
            # 4 EV - the flow continuous...
            TestScenarioEntry(
                input_data=ev_message_in(
                    camera_id="cam2",
                    detected_edges={"U6.1", "U7.1", "U7.2"},
                    missing_edges={"U6.2"}
                ),
                etcd_outputs=[
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.sixth_ply_partially_covered_by_cam2),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.seventh_ply_placed_updated_by_cam2),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam2": {"detectedEdges": ["U6.1", "U7.1", "U7.2"]},
                        "cam3": {"detectedEdges": ["U6.1", "U7.1", "U7.2"]}},
                        session_cam_id="cam2",
                        layers=["layer_U"],
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_U": {"pallets": {"pallet_1": {"missingPlies": 0,
                                                                                       "placedPlies": 7,
                                                                                       "totalPlies": 7}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_U_1,
                        ],
                            session=ev_message_session("cam2")
                        ),
                        "correctlyPlacedPlies": {
                            **mock_data.StaticGraph.FirstPalletU.seventh_ply,
                        },
                        "pliesToBePlaced": {},
                        "newMissingPlies": {},
                        "noLongerMissingPlies": {
                            # TODO: known issue, not critical but would be nice if we could avoid unnecessary nulling
                            **mock_data.StaticGraph.FirstPalletU.sixth_ply,
                        },
                        "forcedPlies": {},
                        "removedPlies": {}
                    }),
                    laser_out(payload=mock_data.LaserFeedbacks.LastPliesPlaced.FirstPalletU.seventh_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToNull.FirstPalletU.sixth_ply),
                    camera_out(
                        camera_ids={"cam1", "cam2", "cam3"},
                        command="start_capture",
                        refresh_interval=cfg.PASSIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                ]
            ),
        ]
        return {
            "entries": entries,
            "initial_mould_state_plies_data": mould_state_plies_data([
                mock_data.MouldStatePlies.PalletU.first_ply_partially_covered,
                mock_data.MouldStatePlies.PalletU.second_ply_partially_covered,
                mock_data.MouldStatePlies.PalletU.third_ply_partially_covered,
                mock_data.MouldStatePlies.PalletU.fourth_ply_partially_covered,
                mock_data.MouldStatePlies.PalletU.fifth_ply_placed_update_by_cam2,
            ]),
            "graph_data": {
                "mould_id": "mould_id",
                "blade_revision": "blade_revision",
                "version": "v1.0.0",
                "plies": {
                    **mock_data.StaticGraph.FirstPalletU.first_ply,
                    **mock_data.StaticGraph.FirstPalletU.second_ply,
                    **mock_data.StaticGraph.FirstPalletU.third_ply,
                    **mock_data.StaticGraph.FirstPalletU.fourth_ply,
                    **mock_data.StaticGraph.FirstPalletU.fifth_ply,
                    **mock_data.StaticGraph.FirstPalletU.sixth_ply,
                    **mock_data.StaticGraph.FirstPalletU.seventh_ply,
                }
            },
        }

    @staticmethod
    def should_cover_multiple_plies_when_all_previous_plies_missing_before_new_ply_detected_by_same_cam():
        entries = [
            # TI 1
            TestScenarioEntry(
                input_data=add_team_instruction_c2dm_request(instruction=mock_data.TeamInstructions.pallet_U_1),
                etcd_outputs=[
                    etcd_instruction_out(instruction=mock_data.TeamInstructions.pallet_U_1),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.sixth_ply_expected),
                    etcd_mould_state_out(state=GlobalMouldState.PRODUCTION),
                    etcd_mould_blade_sn_out(blade_sn="blade_sn"),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam1": {"detectedEdges": ["U1.1", "U2.1"]},
                        "cam2": {"detectedEdges": ["U3.1", "U4.1", "U5.1", "U5.2"], "missingEdges": ["U6.1", "U6.2"]},
                        "cam3": {"detectedEdges": ["U5.1", "U5.2"], "missingEdges": ["U6.1", "U6.2"]}},
                        layers=["layer_U"],
                    ),
                    camera_out(
                        camera_ids={"cam1"},
                        command="start_capture",
                        refresh_interval=cfg.PASSIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                    camera_out(
                        camera_ids={"cam2", "cam3"},
                        command="start_capture",
                        refresh_interval=cfg.ACTIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_U": {"pallets": {"pallet_1": {"missingPlies": 0,
                                                                                       "placedPlies": 5,
                                                                                       "totalPlies": 7}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_U_1,
                        ]),
                        "correctlyPlacedPlies": {},
                        "pliesToBePlaced": {
                            **mock_data.StaticGraph.FirstPalletU.sixth_ply,
                        },
                        "newMissingPlies": {},
                        "noLongerMissingPlies": {},
                        "forcedPlies": {},
                        "removedPlies": {}
                    }),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.FirstPalletU.sixth_ply),
                ]
            ),
            # 2 on EV multiple plies missing due being covered
            TestScenarioEntry(
                input_data=ev_message_in(
                    camera_id="cam1",
                    detected_edges=set(),
                    missing_edges={"U1.1", "U2.1"},
                ),
                etcd_outputs=[
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.first_ply_missing_due_being_covered),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.second_ply_missing_due_being_covered),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.sixth_ply_expected),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam1": {"missingEdges": ["U1.1", "U2.1"]},
                        "cam2": {"detectedEdges": ["U3.1", "U4.1", "U5.1", "U5.2"],
                                 "missingEdges": ["U6.1", "U6.2"]},
                        "cam3": {"detectedEdges": ["U5.1", "U5.2"],
                                 "missingEdges": ["U6.1", "U6.2"]}},
                        session_cam_id="cam1",
                        layers=["layer_U"],
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_U": {"pallets": {"pallet_1": {"missingPlies": 2,
                                                                                       "placedPlies": 5,
                                                                                       "totalPlies": 7}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_U_1,
                        ],
                            session=ev_message_session("cam1")
                        ),
                        "correctlyPlacedPlies": {
                        },
                        "pliesToBePlaced": {
                            **mock_data.StaticGraph.FirstPalletU.sixth_ply,
                        },
                        "newMissingPlies": {
                            **mock_data.StaticGraph.FirstPalletU.first_ply,
                            **mock_data.StaticGraph.FirstPalletU.second_ply,
                        },
                        "noLongerMissingPlies": {},
                        "forcedPlies": {},
                        "removedPlies": {}
                    }),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.FirstPalletU.sixth_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.MissingPlies.FirstPalletU.first_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.MissingPlies.FirstPalletU.second_ply),
                    camera_out(
                        camera_ids={"cam1", "cam2", "cam3"},
                        command="start_capture",
                        refresh_interval=cfg.ACTIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                ]
            ),
            # 3 on EV multiple plies missing due being covered
            TestScenarioEntry(
                input_data=ev_message_in(
                    camera_id="cam2",
                    detected_edges=set(),
                    missing_edges={"U3.1", "U4.1", "U5.1", "U5.2", "U6.1", "U6.2"},
                ),
                etcd_outputs=[
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.third_ply_missing_due_being_covered),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.fourth_ply_missing_due_being_covered),
                    etcd_ply_out(
                        ply=mock_data.MouldStatePlies.PalletU.fifth_ply_missing_due_being_covered_update_by_cam2),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.sixth_ply_expected),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam1": {"missingEdges": ["U1.1", "U2.1"]},
                        "cam2": {"missingEdges": ["U3.1",
                                                  "U4.1",
                                                  "U5.1",
                                                  "U5.2",
                                                  "U6.1",
                                                  "U6.2"]},
                        "cam3": {"missingEdges": ["U5.1", "U5.2", "U6.1", "U6.2"]}},
                        session_cam_id="cam2",
                        layers=["layer_U"],
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_U": {"pallets": {"pallet_1": {"missingPlies": 5,
                                                                                       "placedPlies": 5,
                                                                                       "totalPlies": 7}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_U_1,
                        ],
                            session=ev_message_session("cam2")
                        ),
                        "correctlyPlacedPlies": {
                        },
                        "pliesToBePlaced": {
                            **mock_data.StaticGraph.FirstPalletU.sixth_ply,
                        },
                        "newMissingPlies": {
                            **mock_data.StaticGraph.FirstPalletU.third_ply,
                            **mock_data.StaticGraph.FirstPalletU.fourth_ply,
                            **mock_data.StaticGraph.FirstPalletU.fifth_ply,
                        },
                        "noLongerMissingPlies": {},
                        "forcedPlies": {},
                        "removedPlies": {}
                    }),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.FirstPalletU.sixth_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.MissingPlies.FirstPalletU.third_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.MissingPlies.FirstPalletU.fourth_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.MissingPlies.FirstPalletU.fifth_ply),
                    camera_out(
                        camera_ids={"cam1", "cam2", "cam3"},
                        command="start_capture",
                        refresh_interval=cfg.ACTIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                ]
            ),
            # 4 on EV msg sixth ply fully covers multiple missing plies
            TestScenarioEntry(
                input_data=ev_message_in(
                    camera_id="cam2",
                    detected_edges={"U6.1", "U6.2"},
                    missing_edges={"U3.1", "U4.1", "U5.1", "U5.2"},
                ),
                etcd_outputs=[
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.first_ply_fully_covered_by_U6_on_missing),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.second_ply_fully_covered_by_U6_on_missing),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.third_ply_fully_covered_by_U6_on_missing),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.fourth_ply_fully_covered_by_U6_on_missing),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.fifth_ply_fully_covered_by_U6_on_missing),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.sixth_ply_placed_by_cam2),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.seventh_ply_expected),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam2": {"detectedEdges": ["U6.1", "U6.2"],
                                 "missingEdges": ["U7.1", "U7.2"]},
                        "cam3": {"detectedEdges": ["U6.1", "U6.2"],
                                 "missingEdges": ["U7.1", "U7.2"]}},
                        session_cam_id="cam2",
                        layers=["layer_U"],
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_U": {"pallets": {"pallet_1": {"missingPlies": 0,
                                                                                       "placedPlies": 6,
                                                                                       "totalPlies": 7}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_U_1,
                        ],
                            session=ev_message_session("cam2")
                        ),
                        "correctlyPlacedPlies": {
                            **mock_data.StaticGraph.FirstPalletU.sixth_ply,
                        },
                        "pliesToBePlaced": {
                            **mock_data.StaticGraph.FirstPalletU.seventh_ply,
                        },
                        "newMissingPlies": {},
                        "noLongerMissingPlies": {
                            **mock_data.StaticGraph.FirstPalletU.first_ply,
                            **mock_data.StaticGraph.FirstPalletU.second_ply,
                            **mock_data.StaticGraph.FirstPalletU.third_ply,
                            **mock_data.StaticGraph.FirstPalletU.fourth_ply,
                            **mock_data.StaticGraph.FirstPalletU.fifth_ply,
                        },
                        "forcedPlies": {},
                        "removedPlies": {}
                    }),
                    laser_out(payload=mock_data.LaserFeedbacks.CorrectlyPlacedPlies.FirstPalletU.sixth_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.FirstPalletU.seventh_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToNull.FirstPalletU.first_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToNull.FirstPalletU.second_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToNull.FirstPalletU.third_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToNull.FirstPalletU.fourth_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToNull.FirstPalletU.fifth_ply),
                    camera_out(
                        camera_ids={"cam1"},
                        command="start_capture",
                        refresh_interval=cfg.PASSIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                    camera_out(
                        camera_ids={"cam2", "cam3"},
                        command="start_capture",
                        refresh_interval=cfg.ACTIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                ]
            ),
            # 5 EV - the flow continuous...
            TestScenarioEntry(
                input_data=ev_message_in(
                    camera_id="cam2",
                    detected_edges={"U6.1", "U7.1", "U7.2"},
                    missing_edges={"U6.2"}
                ),
                etcd_outputs=[
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.sixth_ply_partially_covered_by_cam2),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.seventh_ply_placed_updated_by_cam2),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam2": {"detectedEdges": ["U6.1", "U7.1", "U7.2"]},
                        "cam3": {"detectedEdges": ["U6.1", "U7.1", "U7.2"]}},
                        session_cam_id="cam2",
                        layers=["layer_U"],
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_U": {"pallets": {"pallet_1": {"missingPlies": 0,
                                                                                       "placedPlies": 7,
                                                                                       "totalPlies": 7}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_U_1,
                        ],
                            session=ev_message_session("cam2")
                        ),
                        "correctlyPlacedPlies": {
                            **mock_data.StaticGraph.FirstPalletU.seventh_ply,
                        },
                        "pliesToBePlaced": {},
                        "newMissingPlies": {},
                        "noLongerMissingPlies": {
                            # TODO: known issue, not critical but would be nice if we could avoid unnecessary nulling
                            **mock_data.StaticGraph.FirstPalletU.sixth_ply,
                        },
                        "forcedPlies": {},
                        "removedPlies": {}
                    }),
                    laser_out(payload=mock_data.LaserFeedbacks.LastPliesPlaced.FirstPalletU.seventh_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToNull.FirstPalletU.sixth_ply),
                    camera_out(
                        camera_ids={"cam1", "cam2", "cam3"},
                        command="start_capture",
                        refresh_interval=cfg.PASSIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                ]
            ),
        ]
        return {
            "entries": entries,
            "initial_mould_state_plies_data": mould_state_plies_data([
                mock_data.MouldStatePlies.PalletU.first_ply_partially_covered,
                mock_data.MouldStatePlies.PalletU.second_ply_partially_covered,
                mock_data.MouldStatePlies.PalletU.third_ply_partially_covered,
                mock_data.MouldStatePlies.PalletU.fourth_ply_partially_covered,
                mock_data.MouldStatePlies.PalletU.fifth_ply_placed_update_by_cam2,
            ]),
            "graph_data": {
                "mould_id": "mould_id",
                "blade_revision": "blade_revision",
                "version": "v1.0.0",
                "plies": {
                    **mock_data.StaticGraph.FirstPalletU.first_ply,
                    **mock_data.StaticGraph.FirstPalletU.second_ply,
                    **mock_data.StaticGraph.FirstPalletU.third_ply,
                    **mock_data.StaticGraph.FirstPalletU.fourth_ply,
                    **mock_data.StaticGraph.FirstPalletU.fifth_ply,
                    **mock_data.StaticGraph.FirstPalletU.sixth_ply,
                    **mock_data.StaticGraph.FirstPalletU.seventh_ply,
                }
            },
        }

    @staticmethod
    def should_cover_multiple_plies_when_multiple_plies_missing_before_new_ply_detected_by_different_cam():
        entries = [
            # TI 1
            TestScenarioEntry(
                input_data=add_team_instruction_c2dm_request(instruction=mock_data.TeamInstructions.pallet_U_1),
                etcd_outputs=[
                    etcd_instruction_out(instruction=mock_data.TeamInstructions.pallet_U_1),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.sixth_ply_expected),
                    etcd_mould_state_out(state=GlobalMouldState.PRODUCTION),
                    etcd_mould_blade_sn_out(blade_sn="blade_sn"),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam1": {"detectedEdges": ["U1.1", "U2.1"]},
                        "cam2": {"detectedEdges": ["U3.1", "U4.1", "U5.1", "U5.2"],
                                 "missingEdges": ["U6.1", "U6.2"]},
                        "cam3": {"detectedEdges": ["U5.1", "U5.2"],
                                 "missingEdges": ["U6.1", "U6.2"]}},
                        layers=["layer_U"],
                    ),
                    camera_out(
                        camera_ids={"cam1"},
                        command="start_capture",
                        refresh_interval=cfg.PASSIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                    camera_out(
                        camera_ids={"cam2", "cam3"},
                        command="start_capture",
                        refresh_interval=cfg.ACTIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_U": {"pallets": {"pallet_1": {"missingPlies": 0,
                                                                                       "placedPlies": 5,
                                                                                       "totalPlies": 7}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_U_1,
                        ]),
                        "correctlyPlacedPlies": {},
                        "pliesToBePlaced": {
                            **mock_data.StaticGraph.FirstPalletU.sixth_ply,
                        },
                        "newMissingPlies": {},
                        "noLongerMissingPlies": {},
                        "forcedPlies": {},
                        "removedPlies": {}
                    }),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.FirstPalletU.sixth_ply),
                ]
            ),
            # 2 on EV multiple plies missing due being covered (except fifth ply which is still detected by other cam)
            TestScenarioEntry(
                input_data=ev_message_in(
                    camera_id="cam2",
                    detected_edges=set(),
                    missing_edges={"U3.1", "U4.1", "U5.1", "U5.2", "U6.1", "U6.2"},
                ),
                etcd_outputs=[
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.third_ply_missing_due_being_covered),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.fourth_ply_missing_due_being_covered),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.sixth_ply_expected),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam1": {"detectedEdges": ["U1.1", "U2.1"]},
                        "cam2": {"detectedEdges": ["U5.1", "U5.2"],
                                 "missingEdges": ["U3.1", "U4.1", "U6.1", "U6.2"]},
                        "cam3": {"detectedEdges": ["U5.1", "U5.2"],
                                 "missingEdges": ["U6.1", "U6.2"]}},
                        session_cam_id="cam2",
                        layers=["layer_U"],
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_U": {"pallets": {"pallet_1": {"missingPlies": 2,
                                                                                       "placedPlies": 5,
                                                                                       "totalPlies": 7}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_U_1,
                        ],
                            session=ev_message_session("cam2")
                        ),
                        "correctlyPlacedPlies": {
                        },
                        "pliesToBePlaced": {
                            **mock_data.StaticGraph.FirstPalletU.sixth_ply,
                        },
                        "newMissingPlies": {
                            **mock_data.StaticGraph.FirstPalletU.third_ply,
                            **mock_data.StaticGraph.FirstPalletU.fourth_ply,
                        },
                        "noLongerMissingPlies": {},
                        "forcedPlies": {},
                        "removedPlies": {}
                    }),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.FirstPalletU.sixth_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.MissingPlies.FirstPalletU.third_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.MissingPlies.FirstPalletU.fourth_ply),
                    camera_out(
                        camera_ids={"cam1"},
                        command="start_capture",
                        refresh_interval=cfg.PASSIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                    camera_out(
                        camera_ids={"cam2", "cam3"},
                        command="start_capture",
                        refresh_interval=cfg.ACTIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                ]
            ),
            # 3 on EV fifth ply becomes missing because both cameras now can"t see it
            TestScenarioEntry(
                input_data=ev_message_in(
                    camera_id="cam3",
                    detected_edges=set(),
                    missing_edges={"U5.1", "U5.2", "U6.1", "U6.2"},
                ),
                etcd_outputs=[
                    etcd_ply_out(
                        ply=mock_data.MouldStatePlies.PalletU.fifth_ply_missing_due_being_covered_update_by_cam3),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.sixth_ply_expected),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam1": {"detectedEdges": ["U1.1", "U2.1"]},
                        "cam2": {"missingEdges": ["U3.1",
                                                  "U4.1",
                                                  "U5.1",
                                                  "U5.2",
                                                  "U6.1",
                                                  "U6.2"]},
                        "cam3": {"missingEdges": ["U5.1", "U5.2", "U6.1", "U6.2"]}},
                        session_cam_id="cam3",
                        layers=["layer_U"],
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_U": {"pallets": {"pallet_1": {"missingPlies": 3,
                                                                                       "placedPlies": 5,
                                                                                       "totalPlies": 7}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_U_1,
                        ],
                            session=ev_message_session("cam3")
                        ),
                        "correctlyPlacedPlies": {
                        },
                        "pliesToBePlaced": {
                            **mock_data.StaticGraph.FirstPalletU.sixth_ply,
                        },
                        "newMissingPlies": {
                            **mock_data.StaticGraph.FirstPalletU.fifth_ply,
                        },
                        "noLongerMissingPlies": {},
                        "forcedPlies": {},
                        "removedPlies": {}
                    }),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.FirstPalletU.sixth_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.MissingPlies.FirstPalletU.fifth_ply),
                    camera_out(
                        camera_ids={"cam1"},
                        command="start_capture",
                        refresh_interval=cfg.PASSIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                    camera_out(
                        camera_ids={"cam2", "cam3"},
                        command="start_capture",
                        refresh_interval=cfg.ACTIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                ]
            ),
            # 4 on EV msg sixth ply detected by different cam and fully covers multiple missing plies
            TestScenarioEntry(
                input_data=ev_message_in(
                    camera_id="cam3",
                    detected_edges={"U6.1", "U6.2"},
                    missing_edges={"U5.1", "U5.2"},
                ),
                etcd_outputs=[
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.first_ply_fully_covered_by_U6),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.second_ply_fully_covered_by_U6),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.third_ply_fully_covered_by_U6_on_missing),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.fourth_ply_fully_covered_by_U6_on_missing),
                    etcd_ply_out(
                        ply=mock_data.MouldStatePlies.PalletU.fifth_ply_fully_covered_by_U6_on_missing_by_both_cams),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.sixth_ply_placed_by_cam3),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.seventh_ply_expected),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam2": {"detectedEdges": ["U6.1", "U6.2"],
                                 "missingEdges": ["U7.1", "U7.2"]},
                        "cam3": {"detectedEdges": ["U6.1", "U6.2"],
                                 "missingEdges": ["U7.1", "U7.2"]}},
                        session_cam_id="cam3",
                        layers=["layer_U"],
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_U": {"pallets": {"pallet_1": {"missingPlies": 0,
                                                                                       "placedPlies": 6,
                                                                                       "totalPlies": 7}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_U_1,
                        ],
                            session=ev_message_session("cam3")
                        ),
                        "correctlyPlacedPlies": {
                            **mock_data.StaticGraph.FirstPalletU.sixth_ply,
                        },
                        "pliesToBePlaced": {
                            **mock_data.StaticGraph.FirstPalletU.seventh_ply,
                        },
                        "newMissingPlies": {},
                        "noLongerMissingPlies": {
                            **mock_data.StaticGraph.FirstPalletU.third_ply,
                            **mock_data.StaticGraph.FirstPalletU.fourth_ply,
                            **mock_data.StaticGraph.FirstPalletU.fifth_ply,
                        },
                        "forcedPlies": {},
                        "removedPlies": {}
                    }),
                    laser_out(payload=mock_data.LaserFeedbacks.CorrectlyPlacedPlies.FirstPalletU.sixth_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.FirstPalletU.seventh_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToNull.FirstPalletU.third_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToNull.FirstPalletU.fourth_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToNull.FirstPalletU.fifth_ply),
                    camera_out(
                        camera_ids={"cam1"},
                        command="start_capture",
                        refresh_interval=cfg.PASSIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                    camera_out(
                        camera_ids={"cam2", "cam3"},
                        command="start_capture",
                        refresh_interval=cfg.ACTIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                ]
            ),
            # 5 EV - the flow continuous...
            TestScenarioEntry(
                input_data=ev_message_in(
                    camera_id="cam3",
                    detected_edges={"U6.1", "U7.1", "U7.2"},
                    missing_edges={"U6.2"}
                ),
                etcd_outputs=[
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.sixth_ply_partially_covered_by_cam3),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.seventh_ply_placed_updated_by_cam3),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam2": {"detectedEdges": ["U6.1", "U7.1", "U7.2"]},
                        "cam3": {"detectedEdges": ["U6.1", "U7.1", "U7.2"]}},
                        session_cam_id="cam3",
                        layers=["layer_U"],
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_U": {"pallets": {"pallet_1": {"missingPlies": 0,
                                                                                       "placedPlies": 7,
                                                                                       "totalPlies": 7}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_U_1,
                        ],
                            session=ev_message_session("cam3")
                        ),
                        "correctlyPlacedPlies": {
                            **mock_data.StaticGraph.FirstPalletU.seventh_ply,
                        },
                        "pliesToBePlaced": {},
                        "newMissingPlies": {},
                        "noLongerMissingPlies": {
                            # TODO: known issue, not critical but would be nice if we could avoid unnecessary nulling
                            **mock_data.StaticGraph.FirstPalletU.sixth_ply,
                        },
                        "forcedPlies": {},
                        "removedPlies": {}
                    }),
                    laser_out(payload=mock_data.LaserFeedbacks.LastPliesPlaced.FirstPalletU.seventh_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToNull.FirstPalletU.sixth_ply),
                    camera_out(
                        camera_ids={"cam1", "cam2", "cam3"},
                        command="start_capture",
                        refresh_interval=cfg.PASSIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                ]
            ),
        ]
        return {
            "entries": entries,
            "initial_mould_state_plies_data": mould_state_plies_data([
                mock_data.MouldStatePlies.PalletU.first_ply_partially_covered,
                mock_data.MouldStatePlies.PalletU.second_ply_partially_covered,
                mock_data.MouldStatePlies.PalletU.third_ply_partially_covered,
                mock_data.MouldStatePlies.PalletU.fourth_ply_partially_covered,
                mock_data.MouldStatePlies.PalletU.fifth_ply_placed,
            ]),
            "graph_data": {
                "mould_id": "mould_id",
                "blade_revision": "blade_revision",
                "version": "v1.0.0",
                "plies": {
                    **mock_data.StaticGraph.FirstPalletU.first_ply,
                    **mock_data.StaticGraph.FirstPalletU.second_ply,
                    **mock_data.StaticGraph.FirstPalletU.third_ply,
                    **mock_data.StaticGraph.FirstPalletU.fourth_ply,
                    **mock_data.StaticGraph.FirstPalletU.fifth_ply,
                    **mock_data.StaticGraph.FirstPalletU.sixth_ply,
                    **mock_data.StaticGraph.FirstPalletU.seventh_ply,
                }
            },
        }

    @staticmethod
    def should_cover_multiple_plies_when_multiple_plies_missing_before_new_ply_detected_by_other_cam():
        entries = [
            # TI 1
            TestScenarioEntry(
                input_data=add_team_instruction_c2dm_request(instruction=mock_data.TeamInstructions.pallet_U_1),
                etcd_outputs=[
                    etcd_instruction_out(instruction=mock_data.TeamInstructions.pallet_U_1),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.sixth_ply_expected),
                    etcd_mould_state_out(state=GlobalMouldState.PRODUCTION),
                    etcd_mould_blade_sn_out(blade_sn="blade_sn"),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam1": {"detectedEdges": ["U1.1", "U2.1"]},
                        "cam2": {"detectedEdges": ["U3.1", "U4.1", "U5.1", "U5.2"],
                                 "missingEdges": ["U6.1", "U6.2"]},
                        "cam3": {"detectedEdges": ["U5.1", "U5.2"],
                                 "missingEdges": ["U6.1", "U6.2"]}},
                        layers=["layer_U"],
                    ),
                    camera_out(
                        camera_ids={"cam1"},
                        command="start_capture",
                        refresh_interval=cfg.PASSIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                    camera_out(
                        camera_ids={"cam2", "cam3"},
                        command="start_capture",
                        refresh_interval=cfg.ACTIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_U": {"pallets": {"pallet_1": {"missingPlies": 0,
                                                                                       "placedPlies": 5,
                                                                                       "totalPlies": 7}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_U_1,
                        ]),
                        "correctlyPlacedPlies": {},
                        "pliesToBePlaced": {
                            **mock_data.StaticGraph.FirstPalletU.sixth_ply,
                        },
                        "newMissingPlies": {},
                        "noLongerMissingPlies": {},
                        "forcedPlies": {},
                        "removedPlies": {}
                    }),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.FirstPalletU.sixth_ply),
                ]
            ),
            # 2 on EV multiple plies missing due being covered
            TestScenarioEntry(
                input_data=ev_message_in(
                    camera_id="cam2",
                    detected_edges=set(),
                    missing_edges={"U3.1", "U4.1", "U5.1", "U5.2", "U6.1", "U6.2"},
                ),
                etcd_outputs=[
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.third_ply_missing_due_being_covered),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.fourth_ply_missing_due_being_covered),
                    etcd_ply_out(
                        ply=mock_data.MouldStatePlies.PalletU.fifth_ply_missing_due_being_covered_update_by_cam2),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.sixth_ply_expected),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam1": {"detectedEdges": ["U1.1", "U2.1"]},
                        "cam2": {"missingEdges": ["U3.1",
                                                  "U4.1",
                                                  "U5.1",
                                                  "U5.2",
                                                  "U6.1",
                                                  "U6.2"]},
                        "cam3": {"missingEdges": ["U5.1", "U5.2", "U6.1", "U6.2"]}},
                        session_cam_id="cam2",
                        layers=["layer_U"],
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_U": {"pallets": {"pallet_1": {"missingPlies": 3,
                                                                                       "placedPlies": 5,
                                                                                       "totalPlies": 7}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_U_1,
                        ],
                            session=ev_message_session("cam2")
                        ),
                        "correctlyPlacedPlies": {
                        },
                        "pliesToBePlaced": {
                            **mock_data.StaticGraph.FirstPalletU.sixth_ply,
                        },
                        "newMissingPlies": {
                            **mock_data.StaticGraph.FirstPalletU.third_ply,
                            **mock_data.StaticGraph.FirstPalletU.fourth_ply,
                            **mock_data.StaticGraph.FirstPalletU.fifth_ply,
                        },
                        "noLongerMissingPlies": {},
                        "forcedPlies": {},
                        "removedPlies": {}
                    }),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.FirstPalletU.sixth_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.MissingPlies.FirstPalletU.third_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.MissingPlies.FirstPalletU.fourth_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.MissingPlies.FirstPalletU.fifth_ply),
                    camera_out(
                        camera_ids={"cam1"},
                        command="start_capture",
                        refresh_interval=cfg.PASSIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                    camera_out(
                        camera_ids={"cam2", "cam3"},
                        command="start_capture",
                        refresh_interval=cfg.ACTIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                ]
            ),
            # 3 on EV msg sixth ply fully covers multiple missing plies
            TestScenarioEntry(
                input_data=ev_message_in(
                    camera_id="cam3",
                    detected_edges={"U6.1", "U6.2"},
                    missing_edges={"U5.1", "U5.2"},
                ),
                etcd_outputs=[
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.first_ply_fully_covered_by_U6),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.second_ply_fully_covered_by_U6),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.third_ply_fully_covered_by_U6_on_missing),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.fourth_ply_fully_covered_by_U6_on_missing),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.fifth_ply_fully_covered_by_U6_on_missing),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.sixth_ply_placed_by_cam3),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.seventh_ply_expected),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam2": {"detectedEdges": ["U6.1", "U6.2"],
                                 "missingEdges": ["U7.1", "U7.2"]},
                        "cam3": {"detectedEdges": ["U6.1", "U6.2"],
                                 "missingEdges": ["U7.1", "U7.2"]}},
                        session_cam_id="cam3",
                        layers=["layer_U"],
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_U": {"pallets": {"pallet_1": {"missingPlies": 0,
                                                                                       "placedPlies": 6,
                                                                                       "totalPlies": 7}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_U_1,
                        ],
                            session=ev_message_session("cam3")
                        ),
                        "correctlyPlacedPlies": {
                            **mock_data.StaticGraph.FirstPalletU.sixth_ply,
                        },
                        "pliesToBePlaced": {
                            **mock_data.StaticGraph.FirstPalletU.seventh_ply,
                        },
                        "newMissingPlies": {},
                        "noLongerMissingPlies": {
                            **mock_data.StaticGraph.FirstPalletU.third_ply,
                            **mock_data.StaticGraph.FirstPalletU.fourth_ply,
                            **mock_data.StaticGraph.FirstPalletU.fifth_ply,
                        },
                        "forcedPlies": {},
                        "removedPlies": {}
                    }),
                    laser_out(payload=mock_data.LaserFeedbacks.CorrectlyPlacedPlies.FirstPalletU.sixth_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.FirstPalletU.seventh_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToNull.FirstPalletU.third_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToNull.FirstPalletU.fourth_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToNull.FirstPalletU.fifth_ply),
                    camera_out(
                        camera_ids={"cam1"},
                        command="start_capture",
                        refresh_interval=cfg.PASSIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                    camera_out(
                        camera_ids={"cam2", "cam3"},
                        command="start_capture",
                        refresh_interval=cfg.ACTIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                ]
            ),
            # 4 EV - the flow continuous...
            TestScenarioEntry(
                input_data=ev_message_in(
                    camera_id="cam3",
                    detected_edges={"U6.1", "U7.1", "U7.2"},
                    missing_edges={"U6.2"}
                ),
                etcd_outputs=[
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.sixth_ply_partially_covered_by_cam3),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.seventh_ply_placed_updated_by_cam3),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam2": {"detectedEdges": ["U6.1", "U7.1", "U7.2"]},
                        "cam3": {"detectedEdges": ["U6.1", "U7.1", "U7.2"]}},
                        session_cam_id="cam3",
                        layers=["layer_U"],
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_U": {"pallets": {"pallet_1": {"missingPlies": 0,
                                                                                       "placedPlies": 7,
                                                                                       "totalPlies": 7}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_U_1,
                        ],
                            session=ev_message_session("cam3")
                        ),
                        "correctlyPlacedPlies": {
                            **mock_data.StaticGraph.FirstPalletU.seventh_ply,
                        },
                        "pliesToBePlaced": {},
                        "newMissingPlies": {},
                        "noLongerMissingPlies": {
                            # TODO: known issue, not critical but would be nice if we could avoid unnecessary nulling
                            **mock_data.StaticGraph.FirstPalletU.sixth_ply,
                        },
                        "forcedPlies": {},
                        "removedPlies": {}
                    }),
                    laser_out(payload=mock_data.LaserFeedbacks.LastPliesPlaced.FirstPalletU.seventh_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToNull.FirstPalletU.sixth_ply),
                    camera_out(
                        camera_ids={"cam1", "cam2", "cam3"},
                        command="start_capture",
                        refresh_interval=cfg.PASSIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                ]
            ),
        ]
        return {
            "entries": entries,
            "initial_mould_state_plies_data": mould_state_plies_data([
                mock_data.MouldStatePlies.PalletU.first_ply_partially_covered,
                mock_data.MouldStatePlies.PalletU.second_ply_partially_covered,
                mock_data.MouldStatePlies.PalletU.third_ply_partially_covered,
                mock_data.MouldStatePlies.PalletU.fourth_ply_partially_covered,
                mock_data.MouldStatePlies.PalletU.fifth_ply_placed_update_by_cam2,
            ]),
            "graph_data": {
                "mould_id": "mould_id",
                "blade_revision": "blade_revision",
                "version": "v1.0.0",
                "plies": {
                    **mock_data.StaticGraph.FirstPalletU.first_ply,
                    **mock_data.StaticGraph.FirstPalletU.second_ply,
                    **mock_data.StaticGraph.FirstPalletU.third_ply,
                    **mock_data.StaticGraph.FirstPalletU.fourth_ply,
                    **mock_data.StaticGraph.FirstPalletU.fifth_ply,
                    **mock_data.StaticGraph.FirstPalletU.sixth_ply,
                    **mock_data.StaticGraph.FirstPalletU.seventh_ply,
                }
            },
        }

    @staticmethod
    def should_cover_multiple_plies_when_multiple_plies_missing_before_phantom_ply_forced():
        entries = [
            # TI 1
            TestScenarioEntry(
                input_data=add_team_instruction_c2dm_request(instruction=mock_data.TeamInstructions.pallet_U_1),
                etcd_outputs=[
                    etcd_instruction_out(instruction=mock_data.TeamInstructions.pallet_U_1),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.sixth_ply_phantom_expected),
                    etcd_mould_state_out(state=GlobalMouldState.PRODUCTION),
                    etcd_mould_blade_sn_out(blade_sn="blade_sn"),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam1": {"detectedEdges": ["U2.1"]},
                        "cam2": {"detectedEdges": ["U3.1", "U4.1", "U5.1", "U5.2"]},
                        "cam3": {"detectedEdges": ["U5.1", "U5.2"]}},
                        layers=["layer_U"],
                    ),
                    camera_out(
                        camera_ids={"cam1", "cam2", "cam3"},
                        command="start_capture",
                        refresh_interval=cfg.PASSIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_U": {"pallets": {"pallet_1": {"missingPlies": 0,
                                                                                       "placedPlies": 5,
                                                                                       "totalPlies": 7}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_U_1,
                        ]),
                        "correctlyPlacedPlies": {},
                        "pliesToBePlaced": {
                            **mock_data.StaticGraph.FirstPalletU.sixth_ply_phantom,
                        },
                        "newMissingPlies": {},
                        "noLongerMissingPlies": {},
                        "forcedPlies": {},
                        "removedPlies": {}
                    }),
                    laser_out(payload=mock_data.LaserFeedbacks.PhantomPlies.FirstPalletU.sixth_ply),
                ]
            ),
            # 2 on EV multiple plies missing due being covered
            TestScenarioEntry(
                input_data=ev_message_in(
                    camera_id="cam2",
                    detected_edges=set(),
                    missing_edges={"U3.1", "U4.1", "U5.1", "U5.2"},
                ),
                etcd_outputs=[
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.third_ply_missing_due_being_covered),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.fourth_ply_missing_due_being_covered),
                    etcd_ply_out(
                        ply=mock_data.MouldStatePlies.PalletU.fifth_ply_missing_due_being_covered_update_by_cam2),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.sixth_ply_phantom_expected),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam1": {"detectedEdges": ["U2.1"]},
                        "cam2": {"missingEdges": ["U3.1", "U4.1", "U5.1", "U5.2"]},
                        "cam3": {"missingEdges": ["U5.1", "U5.2"]}},
                        session_cam_id="cam2",
                        layers=["layer_U"],
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_U": {"pallets": {"pallet_1": {"missingPlies": 3,
                                                                                       "placedPlies": 5,
                                                                                       "totalPlies": 7}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_U_1,
                        ],
                            session=ev_message_session("cam2")
                        ),
                        "correctlyPlacedPlies": {
                        },
                        "pliesToBePlaced": {
                            **mock_data.StaticGraph.FirstPalletU.sixth_ply_phantom,
                        },
                        "newMissingPlies": {
                            **mock_data.StaticGraph.FirstPalletU.third_ply,
                            **mock_data.StaticGraph.FirstPalletU.fourth_ply,
                            **mock_data.StaticGraph.FirstPalletU.fifth_ply,
                        },
                        "noLongerMissingPlies": {},
                        "forcedPlies": {},
                        "removedPlies": {}
                    }),
                    laser_out(payload=mock_data.LaserFeedbacks.PhantomPlies.FirstPalletU.sixth_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.MissingPlies.FirstPalletU.third_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.MissingPlies.FirstPalletU.fourth_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.MissingPlies.FirstPalletU.fifth_ply),
                    camera_out(
                        camera_ids={"cam1"},
                        command="start_capture",
                        refresh_interval=cfg.PASSIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                    camera_out(
                        camera_ids={"cam2", "cam3"},
                        command="start_capture",
                        refresh_interval=cfg.ACTIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                ]
            ),
            # 3 force_ply command - sixth ply fully covers multiple missing plies
            TestScenarioEntry(
                input_data=force_ply_c2dm_request("U6"),
                etcd_outputs=[
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.second_ply_fully_covered_by_U6),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.third_ply_fully_covered_by_U6_on_missing),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.fourth_ply_fully_covered_by_U6_on_missing),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.fifth_ply_fully_covered_by_U6_on_missing),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.sixth_ply_phantom_forced_on_expected),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.seventh_ply_expected),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam2": {"missingEdges": ["U7.1", "U7.2"]},
                        "cam3": {"missingEdges": ["U7.1", "U7.2"]}},
                        session_cam_id=None,
                        layers=["layer_U"],
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_U": {"pallets": {"pallet_1": {"missingPlies": 0,
                                                                                       "placedPlies": 6,
                                                                                       "totalPlies": 7}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_U_1,
                        ]),
                        "correctlyPlacedPlies": {},
                        "pliesToBePlaced": {
                            **mock_data.StaticGraph.FirstPalletU.seventh_ply,
                        },
                        "newMissingPlies": {},
                        "noLongerMissingPlies": {
                            **mock_data.StaticGraph.FirstPalletU.third_ply,
                            **mock_data.StaticGraph.FirstPalletU.fourth_ply,
                            **mock_data.StaticGraph.FirstPalletU.fifth_ply,
                        },
                        "forcedPlies": {
                            **mock_data.StaticGraph.FirstPalletU.sixth_ply_phantom,
                        },
                        "removedPlies": {}
                    }),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.FirstPalletU.seventh_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToNull.FirstPalletU.third_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToNull.FirstPalletU.fourth_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToNull.FirstPalletU.fifth_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToNull.FirstPalletU.sixth_ply),
                    camera_out(
                        camera_ids={"cam1"},
                        command="start_capture",
                        refresh_interval=cfg.PASSIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                    camera_out(
                        camera_ids={"cam2", "cam3"},
                        command="start_capture",
                        refresh_interval=cfg.ACTIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                ]
            ),
            # 4 EV - the flow continuous...
            TestScenarioEntry(
                input_data=ev_message_in(
                    camera_id="cam2",
                    detected_edges={"U7.1", "U7.2"},
                    missing_edges=set()
                ),
                etcd_outputs=[
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.seventh_ply_placed_updated_by_cam2),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam2": {"detectedEdges": ["U7.1", "U7.2"]},
                        "cam3": {"detectedEdges": ["U7.1", "U7.2"]}},
                        session_cam_id="cam2",
                        layers=["layer_U"],
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_U": {"pallets": {"pallet_1": {"missingPlies": 0,
                                                                                       "placedPlies": 7,
                                                                                       "totalPlies": 7}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_U_1,
                        ],
                            session=ev_message_session("cam2")
                        ),
                        "correctlyPlacedPlies": {
                            **mock_data.StaticGraph.FirstPalletU.seventh_ply,
                        },
                        "pliesToBePlaced": {},
                        "newMissingPlies": {},
                        "noLongerMissingPlies": {},
                        "forcedPlies": {},
                        "removedPlies": {}
                    }),
                    laser_out(payload=mock_data.LaserFeedbacks.LastPliesPlaced.FirstPalletU.seventh_ply),
                    camera_out(
                        camera_ids={"cam1", "cam2", "cam3"},
                        command="start_capture",
                        refresh_interval=cfg.PASSIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                ]
            ),
        ]
        return {
            "entries": entries,
            "initial_mould_state_plies_data": mould_state_plies_data([
                mock_data.MouldStatePlies.PalletU.first_ply_phantom_forced_on_expected,
                mock_data.MouldStatePlies.PalletU.second_ply_partially_covered,
                mock_data.MouldStatePlies.PalletU.third_ply_partially_covered,
                mock_data.MouldStatePlies.PalletU.fourth_ply_partially_covered,
                mock_data.MouldStatePlies.PalletU.fifth_ply_placed_update_by_cam2,
            ]),
            "graph_data": {
                "mould_id": "mould_id",
                "blade_revision": "blade_revision",
                "version": "v1.0.0",
                "plies": {
                    **mock_data.StaticGraph.FirstPalletU.first_ply_phantom,
                    **mock_data.StaticGraph.FirstPalletU.second_ply,
                    **mock_data.StaticGraph.FirstPalletU.third_ply,
                    **mock_data.StaticGraph.FirstPalletU.fourth_ply,
                    **mock_data.StaticGraph.FirstPalletU.fifth_ply,
                    **mock_data.StaticGraph.FirstPalletU.sixth_ply_phantom,
                    **mock_data.StaticGraph.FirstPalletU.seventh_ply,
                }
            },
        }

    @staticmethod
    def should_cover_multiple_plies_when_all_previous_plies_missing_before_phantom_ply_forced():
        entries = [
            # TI 1
            TestScenarioEntry(
                input_data=add_team_instruction_c2dm_request(instruction=mock_data.TeamInstructions.pallet_U_1),
                etcd_outputs=[
                    etcd_instruction_out(instruction=mock_data.TeamInstructions.pallet_U_1),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.sixth_ply_phantom_expected),
                    etcd_mould_state_out(state=GlobalMouldState.PRODUCTION),
                    etcd_mould_blade_sn_out(blade_sn="blade_sn"),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam1": {"detectedEdges": ["U2.1"]},
                        "cam2": {"detectedEdges": ["U3.1", "U4.1", "U5.1", "U5.2"]},
                        "cam3": {"detectedEdges": ["U5.1", "U5.2"]}},
                        layers=["layer_U"],
                    ),
                    camera_out(
                        camera_ids={"cam1", "cam2", "cam3"},
                        command="start_capture",
                        refresh_interval=cfg.PASSIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_U": {"pallets": {"pallet_1": {"missingPlies": 0,
                                                                                       "placedPlies": 5,
                                                                                       "totalPlies": 7}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_U_1,
                        ]),
                        "correctlyPlacedPlies": {},
                        "pliesToBePlaced": {
                            **mock_data.StaticGraph.FirstPalletU.sixth_ply_phantom,
                        },
                        "newMissingPlies": {},
                        "noLongerMissingPlies": {},
                        "forcedPlies": {},
                        "removedPlies": {}
                    }),
                    laser_out(payload=mock_data.LaserFeedbacks.PhantomPlies.FirstPalletU.sixth_ply),
                ]
            ),
            # 2 on EV multiple plies missing due being covered
            TestScenarioEntry(
                input_data=ev_message_in(
                    camera_id="cam1",
                    detected_edges=set(),
                    missing_edges={"U2.1"},
                ),
                etcd_outputs=[
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.second_ply_missing_due_being_covered),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.sixth_ply_phantom_expected),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam1": {"missingEdges": ["U2.1"]},
                        "cam2": {"detectedEdges": ["U3.1", "U4.1", "U5.1", "U5.2"]},
                        "cam3": {"detectedEdges": ["U5.1", "U5.2"]}},
                        session_cam_id="cam1",
                        layers=["layer_U"],
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_U": {"pallets": {"pallet_1": {"missingPlies": 1,
                                                                                       "placedPlies": 5,
                                                                                       "totalPlies": 7}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_U_1,
                        ],
                            session=ev_message_session("cam1")
                        ),
                        "correctlyPlacedPlies": {
                        },
                        "pliesToBePlaced": {
                            **mock_data.StaticGraph.FirstPalletU.sixth_ply_phantom,
                        },
                        "newMissingPlies": {
                            **mock_data.StaticGraph.FirstPalletU.second_ply,
                        },
                        "noLongerMissingPlies": {},
                        "forcedPlies": {},
                        "removedPlies": {}
                    }),
                    laser_out(payload=mock_data.LaserFeedbacks.PhantomPlies.FirstPalletU.sixth_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.MissingPlies.FirstPalletU.second_ply),
                    camera_out(
                        camera_ids={"cam3"},
                        command="start_capture",
                        refresh_interval=cfg.PASSIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                    camera_out(
                        camera_ids={"cam2", "cam1"},
                        command="start_capture",
                        refresh_interval=cfg.ACTIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                ]
            ),
            # 3 on EV multiple plies missing due being covered
            TestScenarioEntry(
                input_data=ev_message_in(
                    camera_id="cam2",
                    detected_edges=set(),
                    missing_edges={"U3.1", "U4.1", "U5.1", "U5.2"},
                ),
                etcd_outputs=[
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.third_ply_missing_due_being_covered),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.fourth_ply_missing_due_being_covered),
                    etcd_ply_out(
                        ply=mock_data.MouldStatePlies.PalletU.fifth_ply_missing_due_being_covered_update_by_cam2),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.sixth_ply_phantom_expected),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam1": {"missingEdges": ["U2.1"]},
                        "cam2": {"missingEdges": ["U3.1", "U4.1", "U5.1", "U5.2"]},
                        "cam3": {"missingEdges": ["U5.1", "U5.2"]}},
                        session_cam_id="cam2",
                        layers=["layer_U"],
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_U": {"pallets": {"pallet_1": {"missingPlies": 4,
                                                                                       "placedPlies": 5,
                                                                                       "totalPlies": 7}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_U_1,
                        ],
                            session=ev_message_session("cam2")
                        ),
                        "correctlyPlacedPlies": {
                        },
                        "pliesToBePlaced": {
                            **mock_data.StaticGraph.FirstPalletU.sixth_ply_phantom,
                        },
                        "newMissingPlies": {
                            **mock_data.StaticGraph.FirstPalletU.third_ply,
                            **mock_data.StaticGraph.FirstPalletU.fourth_ply,
                            **mock_data.StaticGraph.FirstPalletU.fifth_ply,
                        },
                        "noLongerMissingPlies": {},
                        "forcedPlies": {},
                        "removedPlies": {}
                    }),
                    laser_out(payload=mock_data.LaserFeedbacks.PhantomPlies.FirstPalletU.sixth_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.MissingPlies.FirstPalletU.third_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.MissingPlies.FirstPalletU.fourth_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.MissingPlies.FirstPalletU.fifth_ply),
                    camera_out(
                        camera_ids={"cam1", "cam2", "cam3"},
                        command="start_capture",
                        refresh_interval=cfg.ACTIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                ]
            ),
            # 4 force_ply command - sixth ply fully covers multiple missing plies
            TestScenarioEntry(
                input_data=force_ply_c2dm_request("U6"),
                etcd_outputs=[
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.second_ply_fully_covered_by_U6_on_missing),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.third_ply_fully_covered_by_U6_on_missing),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.fourth_ply_fully_covered_by_U6_on_missing),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.fifth_ply_fully_covered_by_U6_on_missing),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.sixth_ply_phantom_forced_on_expected),
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.seventh_ply_expected),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam2": {"missingEdges": ["U7.1", "U7.2"]},
                        "cam3": {"missingEdges": ["U7.1", "U7.2"]}},
                        session_cam_id=None,
                        layers=["layer_U"],
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_U": {"pallets": {"pallet_1": {"missingPlies": 0,
                                                                                       "placedPlies": 6,
                                                                                       "totalPlies": 7}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_U_1,
                        ]),
                        "correctlyPlacedPlies": {},
                        "pliesToBePlaced": {
                            **mock_data.StaticGraph.FirstPalletU.seventh_ply,
                        },
                        "newMissingPlies": {},
                        "noLongerMissingPlies": {
                            **mock_data.StaticGraph.FirstPalletU.second_ply,
                            **mock_data.StaticGraph.FirstPalletU.third_ply,
                            **mock_data.StaticGraph.FirstPalletU.fourth_ply,
                            **mock_data.StaticGraph.FirstPalletU.fifth_ply,
                        },
                        "forcedPlies": {
                            **mock_data.StaticGraph.FirstPalletU.sixth_ply_phantom,
                        },
                        "removedPlies": {}
                    }),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToBePlaced.FirstPalletU.seventh_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToNull.FirstPalletU.second_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToNull.FirstPalletU.third_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToNull.FirstPalletU.fourth_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToNull.FirstPalletU.fifth_ply),
                    laser_out(payload=mock_data.LaserFeedbacks.PliesToNull.FirstPalletU.sixth_ply), camera_out(
                        camera_ids={"cam1"},
                        command="start_capture",
                        refresh_interval=cfg.PASSIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                    camera_out(
                        camera_ids={"cam2", "cam3"},
                        command="start_capture",
                        refresh_interval=cfg.ACTIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                ]
            ),
            # 5 EV - the flow continuous...
            TestScenarioEntry(
                input_data=ev_message_in(
                    camera_id="cam2",
                    detected_edges={"U7.1", "U7.2"},
                    missing_edges=set()
                ),
                etcd_outputs=[
                    etcd_ply_out(ply=mock_data.MouldStatePlies.PalletU.seventh_ply_placed_updated_by_cam2),
                ],
                messaging_outputs=[
                    edge_verification_out(camera_to_edges_to_verify={
                        "cam2": {"detectedEdges": ["U7.1", "U7.2"]},
                        "cam3": {"detectedEdges": ["U7.1", "U7.2"]}},
                        session_cam_id="cam2",
                        layers=["layer_U"],
                    ),
                    stats_out(payload={
                        "metadata": {"correlationId": "correlation_id",
                                     "hallId": "hall_id",
                                     "locationId": "location_id",
                                     "mouldId": "mould_id"},
                        "mouldState": {"layers": {"layer_U": {"pallets": {"pallet_1": {"missingPlies": 0,
                                                                                       "placedPlies": 7,
                                                                                       "totalPlies": 7}}}}}}
                    ),
                    trace_out(payload={
                        "metadata": trace_out_metadata(team_instructions=[
                            mock_data.TeamInstructions.pallet_U_1,
                        ],
                            session=ev_message_session("cam2")
                        ),
                        "correctlyPlacedPlies": {
                            **mock_data.StaticGraph.FirstPalletU.seventh_ply,
                        },
                        "pliesToBePlaced": {},
                        "newMissingPlies": {},
                        "noLongerMissingPlies": {},
                        "forcedPlies": {},
                        "removedPlies": {}
                    }),
                    laser_out(payload=mock_data.LaserFeedbacks.LastPliesPlaced.FirstPalletU.seventh_ply),
                    camera_out(
                        camera_ids={"cam2", "cam1", "cam3"},
                        command="start_capture",
                        refresh_interval=cfg.PASSIVE_EDGE_VERIFICATION_REFRESH_INTERVAL
                    ),
                ]
            ),
        ]
        return {
            "entries": entries,
            "initial_mould_state_plies_data": mould_state_plies_data([
                mock_data.MouldStatePlies.PalletU.first_ply_phantom_forced_on_expected,
                mock_data.MouldStatePlies.PalletU.second_ply_partially_covered,
                mock_data.MouldStatePlies.PalletU.third_ply_partially_covered,
                mock_data.MouldStatePlies.PalletU.fourth_ply_partially_covered,
                mock_data.MouldStatePlies.PalletU.fifth_ply_placed_update_by_cam2,
            ]),
            "graph_data": {
                "mould_id": "mould_id",
                "blade_revision": "blade_revision",
                "version": "v1.0.0",
                "plies": {
                    **mock_data.StaticGraph.FirstPalletU.first_ply_phantom,
                    **mock_data.StaticGraph.FirstPalletU.second_ply,
                    **mock_data.StaticGraph.FirstPalletU.third_ply,
                    **mock_data.StaticGraph.FirstPalletU.fourth_ply,
                    **mock_data.StaticGraph.FirstPalletU.fifth_ply,
                    **mock_data.StaticGraph.FirstPalletU.sixth_ply_phantom,
                    **mock_data.StaticGraph.FirstPalletU.seventh_ply,
                }
            },
        }
