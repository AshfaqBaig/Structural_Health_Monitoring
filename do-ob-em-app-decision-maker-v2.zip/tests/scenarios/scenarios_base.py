# pylint: disable=protected-access, missing-module-docstring, missing-class-docstring, missing-function-docstring, duplicate-code, line-too-long, too-few-public-methods, no-self-use, too-many-locals, too-many-lines
import json
from typing import Union

from azure.iot.device import Message, MethodRequest
from etcd3.events import PutEvent, DeleteEvent
from etcd3.watch import WatchResponse

from app import routes_constants
from app.global_mould_state_enum import GlobalMouldState
from app.models.state.ply_state import PlyState
from tests.scenarios.model.c2dm_response_output import C2DMResponseOutput
from tests.scenarios.model.etcd_output import EtcdOutput
from tests.scenarios.model.messaging_output import MessagingOutput
from tests.tests_base import create_add_team_instruction_c2dm_request, create_force_ply_c2dm_request, \
    create_finalise_c2dm_request, create_recheck_ply_c2dm_request, create_undo_ply_c2dm_request, \
    create_undo_plies_to_c2dm_request, create_undo_plies_to_dry_run_c2dm_request


def mould_state_instructions_data(instructions: list[dict] = None) -> dict:
    if instructions is None:
        return {}
    etcd_data = {}
    for instruction in instructions:
        pallet_id = instruction["palletId"]
        layer_id = instruction["layerId"]
        key = f"/moulds/mould_id/instructions/{layer_id}-{pallet_id}"
        value = instruction
        etcd_data.update({key: value})
    return etcd_data


def mould_state_plies_data(plies: list[PlyState] = None) -> dict:
    if plies is None:
        return {}
    etcd_data = {}
    for ply in plies:
        key = f"/moulds/mould_id/plies/{ply.id}"
        value = ply.serialize()
        etcd_data.update({key: value})
    return etcd_data


def add_team_instruction_c2dm_request(instruction: dict = None) -> MethodRequest:
    return create_add_team_instruction_c2dm_request(team_instruction=instruction)


def finalise_c2dm_request(mould_id: str = None) -> MethodRequest:
    return create_finalise_c2dm_request(mould_id=mould_id)


def force_ply_c2dm_request(ply_id: str, mould_id: str = None) -> MethodRequest:
    return create_force_ply_c2dm_request(ply_id=ply_id, mould_id=mould_id)


def undo_ply_c2dm_request(ply_id: str, mould_id: str = None) -> MethodRequest:
    return create_undo_ply_c2dm_request(ply_id, mould_id)


def undo_plies_to_c2dm_request(ply_id: str, mould_id: str = None) -> MethodRequest:
    return create_undo_plies_to_c2dm_request(ply_id, mould_id)


def undo_plies_to_dry_run_c2dm_request(ply_id: str, mould_id: str = None) -> MethodRequest:
    return create_undo_plies_to_dry_run_c2dm_request(ply_id, mould_id)


def recheck_ply_c2dm_request(ply_id: str, mould_id: str = None) -> MethodRequest:
    return create_recheck_ply_c2dm_request(ply_id, mould_id)


def instructions_loaded_on_boot() -> dict[str, bool]:
    return {"instructions_loaded_on_boot": True}


def ev_message_session(camera_id: str) -> dict:
    return {
        "cameraId": camera_id,
        "moduleId": "edge-verification"
    }


def dm_initiated_session() -> dict:
    return {
        "deviceModuleId": "device_module_id",
        "moduleId": "decision-maker",
        "mouldId": "mould_id"
    }


def ev_message_in(camera_id: str, detected_edges: set = None, missing_edges: set = None) -> Message:
    if detected_edges is None:
        detected_edges = set()
    if missing_edges is None:
        missing_edges = set()
    feedback = [
        {
            "type": "detected-edges",
            "edges": list(detected_edges),
        },
        {
            "type": "missing-edges",
            "edges": list(missing_edges),
        }
    ]
    message_data = {
        "session": ev_message_session(camera_id),
        "feedback": feedback
    }
    message = Message(data=json.dumps(message_data))
    message.input_name = routes_constants.DEFAULT_INPUT
    return message


def etcd_instruction_in(instruction: dict, source: str = None) -> WatchResponse:
    pallet_id = instruction["palletId"]
    layer_id = instruction["layerId"]
    key = f"/moulds/mould_id/instructions/{layer_id}-{pallet_id}"
    value = instruction
    value["source"] = source
    return _create_etcd_watcher_event(key, value, PutEvent)


def etcd_ply_in(ply: PlyState, source: str = None) -> WatchResponse:
    key = f"/moulds/mould_id/plies/{ply.id}"
    value = ply.serialize()
    value["source"] = source
    return _create_etcd_watcher_event(key, value, PutEvent)


def etcd_ply_delete_in(ply_id: str) -> WatchResponse:
    key = f"/moulds/mould_id/plies/{ply_id}"
    value = ''
    return _create_etcd_watcher_event(key, value, DeleteEvent)


def finalise_etcd_event_in() -> WatchResponse:
    return etcd_mould_state_in(GlobalMouldState.FINALISED)


def etcd_mould_state_in(state: GlobalMouldState) -> WatchResponse:
    key = f"/moulds/mould_id/state"
    value = state.name
    return _create_etcd_watcher_event(key, value, PutEvent)


def _create_etcd_watcher_event(key: str, value: Union[dict, str], event_type) -> WatchResponse:
    response = WatchResponse("header", [event_type(type("", (object,), {"kv": type("", (object,), {"key": 0})()})())])
    response.events[0].key = key.encode("utf-8")
    if type(value) == dict:
        response.events[0].value = json.dumps(value).encode("utf-8")
    elif type(value) == str:
        response.events[0].value = value.encode("utf-8")
    else:
        raise NotImplementedError(
            f"_create_etcd_watcher_event method supports only dict and str types, given type: {type(value)}")
    return response


def etcd_instruction_out(instruction: dict) -> EtcdOutput:
    pallet_id = instruction["palletId"]
    layer_id = instruction["layerId"]
    return EtcdOutput(
        key=f"/moulds/mould_id/instructions/{layer_id}-{pallet_id}",
        value=instruction
    )


def etcd_ply_out(ply: PlyState) -> EtcdOutput:
    return EtcdOutput(
        key=f"/moulds/mould_id/plies/{ply.id}",
        value=ply.serialize()
    )


def etcd_ply_delete_out(ply_id: str) -> EtcdOutput:
    return EtcdOutput(
        key=f"/moulds/mould_id/plies/{ply_id}",
        value=None
    )


def etcd_mould_state_out(state: GlobalMouldState) -> EtcdOutput:
    return EtcdOutput(
        key=f"/moulds/mould_id/state",
        value=state.name
    )


def etcd_mould_blade_sn_out(blade_sn: str) -> EtcdOutput:
    return EtcdOutput(
        key=f"/moulds/mould_id/blade_sn",
        value=blade_sn
    )


def etcd_remove_instructions() -> EtcdOutput:
    return EtcdOutput(
        key=f"/moulds/mould_id/instructions",
        value=None
    )


def etcd_remove_plies() -> EtcdOutput:
    return EtcdOutput(
        key=f"/moulds/mould_id/plies",
        value=None
    )


def edge_verification_out(
        camera_to_edges_to_verify: dict = None,
        session_cam_id: str = None,
        layers: list[str] = None,
        metadata: dict = None) -> MessagingOutput:
    if camera_to_edges_to_verify is None:
        camera_to_edges_to_verify = {}
    if session_cam_id is None:
        session = dm_initiated_session()
    else:
        session = ev_message_session(session_cam_id)
    if layers is None:
        layers = ["layer_P"]
    if metadata is None:
        metadata = {"bladeSn": "blade_sn",
                    "bladeRevision": "blade_revision",
                    "groundTruthVersion": "v1.0.0",
                    "layers": layers,
                    "mouldId": "mould_id",
                    "session": session}
    return MessagingOutput(
        output_message={"metadata": metadata, "data": camera_to_edges_to_verify},
        output_name=routes_constants.EDGE_VERIFICATION_OUTPUT
    )


def laser_out(payload: dict) -> MessagingOutput:
    return MessagingOutput(
        output_message=payload,
        output_name=routes_constants.FEEDBACK_OUTPUT
    )


def trace_out(payload: dict) -> MessagingOutput:
    return MessagingOutput(
        output_message=payload,
        output_name=routes_constants.TRACE_OUTPUT
    )


def stats_out(payload: dict) -> MessagingOutput:
    return MessagingOutput(
        output_message=payload,
        output_name=routes_constants.STATS_OUTPUT
    )


def trace_out_metadata(team_instructions: list, session: dict = None) -> dict:
    if session is None:
        session = dm_initiated_session()
    return {
        "session": session,
        "correlationId": "correlation_id",
        "customProperties": {},
        "hallId": "hall_id",
        "locationId": "location_id",
        "mouldId": "mould_id",
        "teamInstructions": team_instructions
    }


def camera_out(camera_ids: set, command: str, refresh_interval: int = None) -> MessagingOutput:
    payload = {}
    for camera_id in camera_ids:
        payload[camera_id] = {
            "command": command,
            "metadata": {
                "session": {
                    "mouldId": "mould_id"
                }
            },
        }
        if refresh_interval is not None:
            payload[camera_id] |= {
                "params": {
                    "refresh_interval_in_seconds": refresh_interval
                }
            }
    return MessagingOutput(
        output_message=payload,
        output_name=routes_constants.START_STREAMING_OUTPUT
    )


def c2dm_response_out(status_code: int, payload: Union[dict, list, str] = None) -> C2DMResponseOutput:
    return C2DMResponseOutput(
        status_code=status_code,
        payload=payload
    )


def replace(obj, key, val):
    return {k: replace(val if k == key else v, key, val)
            for k, v in obj.items()} if isinstance(obj, dict) else obj
