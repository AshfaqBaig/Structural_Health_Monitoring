# pylint: disable=protected-access, missing-module-docstring, missing-class-docstring, missing-function-docstring, duplicate-code, line-too-long, too-few-public-methods, no-self-use, too-many-locals, too-many-lines
from inspect import getmembers, isfunction

from app.global_mould_state_enum import GlobalMouldState
from tests.scenarios import mock_data
from tests.scenarios.model.test_scenario import TestScenario, ScenarioData
from tests.scenarios.model.test_scenario_entry import TestScenarioEntry
from tests.scenarios.scenarios_base import mould_state_plies_data, mould_state_instructions_data


class ScenariosCollector:
    def __init__(self, scenarios_dtos: object):
        self._scenario_list: list[TestScenario] = []
        self._create_test_scenarios(scenarios_dtos)

    @property
    def scenario_list(self) -> list[TestScenario]:
        """ Get collected scenarios list """
        return self._scenario_list

    def _create_test_scenarios(self, scenarios_dtos):
        scenarios_as_methods = getmembers(scenarios_dtos, isfunction)
        for scenario_method_name, scenario_method_ref in scenarios_as_methods:
            self._create_test_scenario(name=scenario_method_name, scenario_dto=scenario_method_ref())

    def _create_test_scenario(self, name: str, scenario_dto: dict) -> None:
        entries: list[TestScenarioEntry] = scenario_dto.get("entries")
        initial_mould_state_instructions_data = scenario_dto.get("initial_mould_state_instructions_data")
        initial_mould_state_plies_data = scenario_dto.get("initial_mould_state_plies_data")
        initial_mould_state = scenario_dto.get("initial_mould_state")
        initial_mould_blade_sn = scenario_dto.get("initial_mould_blade_sn")
        graph_data = scenario_dto.get("graph_data")
        edge_to_cameras_data = scenario_dto.get("edge_to_cameras_data")
        feedback_positions = scenario_dto.get("feedback_positions")

        if initial_mould_state_instructions_data is None:
            initial_mould_state_instructions_data = mould_state_instructions_data()
        if initial_mould_state_plies_data is None:
            initial_mould_state_plies_data = mould_state_plies_data()
        if initial_mould_state is None:
            initial_mould_state = GlobalMouldState.NONE
        if initial_mould_blade_sn is None:
            initial_mould_blade_sn = None
        if graph_data is None:
            graph_data = mock_data.static_graph_data
        if edge_to_cameras_data is None:
            edge_to_cameras_data = mock_data.edge_to_cameras_data
        if feedback_positions is None:
            feedback_positions = mock_data.feedback_positions_data

        scenario_data = ScenarioData(initial_mould_state_instructions_data,
                                     initial_mould_state_plies_data,
                                     initial_mould_state,
                                     initial_mould_blade_sn,
                                     graph_data,
                                     edge_to_cameras_data,
                                     feedback_positions)
        test_scenario = TestScenario(
            name,
            entries,
            scenario_data
        )
        return self._scenario_list.append(test_scenario)
