# pylint: disable=protected-access, missing-module-docstring, missing-class-docstring, missing-function-docstring, duplicate-code, line-too-long, too-few-public-methods, no-self-use, too-many-locals, too-many-lines
from unittest.mock import AsyncMock

import pytest
from azure.iot.device import MethodResponse

from app.handler.cloud_to_device_method_handler import CloudToDeviceMethodHandler
from tests.tests_base import create_c2dm_request, create_add_team_instruction_c2dm_request, \
    create_finalise_c2dm_request, create_force_ply_c2dm_request, create_undo_ply_c2dm_request, \
    create_recheck_ply_c2dm_request, create_undo_plies_to_c2dm_request, \
    create_undo_plies_to_dry_run_c2dm_request


@pytest.mark.asyncio
class CloudToDeviceMethodHandlerTests:
    async def test_should_halndle_add_team_instruction_command(self, mocker, sample_instructions_data):
        # GIVEN
        decision_maker = mocker.patch(
            "app.handler.cloud_to_device_method_handler.DecisionMaker", new_callable=AsyncMock)
        messaging_wrapper = mocker.patch(
            "app.handler.cloud_to_device_method_handler.MessagingWrapper", new_callable=AsyncMock)
        cloud_to_device_method_handler = CloudToDeviceMethodHandler(decision_maker, messaging_wrapper)
        team_instruction_request = create_add_team_instruction_c2dm_request(sample_instructions_data[0])

        # WHEN cloud_to_device_method_handler.handle is called
        await cloud_to_device_method_handler.handle(team_instruction_request)

        # THEN
        assert decision_maker.handle_add_team_instruction_command.call_count == 1
        assert decision_maker.handle_add_team_instruction_command.call_count == 1
        call_args = decision_maker.handle_add_team_instruction_command.call_args.args
        assert call_args[0] == team_instruction_request.payload

        # AND
        assert messaging_wrapper.send_c2dm_response.call_count == 1
        assert messaging_wrapper.send_c2dm_response.await_count == 1
        actual_argument = messaging_wrapper.send_c2dm_response.call_args.args[0]
        expected_response = MethodResponse.create_from_method_request(team_instruction_request, 200, None)
        assert actual_argument.request_id == expected_response.request_id
        assert actual_argument.status == expected_response.status
        assert actual_argument.payload == expected_response.payload

    async def test_should_halndle_finalise_command(self, mocker):
        # GIVEN
        decision_maker = mocker.patch(
            "app.handler.cloud_to_device_method_handler.DecisionMaker", new_callable=AsyncMock)
        messaging_wrapper = mocker.patch(
            "app.handler.cloud_to_device_method_handler.MessagingWrapper", new_callable=AsyncMock)
        cloud_to_device_method_handler = CloudToDeviceMethodHandler(decision_maker, messaging_wrapper)
        finalise_request = create_finalise_c2dm_request(mould_id="mould_id")

        # WHEN cloud_to_device_method_handler.handle is called
        await cloud_to_device_method_handler.handle(finalise_request)

        # THEN
        assert decision_maker.handle_finalise_command.call_count == 1
        assert decision_maker.handle_finalise_command.call_count == 1
        call_args = decision_maker.handle_finalise_command.call_args.args
        assert call_args[0] == finalise_request.payload

        # AND
        assert messaging_wrapper.send_c2dm_response.call_count == 1
        assert messaging_wrapper.send_c2dm_response.await_count == 1
        actual_argument = messaging_wrapper.send_c2dm_response.call_args.args[0]
        expected_response = MethodResponse.create_from_method_request(finalise_request, 200, None)
        assert actual_argument.request_id == expected_response.request_id
        assert actual_argument.status == expected_response.status
        assert actual_argument.payload == expected_response.payload

    async def test_should_halndle_force_ply_command(self, mocker):
        # GIVEN
        decision_maker = mocker.patch(
            "app.handler.cloud_to_device_method_handler.DecisionMaker", new_callable=AsyncMock)
        messaging_wrapper = mocker.patch(
            "app.handler.cloud_to_device_method_handler.MessagingWrapper", new_callable=AsyncMock)
        cloud_to_device_method_handler = CloudToDeviceMethodHandler(decision_maker, messaging_wrapper)
        force_ply_request = create_force_ply_c2dm_request("ply_id", "mould_id", "correlation_id")

        # WHEN cloud_to_device_method_handler.handle is called
        await cloud_to_device_method_handler.handle(force_ply_request)

        # THEN
        assert decision_maker.handle_force_ply_command.call_count == 1
        assert decision_maker.handle_force_ply_command.call_count == 1
        call_args = decision_maker.handle_force_ply_command.call_args.args
        assert call_args[0] == force_ply_request.payload

        # AND
        assert messaging_wrapper.send_c2dm_response.call_count == 1
        assert messaging_wrapper.send_c2dm_response.await_count == 1
        actual_argument = messaging_wrapper.send_c2dm_response.call_args.args[0]
        expected_response = MethodResponse.create_from_method_request(force_ply_request, 200, None)
        assert actual_argument.request_id == expected_response.request_id
        assert actual_argument.status == expected_response.status
        assert actual_argument.payload == expected_response.payload

    async def test_should_halndle_undo_ply_command(self, mocker):
        # GIVEN
        decision_maker = mocker.patch(
            "app.handler.cloud_to_device_method_handler.DecisionMaker", new_callable=AsyncMock)
        messaging_wrapper = mocker.patch(
            "app.handler.cloud_to_device_method_handler.MessagingWrapper", new_callable=AsyncMock)
        cloud_to_device_method_handler = CloudToDeviceMethodHandler(decision_maker, messaging_wrapper)
        undo_ply_request = create_undo_ply_c2dm_request("ply_id", "mould_id", "correlation_id")

        # WHEN cloud_to_device_method_handler.handle is called
        await cloud_to_device_method_handler.handle(undo_ply_request)

        # THEN
        assert decision_maker.handle_undo_ply_command.call_count == 1
        assert decision_maker.handle_undo_ply_command.call_count == 1
        call_args = decision_maker.handle_undo_ply_command.call_args.args
        assert call_args[0] == undo_ply_request.payload

        # AND
        assert messaging_wrapper.send_c2dm_response.call_count == 1
        assert messaging_wrapper.send_c2dm_response.await_count == 1
        actual_argument = messaging_wrapper.send_c2dm_response.call_args.args[0]
        expected_response = MethodResponse.create_from_method_request(undo_ply_request, 200, None)
        assert actual_argument.request_id == expected_response.request_id
        assert actual_argument.status == expected_response.status
        assert actual_argument.payload == expected_response.payload

    async def test_should_handle_undo_plies_to_command(self, mocker):
        # GIVEN
        decision_maker = mocker.patch(
            "app.handler.cloud_to_device_method_handler.DecisionMaker", new_callable=AsyncMock)
        messaging_wrapper = mocker.patch(
            "app.handler.cloud_to_device_method_handler.MessagingWrapper", new_callable=AsyncMock)
        cloud_to_device_method_handler = CloudToDeviceMethodHandler(decision_maker, messaging_wrapper)
        undo_plies_to_request = create_undo_plies_to_c2dm_request("ply_id", "mould_id", "correlation_id")

        # WHEN cloud_to_device_method_handler.handle is called
        await cloud_to_device_method_handler.handle(undo_plies_to_request)

        # THEN
        assert decision_maker.handle_undo_plies_to_command.call_count == 1
        assert decision_maker.handle_undo_plies_to_command.call_count == 1
        call_args = decision_maker.handle_undo_plies_to_command.call_args.args
        assert call_args[0] == undo_plies_to_request.payload

        # AND
        assert messaging_wrapper.send_c2dm_response.call_count == 1
        assert messaging_wrapper.send_c2dm_response.await_count == 1
        actual_argument = messaging_wrapper.send_c2dm_response.call_args.args[0]
        expected_response = MethodResponse.create_from_method_request(undo_plies_to_request, 200, None)
        assert actual_argument.request_id == expected_response.request_id
        assert actual_argument.status == expected_response.status
        assert actual_argument.payload == expected_response.payload

    async def test_should_handle_undo_plies_to_dry_run_command(self, mocker):
        # GIVEN
        decision_maker = mocker.patch(
            "app.handler.cloud_to_device_method_handler.DecisionMaker", new_callable=AsyncMock)
        plies_to_return = ["P1", "P2", "P3"]
        decision_maker_handle_undo_plies_to_dry_run_command = mocker.patch.object(
            decision_maker, "handle_undo_plies_to_dry_run_command", return_value=plies_to_return)
        messaging_wrapper = mocker.patch(
            "app.handler.cloud_to_device_method_handler.MessagingWrapper", new_callable=AsyncMock)
        cloud_to_device_method_handler = CloudToDeviceMethodHandler(decision_maker, messaging_wrapper)
        undo_plies_to_dry_run_request = create_undo_plies_to_dry_run_c2dm_request(
            "ply_id", "mould_id", "correlation_id")

        # WHEN cloud_to_device_method_handler.handle is called
        await cloud_to_device_method_handler.handle(undo_plies_to_dry_run_request)

        # THEN
        assert decision_maker_handle_undo_plies_to_dry_run_command.call_count == 1
        assert decision_maker_handle_undo_plies_to_dry_run_command.call_count == 1
        call_args = decision_maker_handle_undo_plies_to_dry_run_command.call_args.args
        assert call_args[0] == undo_plies_to_dry_run_request.payload

        # AND
        assert messaging_wrapper.send_c2dm_response.call_count == 1
        assert messaging_wrapper.send_c2dm_response.await_count == 1
        actual_argument = messaging_wrapper.send_c2dm_response.call_args.args[0]
        expected_response = MethodResponse.create_from_method_request(
            undo_plies_to_dry_run_request, 200, plies_to_return)
        assert actual_argument.request_id == expected_response.request_id
        assert actual_argument.status == expected_response.status
        assert actual_argument.payload == expected_response.payload

    async def test_should_halndle_recheck_ply_command(self, mocker):
        # GIVEN
        decision_maker = mocker.patch(
            "app.handler.cloud_to_device_method_handler.DecisionMaker", new_callable=AsyncMock)
        messaging_wrapper = mocker.patch(
            "app.handler.cloud_to_device_method_handler.MessagingWrapper", new_callable=AsyncMock)
        cloud_to_device_method_handler = CloudToDeviceMethodHandler(decision_maker, messaging_wrapper)
        recheck_ply_request = create_recheck_ply_c2dm_request("ply_id", "mould_id", "correlation_id")

        # WHEN cloud_to_device_method_handler.handle is called
        await cloud_to_device_method_handler.handle(recheck_ply_request)

        # THEN
        assert decision_maker.handle_recheck_ply_command.call_count == 1
        assert decision_maker.handle_recheck_ply_command.call_count == 1
        call_args = decision_maker.handle_recheck_ply_command.call_args.args
        assert call_args[0] == recheck_ply_request.payload

        # AND
        assert messaging_wrapper.send_c2dm_response.call_count == 1
        assert messaging_wrapper.send_c2dm_response.await_count == 1
        actual_argument = messaging_wrapper.send_c2dm_response.call_args.args[0]
        expected_response = MethodResponse.create_from_method_request(recheck_ply_request, 200, None)
        assert actual_argument.request_id == expected_response.request_id
        assert actual_argument.status == expected_response.status
        assert actual_argument.payload == expected_response.payload

    async def test_should_halndle_log_level_update_command(self, mocker):
        # GIVEN
        cfg = mocker.patch("app.handler.cloud_to_device_method_handler.cfg")
        log = mocker.patch("app.handler.cloud_to_device_method_handler.log")
        logger = mocker.patch("app.handler.cloud_to_device_method_handler.logger")
        decision_maker = mocker.patch(
            "app.handler.cloud_to_device_method_handler.DecisionMaker", new_callable=AsyncMock)
        messaging_wrapper = mocker.patch(
            "app.handler.cloud_to_device_method_handler.MessagingWrapper", new_callable=AsyncMock)
        cloud_to_device_method_handler = CloudToDeviceMethodHandler(decision_maker, messaging_wrapper)
        command = "set_log_level"
        params = {"logLevel": "log_level"}
        request = create_c2dm_request(command, params)

        # WHEN cloud_to_device_method_handler.handle is called
        await cloud_to_device_method_handler.handle(request)

        # THEN cfg.LOG_LEVEL is assigned correct logging level
        assert cfg.LOG_LEVEL == "log_level"

        # AND logger is called once with correct argument
        assert logger.update_log_level.call_count == 1
        call_args = logger.update_log_level.call_args.args
        assert call_args[0] == log

        # AND messaging.send_c2dm_response is called and awaited with correct argument
        assert messaging_wrapper.send_c2dm_response.call_count == 1
        assert messaging_wrapper.send_c2dm_response.await_count == 1
        actual_argument = messaging_wrapper.send_c2dm_response.call_args.args[0]
        expected_response = MethodResponse.create_from_method_request(request, 200, None)
        assert actual_argument.request_id == expected_response.request_id
        assert actual_argument.status == expected_response.status
        assert actual_argument.payload == expected_response.payload

    async def test_should_not_handle_request_and_correctly_report_error_when_unknown_command_given(self, mocker):
        # GIVEN
        log = mocker.patch("app.handler.cloud_to_device_method_handler.log")
        decision_maker = mocker.patch("app.handler.cloud_to_device_method_handler.DecisionMaker",
                                      new_callable=AsyncMock)
        messaging_wrapper = mocker.patch("app.handler.cloud_to_device_method_handler.MessagingWrapper",
                                         new_callable=AsyncMock)
        cloud_to_device_method_handler = CloudToDeviceMethodHandler(decision_maker, messaging_wrapper)
        command = "INVALID"
        params = {"mock": "data"}
        request = create_c2dm_request(command, params)

        # WHEN cloud_to_device_method_handler.handle is called
        await cloud_to_device_method_handler.handle(request)

        # THEN messaging.send_message_to_error_output is called and awaited once with correct argument
        assert messaging_wrapper.send_message_to_error_output.call_count == 1
        assert messaging_wrapper.send_message_to_error_output.await_count == 1
        call_args = messaging_wrapper.send_message_to_error_output.call_args.args
        error_message = f"Failed to recognize command in C2DM request " \
                        f"with correlation_id: {request.payload.get('correlationId')}"
        assert call_args[0] == error_message

        # AND messaging.send_c2dm_response is called and awaited with correct argument
        assert messaging_wrapper.send_c2dm_response.call_count == 1
        assert messaging_wrapper.send_c2dm_response.await_count == 1
        actual_argument = messaging_wrapper.send_c2dm_response.call_args.args[0]
        expected_response = MethodResponse.create_from_method_request(request, 400, error_message)
        assert actual_argument.request_id == expected_response.request_id
        assert actual_argument.status == expected_response.status
        assert actual_argument.payload == expected_response.payload

        # AND log.error is called with correct argument
        assert log.error.call_count == 1
        call_args = log.error.call_args.args
        assert call_args[0] == error_message

        # AND decision_maker.handle_finalise_command is not called
        assert decision_maker.handle_finalise_command.call_count == 0

        # AND decision_maker.handle_add_team_instruction_command is not called
        assert decision_maker.handle_add_team_instruction_command.call_count == 0

        # AND decision_maker.handle_force_ply_command is not called
        assert decision_maker.handle_force_ply_command.call_count == 0

        # AND decision_maker.update_log_level is not called
        assert decision_maker.update_log_level.call_count == 0

    async def test_should_correctly_report_error_when_exception_raised_while_handling_command(self, mocker):
        # GIVEN correctly
        log = mocker.patch("app.handler.cloud_to_device_method_handler.log")
        decision_maker = mocker.patch("app.handler.cloud_to_device_method_handler.DecisionMaker",
                                      new_callable=AsyncMock)
        messaging_wrapper = mocker.patch("app.handler.cloud_to_device_method_handler.MessagingWrapper",
                                         new_callable=AsyncMock)
        cloud_to_device_method_handler = CloudToDeviceMethodHandler(decision_maker, messaging_wrapper)
        command = "add_team_instruction"
        params = {"mock": "data"}
        request = create_c2dm_request(command, params)

        # AND raised exception when decision_maker.handle_add_team_instruction_command is called
        ex_message = "exception message"
        mocker.patch.object(decision_maker, "handle_add_team_instruction_command", side_effect=ValueError(ex_message))

        # WHEN cloud_to_device_method_handler.handle is called
        await cloud_to_device_method_handler.handle(request)

        # THEN messaging.send_message_to_error_output is called and awaited once with correct argument
        assert messaging_wrapper.send_message_to_error_output.call_count == 1
        assert messaging_wrapper.send_message_to_error_output.await_count == 1
        call_args = messaging_wrapper.send_message_to_error_output.call_args.args
        error_message = f"Failed to handle requested command: {request.name}, via C2DM request " \
                        f"with correlation_id: {request.payload.get('correlationId')}, due to: {ex_message}"
        assert call_args[0] == error_message

        # AND log.exception is called with correct argument
        assert log.exception.call_count == 1
        call_args = log.exception.call_args.args
        assert call_args[0] == error_message

        # AND
        assert messaging_wrapper.send_c2dm_response.call_count == 1
        assert messaging_wrapper.send_c2dm_response.await_count == 1
        actual_argument = messaging_wrapper.send_c2dm_response.call_args.args[0]
        expected_response = MethodResponse.create_from_method_request(request, 400, error_message)
        assert actual_argument.request_id == expected_response.request_id
        assert actual_argument.status == expected_response.status
        assert actual_argument.payload == expected_response.payload
