# pylint: disable=protected-access, missing-module-docstring, missing-class-docstring, missing-function-docstring, duplicate-code, line-too-long, too-few-public-methods, no-self-use, too-many-locals, too-many-lines
import json
from unittest.mock import AsyncMock, call, Mock

import pytest
from azure.iot.device import Message

from app.handler.input_message_handler import InputMessageHandler
from tests.tests_base import create_edge_verification_feedback


@pytest.mark.asyncio
class HandleInputMessageTests:
    async def test_should_correctly_handle_edge_verification_message(self, mocker, sample_edge_verification_feedback):
        # GIVEN
        decision_maker = mocker.patch("app.handler.input_message_handler.DecisionMaker", new_callable=AsyncMock)
        messaging_wrapper = mocker.patch("app.handler.input_message_handler.MessagingWrapper", new_callable=AsyncMock)
        input_message_handler = InputMessageHandler(decision_maker, messaging_wrapper)

        session = {"cameraId": "camera_id"}
        message_data = {"session": session, "feedback": sample_edge_verification_feedback}
        message = Message(data=json.dumps(message_data))
        message.input_name = "sample_input_name"
        message.correlation_id = "correlation_id"
        message.custom_properties = "custom_properties"

        # WHEN input_message_handler.handle is called
        await input_message_handler.handle(message)

        # THEN decision_maker.handle_edge_verification_message is called and awaited once with correct argument
        decision_maker.handle_edge_verification_message.assert_called_once()
        decision_maker.handle_edge_verification_message.assert_awaited_once()
        call_args = decision_maker.handle_edge_verification_message.call_args.args
        verification_data = call_args[0]
        metadata_to_forward = call_args[1]
        assert verification_data == sample_edge_verification_feedback
        assert metadata_to_forward.camera_id == session["cameraId"]
        assert metadata_to_forward.session == session
        assert metadata_to_forward.correlation_id == "correlation_id"
        assert metadata_to_forward.custom_properties == "custom_properties"

    async def test_should_forward_message_to_feedback_module_when_received_message_not_from_edge_verification_module(
            self, mocker):
        # GIVEN
        log = mocker.patch("app.handler.input_message_handler.log")
        decision_maker = mocker.patch("app.handler.input_message_handler.DecisionMaker", new_callable=AsyncMock)
        messaging_wrapper = mocker.patch("app.handler.input_message_handler.MessagingWrapper", new_callable=AsyncMock)
        input_message_handler = InputMessageHandler(decision_maker, messaging_wrapper)

        data = {
            "feedback": [
                {
                    "moduleId": "anomaly-detection",
                    "type": "polyline",
                    "coordinates": []
                }
            ]}
        correlation_id = "correlation_id"
        message = Message(data=json.dumps(data))
        message.input_name = "sample_input_name"
        message.correlation_id = "correlation_id"

        # WHEN input_message_handler.handle is called
        await input_message_handler.handle(message)

        # THEN decision_maker.handle_edge_verification_message is not called, means execution of method was aborted
        decision_maker.handle_edge_verification_message.assert_not_called()

        # AND log.warning is called with correct arguments
        assert log.warning.call_count == 1
        call_args = log.warning.call_args.args
        warning_message = "Message is not intended for processing on DM. Forwarding message data to Feedback module."
        assert call_args[0] == warning_message

        # AND messaging.send_message_to_feedback is called and awaited once with correct argument
        messaging_wrapper.send_message_to_feedback.assert_called_once()
        messaging_wrapper.send_message_to_feedback.assert_awaited_once()
        call_args = messaging_wrapper.send_message_to_feedback.call_args.args
        assert call_args[0] == data

    async def test_should_send_message_to_error_output_when_none_type_feedback_data_recieved(self, mocker):
        # GIVEN
        log = mocker.patch("app.handler.input_message_handler.log")
        decision_maker = mocker.patch("app.handler.input_message_handler.DecisionMaker", new_callable=AsyncMock)
        messaging_wrapper = mocker.patch("app.handler.input_message_handler.MessagingWrapper", new_callable=AsyncMock)
        input_message_handler = InputMessageHandler(decision_maker, messaging_wrapper)

        data = {"feedback": None}
        message = Message(data=json.dumps(data))
        message.input_name = "sample_input_name"

        # WHEN input_message_handler.handle is called
        await input_message_handler.handle(message)

        # THEN decision_maker.handle_edge_verification_message is not called, means execution of method was aborted
        decision_maker.handle_edge_verification_message.assert_not_called()

        # AND log.exception is called once with correct argument
        assert log.exception.call_count == 1
        call_args = log.exception.call_args.args
        exception_str = f"'feedback' property not found in message data: {data}"
        error_message = f"Failed to handle Edge Hub routed input message: {message}, due to: {exception_str}"
        assert call_args[0] == error_message

        # AND messaging.send_message_to_error_output is called and awaited once with correct argument
        messaging_wrapper.send_message_to_error_output.assert_called_once()
        messaging_wrapper.send_message_to_error_output.assert_awaited_once()
        call_args = messaging_wrapper.send_message_to_error_output.call_args.args
        assert call_args[0] == error_message

    async def test_should_send_message_to_error_output_when_feedback_key_do_not_exist_in_recieved_message(self, mocker):
        # GIVEN
        log = mocker.patch("app.handler.input_message_handler.log")
        decision_maker = mocker.patch("app.handler.input_message_handler.DecisionMaker", new_callable=AsyncMock)
        messaging_wrapper = mocker.patch("app.handler.input_message_handler.MessagingWrapper", new_callable=AsyncMock)
        input_message_handler = InputMessageHandler(decision_maker, messaging_wrapper)

        data = {"feedback_key": "do_not_exist"}
        message = Message(data=json.dumps(data))
        message.input_name = "sample_input_name"

        # WHEN input_message_handler.handle is called
        await input_message_handler.handle(message)

        # THEN decision_maker.handle_edge_verification_message is not called, means execution of method was aborted
        decision_maker.handle_edge_verification_message.assert_not_called()

        # AND log.exception is called once with correct argument
        assert log.exception.call_count == 1
        call_args = log.exception.call_args.args
        exception_str = f"'feedback' property not found in message data: {data}"
        error_message = f"Failed to handle Edge Hub routed input message: {message}, due to: {exception_str}"
        assert call_args[0] == error_message

        # AND messaging.send_message_to_error_output is called and awaited once with correct argument
        messaging_wrapper.send_message_to_error_output.assert_called_once()
        messaging_wrapper.send_message_to_error_output.assert_awaited_once()
        call_args = messaging_wrapper.send_message_to_error_output.call_args.args
        assert call_args[0] == error_message

    async def test_should_log_warning_and_abort_processing_when_empty_feedback_data_recieved(self, mocker):
        # GIVEN
        log = mocker.patch("app.handler.input_message_handler.log")
        decision_maker = mocker.patch("app.handler.input_message_handler.DecisionMaker", new_callable=AsyncMock)
        messaging_wrapper = mocker.patch("app.handler.input_message_handler.MessagingWrapper", new_callable=AsyncMock)
        input_message_handler = InputMessageHandler(decision_maker, messaging_wrapper)

        data = {"feedback": []}
        message = Message(data=json.dumps(data))
        message.input_name = "sample_input_name"

        # WHEN
        await input_message_handler.handle(message)

        # THEN decision_maker.handle_edge_verification_message is not called, means execution of method was aborted
        assert decision_maker.handle_edge_verification_message.call_count == 0

        # AND
        assert log.exception.call_count == 1
        call_args = log.exception.call_args.args
        ex_message = f"Empty 'feedback' property in message data cannot be processed, discarding: {data}"
        error_message = f"Failed to handle Edge Hub routed input message: {message}, due to: {ex_message}"
        assert call_args[0] == error_message

    async def test_should_report_error_when_exception_raised_and_caught(
            self, mocker, sample_edge_verification_feedback):
        # GIVEN
        log = mocker.patch("app.handler.input_message_handler.log")
        decision_maker = mocker.patch("app.handler.input_message_handler.DecisionMaker", new_callable=AsyncMock)
        messaging_wrapper = mocker.patch("app.handler.input_message_handler.MessagingWrapper", new_callable=AsyncMock)
        input_message_handler = InputMessageHandler(decision_maker, messaging_wrapper)

        message_data = {"session": {"cameraId": "camera_id"}, "feedback": sample_edge_verification_feedback}
        message = Message(data=json.dumps(message_data))
        message.input_name = "sample_input_name"

        # AND raised exception when decision_maker.handle_edge_verification_message is called
        ex_message = "exception message"
        mocker.patch.object(decision_maker, "handle_edge_verification_message", side_effect=ValueError(ex_message))

        # WHEN input_message_handler.handle is called
        await input_message_handler.handle(message)

        # THEN exception caught and messaging.send_message_to_error_output is called and awaited with correct argument
        error_message = f"Failed to handle Edge Hub routed input message: {message}, due to: {ex_message}"
        assert messaging_wrapper.send_message_to_error_output.call_count == 1
        assert messaging_wrapper.send_message_to_error_output.await_count == 1
        assert messaging_wrapper.send_message_to_error_output.call_args.args[0] == error_message

        # AND log.exception is called with correct argument
        assert log.exception.call_count == 1
        call_args = log.exception.call_args.args
        assert call_args[0] == error_message


class HasDetectedOrMissingEdgesTests:
    def test_should_return_true_when_detected_and_missing_edges_feedback_given(self):
        # GIVEN
        input_message_handler = InputMessageHandler(Mock(), Mock())
        feedback = [{"type": "detected-edges"}, {"type": "missing-edges"}]

        # WHEN input_message_handler._has_detected_or_missing_edges is called
        result = input_message_handler._has_detected_or_missing_edges({"feedback": feedback})

        # THEN correct result is returned
        assert result is True

    def test_should_return_false_when_empty_feedback_given(self):
        # GIVEN
        input_message_handler = InputMessageHandler(Mock(), Mock())
        feedback = []

        # WHEN input_message_handler._has_detected_or_missing_edges is called
        result = input_message_handler._has_detected_or_missing_edges({"feedback": feedback})

        # THEN correct result is returned
        assert result is False

    def test_should_return_false_when_given_feedback_not_from_edge_verification_module(self):
        # GIVEN
        input_message_handler = InputMessageHandler(Mock(), Mock())
        feedback = [
            {
                "moduleId": "anomaly-detection",
                "type": "polyline",
                "coordinates": []
            }
        ]

        # WHEN input_message_handler._has_detected_or_missing_edges is called
        result = input_message_handler._has_detected_or_missing_edges({"feedback": feedback})

        # THEN correct result is returned
        assert result is False

    def test_should_return_true_when_only_detected_edges_feedback_given(self):
        # GIVEN
        input_message_handler = InputMessageHandler(Mock(), Mock())
        feedback = [{"type": "detected-edges"}]

        # WHEN input_message_handler._has_detected_or_missing_edges is called
        result = input_message_handler._has_detected_or_missing_edges({"feedback": feedback})

        # THEN correct result is returned
        assert result is True

    def test_should_return_true_when_only_missing_edges_feedback_given(self):
        # GIVEN
        input_message_handler = InputMessageHandler(Mock(), Mock())
        feedback = [{"type": "missing-edges"}]

        # WHEN input_message_handler._has_detected_or_missing_edges is called
        result = input_message_handler._has_detected_or_missing_edges({"feedback": feedback})

        # THEN correct result is returned
        assert result is True


class CheckEdgeVerificationMessageDuplicationTests:
    @pytest.mark.asyncio
    async def test_should_log_warning_on_receiving_a_same_edge_verification_message_multiple_times_in_a_row(
            self, mocker):
        # GIVEN
        log = mocker.patch("app.handler.input_message_handler.log")
        decision_maker = mocker.patch("app.handler.input_message_handler.DecisionMaker", new_callable=AsyncMock)
        messaging_wrapper = mocker.patch("app.handler.input_message_handler.MessagingWrapper", new_callable=AsyncMock)
        input_message_handler = InputMessageHandler(decision_maker, messaging_wrapper)

        feedback = create_edge_verification_feedback({"edge_1"}, {"edge_2"})
        camera_id = "camera_id"
        message_data = {"session": {"cameraId": camera_id}, "feedback": feedback}
        message = Message(data=json.dumps(message_data))

        # WHEN input_message_handler.handle is called
        await input_message_handler.handle(message)
        await input_message_handler.handle(message)
        await input_message_handler.handle(message)

        # THEN log.warning is called correct times with correct argument
        assert log.warning.call_count == 2
        call_args_list = log.warning.call_args_list

        assert call_args_list[0] == call(
            f"Same edge verification message for camera: '{camera_id}' received {2} times in a row.")
        assert call_args_list[1] == call(
            f"Same edge verification message for camera: '{camera_id}' received {3} times in a row.")

    @pytest.mark.asyncio
    async def test_should_correctly_count_duplicated_messages_from_one_source_when_receiving_from_multiple_sources(
            self, mocker):
        # GIVEN
        log = mocker.patch("app.handler.input_message_handler.log")
        decision_maker = mocker.patch("app.handler.input_message_handler.DecisionMaker", new_callable=AsyncMock)
        messaging_wrapper = mocker.patch("app.handler.input_message_handler.MessagingWrapper", new_callable=AsyncMock)
        input_message_handler = InputMessageHandler(decision_maker, messaging_wrapper)

        feedback_0 = create_edge_verification_feedback({"edge_1"}, {"edge_2"})
        camera_id = "camera_id"
        message_0_data = {"session": {"cameraId": camera_id}, "feedback": feedback_0}
        message_0 = Message(data=json.dumps(message_0_data))

        feedback_1 = create_edge_verification_feedback({"edge_1"}, {"edge_2"})
        camera_id_other = "camera_id_other"
        message_1_data = {"session": {"cameraId": camera_id_other}, "feedback": feedback_1}
        message_1 = Message(data=json.dumps(message_1_data))

        feedback_2 = create_edge_verification_feedback({"edge_1"}, {"edge_2"})
        message_2_data = {"session": {"cameraId": camera_id}, "feedback": feedback_2}
        message_2 = Message(data=json.dumps(message_2_data))

        feedback_3 = create_edge_verification_feedback({"edge_3"}, {"edge_4"})
        message_3_data = {"session": {"cameraId": camera_id_other}, "feedback": feedback_3}
        message_3 = Message(data=json.dumps(message_3_data))

        feedback_4 = create_edge_verification_feedback({"edge_1"}, {"edge_2"})
        message_4_data = {"session": {"cameraId": camera_id}, "feedback": feedback_4}
        message_4 = Message(data=json.dumps(message_4_data))

        # WHEN input_message_handler.handle is called
        await input_message_handler.handle(message_0)
        await input_message_handler.handle(message_1)
        await input_message_handler.handle(message_2)
        await input_message_handler.handle(message_3)
        await input_message_handler.handle(message_4)

        # THEN log.warning is called correct times with correct argument
        assert log.warning.call_count == 2
        call_args_list = log.warning.call_args_list

        assert call_args_list[0] == call(
            f"Same edge verification message for camera: '{camera_id}' received {2} times in a row.")
        assert call_args_list[1] == call(
            f"Same edge verification message for camera: '{camera_id}' received {3} times in a row.")

    @pytest.mark.asyncio
    async def test_should_not_log_warning_on_receiving_a_same_edges_verification_message_from_different_source(
            self, mocker):
        # GIVEN
        log = mocker.patch("app.handler.input_message_handler.log")
        decision_maker = mocker.patch("app.handler.input_message_handler.DecisionMaker", new_callable=AsyncMock)
        messaging_wrapper = mocker.patch("app.handler.input_message_handler.MessagingWrapper", new_callable=AsyncMock)
        input_message_handler = InputMessageHandler(decision_maker, messaging_wrapper)

        feedback = create_edge_verification_feedback({"edge_1"}, {"edge_2"})

        camera_id_0 = "camera_id_0"
        message_0_data = {"session": {"cameraId": camera_id_0}, "feedback": feedback}
        message_0 = Message(data=json.dumps(message_0_data))

        camera_id_1 = "camera_id_1"
        message_1_data = {"session": {"cameraId": camera_id_1}, "feedback": feedback}
        message_1 = Message(data=json.dumps(message_1_data))

        camera_id_2 = "camera_id_2"
        message_2_data = {"session": {"cameraId": camera_id_2}, "feedback": feedback}
        message_2 = Message(data=json.dumps(message_2_data))

        # WHEN input_message_handler.handle is called
        await input_message_handler.handle(message_0)
        await input_message_handler.handle(message_1)
        await input_message_handler.handle(message_2)

        # THEN log.warning is called correct times with correct argument
        assert log.warning.call_count == 0

    @pytest.mark.asyncio
    async def test_should_not_log_warning_when_non_duplicated_edge_verification_message_received(self, mocker):
        # GIVEN
        log = mocker.patch("app.handler.input_message_handler.log")
        decision_maker = mocker.patch("app.handler.input_message_handler.DecisionMaker", new_callable=AsyncMock)
        messaging_wrapper = mocker.patch("app.handler.input_message_handler.MessagingWrapper", new_callable=AsyncMock)
        input_message_handler = InputMessageHandler(decision_maker, messaging_wrapper)

        camera_id = "camera_id"

        feedback_0 = create_edge_verification_feedback({"edge_1"}, {"edge_2"})
        message_0_data = {"session": {"cameraId": camera_id}, "feedback": feedback_0}
        message_0 = Message(data=json.dumps(message_0_data))

        feedback_1 = create_edge_verification_feedback({"edge_3"}, {"edge_4"})
        message_1_data = {"session": {"cameraId": camera_id}, "feedback": feedback_1}
        message_1 = Message(data=json.dumps(message_1_data))

        feedback_2 = create_edge_verification_feedback({"edge_5"}, {"edge_6"})
        message_2_data = {"session": {"cameraId": camera_id}, "feedback": feedback_2}
        message_2 = Message(data=json.dumps(message_2_data))

        # WHEN input_message_handler.handle is called
        await input_message_handler.handle(message_0)
        await input_message_handler.handle(message_1)
        await input_message_handler.handle(message_2)

        # THEN log.warning is called correct times with correct argument
        assert log.warning.call_count == 0

    @pytest.mark.asyncio
    async def test_should_not_log_warning_when_duplicated_edge_verification_message_received_not_in_a_row(self, mocker):
        # GIVEN
        log = mocker.patch("app.handler.input_message_handler.log")
        decision_maker = mocker.patch("app.handler.input_message_handler.DecisionMaker", new_callable=AsyncMock)
        messaging_wrapper = mocker.patch("app.handler.input_message_handler.MessagingWrapper", new_callable=AsyncMock)
        input_message_handler = InputMessageHandler(decision_maker, messaging_wrapper)

        camera_id = "camera_id"

        feedback_0 = create_edge_verification_feedback({"edge_1"}, {"edge_2"})
        message_0_data = {"session": {"cameraId": camera_id}, "feedback": feedback_0}
        message_0 = Message(data=json.dumps(message_0_data))

        feedback_1 = create_edge_verification_feedback({"edge_3"}, {"edge_4"})
        message_1_data = {"session": {"cameraId": camera_id}, "feedback": feedback_1}
        message_1 = Message(data=json.dumps(message_1_data))

        # WHEN input_message_handler.handle is called
        await input_message_handler.handle(message_0)
        await input_message_handler.handle(message_1)
        await input_message_handler.handle(message_0)

        # THEN log.warning is called correct times with correct argument
        assert log.warning.call_count == 0

    @pytest.mark.asyncio
    async def test_should_reset_count_when_after_duplicated_edge_verification_message_received_other_duplicates(
            self, mocker):
        # GIVEN
        log = mocker.patch("app.handler.input_message_handler.log")
        decision_maker = mocker.patch("app.handler.input_message_handler.DecisionMaker", new_callable=AsyncMock)
        messaging_wrapper = mocker.patch("app.handler.input_message_handler.MessagingWrapper", new_callable=AsyncMock)
        input_message_handler = InputMessageHandler(decision_maker, messaging_wrapper)

        camera_id = "camera_id"

        feedback_0 = create_edge_verification_feedback({"edge_1"}, {"edge_2"})
        message_0_data = {"session": {"cameraId": camera_id}, "feedback": feedback_0}
        message_0 = Message(data=json.dumps(message_0_data))

        feedback_1 = create_edge_verification_feedback({"edge_3"}, {"edge_4"})
        message_1_data = {"session": {"cameraId": camera_id}, "feedback": feedback_1}
        message_1 = Message(data=json.dumps(message_1_data))

        # WHEN input_message_handler.handle is called
        await input_message_handler.handle(message_0)
        await input_message_handler.handle(message_0)
        await input_message_handler.handle(message_1)
        await input_message_handler.handle(message_1)

        # THEN log.warning is called correct times with correct argument
        assert log.warning.call_count == 2
        call_args_list = log.warning.call_args_list
        assert call_args_list[0] == call(
            f"Same edge verification message for camera: '{camera_id}' received {2} times in a row.")
        assert call_args_list[1] == call(
            f"Same edge verification message for camera: '{camera_id}' received {2} times in a row.")
