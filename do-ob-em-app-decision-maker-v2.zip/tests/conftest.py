# pylint: disable=protected-access,missing-module-docstring, missing-class-docstring, missing-function-docstring, duplicate-code

import pytest

from tests.etcd_container import EtcdContainer
from tests.tests_base import StatePliesMock


@pytest.fixture
def sample_instructions_data() -> list:
    return [
        {
            "version": "v0.0.0",
            "mouldId": "mould_id",
            "bladeSn": "blade_sn",
            "bladeRevision": "blade_revision",
            "layerId": "layer_P",
            "palletId": "pallet_1"
        },
        {
            "version": "v0.0.0",
            "mouldId": "mould_id",
            "bladeSn": "blade_sn",
            "bladeRevision": "blade_revision",
            "layerId": "layer_P",
            "palletId": "pallet_2"
        },
        {
            "version": "v0.0.0",
            "mouldId": "mould_id",
            "bladeSn": "blade_sn",
            "bladeRevision": "blade_revision",
            "layerId": "layer_P",
            "palletId": "pallet_3"
        },
    ]


@pytest.fixture
def sample_ev_session() -> dict:
    return {
        "cameraId": "aal-b9701u2-cam015",
        "moduleId": "edge-verification",
        "correlationId": "correlation_id",
    }


@pytest.fixture
def sample_graph_data():
    return {
        "mould_id": "mould_id",
        "blade_revision": "blade_revision",
        "plies": {
            "P1": {
                "layer_id": "layer_P",
                "pallet_id": "pallet_1",
                "previous_plies": [],
                "next_plies": ["P2"],
                "edges_covered": [],
                "dxf_id": "dxf_id_P",
                "dxf_ply_id": "dxf_ply_id_P1",
                "edges": ["P1.1", "P1.2"]
            },
            "P2": {
                "layer_id": "layer_P",
                "pallet_id": "pallet_1",
                "previous_plies": ["P1"],
                "next_plies": ["P3"],
                "edges_covered": ["P1.2"],
                "dxf_id": "dxf_id_P",
                "dxf_ply_id": "dxf_ply_id_P2",
                "edges": ["P2.1", "P2.2"]
            },
            "P3": {
                "layer_id": "layer_P",
                "pallet_id": "pallet_1",
                "previous_plies": ["P2"],
                "next_plies": [],
                "edges_covered": ["P2.2"],
                "dxf_id": "dxf_id_P",
                "dxf_ply_id": "dxf_ply_id_P3",
                "edges": ["P3.1", "P3.2"]
            },
            # TODO: test more upper layer ply covering sizes
            # TODO: test more possible cases with previous_plies and edges_covered
            # different upper ply which covers 1.5 or 2 plies
            "T1": {
                "layer_id": "layer_T",
                "pallet_id": "pallet_1",
                "previous_plies": ["P1", "P2"],
                # "next_plies": [], # TBD
                "edges_covered": ["P1.1", "P2.1"],  # if covers 1.5 plies
                # "edges_covered": ["P1.1", "P2.2"],  # How about this one ?
                # "edges_covered": ["P1.1", "P1.2"],    # if covers 1.5 plies
                # "edges_covered": ["P1.1", "P2.1", "P3.1"],  # if covers exactly 2 plies
                # "edges_covered": ["P1.1", "P1.2", "P2.2"],  # if covers exactly 2 plies
                # "edges_covered": ["P1.1", "P2.1", "P2.2 "],  # if covers exactly 2 plies
                # "edges_covered": ["P1.1", "P1.2", "P3.1"],  # if covers exactly 2 plies
                "dxf_id": "dxf_id_T",
                "dxf_ply_id": "dxf_ply_id_T1",
                "edges": ["T1.1", "T1.2"]
            },
            # upper ply which covers 2 plies or 2.5
            # "U1": {
            #     "layer_id": "layer_U",
            #     "pallet_id": "pallet_1",
            #     "previous_plies": ["P1", "P2", "P3"],  # (a
            #     # what ply covers what:
            #     # a) P1 covered by P2, P2 covered by P3; # then "edges_covered": ["P1.1", "P2.1", "P3.1"],
            #     # b) P3 covered by P2, P2 covered by P1; # then "edges_covered": ["P1.1", "P2.1", "P3.1"],
            #     # c) P2 covers P1 and P3; # then "edges_covered": ["P1.1", "P2.1", "P2.2"],
            #     # d) P1 and P3 covers P2; in this case should we keep in previous_plies all three or just two plies?
            #     # like "previous_plies": ["P1", "P3"]; # then "edges_covered": ["P1.1", "P1.2", "P3.1"],
            #     # Do we care about order in list, can we make assumptions when ignoring order?
            #     # "next_plies": [], # TBD
            #     "edges_covered": ["P1.1", "P2.1", "P3.1"],
            #     "dxf_id": "dxf_id_U",
            #     "dxf_ply_id": "dxf_ply_id_U1",
            #     "edges": ["U1.1", "U1.2"]
            # },
            # TODO: test more multi-teams situations with initial ply with previous_plies == []
            # Second ply with none previous plies, could be placed by second team working in parallel with other team
            "Z1": {
                "layer_id": "layer_Z",
                "pallet_id": "pallet_1",
                "previous_plies": [],
                "next_plies": ["Z1"],
                "edges_covered": [],
                # what if team1 working with other pallet should slip its last ply's edge P3.2 under Z1.1 edge? then:
                # "previous_plies": ["P3"],
                # "edges_covered": ["P3.2"],
                "dxf_id": "dxf_id_Z",
                "dxf_ply_id": "dxf_ply_id_Z1",
                "edges": ["Z1.1", "Z1.2"]
            },
            # Third ply with none previous plies, could be placed by third team working in parallel with other teams
            "E1": {
                "layer_id": "layer_E",
                "pallet_id": "pallet_1",
                "previous_plies": [],
                "next_plies": ["E1"],
                "edges_covered": [],
                "dxf_id": "dxf_id_E",
                "dxf_ply_id": "dxf_ply_id_E1",
                "edges": ["E1.1", "E1.2"]
            },
            "L1": {
                "layer_id": "layer_L",
                "pallet_id": "pallet_1",
                "previous_plies": [],
                "next_plies": ["L1"],
                "edges_covered": [],
                "dxf_id": "dxf_id_L",
                "dxf_ply_id": "dxf_ply_id_L1",
                "edges": ["L1.1", "L1.2"]
            },
            "PH1": {
                "layer_id": "layer_PH",
                "pallet_id": "pallet_1",
                "previous_plies": [],
                "next_plies": ["PH2"],
                "edges_covered": [],
                "dxf_id": "dxf_id_PH",
                "dxf_ply_id": "dxf_ply_id_PH1",
                "edges": []
            },
            "PH2": {
                "layer_id": "layer_PH",
                "pallet_id": "pallet_1",
                "previous_plies": ["PH1"],
                "next_plies": [],
                "edges_covered": ["PH1.1", "PH1.2"],
                "dxf_id": "dxf_id_PH",
                "dxf_ply_id": "dxf_ply_id_PH2",
                "edges": []
            },
        }
    }


@pytest.fixture
def sample_mould_state_plies() -> set:
    state_plies_mock = StatePliesMock()
    return {state_plies_mock.first_ply_partially_covered, state_plies_mock.second_ply_placed}


@pytest.fixture
def sample_global_mould_state_plies_data() -> dict:
    state_plies_mock = StatePliesMock()
    ply_1 = state_plies_mock.first_ply_partially_covered
    ply_2 = state_plies_mock.second_ply_placed
    return {
        f"/moulds/mould_id/plies/" + ply_1.id: ply_1.serialize(),
        f"/moulds/mould_id/plies/" + ply_2.id: ply_2.serialize(),
    }


@pytest.fixture
def sample_global_mould_state_instructions_data(sample_instructions_data) -> dict:
    return {
        f"/moulds/mould_id/instructions/layer_1-pallet_3": sample_instructions_data[0],
        f"/moulds/mould_id/instructions/layer_2-pallet_2": sample_instructions_data[1],
        f"/moulds/mould_id/instructions/layer_3-pallet_3": sample_instructions_data[2],
    }


@pytest.fixture
def sample_edge_to_cameras() -> dict:
    return {
        "mould_id": "mould_id",
        "blade_revision": "blade_revision",
        "edges": {
            "P1.1": ["cam1"],
            "P1.2": ["cam1"],
            "P2.1": ["cam1"],
            "P2.2": ["cam1", "cam2"],
            "P3.1": ["cam2"],
            "P3.2": ["cam2", "cam3"],
            "T1.1": ["cam1"],
            "T1.2": ["cam1"],
            "Z1.1": ["cam4"],
            "Z1.2": ["cam4"],
            "E1.1": [],
            "E1.2": ["cam5"],
            "L1.1": ["cam6"],
            "L1.2": ["cam6"],
        }
    }


@pytest.fixture
def etcd_container() -> EtcdContainer:
    return EtcdContainer()


@pytest.fixture
def sample_edge_verification_feedback() -> list:
    detected_edges = {"P2.1", "P2.2"}
    missing_edges = {"P1.1"}
    return [
        {
            "type": "detected-edges",
            "edges": list(detected_edges),
        },
        {
            "type": "missing-edges",
            "edges": list(missing_edges),
        }
    ]


@pytest.fixture
def sample_feedback_positions() -> dict:
    return {
        "mould_id": "mould_id",
        "blade_revision": "blade_revision",
        "plies": {
            "P1": {
                "mid_point": [1, 0, 1]
            },
            "P2": {
                "mid_point": [1, 0, 2]
            },
            "P3": {
                "mid_point": [1, 0, 3]
            },
            "T1": {
                "mid_point": [1, 1, 1]
            },
            "Z1": {
                "mid_point": [1, 0, 10]
            },
            "E1": {
                "mid_point": [1, 0, 20]
            },
            "L1": {
                "mid_point": [1, 0, 30]
            },
            "PH1": {
                "mid_point": [1, 1, 1]
            },
            "PH2": {
                "mid_point": [1, 1, 2]
            },
        }
    }


@pytest.fixture
def sample_feedback_data(sample_graph_data) -> dict:
    missing_plies = {
        "E1": sample_graph_data["plies"]["E1"],
    }
    plies_to_be_placed = {
        "P3": sample_graph_data["plies"]["P3"],
        "T1": sample_graph_data["plies"]["T1"],
    }
    phantom_plies = {
        "PH1": sample_graph_data["plies"]["PH1"],
        "PH2": sample_graph_data["plies"]["PH2"],
    }
    correctly_placed_plies = {
        "P2": sample_graph_data["plies"]["P2"],
        "Z1": sample_graph_data["plies"]["Z1"]
    }
    last_plies_placed = {
        "L1": sample_graph_data["plies"]["L1"],
    }
    plies_to_null = {
        "P1": sample_graph_data["plies"]["P1"],
    }
    feedback_data = {
        "missing-plies": missing_plies,
        "plies-to-be-placed": plies_to_be_placed,
        "phantom-plies": phantom_plies,
        "correctly-placed-plies": correctly_placed_plies,
        "last-plies-placed": last_plies_placed,
        "plies-to-null": plies_to_null,
    }
    return feedback_data
