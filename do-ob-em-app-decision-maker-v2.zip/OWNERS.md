# Authors
- Grigorij Kaplan - IBM (grigorij.kaplan@lt.ibm.com)
- Martynas Skaringa - IBM (martynas.skaringa@ibm.com)
- Zaiyong Zhang - SGRE (zaiyong.zhang@siemensgamesa.com)