# do-ob-em-app-decision-maker-v2
![Python](https://img.shields.io/badge/Python-3.9-informational)
![Docker](https://img.shields.io/badge/image-amd64/python:3.9.0--slim--buster-informational)

![azure-iot-device](https://img.shields.io/badge/azure--iot--device-v2.4.0-informational)
![azure-iot-device (latest)](https://img.shields.io/pypi/v/azure--iot--device?label=latest)

![prometheus-python](https://img.shields.io/badge/prometheus--client-v0.12.0-informational)
![prometheus-python (latest)](https://img.shields.io/pypi/v/prometheus--client?label=latest)

[![Build Status](https://siemensgamesa.visualstudio.com/SGRE%20Digital%20Transformation/_apis/build/status/do-ob-em-app-decision-maker-v2?branchName=master)](https://siemensgamesa.visualstudio.com/SGRE%20Digital%20Transformation/_build/latest?definitionId=656&branchName=master)

# Introduction
~~Sample IoT Edge module which can be used as a baseline for any other module using MQTT and if needed Triton Inference
Server. This module supposed to be overriden and tailored according to target use case. Module's design conforms to
diagram below:~~
![IoT Module](../blade-inspection-wiki/.attachments/architecture/diagrams/iot-module-pattern/IoT%20Module%20pattern.svg)

# Customizing module for specific use case

~~Module assumes that you are deploying it as IoT Hub Edge deployment module and it should delegate inference logic to
external Triton Inference Server service. Typically this flow supposed to be followed `pre-processor` -> `inference`
-> `post-processor`. These are the extension points which developers should change:~~

~~* `app/processors/preprocessor.py` - `RequestPreprocessor.run` function should be overriden/corrected according to the
use case. Typically this part should parse MQTT payload and read image files into memory
~~* `app/processors/default.py` - `DefaultProcessor.run` function should be overriden/corrected according to the use
case. Typically this part invokes preprocessor, inference server and postprocessor.~~
~~* `app/processors/postprocessor.py` - `ResponsePostprocessor.run` function should be overriden/corrected according to
the use case. Typically this part should alter/save inference results if that is needed.~~~~

###### TODO: Update readme for current codebase structure

# Environment variables

Module can be configured using env variables and overridden by C2DM request or routed input messages

| Parameter      | Default value                                      | Overridable by C2DM  | Overridable by Msg | Description                                                                                            |
| -------------- | -------------------------------------------------- | --------------- | --------------- | ------------------------------------------------------------------------------------------------------ |
| MODULE_APP_NAME | decision-maker |  No | No | Edge Module's application name |
| DATA_PROVISIONING_PATH |  |  No | No | Path to data provisioning files | 
| STATIC_GRAPH_FILE_SUFFIX | static-graph |  No | No | static graph file name suffix (_mould_id-blade_revision-static-graph.json_)| 
| CAMERAS_MAPPING_FILE_SUFFIX | edge-to-cameras |  No | No | edge to cameras file name suffix (_mould_id-blade_revision-edge-to-cameras.json_)|
| FEEDBACK_POSITIONS_FILE_SUFFIX | feedback-positions |  No | No | feedback positions file name suffix (_mould_id-blade_revision-feedback-positions.json_)|
| MOULD_ID |  |  Yes | No | Preconfigured Mould Id |
| LOG_LEVEL | 20 |  Yes | Yes | Default log level |
| ETCD_URL | localhost:2379 | Yes | No | etcd service hostname:port |
| ETCD_TTL | 600 | Yes | No | etcd service ttl |
| LASER_MARK_SIZE | 200 | Yes | No | feedback laser figure size in mm  |
| LONG_LIVED_LASER_MARK_TTL | 600 | Yes | No | laser mark expiration time in seconds for missing-plies and plies-to-be-placed |
| SHORT_LIVED_LASER_MARK_TTL | 20 | Yes | No | laser mark expiration time in seconds for correctly-placed-plies |
| PROMETHEUS_PORT | 9060 | Yes | No | Port exposed for Prometheus |
| MOULD_ID | None | Yes | No | ID of mould being used |
| IOTEDGE_DEVICEID | None | Yes | No | ID of device being used |
| IOTEDGE_MODULEID | None | Yes | No | ID of device being used |

### Install dependencies
```
pip3 install -r requirements.txt
```

### Run Pylint locally
````
find . -type f -name "*.py" | xargs pylint --fail-under=8 || pylint-exit $?
```

### Run IT (Integration Test)
```
export PYTHONPATH='./'
pytest it
```

# Test
### Install dependencies
```
pip3 install -r requirements-tests.txt
```
### Run unit test
```
export PYTHONPATH='./'
pytest tests/
```
