""" Module Listener - main entrypoint to application """
import asyncio
import time

from azure.iot.device.aio import IoTHubModuleClient

import app.config as cfg
from app.decision_maker import DecisionMaker
from app.handler.cloud_to_device_method_handler import CloudToDeviceMethodHandler
from app.handler.input_message_handler import InputMessageHandler
from app.messaging_wrapper import MessagingWrapper
from app.models.payload_metadata import PayloadMetadata
from app.module_initializer import ModuleInitializer
from app.shared_storage import SharedStorage
from app.logging.logger import yield_logger

log = yield_logger()

class MessageListener:
    """ Module Listener to listen for Edge Hub module routed Input Messages and C2DM requests. """

    def __init__(self):
        try:
            log.info("Creating IoT Hub module client...")
            self._module_client = IoTHubModuleClient.create_from_edge_environment()

            log.info("Initializing Decision Maker services...")
            shared_storage = SharedStorage(cfg.ETCD_URL, cfg.ETCD_TTL)
            self._messaging = MessagingWrapper(self._module_client)

            self._team_instructions, mould_state = ModuleInitializer(shared_storage).run()

            self._decision_maker = DecisionMaker(shared_storage, self._messaging, self._team_instructions, mould_state)

        except Exception as ex:
            raise SystemExit(f"Failed to initialize Decision Maker module, due to: {ex}")

    async def run(self) -> None:
        """ Main entrypoint - method to start Edge Hub module client listeners. """
        try:
            log.info("Connecting hub module client to IoT Edge Hub...")
            await self._module_client.connect()

            log.info("Module client connected. Starting IoT Hub module client listeners...")
            input_message_handler = InputMessageHandler(self._decision_maker, self._messaging)
            self._module_client.on_message_received = input_message_handler.handle

            cloud_to_device_method_handler = CloudToDeviceMethodHandler(self._decision_maker, self._messaging)
            self._module_client.on_method_request_received = cloud_to_device_method_handler.handle
            log.info("Module Listener started listening for Routed Input Messages and C2DM requests")

            if self._team_instructions.data:
                log.info("Handling Team Instructions preloaded from ETCD store on boot...")
                metadata_to_forward = PayloadMetadata()
                await self._decision_maker.process_team_instructions_changes(metadata_to_forward)

            # Run the empty listener in the event loop to keep module always running
            asyncio_event_loop = asyncio.get_event_loop()
            asyncio_event_loop.run_in_executor(None, self._empty_listener)

        except Exception as ex:
            raise SystemExit(f"Failed to start Decision Maker module client listeners, due to {ex}")

    @staticmethod
    def _empty_listener() -> None:
        """ Empty listener to keep module always running. """
        while True:
            time.sleep(600) # nosemgrep: python.lang.best-practice.sleep.arbitrary-sleep
