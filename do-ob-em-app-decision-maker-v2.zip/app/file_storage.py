""" File Storage module for loading data from file system. """

import os
from os.path import isfile

import app.config as cfg
from app.models.edge_cameras import EdgeCameras
from app.models.feedback_positions import FeedbackPositions
from app.models.graph import Graph
from app.models.team_instructions import TeamInstructions
from app.utils import load_json_from_file, merge_dicts_of_data_structures
from app.logging.logger import yield_logger

log = yield_logger()


def get_static_graph(team_instructions: TeamInstructions) -> Graph:
    """ Returns Graph loaded with static graph data from file system. """
    file_suffix = cfg.STATIC_GRAPH_FILE_SUFFIX
    data = _read_files(file_suffix, team_instructions)
    return Graph(data)


def get_edge_cameras(team_instructions: TeamInstructions) -> EdgeCameras:
    """ Returns EdgeCameras loaded with edge-to-cameras data from file system. """
    file_suffix = cfg.CAMERAS_MAPPING_FILE_SUFFIX
    data = _read_files(file_suffix, team_instructions)
    return EdgeCameras(data)


def get_feedback_positions(team_instructions: TeamInstructions) -> FeedbackPositions:
    """ Returns FeedbackPositions loaded with feedback-positions data from file system. """
    file_suffix = cfg.FEEDBACK_POSITIONS_FILE_SUFFIX
    data = _read_files(file_suffix, team_instructions)
    return FeedbackPositions(data)


def _read_files(file_suffix: str, team_instructions: TeamInstructions) -> dict:
    """ Reads file from file system for given filepath (parameters). """
    mould_id = team_instructions.mould_id
    blade_revision = team_instructions.blade_revision
    ground_truth_version = team_instructions.ground_truth_version
    layer_ids = team_instructions.layer_ids

    path = cfg.DATA_PROVISIONING_PATH

    merged_files_data: dict = {}

    for layer_id in sorted(layer_ids):
        file_name = _get_file_name(mould_id, blade_revision, layer_id, file_suffix)
        file_path = _get_file_path(path, mould_id, ground_truth_version, file_name)
        file_data = _attempt_to_read(file_path)
        if file_data:
            _validate(file_data, file_path, mould_id, blade_revision)
            merged_files_data = merge_dicts_of_data_structures(merged_files_data, file_data)
        else:
            error_message = f"Failed to load {file_suffix} for given mould_id: {mould_id}, " \
                            f"blade_revision: {blade_revision}, ground_truth_version: {ground_truth_version} " \
                            f"and layer_ids: {layer_ids} taken from Team Instructions."
            raise ValueError(error_message) from None

    return merged_files_data


def _get_file_path(path: str, folder_name: str, ground_truth_version: str, file_name: str) -> str:
    file_path = os.path.join(path, folder_name, ground_truth_version, file_name)
    return file_path


def _get_file_name(mould_id: str, blade_revision: str, layer_id: str, file_suffix: str) -> str:
    file_name = f"{mould_id}-{blade_revision}-{layer_id}-{file_suffix}.json"
    return file_name


def _attempt_to_read(file_path: str) -> dict:
    log.info("Attempting to read file: %s", file_path)
    if isfile(file_path):
        log.info("Found file: '%s', loading....", file_path)
        return load_json_from_file(file_path)
    else:
        log.warning("Did not found file: '%s'", file_path)


def _validate(file_data: dict, file_path: str, mould_id: str, blade_revision: str) -> None:
    if _is_matching(file_data, mould_id, blade_revision):
        log.info("Successfully loaded %s from file", file_path)
    else:
        error_message = f"Data in file: {file_path}, do not match given mould_id: {mould_id} " \
                        f"and blade_revision: {blade_revision} from Team Instructions."
        raise ValueError(error_message)


def _is_matching(file_data: dict, mould_id: str, blade_revision: str) -> bool:
    try:
        return file_data["mould_id"] == mould_id and file_data["blade_revision"] == blade_revision
    except KeyError as ex:
        error_message = f"Missing mould_id or blade_revision attribute: {ex}, in file"
        raise Exception(error_message) from None
