""" Utility functions """
import copy
import json
import os
from collections import deque
from copy import deepcopy
from os import access, R_OK
from os.path import isfile
from app.logging.logger import yield_logger

log = yield_logger()


def load_json_from_file(path: str) -> dict:
    """ Reads JSON from file, parses and returns content as dict type. """
    log.info("Checking R/O file %s", path)
    assert isfile(path) and access(path, R_OK), f"File {path} doesn't exist or isn't readable"
    filesize = os.path.getsize(path)
    if filesize == 0:
        raise ValueError(f"Can't process empty file: {path}")

    try:
        with open(path, "r", encoding="utf-8") as file_handle:
            file_content = file_handle.read()
            return json.loads(file_content)
    except (OSError, IOError) as exc:
        log.error("Error parsing file %s: \t %s", path, exc)


def flatten(list_of_lists: list[list]) -> list:
    """ Flattens given list of lists"""
    flat_list = []
    for sublist in list_of_lists:
        for item in sublist:
            flat_list.append(item)
    return flat_list


def dict_of_dicts_merge(x: dict, y: dict) -> dict:
    z = {}
    overlapping_keys = x.keys() & y.keys()
    for key in overlapping_keys:
        z[key] = dict_of_dicts_merge(x[key], y[key])
    for key in x.keys() - overlapping_keys:
        z[key] = deepcopy(x[key])
    for key in y.keys() - overlapping_keys:
        z[key] = deepcopy(y[key])
    return z


def merge_dicts_of_data_structures(dict_1: dict, dict_2: dict) -> dict:
    merged_dict = {**dict_2}
    for key, value in merged_dict.items():
        if key in dict_1 and key in dict_2:
            _merge_dicts_only(dict_1, key, value, merged_dict)

    return merged_dict


def _merge_dicts_only(dict_1: dict, key: dict, value: dict, merged_dict: dict) -> None:
    if isinstance(value, dict) and isinstance(dict_1[key], dict):
        merged_dict[key] = {**value, **dict_1[key]}


def dict_subtract(a: dict, b: dict) -> dict:
    subtracted_dict = copy.deepcopy(a)
    consume = deque(maxlen=0).extend
    consume(subtracted_dict.pop(key, None) for key in b)
    return subtracted_dict
