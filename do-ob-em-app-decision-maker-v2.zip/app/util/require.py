""" Utility functions """
from typing import Iterable
from app.logging.logger import yield_logger

log = yield_logger()


def not_empty(value: Iterable, value_name: str) -> None:
    if not value:
        error_message = f"'{value_name}' must not be empty or None."
        log.error(error_message)
        raise ValueError(error_message)


def not_none(value, value_name: str) -> None:
    if value is None:
        error_message = f"'{value_name}' must not be None."
        log.error(error_message)
        raise ValueError(error_message)
