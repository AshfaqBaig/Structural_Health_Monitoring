""" Preconfigures Application Wide Logging """
import logging.config
import os
from logging import Logger
from os.path import exists

import app.config as cfg

LOGGER_CONFIG_LOCATIONS = [
    os.path.join(os.sep, os.path.dirname(os.path.abspath(__file__)), "..", "..", cfg.LOGGER_CONFIG),
    f"./app/{cfg.LOGGER_CONFIG}",
    f"./{cfg.LOGGER_CONFIG}",
]


def yield_logger() -> logging.Logger:
    """ Preconfigures application wide logging system and returns logger. """
    logging_file_config = locate_logger_config()
    logging.config.fileConfig(logging_file_config)
    return logging.getLogger(cfg.MODULE_APP_NAME)


def locate_logger_config():
    """ Locate logger config which can be placed in different locations """
    for location in LOGGER_CONFIG_LOCATIONS:
        if exists(location):
            return location
    raise FileNotFoundError("Logging config not found")


def update_log_level(log: Logger, log_level: str) -> None:
    """ Update log level for given logger and its handlers. """
    log.setLevel(log_level)
    for handler in log.handlers:
        handler.setLevel(log_level)
    log.info(f"Updated log level to {log.level} for {log.name} logger")
