""" Helper function to validate data from edge verification feedback message. """
from app.dm_helper import graph_resolver
from app.logging.logger import yield_logger
from app.models.state.mould_state import MouldState

log = yield_logger()


def validate(detected_edges: set, missing_edges: set, mould_state: MouldState) -> None:
    """
    Validates given detected and missing edges, from edge verification message.
    Raises ValueError exception if detected_edges or missing_edges are not expected nor visible.
    """
    detected_edges_states_to_verify, missing_edges_states_to_verify = mould_state.get_edges_to_verify()
    valid_edges_states = detected_edges_states_to_verify | missing_edges_states_to_verify
    valid_edges = graph_resolver.edges_from(valid_edges_states)

    # should verify both to validate edge verification message
    _verify("detected-edges", detected_edges, valid_edges)
    _verify("missing-edges", missing_edges, valid_edges)


def _verify(edges_type: str, edges: set, valid_edges: set) -> None:
    if not edges.issubset(valid_edges):
        warning_message = f"Invalid edge verification data received, {edges_type}: {edges}, " \
                          f"is not subset of valid edges (expected or visible)."
        log.warning(warning_message)
        raise ValueError(warning_message)
