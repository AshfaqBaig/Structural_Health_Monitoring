""" Module to send Feedback data """
import app.config as cfg
from app.messaging_wrapper import MessagingWrapper
from app.models.graph import Graph
from app.models.team_instructions import TeamInstructions
from app.models.payload_metadata import PayloadMetadata
from collections import OrderedDict
from app.logging.logger import yield_logger

log = yield_logger()

class LaserFeedback:
    """" Class for sending laser feedback data to LF module. """

    def __init__(self, messaging: MessagingWrapper, graph: Graph, team_instructions: TeamInstructions):
        self._messaging = messaging
        self._graph = graph
        self._team_instructions = team_instructions

    async def invoke(self, feedback_data: dict[str, dict], metadata_to_forward: PayloadMetadata) -> None:
        """
        Method invocation process given feedback data, creates payloads and sends to FB module.

        Different feedback_type messages can be generated and sent: "missing-plies", "plies-to-be-placed",
        "correctly-placed-plies", "phantom-plies" , "last-plies-placed" and "plies-to-null" for clearing laser marks.
        The difference in feedback_type messages is expiration values, session keys and feedback items.
        One reason for different feedback message types is their display time, "correctly-placed-plies" should be
        displayed only for shorter period (20s), while "missing-plies", "last-plies-placed" and "plies-to-be-placed"
        for longer period (600s) or until placed correctly on the mould. While "plies-to-null" used to reset plies.

        In case TTL passes but ply is not placed correctly, human shall stir one of the plies to provoke changes in DM.

        :param feedback_data: contains map of "missing-plies", "plies-to-be-placed", "correctly-placed-plies",
        "last-plies-placed", "phantom-plies" and "plies-to-null".
        :param metadata_to_forward: contains metadata to forward to laser modules.
        """
        log.debug("Initiating laser feedback data processing for feedback_data: %s", feedback_data)
        if feedback_data == {}:
            warning_message = f"Nothing to process, empty or None feedback_data given: {feedback_data}"
            log.warning(warning_message)

        for feedback_type, plies in feedback_data.items():
            if plies == {} or plies is None:
                warning_message = f"Can't process empty or None plies for feedback_type: {feedback_type}," \
                                  f" in given feedback_data: {feedback_data}"
                log.warning(warning_message)
                continue
            await self._create_feedback_items_and_send(plies, feedback_type, metadata_to_forward)

    async def _create_feedback_items_and_send(self, plies, feedback_type: str, metadata: PayloadMetadata) -> None:
        log.debug("Creating laser feedback items of type: %s, for plies: %s.", feedback_type, set(plies))
        sorted_plies = OrderedDict(sorted(plies.items()))
        for ply_id, ply_data in sorted_plies.items():
            refactored_ply_data = {k: v for k, v in ply_data.items() if k not in ["edges", "edges_covered"]}
            # TODO: refactor
            refactored_ply_data["next_plies_pallets"] = self._graph.get_next_plies_pallets(ply_id)
            payload = {"metadata": {
                "session": {
                    "mouldId": cfg.MOULD_ID,
                    "plyId": ply_id,
                    "moduleId": "em-decision-maker"
                },
                "groundTruthVersion": self._team_instructions.ground_truth_version,
                "mouldId": self._team_instructions.mould_id,
                "bladeSn": self._team_instructions.blade_sn,
                "bladeRevision": self._team_instructions.blade_revision,
                "layers": sorted(list(self._team_instructions.layer_ids)),
            },
                "feedback": [
                    {"type": feedback_type,
                     ply_id: refactored_ply_data
                     }
                ],
                "feedbackType": feedback_type
            }
            await self._send(payload, metadata)

    async def _send(self, payload: dict, metadata_to_forward: PayloadMetadata) -> None:
        log.debug("Sending payload to LF module: %s", payload)
        await self._messaging.send_message_to_feedback(payload, metadata_to_forward)

    async def clear(self, all_mould_state_plies: dict, metadata_to_forward: PayloadMetadata) -> None:
        """ Sends all laser feedback types as empty dicts to clear DM module sessions with LF module and LH. """
        log.info("Clearing DM module sessions with LF module and Laser hub...")

        # TODO: later implement more performant version to clear just all missing, all to be placed, an correctly placed
        feedback_to_send = {"plies-to-null": all_mould_state_plies}

        await self.invoke(feedback_to_send, metadata_to_forward)
