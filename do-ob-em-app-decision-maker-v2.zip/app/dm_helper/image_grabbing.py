# pylint: disable=missing-module-docstring

import app.config as cfg
from app.messaging_wrapper import MessagingWrapper
from app.models.payload_metadata import PayloadMetadata
from app.logging.logger import yield_logger

log = yield_logger()

class ImageGrabbing:
    def __init__(self, messaging: MessagingWrapper):
        self._messaging = messaging

    async def start_update(self, camera_ids: set[str], refresh_interval: int, metadata: PayloadMetadata) -> None:
        if not camera_ids:
            log.debug(f"Got empty cam list for {refresh_interval}s refresh interval, skipping IG update.")
            return

        log.debug(f"Starting image grabbing for cams: {camera_ids}, with {refresh_interval}s interval.")
        payload = self._create_payload(camera_ids, "start_capture", refresh_interval)
        await self._messaging.send_message_to_image_grabber(payload, metadata)

    async def stop(self, camera_ids: set[str], metadata: PayloadMetadata) -> None:
        log.debug("Stopping image grabbing process.")
        payload = self._create_payload(camera_ids, "stop_capture")
        await self._messaging.send_message_to_image_grabber(payload, metadata)

    @staticmethod
    def _create_payload(camera_ids: set, command: str, refresh_interval_in_seconds: int = None) -> dict:
        payload = {}
        for camera_id in camera_ids:
            payload[camera_id] = {
                "command": command,
                "metadata": {
                    "session": {"mouldId": cfg.MOULD_ID}
                }
            }
            if refresh_interval_in_seconds is not None:
                payload[camera_id] |= {
                    "params": {
                        "refresh_interval_in_seconds": refresh_interval_in_seconds
                    }
                }
        return payload
