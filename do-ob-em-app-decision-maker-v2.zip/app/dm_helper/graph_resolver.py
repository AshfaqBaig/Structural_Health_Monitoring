from app.models.graph import Graph
from app.models.state.edge_state import EdgeState
from app.models.state.ply_state import PlyState


def plies_from(mould_state_plies: set[PlyState], graph: Graph) -> dict:
    """ Resolves graph plies from given graph and mould state type plies. """
    graph_plies = {}
    for state_ply in mould_state_plies:
        graph_ply = graph.get_ply(state_ply.id)
        graph_plies.update({state_ply.id: graph_ply})
    return graph_plies


def edges_from(mould_state_edges: set[EdgeState]) -> set[str]:
    """ Resolves graph edges from given mould state type edges. """
    return {state_edge.id for state_edge in mould_state_edges}
