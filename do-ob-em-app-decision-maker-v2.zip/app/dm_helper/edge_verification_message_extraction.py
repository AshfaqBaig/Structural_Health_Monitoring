""" Helper function to extract data from edge verification feedback message """


def detected_and_missing_edges(feedback: list) -> tuple[set, set]:
    """ Extract found and missing edges from feedback in edge verification message received from EV module. """
    detected_edges = _extract("detected-edges", feedback)
    missing_edges = _extract("missing-edges", feedback)
    return detected_edges, missing_edges


def _extract(edges_type: str, feedback: list) -> set:
    return set(*[item["edges"] for item in feedback if item["type"] == edges_type])
