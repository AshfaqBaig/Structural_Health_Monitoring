""" App config parameters """
import logging
import os

# env var
from distutils.util import strtobool

LOGGER_CONFIG = os.getenv("LOGGER_CONFIG", "logging-plain.ini")

PROMETHEUS_PORT = int(os.getenv("PROMETHEUS_PORT", 9060))
METRIC_LABELS = ["device_id", "module_id", "mould_id"]

MODULE_APP_NAME = "decision-maker"

IOTEDGE_MODULEID = os.getenv("IOTEDGE_MODULEID")
IOTEDGE_DEVICEID = os.getenv("IOTEDGE_DEVICEID")
IOTEDGE_GATEWAYHOSTNAME = os.environ.get("IOTEDGE_GATEWAYHOSTNAME")
DEVICE_MODULE_ID = f"{IOTEDGE_DEVICEID}-{IOTEDGE_MODULEID}"

DATA_PROVISIONING_PATH = os.getenv("DATA_PROVISIONING_PATH")
STATIC_GRAPH_FILE_SUFFIX = os.getenv("STATIC_GRAPH_FILE_SUFFIX", "static-graph")
CAMERAS_MAPPING_FILE_SUFFIX = os.getenv("CAMERAS_MAPPING_FILE_SUFFIX", "edge-to-cameras")
FEEDBACK_POSITIONS_FILE_SUFFIX = os.getenv("FEEDBACK_POSITIONS_FILE_SUFFIX", "feedback-positions")

# -1 should disable feature and verify all placed verifiable plies
# 0 should not validate any placed plies only plies_to_be_placed
# n should not validate any placed plies up to n-th ply and only
NUMBER_OF_PLACED_PLIES_TO_VERIFY = int(os.getenv("NUMBER_OF_PLACED_PLIES_TO_VERIFY", -1))

ACTIVE_EDGE_VERIFICATION_REFRESH_INTERVAL = int(os.getenv("ACTIVE_EDGE_VERIFICATION_REFRESH_INTERVAL", 5))
PASSIVE_EDGE_VERIFICATION_REFRESH_INTERVAL = int(os.getenv("PASSIVE_EDGE_VERIFICATION_REFRESH_INTERVAL", 60))

FF_EDGE_DETECTION_STRICT = bool(strtobool(os.getenv("FF_EDGE_DETECTION_STRICT", "False")))
FF_PLY_PLACED_STRICT = bool(strtobool(os.getenv("FF_PLY_PLACED_STRICT", "True")))
FF_REMOVE_INVISIBLE_EDGES_ON_GRAPH_LOAD = bool(
    strtobool(os.getenv("FF_REMOVE_INVISIBLE_EDGES_ON_GRAPH_LOAD", "True")))
FF_ENABLE_CHAINED_STATE_SHARE = bool(strtobool(os.getenv("FF_ENABLE_CHAINED_STATE_SHARE", "False")))
FF_FILTER_MISSING_PLIES_LIKELY_BEING_COVERED = bool(
    strtobool(os.getenv("FF_FILTER_MISSING_PLIES_LIKELY_BEING_COVERED", "True")))

LOCATION_ID = os.getenv("LOCATION_ID")
HALL_ID = os.getenv("HALL_ID")
MOULD_ID = os.getenv("MOULD_ID")

LOG_LEVEL = os.getenv("LOG_LEVEL", logging.DEBUG)

ETCD_URL = os.getenv("ETCD_URL", "localhost:2379")
ETCD_TTL = int(os.getenv("ETCD_TTL", 600))
