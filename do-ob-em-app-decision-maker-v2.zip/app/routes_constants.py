""" Edge Hub routes constants """

DEFAULT_INPUT = "defaultInput"

DEFAULT_OUTPUT = "defaultOutput"
ERROR_OUTPUT = "errorOutput"
FEEDBACK_OUTPUT = "feedbackOutput"
START_STREAMING_OUTPUT = "startStreamingOutput"
EDGE_VERIFICATION_OUTPUT = "edgeVerificationOutput"
TRACE_OUTPUT = "traceOutput"
STATS_OUTPUT = "statsOutput"
