""" Messaging Wrapper """
import json

from azure.iot.device import Message, MethodResponse
from azure.iot.device.aio import IoTHubModuleClient
from azure.iot.device.exceptions import ClientError

import app.config as cfg
from app import routes_constants
from app.logging.logger import yield_logger
from app.models.payload_metadata import PayloadMetadata
from app.util import require

log = yield_logger()


class MessagingWrapper:
    """ Messaging Wrapper for Edge Hub routed messages """

    def __init__(self, module_client: IoTHubModuleClient):
        self._module_client = module_client

    async def send_c2dm_response(self, response: MethodResponse) -> None:
        """ Send a cloud to device method response to a method request. """
        try:
            await self._module_client.send_method_response(response)
            log.info("Successfully sent C2DM response.")
        except ClientError:
            log.exception(f"Failed to send C2DM response.")

    async def send_message_to_default_output(self, message, metadata: PayloadMetadata) -> None:
        """ Sends a message to default output """
        await self._send_message(message, routes_constants.DEFAULT_OUTPUT, metadata)

    async def send_message_to_error_output(self, message, metadata: PayloadMetadata) -> None:
        """ Sends a message to error output """
        await self._send_message(message, routes_constants.ERROR_OUTPUT, metadata)

    async def send_message_to_feedback(self, message, metadata: PayloadMetadata) -> None:
        """ Sends a message to feedback output """
        await self._send_message(message, routes_constants.FEEDBACK_OUTPUT, metadata)

    async def send_message_to_image_grabber(self, message, metadata: PayloadMetadata) -> None:
        """ Sends a message to start streaming output """
        await self._send_message(message, routes_constants.START_STREAMING_OUTPUT, metadata)

    async def send_message_to_edge_verification(self, message, metadata: PayloadMetadata) -> None:
        """ Sends a message to edge verification output """
        await self._send_message(message, routes_constants.EDGE_VERIFICATION_OUTPUT, metadata)

    async def send_message_to_trace(self, message, metadata: PayloadMetadata) -> None:
        """ Sends a message to trace output """
        metadata.content_type = f"{cfg.MODULE_APP_NAME}-trace"
        await self._send_message(message, routes_constants.TRACE_OUTPUT, metadata)

    async def send_message_to_stats(self, message, metadata: PayloadMetadata) -> None:
        """ Sends a message to stats output """
        metadata.content_type = f"{cfg.MODULE_APP_NAME}-stats"
        await self._send_message(message, routes_constants.STATS_OUTPUT, metadata)

    async def _send_message(self, message, output_name, metadata: PayloadMetadata) -> None:
        """ Sends a message to Edge Hub routed output """
        log.debug(
            f"Sending to: {output_name}, message: {message}; "
            f"(correlation_id={metadata.correlation_id} custom_properties={metadata.custom_properties})",
            extra={"correlation_id": metadata.correlation_id}
        )
        require.not_none(metadata, "metadata")
        amqp_message = Message(data=json.dumps(message))
        amqp_message.correlation_id = metadata.correlation_id
        amqp_message.custom_properties = metadata.custom_properties
        amqp_message.content_type = metadata.content_type
        await self._module_client.send_message_to_output(amqp_message, output_name)
