from enum import Enum


class GlobalMouldState(Enum):
    NONE = 1
    PRODUCTION = 2
    FINALISED = 3

    @classmethod
    def value_of(cls, value):
        for k, v in cls.__members__.items():
            if value is None:
                return GlobalMouldState.NONE
            if k == value:
                return v
        else:
            raise ValueError(f"'{cls.__name__}' enum not found for '{value}'")
