""" Module for Team Instructions storage """
import app.config as cfg
from app.logging.logger import yield_logger
from app.util import require

log = yield_logger()

class TeamInstructions:
    """ Class for storing Team Instructions and manipulating its data """

    def __init__(self, team_instructions_data: list[dict] = None):
        self._stored_team_instructions_data: list[dict] = []
        if team_instructions_data:
            self._store(team_instructions_data)

    @property
    def data(self) -> list[dict]:
        """ Get stored team instructions data. """
        return self._stored_team_instructions_data

    @property
    def mould_id(self) -> str:
        """ Get the mould_id assigned to Team Instructions. """
        return self._stored_team_instructions_data[0]["mouldId"]

    @property
    def blade_sn(self) -> str:
        """ Get the blade_sn assigned to Team Instructions. """
        return self._stored_team_instructions_data[0]["bladeSn"]

    @property
    def blade_revision(self) -> str:
        """ Get the blade_revision assigned to Team Instructions. """
        return self._stored_team_instructions_data[0]["bladeRevision"]

    @property
    def layer_ids(self) -> set[str]:
        """ Get all layer ids from Team Instructions. """
        return {team_instruction["layerId"] for team_instruction in self.data}

    @property
    def ground_truth_version(self) -> str:
        """ Get the ground truth version assigned to Team Instructions. """
        return self._stored_team_instructions_data[0]["version"]

    def _store(self, team_instructions_data: list) -> None:
        """ Stores filtered Team Instructions and checks if (mould_id, blade_revision) combination are homogenous. """
        log.info("Initiating Team Instructions instance with data: %s", team_instructions_data)
        require.not_empty(team_instructions_data, "team_instructions_data")
        for team_instructions in team_instructions_data:
            TeamInstructions._apply_lowercase(team_instructions)

        mould_team_instructions = TeamInstructions._filter_mould_team_instructions(team_instructions_data)
        self._stored_team_instructions_data = mould_team_instructions
        log.info("Stored Team Instructions after initiation: %s", self._stored_team_instructions_data)

    def update(self, team_instruction_update: dict) -> None:
        """ Method to update Team Instructions with given team_instruction. """
        require.not_empty(team_instruction_update, "team_instruction_update")
        TeamInstructions._apply_lowercase(team_instruction_update)

        if self._stored_team_instructions_data is not None:
            self._merge(team_instruction_update)
            log.info(f"Stored Team Instructions after the merge: {self._stored_team_instructions_data}")
        else:
            raise ValueError(f"Can't update Team Instructions while DM is not loaded with initial instructions.")

    @staticmethod
    def _apply_lowercase(team_instruction: dict) -> None:
        for k, v in team_instruction.items():
            properties_to_ignore = {"layerId", "palletId"}
            if k in properties_to_ignore:
                continue
            team_instruction[k] = v.lower()

    def _merge(self, team_instruction_update: dict) -> None:
        log.info(f"Merging team instruction: {team_instruction_update}")
        
        mould_team_instruction = TeamInstructions._filter_mould_team_instructions([team_instruction_update])

        if mould_team_instruction not in self._stored_team_instructions_data:
            self._stored_team_instructions_data.append(team_instruction_update)
        else:
            log.warning(f"Given team_instruction_update: {team_instruction_update}, already exists locally!")

    @staticmethod
    def _filter_mould_team_instructions(team_instructions: list) -> list:
        mould_team_instructions = TeamInstructions._filter_by_mould_id(team_instructions, cfg.MOULD_ID)
        if not mould_team_instructions:
            log.warning(
                "Unable to find any team instruction for mould_id = %s in given team_instructions: %s",
                cfg.MOULD_ID,
                team_instructions
            )
            return []

        TeamInstructions._validate(mould_team_instructions)
        return mould_team_instructions

    @staticmethod
    def _validate(mould_team_instructions: list) -> None:
        """ Validate that mould team instructions have homogenous mould_id, blade_revision and version combinations. """
        blade_revisions = TeamInstructions._extract_all_blade_revisions(mould_team_instructions)
        versions = TeamInstructions._extract_all_versions(mould_team_instructions)
        if len(blade_revisions) != 1 or len(versions) != 1:
            error_message = f"Filtered mould_team_instructions: {mould_team_instructions}\n" \
                            f"have different, not homogenous (mould_id, blade_revision, version) combinations. " \
                            f"Found blade_revisions: {blade_revisions} " \
                            f"and versions: {versions}, for mould_id: {cfg.MOULD_ID}."
            raise ValueError(error_message)

    @staticmethod
    def _filter_by_mould_id(team_instructions: list, cfg_mould_id: str) -> list:
        mould_team_instructions = []
        for team_instruction in team_instructions:
            if team_instruction["mouldId"] == cfg_mould_id:
                mould_team_instructions.append(team_instruction)
            else:
                log.warning(
                    """Skipping team instruction for mould_id %s because module is configured for mould_id %s""",
                    team_instruction["mouldId"],
                    cfg_mould_id,
                )
        return mould_team_instructions

    @staticmethod
    def _extract_all_blade_revisions(team_instructions: list) -> set:
        blade_revisions = set()
        for team_instruction in team_instructions:
            blade_revisions.add(team_instruction["bladeRevision"])
        return blade_revisions

    @staticmethod
    def _extract_all_versions(team_instructions: list) -> set:
        versions = set()
        for team_instruction in team_instructions:
            versions.add(team_instruction["version"])
        return versions

    def is_matching(self, ply: dict) -> bool:
        """
        Checks if given ply matches current team instructions.
        Ply is matching if ply's (layer_id , pallet_id) belong to any team instructions (layer_id , pallet_id),
        a combination because same pallet may be found in different layers.
        """
        layer_id_and_pallet_id_combinations_from_team_instructions = self._extract_layer_id_and_pallet_id_combinations()
        layer_id = ply.get("layer_id")
        pallet_id = ply.get("pallet_id")
        tuple_of_layer_pallet_ids = (layer_id, pallet_id)
        if layer_id and pallet_id:
            return tuple_of_layer_pallet_ids in layer_id_and_pallet_id_combinations_from_team_instructions
        else:
            error_message = f"Failed to found layer_id or pallet_id: {tuple_of_layer_pallet_ids}, in ply: {ply}"
            log.error(error_message)
            return False

    def _extract_layer_id_and_pallet_id_combinations(self) -> set[tuple]:
        set_of_tuples = set()
        for team_instruction in self._stored_team_instructions_data:
            layer_id = team_instruction.get("layerId")
            pallet_id = team_instruction.get("palletId")
            tuple_of_layer_pallet_ids = (layer_id, pallet_id)
            if layer_id and pallet_id:
                set_of_tuples.add(tuple_of_layer_pallet_ids)
            else:
                error_message = "Failed to found layer_id or pallet_id: %s, in team_instruction: %s".format(
                    tuple_of_layer_pallet_ids, team_instruction)
                log.error(error_message)
                raise ValueError(error_message)
        return set_of_tuples
