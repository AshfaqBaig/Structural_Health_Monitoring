""" Module for storing and processing edge to cameras mapping. """
from app.logging.logger import yield_logger

log = yield_logger()

class EdgeCameras:
    """ Model for storing and processing edge to cameras mapping. """

    def __init__(self, edge_to_cameras: dict):
        self._edge_to_cameras = edge_to_cameras
        self._invisible_edges = self._filter_invisible(edge_to_cameras)

    @property
    def mould_id(self) -> str:
        """ Get the mould_id assigned to edge to cameras mapping. """
        return self._edge_to_cameras["mould_id"]

    @property
    def blade_revision(self) -> str:
        """ Get the blade_revision assigned to edge to cameras mapping. """
        return self._edge_to_cameras["blade_revision"]

    @property
    def invisible_edges(self) -> set:
        """ Returns edge ids invisible to all cameras. """
        return self._invisible_edges

    def get_cameras(self, edge_id: str) -> list:
        """ Returns cameras list for given edge_id. """
        try:
            return self._edge_to_cameras["edges"][edge_id]
        except KeyError:
            log.error(f"Failed to found cameras in edge-to-cameras mapping by edge_id: %s", edge_id)
            return []

    def is_edge_invisible(self, edge_id: str) -> bool:
        """ Returns True if given edge is invisible to all cameras. """
        return edge_id in self._invisible_edges

    @staticmethod
    def _filter_invisible(edge_to_cameras: dict) -> set:
        invisible_edges = {edge_id for edge_id, cams in edge_to_cameras["edges"].items() if cams == []}
        if invisible_edges:
            log.warning("Edges to cameras mapping contains invisible edges: %s ", invisible_edges)
        return invisible_edges
