def edges(plies: dict) -> set:
    """ Extracts edges from given graph plies. """
    extracted_edges = set()
    for ply_id in plies:
        extracted_edges.update(plies[ply_id]["edges"])
    return extracted_edges


def layer_ids(plies: dict) -> set[str]:
    """ Extracts layer_ids from given graph plies. """
    extracted_layer_ids = set()
    for ply_id in plies:
        extracted_layer_ids.add(plies[ply_id]["layer_id"])
    return extracted_layer_ids
