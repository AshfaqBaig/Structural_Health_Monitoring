""" Module for storing and processing graph. """
from __future__ import annotations

from app.logging.logger import yield_logger
from app.models.team_instructions import TeamInstructions

log = yield_logger()


class Graph:
    """ Model for storing graph and creating sub-graph from stored graph. """

    def __init__(self, graph_data: dict):
        self._stored_graph_data = graph_data
        self._edge_to_ply = self._map_edge_to_ply()
        self._layer_to_pallets = None

    @property
    def data(self) -> dict:
        """ Get stored graph data. """
        return self._stored_graph_data

    def validate(self, ply_id) -> None:
        if not self.find_ply(ply_id):
            raise ValueError(f"Given {ply_id} is not valid, it does not exist in the graph") from None

    def get_edges_covered_by_ply(self, ply_id: str) -> set:
        """ Returns ply edges_covered by given ply id. """
        try:
            ply = self.get_ply(ply_id)
            return set(ply["edges_covered"])
        except ValueError as ex:
            raise ValueError(f"Failed to get_edges_covered_by_ply for given ply: {ply_id}, due to: {ex}") from None

    def get_edges_covered_by_plies(self, ply_ids: set) -> set:
        """ Returns set of plies edges_covered by given ply ids. """
        try:
            edges_to_return = set()
            for ply_id in ply_ids:
                edges = self.get_edges_covered_by_ply(ply_id)
                edges_to_return.update(edges)
            return edges_to_return
        except ValueError as ex:
            raise ValueError(f"Failed to get_edges_covered_by_plies for given plies: {ply_ids}, due to: {ex}") from None

    def get_edges_by_ply(self, ply_id: str) -> set:
        """ Returns ply edges from graph ply by given ply id. """
        try:
            ply = self.get_ply(ply_id)
            return set(ply["edges"])
        except KeyError as ex:
            raise ValueError(f"Missing attribute: {ex}, for given ply: {ply_id}")
        except ValueError as ex:
            raise ValueError(f"Failed to get_edges_by_ply for given ply: {ply_id}, due to: {ex}") from None

    def get_edges_by_plies(self, ply_ids: set) -> set:
        """ Returns set of plies edges by given ply ids. """
        try:
            edges_to_return = set()
            for ply_id in ply_ids:
                edges = self.get_edges_by_ply(ply_id)
                edges_to_return.update(edges)
            return edges_to_return
        except ValueError as ex:
            raise ValueError(f"Failed to get_edges_by_plies for given plies: {ply_ids}, due to: {ex}") from None

    def get_all_edges(self) -> set:
        """ Returns set of all edges from graph plies. """
        all_edges = set()
        for ply_id in self.get_all_plies():
            edges = self.get_edges_by_ply(ply_id)
            all_edges.update(edges)
        return all_edges

    def get_ply(self, ply_id: str) -> dict:
        """ Returns a ply by given ply_id. """
        try:
            graph_plies = self.get_all_plies()
            return graph_plies[ply_id]
        except KeyError as ex:
            raise ValueError(f"Failed to found ply in graph by given ply_id: {ex}") from None

    def find_ply(self, ply_id: str) -> dict:
        """ Returns a ply by given ply_id. """
        graph_plies = self.get_all_plies()
        return graph_plies.get(ply_id)

    def get_all_plies(self) -> dict:
        """ Returns all plies from graph. """
        try:
            return self._stored_graph_data["plies"]
        except KeyError as ex:
            raise ValueError(f"Missing attribute: {ex}, in stored graph data: {self._stored_graph_data}")

    def get_previous_plies(self, ply_id: str) -> set:
        """ Returns previous_plies of a ply by given ply_id. """
        try:
            ply = self.get_ply(ply_id)
            return set(ply["previous_plies"])
        except KeyError as ex:
            raise ValueError(f"Failed to get_previous_plies. Missing attribute: {ex}, in ply: {ply_id}") from None

    def get_next_plies(self, ply_id: str) -> set:
        """ Returns next_plies of a ply by given ply_id. """
        try:
            ply = self.get_ply(ply_id)
            return set(ply["next_plies"])
        except KeyError as ex:
            raise ValueError(f"Failed to get_next_plies. Missing attribute: {ex}, in ply: {ply_id}") from None

    def get_pallet(self, ply_id: str) -> str:
        """ Returns pallet_id of a ply by given ply_id. """
        try:
            ply = self.get_ply(ply_id)
            return ply["pallet_id"]
        except KeyError as ex:
            raise ValueError(f"Failed to get_pallet. Missing attribute: {ex}, in ply: {ply_id}") from None

    def get_next_plies_pallets(self, ply_id: str) -> list:
        """ Returns pallet ids of next_plies of a ply by given ply_id. """
        next_plies = self.get_next_plies(ply_id)
        # TODO: refactor
        return list(set([self.get_pallet(p) for p in next_plies]))

    def get_layer(self, ply_id: str) -> str:
        """ Returns layer_id of a ply by given ply_id. """
        try:
            ply = self.get_ply(ply_id)
            return ply["layer_id"]
        except KeyError as ex:
            raise ValueError(f"Failed to get_layer. Missing attribute: {ex}, in ply: {ply_id}") from None

    def get_pallets_by_layer(self, layer_id: str) -> set[str]:
        """ Returns all pallet ids for given layer_id. """
        try:
            pallet_ids = self._layer_to_pallets[layer_id]
            return pallet_ids
        except KeyError:
            raise ValueError(f"Failed to get pallets by given layer_id: {layer_id}, in layer-to-pallets mapping.") \
                from None

    def get_plies_by_pallet_and_layer(self, pallet_id: str, layer_id: str) -> dict:
        """ Returns sub set of graph plies where ply's pallet_id and layer_id match given. """
        plies_to_return = {}
        for ply_id, ply in self._get_plies_by_pallet(pallet_id).items():
            if layer_id == self.get_layer(ply_id):
                plies_to_return.update({ply_id: ply})

        return plies_to_return

    def _get_plies_by_pallet(self, pallet_id: str) -> dict:
        """ Returns sub set of graph plies where ply's pallet_id match given one. """
        plies_to_return = {}
        for ply_id, ply in self.get_all_plies().items():
            if pallet_id == self.get_pallet(ply_id):
                plies_to_return.update({ply_id: ply})

        return plies_to_return

    def get_n_previous_plies(self, ply_id: str, depth_level: int) -> set:
        """ Returns accumulated previous_plies for given ply_id and depth_level. """
        if depth_level == 0:
            return set()

        acc_previous_plies = set()
        previous_plies = self.get_previous_plies(ply_id)
        acc_previous_plies.update(previous_plies)
        self._get_previous_plies_of_previous_plies(acc_previous_plies, previous_plies, depth_level)
        return acc_previous_plies

    def _get_previous_plies_of_previous_plies(self, acc_previous_plies: set, plies: set, depth_level: int) -> None:
        for ply_id in plies:
            previous_plies = self.get_n_previous_plies(ply_id, depth_level - 1)
            acc_previous_plies.update(previous_plies)

    def find_plies_to_be_placed(self, placed_plies: dict) -> dict:
        """ Processes given placed_plies to find next plies_to_be_placed according to the graph. """
        graph_plies = self.get_all_plies()
        plies_to_be_placed = {}
        # if state is empty find all graph plies with empty previous_plies
        if placed_plies is None or len(placed_plies) == 0:
            # notice there may be multiple plies with empty previous_plies because of multi-team
            for ply_id in graph_plies:
                graph_previous_plies = self.get_previous_plies(ply_id)
                if len(graph_previous_plies) == 0:
                    plies_to_be_placed[ply_id] = self.get_ply(ply_id)
        # else find all graph plies where all previous_plies in state (there may be multiple plies to find and to cover)
        else:
            for ply_id in graph_plies:
                # add only if all previous plies in state - already placed, because some plies may cover multiple plies
                graph_previous_plies = self.get_previous_plies(ply_id)
                if graph_previous_plies.issubset(placed_plies) and ply_id not in placed_plies:
                    plies_to_be_placed[ply_id] = self.get_ply(ply_id)

        return plies_to_be_placed

    def get_all_dependent_plies_on_ply(self, ply_id: str) -> list:
        """ Returns all plies dependent on a ply. """
        acc_dependent_plies = []
        plies_by_previous_plies = list(self.get_plies_by_previous_plies(ply_id))
        acc_dependent_plies.extend(plies_by_previous_plies)
        self._get_dependent_plies_of_dependent_plies(acc_dependent_plies, plies_by_previous_plies)
        return acc_dependent_plies

    def _get_dependent_plies_of_dependent_plies(self, acc_dependent_plies: list, plies: list) -> None:
        for ply_id in plies:
            dependent_plies = self.get_all_dependent_plies_on_ply(ply_id)
            self._append_uniques_and_reappend_duplicates(acc_dependent_plies, dependent_plies)

    @staticmethod
    def _append_uniques_and_reappend_duplicates(acc_dependent_plies: list, plies: list) -> None:
        already_collected_plies = set(acc_dependent_plies)
        for ply in plies:
            if ply not in already_collected_plies:
                already_collected_plies.add(ply)
                acc_dependent_plies.append(ply)
            else:
                acc_dependent_plies.remove(ply)
                acc_dependent_plies.append(ply)

    def get_plies_by_previous_plies(self, ply_id_to_match: str) -> dict:
        """ Returns sub set of graph plies where ply_id in ply's previous_plies list. """
        plies_to_return = {}
        for ply_id, ply in self.get_all_plies().items():
            graph_previous_plies = self.get_previous_plies(ply_id)
            if ply_id_to_match in graph_previous_plies:
                plies_to_return.update({ply_id: ply})

        return plies_to_return

    def create_sub_graph(self, team_instructions: TeamInstructions) -> Graph:
        """ Creates and returns a subset of graph data for given Team Instructions. """
        log.debug("Starting Sub-Graph creation for team instructions: %s", team_instructions.data)
        filtered_plies = self._filter_graph_plies(self._stored_graph_data["plies"], team_instructions)
        sub_graph_data = {
            "mould_id": team_instructions.mould_id,
            "blade_revision": team_instructions.blade_revision,
            "plies": filtered_plies
        }
        if filtered_plies == {}:
            warning_message = f"Failed to create sub-graph, filtered plies are empty: {filtered_plies}\n" \
                              f"for given team instructions: {team_instructions.data}"
            log.warning(warning_message)
            raise ValueError(warning_message)

        log.debug(f"Sub-graph successfully created.")
        sub_graph = Graph(sub_graph_data)
        sub_graph._map_and_cache_layer_to_pallets()
        return sub_graph

    @staticmethod
    def _filter_graph_plies(plies: dict, team_instructions: TeamInstructions) -> dict:
        """
        Creates a sub-graph plies from graph plies by filtering in only plies matching given team instructions
        """
        filtered_plies = {ply_id: ply for (ply_id, ply) in plies.items() if team_instructions.is_matching(ply)}
        log.debug(f"Graph of {len(plies.keys())} plies was filtered to Sub-Graph of {len(filtered_plies.keys())} plies")
        return filtered_plies

    def _map_and_cache_layer_to_pallets(self) -> None:
        if self._layer_to_pallets is not None:
            log.error(f"Layer to pallets already mapped, this should happen only once and short after graph creation.")
        else:
            log.warning("Mapping and storing layer to pallets map...")
            self._layer_to_pallets = self._map_layer_to_pallets()

    def find_plies_by_edges(self, edges: set) -> dict:
        """ Returns sub set of graph plies for given edges. """
        if edges == set():
            log.warning("No edges given to find plies by in the graph, returning empty result.")
            return {}

        plies_to_return = {}
        for edge in edges:
            ply_id, ply = self.find_ply_by_edge(edge)
            if ply_id is not None and ply is not None:
                plies_to_return.update({ply_id: ply})
            else:
                log.warning("Ply not found by given edge: %s", edge)

        log.debug("Found plies: %s for given edges: %s", set(plies_to_return), edges)
        return plies_to_return

    def find_ply_by_edge(self, edge: str) -> [tuple[str, dict]]:
        """ Returns tuple for (ply_id, ply) by given edge or None if not found. """
        ply_id = self._edge_to_ply.get(edge)
        if ply_id:
            ply = self.find_ply(ply_id)
            return ply_id, ply
        return None, None

    def get_ply_by_edge(self, edge: str) -> tuple[str, dict]:
        """ Returns tuple for (ply_id, ply) by given edge. """
        try:
            ply_id = self._edge_to_ply[edge]
            ply = self.get_ply(ply_id)
            return ply_id, ply
        except KeyError:
            raise ValueError(f"Failed to found ply by given edge: {edge}, in edge-to-ply mapping.") from None

    def remove_invisible_edges(self, edges: set) -> None:
        """ Removes edges from graph plies attributes: 'edges' and 'edges_covered', by given edges. """
        log.warning("Removing invisible edges: %s, from graph plies attributes 'edges' and 'edges_covered'.", edges)
        for edge in edges:
            self._prune_plies_edges(edge)
            self._prune_plies_edges_covered(edge)

    def _prune_plies_edges(self, edge: str) -> None:
        """ Find and remove given edge from 'edges' attribute in graph plies. """
        try:
            ply_id, ply = self.get_ply_by_edge(edge)
            ply["edges"].remove(edge)
            log.warning("Edge %s removed from 'edges' attributes in ply: %s", edge, ply_id)
        except ValueError as ex:
            log.warning(f"Failed to remove edge: {edge} from 'edges' attribute in graph plies, due to: {ex}")

    def _prune_plies_edges_covered(self, edge: str) -> None:
        """ Find and remove given edge from 'edges_covered' attribute in graph plies. """
        try:
            plies_to_prune = self._get_plies_by_edges_covered(edge)
            for ply_id, ply in plies_to_prune.items():
                ply["edges_covered"].remove(edge)
                log.warning("Edge %s removed from 'edges_covered' attributes in ply: %s", edge, ply_id)
        except ValueError as ex:
            log.warning(f"Failed to remove edge: {edge} from 'edges_covered' attr in graph plies, due to: {ex}")

    def _get_plies_by_edges_covered(self, edge: str) -> dict:
        """ Returns sub set of graph plies where edge in ply's edges_covered list. """
        plies_to_return = {}
        for ply_id, ply in self.get_all_plies().items():
            try:
                ply_edges_covered = ply["edges_covered"]
                if edge in ply_edges_covered:
                    plies_to_return.update({ply_id: ply})
            except KeyError as ex:
                log.warning("Missing '%s' attribute in ply: %s", ex, ply_id)

        if not plies_to_return:
            warn_message = f"Failed to found any ply where given edge: {edge}, in ply's 'edges_covered' attribute."
            log.warning(warn_message)
            raise ValueError(warn_message) from None

        return plies_to_return

    def _map_edge_to_ply(self) -> dict:
        edge_to_ply = {}
        try:
            for ply_id in self.get_all_plies():
                for edge in self.get_edges_by_ply(ply_id):
                    edge_to_ply.update({edge: ply_id})
            return edge_to_ply
        except ValueError as ex:
            raise ValueError(f"Failed to map_edge_to_ply on graph creation, due to: {ex}") from None

    def _map_layer_to_pallets(self) -> dict:
        layer_to_pallets = {}
        try:
            for ply_id in self.get_all_plies():
                layer = self.get_layer(ply_id)
                pallet = self.get_pallet(ply_id)
                if layer not in layer_to_pallets:
                    layer_to_pallets.update({layer: {pallet}})
                else:
                    layer_to_pallets[layer].add(pallet)
            return layer_to_pallets
        except ValueError as ex:
            raise ValueError(f"Failed to map_layer_to_pallets, due to: {ex}") from None
