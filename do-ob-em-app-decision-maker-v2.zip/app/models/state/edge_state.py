# pylint: disable=missing-module-docstring

from __future__ import annotations

from typing import Tuple

import app.config as cfg
from app.logging.logger import yield_logger
from app.models.state.edge_cam_state import EdgeCamState
from app.models.state.edge_cam_state_enum import EdgeCamStateEnum
from app.models.state.edge_state_enum import EdgeStateEnum
from app.models.state.edge_state_transitions import EdgeStateTransitions

log = yield_logger()

class EdgeState:
    def __init__(
            self,
            edge_id: str,
            cams: set[EdgeCamState] = None,
            state: EdgeStateEnum = EdgeStateEnum.MISSING,
    ):
        if cams is None:
            cams = set()
        self._edge_id = edge_id
        self._cams = cams
        self._state = state

    def __str__(self) -> str:
        return str(self.__dict__)

    def __eq__(self, other: EdgeState) -> bool:
        if not isinstance(other, EdgeState):
            raise TypeError(
                f"EdgeState equality comparator cannot compare itself to other type instance: {type(other)}")
        else:
            return all({
                self._edge_id == other._edge_id,
                self._cams == other._cams,
                self._state == other._state,
            })

    def __hash__(self):
        return hash((self._edge_id, str(sorted([cam.id for cam in self._cams]))))

    @property
    def id(self) -> str:
        """ Get edge's id """
        return self._edge_id

    @property
    def cams(self) -> set[EdgeCamState]:
        """ Get edge's cams """
        return self._cams

    def find_cam(self, cam_id: str) -> EdgeCamState:
        """ Tries to return an cam from edge state by given cam_id or None if cam state do not exist. """
        for cam in self._cams:
            if cam.id == cam_id:
                return cam

    def get_cam(self, cam_id: str) -> EdgeCamState:
        """ Return an edge cam from mould state ply by given cam_id or raises ValueError exception. """
        cam = self.find_cam(cam_id)
        if cam:
            return cam
        raise ValueError(f"Failed to get edge cam in mould state ply edge: {self.id}, by given cam_id: {cam_id}")

    @property
    def state(self) -> EdgeStateEnum:
        """ Get edge's state """
        return self._state

    def serialize(self) -> dict:
        """Serialise object into dict structure"""

        result: dict = {
            "edge_id": self._edge_id,
            "cams": [],
            "state": self._state.name
        }
        cam_state: EdgeCamState
        for cam_state in self._cams:
            result["cams"].append(cam_state.serialize())
        result["cams"] = sorted(result["cams"], key=lambda i: i["cam_id"])

        return result

    @staticmethod
    def deserialize(state_dict: dict) -> EdgeState:
        """Deserialize dict into object"""

        edge_id: str = state_dict.get("edge_id")
        state_name: str = state_dict.get("state")
        cams: str = state_dict.get("cams")

        if not edge_id or not state_name or cams is None:
            raise ValueError(f"Invalid edge state keys. Expected: edge_id, state, cams. Actual: {state_dict.keys()}")

        cams_deserialized: set[EdgeCamState] = set(map(EdgeCamState.deserialize, cams))

        return EdgeState(edge_id, state=EdgeStateEnum.value_of(state_name), cams=cams_deserialized)

    def update_state(self, new_state: EdgeStateEnum) -> bool:
        """ Set new edge's state """
        log.debug("Updating %s edge state: %s -> %s", self._edge_id, self._state.name, new_state.name)
        state_has_changed = self._state != new_state
        self._state = new_state
        return state_has_changed

    def reset_cams_to_state(self, new_state: EdgeCamStateEnum) -> bool:
        cam_updated: bool = False
        for cam in self.cams:
            cam_is_not_in_initial_state = cam.state != EdgeCamStateEnum.NEVER_DETECTED
            if cam_is_not_in_initial_state:
                cam_updated |= cam.update_state(new_state)

        return cam_updated

    def init_state(self, cameras: set[str]) -> None:
        for camera in cameras:
            self.cams.add(EdgeCamState(camera))
        self._recalculate_state()

    def reset(self) -> None:
        self._state = EdgeStateEnum.MISSING
        for cam in self.cams:
            cam.reset()

    def update_cam_state(self, new_edge_cam_states: set[EdgeCamState]) -> bool:
        edge_cam_state_updated = False
        for new_cam_state in new_edge_cam_states:
            self._get_cam_state(new_cam_state.id)
            current_edge_cam_state = self._get_cam_state(new_cam_state.id)
            edge_cam_state_updated |= current_edge_cam_state.update_state(new_cam_state.state)
        return edge_cam_state_updated

    def update_cam(self, camera_id: str, state_update: EdgeCamStateEnum) -> Tuple[bool, bool]:
        """Update edge cam states"""

        current_cam_state: EdgeCamState = self._find_cam_state(camera_id)

        if current_cam_state:
            edge_updated: bool = False
            cam_updated: bool = current_cam_state.update_cam(state_update)
            if cam_updated:
                edge_updated = self._recalculate_state()
            return edge_updated, cam_updated
        else:
            log.warning("Cam %s state not found in edge: %s (no mapping in edge-to-cameras file?) ", camera_id, self.id)
            return False, False

    def _recalculate_state(self) -> bool:
        """Recalculate new edge state"""

        new_edge_state: EdgeStateEnum = self._resolve_new_edge_state()

        if new_edge_state == self._state:
            return False
        else:
            log.info("Updating %s edge state: %s -> %s", self._edge_id, self._state.name, new_edge_state.name)
            self._state = new_edge_state
            return True

    def _find_cam_state(self, camera_id: str) -> EdgeCamState:
        """ Find cam state by camera_id """
        for cam in self._cams:
            if cam.id == camera_id:
                return cam

    def _get_cam_state(self, camera_id: str) -> EdgeCamState:
        """ Get cam state by camera_id """
        cam = self._find_cam_state(camera_id)
        if cam:
            return cam
        raise ValueError(f"Failed to find cam state in edge: {self._edge_id}, for given camera: {camera_id}")

    def _resolve_new_edge_state(self) -> EdgeStateEnum:
        """Resolve new edge state"""

        edge_state_transition_rule = self._resolve_edge_state_rule()

        detections_count = self._edge_detected_by_cams_count()

        if cfg.FF_EDGE_DETECTION_STRICT:
            # each camera detects an edge
            if detections_count == len(self._cams):
                return edge_state_transition_rule["rule_detected"]
            else:
                return edge_state_transition_rule["rule_undetected"]
        else:
            # at least one camera detects an edge
            if detections_count > 0:
                return edge_state_transition_rule["rule_detected"]
            else:
                return edge_state_transition_rule["rule_undetected"]

    def _edge_detected_by_cams_count(self):
        """Return count of cams which detected an edge"""

        detections_count: int = 0
        for cam_state in self._cams:
            if cam_state.state.value == EdgeCamStateEnum.DETECTED.value:
                detections_count += 1
        return detections_count

    def _resolve_edge_state_rule(self):
        """Resolve edge state transitioning rule"""

        for edge_state_rule in EdgeStateTransitions.config:
            if edge_state_rule["current"] == self._state:
                return edge_state_rule
        raise ValueError(f"Failed to find transition rule for {self._state}")
