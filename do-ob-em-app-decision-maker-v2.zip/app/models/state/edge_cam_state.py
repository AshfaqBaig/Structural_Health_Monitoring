# pylint: disable=missing-module-docstring
from __future__ import annotations

from app.logging.logger import yield_logger
from app.models.state.edge_cam_state_enum import EdgeCamStateEnum
from app.models.state.edge_cam_state_transitions import EdgeCamStateTransitions

log = yield_logger()

class EdgeCamState:
    def __init__(
            self,
            cam_id: str,
            state: EdgeCamStateEnum = EdgeCamStateEnum.NEVER_DETECTED,
    ):
        self._cam_id = cam_id
        self._state = state

    def __str__(self) -> str:
        return str(self.__dict__)

    def __eq__(self, other: EdgeCamState) -> bool:
        if not isinstance(other, EdgeCamState):
            raise TypeError(
                f"EdgeCamState equality comparator cannot compare itself to other type instance: {type(other)}")
        else:
            return all({
                self._cam_id == other._cam_id,
                self._state == other._state,
            })

    def __hash__(self):
        return hash(self._cam_id)

    @property
    def id(self) -> str:
        """ Get cam id """
        return self._cam_id

    @property
    def state(self) -> EdgeCamStateEnum:
        """ Get edge camera state """
        return self._state

    def serialize(self) -> dict:
        """Serialise object into dict structure"""

        return {
            "cam_id": self._cam_id,
            'state': self._state.name
        }

    @staticmethod
    def deserialize(state_dict: dict) -> EdgeCamState:
        """Deserialize dict into object"""

        cam_id: str = state_dict.get("cam_id")
        state_name: str = state_dict.get("state")

        if not cam_id or not state_name:
            raise ValueError(f"Invalid cam state keys. Expected: cam_id, state. Actual: {state_dict.keys()}")

        return EdgeCamState(cam_id, EdgeCamStateEnum.value_of(state_name))

    def update_state(self, new_state: EdgeCamStateEnum) -> bool:
        log.debug("Updating %s edge cam state: %s -> %s", self._cam_id, self._state.name, new_state.name)
        state_has_changed = self._state != new_state
        self._state = new_state
        return state_has_changed

    def update_cam(self, state_update: EdgeCamStateEnum) -> bool:
        if state_update != self._state:
            new_cam_state = self._resolve_cam_state_transition(state_update)
            if new_cam_state != self._state:
                return self.update_state(new_cam_state)

        return False

    def _resolve_cam_state_transition(self, state_update: EdgeCamStateEnum) -> EdgeCamStateEnum:
        """Resolve new cam state transition config by comparing old and new states"""

        for transition_rule in EdgeCamStateTransitions.config:
            if transition_rule["current"] == self._state and transition_rule["new"] == state_update:
                return transition_rule["transition"]
        raise ValueError(f'Failed to find cam transition rule for {self._state} -> {state_update}')

    def reset(self) -> None:
        self._state = EdgeCamStateEnum.NEVER_DETECTED
