# pylint: disable=missing-module-docstring
from app.models.state.edge_state_enum import EdgeStateEnum


class EdgeStateTransitions:
    """Edge Camera State transition matrix"""

    config = [
        {
            "current": EdgeStateEnum.MISSING,
            "rule_detected": EdgeStateEnum.DETECTED,
            "rule_undetected": EdgeStateEnum.MISSING
        },
        {
            "current": EdgeStateEnum.DETECTED,
            "rule_detected": EdgeStateEnum.DETECTED,
            "rule_undetected": EdgeStateEnum.MISSING
        },
        {
            "current": EdgeStateEnum.COVERED,
            "rule_detected": EdgeStateEnum.COVERED,
            "rule_undetected": EdgeStateEnum.COVERED
        },
        {
            "current": EdgeStateEnum.FORCED,
            "rule_detected": EdgeStateEnum.FORCED,
            "rule_undetected": EdgeStateEnum.FORCED
        }
    ]
