from enum import Enum


class EdgeCamStateEnum(Enum):
    NEVER_DETECTED = 1
    MISSING = 2
    DETECTED = 3

    @classmethod
    def value_of(cls, value):
        for k, v in cls.__members__.items():
            if k == value:
                return v
        else:
            raise ValueError(f"'{cls.__name__}' enum not found for '{value}'")
