from app.models.state.edge_cam_state import EdgeCamState
from app.models.state.edge_state import EdgeState
from app.models.state.ply_state import PlyState


def edge_states(plies: set[PlyState]) -> set[EdgeState]:
    """ Extracts edges states from given plies states. """
    edges = set()
    for ply in plies:
        edges.update(ply.edges)
    return edges


def cam_states(plies: set[PlyState]) -> set[EdgeCamState]:
    """ Extracts edge cams states from given plies states. """
    cams = set()
    for edge in edge_states(plies):
        cams.update(edge.cams)
    return cams
