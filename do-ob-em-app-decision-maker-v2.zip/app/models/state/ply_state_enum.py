from enum import Enum


class PlyStateEnum(Enum):
    EXPECTED = 1
    PLACED = 2
    MISSING = 3
    COVERED = 4
    FORCED = 5

    @classmethod
    def value_of(cls, value):
        for k, v in cls.__members__.items():
            if k == value:
                return v
        else:
            raise ValueError(f"'{cls.__name__}' enum not found for '{value}'")
