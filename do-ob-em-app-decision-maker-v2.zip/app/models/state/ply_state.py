from __future__ import annotations

import app.config as cfg
from app.logging.logger import yield_logger
from app.models.edge_cameras import EdgeCameras
from app.models.state.edge_cam_state import EdgeCamState
from app.models.state.edge_cam_state_enum import EdgeCamStateEnum
from app.models.state.edge_state import EdgeState
from app.models.state.edge_state_enum import EdgeStateEnum
from app.models.state.ply_state_enum import PlyStateEnum

log = yield_logger()


class PlyState:
    def __init__(
            self,
            ply_id: str,
            edges: set[EdgeState] = None,
            state: PlyStateEnum = PlyStateEnum.EXPECTED,
            previous_state: PlyStateEnum = None,
            updated_by: str = "initial",
            source_device: str = None,
    ):
        if edges is None:
            edges = set()
        self._ply_id = ply_id
        self._edges = edges
        self._state = state
        self._previous_state = previous_state
        self._updated_by = updated_by
        self.source_device: str = source_device

    def __str__(self) -> str:
        return str(self.__dict__)

    def __eq__(self, other: PlyState) -> bool:
        if not isinstance(other, PlyState):
            raise TypeError(f"PlyState equality comparator cannot compare itself to other type instance: {type(other)}")
        else:
            return all({
                self._ply_id == other._ply_id,
                self._edges == other._edges,
                self._state == other._state,
                self._previous_state == other._previous_state,
                self._updated_by == other._updated_by,
            })

    def __hash__(self):
        return hash((self._ply_id, str(sorted([edge.id for edge in self._edges]))))

    @property
    def id(self) -> str:
        """ Get ply's id """
        return self._ply_id

    @property
    def edges(self) -> set[EdgeState]:
        """ Get ply's edges """
        return self._edges

    @property
    def state(self) -> PlyStateEnum:
        """ Get ply's state """
        return self._state

    @property
    def updated_by(self) -> str:
        """ Get updated_by """
        return self._updated_by

    @updated_by.setter
    def updated_by(self, updated_by: str) -> None:
        """ Get updated_by """
        self._updated_by = updated_by

    def update_state(self, new_state: PlyStateEnum) -> bool:
        """ Set new ply's state """
        log.debug("Updating %s ply state: %s -> %s", self.id, self._state.name, new_state.name)
        state_has_changed = self._state != new_state
        self._previous_state = self.state
        self._state = new_state
        return state_has_changed

    @property
    def previous_state(self) -> PlyStateEnum:
        """ Get ply"s previous state """
        return self._previous_state

    def serialize(self) -> dict:
        """Serialise object into dict structure"""

        result: dict = {
            "ply_id": self._ply_id,
            "edges": [],
            "state": self._state.name,
            "previous_state": self._previous_state.name if self._previous_state else None,
            "updated_by": self._updated_by,
            "source_device": self.source_device
        }
        edge_state: EdgeState
        for edge_state in self._edges:
            result["edges"].append(edge_state.serialize())
        result["edges"] = sorted(result["edges"], key=lambda i: i["edge_id"])

        return result

    @staticmethod
    def deserialize(state_dict: dict) -> PlyState:
        """Deserialize dict into object"""

        if "ply_id" not in state_dict or "state" not in state_dict or "edges" not in state_dict:
            log.error("Deserializing ply state failed: \n%s", state_dict)
            raise ValueError(f"Invalid ply state keys. Required: ply_id, state, edges. Actual: {set(state_dict)}")

        ply_id: str = state_dict.get("ply_id")
        state_name: str = state_dict.get("state")
        edges: str = state_dict.get("edges")
        updated_by: str = state_dict.get("updated_by")
        previous_state_name: str = state_dict.get("previous_state")
        source_device: str = state_dict.get("source_device")

        edges_deserialized: set[EdgeState] = set(map(EdgeState.deserialize, edges))

        return PlyState(
            ply_id,
            state=PlyStateEnum.value_of(state_name),
            previous_state=PlyStateEnum.value_of(previous_state_name) if previous_state_name is not None else None,
            edges=edges_deserialized,
            updated_by=updated_by,
            source_device=source_device,
        )

    def update_cam(self, camera: str, detected_edges: set[str], missing_edges: set[str]) -> tuple[bool, bool, bool]:
        overall_cam_updated = False
        overall_edge_updated = False
        overall_ply_updated = False

        if detected_edges:
            cam_updated, edge_updated = self._process_edges_cam_update(
                camera, detected_edges, EdgeCamStateEnum.DETECTED)
            overall_cam_updated |= cam_updated
            overall_edge_updated |= edge_updated

        if missing_edges:
            cam_updated, edge_updated = self._process_edges_cam_update(camera, missing_edges, EdgeCamStateEnum.MISSING)
            overall_cam_updated |= cam_updated
            overall_edge_updated |= edge_updated

        if overall_cam_updated:
            self.updated_by = f"cam:{camera}"
        if overall_edge_updated:
            overall_ply_updated |= self._recalculate_state()

        return overall_cam_updated, overall_edge_updated, overall_ply_updated

    def _process_edges_cam_update(self, camera, edges, state: EdgeCamStateEnum) -> tuple[bool, bool]:
        overall_cam_updated = False
        overall_edge_updated = False
        for edge in self.get_edges(edges):
            cam_updated, edge_updated = edge.update_cam(camera, state)
            overall_cam_updated |= cam_updated
            overall_edge_updated |= edge_updated
        return overall_cam_updated, overall_edge_updated

    def init_state(self, graph_ply: dict, cameras: EdgeCameras) -> None:
        edge_ids = set(graph_ply["edges"])
        for edge_id in edge_ids:
            edge = EdgeState(edge_id)
            edge.init_state(set(cameras.get_cameras(edge_id)))
            self._edges.add(edge)

    def reset_edges_to_state(
            self, edges_to_reset: set[str], new_edge_state: EdgeStateEnum, new_cam_state: EdgeCamStateEnum
    ) -> tuple[bool, bool]:
        log.info(f"Updating ply {self.id} edges to state: {new_edge_state}, cam to state: {new_cam_state}")
        cam_updated: bool = False
        edge_updated: bool = False
        for edge in self.edges:
            edge_is_not_in_initial_state = edge.state != EdgeStateEnum.MISSING
            if edge.id in edges_to_reset and edge_is_not_in_initial_state:
                edge_updated |= edge.update_state(new_edge_state)
                cam_updated |= edge.reset_cams_to_state(new_cam_state)

        return cam_updated, edge_updated

    def reset_all_uncovered_edges(self) -> None:
        log.info(f"Resetting ply's {self.id} un-COVERED edges into initial state...")
        for edge in self.edges:
            if edge.state != EdgeStateEnum.COVERED:
                edge.reset()

    def _recalculate_state(self) -> bool:
        if self.edges == set():
            log.debug(f"Ply {self.id} is a phantom, aborting state recalculation.")
            return False

        ply_is_in_rigid_state = self.state in {PlyStateEnum.COVERED, PlyStateEnum.FORCED}
        if ply_is_in_rigid_state:
            log.debug(f"Ply {self.id} is in rigid state, aborting state recalculation.")
            return False

        ply_updated = False
        if cfg.FF_PLY_PLACED_STRICT:
            ply_updated |= self._evaluation_rule_all_or_nothing()
        else:
            ply_updated |= self._evaluation_rule_at_least_one()

        if self.state == PlyStateEnum.COVERED:
            log.warning("Why are we trying recalculating a state for ply with state COVERED ? will not happen.")
        elif self.state == PlyStateEnum.FORCED:
            log.warning("Why are we trying recalculating a state for ply with state FORCED ? will not happen.")

        return ply_updated

    def _evaluation_rule_all_or_nothing(self) -> bool:
        if all(edge.state == EdgeStateEnum.COVERED for edge in self.edges):
            return self.update_state(PlyStateEnum.COVERED)
        elif any(edge.state == EdgeStateEnum.MISSING for edge in self.edges):
            if self.state == PlyStateEnum.PLACED:
                return self.update_state(PlyStateEnum.MISSING)
        elif self.state == PlyStateEnum.EXPECTED or self.state == PlyStateEnum.MISSING:
            return self.update_state(PlyStateEnum.PLACED)
        return False

    def _evaluation_rule_at_least_one(self) -> bool:
        raise NotImplementedError("Currently not implemented, for FF_PLY_PLACED_STRICT must be True")

    def update_edge_states(self, edge_ids: set[str], new_state: EdgeStateEnum) -> bool:
        """ Set edges states to new_state """
        for edge in self.edges:
            if edge.id in edge_ids:
                edge.update_state(new_state)
        return self._recalculate_state()

    def get_edges(self, edges_ids: set[str]) -> set[EdgeState]:
        """ Returns set of edges from mould state ply for all given edge_ids or raises ValueError exception. """
        to_return = set()
        for edge_id in edges_ids:
            edge = self.get_edge(edge_id)
            to_return.add(edge)
        return to_return

    def get_edge(self, edge_id: str) -> EdgeState:
        """ Return an edge from mould state ply by given edges_id or raises ValueError exception. """
        edge = self.find_edge(edge_id)
        if edge:
            return edge
        raise ValueError(f"Failed to get edge in mould state ply: {self.id}, by given edge_id: {edge_id}")

    def find_edge(self, edge_id: str) -> EdgeState:
        """ Tries to return an edge from mould state ply by given edge_id or None if edge state do not exist. """
        for edge in self.edges:
            if edge.id == edge_id:
                return edge

    def merge(self, new_ply_state: PlyState) -> bool:
        """Merge new ply state into existing ply state based on updated_by value (cam<id>/force/ply)"""
        log.debug("ply_state.merge invoked, for new ply: %s", new_ply_state.id)

        if not new_ply_state.updated_by or not new_ply_state.state or new_ply_state.edges is None:
            log.error("Invalid ply state. Expected: id, state, edges, updated_by to be set")
            return False

        state_updated = False
        if "cam" in new_ply_state.updated_by:
            state_updated |= self._merge_by_cam(new_ply_state)
        elif "force" in new_ply_state.updated_by:
            state_updated |= self._merge_by_force(new_ply_state)
        elif "ply" in new_ply_state.updated_by:
            state_updated |= self._merge_by_ply(new_ply_state)
        else:
            log.error("Unrecognized updated_by %s value", new_ply_state.updated_by)

        self.updated_by = new_ply_state.updated_by

        if new_ply_state.state not in {PlyStateEnum.COVERED, PlyStateEnum.FORCED}:
            log.debug("Recalculating state for ply: %s", new_ply_state.id)
            self._recalculate_state()

        return state_updated

    def _merge_by_ply(self, new_ply_state) -> bool:
        log.debug("ply_state._merge_by_ply invoked. Updating edges states for %s ply", new_ply_state.id)

        if new_ply_state.state == PlyStateEnum.EXPECTED:
            log.debug("Expected ply %s should not be merged as already exist in local mould state, skipping merge...",
                      new_ply_state.id)
            return False

        ply_state_updated = False
        if new_ply_state.state in {PlyStateEnum.COVERED, PlyStateEnum.FORCED}:
            ply_state_updated: bool = self.update_state(new_ply_state.state)

        edge_state_updated: bool = self._update_edge_states(new_ply_state.edges)

        return ply_state_updated or edge_state_updated

    def _merge_by_force(self, new_ply_state) -> bool:
        log.debug("ply_state._merge_by_force invoked. Updating ply and edges states for %s ply", new_ply_state.id)
        self.update_state(new_ply_state.state)
        self._update_edge_states(new_ply_state.edges)
        self._update_edge_cam_states(new_ply_state.edges)
        return True

    def _merge_by_cam(self, new_ply_state) -> bool:
        cam_id = new_ply_state.updated_by.split(':')[1]
        log.debug("ply_state._merge_by_cam invoked. Updating cam %s states for %s ply", cam_id, new_ply_state.id)
        ply_state_updated = False
        if new_ply_state.state in {PlyStateEnum.COVERED, PlyStateEnum.FORCED}:
            ply_state_updated: bool = self.update_state(new_ply_state.state)

        edge_state_updated: bool = self._update_cam_states(cam_id, new_ply_state)

        return edge_state_updated or ply_state_updated

    def _update_cam_states(self, cam_id: str, new_ply_state: PlyState) -> bool:
        """Update each edge cam states based on new cam states"""
        edge_state_updated = False
        for current_edge_state in self._edges:
            new_edge_state = new_ply_state.get_edge(current_edge_state.id)

            if new_edge_state.state in [EdgeStateEnum.COVERED, EdgeStateEnum.FORCED]:
                edge_state_updated |= current_edge_state.update_state(new_edge_state.state)

            new_cam_state: EdgeCamState = new_edge_state.find_cam(cam_id)
            if new_cam_state:
                log.debug(f"Updating {cam_id} cam states for {current_edge_state.id} edge")
                # cam updated is ignored to avoid cyclic message flow from ETCD store
                edge_updated, _ = current_edge_state.update_cam(cam_id, new_cam_state.state)
                edge_state_updated |= edge_updated
            else:
                log.debug(f"{cam_id} cam state not found for {current_edge_state.id} edge")

        return edge_state_updated

    def _update_edge_states(self, edges: list[EdgeState]) -> bool:
        """Update current edge states based new edge states"""
        edge_state_updated = False
        for new_edge_state in edges:
            current_edge_state = self.find_edge(new_edge_state.id)
            if current_edge_state:
                edge_state_updated: bool = current_edge_state.update_state(new_edge_state.state)
            else:
                log.error(f"{new_edge_state.id} edge state missing for {self.id} ply")
        return edge_state_updated

    def _update_edge_cam_states(self, edges: set[EdgeState]) -> bool:
        edge_state_updated = False
        for new_edge_state in edges:
            current_edge_state = self.get_edge(new_edge_state.id)
            edge_state_updated |= current_edge_state.update_cam_state(new_edge_state.cams)
        return edge_state_updated
