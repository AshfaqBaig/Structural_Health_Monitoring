from typing import Tuple

from app.logging.logger import yield_logger
from app.models.edge_cameras import EdgeCameras
from app.models.graph import Graph
from app.models.state import ply_state_extraction
from app.models.state.edge_cam_state import EdgeCamState
from app.models.state.edge_cam_state_enum import EdgeCamStateEnum
from app.models.state.edge_state import EdgeState
from app.models.state.edge_state_enum import EdgeStateEnum
from app.models.state.ply_state import PlyState
from app.models.state.ply_state_enum import PlyStateEnum
from app.shared_storage import SharedStorage
from app.utils import dict_of_dicts_merge

log = yield_logger()


class MouldState:
    """ Class for storing State Locally and leveraging its data """

    def __init__(self, plies: set[PlyState]):
        self._plies = plies

    @property
    def plies(self) -> set[PlyState]:
        """ Return all placed plies on the mould, with visible edges and no longer visible due to being covered. """
        return self._plies

    def update_cam(self, camera: str, detected_edges: set[str], missing_edges: set[str], graph: Graph) -> set[PlyState]:
        """ Update mould state plies for given data from edge verification message. """

        detected_edges_by_plies = MouldState._group_by_ply(detected_edges, "detected_edges", graph)
        missing_edges_by_plies = MouldState._group_by_ply(missing_edges, "missing_edges", graph)
        detected_and_missing_edges_by_plies = dict_of_dicts_merge(detected_edges_by_plies, missing_edges_by_plies)

        updated_mould_state_plies = set()
        for ply_id in detected_and_missing_edges_by_plies:
            ply_detected_edges = detected_and_missing_edges_by_plies.get(ply_id).get("detected_edges")
            ply_missing_edges = detected_and_missing_edges_by_plies.get(ply_id).get("missing_edges")
            ply_state = self.get_ply(ply_id)
            cam_updated, edge_updated, ply_updated = ply_state.update_cam(camera, ply_detected_edges, ply_missing_edges)

            if cam_updated:
                updated_mould_state_plies.add(ply_state)

            if ply_updated:
                covered_plies = self.process_covered_plies(ply_state, graph)
                updated_mould_state_plies.update(covered_plies)

        return updated_mould_state_plies

    def add_ply(self, ply: PlyState) -> None:
        """Add new ply to plies list"""

        self._plies.add(ply)

    @staticmethod
    def _group_by_ply(edges: set[str], edges_type: str, graph: Graph) -> dict:
        edges_by_plies = {}
        for edge in edges:
            ply_id, _ = graph.get_ply_by_edge(edge)
            if ply_id in edges_by_plies:
                if edges_type in edges_by_plies[ply_id]:
                    edges_by_plies[ply_id][edges_type].add(edge)
                else:
                    edges_by_plies[ply_id].update({ply_id: {edges_type: {edge}}})
            else:
                edges_by_plies.update({ply_id: {edges_type: {edge}}})

        return edges_by_plies

    def mark_covered_edges(self, ply: PlyState, graph: Graph) -> set[PlyState]:
        """ Marks edges covered by given ply as COVERED. """
        log.debug("mould_state.mark_covered_edges invoked, for ply: %s", ply.id)
        ply_edges_covered = graph.get_edges_covered_by_ply(ply.id)
        covered_plies_ids = set(graph.find_plies_by_edges(ply_edges_covered))
        covered_plies = self.find_plies(covered_plies_ids)

        log.debug(f"Attempting ply {ply.id} edges_covered {ply_edges_covered} to mark as COVERED...")
        for covered_ply in covered_plies:
            ply_updated = covered_ply.update_edge_states(ply_edges_covered, EdgeStateEnum.COVERED)

            ply_state_is_rigid = covered_ply.state in {PlyStateEnum.COVERED, PlyStateEnum.FORCED}
            if not ply_updated and not ply_state_is_rigid:
                covered_ply.update_state(covered_ply.state)

            covered_ply.updated_by = f"ply:{ply.id}"

        return covered_plies

    def add_expected_plies(self, graph_plies: dict, edge_cameras: EdgeCameras) -> None:
        """ Add given graph plies as new expected plies states into mould state. """
        expected_plies = self._create_plies_with_initial_states(graph_plies, edge_cameras)
        self._plies.update(expected_plies)

    def _create_plies_with_initial_states(self, graph_plies: dict, edge_cameras: EdgeCameras) -> set[PlyState]:
        """ Returns created and initialised ply state objects for given graph plies. """
        created_plies = set()
        for ply_id, graph_ply in graph_plies.items():
            if not self.find_ply(ply_id):
                ply = PlyState(ply_id)
                ply.init_state(graph_ply, edge_cameras)
                created_plies.add(ply)

        return created_plies

    def get_ply(self, ply_id: str) -> PlyState:
        """ Return a ply from mould state by given ply_id. """
        ply = self.find_ply(ply_id)
        if ply:
            return ply

        raise ValueError(f"Failed to get ply in mould state by given ply_id: {ply_id}")

    def get_plies(self, ply_ids: set[str]) -> set[PlyState]:
        """ Returns set of plies found in mould state by given ply_ids or empty set if none found. """
        to_return = set()
        for ply_id in ply_ids:
            ply = self.get_ply(ply_id)
            if ply:
                to_return.add(ply)

        return to_return

    def find_ply(self, ply_id: str) -> PlyState:
        """ Tries to return a ply from mould state by given ply_id or None if ply state do not exist. """
        for ply in self.plies:
            if ply.id == ply_id:
                return ply

    def find_plies(self, ply_ids: set[str]) -> set[PlyState]:
        """ Returns set of plies found in mould state by given ply_ids or empty set if none found. """
        to_return = set()
        for ply_id in ply_ids:
            ply = self.find_ply(ply_id)
            if ply:
                to_return.add(ply)

        return to_return

    def get_by_state(self, state: PlyStateEnum) -> set[PlyState]:
        """ Return mould plies where mould ply state is equal to given state. """
        return MouldState._filter_by_state(self._plies, state)

    def get_by_states(self, states: set[PlyStateEnum]) -> set[PlyState]:
        """ Return mould plies where mould plies states is in set of given states. """
        return MouldState._filter_by_states(self._plies, states)

    def get_edges_to_verify(self) -> Tuple[set[EdgeState], set[EdgeState]]:
        """ Returns set of plies edges for verification based on current mould state data. """
        detected_edges = self.get_edges_by_states({EdgeStateEnum.DETECTED})
        missing_edges = self.get_edges_by_states({EdgeStateEnum.MISSING})
        return detected_edges, missing_edges

    def get_placed_plies_on_mould(self) -> set[PlyState]:
        """ Return all placed plies on the mould, with visible edges and no longer visible due to being covered. """
        return MouldState._filter_by_states(
            self._plies, {PlyStateEnum.PLACED, PlyStateEnum.FORCED, PlyStateEnum.COVERED, PlyStateEnum.MISSING})

    @staticmethod
    def _filter_by_state(plies: set[PlyState], state: PlyStateEnum) -> set[PlyState]:
        """ Filters and returns subset of given plies matching given state. """
        return MouldState._filter_by_states(plies, {state})

    @staticmethod
    def _filter_by_states(plies: set[PlyState], states: set[PlyStateEnum]) -> set[PlyState]:
        """ Filters and returns subset of given plies matching given states. """
        return {ply for ply in plies if ply.state in states}

    @staticmethod
    def _filter_by_previous_and_current_states(
            plies: set[PlyState], previous: PlyStateEnum, current: PlyStateEnum) -> set[PlyState]:
        """ Filters and returns subset of given plies where mould plies match given previous and current states. """
        return {ply for ply in plies if ply.state == current and ply.previous_state == previous}

    @staticmethod
    def filter_missing_plies(plies: set[PlyState]) -> set[PlyState]:
        """ Filters and returns subset of given plies where state matching missing_plies. """
        return MouldState._filter_by_state(plies, PlyStateEnum.MISSING)

    @staticmethod
    def filter_forced_plies(plies: set[PlyState]) -> set[PlyState]:
        """ Filters and returns subset of given plies where state matching forced_plies. """
        return MouldState._filter_by_state(plies, PlyStateEnum.FORCED)

    @staticmethod
    def filter_correctly_placed_plies(plies: set[PlyState]) -> set[PlyState]:
        """ Filters and returns subset of given plies where state change matching correctly_placed_plies. """
        return MouldState._filter_by_previous_and_current_states(plies, PlyStateEnum.EXPECTED, PlyStateEnum.PLACED)

    @staticmethod
    def filter_plies_by_ply_ids(plies: set[PlyState], plies_ids: set[str]) -> set[PlyState]:
        to_return = set()
        for ply in plies:
            if ply.id in plies_ids:
                to_return.add(ply)

        return to_return

    @staticmethod
    def filter_no_longer_missing_plies(plies: set[PlyState]) -> set[PlyState]:
        """ Filters and returns subset of given plies where state change matching no_longer_missing_plies. """
        missing_to_placed_plies = MouldState._filter_by_previous_and_current_states(
            plies, PlyStateEnum.MISSING, PlyStateEnum.PLACED)
        missing_to_covered_plies = MouldState._filter_by_previous_and_current_states(
            plies, PlyStateEnum.MISSING, PlyStateEnum.COVERED)
        return missing_to_placed_plies | missing_to_covered_plies

    def process_covered_plies(self, ply: PlyState, graph: Graph) -> set[PlyState]:
        """ Process ply_state affected plies by marking covered edges """
        ply_is_correctly_placed = ply.previous_state == PlyStateEnum.EXPECTED and \
                                  ply.state in {PlyStateEnum.PLACED, PlyStateEnum.FORCED}
        if ply_is_correctly_placed:
            covered_plies = self.mark_covered_edges(ply, graph)
            return covered_plies

        return set()

    def get_edges(self) -> set[EdgeState]:
        """ Returns all edges from mould state plies. """
        plies_edges = set()
        for ply in self._plies:
            plies_edges.update(ply.edges)

        return plies_edges

    def get_edges_by_states(self, states: set[EdgeStateEnum]) -> set[EdgeState]:
        """ Return mould plies edges where edges states is in set of given states. """
        return MouldState.filter_edges_by_states(self.get_edges(), states)

    @staticmethod
    def filter_edges_by_states(edges: set[EdgeState], states: set[EdgeStateEnum]) -> set[EdgeState]:
        """ Filters and returns subset of given edges matching given states. """
        return {edge for edge in edges if edge.state in states}

    @staticmethod
    def filter_uncovered_edges(edges: set[EdgeState]) -> set[EdgeState]:
        """ Filters and returns subset of given edges matching states of uncovered type. """
        uncovered_edge_states = {EdgeStateEnum.MISSING, EdgeStateEnum.DETECTED, EdgeStateEnum.FORCED}
        return {edge for edge in edges if edge.state in uncovered_edge_states}

    def force_ply(self, ply_id: str) -> PlyState:
        """ Mark unverifiable ply as FORCED in mould state. """
        ply = self.get_ply(ply_id)
        for edge in ply.edges:
            edge.update_state(EdgeStateEnum.FORCED)

        ply.update_state(PlyStateEnum.FORCED)
        ply.updated_by = "command:force_ply"
        return ply

    def get_all_cam_ids(self) -> set[str]:
        """ Returns all camera ids based on given mould state. """
        all_plies = self.plies
        all_cams = ply_state_extraction.cam_states(all_plies)
        all_cam_ids = MouldState._extract_camera_ids(all_cams)
        return all_cam_ids

    def get_high_frame_rate_cam_ids(self) -> set[str]:
        """ Returns high frame rate camera ids based on given mould state. """
        high_frame_rate_plies = self.get_by_states({PlyStateEnum.EXPECTED, PlyStateEnum.MISSING})
        high_frame_rate_cams = ply_state_extraction.cam_states(high_frame_rate_plies)
        high_frame_rate_cam_ids = MouldState._extract_camera_ids(high_frame_rate_cams)
        return high_frame_rate_cam_ids

    def get_low_frame_rate_cam_ids(self) -> set[str]:
        """ Returns low frame rate camera ids based on given mould state. """
        all_cam_ids = self.get_all_cam_ids()
        high_frame_rate_cam_ids = self.get_high_frame_rate_cam_ids()
        low_frame_rate_cam_ids = all_cam_ids - high_frame_rate_cam_ids
        return low_frame_rate_cam_ids

    @staticmethod
    def _extract_camera_ids(cam_states: set[EdgeCamState]) -> set[str]:
        camera_ids = set()
        for cam_state in cam_states:
            camera_ids.add(cam_state.id)

        return camera_ids

    def undo_plies_to(self, ply_id: str, shared_storage: SharedStorage, graph: Graph) -> set[PlyState]:
        ply = self.get_ply(ply_id)
        self.validate_ply_is_not_of_state(ply, "undo_plies_to", PlyStateEnum.EXPECTED)

        all_dependent_plies_in_graph = graph.get_all_dependent_plies_on_ply(ply.id)
        plies_to_undo = self._get_plies_to_undo(ply.id, all_dependent_plies_in_graph)
        undone_plies = self._try_to_undo_plies_from_deepest_dependent(ply_id, plies_to_undo, shared_storage, graph)

        return undone_plies

    def _try_to_undo_plies_from_deepest_dependent(
            self, ply_id: str, plies_to_undo: list[str], shared_storage: SharedStorage, graph: Graph) -> set[PlyState]:
        undone_plies = set()
        try:
            for ply_to_undo in reversed(plies_to_undo):
                undone_plies.update(self.undo_ply(ply_to_undo, shared_storage, graph))
        except Exception as ex:
            raise ValueError(
                f"Failed to undo_plies_to for given ply_id: {ply_id} and its dependents: {plies_to_undo}, due to {ex}")
        return undone_plies

    def undo_plies_to_dry_run(self, ply_id: str, graph: Graph) -> list[str]:
        ply = self.get_ply(ply_id)
        self.validate_ply_is_not_of_state(ply, "undo_plies_to_dry_run", PlyStateEnum.EXPECTED)

        all_dependent_plies_in_graph = graph.get_all_dependent_plies_on_ply(ply.id)
        plies_to_undo = self._get_plies_to_undo(ply.id, all_dependent_plies_in_graph)

        return plies_to_undo

    def _get_plies_to_undo(self, undo_to_ply_id_inclusive: str, all_dependent_plies: list[str]) -> list[str]:
        plies_to_undo = [undo_to_ply_id_inclusive]
        for ply_id in all_dependent_plies:
            ply = self.find_ply(ply_id)
            if not ply or ply.state == PlyStateEnum.EXPECTED:
                break
            plies_to_undo.append(ply_id)
        return plies_to_undo

    def undo_ply(self, ply_id: str, shared_storage: SharedStorage, graph: Graph) -> set[PlyState]:
        ply = self.get_ply(ply_id)
        self.validate_ply_is_not_of_state(ply, "undo", PlyStateEnum.EXPECTED)
        self.validate_ply_is_not_of_state(ply, "undo", PlyStateEnum.COVERED)
        self.validate_ply_has_no_covered_edges(ply)

        plies_by_previous_plies = self.find_plies(set(graph.get_plies_by_previous_plies(ply.id)))
        removable_plies = self._filter_by_state(plies_by_previous_plies, PlyStateEnum.EXPECTED)
        self._validate_undo_ply_is_not_a_dependency_to_other_plies(ply, plies_by_previous_plies, removable_plies)

        new_expected_ply = self._reset_undo_ply_to_expected(ply, shared_storage)
        old_expected_removed_plies = self._remove_plies_globally(removable_plies, shared_storage)
        uncovered_plies = self._reset_uncovered_plies(ply, shared_storage, graph)

        return old_expected_removed_plies | {new_expected_ply} | uncovered_plies

    @staticmethod
    def _validate_undo_ply_is_not_a_dependency_to_other_plies(ply, plies_dependent_on_undo_ply, removable_plies):
        if plies_dependent_on_undo_ply != removable_plies:
            non_expected_plies = plies_dependent_on_undo_ply - removable_plies
            raise ValueError(f"Given ply {ply.id} is not valid to undo, "
                             f"plies: {sorted([ply.id for ply in non_expected_plies])} depend on it, undo them first.")

    def _remove_plies_globally(self, plies_to_remove: set[PlyState], shared_storage: SharedStorage) -> set[PlyState]:
        removed_plies = set()
        for ply in plies_to_remove:
            removed_plies.add(self.remove(ply))
            shared_storage.delete_ply(ply.id)
        return removed_plies

    def _reset_undo_ply_to_expected(self, ply: PlyState, shared_storage: SharedStorage) -> PlyState:
        edges_to_reset = self.filter_uncovered_edges(ply.edges)
        edges_to_reset_ids = {edge.id for edge in edges_to_reset}
        new_expected_ply = self._reset_ply_to_expected_state(ply, edges_to_reset_ids)
        shared_storage.update_mould_plies({new_expected_ply})
        return new_expected_ply

    def _reset_uncovered_plies(self, ply: PlyState, shared_storage: SharedStorage, graph: Graph) -> set[PlyState]:
        covered_edges = graph.get_edges_covered_by_ply(ply.id)
        covered_plies_ids = set(graph.find_plies_by_edges(covered_edges))
        uncovered_plies = self._reset_plies_to_placed_state(covered_plies_ids, covered_edges)
        shared_storage.update_mould_plies(uncovered_plies)
        return uncovered_plies

    @staticmethod
    def validate_ply_has_no_covered_edges(ply: PlyState) -> None:
        covered_edges = MouldState.filter_edges_by_states(ply.edges, {EdgeStateEnum.COVERED})
        ply_has_covered_edges = len(covered_edges) > 0
        if ply_has_covered_edges:
            raise ValueError(f"Given ply {ply.id} is not valid to undo, it has COVERED edge.")

    def remove(self, ply: PlyState) -> PlyState:
        log.info(f"Removing ply {ply.id} from local mould state...")
        self.plies.remove(ply)
        return ply

    @staticmethod
    def _reset_ply_to_expected_state(ply: PlyState, edges_to_reset: set[str]) -> PlyState:
        ply.update_state(PlyStateEnum.EXPECTED)
        ply.updated_by = "command:undo_ply:force"
        ply.reset_edges_to_state(edges_to_reset, EdgeStateEnum.MISSING, EdgeCamStateEnum.NEVER_DETECTED)
        return ply

    def _reset_plies_to_placed_state(self, ply_ids: set[str], edges_to_reset: set[str]) -> set[PlyState]:
        plies = self.get_plies(ply_ids)
        plies_to_reset = self._filter_non_expected_plies(plies)
        for ply in plies_to_reset:
            if ply.state is PlyStateEnum.COVERED:
                ply.update_state(PlyStateEnum.PLACED)
            ply.updated_by = "command:undo_ply:force"
            ply.reset_edges_to_state(edges_to_reset, EdgeStateEnum.DETECTED, EdgeCamStateEnum.DETECTED)

        return plies_to_reset

    @staticmethod
    def _filter_non_expected_plies(plies: set[PlyState]) -> set[PlyState]:
        filtered_plies = set()
        for ply in plies:
            if ply.state != PlyStateEnum.EXPECTED:
                filtered_plies.add(ply)
            else:
                log.warning(f"Skipping ply {ply.id} state reset from EXPECTED -> PLACED, "
                            f"this should not happen but can due poor ply dependency relations in static-graph data.")

        return filtered_plies

    def recheck_ply(self, ply_id: str) -> PlyState:
        ply = self.get_ply(ply_id)
        self.validate_ply_is_not_of_state(ply, "recheck", PlyStateEnum.EXPECTED)
        self.validate_ply_is_not_of_state(ply, "recheck", PlyStateEnum.COVERED)
        ply.reset_all_uncovered_edges()
        ply.update_state(PlyStateEnum.MISSING)
        ply.updated_by = "command:recheck_ply:force"
        return ply

    @staticmethod
    def validate_ply_is_not_of_state(ply: PlyState, action: str, state: PlyStateEnum) -> None:
        if ply.state == state:
            raise ValueError(f"Given ply {ply.id} is not valid ply to {action}, it must be not {state.name} ply.")
