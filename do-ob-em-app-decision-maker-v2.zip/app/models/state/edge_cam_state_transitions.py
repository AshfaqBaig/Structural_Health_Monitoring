# pylint: disable=missing-module-docstring
from app.models.state.edge_cam_state_enum import EdgeCamStateEnum


class EdgeCamStateTransitions:
    """Edge Camera State transition matrix"""

    config = [
        {
            "current": EdgeCamStateEnum.NEVER_DETECTED,
            "new": EdgeCamStateEnum.MISSING,
            "transition": EdgeCamStateEnum.NEVER_DETECTED
        },
        {
            "current": EdgeCamStateEnum.NEVER_DETECTED,
            "new": EdgeCamStateEnum.DETECTED,
            "transition": EdgeCamStateEnum.DETECTED
        },
        {
            "current": EdgeCamStateEnum.MISSING,
            "new": EdgeCamStateEnum.MISSING,
            "transition": EdgeCamStateEnum.MISSING
        },
        {
            "current": EdgeCamStateEnum.MISSING,
            "new": EdgeCamStateEnum.DETECTED,
            "transition": EdgeCamStateEnum.DETECTED
        },
        {
            "current": EdgeCamStateEnum.DETECTED,
            "new": EdgeCamStateEnum.MISSING,
            "transition": EdgeCamStateEnum.MISSING
        },
        {
            "current": EdgeCamStateEnum.DETECTED,
            "new": EdgeCamStateEnum.DETECTED,
            "transition": EdgeCamStateEnum.DETECTED
        }
    ]
