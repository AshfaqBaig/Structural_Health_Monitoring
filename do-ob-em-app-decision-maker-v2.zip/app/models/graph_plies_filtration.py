def phantom_plies(plies: dict) -> dict:
    """ Filters Phantom plies, plies with empty edges, from given graph plies. """
    phantom_plies = {}
    for ply_id, ply in plies.items():
        if not ply.get("edges"):
            phantom_plies.update({ply_id: ply})
    return phantom_plies
