import uuid

import app.config as cfg


class PayloadMetadata:
    """ Class for storing inbound message metadata. """

    def __init__(self, session: dict = None, correlation_id: str = None, custom_properties=None):
        if session is None:
            session = {
                "deviceModuleId": f"{cfg.DEVICE_MODULE_ID}",
                "moduleId": f"{cfg.MODULE_APP_NAME}",
                "mouldId": f"{cfg.MOULD_ID}",
            }
        if correlation_id is None:
            correlation_id = str(uuid.uuid4())
        if custom_properties is None:
            custom_properties = {}

        self._session = session
        self._correlation_id = correlation_id
        self._custom_properties = custom_properties
        self._content_type = None

    def __str__(self) -> str:
        return str(self.__dict__)

    @property
    def session(self) -> dict:
        """ Get session """
        return self._session

    @property
    def correlation_id(self) -> str:
        """ Get correlation id """
        return self._correlation_id

    @property
    def custom_properties(self) -> dict:
        """ Get custom_properties """
        return self._custom_properties

    @property
    def camera_id(self) -> str:
        """ Get camera id """
        return self.session.get("cameraId")

    @property
    def content_type(self) -> str:
        """ Get content_type """
        return self._content_type

    @content_type.setter
    def content_type(self, content_type: str) -> None:
        """ Set content_type """
        self._content_type = content_type
