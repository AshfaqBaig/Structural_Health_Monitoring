class PliesToLaser:
    def __init__(
            self,
            correctly_placed_plies: dict = None,
            plies_to_be_placed: dict = None,
            new_missing_plies: dict = None,
            no_longer_missing_plies: dict = None,
            forced_plies: dict = None,
            removed_plies: dict = None,
    ):
        if correctly_placed_plies is None:
            correctly_placed_plies = {}
        if plies_to_be_placed is None:
            plies_to_be_placed = {}
        if new_missing_plies is None:
            new_missing_plies = {}
        if no_longer_missing_plies is None:
            no_longer_missing_plies = {}
        if forced_plies is None:
            forced_plies = {}
        if removed_plies is None:
            removed_plies = {}

        self._correctly_placed_plies = correctly_placed_plies
        self._plies_to_be_placed = plies_to_be_placed
        self._new_missing_plies = new_missing_plies
        self._no_longer_missing_plies = no_longer_missing_plies
        self._forced_plies = forced_plies
        self._removed_plies = removed_plies

    def __str__(self) -> str:
        return str(self.__dict__)

    @property
    def correctly_placed_plies(self) -> dict:
        return self._correctly_placed_plies

    @property
    def plies_to_be_placed(self) -> dict:
        return self._plies_to_be_placed

    @property
    def new_missing_plies(self) -> dict:
        return self._new_missing_plies

    @property
    def no_longer_missing_plies(self) -> dict:
        return self._no_longer_missing_plies

    @property
    def forced_plies(self) -> dict:
        return self._forced_plies

    @property
    def removed_plies(self) -> dict:
        return self._removed_plies
