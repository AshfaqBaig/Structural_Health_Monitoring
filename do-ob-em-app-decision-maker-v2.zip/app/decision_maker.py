""" Orchestrator for Decision Maker application """
import asyncio
import copy
import json

from app import file_storage, config as cfg
from app.dm_helper import edge_verification_message_extraction, edge_verification_message_validation, graph_resolver
from app.dm_helper.image_grabbing import ImageGrabbing
from app.dm_helper.laser_feedback import LaserFeedback
from app.global_mould_state_enum import GlobalMouldState
from app.logging.logger import yield_logger
from app.messaging_wrapper import MessagingWrapper
from app.models import graph_plies_filtration, graph_plies_extraction
from app.models.edge_cameras import EdgeCameras
from app.models.feedback_positions import FeedbackPositions
from app.models.graph import Graph
from app.models.payload_metadata import PayloadMetadata
from app.models.plies_to_laser import PliesToLaser
from app.models.state import ply_state_extraction
from app.models.state.edge_state_enum import EdgeStateEnum
from app.models.state.mould_state import MouldState
from app.models.state.ply_state import PlyState
from app.models.state.ply_state_enum import PlyStateEnum
from app.models.team_instructions import TeamInstructions
from app.shared_storage import SharedStorage
from app.util import require
from app.utils import dict_subtract, dict_of_dicts_merge

log = yield_logger()


class DecisionMaker:
    """
    The orchestrator for Decision Maker app - handles all logic when team instructions received via C2DM requests
    and input messages received from edge verification.
    """

    def __init__(
            self,
            shared_storage: SharedStorage,
            messaging: MessagingWrapper,
            team_instructions: TeamInstructions,
            mould_state: MouldState
    ):
        self._shared_storage = shared_storage
        self._messaging = messaging

        self._team_instructions: TeamInstructions = team_instructions
        self._mould_state: MouldState = mould_state

        self._static_graph: Graph = None
        self._sub_graph: Graph = None
        self._edge_cameras: EdgeCameras = None
        self._feedback_positions: FeedbackPositions = None

        log.info("Subscribing for module settings updates from ETCD store...")
        self._shared_storage.watch_module_settings_updates(self._module_settings_update_callback)
        log.info("Subscribing for Global Mould State team instructions updates from ETCD store...")
        self._shared_storage.watch_mould_instructions_updates(self._global_mould_state_instructions_update_callback)
        log.info("Subscribing for Global Mould State plies updates from ETCD store...")
        self._shared_storage.watch_mould_plies_updates(self._global_mould_state_plies_update_callback)
        log.info("Subscribing for Global Mould State plies removal from ETCD store...")
        self._shared_storage.watch_mould_plies_removals(self._global_mould_state_plies_removal_callback)
        log.info("Subscribing for Global Mould State finalisation updates from ETCD store...")
        self._shared_storage.watch_mould_state_updates(self._global_mould_state_finalisation_update_callback)

    def __str__(self) -> str:
        """ Representation of this object with parameters """
        return str(self.__dict__)

    @staticmethod
    def _check_for_self_messaging(value: dict) -> None:
        if type(value) == dict and value.get("source_device") == cfg.DEVICE_MODULE_ID:
            raise ValueError("Discarding self-message received from global mould state")

    def _module_settings_update_callback(self, value: str) -> None:
        """ Handle module settings change incoming from etcd """
        # TODO: a place holder to implement logic
        try:
            value: dict = json.loads(value)
            log.info(f"Received module settings update from ETCD: {value}")
        except ValueError:
            log.exception("Failed to deserialize value received via module settings update.")

    def _global_mould_state_instructions_update_callback(self, value: str) -> None:
        """ Handle global mould state update on team instructions by merging it with local team_instructions. """
        team_instruction = json.loads(value)
        self._check_for_self_messaging(team_instruction)
        log.info(f"Received team instruction update from global mould state: {team_instruction}")
        require.not_empty(team_instruction, "team_instruction")
        metadata_to_forward = PayloadMetadata()
        asyncio.run(
            self._handle_team_instruction_update(
                team_instruction, metadata_to_forward, cfg.FF_ENABLE_CHAINED_STATE_SHARE))

    async def _handle_team_instruction_update(
            self, team_instruction: dict, metadata_to_forward: PayloadMetadata, is_state_share_chained=True) -> None:
        """ Handles team instruction received either via C2DM request or global mould state update. """
        log.debug(f"decision_maker._handle_team_instruction invoked")

        if team_instruction in self._team_instructions.data:
            log.debug("Received team_instruction is already exists locally, skipping merge process.")
        else:
            log.info(f"Adding new team instruction...")
            self._team_instructions.update(team_instruction)
            self._process_global_mould_state_instructions_update(team_instruction, is_state_share_chained)
            await self.process_team_instructions_changes(metadata_to_forward)

    def _process_global_mould_state_instructions_update(
            self, team_instruction: dict, is_state_share_chained: bool) -> None:
        # Do not send if invoked via shared storage callback and FF_ENABLE_CHAINED_STATE_SHARE is False
        if is_state_share_chained:
            self._shared_storage.update_mould_instructions([team_instruction])
        else:
            log.debug("Chained state share is Disabled, skipping global mould state instructions update...")

    async def process_team_instructions_changes(self, metadata_to_forward: PayloadMetadata) -> None:
        log.debug("decision_maker._process_team_instructions_changes invoked")
        require.not_none(metadata_to_forward, "metadata_to_forward")

        if not self._all_files_for_instructions_layers_are_loaded():
            self._load_data_provisioning_files()

        self._sub_graph = self._static_graph.create_sub_graph(self._team_instructions)

        #  TODO: Refactor to compare sets first for diff and only different plies to process to merge
        global_mould_state_plies: dict = self._shared_storage.get_mould_plies()
        await self._process_global_mould_state_plies(global_mould_state_plies)

        plies_to_be_placed = self._find_plies_to_be_placed()
        self._mould_state.add_expected_plies(plies_to_be_placed, self._edge_cameras)

        verification_payload = self._get_edge_verification_payload(metadata_to_forward.session)
        await self._messaging.send_message_to_edge_verification(verification_payload, metadata_to_forward)

        await self._start_image_streaming_or_update_image_grabber_refresh_interval(metadata_to_forward)

        state_plies_to_be_placed = self._mould_state.get_plies(set(plies_to_be_placed))
        self._shared_storage.update_mould_plies(state_plies_to_be_placed)

        await self._send_mould_state_statistics(metadata_to_forward)

        plies_to_laser = PliesToLaser(plies_to_be_placed=plies_to_be_placed)
        await self._send_to_trace_output(plies_to_laser, metadata_to_forward)

        feedback_to_send = {}
        self._process_plies_to_be_placed(plies_to_be_placed, feedback_to_send)
        await self._send_to_laser(feedback_to_send, metadata_to_forward)

    def _all_files_for_instructions_layers_are_loaded(self) -> bool:
        if self._static_graph is None:
            return False
        static_graph_layer_ids = graph_plies_extraction.layer_ids(self._static_graph.get_all_plies())
        return static_graph_layer_ids == self._team_instructions.layer_ids

    def _load_data_provisioning_files(self) -> None:
        log.info(f"Loading Data Provisioning files...")
        try:
            self._static_graph = file_storage.get_static_graph(self._team_instructions)
            self._edge_cameras = file_storage.get_edge_cameras(self._team_instructions)
            self._feedback_positions = file_storage.get_feedback_positions(self._team_instructions)

            if cfg.FF_REMOVE_INVISIBLE_EDGES_ON_GRAPH_LOAD:
                invisible_edges = self._edge_cameras.invisible_edges
                if invisible_edges:
                    self._static_graph.remove_invisible_edges(invisible_edges)

        except Exception as ex:
            error_message = f"Failed to load_data_from_mapping_files for team instructions: {self._team_instructions.data}"
            self._clear()
            raise ValueError(error_message) from ex

    async def _start_image_streaming_or_update_image_grabber_refresh_interval(self, metadata: PayloadMetadata):
        low_frame_rate_cams = self._mould_state.get_low_frame_rate_cam_ids()
        high_frame_rate_cams = self._mould_state.get_high_frame_rate_cam_ids()
        image_grabber = ImageGrabbing(self._messaging)
        await image_grabber.start_update(low_frame_rate_cams, cfg.PASSIVE_EDGE_VERIFICATION_REFRESH_INTERVAL, metadata)
        await image_grabber.start_update(high_frame_rate_cams, cfg.ACTIVE_EDGE_VERIFICATION_REFRESH_INTERVAL, metadata)

    async def _process_global_mould_state_plies(self, global_mould_state_plies: dict) -> None:
        if not global_mould_state_plies:
            log.debug("Did not found plies in ETCD, skipping processing.")
        else:
            log.debug("Fetched plies from ETCD, processing...")
            for global_ply_state in global_mould_state_plies.values():
                await self._handle_mould_state_ply_update(global_ply_state)

    def _global_mould_state_plies_update_callback(self, value: str) -> None:
        global_ply_state = json.loads(value)
        self._check_for_self_messaging(global_ply_state)
        log.debug(f"Received mould state ply update from ETCD: {global_ply_state.get('ply_id')}")
        require.not_empty(global_ply_state, "global_ply_state")
        asyncio.run(self._handle_mould_state_ply_update(global_ply_state))

    async def _handle_mould_state_ply_update(self, global_ply_state: dict) -> None:
        """ Handle global mould state update on ply by merging it with current state and updating dependent plies. """
        new_ply_state: PlyState = PlyState.deserialize(global_ply_state)
        self._sub_graph.validate(new_ply_state.id)
        existing_ply_state = self._mould_state.find_ply(new_ply_state.id)

        if not existing_ply_state:
            log.warning("Adding new ply %s state, which doesn't exist in local mould state", new_ply_state.id)
            self._mould_state.add_ply(new_ply_state)
        elif new_ply_state == existing_ply_state:
            log.debug("Received ply state from ETCD store is the same as stored locally, skipping merge process.")
        else:
            log.debug("Merging new ply state into local mould state...")
            await self._merge_ply_state(existing_ply_state, new_ply_state, self._sub_graph)

    async def _merge_ply_state(self, existing_ply_state: PlyState, new_ply_state: PlyState, graph: Graph) -> None:
        """Merge incoming shared state update into current ply state and update affected plies"""

        state_updated: bool = existing_ply_state.merge(new_ply_state)
        if state_updated:
            covered_plies: set[PlyState] = self._mould_state.process_covered_plies(existing_ply_state, graph)
            updated_mould_state_plies = {existing_ply_state} | covered_plies
            metadata_to_forward = PayloadMetadata()
            await self._process_mould_state_changes(
                updated_mould_state_plies, metadata_to_forward, cfg.FF_ENABLE_CHAINED_STATE_SHARE)
        else:
            log.debug("Received ply from ETCD store did not changed local state, skipping mould state changes process.")

    async def handle_edge_verification_message(self, verification_data: list,
                                               metadata_to_forward: PayloadMetadata) -> None:
        """ Handles edge verification message data received from EV module. """
        log.debug("decision_maker.handle_edge_verification_message invoked")
        self._require_initialised_mould_state("handle_edge_verification_message")
        require.not_none(metadata_to_forward, "metadata_to_forward")

        detected_edges, missing_edges = edge_verification_message_extraction.detected_and_missing_edges(
            verification_data)
        edge_verification_message_validation.validate(detected_edges, missing_edges, self._mould_state)

        updated_mould_state_plies = self._mould_state.update_cam(
            metadata_to_forward.camera_id, detected_edges, missing_edges, self._sub_graph)

        await self._process_mould_state_changes(updated_mould_state_plies, metadata_to_forward)

    async def _process_mould_state_changes(
            self,
            updated_plies: set[PlyState],
            metadata_to_forward: PayloadMetadata,
            is_state_share_chained=True
    ) -> None:
        if updated_plies:
            log.debug("Found updated mould state plies: %s, processing changes...", {ply.id for ply in updated_plies})

            correctly_placed_plies_states = self._mould_state.filter_correctly_placed_plies(updated_plies)
            correctly_placed_plies = graph_resolver.plies_from(correctly_placed_plies_states, self._sub_graph)

            plies_to_be_placed = self._find_plies_to_be_placed()
            self._mould_state.add_expected_plies(plies_to_be_placed, self._edge_cameras)

            verification_payload = self._get_edge_verification_payload(metadata_to_forward.session)
            await self._messaging.send_message_to_edge_verification(verification_payload, metadata_to_forward)

            new_missing_plies_states = self._find_new_missing_plies(updated_plies)
            new_missing_plies = graph_resolver.plies_from(new_missing_plies_states, self._sub_graph)

            no_longer_missing_plies_states = self._mould_state.filter_no_longer_missing_plies(updated_plies)
            no_longer_missing_plies = graph_resolver.plies_from(no_longer_missing_plies_states, self._sub_graph)

            removed_plies_states = self._find_removed_plies(updated_plies)
            removed_plies = graph_resolver.plies_from(removed_plies_states, self._sub_graph)

            forced_plies_states = self._mould_state.filter_forced_plies(updated_plies)
            forced_plies = graph_resolver.plies_from(forced_plies_states, self._sub_graph)

            self._process_global_mould_state_plies_update(plies_to_be_placed, updated_plies, is_state_share_chained)

            await self._send_mould_state_statistics(metadata_to_forward)

            plies_to_laser = PliesToLaser(
                correctly_placed_plies,
                plies_to_be_placed,
                new_missing_plies,
                no_longer_missing_plies,
                forced_plies,
                removed_plies)

            await self._send_to_trace_output(plies_to_laser, metadata_to_forward)

            feedback_to_laser = self._aggregate_feedback_to_laser(plies_to_laser)
            await self._send_to_laser(feedback_to_laser, metadata_to_forward)
            await self._start_image_streaming_or_update_image_grabber_refresh_interval(metadata_to_forward)

        else:
            log.debug("No updated mould state plies found, skipping mould state changes processing.")

    def _find_removed_plies(self, updated_plies: set[PlyState]) -> set[PlyState]:
        removed_plies = set()
        for ply in updated_plies:
            if not self._mould_state.find_ply(ply.id):
                removed_plies.add(ply)

        return removed_plies

    def _find_new_missing_plies(self, updated_plies: set[PlyState]) -> set[PlyState]:
        new_missing_plies = self._mould_state.filter_missing_plies(updated_plies)
        if cfg.FF_FILTER_MISSING_PLIES_LIKELY_BEING_COVERED:
            missing_plies_likely_being_covered = self._filter_missing_plies_likely_being_covered(new_missing_plies)
            filtered_ids = {ply.id for ply in missing_plies_likely_being_covered}
            log.debug(f"Filtered new missing plies that are likely being covered: {filtered_ids}")
            return new_missing_plies - missing_plies_likely_being_covered
        else:
            return new_missing_plies

    def _filter_missing_plies_likely_being_covered(self, plies: set[PlyState]) -> set[PlyState]:
        missing_plies_likely_being_covered = set()
        edges_to_be_covered = self._find_edges_to_be_covered()
        for ply in plies:
            missing_edges = self._extract_missing_edges_ids(ply)
            if missing_edges.issubset(edges_to_be_covered):
                missing_plies_likely_being_covered.add(ply)

        return missing_plies_likely_being_covered

    def _find_edges_to_be_covered(self) -> set[str]:
        plies_to_be_placed = self._find_plies_to_be_placed()
        edges_to_be_covered = self._sub_graph.get_edges_covered_by_plies(set(plies_to_be_placed))
        return edges_to_be_covered

    @staticmethod
    def _extract_missing_edges_ids(ply: PlyState) -> set[str]:
        edges = ply_state_extraction.edge_states({ply})
        missing_edges_states = MouldState.filter_edges_by_states(edges, {EdgeStateEnum.MISSING})
        missing_edges = {edge.id for edge in missing_edges_states}
        return missing_edges

    def _process_global_mould_state_plies_update(self, plies_to_be_placed, updated_plies, is_state_share_chained):
        # Do not send if invoked via shared storage callback and FF_ENABLE_CHAINED_STATE_SHARE is False
        if is_state_share_chained:
            state_plies_to_be_placed = self._mould_state.get_plies(set(plies_to_be_placed))
            removed_plies_states = self._find_removed_plies(updated_plies)
            plies_to_update_on_global_mould_state = (updated_plies | state_plies_to_be_placed) - removed_plies_states
            self._shared_storage.update_mould_plies(plies_to_update_on_global_mould_state)
        else:
            log.debug("Chained state share is Disabled, skipping global mould state plies update...")

    async def _send_mould_state_statistics(self, metadata: PayloadMetadata) -> None:
        mould_state_statistics = self._create_mould_state_statistics()
        statistics_payload = self._envelop_statistics_payload_data(metadata, mould_state_statistics)
        await self._messaging.send_message_to_stats(statistics_payload, metadata)

    def _create_mould_state_statistics(self) -> dict:
        pallets_by_layers = self._group_pallets_by_layers()
        return {
            "layers": pallets_by_layers
        }

    def _group_pallets_by_layers(self) -> dict:
        pallets_by_layers = {}
        for layer_id in self._team_instructions.layer_ids:
            pallets_by_layer = self._group_pallets_by_layer(layer_id)
            layer_entry = {
                "pallets": pallets_by_layer
            }
            pallets_by_layers.update({layer_id: layer_entry})

        return pallets_by_layers

    def _group_pallets_by_layer(self, layer_id: str) -> dict[str, dict[str, int]]:
        pallets_by_layer = {}
        pallet_ids = self._sub_graph.get_pallets_by_layer(layer_id)
        for pallet_id in pallet_ids:
            pallet_stats = self._generate_pallet_statistics(pallet_id, layer_id)
            pallets_by_layer.update({pallet_id: pallet_stats})

        return pallets_by_layer

    def _generate_pallet_statistics(self, pallet_id: str, layer_id: str) -> dict[str, int]:
        pallet_plies_ids = set(self._sub_graph.get_plies_by_pallet_and_layer(pallet_id, layer_id))
        total_plies_count = len(pallet_plies_ids)

        placed_plies_on_mould = self._mould_state.get_placed_plies_on_mould()
        pallet_placed_plies = self._mould_state.filter_plies_by_ply_ids(placed_plies_on_mould, pallet_plies_ids)
        placed_plies_count = len(pallet_placed_plies)

        missing_plies = self._mould_state.get_by_state(PlyStateEnum.MISSING)
        pallet_missing_plies = self._mould_state.filter_plies_by_ply_ids(missing_plies, pallet_plies_ids)
        missing_plies_count = len(pallet_missing_plies)

        return {
            "totalPlies": total_plies_count,
            "placedPlies": placed_plies_count,
            "missingPlies": missing_plies_count
        }

    @staticmethod
    def _envelop_statistics_payload_data(metadata: PayloadMetadata, data: dict) -> dict:
        return {
            "metadata": {
                "mouldId": cfg.MOULD_ID,
                "hallId": cfg.HALL_ID,
                "locationId": cfg.LOCATION_ID,
                "correlationId": metadata.correlation_id,
            },
            "mouldState": data
        }

    async def _send_to_trace_output(self, plies_to_laser: PliesToLaser, metadata: PayloadMetadata) -> None:
        trace_payload = {
            "metadata": {
                "teamInstructions": self._team_instructions.data,
                "mouldId": cfg.MOULD_ID,
                "hallId": cfg.HALL_ID,
                "locationId": cfg.LOCATION_ID,
                "session": metadata.session,
                "correlationId": metadata.correlation_id,
                "customProperties": metadata.custom_properties,
            },
            "correctlyPlacedPlies": plies_to_laser.correctly_placed_plies,
            "pliesToBePlaced": plies_to_laser.plies_to_be_placed,
            "newMissingPlies": plies_to_laser.new_missing_plies,
            "noLongerMissingPlies": plies_to_laser.no_longer_missing_plies,
            "forcedPlies": plies_to_laser.forced_plies,
            "removedPlies": plies_to_laser.removed_plies,
        }
        await self._messaging.send_message_to_trace(trace_payload, metadata)

    async def _send_to_laser(self, feedback_to_send, metadata_to_forward: PayloadMetadata):
        if feedback_to_send != {}:
            laser_feedback = LaserFeedback(self._messaging, self._sub_graph, self._team_instructions)
            await laser_feedback.invoke(feedback_to_send, metadata_to_forward)
        else:
            log.warning("Feedback data is empty, skipping Feedback invocation process.")

    def _find_plies_to_be_placed(self) -> dict:
        placed_plies_on_mould = self._mould_state.get_placed_plies_on_mould()
        placed_plies = graph_resolver.plies_from(placed_plies_on_mould, self._sub_graph)
        plies_to_be_placed = self._sub_graph.find_plies_to_be_placed(placed_plies)
        return plies_to_be_placed

    def _get_edge_verification_payload(self, session: dict) -> dict:
        detected_states_to_verify, missing_states_to_verify = self._mould_state.get_edges_to_verify()
        detected_edges_to_verify = graph_resolver.edges_from(detected_states_to_verify)
        missing_edges_to_verify = graph_resolver.edges_from(missing_states_to_verify)

        is_limited_number_of_placed_plies_verification_enabled = cfg.NUMBER_OF_PLACED_PLIES_TO_VERIFY != -1
        if is_limited_number_of_placed_plies_verification_enabled:
            self._apply_number_of_placed_plies_to_verify_filter(detected_edges_to_verify)

        return self._create_edge_verification_payload(detected_edges_to_verify, missing_edges_to_verify, session)

    # TODO: to avoid recursion Grigorij recommends to create and store data structure where ply nodes has levels
    def _apply_number_of_placed_plies_to_verify_filter(self, edges_to_verify: set) -> None:
        plies_to_be_placed = self._find_plies_to_be_placed()
        acc_previous_plies = set()
        for ply in plies_to_be_placed:
            previous_plies = self._sub_graph.get_n_previous_plies(ply, cfg.NUMBER_OF_PLACED_PLIES_TO_VERIFY)
            acc_previous_plies.update(previous_plies)

        edges_of_previous_plies = self._sub_graph.get_edges_by_plies(acc_previous_plies)
        edges_of_plies_to_be_placed = self._sub_graph.get_edges_by_plies(set(plies_to_be_placed))
        valid_edges_to_verify = edges_of_previous_plies | edges_of_plies_to_be_placed

        edges_to_verify.intersection_update(valid_edges_to_verify)

    def _create_edge_verification_payload(
            self, detected_edges: set[str], missing_edges: set[str], session: dict = None) -> dict:
        data = self._generate_edge_verification_payload_data(detected_edges, missing_edges)
        return self._envelop_edge_verification_payload_data(data, session)

    def _generate_edge_verification_payload_data(self, detected_edges: set[str], missing_edges: set[str]) -> dict:
        detected_edges_payload_data = self._group_by_cameras_and_type(detected_edges, "detectedEdges")
        missing_edges_payload_data = self._group_by_cameras_and_type(missing_edges, "missingEdges")
        data = dict_of_dicts_merge(detected_edges_payload_data, missing_edges_payload_data)
        return data

    def _group_by_cameras_and_type(self, edges: set, edge_type: str) -> dict:
        payload_data = {}
        for edge in edges:
            for camera in self._edge_cameras.get_cameras(edge):
                if camera in payload_data:
                    payload_data[camera][edge_type].append(edge)
                    payload_data[camera][edge_type].sort()
                else:
                    payload_data[camera] = {}
                    payload_data[camera][edge_type] = [edge]
        return payload_data

    def _envelop_edge_verification_payload_data(self, data: dict, session: dict) -> dict:
        metadata = {
            "groundTruthVersion": self._team_instructions.ground_truth_version,
            "mouldId": self._team_instructions.mould_id,
            "bladeSn": self._team_instructions.blade_sn,
            "bladeRevision": self._team_instructions.blade_revision,
            "layers": sorted(list(self._team_instructions.layer_ids)),
            "session": session
        }
        return {
            "metadata": metadata,
            "data": data
        }

    def _aggregate_feedback_to_laser(self, plies_to_laser: PliesToLaser) -> dict:
        correctly_placed_plies = plies_to_laser.correctly_placed_plies
        plies_to_be_placed = plies_to_laser.plies_to_be_placed
        new_missing_plies = plies_to_laser.new_missing_plies
        no_longer_missing_plies = plies_to_laser.no_longer_missing_plies
        forced_plies = plies_to_laser.forced_plies
        removed_plies = plies_to_laser.removed_plies
        feedback_to_send = {}

        self._process_correctly_placed_plies(plies_to_be_placed, correctly_placed_plies, feedback_to_send)
        self._process_plies_to_be_placed(plies_to_be_placed, feedback_to_send)
        self._process_new_missing_plies(new_missing_plies, feedback_to_send)
        self._process_no_longer_missing_plies(no_longer_missing_plies, feedback_to_send)
        self._process_forced_plies(forced_plies, feedback_to_send)
        self._process_removed_plies(removed_plies, feedback_to_send)

        return feedback_to_send

    def _process_correctly_placed_plies(
            self, plies_to_be_placed: dict, correctly_placed_plies: dict, feedback_to_send: dict):
        if not plies_to_be_placed:
            log.warning("============================ All plies from graph are placed! ============================")
            log.debug(
                "Found last correctly-placed-plies: %s, assigning as last-plies-placed...", set(correctly_placed_plies))
            self._assign_last_plies_placed(feedback_to_send, correctly_placed_plies)
        elif correctly_placed_plies:
            log.debug(
                "Found correctly-placed-plies: %s, assigning as correctly-placed-plies...", set(correctly_placed_plies))
            self._assign_correctly_placed_plies(feedback_to_send, correctly_placed_plies)
        else:
            log.debug("Did not found correctly-placed-plies")

    def _process_plies_to_be_placed(self, plies_to_be_placed: dict, feedback_to_send: dict) -> None:
        if not plies_to_be_placed:
            log.warning("Did not found plies-to-be-placed, this should happen only if all plies placed, are they?")
            return

        phantom_plies = graph_plies_filtration.phantom_plies(plies_to_be_placed)
        self._process_phantom_plies(phantom_plies, feedback_to_send)

        placeable_plies_to_be_placed = dict_subtract(plies_to_be_placed, phantom_plies)
        self._assign_plies_to_be_placed(feedback_to_send, placeable_plies_to_be_placed)

    def _process_new_missing_plies(self, new_missing_plies: dict, feedback_to_send: dict) -> None:
        if new_missing_plies:
            log.debug("Found new_missing-plies: %s, assigning as missing-plies...", set(new_missing_plies))
            self._assign_missing_plies(feedback_to_send, new_missing_plies)
        else:
            log.debug("Did not found new_missing_plies")

    def _process_no_longer_missing_plies(self, no_longer_missing_plies: dict, feedback_to_send: dict) -> None:
        if no_longer_missing_plies:
            log.debug("Found no_longer_missing_plies: %s, assigning as plies-to-null..", set(no_longer_missing_plies))
            self._assign_plies_to_null(feedback_to_send, no_longer_missing_plies)
        else:
            log.debug("Did not found no_longer_missing_plies")

    def _process_forced_plies(self, forced_plies: dict, feedback_to_send: dict) -> None:
        if forced_plies:
            log.debug("Found forced_plies: %s, assigning as plies-to-null...", set(forced_plies))
            self._assign_plies_to_null(feedback_to_send, forced_plies)
        else:
            log.debug("Did not found forced_plies")

    def _process_removed_plies(self, removed_plies: dict, feedback_to_send: dict) -> None:
        if removed_plies:
            log.debug("Found removed_plies: %s, assigning as plies-to-null...", set(removed_plies))
            self._assign_plies_to_null(feedback_to_send, removed_plies)
        else:
            log.debug("Did not found removed_plies")

    def _process_phantom_plies(self, phantom_plies: dict, feedback_to_send: dict) -> None:
        if phantom_plies:
            log.debug("Found phantom-plies: %s, assigning as phantom-plies...", set(phantom_plies))
            self._assign_phantom_plies(feedback_to_send, phantom_plies)
        else:
            log.debug("Did not found phantom-plies")

    @staticmethod
    def _assign_correctly_placed_plies(feedback_to_send: dict, correctly_placed_plies: dict) -> None:
        log.debug("Assigning correctly-placed-plies: %s, to feedback_to_send", set(correctly_placed_plies))
        feedback_to_send["correctly-placed-plies"] = correctly_placed_plies

    @staticmethod
    def _assign_plies_to_be_placed(feedback_to_send: dict, current_plies_to_be_placed: dict) -> None:
        log.debug("Assigning plies-to-be-placed: %s, to feedback_to_send.", set(current_plies_to_be_placed))
        feedback_to_send["plies-to-be-placed"] = current_plies_to_be_placed

    @staticmethod
    def _assign_phantom_plies(feedback_to_send: dict, phantom_plies: dict) -> None:
        log.debug("Assigning phantom-plies: %s, to feedback_to_send.", set(phantom_plies))
        feedback_to_send["phantom-plies"] = phantom_plies

    @staticmethod
    def _assign_missing_plies(feedback_to_send: dict, new_missing_plies: dict) -> None:
        log.debug("Assigning missing-plies: %s, to feedback_to_send.", set(new_missing_plies))
        feedback_to_send["missing-plies"] = new_missing_plies

    @staticmethod
    def _assign_plies_to_null(feedback_to_send: dict, plies_to_null: dict) -> None:
        log.debug("Assigning plies-to-null: %s, to feedback_to_send.", set(plies_to_null))
        if feedback_to_send.get("plies-to-null"):
            feedback_to_send["plies-to-null"] = feedback_to_send["plies-to-null"] | plies_to_null
        else:
            feedback_to_send["plies-to-null"] = plies_to_null

    @staticmethod
    def _assign_last_plies_placed(feedback_to_send: dict, last_correctly_placed_plies: dict) -> None:
        log.debug(
            "Assigning the last_correctly_placed_plies: %s, to feedback_to_send", set(last_correctly_placed_plies))
        feedback_to_send["last-plies-placed"] = last_correctly_placed_plies

    async def handle_finalise_command(self, payload: dict) -> None:
        """ Resets DM module into initial state """
        log.info(f"decision_maker.handle_finalise_command invoked")
        self._require_initialised_mould_state("handle_finalise_command")

        correlation_id: str = payload.get("correlationId")
        require.not_none(correlation_id, "handle_finalise_command correlation_id")
        metadata_to_forward = PayloadMetadata(correlation_id=correlation_id)

        params: dict = payload.get("params")
        require.not_empty(params, "handle_finalise_command params")
        require.not_none(params.get("mouldId"), "mouldId in handle_finalise_command params")
        self._validate_mould_id(params, "handle_finalise_command")

        self._shared_storage.set_mould_state(GlobalMouldState.FINALISED)
        await self._finalise(metadata_to_forward)

    def _global_mould_state_finalisation_update_callback(self, value: str) -> None:
        """ Handle global mould state update on state change to FINALISED to reset DM. """
        global_mould_state = GlobalMouldState.value_of(value)
        log.info(f"Received Global Mould State update from shared state: {global_mould_state}")
        if global_mould_state == GlobalMouldState.FINALISED:
            self._require_initialised_mould_state("finalised_state_received_via_etcd")
            metadata_to_forward = PayloadMetadata()
            asyncio.run(self._finalise(metadata_to_forward))
        else:
            log.info("Received Global Mould State from ETCD store is not FINALISED, skipping finalise process.")

    async def _finalise(self, metadata_to_forward: PayloadMetadata) -> None:
        log.info("decision_maker._finalise invoked. Resetting DM module into initial state...")

        all_cam_ids = self._mould_state.get_all_cam_ids()
        await self._null_edge_verification_modules(metadata_to_forward)
        await ImageGrabbing(self._messaging).stop(all_cam_ids, metadata_to_forward)

        # hold on to the copies to be use after original is cleared on DecisionMaker._clear(self)
        all_mould_state_plies_copy = copy.deepcopy(graph_resolver.plies_from(self._mould_state.plies, self._sub_graph))
        team_instructions_copy = copy.deepcopy(self._team_instructions)
        sub_graph_copy = copy.deepcopy(self._sub_graph)

        DecisionMaker._clear(self)

        self._shared_storage.remove_mould_plies()
        self._shared_storage.remove_mould_instructions()

        laser_feedback = LaserFeedback(self._messaging, sub_graph_copy, team_instructions_copy)
        await laser_feedback.clear(all_mould_state_plies_copy, metadata_to_forward)

        log.warning("DM module successfully reset to initial state. Waiting for new initial Team Instructions...")

    async def _null_edge_verification_modules(self, metadata_to_forward: PayloadMetadata) -> None:
        nulled_verification_payload = self._create_nulled_verification_payload(metadata_to_forward.session)
        await self._messaging.send_message_to_edge_verification(nulled_verification_payload, metadata_to_forward)

    def _create_nulled_verification_payload(self, session: dict) -> dict:
        all_cam_ids = self._mould_state.get_all_cam_ids()
        data = self._generate_nulled_edge_verification_payload_data(all_cam_ids)
        return self._envelop_edge_verification_payload_data(data, session)

    @staticmethod
    def _generate_nulled_edge_verification_payload_data(all_cam_ids: set[str]) -> dict:
        data = {}
        for cam_id in all_cam_ids:
            data[cam_id] = {"detectedEdges": [], "missingEdges": []}
        return data

    def _clear(self) -> None:
        log.warning("Clearing in-memory state of a DecisionMaker instance...")
        self._static_graph = None
        self._sub_graph = None
        self._mould_state = MouldState(set())
        self._team_instructions = TeamInstructions([])
        self._edge_cameras = None
        self._feedback_positions = None

    async def handle_add_team_instruction_command(self, payload: dict) -> None:
        log.info(f"decision_maker.handle_add_team_instruction_command invoked")

        correlation_id = payload.get("correlationId")
        require.not_none(correlation_id, "handle_add_team_instruction_command correlation_id")
        metadata_to_forward = PayloadMetadata(correlation_id=correlation_id)

        team_instruction: dict = payload.get("params")
        require.not_empty(team_instruction, "handle_add_team_instruction_command params")
        require.not_none(team_instruction.get("version"), "version in add_team_instruction_command params")
        require.not_none(team_instruction.get("mouldId"), "mouldId in add_team_instruction_command params")
        require.not_none(team_instruction.get("bladeRevision"), "bladeRevision in add_team_instruction_command params")
        require.not_none(team_instruction.get("layerId"), "layerId in add_team_instruction_command params")
        require.not_none(team_instruction.get("palletId"), "palletId in add_team_instruction_command params")
        require.not_none(team_instruction.get("bladeSn"), "bladeSn in add_team_instruction_command params")

        self._validate_mould_id(team_instruction, "handle_add_team_instruction_command")
        self._validate_mould_state_and_blade_sn(team_instruction)

        self._shared_storage.set_mould_state(GlobalMouldState.PRODUCTION)
        self._shared_storage.set_mould_blade_sn(team_instruction)

        await self._handle_team_instruction_update(team_instruction, metadata_to_forward)

    def _validate_mould_state_and_blade_sn(self, team_instruction: dict) -> None:
        global_mould_state = self._shared_storage.get_mould_state()
        global_blade_sn = self._shared_storage.get_mould_blade_sn()

        blade_sn_is_finalised = global_mould_state == GlobalMouldState.FINALISED and \
                                global_blade_sn == team_instruction["bladeSn"]
        if blade_sn_is_finalised:
            warning_message = f"Discarding team instruction, " \
                              f"given blade_sn: {team_instruction['bladeSn']} is already finalised."
            log.warning(warning_message)
            raise ValueError(warning_message)

        mould_is_in_production_for_different_blade_sn = global_mould_state == GlobalMouldState.PRODUCTION and \
                                                        global_blade_sn != team_instruction["bladeSn"]
        if mould_is_in_production_for_different_blade_sn:
            warning_message = f"Discarding team instruction for blade_sn: {team_instruction['bladeSn']}, " \
                              f"given mould_id {team_instruction['mouldId']} " \
                              f"is already in production for different blade_sn: {global_blade_sn}"
            log.warning(warning_message)
            raise ValueError(warning_message)

    async def handle_force_ply_command(self, payload: dict) -> None:
        log.info(f"decision_maker.handle_force_ply_command invoked")

        correlation_id = payload.get("correlationId")
        require.not_none(correlation_id, "handle_force_ply_command correlation_id")
        metadata_to_forward = PayloadMetadata(correlation_id=correlation_id)

        params: dict = payload.get("params")
        require.not_empty(params, "handle_force_ply_command params")
        self._require_initialised_mould_state("handle_force_ply_command")

        mould_id, ply_id = params.get("mouldId"), params.get("ply")
        require.not_none(mould_id, "mouldId in handle_force_ply_command params")
        require.not_none(ply_id, "ply in handle_force_ply_command params")
        self._validate_mould_id(params, "handle_force_ply_command")

        log.debug("Marking Ply '%s' as FORCED in mould state...", ply_id)
        ply_state = self._mould_state.force_ply(ply_id)
        covered_plies = self._mould_state.mark_covered_edges(ply_state, self._sub_graph)
        await self._process_mould_state_changes(covered_plies | {ply_state}, metadata_to_forward)

    def _require_initialised_mould_state(self, command_type: str) -> None:
        if not self._mould_state.plies:
            warning_message = f"Can't process {command_type} while DM is not yet loaded with Team Instructions."
            log.warning(warning_message)
            raise ValueError(warning_message)

    @staticmethod
    def _validate_mould_id(params: dict, command_type: str) -> None:
        mould_id = params.get("mouldId")
        if mould_id != cfg.MOULD_ID:
            message = f"Aborting {command_type}, " \
                      f"due to given mouldId != preconfigured mould_id ({mould_id} != {cfg.MOULD_ID})"
            log.warning(message)
            raise ValueError(message)

    async def handle_undo_ply_command(self, payload: dict) -> None:
        log.info("decision_maker.handle_undo_ply_command invoked")

        correlation_id = payload.get("correlationId")
        require.not_none(correlation_id, "handle_undo_ply_command correlation_id")
        metadata_to_forward = PayloadMetadata(correlation_id=correlation_id)

        params: dict = payload.get("params")
        require.not_empty(params, "handle_undo_ply_command params")
        self._require_initialised_mould_state("handle_undo_ply_command")

        mould_id, ply_id = params.get("mouldId"), params.get("ply")
        require.not_none(mould_id, "mouldId in handle_undo_ply_command params")
        require.not_none(ply_id, "ply in handle_undo_ply_command params")
        self._validate_mould_id(params, "handle_undo_ply_command")

        affected_plies = self._mould_state.undo_ply(ply_id, self._shared_storage, self._sub_graph)
        await self._process_mould_state_changes(affected_plies, metadata_to_forward, is_state_share_chained=False)

    def _global_mould_state_plies_removal_callback(self, key_to_delete: str) -> None:
        log.debug(f"Received mould state ply removal from ETCD: {key_to_delete}")
        ply_id = key_to_delete.split("/")[-1]
        self._handle_mould_state_ply_removal(ply_id)

    def _handle_mould_state_ply_removal(self, ply_id: str) -> None:
        ply = self._mould_state.get_ply(ply_id)
        self._mould_state.validate_ply_is_not_of_state(ply, "undo", PlyStateEnum.COVERED)
        removed_ply = self._mould_state.remove(ply)
        self._check_race_condition(ply_id)
        metadata = PayloadMetadata()
        asyncio.run(self._process_mould_state_changes({removed_ply}, metadata, cfg.FF_ENABLE_CHAINED_STATE_SHARE))

    def _check_race_condition(self, ply_id):
        if not self._all_previous_plies_is_expected(ply_id):
            log.error(f"Seems like due to a race condition not all previous_plies, of given ply {ply_id} to delete, "
                      f"were reset to EXPECTED as intended for undo ply operation.")

    def _all_previous_plies_is_expected(self, ply_id: str) -> bool:
        previous_plies = self._sub_graph.get_previous_plies(ply_id)
        return all(
            previous_ply.state == PlyStateEnum.EXPECTED for previous_ply in self._mould_state.get_plies(previous_plies))

    async def handle_undo_plies_to_command(self, payload: dict) -> None:
        log.info("decision_maker.handle_undo_plies_to_command invoked")

        correlation_id = payload.get("correlationId")
        require.not_none(correlation_id, "handle_undo_plies_to_command correlation_id")
        metadata_to_forward = PayloadMetadata(correlation_id=correlation_id)

        params: dict = payload.get("params")
        require.not_empty(params, "handle_undo_plies_to_command params")
        self._require_initialised_mould_state("handle_undo_plies_to_command")

        mould_id, ply_id = params.get("mouldId"), params.get("ply")
        require.not_none(mould_id, "mouldId in handle_undo_plies_to_command params")
        require.not_none(ply_id, "ply in handle_undo_plies_to_command params")
        self._validate_mould_id(params, "handle_undo_plies_to_command")

        affected_plies = self._mould_state.undo_plies_to(ply_id, self._shared_storage, self._sub_graph)
        await self._process_mould_state_changes(affected_plies, metadata_to_forward, is_state_share_chained=False)

    async def handle_undo_plies_to_dry_run_command(self, payload: dict) -> list:
        log.info("decision_maker.handle_undo_plies_to_command invoked")

        params: dict = payload.get("params")
        require.not_empty(params, "handle_undo_plies_to_dry_run_command params")
        self._require_initialised_mould_state("handle_undo_plies_to_dry_run_command")

        mould_id, ply_id = params.get("mouldId"), params.get("ply")
        require.not_none(mould_id, "mouldId in handle_undo_plies_to_dry_run_command params")
        require.not_none(ply_id, "ply in handle_undo_plies_to_dry_run_command params")
        self._validate_mould_id(params, "handle_undo_plies_to_dry_run_command")

        return self._mould_state.undo_plies_to_dry_run(ply_id, self._sub_graph)

    async def handle_recheck_ply_command(self, payload: dict) -> None:
        log.info("decision_maker.handle_recheck_ply_command invoked")

        correlation_id = payload.get("correlationId")
        require.not_none(correlation_id, "handle_recheck_ply_command correlation_id")
        metadata_to_forward = PayloadMetadata(correlation_id=correlation_id)

        params: dict = payload.get("params")
        require.not_empty(params, "handle_recheck_ply_command params")
        self._require_initialised_mould_state("handle_recheck_ply_command")

        mould_id, ply_id = params.get("mouldId"), params.get("ply")
        require.not_none(mould_id, "mouldId in handle_recheck_ply_command params")
        require.not_none(ply_id, "ply in handle_recheck_ply_command params")
        self._validate_mould_id(params, "handle_recheck_ply_command")

        affected_ply = self._mould_state.recheck_ply(ply_id)
        await self._process_mould_state_changes({affected_ply}, metadata_to_forward)
