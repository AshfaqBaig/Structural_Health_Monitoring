import app.config as cfg
from app.global_mould_state_enum import GlobalMouldState
from app.models.state.mould_state import MouldState
from app.models.state.ply_state import PlyState
from app.models.team_instructions import TeamInstructions
from app.shared_storage import SharedStorage
from app.logging.logger import yield_logger

log = yield_logger()

class ModuleInitializer:
    def __init__(
            self,
            shared_storage: SharedStorage,
    ):
        self._shared_storage = shared_storage
        self._team_instructions: TeamInstructions = None
        self._mould_state: MouldState = None

    def run(self) -> (TeamInstructions, MouldState):
        """ Module initializer fetched global mould state from ETCD store """
        log.info("Initializing Decision Maker state...")
        try:
            global_mould_state = self._shared_storage.get_mould_state()

            if global_mould_state in [GlobalMouldState.FINALISED, GlobalMouldState.NONE]:
                log.info(f"Initialising with empty Local Mould State, waiting for initial Team Instruction...")
                self._team_instructions = TeamInstructions()
                self._mould_state = MouldState(set())

            elif global_mould_state == GlobalMouldState.PRODUCTION:
                log.info(f"Fetching Global Mould State data from ETCD store...")
                global_mould_state_instructions: dict = self._shared_storage.get_mould_instructions()
                global_mould_state_plies: dict = self._shared_storage.get_mould_plies()
                self._initialise_local_mould_state_instructions(global_mould_state_instructions)
                self._initialise_local_mould_state_plies(global_mould_state_plies)

            else:
                raise NotImplementedError(f"Unrecognised global mould state type: {global_mould_state}")

            log.info("Module State Initialization completed.")
            return self._team_instructions, self._mould_state

        except Exception as ex:
            error_message = f"Failed to get Global Mould State for mould_id: {cfg.MOULD_ID}, due to: {ex}"
            raise ValueError(error_message)

    def _initialise_local_mould_state_instructions(self, global_mould_state_instructions: dict) -> None:
        if global_mould_state_instructions == {}:
            log.info(
                f"Fetched empty Global Mould State Instructions from ETCD store: {global_mould_state_instructions}, "
                f"initialising with empty Local Team Instructions.")
            self._team_instructions = TeamInstructions()
        else:
            team_instructions_data = []
            for team_instruction in global_mould_state_instructions.values():
                team_instructions_data.append(team_instruction)

            self._team_instructions = TeamInstructions(team_instructions_data)
            log.info(f"Global Mould State Team Instructions fetched from ETCD store: {global_mould_state_instructions}")

    def _initialise_local_mould_state_plies(self, global_mould_state_plies: dict) -> None:
        if not self._team_instructions.data:
            log.info(
                f"No Global Mould State Instructions preloaded from ETCD store: {global_mould_state_plies}, "
                f"initialising with empty Local Mould State Plies.",
            )
            self._mould_state = MouldState(set())
        elif global_mould_state_plies == {}:
            log.info(
                f"Fetched empty Global Mould State Plies from ETCD store: {global_mould_state_plies}, "
                f"initialising with empty Local Mould State Plies.",
            )
            self._mould_state = MouldState(set())
        else:
            plies = ModuleInitializer.resolve_plies_from(global_mould_state_plies)
            self._mould_state = MouldState(plies)
            log.info(f"Global Mould State Plies fetched from ETCD store: {global_mould_state_plies}")

    @staticmethod
    def resolve_plies_from(global_mould_state_plies: dict) -> set[PlyState]:
        """ Extract plies states from global_mould_state_plies received from ETCD store. """
        plies_to_return = set()
        # key format /moulds/<mould_id>/plies/<ply_id>
        for key, value in global_mould_state_plies.items():
            key_ply_id = key[key.rindex("/") + 1:]
            value_ply_id = value["ply_id"]
            ModuleInitializer._validate(key_ply_id, value_ply_id)
            ply_state = PlyState.deserialize(value)
            plies_to_return.add(ply_state)
        return plies_to_return

    @staticmethod
    def _validate(key_ply_id: str, value_ply_id: str) -> None:
        if key_ply_id != value_ply_id:
            error_message = f"Invalid global mould state plies data fetched, " \
                            f"ply id in key do not match ply id in value: {key_ply_id} != {value_ply_id}."
            raise ValueError(error_message)
