""" Main entrypoint module """
import asyncio

import prometheus_client as prometheus
from prometheus_client import start_http_server

import app.config as cfg
from app.message_listener import MessageListener
from app.logging.logger import yield_logger, update_log_level

log = yield_logger()
update_log_level(log, cfg.LOG_LEVEL)


def initialize_prometheus():
    prometheus.REGISTRY.unregister(prometheus.PROCESS_COLLECTOR)
    prometheus.REGISTRY.unregister(prometheus.PLATFORM_COLLECTOR)
    prometheus.REGISTRY.unregister(prometheus.GC_COLLECTOR)
    start_http_server(cfg.PROMETHEUS_PORT)

if __name__ == "__main__":
    initialize_prometheus()
    asyncio.run(MessageListener().run())
