""" IoT Edge Hub input message handler module """
import json
import math
import time

from azure.iot.device import Message
from prometheus_client import Summary, Histogram

import app.config as cfg
from app.decision_maker import DecisionMaker
from app.messaging_wrapper import MessagingWrapper
from app.models.payload_metadata import PayloadMetadata
from app.util import require
from app.logging.logger import yield_logger

log = yield_logger()

HISTOGRAM_BUCKETS = (.1, .2, .5, 1.0, math.inf)
METRICS_HISTOGRAM = \
    Histogram('dm_processing_duration_histogram_seconds',
              'Decision Maker (DM) input processing duration histogram in seconds',
              buckets=HISTOGRAM_BUCKETS,
              labelnames=cfg.METRIC_LABELS).labels(mould_id=cfg.MOULD_ID,
                                                   device_id=cfg.IOTEDGE_DEVICEID,
                                                   module_id=cfg.IOTEDGE_MODULEID)
METRICS_SUMMARY = Summary('dm_processing_duration_seconds',
                          'Decision Maker (DM) input processing duration summary in seconds',
                          labelnames=cfg.METRIC_LABELS).labels(mould_id=cfg.MOULD_ID,
                                                               device_id=cfg.IOTEDGE_DEVICEID,
                                                               module_id=cfg.IOTEDGE_MODULEID)


class InputMessageHandler:
    """ IoT Edge Hub routed input message handler """

    def __init__(self, decision_maker: DecisionMaker, messaging: MessagingWrapper):
        self._decision_maker = decision_maker
        self._messaging = messaging

        self.previous_edge_verification_message_by_camera_id: dict[str, dict] = {}

    async def handle(self, message: Message) -> None:
        """ Callback function to handle Hub routed input message. """
        data: dict = json.loads(message.data)
        metadata_to_forward = PayloadMetadata(
            session=data.get("session"),
            correlation_id=message.correlation_id,
            custom_properties=message.custom_properties
        )
        log.debug(
            f"Message received on input: {message.input_name}, data: {data}, "
            f"metadata: {metadata_to_forward}, custom_properties={message.custom_properties}",
            extra={"correlation_id": message.correlation_id}
        )
        try:
            operation_start = time.time()
            self._validate(data)

            if self._has_detected_or_missing_edges(data):
                log.debug("Starting edge verification message handling...")
                self._check_edge_verification_message_duplication(data)
                verification_data = data.get("feedback")
                await self._decision_maker.handle_edge_verification_message(verification_data, metadata_to_forward)
            else:
                log.warning("Message is not intended for processing on DM. Forwarding message data to Feedback module.")
                await self._messaging.send_message_to_feedback(data, metadata_to_forward)

            self._print_total_processing_time(operation_start)
            self._track_total_processing_time_metrics(operation_start)

        except Exception as ex:
            error_message = f"Failed to handle Edge Hub routed input message: {message}, due to: {ex}"
            log.exception(error_message)
            await self._messaging.send_message_to_error_output(error_message, metadata_to_forward)

    @staticmethod
    def _track_total_processing_time_metrics(operation_start: float) -> None:
        operation_duration = time.time() - operation_start
        METRICS_SUMMARY.observe(operation_duration)
        METRICS_HISTOGRAM.observe(operation_duration)

    @staticmethod
    def _print_total_processing_time(operation_start: float) -> None:
        total_time = round((time.time() - operation_start) * 1000, 2)
        log.info(f"Total processing time for input message: {total_time} ms")

    @staticmethod
    def _validate(data: dict) -> None:
        feedback: list = data.get("feedback")
        if feedback is None:
            raise ValueError(f"'feedback' property not found in message data: {data}")
        if len(feedback) == 0:
            raise ValueError(f"Empty 'feedback' property in message data cannot be processed, discarding: {data}")

    @staticmethod
    def _has_detected_or_missing_edges(data: dict) -> bool:
        """ Return True when feedback type is detected-edges or missing-edges. """
        feedback: list = data.get("feedback")
        return any(item.get("type") in ["detected-edges", "missing-edges"] for item in feedback)

    def _check_edge_verification_message_duplication(self, data: dict) -> None:
        """ Logs warning if same edge verification message received multiple times in a row. """
        session = data.get("session")
        require.not_empty(session, "session")

        camera_id = session["cameraId"]
        require.not_none(camera_id, "camera_id in session")
        feedback: list = data.get("feedback")

        self._initialize_message_tracker(camera_id)
        previous_feedback = self.previous_edge_verification_message_by_camera_id.get(camera_id).get("feedback")

        if feedback == previous_feedback:
            count = self.previous_edge_verification_message_by_camera_id[camera_id]["message_duplication_count"]
            new_count = count + 1
            self.previous_edge_verification_message_by_camera_id[camera_id]["message_duplication_count"] = new_count
            warning_message = f"Same edge verification message for camera: '{camera_id}' " \
                              f"received {new_count} times in a row."
            log.warning(warning_message)
        else:
            self.previous_edge_verification_message_by_camera_id[camera_id] = {
                "message_duplication_count": 1,
                "feedback": feedback
            }

    def _initialize_message_tracker(self, camera_id: str) -> None:
        message_by_camera = self.previous_edge_verification_message_by_camera_id.get(camera_id)
        if message_by_camera is None:
            self.previous_edge_verification_message_by_camera_id[camera_id] = {}
