""" Module C2DM handler module """
from azure.iot.device import MethodRequest, MethodResponse

import app.config as cfg
from app.decision_maker import DecisionMaker
from app.logging import logger
from app.messaging_wrapper import MessagingWrapper
from app.models.payload_metadata import PayloadMetadata

log = logger.yield_logger()


class CloudToDeviceMethodHandler:
    """ Cloud to device method request handler """

    def __init__(self, decision_maker: DecisionMaker, messaging: MessagingWrapper):
        self._decision_maker = decision_maker
        self._messaging = messaging

        self._error_message: str = None
        self._correlation_id: str = None
        self._metadata_to_forward: PayloadMetadata = None
        self._request: MethodRequest = None

    async def handle(self, request: MethodRequest) -> None:
        """ Callback function to handle cloud to device method request with given command. """
        log.info(f"C2DM request received, command: {request.name}, payload: {request.payload}")

        await self._clear_and_set_up_handler_for(request)
        await self._handle_requested_command()
        await self._send_response()

        log.info(f"======= C2DM request with correlation_id: {self._correlation_id} processed. =======",
                 extra={"correlation_id": self._correlation_id})

    async def _clear_and_set_up_handler_for(self, request: MethodRequest) -> None:
        self._success_payload = None
        self._error_message = None
        self._correlation_id = request.payload.get("correlationId")
        self._metadata_to_forward = PayloadMetadata(correlation_id=self._correlation_id)
        self._request = request

    async def _handle_requested_command(self) -> None:
        try:
            command = self._request.name
            log.info(f"Starting '{command}' command handling...")

            if command == "add_team_instruction":
                await self._decision_maker.handle_add_team_instruction_command(self._request.payload)
            elif command == "force_ply":
                await self._decision_maker.handle_force_ply_command(self._request.payload)
            elif command == "undo_ply":
                await self._decision_maker.handle_undo_ply_command(self._request.payload)
            elif command == "undo_plies_to":
                await self._decision_maker.handle_undo_plies_to_command(self._request.payload)
            elif command == "undo_plies_to_dry_run":
                result = await self._decision_maker.handle_undo_plies_to_dry_run_command(self._request.payload)
                self._success_payload = result
            elif command == "recheck_ply":
                await self._decision_maker.handle_recheck_ply_command(self._request.payload)
            elif command == "finalise":
                await self._decision_maker.handle_finalise_command(self._request.payload)
            elif command == "set_log_level":
                cfg.LOG_LEVEL = self._request.payload.get("params").get("logLevel")
                logger.update_log_level(log, cfg.LOG_LEVEL)
            else:
                self._error_message = f"Failed to recognize command in C2DM request " \
                                      f"with correlation_id: {self._correlation_id}"
                log.error(self._error_message, extra={"correlation_id": self._correlation_id})
                await self._messaging.send_message_to_error_output(self._error_message, self._metadata_to_forward)

        except Exception as ex:
            self._error_message = f"Failed to handle requested command: {self._request.name}, " \
                                  f"via C2DM request with correlation_id: {self._correlation_id}, due to: {ex}"
            log.exception(self._error_message, extra={"correlation_id": self._correlation_id})
            await self._messaging.send_message_to_error_output(self._error_message, self._metadata_to_forward)

    async def _send_response(self) -> None:
        status_code, payload = await self._get_status_code_and_response_payload()
        response = MethodResponse.create_from_method_request(self._request, status_code, payload)
        await self._messaging.send_c2dm_response(response)

    async def _get_status_code_and_response_payload(self):
        if self._error_message:
            return 400, self._error_message
        else:
            return 200, self._success_payload
