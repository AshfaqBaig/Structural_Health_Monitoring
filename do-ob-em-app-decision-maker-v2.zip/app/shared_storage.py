""" etcd client wrapper """
import json
import math
import time
from typing import Callable, Union, Optional

import etcd3
from etcd3 import Etcd3Exception
from etcd3.events import PutEvent, DeleteEvent, Event
from etcd3.watch import WatchResponse
from prometheus_client.metrics import Histogram, Summary

import app.config as cfg
from app.global_mould_state_enum import GlobalMouldState
from app.models.state.ply_state import PlyState
from app.logging.logger import yield_logger

log = yield_logger()

HISTOGRAM_BUCKETS = (.1, .2, .5, 1.0, math.inf)

METRICS_HISTOGRAM = Histogram("dm_state_update_duration_histogram_seconds",
                              "Decision Maker (DM) mould state update duration histogram in seconds",
                              buckets=HISTOGRAM_BUCKETS,
                              labelnames=cfg.METRIC_LABELS).labels(mould_id=cfg.MOULD_ID,
                                                                   device_id=cfg.IOTEDGE_DEVICEID,
                                                                   module_id=cfg.IOTEDGE_MODULEID)
METRICS_SUMMARY = Summary("dm_state_update_duration_seconds",
                          "Decision Maker (DM) mould state update duration summary in seconds",
                          labelnames=cfg.METRIC_LABELS).labels(mould_id=cfg.MOULD_ID,
                                                               device_id=cfg.IOTEDGE_DEVICEID,
                                                               module_id=cfg.IOTEDGE_MODULEID)


class SharedStorage:
    """ An etcd client wrapper. Instance of the class connects to etcd storage. """

    def __init__(self, etdc_url: str = None, ttl: int = 600):
        self._etdc_url = etdc_url
        if etdc_url is None:
            self.etcd_client = etcd3.client(host="localhost")
        else:
            if ":" in etdc_url:
                host = etdc_url.split(":")[0]
                port = etdc_url.split(":")[1]
                self.etcd_client = etcd3.client(host=host, port=port)
            else:
                self.etcd_client = etcd3.client(host=etdc_url)
        self._ttl = ttl
        self._watchers = {}
        self._module_settings_update_callback: Callable = None
        self._global_mould_state_plies_update_callback: Callable = None
        self._global_mould_state_plies_removal_callback: Callable = None
        self._global_mould_state_instructions_update_callback: Callable = None
        self._global_mould_state_update_callback: Callable = None

        # ETCD connection-test
        try:
            self.etcd_client.get("ETCD connection-test")
            log.info("Connection to ETCD established!")
        except ConnectionError as ex:
            raise SystemExit(f"Failed to connect to ETCD store, due to {ex}")
        except Etcd3Exception as ex:
            raise SystemExit(f"Unexpected ETCD storage error, due to {ex}")

    def __str__(self) -> str:
        return str(self.__dict__)

    @property
    def module_setting_key(self) -> str:
        return f"/devices/{cfg.IOTEDGE_GATEWAYHOSTNAME}/modules/{cfg.MODULE_APP_NAME}/settings"

    @property
    def mould_key_prefix(self) -> str:
        return f"/moulds/{cfg.MOULD_ID}"

    @property
    def mould_state_key(self) -> str:
        return f"{self.mould_key_prefix}/state"

    @property
    def mould_blade_sn_key(self) -> str:
        return f"{self.mould_key_prefix}/blade_sn"

    @property
    def mould_plies_key_prefix(self) -> str:
        return f"{self.mould_key_prefix}/plies"

    @property
    def mould_instructions_key_prefix(self) -> str:
        return f"{self.mould_key_prefix}/instructions"

    def watch_prefix(self, key_prefix: str, handler: object) -> None:
        """ Watch for put-events with specific prefix and call "handler" in case. """
        watcher = None
        try:
            log.debug("Trying to add watch callback for key prefix: %s", key_prefix)
            watcher = self.etcd_client.add_watch_prefix_callback(key_prefix, callback=handler)
            log.debug("Added watch callback successfully")
        except Etcd3Exception as ex:
            log.error("Failed to add watch callback for given key_prefix: %s, due to %s:", key_prefix, ex)
        self._watchers[key_prefix] = watcher

    def watch_key(self, key: str, handler: object) -> None:
        """ Watch for put-events with specific key and call "handler" in case. """
        watcher = None
        try:
            log.debug(f"Trying to add watch callback for given key: {key}")
            watcher = self.etcd_client.add_watch_callback(key, callback=handler)
            log.debug("Added watch callback successfully")
        except Etcd3Exception as ex:
            log.error(f"Failed to add watch callback for given key: {key}, due to {ex}")
        self._watchers[key] = watcher

    # TODO: refactor to accommodate both variants of watch adder functions
    def unwatch_prefix(self, key_prefix: str) -> None:
        """ To keep clean, unwatch prefix when done. """
        try:
            log.info("Trying to un-watch by given key_prefix: %s", key_prefix)
            watcher = self._watchers.pop(key_prefix)
            log.debug("Removed watcher: %s", watcher)
            log.debug("Watchers remaining: %s", self._watchers)
            if watcher is not None:
                log.debug("Watcher_id: %s was found for key prefix: %s, un-watching...", watcher, key_prefix)
                self.etcd_client.cancel_watch(watcher)
        except KeyError:
            error_message = f"Failed to unwatch key prefix: {key_prefix};\n" \
                            f"because watcher was not found by given key prefix in watchers: {self._watchers}"
            log.error(error_message)
            raise ValueError(error_message) from None

    def get_values_by_prefix(self, key_prefix: str) -> dict:
        """ Get stored complete_key:value pair from etcd by key prefix. Returns empty dict if values does not exist. """
        log.info("Getting complete_key:value pairs from ETCD store by given key_prefix: %s", key_prefix)
        try:
            data = self.etcd_client.get_prefix(key_prefix)
            return {metadata.key.decode("utf-8"): json.loads(value.decode("utf-8")) for value, metadata in data}
        except Etcd3Exception as ex:
            log.error("Failed to get_by_prefix by given key_prefix: %s, due to %s:", key_prefix, ex)
            return {}

    def get_value_by_complete_key(self, key: str) -> Optional[str]:
        """ Get a stored value from etcd by given complete key. Returns None if value does not exist. """
        log.info("Getting value from ETCD store by given complete key: %s", key)
        try:
            value, metadata = self.etcd_client.get(key)
            if value is not None:
                return value.decode("utf-8")
            else:
                return None
        except Etcd3Exception as ex:
            log.error("Failed to get_by_complete_key by given key: %s, due to %s:", key, ex)

    def get_mould_blade_sn(self) -> str:
        """ Get global blade serial number from etcd. """
        blade_sn = self.get_value_by_complete_key(self.mould_blade_sn_key)
        log.info(f"Fetched Global Mould Blade SN: {blade_sn}")
        return blade_sn

    def get_mould_state(self) -> GlobalMouldState:
        """ Get global mould state from etcd. """
        state = self.get_value_by_complete_key(self.mould_state_key)
        log.info(f"Fetched Global Mould State: {state}")
        return GlobalMouldState.value_of(state)

    def put_key(self, key: str, value: Union[dict, str]) -> None:
        """ Inserting/Updating key value in etcd. Value can be str or dict type"""
        log.info(f"Putting into ETCD store: {key}={value}")
        if type(value) == dict:
            self.etcd_client.put(key, json.dumps(value))
        elif type(value) == str:
            self.etcd_client.put(key, value)
        else:
            raise NotImplementedError(f"put_key method supports only dict and str types, given type: {type(value)}")

    def delete_prefix(self, key_prefix: str) -> None:
        """ Deleting values from etcd by given by key prefix. """
        log.info("Deleting from ETCD store by key prefix: %s\t", key_prefix)
        self.etcd_client.delete_prefix(key_prefix)

    def delete_ply(self, ply_id: str) -> None:
        """ Deleting ply from etcd by given ply_id. Raises ValueError if key has not been deleted. """
        if not self._delete(f"{self.mould_plies_key_prefix}/{ply_id}"):
            raise ValueError(f"Failed to delete ply {ply_id} from ETCD store.")

    def _delete(self, key: str) -> bool:
        """ Deleting value from etcd by given by complete key. Returns True if the key has been deleted. """
        log.info("Deleting from ETCD store by complete key : %s\t", key)
        return self.etcd_client.delete(key)

    def get_mould_plies(self) -> dict:
        """ Return global mould state plies by mould id from etcd """
        return self.get_values_by_prefix(self.mould_plies_key_prefix)

    def get_mould_instructions(self) -> dict:
        """ Return global mould state instructions by mould id from etcd """
        return self.get_values_by_prefix(self.mould_instructions_key_prefix)

    def watch_mould_plies_updates(self, global_mould_state_plies_update_callback: Callable) -> None:
        """ Subscribe to global mould state plies updates and invoke callback on put events """
        self._global_mould_state_plies_update_callback = global_mould_state_plies_update_callback
        self.watch_prefix(self.mould_plies_key_prefix, self._handle_global_mould_changes)

    def watch_mould_plies_removals(self, global_mould_state_plies_removal_callback: Callable) -> None:
        """ Subscribe to global mould state plies removals and invoke callback on delete events """
        self._global_mould_state_plies_removal_callback = global_mould_state_plies_removal_callback
        self.watch_prefix(self.mould_plies_key_prefix, self._handle_global_mould_changes)

    def watch_mould_instructions_updates(self, global_mould_state_instructions_update_callback: Callable) -> None:
        """ Subscribe to global mould state team instructions changes and invoke callback on change events """
        self._global_mould_state_instructions_update_callback = global_mould_state_instructions_update_callback
        self.watch_prefix(self.mould_instructions_key_prefix, self._handle_global_mould_changes)

    def watch_mould_state_updates(self, global_mould_state_update_callback: Callable) -> None:
        """ Subscribe to global mould state state key changes and invoke callback on change events """
        self._global_mould_state_update_callback = global_mould_state_update_callback
        self.watch_prefix(self.mould_state_key, self._handle_global_mould_changes)

    def watch_module_settings_updates(self, module_settings_update_callback: Callable) -> None:
        """" Subscribe to module settings changes and invoke callback on change events """
        self._module_settings_update_callback = module_settings_update_callback
        self.watch_key(self.module_setting_key, self._handle_global_mould_changes)

    def _handle_global_mould_changes(self, watch_response: WatchResponse) -> None:
        """ Callback function to handle global mould state change events """
        try:
            operation_start = time.time()
            self._check_number_of_events(watch_response.events)
            self._process_global_mould_change_events(watch_response.events)
            self._track_total_processing_time_metrics(operation_start)
        except Exception as ex:
            log.warning(f"Failed to handle global mould changes received from ETCD, due to {ex}")

    @staticmethod
    def _check_number_of_events(change_events: list[Event]) -> None:
        if len(change_events) > 1:
            log.warning("Multiple change events received in ETCD watch response. Are we having network congestion?")

    def _process_global_mould_change_events(self, events: list[Event]) -> None:
        for event in events:
            log.debug(f"Event from ETCD received: {event}")
            if isinstance(event, PutEvent):
                self._handle_global_mould_change_put_event(event)
            elif isinstance(event, DeleteEvent):
                self._handle_global_mould_change_delete_event(event)
            else:
                raise ValueError(f"Unrecognised ETCD event type: {event}")

    def _handle_global_mould_change_put_event(self, event: PutEvent) -> None:
        """ Callback function to handle global mould state put events """
        try:
            key, value = self._extract_key_value_pair(event)
            if "plies" in key:
                self._global_mould_state_plies_update_callback(value)
            elif "instructions" in key:
                self._global_mould_state_instructions_update_callback(value)
            elif "state" in key:
                self._global_mould_state_update_callback(value)
            elif "settings" in key:
                self._module_settings_update_callback(value)
            else:
                raise ValueError(f"Unrecognised ETCD put event 'key': {key}")
        except ValueError as ex:
            log.warning(f"Failed to handle global mould state put event from ETCD, due to {ex}")

    def _handle_global_mould_change_delete_event(self, event: DeleteEvent) -> None:
        """ Callback function to handle global mould state delete events """
        try:
            key, _ = self._extract_key_value_pair(event)
            if "plies" in key:
                self._global_mould_state_plies_removal_callback(key)
            else:
                raise ValueError(f"Unrecognised ETCD delete event 'key': {key}")
        except ValueError as ex:
            log.warning(f"Failed to handle global mould state put event from ETCD, due to {ex}")

    @staticmethod
    def _extract_key_value_pair(event: Event) -> tuple[str, str]:
        key: str = event.key.decode("utf-8")
        value: str = event.value.decode("utf-8")
        return key, value

    @staticmethod
    def _track_total_processing_time_metrics(operation_start: float) -> None:
        operation_duration = time.time() - operation_start
        METRICS_SUMMARY.observe(operation_duration)
        METRICS_HISTOGRAM.observe(operation_duration)

    def update_mould_plies(self, updated_mould_state_plies: set[PlyState]) -> None:
        """ Push mould plies updates to ETCD store """
        for ply in updated_mould_state_plies:
            ply.source_device = cfg.DEVICE_MODULE_ID
            self.put_key(f"{self.mould_plies_key_prefix}/{ply.id}", ply.serialize())

    def set_mould_state(self, value: GlobalMouldState) -> None:
        """ Set mould state to ETCD store """
        self.put_key(f"{self.mould_state_key}", value.name)

    def set_mould_blade_sn(self, team_instruction: dict) -> None:
        """ Set mould blade_sn to ETCD store """
        blade_sn = team_instruction["bladeSn"]
        self.put_key(f"{self.mould_blade_sn_key}", blade_sn)

    def update_mould_instructions(self, team_instructions_update: list[dict]) -> None:
        """ Push mould instructions updates to ETCD store """
        for instruction in team_instructions_update:
            layer_id = instruction["layerId"]
            pallet_id = instruction["palletId"]
            instruction_id = f"{layer_id}-{pallet_id}"
            instruction["source_device"] = cfg.DEVICE_MODULE_ID
            self.put_key(f"{self.mould_instructions_key_prefix}/{instruction_id}", instruction)

    def remove_mould_plies(self) -> None:
        """ Remove global mould state plies """
        self.delete_prefix(self.mould_plies_key_prefix)

    def remove_mould_instructions(self) -> None:
        """ Remove global mould state instructions """
        self.delete_prefix(self.mould_instructions_key_prefix)
