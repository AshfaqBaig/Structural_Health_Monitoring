from collections import namedtuple
import pytest

import numpy as np

from app.inference.tis_client import TritonInferenceServerClient

@pytest.mark.parametrize(
    "type, expectation",
    [
        ("BOOL", bool),
        ("FP16",  np.float16),
        ("FP32", np.float32),
        ("FP64", np.float64),
        ("BYTES", np.dtype(object)),
    ],
)
def test_model_dtype_to_np(type, expectation):
    assert TritonInferenceServerClient.model_dtype_to_np(type) == expectation

def test_model_metadata_input_check():
    model_metadata = namedtuple('model_meta', 'inputs outputs')
    model_config = namedtuple('model_meta', 'input')

    model_metadata_instance = model_metadata(["1"], ["1"])
    model_config_instance = model_config(["1"])
    assert TritonInferenceServerClient.model_metadata_input_check(model_metadata_instance, model_config_instance) is None

    model_metadata_instance = model_metadata([], ["1"])
    model_config_instance = model_config(["1"])
    with pytest.raises(Exception) as exp:
        TritonInferenceServerClient.model_metadata_input_check(model_metadata_instance, model_config_instance)
    assert str(exp.value) == "expecting 1 input, got 0"

    model_metadata_instance = model_metadata(["1"], [])
    model_config_instance = model_config(["1"])
    with pytest.raises(Exception) as exp:
        TritonInferenceServerClient.model_metadata_input_check(model_metadata_instance, model_config_instance)
    assert str(exp.value) == "expecting 1 output, got 0"

    model_metadata_instance = model_metadata(["1"], ["1"])
    model_config_instance = model_config([])
    with pytest.raises(Exception) as exp:
        TritonInferenceServerClient.model_metadata_input_check(model_metadata_instance, model_config_instance)
    assert str(exp.value) == "expecting 1 input in model configuration, got 0"
