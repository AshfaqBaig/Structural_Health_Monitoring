# pylint: disable=no-self-use

from unittest.mock import Mock, MagicMock
import pytest
import numpy as np
import app.config as cfg

from app.inference.tis_client import TritonInferenceServerClient

from app.logging.logger import yield_logger
log = yield_logger()


@pytest.fixture(name="grpc_stub")
def fixture_grpc_stub():
    """ Fixture to mock grpc_stub """
    class GRPCstub:
        """ Class to mock grpc_stub object """

        def ServerLive(self, param1) -> str:
            """ Function to mock GRPCstub.ServerLive() """
            return param1

        def ServerReady(self, param1) -> str:
            """ Function to mock GRPCstub.ServerReady() """
            return param1

        def ModelReady(self, param1) -> str:
            """ Function to mock GRPCstub.ModelReady() """
            return param1

        def ServerMetadata(self, param1) -> str:
            """ Function to mock GRPCstub.ServerMetadata() """
            return param1

        def ModelMetadata(self, _) -> str:
            """ Function to mock GRPCstub.ModelMetadata() """
            return MagicMock()

        def ModelConfig(self, _) -> str:
            """ Function to mock GRPCstub.ModelConfig() """
            return MagicMock()

        def ModelInfer(self, _) -> str:
            """ Function to mock GRPCstub.ModelInfer() """
            return MagicMock()
    return GRPCstub()


@pytest.fixture(name="model_dtype")
def fixture_model_dtype():
    """ Fixture to mock model dtype """
    class Modeldtype:
        """ Class to mock Model dtype object """

        def model_type(self, param1):
            """ Function to mock model_type() """
            if param1 == "BOOL":
                return bool
            if param1 == "FP16":
                return np.float16
            if param1 == "FP32":
                return np.float32
            if param1 == "FP64":
                return np.float64
            if param1 == "BYTES":
                return np.dtype(object)
            return None
    return Modeldtype()


@pytest.fixture(name="tis_client_obj")
def fixture_tis_client_obj(mocker, grpc_stub):
    """ Fixture to create an object of TritonInferenceServerClient class """
    mocker.patch("app.inference.tis_client", "MAX_GRPC_MESSAGE_SIZE", 10)
    mocker.patch("grpc.insecure_channel")
    mocker.patch(
        "tritonclient.grpc.service_pb2_grpc.GRPCInferenceServiceStub", return_value=grpc_stub)
    mocker.patch("tritonclient.grpc.service_pb2.ServerLiveRequest",
                 return_value="some live value")
    mocker.patch("tritonclient.grpc.service_pb2.ServerReadyRequest",
                 return_value="some ready value")
    mocker.patch("tritonclient.grpc.service_pb2.ModelReadyRequest",
                 return_value="some model value")
    mocker.patch("tritonclient.grpc.service_pb2.ServerMetadataRequest",
                 return_value="some metadata value")
    mocker.patch("tritonclient.grpc.service_pb2.ModelMetadataRequest",
                 return_value="some model metadata value")
    mocker.patch("tritonclient.grpc.service_pb2.ModelConfigRequest",
                 return_value="some model config value")
    mocker.patch(
        "tritonclient.grpc.service_pb2.ModelMetadataResponse", return_value=Mock())
    mocker.patch.object(TritonInferenceServerClient,
                        "parse_model", return_value=[1, 2, 3, 4, 5, 6, 7])
    mocker.patch.object(TritonInferenceServerClient, "model_dtype_to_np")
    return TritonInferenceServerClient()


def test_set_model_name(tis_client_obj: TritonInferenceServerClient):
    """ Function to mock set_model_name """
    tis_client_obj.set_model_name("some model name")
    assert cfg.TIS_MODEL_NAME == "some model name"


def test_get_model_name(tis_client_obj: TritonInferenceServerClient):
    """ Function to mock get_model_name """
    tis_client_obj.set_model_name("my_model")
    assert cfg.TIS_MODEL_NAME == "my_model"
    assert tis_client_obj.get_model_name() == "my_model"


def test_set_model_version(tis_client_obj: TritonInferenceServerClient):
    """ Function to mock set_model_version """
    tis_client_obj.set_model_version("1")
    assert cfg.TIS_MODEL_VERSION == "1"


def test_get_model_version(tis_client_obj: TritonInferenceServerClient):
    """ Function to mock get_model_version """
    tis_client_obj.set_model_version("2")
    assert cfg.TIS_MODEL_VERSION == "2"
    assert tis_client_obj.get_model_version() == "2"


@pytest.mark.parametrize("test_input, expected", [("BOOL", bool), ("FP16", np.float16), ("FP32", np.float32), ("BYTES", np.dtype(object))])
def test_model_dtype_to_np(tis_client_obj: TritonInferenceServerClient, model_dtype, test_input, expected):
    """ Function to mock model_dtype_to_np """
    tis_client_obj.npdtype = model_dtype.model_type(test_input)
    assert tis_client_obj.npdtype == expected


def test_tis_infer_asyn(tis_client_obj: TritonInferenceServerClient, mocker):
    '''Function checks the request '''
    filename = 'ig_aal-h10-b9702u1-cm0101-20220327-06091546.jpg'
    tiles = {
        f"{filename.split('.', maxsplit=1)[0]}_0_0_400_400": np.ones((400, 400)),
        f"{filename.split('.', maxsplit=1)[0]}_6400_4800_400_400": np.ones((400, 400))
    }
    mocker.patch.object(TritonInferenceServerClient, "request_generator")
    responses, result_filenames = tis_client_obj.infer_async(tiles)
    assert responses is not None
    assert result_filenames is not None


def test_model_metadata_input_format_check(tis_client_obj: TritonInferenceServerClient):
    '''Function checks the model input metadata '''
    model_metadata = tis_client_obj.grpc_stub.ModelMetadata("some")
    config_response = tis_client_obj.grpc_stub.ModelConfig("ff")
    channels, h, w = tis_client_obj.model_metadata_input_format_check(
        config_response, 10, model_metadata)
    assert channels is not None
    assert h is not None
    assert w is not None
