import json
import pytest
import ray
from azure.iot.device.aio import IoTHubModuleClient
from app.inference.tis_client import TritonInferenceServerClient
from app.message_listener import MessageListener
from app.messaging_wrapper import MessagingWrapper


@pytest.fixture(autouse=True)
def run_around_tests():
    '''Function shutdown the ray '''
    yield
    ray.shutdown()


@pytest.fixture(name="message_listener")
def message_listener_instance(mocker):
    '''Function to mock the constructor MessageListener'''
    mocker.patch.object(TritonInferenceServerClient,
                        "__init__", return_value=None)
    mocker.patch("app.processors.default.DefaultProcessor")
    mocker.patch("azure.iot.device.aio.IoTHubModuleClient.create_from_edge_environment",
                 return_value=IoTHubModuleClient)
    mocker.patch("asyncio.run")
    mocker.patch.object(MessagingWrapper, "__init__", return_value=None)
    return MessageListener()


@pytest.mark.asyncio
async def test_extract_input(message_listener):
    '''Check the correlation id and data'''
    # GIVEN
    message = message_listener._build_message(output_message=json.dumps({"output": 1}),
                                              correlation_id="abc",
                                              custom_properties="")

    # WHEN
    correlation_id, custom_properties, data = message_listener._extract_input(
        message)
    assert correlation_id == "abc"
    assert custom_properties == ""
    assert data is not None
