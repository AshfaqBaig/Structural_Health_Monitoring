# pylint: disable=missing-class-docstring, missing-function-docstring

import logging
import json
from unittest.mock import MagicMock
from app.settings_change_handler import SettingsChangeHandler
import app.config as cfg

def test_on_settings_change(caplog):
    # GIVEN
    restart_module_callback = MagicMock()
    handler = SettingsChangeHandler(restart_module_callback)
    output_name = "magicOutput"
    key = f"/some-module/output/{output_name}"
    cfg.MOULD_ID = "initial"
    value = {
        "random": "value",
        "MOULD_ID": "xyz"
    }
    response = MagicMock(
        events=[MagicMock(key=key.encode(), value=json.dumps(value).encode())])

    # WHEN
    caplog.set_level("DEBUG", "edge-detection")
    with caplog.at_level(logging.DEBUG):
        # WHEN handler.on_settings_change is called
        handler.on_settings_change(response)

    # VERIFY
    assert restart_module_callback.call_count == 1
    assert "Etcd message key:" in caplog.text
    assert "New module configuration received" in caplog.text
    assert "Module does not support config key: random" in caplog.text
    assert "Updating key MOULD_ID" in caplog.text

def test_on_settings_change_exception(caplog):
    # GIVEN
    restart_module_callback = MagicMock()
    handler = SettingsChangeHandler(restart_module_callback)
    output_name = "magicOutput"
    key = f"/some-module/output/{output_name}"

    response = MagicMock(
        events=[MagicMock(key=key.encode(), value="a")])

    # WHEN handler.on_settings_change is called
    handler.on_settings_change(response)

    # THEN an exception of type AttributeError is raised
    assert "AttributeError" in caplog.text

    assert restart_module_callback.call_count == 0
