# pylint: disable=missing-class-docstring, missing-function-docstring, no-self-use, protected-access
import logging
from unittest.mock import MagicMock, AsyncMock
import pytest
from app.method_request_handler import MethodRequestHandler
import app.config as cfg

@pytest.fixture(name="method_request_handler")
def fixture_method_request_handler():
    return MethodRequestHandler(MagicMock())

@pytest.fixture(name="set_log_level_payload")
def fixture_set_log_level_payload(mocker):
    mock_request = MagicMock()
    mocker.patch.object(mock_request, "name", "set_log_level")
    mocker.patch.object(mock_request, "payload",  {"value": "DEBUG"})
    return mock_request

@pytest.mark.asyncio
async def test_set_log_level_when_different_log_level(mocker, method_request_handler, set_log_level_payload, caplog):
    mock_create_from_method_request = mocker.patch("app.method_request_handler.MethodResponse.create_from_method_request")
    mock_client = mocker.patch.object(method_request_handler, "module_client", new_callable=MagicMock)
    mock_send_method_response = mocker.patch.object(mock_client, "send_method_response", new_callable=AsyncMock)
    cfg.LOG_LEVEL = "ERROR"

    # RUN
    with caplog.at_level(logging.DEBUG):
        await method_request_handler.run(set_log_level_payload)

    # VERIFY
    assert mock_send_method_response.call_count == 1
    assert mock_create_from_method_request.call_count == 1
    assert mock_create_from_method_request.call_args[0][1] == 200
    assert mock_create_from_method_request.call_args[0][2] == {"value": "DEBUG"}
    assert "Method set_log_level invocation with:" in caplog.text
    assert "Updated log level to" in caplog.text
    assert cfg.LOG_LEVEL == set_log_level_payload.payload.get("value")

@pytest.mark.asyncio
async def test_set_log_level_when_same_log_level(mocker, method_request_handler, set_log_level_payload, caplog):
    mock_create_from_method_request = mocker.patch("app.method_request_handler.MethodResponse.create_from_method_request")
    mock_client = mocker.patch.object(method_request_handler, "module_client", new_callable=MagicMock)
    mock_send_method_response = mocker.patch.object(mock_client, "send_method_response", new_callable=AsyncMock)
    cfg.LOG_LEVEL = "DEBUG"

    # RUN
    with caplog.at_level(logging.DEBUG):
        await method_request_handler.run(set_log_level_payload)

    # VERIFY
    assert mock_send_method_response.call_count == 1
    assert mock_create_from_method_request.call_count == 1
    assert mock_create_from_method_request.call_args[0][1] == 304
    assert "Method set_log_level invocation with:" in caplog.text
    assert cfg.LOG_LEVEL == set_log_level_payload.payload.get("value")

@pytest.mark.asyncio
async def test_invalid_method(mocker, method_request_handler, caplog):
    mock_client = mocker.patch.object(method_request_handler, "module_client", new_callable=MagicMock)
    mock_send_method_response = mocker.patch.object(mock_client, "send_method_response", new_callable=AsyncMock)
    mock_create_from_method_request = mocker.patch("app.method_request_handler.MethodResponse.create_from_method_request")

    mock_request = MagicMock()
    mocker.patch.object(mock_request, "name", "invalid_method_name")

    # RUN
    with caplog.at_level(logging.DEBUG):
        await method_request_handler.run(mock_request)

    # VERIFY
    assert mock_send_method_response.call_count == 1
    assert mock_create_from_method_request.call_count == 1
    assert mock_create_from_method_request.call_args[0][1] == 400
    assert "Method invalid_method_name invocation with:" in caplog.text
