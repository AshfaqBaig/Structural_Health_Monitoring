# All tests need severe refactoring

# pylint: disable=protected-access, missing-class-docstring, missing-function-docstring
import json
from unittest.mock import Mock, MagicMock
import ray

import pytest
from app.processors.default import DefaultProcessor

from app.logging.logger import yield_logger
log = yield_logger()


class DefaultProcessorTests:

    @pytest.fixture(autouse=True)
    def run_around_tests(self):
        yield
        ray.shutdown()

    def test_success_single_image(self, mocker):
        # prepare testing subjects
        mock_tis = mocker.patch(
            "app.inference.tis_client.TritonInferenceServerClient", new_callable=Mock)
        mock_tis_infer_async = mocker.patch.object(
            mock_tis, "infer_async", return_value=({}, ["filename.json"]))

        default_processor = DefaultProcessor(mock_tis, MagicMock())

        with open("tests/test_resources/payload.json", "rb") as file:
            file_content = file.read()
            payload = json.loads(file_content)
            log.info("payload is %s ", payload)
            filename = payload['images'][0]['location']
            tiles = {
                f"{filename.split('.')[0]}_0_0_400_400": "",
                f"{filename.split('.')[0]}_6400_4800_400_400": ""
            }
            shape = (4860, 6480)
            request_preprocessor_test = mocker.patch("app.processors.preprocessor.RequestPreprocessor.run",
                                                     return_value=[tiles, shape])
            request_postprocessor_test = mocker.patch(
                "app.processors.postprocessor.ResponsePostprocessor.run")

            # run test
            result: str = default_processor.run(payload)

            # verify
            assert result is not None
            assert result['session'] is not None
            assert len(result['images']) == 1
            assert result['images'][0]['location'] is not None

            first_image = payload['images'][0]
            request_preprocessor_test.assert_called_once_with(first_image)
            mock_tis_infer_async.assert_called_once()
            request_postprocessor_test.assert_called_once_with(
                first_image['location'],  {}, ['filename.json'], shape)

    def test_success_multiple_images(self, mocker):
        # prepare testing subjects
        mock_tis = mocker.patch(
            "app.inference.tis_client.TritonInferenceServerClient", new_callable=Mock)
        mock_tis_infer_async = mocker.patch.object(
            mock_tis, "infer_async", return_value=({}, ["filename.json"]))

        default_processor = DefaultProcessor(mock_tis, MagicMock())

        with open("tests/test_resources/payload_multiple_images.json", "rb") as file:
            file_content = file.read()
            payload = json.loads(file_content)
            log.info("payload is %s ", payload)
            filename = payload['images'][0]['location']
            tiles = {
                f"{filename.split('.')[0]}_0_0_400_400": "",
                f"{filename.split('.')[0]}_6400_4800_400_400": ""
            }
            request_preprocessor_test = mocker.patch("app.processors.preprocessor.RequestPreprocessor.run",
                                                     return_value=tiles)
            request_postprocessor_test = mocker.patch(
                "app.processors.postprocessor.ResponsePostprocessor.run")

            # run test
            result: str = default_processor.run(payload)

            # verify
            assert result is not None
            assert result['session'] is not None
            assert len(result['images']) == 2
            assert result['images'][0]['location'] is not None

            assert request_preprocessor_test.call_count == 2
            assert mock_tis_infer_async.call_count == 2
            assert request_postprocessor_test.call_count == 2
