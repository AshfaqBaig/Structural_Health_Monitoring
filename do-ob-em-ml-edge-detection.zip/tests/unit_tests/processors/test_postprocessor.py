import os
import pytest
import numpy as np
import ray
import cv2
import app.config as cfg

from app.processors.postprocessor import ResponsePostprocessor

from app.logging.logger import yield_logger
log = yield_logger()

@pytest.fixture(autouse=True)
def run_around_tests():
    yield
    ray.shutdown()

def tile_image(image, image_name, step_size=400, window_size=(400, 400), convert_byte=False):
    ''' Function tiles the image '''
    tiles = {}
    response = []
    result_filenames = []
    #  slide a window across the image
    for y in range(0, image.shape[0], step_size):
        for x in range(0, image.shape[1], step_size):
            # yield the current window
            tile_name = [
                str(i) for i in [image_name, x, y, window_size[0], window_size[1]]
            ]
            tile_name = "_".join(tile_name)
            tiles[tile_name] = image[y: y +
                                        window_size[1], x: x + window_size[0]]
            if tiles[tile_name].shape[0] < 400 or tiles[tile_name].shape[1] < 400:
                bottom_border = 400 - tiles[tile_name].shape[0]
                right_border  = 400 - tiles[tile_name].shape[1]
                tiles[tile_name]  = cv2.copyMakeBorder(tiles[tile_name], 0, bottom_border, 0, right_border, cv2.BORDER_CONSTANT, (0,0,0))
            shape_tile =  tiles[tile_name].shape
            if convert_byte:
                tiles[tile_name] = tiles[tile_name].astype("float32").tobytes()
                response.append((tiles[tile_name], shape_tile))
                result_filenames.append([tile_name])
    if convert_byte:
        return response,  result_filenames
    return tiles

def test_stitch_image():
    '''Function tests the stitching of images '''
    filename = "ig_aal-h10-b9702u1-cm0101-20220327-06091546.jpg"
    tiles = tile_image(np.ones((4860, 6480)), filename.split('.', maxsplit=1)[0])
    single_images = ResponsePostprocessor().stitch_image(tiles, (4860, 6480))
    assert single_images.shape == (4860, 6480)

def test_sigmoid_psitive_values():
    '''Function checks the positive values in sigmoid'''
    tile = np.zeros((400, 400))
    output_sigmoid = ResponsePostprocessor().vec_sigmoid(tile)
    assert np.unique(output_sigmoid)[0] == 0.5

def test_sigmoid_negative_values():
    '''Function checks the negative values in sigmoid'''
    tile = np.zeros((400, 400))
    tile[tile == 0] = -1
    output_sigmoid = ResponsePostprocessor().vec_sigmoid(tile)
    assert round(np.unique(output_sigmoid)[0], 4) == 0.2689

def test_image_normalization():
    '''Function tests the image normalisation function'''
    tile = np.zeros((400,400))
    output_image = ResponsePostprocessor().image_normalization(tile)
    assert np.unique(output_image)[0] == 0.0

def test_post_processor_run():
    '''Function tests the post processing run'''
    filename = "ig_aal-h10-b9702u1-cm0101-20220327-06091546.jpg"
    cfg.OUTPUT_PATH = "tests/test_resources/results"
    response, result_filenames = tile_image(np.ones((4860, 6480)), filename.split('.', maxsplit=1)[0], convert_byte = True)
    instance_post_processor = ResponsePostprocessor()
    instance_post_processor.run(filename, inference_response = response, result_filenames= result_filenames, shape=(4860, 6480) )
    filename = filename.replace("ig_", "ed_", 1)
    result_path = f"{cfg.OUTPUT_PATH}/{filename}"
    assert os.path.exists(result_path)
