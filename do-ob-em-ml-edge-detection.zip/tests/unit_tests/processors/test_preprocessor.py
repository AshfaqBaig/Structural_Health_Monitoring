# TODO: Get rid of Unit-Test Library Overhead, get rid of hardcoded references to images
# pylint: disable=protected-access, missing-class-docstring, missing-function-docstring, no-self-use, disable=unsubscriptable-object
import datetime
from unittest.mock import MagicMock
import pytest

from app.processors.preprocessor import RequestPreprocessor
import app.config as cfg


class RequestPreprocessorTests:

    @pytest.fixture(autouse=True)
    def run_around_tests(self):
        cfg.INPUT_PATH = "tests/test_resources/"

    def test_preprocessor_success(self):
        mock_messaging = MagicMock()
        preprocessor = RequestPreprocessor(mock_messaging)
        filename = 'ig_aal-h10-b9702u1-cm0101-20220327-06091546.jpg'
        payload = {
            "location": filename,
            "metadata": {
                "camera-id": "hall-1-blade-2-camera-01",
                "image-id": "00000001",
                "image-content-type": "image/jpg",
                "capture-timestamp": (datetime.datetime.today() + datetime.timedelta(days=1)).strftime('%Y%m%d')
            }
        }

        # RUN
        tiles, shape = preprocessor.run(payload)

        # VERIFY
        assert tiles is not None
        assert shape is not None
        assert shape == (4860, 6480)
        assert len(tiles) == 221
        filename_without_extension = filename.split('.', maxsplit=1)[0]
        assert tiles[f"{filename_without_extension}_0_0_400_400"] is not None
        assert tiles[f"{filename_without_extension}_400_0_400_400"] is not None
        assert tiles[f"{filename_without_extension}_800_0_400_400"] is not None
        assert tiles[f"{filename_without_extension}_6400_4800_400_400"] is not None
        assert mock_messaging.send_message_to_trace_task.call_count == 0

    def test_pile_up(self, caplog):
        mock_messaging = MagicMock()
        preprocessor = RequestPreprocessor(mock_messaging)
        filename = 'ig_aal-h10-b9702u1-cm0101-20220327-06091546.jpg'
        payload = {
            "location": filename,
            "metadata": {
                "camera-id": "hall-1-blade-2-camera-01",
                "image-id": "00000001",
                "image-content-type": "image/jpg",
                "capture-timestamp":  (datetime.datetime.today() - datetime.timedelta(days=1)).strftime('%Y%m%d')
            }
        }

        #RUN
        tiles, shape = preprocessor.run(payload)

        # VERIFY
        assert tiles is None
        assert shape is None
        assert "Discarding image due to delay of" in caplog.text
        assert mock_messaging.send_message_to_trace_task.call_count == 1

    def test_preprocessor_failure(self):
        mock_messaging = MagicMock()
        preprocessor = RequestPreprocessor(mock_messaging)
        filename = 'invalid.jpg'
        payload = {
            "location": filename,
            "metadata": {
                "camera-id": "hall-1-blade-2-camera-01",
                "image-id": "00000001",
                "image-content-type": "image/jpg",
                "capture-timestamp": (datetime.datetime.today() + datetime.timedelta(days=1)).strftime('%Y%m%d')
            }
        }
        # RUN
        tiles, shape = preprocessor.run(payload)

        # VERIFY
        assert tiles is None
        assert shape is None
        assert mock_messaging.send_message_to_trace_task.call_count == 0
