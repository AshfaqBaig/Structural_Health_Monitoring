import datetime
import pytest

from unittest.mock import MagicMock
from app.processors.default import DefaultProcessor
from app.inference.tis_client import TritonInferenceServerClient
import app.config as cfg


@pytest.fixture(name="payload_generator", autouse=True)
def fixture_payload_generator():
    '''Function generates payload'''
    payload = {
        "session": {
            "cameraId": "test_cam",
            "moduleId": "test"
        },
        "images": [
            {
                "location": "ig_aal-h10-b9702u1-cm0101-20220327-06091546.jpg",
                "metadata": {
                            "camera-id": "hall-1-blade-2-camera-01",
                    "image-id": "00000001",
                    "image-content-type": "image/jpg",
                    "capture-timestamp": datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S.%f%z')
                }
            }
        ]
    }
    return payload


def test_processor_success(payload_generator):
    """Inference server test case configurion goes here"""

    cfg.INPUT_PATH = "tests/test_resources/"
    cfg.OUTPUT_PATH = "tests/test_resources/results"
    cfg.TIS_URL = "localhost:8001"
    cfg.TIS_MODEL_NAME = "dexined_tf2"
    cfg.TIS_MODEL_VERSION = "35"
    cfg.TIS_BATCH_SIZE = 1

    tis_client = TritonInferenceServerClient()
    processor = DefaultProcessor(tis_client, MagicMock())

    # run preprocessor, processor, postprocessor
    result = processor.run(payload_generator)

    # check inference results
    assert result
