#!/bin/bash

PAYLOAD_NAME=${1-"dev_gt_test"}
#INPUT_DIR=${2:-${HOME}/data/dataset-edge_detection/splitset/valid/images}
INPUT_DIR=${2:-${HOME}/data/dataset-edge_dev_gt_test}

rm -rf payload_${PAYLOAD_NAME}.json

(
cat <<HERE
{
  "messageId": "5e5ee761-5741-4212-b038-c47ffcc74a2a",
  "correlationId": "a51dd965-04e8-4125-9d86-182a62553327",
  "time": "2020-06-22T13:00:00Z",
  "contentType": "application/json",
  "contentEncoding": "utf-8",
  "data": {
    "session": {
      "jobId": "test_job",
      "cameraId": "test_cam",
      "moduleId": "test"
    },
    "images": [
HERE
) > payload_${PAYLOAD_NAME}.json


TOT_IMG=`ls ${INPUT_DIR} | wc | awk '{print $1}'`
set i=0
for image in `ls ${INPUT_DIR}`;do
	let "i++"
	echo "$image $i"

if [ "${i}" == "${TOT_IMG}" ];then
(
cat <<HERE 
	    {
        "location": "${image}",
        "metadata": {
          "camera-id": "hall-1-blade-2-camera-01",
          "image-id": "000000$i",
          "image-content-type": "image/jpg",
          "capture-timestamp": "2020-06-22T13:00:01Z"
        }
      }
HERE
) >> payload_${PAYLOAD_NAME}.json
else
(
cat <<HERE 
	    {
        "location": "${image}",
        "metadata": {
          "camera-id": "hall-1-blade-2-camera-01",
          "image-id": "000000$i",
          "image-content-type": "image/jpg",
          "capture-timestamp": "2020-06-22T13:00:01Z"
        }
      },
HERE
) >> payload_${PAYLOAD_NAME}.json
fi

done

(
cat <<HERE
   ]
  }
}
HERE
) >> payload_${PAYLOAD_NAME}.json


