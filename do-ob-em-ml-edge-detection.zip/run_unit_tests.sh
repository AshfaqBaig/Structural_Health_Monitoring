#!/bin/bash
echo "Executing Unit Tests..."
python -m pytest -vv tests/unit_tests --random-order --random-order-bucket=module --random-order-seed=84334 --cov-report term --cov=app 
result=$?
if [ $result -ne 0 ]
then
  echo "Failed for Unit-Test"
fi
rm -r .pytest_cache 2> /dev/null
rm .coverage* 2> /dev/null
rm coverage.xml 2> /dev/null
rm test-result.xml 2> /dev/null
exit $result
