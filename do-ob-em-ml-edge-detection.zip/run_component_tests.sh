#!/bin/bash
echo "Executing Component Tests..."
python -m pytest -vv tests/component_tests 
result=$?
if [ $result -ne 0 ]
then
  echo "Failed for Component-Test"
fi
rm -r .pytest_cache 2> /dev/null
rm .coverage* 2> /dev/null
rm coverage.xml 2> /dev/null
rm test-result.xml 2> /dev/null
exit $result