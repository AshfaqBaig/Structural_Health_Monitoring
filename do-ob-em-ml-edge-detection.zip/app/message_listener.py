import time
import asyncio
import json
from typing import Tuple, Any

from azure.iot.device.aio import IoTHubModuleClient
from azure.iot.device.iothub.models import Message

from app.logging import logger
from app.processors.default import DefaultProcessor
from app.inference.tis_client import TritonInferenceServerClient
from app.method_request_handler import MethodRequestHandler
from app.messaging_wrapper import MessagingWrapper

DEFAULT_OUTPUT = "defaultOutput"
ERROR_OUTPUT = "errorOutput"

log = logger.yield_logger()


class MessageListener:
    """
    AMQP Listener implementation. It accepts AMQP payloads and forwards them to request processor.
    Also module direct methods are supported.
    """

    def __init__(self):
        self.tis_client = TritonInferenceServerClient()
        self.module_client = IoTHubModuleClient.create_from_edge_environment()
        self._messaging = MessagingWrapper(self.module_client)
        self.default_processor = DefaultProcessor(self.tis_client, self._messaging)
        self.method_request_handler = MethodRequestHandler(self.module_client)
        
    def restart(self):
        """Check model metadata """
        self.tis_client.read_model_meta_data()

    async def message_handler(self, input_message):
        """
        Default AMQP message handler
        """
        try:
            log.info("Message received on '%s'", input_message.input_name)
            correlation_id, custom_properties, data = self._extract_input(input_message)
            output_message = self.default_processor.run(data)  # call pipeline logic
            message = self._build_message(output_message, correlation_id, custom_properties)
            # pass data further to output
            await self.module_client.send_message_to_output(message, DEFAULT_OUTPUT)
        except Exception as ex:
            # pass data further to error output
            log.exception(ex)
            await self.module_client.send_message_to_output(str(ex), ERROR_OUTPUT)

    @staticmethod
    def _build_message(output_message: dict, correlation_id: str, custom_properties: Any) -> Message:
        """ Creates message to EV """
        log.debug(
            f"Building message with correlation_id={correlation_id} and custom_properties={custom_properties}.", extra={"correlation_id": correlation_id})
        message = Message(data=str(json.dumps(output_message)))
        message.correlation_id = correlation_id
        message.custom_properties = custom_properties
        return message

    @staticmethod
    def _extract_input(input_message: Message) -> Tuple:
        """ Extracts message components"""
        correlation_id = input_message.correlation_id
        custom_properties = input_message.custom_properties
        data = json.loads(input_message.data)
        log.debug(
            f"Extracted correlation_id={correlation_id} and custom_properties={custom_properties} from message.", extra={"correlation_id": correlation_id})
        return correlation_id, custom_properties, data

    def empty_listener(self):
        """
        Empty listener to keep module always running
        """
        while True:
            time.sleep(600) # nosemgrep: python.lang.best-practice.sleep.arbitrary-sleep

    async def run(self):
        """
        Entrypoint main method
        """
        try:
            await self.module_client.connect()

            self.module_client.on_message_received = self.message_handler
            self.module_client.on_method_request_received = self.method_request_handler.run

            log.info("Message Listener started")
            log.info(f"Log level for {log.name} logger is: {log.getEffectiveLevel()}")

            # Run the empty listener in the event loop
            loop = asyncio.get_event_loop()
            user_finished = loop.run_in_executor(None, self.empty_listener)
            await user_finished

            # Finally, disconnect
            await self.module_client.disconnect()

        except Exception:
            log.exception("Unexpected error")
            raise
