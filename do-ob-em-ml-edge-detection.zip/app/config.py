"""Module defines all configuration options"""
import os
import logging

MODULE_APP_NAME = "edge-detection"
LOGGER_CONFIG = os.getenv("LOGGER_CONFIG", "logging-plain.ini")

MOULD_ID = os.environ.get("MOULD_ID")
IOTEDGE_MODULEID = os.environ.get("IOTEDGE_MODULEID")
IOTEDGE_DEVICEID = os.environ.get("IOTEDGE_DEVICEID")
IOTEDGE_GATEWAYHOSTNAME = os.environ.get("IOTEDGE_GATEWAYHOSTNAME")

# env var
TIS_URL = os.environ.get("TIS_URL", "tis:8007")
INPUT_PATH = os.environ.get("INPUT_PATH")
OUTPUT_PATH = os.environ.get("OUTPUT_PATH")

TIS_MODEL_NAME = os.environ.get("TIS_MODEL_NAME")
TIS_MODEL_VERSION = os.environ.get("TIS_MODEL_VERSION", "")
TIS_BATCH_SIZE = os.environ.get("TIS_BATCH_SIZE", 1)
LOG_LEVEL = os.environ.get("LOG_LEVEL", logging.INFO)

METRIC_LABELS = ["device_id", "module_id", "mould_id"]
PROMETHEUS_PORT = int(os.environ.get("PROMETHEUS_PORT") or 9060)
DISCARD_IMAGE_AFTER_S = float(os.environ.get("DISCARD_IMAGE_AFTER_S", 1))

MODULE_SETTINGS_KEY = f"/devices/{IOTEDGE_GATEWAYHOSTNAME}/modules/{MODULE_APP_NAME}/settings"
ETCD_URL = os.getenv("ETCD_URL", "localhost:2379")
ETCD_TTL = int(os.getenv("ETCD_TTL", 600))
