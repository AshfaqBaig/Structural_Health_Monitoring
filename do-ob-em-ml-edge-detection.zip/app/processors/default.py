"""Starts the ED Pipeline"""
import logging
import json
import time
import math

from prometheus_client import Summary, Histogram

import app.config as cfg
import app.metrics as Metrics
from app.inference.tis_client import TritonInferenceServerClient
from app.processors.preprocessor import RequestPreprocessor
from app.processors.postprocessor import ResponsePostprocessor
from app.messaging_wrapper import MessagingWrapper

from app.logging.logger import yield_logger
log = yield_logger()

HISTOGRAM_BUCKETS = (1, 2, 2.5, 3, 3.5, 4, 5, 10, math.inf)

METRICS_HISTOGRAM = \
    Histogram('ed_total_duration_histogram_seconds',
              'Edge Detection (ED) total duration histogram in seconds',
              buckets=HISTOGRAM_BUCKETS,
              labelnames=Metrics.get_label_keys())
METRICS_SUMMARY = Summary('ed_total_duration_seconds',
                          'Edge Detection (ED) total duration summary in seconds',
                          labelnames=Metrics.get_label_keys())


class DefaultProcessor:
    '''Default message processor'''

    def __init__(self, tis_client: TritonInferenceServerClient, messaging: MessagingWrapper):
        self.tis_client = tis_client
        self.preprocessor = RequestPreprocessor(messaging)
        self.postprocessor = ResponsePostprocessor()

    @staticmethod
    def _log_metrics(operation_start: int):
        operation_duration = time.time() - operation_start
        METRICS_HISTOGRAM.labels(
            **Metrics.get_labels()).observe(operation_duration)
        METRICS_SUMMARY.labels(**Metrics.get_labels()
                               ).observe(operation_duration)

    def run(self, payload: dict) -> dict:
        operation_start = time.time()
        for image in payload["images"]:
            self.process_image(image)
            image["location"] = image["location"].replace("ig_", "ed_", 1)

            if cfg.LOG_LEVEL == logging.DEBUG:
                image_nn = image["location"].split('.')[0]
                result_path = f"{cfg.OUTPUT_PATH}/{image_nn}.json"
                log.info("result_path %s", result_path)
                with open(result_path, "w", encoding="utf-8") as outfile:
                    outfile.write(json.dumps(payload))

        log.debug("Message processed %s", payload['session'])
        total_time = round((time.time()-operation_start) * 1000, 1)
        log.info(f"Total time: {total_time} ms")
        self._log_metrics(time.time() - operation_start)
        return payload

    def process_image(self, image):
        '''Preprocess -> infer -> postprocess image'''

        # preprocess AMQP message
        start = time.time() * 1000
        tiles, shape = self.preprocessor.run(image)
        prep_time = (time.time() * 1000) - start

        # inference
        if tiles is not None:
            start = time.time() * 1000
            inference_response, result_filenames = self.tis_client.infer_async(
                tiles)
            infer_time = (time.time() * 1000) - start

            # postprocess inference result
            start = time.time() * 1000
            self.postprocessor.run(
                image["location"], inference_response, result_filenames, shape)
            post_time = (time.time() * 1000) - start
            log.info("Number of plys %s; Prep time: %sms; Inference time: %sms; Post time %sms", len(tiles),
                     round(prep_time, 1), round(infer_time, 1), round(post_time, 1))
