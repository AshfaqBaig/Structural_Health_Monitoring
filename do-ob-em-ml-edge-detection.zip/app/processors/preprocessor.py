"""
Triton Inference Server request postprocessor module
"""
import os

from typing import Union
from datetime import datetime
import time
from prometheus_client import Summary, Histogram
import cv2

from dateutil import parser
import app.metrics as Metrics
import app.config as cfg
from app.messaging_wrapper import MessagingWrapper

from app.logging.logger import yield_logger
log = yield_logger()

METRICS_HISTOGRAM = \
    Histogram('ed_preprocessing_duration_histogram_seconds',
              'Edge Detection (ED) preprocessing duration histogram in seconds',
              buckets=Metrics.HISTOGRAM_BUCKETS,
              labelnames=Metrics.get_label_keys())
METRICS_SUMMARY = Summary('ed_preprocessing_duration_seconds',
                          'Edge Detection (ED) preprocessing duration summary in seconds',
                         labelnames=Metrics.get_label_keys())
class RequestPreprocessor:
    """
    Inference server request preprocessor
    """
    
    def __init__(self, messaging: MessagingWrapper):
        # Model input is BGR but this is RGB.
        self.rgb_mean = [94.36934384636045,
                         99.62271112435992, 92.01613061914263]
        self._messaging = messaging
    
    @staticmethod
    def _log_metrics(operation_start: int):
        operation_duration = time.time() - operation_start
        METRICS_HISTOGRAM.labels(**Metrics.get_labels()).observe(operation_duration)
        METRICS_SUMMARY.labels(**Metrics.get_labels()).observe(operation_duration)    

    def run(self, payload: dict) -> Union[None, dict]:
        operation_start = time.time()
        
        filename = payload["location"]
        log.info("Processing image %s", filename)
        full_path = f"{cfg.INPUT_PATH}{filename}"

        difference = self._calc_timedifference(
            payload.get('metadata').get('capture-timestamp'))
        if difference >= cfg.DISCARD_IMAGE_AFTER_S:
            discard_message = f"Discarding image due to delay of {difference}sec"
            log.warning(discard_message)
            self._messaging.send_message_to_trace_task(discard_message)
            return None, None

        if os.path.exists(full_path):
            try:
                # Read BGR image.
                image = cv2.imread(full_path, cv2.IMREAD_COLOR)

                # Scale, normalize, and equalize.
                image = self.equalize_clahe(image)

                # TODO: image = image[..., [2, 1, 0]] - self.rgb_mean or  image = image - self.rgb_mean
                shape = (image.shape[0], image.shape[1])

                # Tile image for inference.
                image_name = filename.split(".")[0]
                tiles = self.tile_image(image, image_name)

                log.debug(f"File {cfg.INPUT_PATH}{filename} read")
            except Exception as ex:
                log.exception(ex)
                return
        else:
            log.error("File %s doesn't exist", full_path)
            return None, None
        self._log_metrics(time.time() - operation_start)
        return tiles, shape

    @staticmethod
    def equalize_clahe(image, clip_limit=5, grid_bins=50):
        """
        TODO: Docstring, Unit-test
        TODO: Type-Hints
        """
        lab = cv2.cvtColor(image, cv2.COLOR_BGR2LAB)

        clahe = cv2.createCLAHE(
            clipLimit=clip_limit, tileGridSize=(grid_bins, grid_bins)
        )

        lab[..., 0] = clahe.apply(lab[..., 0])
        return cv2.cvtColor(lab, cv2.COLOR_LAB2BGR)

    @staticmethod
    def tile_image(image, image_name, step_size=400, window_size=(400, 400)):
        """
        TODO: Docstring, Unit-test
        TODO: Type-Hints
        """
        tiles = {}
        #  slide a window across the image
        for y in range(0, image.shape[0], step_size):
            for x in range(0, image.shape[1], step_size):
                # yield the current window
                tile_name = [
                    str(i) for i in [image_name, x, y, window_size[0], window_size[1]]
                ]
                tile_name = "_".join(tile_name)
                tiles[tile_name] = image[y: y +
                                         window_size[1], x: x + window_size[0]]

        return tiles

    @staticmethod
    def _calc_timedifference(timestamp):
        """ Calculates the time in sec btw timestamp and now """
        capture_timestamp = parser.isoparse(timestamp)
        difference = datetime.now() - capture_timestamp.replace(tzinfo=None)
        difference_in_s = round(difference.total_seconds(), 2)
        log.debug(f"Time difference between capture {difference_in_s}sec")
        return difference_in_s
