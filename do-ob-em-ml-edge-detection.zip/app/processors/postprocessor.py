import os
import math
import cv2
import numpy as np
import ray

import time
from prometheus_client import Summary, Histogram
import app.metrics as Metrics
import app.config as cfg

from app.logging.logger import yield_logger
log = yield_logger()

METRICS_HISTOGRAM = \
    Histogram('ed_postprocessing_duration_histogram_seconds',
              'Edge Detection (ED) postprocessing duration histogram in seconds',
              buckets=Metrics.HISTOGRAM_BUCKETS,
              labelnames=Metrics.get_label_keys())
METRICS_SUMMARY = Summary('ed_postprocessing_duration_seconds',
                            'Edge Detection (ED) postprocessing duration summary in seconds',
                            labelnames=Metrics.get_label_keys())

class ResponsePostprocessor:
    """
    Inference server response postprocessor
    """
    def __init__(self):
        self.vec_sigmoid = np.vectorize(self.sigmoid)
        ray.init(num_cpus=64)
        
    @staticmethod
    def _log_metrics(operation_start: int):
        operation_duration = time.time() - operation_start
        METRICS_HISTOGRAM.labels(**Metrics.get_labels()).observe(operation_duration)
        METRICS_SUMMARY.labels(**Metrics.get_labels()).observe(operation_duration)
    
    def run(self, filename: str, inference_response: dict, result_filenames, shape:tuple):
        operation_start = time.time()
        filename = filename.replace("ig_", "ed_", 1)
        result_path = f"{cfg.OUTPUT_PATH}/{filename}"
        os.makedirs(os.path.dirname(result_path), exist_ok=True)

        # pylint: disable=no-member
        tiles = ray.get([
            self._decode_output.remote(self, # pylint: disable=no-member
                                      response=inference_response[i],
                                      filenames=result_filenames[i]) for i in range(len(result_filenames))])
        tiles = {k: v for d in tiles for k, v in d.items()}

        image = self.stitch_image(tiles, shape)
        cv2.imwrite(result_path, image)
        log.debug(f"Result file {result_path} saved")
        
        self._log_metrics(time.time() - operation_start)
        return inference_response

    @staticmethod
    def stitch_image(tiles, shape):
        """
        TODO: Docstring
        TODO: check using numba jit
        TODO: Unit-Test
        TODO: Type-Hints
        """
        image = np.zeros(shape)
        for tile_name in tiles:
            x_y_w_h = tile_name.split(".")[0]
            x = int(x_y_w_h.split("_")[2])
            y = int(x_y_w_h.split("_")[3])
            w = int(x_y_w_h.split("_")[4])
            h = int(x_y_w_h.split("_")[5])

            tile = tiles[tile_name]

            if y + h >= shape[0] and y < shape[0]:
                h = shape[0] - y
            elif y >= shape[0]:
                h = 0
            if x + w >= shape[1] and x < shape[1]:
                w = shape[1] - x
            elif x >= shape[1]:
                w = 0

            image[y : y + h, x : x + w] = tile[:h, :w]

        return 255 - image

    @ray.remote
    def _decode_output(self, response, filenames):
        """
        TODO: Docstring
        TODO: Unit-Test
        TODO: Type-Hints
        """
        all_tiles = {}

        # Bytes to numpy.
        tiles = np.frombuffer(response[0], dtype=np.float32)
        tiles = np.reshape(tiles, response[1])

        for tile, filename in zip(tiles, filenames):
            tile = self.vec_sigmoid(tile)
            tile[tile < 0.0] = 0.0
            tile = self.image_normalization(tile)
            tile = cv2.bitwise_not(tile)

            all_tiles[filename] = tile
        return all_tiles

    @staticmethod
    def sigmoid(x):
        """Numerically-stable sigmoid function.
        TODO: Type-Hints"""
        if x >= 0:
            z = math.exp(-x)
            return 1 / (1 + z)
        else:
            z = math.exp(x)
            return z / (1 + z)

    @staticmethod
    def image_normalization(image, image_min=0, image_max=255):
        """This is a typical image normalization function
        where the minimum and maximum of the image is needed
        source: https://en.wikipedia.org/wiki/Normalization_(image_processing)
        :param image: an image could be gray scale or color
        :param image_min:  for default is 0
        :param image_max: for default is 255
        :return: a normalized image, if max is 255 the dtype is uint8
        TODO: check using numba jit
        TODO: Type-Hints
        """
        image = np.float32(image)
        epsilon = 1e-12  # whenever an inconsistent image
        image = (image - np.min(image)) * (image_max - image_min) / (
            (np.max(image) - np.min(image)) + epsilon
        ) + image_min
        return np.uint8(image)
