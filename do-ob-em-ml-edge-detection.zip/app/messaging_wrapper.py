""" Messaging Wrapper """
import asyncio
import json

from azure.iot.device import Message
from azure.iot.device.aio import IoTHubModuleClient
import app.config as cfg
from app import routes_constants
from app.logging.logger import yield_logger

log = yield_logger()


class MessagingWrapper:
    """ Messaging Wrapper for Edge Hub routed messages """

    def __init__(self, module_client: IoTHubModuleClient):
        self._module_client = module_client

    async def send_message_to_trace(self, status_message: str) -> None:
        """Sends a message to trace output"""

        trace_payload = {
            "StatusMessage": status_message
        }
        content_type = f"{cfg.MODULE_APP_NAME}-trace"
        await self._send_message(trace_payload, routes_constants.TRACE_OUTPUT, content_type)

    def send_message_to_trace_task(self, status_message: str) -> None:
        """Sends a message to trace output from within already running event loop"""

        loop = asyncio.get_running_loop()
        loop.create_task(self.send_message_to_trace(status_message))

    async def _send_message(self, message, output_name, content_type=None) -> None:
        """ Sends a message to Edge Hub routed output """
        log.debug(f"Sending message: {message} to output: {output_name}")
        message = Message(data=json.dumps(message))
        message.content_type = content_type
        await self._module_client.send_message_to_output(message, output_name)
