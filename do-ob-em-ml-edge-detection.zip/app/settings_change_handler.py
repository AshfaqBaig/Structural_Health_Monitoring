import json
from typing import Callable
from etcd3.watch import WatchResponse
from app.logging.logger import yield_logger
import app.config as cfg

log = yield_logger()


class SettingsChangeHandler:
    """ Handle module settings change incoming from etcd """

    def __init__(self, restart_module_callback: Callable):
        self._restart_module_callback = restart_module_callback

    def on_settings_change(self, response: WatchResponse):
        """ Handle module settings change incoming from etcd """
        key: str = response.events[0].key.decode("utf-8")
        try:
            configuration: dict = json.loads(response.events[0].value.decode("utf-8"))
            log.debug(f"Etcd message key: {key}, value: {configuration}")

            # update configuration
            log.info("New module configuration received")
            for key in configuration.keys():
                self._update_config_key(key, configuration)

            # restart app
            self._restart_module_callback()
        except (ValueError, AttributeError):
            log.exception("Failed to parse settings_change")

    def _update_config_key(self, key, configuration):
        try:
            current_config_value = getattr(cfg, key)
            new_config_value = configuration.get(key)

            if current_config_value != new_config_value:
                log.info(f"Updating key {key}: {current_config_value} -> {new_config_value}")
                setattr(cfg, key, new_config_value)
        except AttributeError:
            log.warning(f"Module does not support config key: {key}")
