"""
Triton Inference Server client module which uses gRPC as a communication protocol
"""
import struct
import math
import grpc
from prometheus_client import Summary, Histogram
import tritonclient.grpc.model_config_pb2 as mc
from tritonclient.grpc import service_pb2, service_pb2_grpc
import numpy as np

import time
import app.metrics as Metrics
import app.config as cfg

from app.logging.logger import yield_logger
log = yield_logger()

MAX_GRPC_MESSAGE_SIZE = 2**(struct.Struct('i').size * 8 - 1) - 1

METRICS_HISTOGRAM = \
    Histogram('ed_inference_duration_histogram_seconds',
              'Edge Detection (ED) inference duration histogram in seconds',
              buckets=Metrics.HISTOGRAM_BUCKETS,
              labelnames=Metrics.get_label_keys())
METRICS_SUMMARY = Summary('ed_inference_duration_seconds',
                        'Edge Detection (ED) inference duration summary in seconds',
                         labelnames=Metrics.get_label_keys())

class TritonInferenceServerClient:
    """Triton Inference Server client class"""

    def __init__(self):
        """
        Create and check connection. Also output some meta data about the connection and default model used
        """
        channel_opt = [('grpc.max_send_message_length', MAX_GRPC_MESSAGE_SIZE),
                       ('grpc.max_receive_message_length',
                        MAX_GRPC_MESSAGE_SIZE)]
        # Create gRPC stub
        log.info('Connecting to %s inference server...', cfg.TIS_URL)
        channel = grpc.insecure_channel(cfg.TIS_URL, options=channel_opt)
        self.grpc_stub = service_pb2_grpc.GRPCInferenceServiceStub(channel)

        # Healthcheck
        try:
            request = service_pb2.ServerLiveRequest()
            response = self.grpc_stub.ServerLive(request)
            log.info("TIS %s", response)
        except Exception as ex:
            log.error(ex)

        request = service_pb2.ServerReadyRequest()
        response = self.grpc_stub.ServerReady(request)
        log.info("TIS %s", response)

        request = service_pb2.ModelReadyRequest(
            name=cfg.TIS_MODEL_NAME, version=cfg.TIS_MODEL_VERSION
        )
        response = self.grpc_stub.ModelReady(request)
        log.debug("TIS model %s", response)

        # TIS metadata
        request = service_pb2.ServerMetadataRequest()
        response = self.grpc_stub.ServerMetadata(request)
        log.debug("TIS metadata %s", response)
        
        metadata_response, config_response = self.read_model_meta_data()
        
        (
            self.input_name,
            self.output_name,
            self.c,
            self.h,
            self.w,
            self.format,
            self.dtype,
        ) = self.parse_model(metadata_response, config_response.config)

        self.npdtype = self.model_dtype_to_np(self.dtype)
    
    def read_model_meta_data(self):
        '''Reads the model meta data from triton server'''
        # Model metadata
        request = service_pb2.ModelMetadataRequest(
            name=cfg.TIS_MODEL_NAME, version=cfg.TIS_MODEL_VERSION
        )
        metadata_response = self.grpc_stub.ModelMetadata(request)
        log.debug("TIS model metadata:\n %s", metadata_response)
        
        # Configuration
        request = service_pb2.ModelConfigRequest(
            name=cfg.TIS_MODEL_NAME, version=cfg.TIS_MODEL_VERSION
        )
        config_response = self.grpc_stub.ModelConfig(request)
        log.debug("TIS model config:\n%s", config_response)
        
        return metadata_response, config_response
        
    
    @staticmethod
    def _log_metrics(operation_start: int):
        operation_duration = time.time() - operation_start
        METRICS_HISTOGRAM.labels(**Metrics.get_labels()).observe(operation_duration)
        METRICS_SUMMARY.labels(**Metrics.get_labels()).observe(operation_duration)

    @staticmethod
    def set_model_name(model_name: str):
        '''sets the name of the model '''
        cfg.TIS_MODEL_NAME = model_name

    @staticmethod
    def set_model_version(model_version: str):
        '''sets the version of the model '''
        cfg.TIS_MODEL_VERSION = model_version

    @staticmethod
    def get_model_name():
        ''' gets the name of the model '''
        return cfg.TIS_MODEL_NAME

    @staticmethod
    def get_model_version():
        ''' gets the version of the model '''
        return cfg.TIS_MODEL_VERSION

    @staticmethod
    def model_metadata_input_check(model_metadata, model_config):
        ''' Check the model input metadata'''
        if len(model_metadata.inputs) != 1:
            raise Exception(
                f"expecting 1 input, got {len(model_metadata.inputs)}")
        if len(model_metadata.outputs) != 1:
            raise Exception(
                f"expecting 1 output, got {len(model_metadata.outputs)}")
        if len(model_config.input) != 1:
            raise Exception(
                f"expecting 1 input in model configuration, got {len(model_config.input)}")

    @staticmethod
    def model_metadata_input_format_check(input_config, input_batch_dim, model_metadata):
        ''' check input format of model '''
        input_metadata = model_metadata.inputs[0]
        if input_config.format == mc.ModelInput.FORMAT_NHWC:
            h = input_metadata.shape[1 if input_batch_dim else 0]
            w = input_metadata.shape[2 if input_batch_dim else 1]
            c = input_metadata.shape[3 if input_batch_dim else 2]
        else:
            c = input_metadata.shape[1 if input_batch_dim else 0]
            h = input_metadata.shape[2 if input_batch_dim else 1]
            w = input_metadata.shape[3 if input_batch_dim else 2]
        return c, h, w

    def parse_model(self, model_metadata, model_config):
        '''Function to parse the model'''
        self.model_metadata_input_check(
            model_metadata, model_config)
        input_metadata = model_metadata.inputs[0]
        input_config = model_config.input[0]
        output_metadata = model_metadata.outputs[0]

        if output_metadata.datatype != "FP32":
            raise Exception(
                f"expecting output datatype to be FP32, model \
                 {model_metadata.name} output type is \
                 {output_metadata.datatype}"
            )

        # Model input must have 3 dims, either CHW or HWC (not counting
        # the batch dimension), either CHW or HWC
        input_batch_dim = model_config.max_batch_size > 0
        expected_input_dims = 3 + (1 if input_batch_dim else 0)

        if len(input_metadata.shape) != expected_input_dims:
            raise Exception(
                f"expecting input to have {expected_input_dims} dimensions, \
                model '{model_metadata.name}' input has {len(input_metadata.shape)}"
            )
        if input_config.format is not mc.ModelInput.FORMAT_NCHW and \
           input_config.format is not mc.ModelInput.FORMAT_NHWC:
            raise Exception(
                f"unexpected input format \
                {mc.ModelInput.Format.Name(input_config.format)}, expecting \
                {mc.ModelInput.Format.Name(mc.ModelInput.FORMAT_NCHW)} or \
                {mc.ModelInput.Format.Name(mc.ModelInput.FORMAT_NHWC)}"
            )

        c, h, w = self.model_metadata_input_format_check(
            input_config, input_batch_dim, model_metadata)

        return (
            input_metadata.name,
            output_metadata.name,
            c,
            h,
            w,
            input_config.format,
            input_metadata.datatype,
        )

    @staticmethod
    def model_dtype_to_np(model_dtype):
        '''Function to set the model dtype'''
        if model_dtype == "BOOL":
            return np.bool
        if model_dtype == "FP16":
            return np.float16
        if model_dtype == "FP32":
            return np.float32
        if model_dtype == "FP64":
            return np.float64
        if model_dtype == "BYTES":
            return np.dtype(object)
        return None

    def request_generator(self, images, filenames, result_filenames):
        ''' Function to generate request for inference'''
        request = service_pb2.ModelInferRequest()
        request.model_name = cfg.TIS_MODEL_NAME
        request.model_version = cfg.TIS_MODEL_VERSION

        output = service_pb2.ModelInferRequest().InferRequestedOutputTensor()
        output.name = self.output_name
        request.outputs.extend([output])

        infer_input = service_pb2.ModelInferRequest().InferInputTensor()
        infer_input.name = self.input_name
        infer_input.datatype = self.dtype
        if self.format == mc.ModelInput.FORMAT_NHWC:
            infer_input.shape.extend([cfg.TIS_BATCH_SIZE, self.h, self.w, self.c])
        else:
            infer_input.shape.extend([cfg.TIS_BATCH_SIZE, self.c, self.h, self.w])

        image_idx = 0
        last_request = False

        while not last_request:
            input_bytes = None
            input_filenames = []
            request.ClearField("inputs")
            request.ClearField("raw_input_contents")
            for _ in range(cfg.TIS_BATCH_SIZE):
                input_filenames.append(filenames[image_idx])
                if input_bytes is None:
                    input_bytes = images[image_idx].astype(
                        self.npdtype).tobytes()
                else:
                    input_bytes += images[image_idx].astype(
                        self.npdtype).tobytes()

                image_idx = (image_idx + 1) % len(images)
                if image_idx == 0:
                    last_request = True
            request.inputs.extend([infer_input])
            result_filenames.append(input_filenames)
            request.raw_input_contents.extend([input_bytes])
            yield request

    def infer_async(self, input_request):
        """Main async inference method"""
        operation_start = time.time()
        requests = []
        responses = []
        result_filenames = []

        for request in self.request_generator(
            list(input_request.values()),
            list(input_request.keys()),
            result_filenames,
        ):
            requests.append(self.grpc_stub.ModelInfer.future(request))

        for request in requests:
            res = request.result()
            responses.append(
                (res.raw_output_contents[0], res.outputs[0].shape[0:3]))
        self._log_metrics(time.time() - operation_start)
        return responses, result_filenames
