#!/bin/sh

mkdir -p /image-output
chown -R nonroot:nonroot /image-output
exec runuser -u nonroot "$@"