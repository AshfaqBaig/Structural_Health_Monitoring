#!/bin/bash
clean_up () {
  rm -r .pytest_cache 2> /dev/null
  rm .coverage* 2> /dev/null
  rm coverage.xml 2> /dev/null
  rm test-result.xml 2> /dev/null
}

echo "Executing Component Tests..."
python -m pytest tests/component_tests
result=$?
if [ $result -ne 0 ]
then
  echo "Failed for Component-Test"
  clean_up
  exit $result
fi
echo "Executing Unit Tests..."
python -m pytest -vv tests/unit_tests --random-order --cov-report xml:coverage.xml --cov=app --junitxml=test-result.xml 
result=$?
if [ $result -ne 0 ]
then
  echo "Failed for Unit-Test"
  clean_up
  exit $result
fi
echo "Executing Pylint"
pylint --rcfile=.pylintrc app/ || pylint-exit --error-fail $?
clean_up

