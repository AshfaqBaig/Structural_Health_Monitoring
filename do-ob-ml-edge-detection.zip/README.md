# Introduction 

Initial implementation of DexiNed-TF2 is taken from commit f3b2d4bc1363dd41bd6265cc9cd0836f86825749 at https://github.com/xavysp/DexiNed distributed under MIT license.
