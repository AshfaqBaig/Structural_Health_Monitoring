from __future__ import absolute_import, division, print_function

import time, os
import numpy as np
from os.path import join
import cv2 as cv

#Original Model
#from model import *
#Reduced Model
from model_red_2 import *

from utls import (
    image_normalization,
    visualize_result,
    tensor2image,
    cv_imshow,
    h5_writer,
)
from dataset_manager import DataLoader

try:
    from azureml.core import Model as azmodel
except ImportError:
    AZML = False
else:
    AZML = True


BUFFER_SIZE = 448

# tf.set_random_seed(1)
class run_DexiNed:
    def __init__(self, args, run=None):
        self.args = args
        self.args.rgbn_mean = list(eval(self.args.rgbn_mean))
        self.model_state = args.model_state
        self.img_width = args.image_width
        self.img_height = args.image_height
        self.epochs = args.max_epochs
        self.bs = args.batch_size
        self.gpu = args.gpu
        

        gpus = tf.config.experimental.list_physical_devices("GPU")
        tf.config.set_visible_devices(gpus[self.gpu], "GPU")

        # AZML
        self.run = run
        if self.run:
            self.runId = run.get_details()["runId"]
            os.makedirs("./outputs", exist_ok=True)

    def train(self):
        checkpoint_dir = os.path.join(self.args.checkpoint_dir, "models", self.runId)

        summary_dir = os.path.join(self.args.checkpoint_dir, "logs", self.runId)
        train_log_dir = os.path.join(summary_dir, "train")
        val_log_dir = os.path.join(summary_dir, "val")

        os.makedirs(checkpoint_dir, exist_ok=True)
        os.makedirs(train_log_dir, exist_ok=True)
        os.makedirs(val_log_dir, exist_ok=True)

        os.system(
            "tensorboard --logdir {} --port 6000{} --bind_all &".format(
                summary_dir, self.gpu
            )
        )

        # Validation and Train dataset generation
        train_data = DataLoader(data_name=self.args.data4train, arg=self.args)
        n_train = train_data.indices.size  # data_cache["n_files"]
        val_data = DataLoader(
            data_name=self.args.data4train, arg=self.args, is_val=True
        )
        val_idcs = np.arange(val_data.indices.size)

        train_writer = tf.summary.create_file_writer(train_log_dir)
        val_writer = tf.summary.create_file_writer(val_log_dir)

        print("[INFO] dataset mean", self.args.rgbn_mean)
        my_model = DexiNed(rgb_mean=self.args.rgbn_mean)

        #Precision and Recall values for training dataset
        precision = metrics.Precision(thresholds=0.5)
        recall    = metrics.Recall(thresholds=0.5)

        #Precision and Recall values for validation dataset
        precision_val = metrics.Precision(thresholds=0.5)
        recall_val = metrics.Recall(thresholds=0.5)

        loss_bc = losses.BinaryCrossentropy(from_logits=False)

        # optimizer = optimizers.Adam(
        #     learning_rate=self.args.lr, beta_1=self.args.beta1
        # )

        iter = 0
        global_loss = 1000.0
        t_loss = []
        val_acc_save = 0
        Mlearning_rate=0.00001
        for epoch in range(self.args.max_epochs):
            # training
            t_loss = []
            Mlearning_rate=0.00001

            optimizer = optimizers.Adam(
                learning_rate=Mlearning_rate,
                beta_1=0.9,
                beta_2=0.999,
                epsilon=1e-08,
                amsgrad=False,
                name="Adam"
            )
            for step, (x, y) in enumerate(train_data):

                with tf.GradientTape() as tape:
                    pred = my_model(x, training=True)

                    preds, loss = pre_process_binary_cross_entropy(
                        loss_bc, pred, y, self.args, use_tf_loss=False
                    )

                predar=np.ravel(preds[-1])
                y_array=np.ravel(y)
                y_array[y_array > 0.5] = 1
                y_array[y_array <= 0.5] = 0

                precision.update_state(y_true=y_array, y_pred=predar)
                recall.update_state(y_true=y_array, y_pred=predar)

                gradients = tape.gradient(loss, my_model.trainable_variables)
                optimizer.apply_gradients(
                    zip(gradients, my_model.trainable_variables)
                )

                # logging the current precision and recall value so far.
                t_loss.append(loss.numpy())
                if step % 100 == 0:
                    print(
                        "Epoch:",
                        epoch,
                        "Step:",
                        step,
                        "Learning rate:",
                        Mlearning_rate,
                        "Loss: %.6f" % loss.numpy(),
                        "Precision: %.4f" % precision.result(),
                        "Recall: %.4f" % recall.result(),
                        time.ctime(),
                    )

                if step % 400 == 0:
                    # visualize preds
                    img_test = "Epoch: {0} Sample {1}/{2} Loss: {3}".format(
                        epoch,
                        step,
                        n_train // self.args.batch_size,
                        loss.numpy(),
                    )
                    vis_imgs = visualize_result(
                        x=x[2], y=y[2], p=preds, img_title=img_test
                    )
                    vis_imgs = np.reshape(
                        vis_imgs, (-1, vis_imgs.shape[0], vis_imgs.shape[1], 3)
                    )
                    with train_writer.as_default():
                        img_step = (
                            epoch * (n_train // self.args.batch_size) + step
                        )
                        tf.summary.image(
                            "Model Output",
                            vis_imgs[..., [2, 1, 0]],
                            step=img_step,
                        )

                if step % 500 == 0 and loss < global_loss:  # 500
                    if epoch == 0 and step == 0:
                        tmp_loss = np.array(t_loss)
                        with train_writer.as_default():
                            tf.summary.scalar("loss", tmp_loss.mean(), step=epoch)
                            tf.summary.scalar("precision", precision.result(), step=epoch)
                            tf.summary.scalar("recall", recall.result(), step=epoch)

                        # AZML
                        if self.run:
                            self.run.log("train_loss", tmp_loss.mean())
                            self.run.log("train_precision", precision.result().numpy())
                            self.run.log("train_recall", recall.result().numpy())

                    global_loss = loss

                iter += 1  # global iteration

            t_loss = np.array(t_loss)
            # train summary
            if epoch != 0:
                with train_writer.as_default():
                    tf.summary.scalar("loss", t_loss.mean(), step=epoch)
                    tf.summary.scalar("precision", precision.result(), step=epoch)
                    tf.summary.scalar("recall", recall.result(), step=epoch)

                # AZML
                if self.run:
                    self.run.log("train_loss", t_loss.mean())
                    self.run.log("train_precision", precision.result().numpy())
                    self.run.log("train_recall", recall.result().numpy())

            # validation
            t_val_loss = []
            for i, (x_val, y_val) in enumerate(val_data):

                pred_val = my_model(x_val)
                v_logits, V_loss = pre_process_binary_cross_entropy(
                    loss_bc, pred_val, y_val, self.args, use_tf_loss=False
                )

                predar=np.ravel(v_logits[-1])
                y_val=np.ravel(y_val)
                y_val[y_val > 0.5] = 1
                y_val[y_val <= 0.5] = 0

                precision_val.update_state(y_true=y_val, y_pred=predar)
                recall_val.update_state(y_true=y_val, y_pred=predar)

                t_val_loss.append(V_loss.numpy())
                #if i == 7:
                    #break

            val_precision = precision_val.result()
            val_recall = recall_val.result()
            t_val_loss = np.array(t_val_loss)
            print(
                "Epoch(validation):",
                epoch,
                "Val loss: ",
                t_val_loss.mean(),
                "Precision: ",
                val_precision.numpy(),
                "Recall: ",
                val_recall.numpy(),
            )
            # validation summary
            with val_writer.as_default():
                tf.summary.scalar("loss", t_val_loss.mean(), step=epoch)
                tf.summary.scalar("precision", val_precision.numpy(), step=epoch)
                tf.summary.scalar("recall", val_recall.numpy(), step=epoch)

            # AZML
            if self.run:
                self.run.log("val_loss", t_val_loss.mean())
                self.run.log("val_precision", val_precision.numpy())
                self.run.log("val_recall", val_recall.numpy())

            if val_acc.numpy() > val_acc_save:
                h5_path = os.path.join(checkpoint_dir, "DexiNedL_model.h5")
                Model.save_weights(my_model, h5_path, save_format="h5")

                # Tensorflow SavedModel for deployment.
                savedmodel_path = os.path.join(
                    checkpoint_dir, "DexiNedL_savedmodel"
                )
                save_model(my_model, savedmodel_path, save_format="tf")

                #val_acc_save = val_acc.numpy()

                print("Epoch:", epoch, "Model saved in Loss: ", t_loss.mean())

            # Reset metrics every epoch
            precision.reset_states()
            recall.reset_states()
            precision_val.reset_states()
            recall_val.reset_states()

        # AZML
        if self.run:
            self.run.upload_folder("./logs/train", train_log_dir)
            self.run.upload_folder("./logs/val", val_log_dir)

            self.run.upload_file("./outputs/models/dexined_h5", h5_path)
            self.run.register_model(
                model_name="dexined_h5",
                model_path="./outputs/models/dexined_h5",
                description="A fine-tuned dexined model.",
                tags={"type": "edge-detection"},
                model_framework=azmodel.Framework.TFKERAS,
                model_framework_version=tf.__version__,
            )

            self.run.upload_folder(
                "./outputs/models/dexined_savedmodel", savedmodel_path
            )
            self.run.register_model(
                model_name="dexined_savedmodel",
                model_path="./outputs/models/dexined_savedmodel",
                description="A fine-tuned dexined model.",
                tags={"type": "edge-detection"},
                model_framework=azmodel.Framework.TENSORFLOW,
                model_framework_version=tf.__version__,
            )

        my_model.summary()

    def test(self):
        # Test dataset generation

        test_data = DataLoader(data_name=self.args.data4test, arg=self.args)
        n_test = test_data.indices.size  # data_cache["n_files"]

        optimizer = tf.keras.optimizers.Adam(
            learning_rate=self.args.lr, beta_1=self.args.beta1
        )

        print("[INFO] dataset mean", self.args.rgbn_mean)
        my_model = DexiNed(rgb_mean=self.args.rgbn_mean)
        input_shape = test_data.input_shape
        my_model.build(input_shape=input_shape)  # rgb_mean=self.args.rgbn_mean

        checkpoit_dir = os.path.join(self.args.checkpoint_dir)  # ,
        # self.args.model_name + "2" + self.args.data4train)

        my_model.load_weights(
            os.path.join(checkpoit_dir, self.args.checkpoint)
        )

        result_dir = os.path.join(self.args.output_dir)  # ,
        # self.args.model_name + '-' + self.args.data4train + "2" + self.args.data4test)
        os.makedirs(result_dir, exist_ok=True)
        if self.args.scale is not None:
            scl = self.args.scale
            save_dir = [
                "fuse_" + str(scl),
                "avrg_" + str(scl),
                "h5_" + str(scl),
            ]
        else:
            save_dir = ["fuse", "avrg", "h5"]
        save_dirs = []
        for tmp_dir in save_dir:
            os.makedirs(os.path.join(result_dir, tmp_dir), exist_ok=True)
            save_dirs.append(os.path.join(result_dir, tmp_dir))

        total_time = []
        data_names = test_data.imgs_name
        data_shape = test_data.imgs_shape
        k = 0
        for step, (x, y) in enumerate(test_data):

            start_time = time.time()
            preds = my_model(x, training=False)
            tmp_time = time.time() - start_time
            total_time.append(tmp_time)

            preds = [tf.sigmoid(i).numpy() for i in preds]
            all_preds = np.array(preds)
            for i in range(all_preds.shape[1]):
                tmp_name = data_names[k]
                tmp_name, _ = os.path.splitext(tmp_name)
                tmp_shape = data_shape[k]
                # print("[DEBUG] data_shape -> h,w:", tmp_shape[0],tmp_shape[1])

                tmp_preds = all_preds[:, i, ...]
                tmp_av = np.expand_dims(tmp_preds.mean(axis=0), axis=0)
                tmp_preds = np.concatenate((tmp_preds, tmp_av), axis=0)
                res_preds = []
                for j in range(tmp_preds.shape[0]):
                    tmp_pred = tmp_preds[j, ...]
                    tmp_pred[tmp_pred < 0.0] = 0.0
                    tmp_pred = cv.bitwise_not(
                        np.uint8(image_normalization(tmp_pred))
                    )
                    h, w = tmp_pred.shape[:2]
                    # print("[DEBUG] pred_shape -> h,w:", h,w)
                    if h > tmp_shape[0] or w > tmp_shape[1]:
                        # tmp_pred = cv.resize(tmp_pred, (tmp_shape[1], tmp_shape[0]))
                        tmp_pred = tmp_pred[: tmp_shape[0], : tmp_shape[1]]
                    res_preds.append(tmp_pred)
                n_save = len(tmp_preds) - 2
                for idx in range(len(save_dirs) - 1):
                    s_dir = save_dirs[idx]
                    tmp = res_preds[n_save + idx]
                    cv.imwrite(join(s_dir, tmp_name + ".png"), tmp)
                print("saved:", join(s_dir, tmp_name + ".png"))
                #
                #h5_writer(
                #    path=join(save_dirs[-1], tmp_name + ".h5"),
                #    vars=np.squeeze(res_preds),
                #)
                # print("saved:", join(save_dirs[-1], tmp_name + '.h5'), tmp_preds.shape)
                k += 1

            # tmp_name = data_names[step][:-3]+"png"
            # tmp_shape = data_shape[step]
            # tmp_path = os.path.join(result_dir,tmp_name)
            # tensor2image(preds[-1].numpy(), img_path =tmp_path,img_shape=tmp_shape)

        total_time = np.array(total_time)

        print("-------------------------------------------------")
        print("End testing in: ", self.args.data4test)
        print("Batch size: ", self.args.test_bs)
        print("Time average per batch: ", total_time.mean(), "secs")
        print("Total time: ", total_time.sum(), "secs")
        print("-------------------------------------------------")
