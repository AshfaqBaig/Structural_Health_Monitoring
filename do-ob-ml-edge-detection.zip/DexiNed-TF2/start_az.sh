#!/bin/bash

###################################################################
# Setup Environment
###################################################################

WD=${PWD}

GPU=${1:-0}

sed "s|FILL_VOLUME|${HOME}:${HOME}|" environment/azureml_environment.template.json >environment/azureml_environment.json
sed -i "s|FILL_PORT|6000${GPU}:6000${GPU}|g" environment/azureml_environment.json

source ${HOME}/miniconda3/etc/profile.d/conda.sh

CONDA_ENV=$(conda env list | grep "azureml_" | awk '{print $1}')

if [ "${CONDA_ENV}" == "" ]; then
    echo "CREATING AZURE ML CONDA ENV"
    conda env create -f environment/conda_dependencies.yml
    CONDA_ENV=$(conda env list | grep "azureml_" | awk '{print $1}')
    conda activate ${CONDA_ENV}
else
    echo "CONDA AZURE ML ENV FOUND:"
    echo ${CONDA_ENV}
    conda activate ${CONDA_ENV}
fi

###################################################################
# Set Parameters
###################################################################

RUN_MODE="train"          # two modes "train" / "test"
RUN_ID="10268i_075e_24b_clahe_c5_b050_dca0d"
#RUN_ID="29693i_150e_08b_v2_aug"

# CONTINUE=False # not implemented in DexiNed code
# used either for inference in "test" mode or to continue training in "train" mode

MODEL_OUTP=${HOME}
MODEL_CKPT="DexiNed142_model.h5"

DATASET_NAME="dataset-edge_detection"
DATASET_VERSION="2.0.1"
DATASET_REPO="azure"
DATASET_BRANCH="clahe_c5_b050"

DATASET_BASE=${HOME}/data/${DATASET_NAME}
DATASET_PATH=${DATASET_BASE}/trainset

EPOCHS=75
BATCH_SIZE=24

IMAGE_HEIGTH=400
IMAGE_WIDTH=400

INCL_NEGATIVES=False
INCL_PARTIALS=False

###################################################################
# Download Data
###################################################################

echo "CHECKING OUT DATASET"

export AZURE_STORAGE_CONNECTION_STRING="DefaultEndpointsProtocol=https;AccountName=stdevdvlgenobawe01storml;AccountKey=h9/8TUO9SicgV/MTtQ9olifASkgaUPOxo93uxNji+1s5mjAQOXkLibTeVgOQv4TXzYrUthc2isJlSjI5dnS2kA==;BlobEndpoint=https://stdevdvlgenobawe01storml.blob.core.windows.net/;QueueEndpoint=https://stdevdvlgenobawe01storml.queue.core.windows.net/;TableEndpoint=https://stdevdvlgenobawe01storml.table.core.windows.net/;FileEndpoint=https://stdevdvlgenobawe01storml.file.core.windows.net/;"

if [ "${DATASET_REPO}" == "azure" ]; then
    #DATASET_REPO="git@ssh.dev.azure.com:v3/SGRE-IBM/BladeInspection/"${DATASET_NAME}
    DATASET_REPO="https://SGRE-IBM@dev.azure.com/SGRE-IBM/BladeInspection/_git/"${DATASET_NAME}
fi

if [ "${DATASET_BRANCH}" != "master" ]; then
    DATASET_OWNER=${MODEL_OWNER}
else
    DATASET_OWNER="git.master"
fi

if [[ -d ${DATASET_BASE} ]]; then
    cd ${DATASET_BASE}
    git fetch --all --tags
    if [ "${DATASET_BRANCH}" == "master" ]; then
        git checkout master
        git pull origin master
        git checkout v${DATASET_VERSION}
    else
        git checkout ${DATASET_BRANCH}
        git pull origin ${DATASET_BRANCH}
    fi
else
    cd ${HOME}/data
    git clone ${DATASET_REPO}
    cd ${DATASET_BASE}
    git config credential.helper store
    if [ "${DATASET_BRANCH}" == "master" ]; then
        git checkout v${DATASET_VERSION}
    else
        git checkout ${DATASET_BRANCH}
    fi
fi

echo "PULLING DVC FILES"
dvc pull -f
cd ${WD}

###################################################################
# Train/Test
###################################################################

echo "TRAIN FILES FOUND"
ls ${DATASET_PATH}/train/images | wc -l

echo "VALID FILES FOUND"
ls ${DATASET_PATH}/valid/images | wc -l

echo "CHECKING FOR DATASET MEAN"
if [[ -f ${DATASET_PATH}/train_mean.dat ]]; then
    echo "Dataset mean file found..."
    R=`cat ${DATASET_PATH}/train_mean.dat | awk '{print $1}'`
    G=`cat ${DATASET_PATH}/train_mean.dat | awk '{print $2}'`
    B=`cat ${DATASET_PATH}/train_mean.dat | awk '{print $3}'`
    N=`cat ${DATASET_PATH}/train_mean.dat | awk '{print $4}'`
else
    echo "No dataset mean file found..."
    R=103.939
    G=116.779
    B=123.68
    N=137.86
fi


# --continue_training=${CONTINUE} \ # not implemented
if [ ${RUN_MODE} == "train" ]; then
    python prepare_lists.py --dataset_path=${DATASET_PATH} --min_side_size=${IMAGE_HEIGTH} \
        --include_negative_tiles=${INCL_NEGATIVES} \
        --include_partial_tiles=${INCL_PARTIALS}

    python azml_run.py \
        --model_state=${RUN_MODE} \
        --checkpoint_dir=${MODEL_OUTP} \
        --train_dir=${DATASET_PATH} \
        --train_list=train_list.txt \
        --valid_list=valid_list.txt \
        --rgbn_mean=$R,$G,$B,$N \
        --max_epochs=${EPOCHS} \
        --batch_size=${BATCH_SIZE} \
        --image_height=${IMAGE_HEIGTH} \
        --image_width=${IMAGE_WIDTH} \
        --run_id=${RUN_ID} \
        --gpu=${GPU}
elif [ ${RUN_MODE} == "test" ]; then
    # validate on validation
    python prepare_lists.py --dataset_path=${DATASET_PATH} --min_side_size=${IMAGE_HEIGTH} \
        --include_negative_tiles=True \
        --include_partial_tiles=True

    python main.py \
        --model_state=${RUN_MODE} \
        --checkpoint_dir=${MODEL_OUTP} \
        --checkpoint=${MODEL_CKPT} \
        --test_dir=${DATASET_PATH} \
        --test_list=valid_list.txt \
	--rgbn_mean=$R,$G,$B,$N \
        --test_bs=${BATCH_SIZE} \
        --test_img_height=${IMAGE_HEIGTH} \
        --test_img_width=${IMAGE_WIDTH} \
        --output_dir=${MODEL_OUTP}/outputs

    python stitch_outputs.py \
        --input_tiles_dir=${MODEL_OUTP}/outputs/DexiNed-CUSTOM2CUSTOM/fuse \
        --output_images_dir=${MODEL_OUTP}/outputs/fuse_stitched

    rm train_list.txt
    mv valid_list.txt ${MODEL_OUTP}/metadata/valid_list_all_tiles.txt
fi
