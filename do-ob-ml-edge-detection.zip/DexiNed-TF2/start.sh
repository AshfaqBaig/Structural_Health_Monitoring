#!/bin/bash

WD=${PWD}
OWNER_SPACE=${HOME}

RUN_MODE="test" # two modes "train" / "test"
RUN_ID="34045i_150e_24b_clahe_c5_b100_r1f4_dc657"

# CONTINUE=False # not implemented in DexiNed code
# used either for inference in "test" mode or to continue training in "train" mode

MODEL_CKPT="DexiNedL_model.h5"
MODEL_OUTP=${OWNER_SPACE}/models/${RUN_ID}
chown -R `whoami` ${MODEL_OUTP}

DATASET_NAME="dataset-edge_detection"
DATASET_VERSION="2.0.1"
DATASET_REPO="azure"
DATASET_BRANCH="clahe_c5_b100_r1f4"

DATASET_BASE=${OWNER_SPACE}/data/${DATASET_NAME}
DATASET_PATH=${DATASET_BASE}/trainset

GPU=${1:-1}

EPOCHS=1
BATCH_SIZE=1

IMAGE_HEIGTH=400
IMAGE_WIDTH=400

INCL_NEGATIVES=False
INCL_PARTIALS=False

mkdir -p ${MODEL_OUTP}

#####################################################
echo "CHECKING OUT DATASET..."

export AZURE_STORAGE_CONNECTION_STRING="DefaultEndpointsProtocol=https;AccountName=stdevdvlgenobawe01storml;AccountKey=h9/8TUO9SicgV/MTtQ9olifASkgaUPOxo93uxNji+1s5mjAQOXkLibTeVgOQv4TXzYrUthc2isJlSjI5dnS2kA==;BlobEndpoint=https://stdevdvlgenobawe01storml.blob.core.windows.net/;QueueEndpoint=https://stdevdvlgenobawe01storml.queue.core.windows.net/;TableEndpoint=https://stdevdvlgenobawe01storml.table.core.windows.net/;FileEndpoint=https://stdevdvlgenobawe01storml.file.core.windows.net/;"

if [ "${DATASET_REPO}" == "azure" ];then
    #DATASET_REPO="git@ssh.dev.azure.com:v3/SGRE-IBM/BladeInspection/"${DATASET_NAME}
    DATASET_REPO="https://SGRE-IBM@dev.azure.com/SGRE-IBM/BladeInspection/_git/"${DATASET_NAME}
fi

if [ "${DATASET_BRANCH}" != "master" ];then
    DATASET_OWNER=${MODEL_OWNER}
else
    DATASET_OWNER="git.master"
fi


if [[ -d ${DATASET_BASE} ]];then
    cd ${DATASET_BASE}
    git fetch --all --tags
    if [ "${DATASET_BRANCH}" == "master" ];then
        git checkout master
	    git pull origin master
        git checkout v${DATASET_VERSION}
    else
        git checkout ${DATASET_BRANCH}
	    git pull origin ${DATASET_BRANCH}
    fi
else
    cd ${OWNER_SPACE}/data
    git clone ${DATASET_REPO}
    cd ${DATASET_BASE}
    if [ "${DATASET_BRANCH}" == "master" ];then
        git checkout v${DATASET_VERSION}
    else
        git checkout ${DATASET_BRANCH}
    fi
fi

echo "PULLING DVC FILES..."
dvc pull -f
cd ${WD}

#####################################################

echo "TRAIN FILES FOUND:"
ls ${DATASET_PATH}/train/images | wc -l

echo "VALID FILES FOUND:"
ls ${DATASET_PATH}/valid/images | wc -l

echo "CHECKING FOR DATASET MEAN"
if [[ -f ${DATASET_PATH}/train_mean.dat ]]; then
    echo "Dataset mean file found..."
    R=`cat ${DATASET_PATH}/train_mean.dat | awk '{print $1}'`
    G=`cat ${DATASET_PATH}/train_mean.dat | awk '{print $2}'`
    B=`cat ${DATASET_PATH}/train_mean.dat | awk '{print $3}'`
    N=`cat ${DATASET_PATH}/train_mean.dat | awk '{print $4}'`
else
    echo "No dataset mean file found..."
    R=103.939
    G=116.779
    B=123.68
    N=137.86
fi


# --continue_training=${CONTINUE} \ # not implemented
if [ ${RUN_MODE} == "train" ];then
    python prepare_lists.py --dataset_path=${DATASET_PATH} --min_side_size=${IMAGE_HEIGTH} \
                            --include_negative_tiles=${INCL_NEGATIVES} \
                            --include_partial_tiles=${INCL_PARTIALS}
    python main.py \
               --model_state=${RUN_MODE} \
               --checkpoint_dir=${MODEL_OUTP} \
               --train_dir=${DATASET_PATH} \
               --train_list=train_list.txt \
               --valid_list=valid_list.txt \
               --rgbn_mean=$R,$G,$B,$N \
               --max_epochs=${EPOCHS} \
               --batch_size=${BATCH_SIZE} \
               --image_height=${IMAGE_HEIGTH} \
               --image_width=${IMAGE_WIDTH} \
               --gpu=${GPU}

    mkdir -p ${MODEL_OUTP}/metadata
    mv train_list.txt ${MODEL_OUTP}/metadata/
    mv valid_list.txt ${MODEL_OUTP}/metadata/
    mv logs ${MODEL_OUTP}/
    mv results ${MODEL_OUTP}/

elif [ ${RUN_MODE} == "test" ];then
    # validate on validation
    python prepare_lists.py --dataset_path=${DATASET_PATH} --min_side_size=${IMAGE_HEIGTH} \
                            --include_negative_tiles=True \
                            --include_partial_tiles=True

    python main.py \
                --model_state=${RUN_MODE} \
                --checkpoint_dir=${MODEL_OUTP} \
                --checkpoint=${MODEL_CKPT} \
                --test_dir=${DATASET_PATH} \
                --test_list=valid_list.txt \
                --rgbn_mean=$R,$G,$B,$N \
                --test_img_height=${IMAGE_HEIGTH} \
                --test_img_width=${IMAGE_WIDTH} \
                --output_dir=${MODEL_OUTP}/results \
                --gpu=${GPU}

    python stitch_outputs.py \
                --input_tiles_dir=${MODEL_OUTP}/results/fuse \
                --output_images_dir=${MODEL_OUTP}/results/fuse_stitched

    rm train_list.txt
   # mv valid_list.txt ${MODEL_OUTP}/metadata/valid_list_all_tiles.txt

fi
