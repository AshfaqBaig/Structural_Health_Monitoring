import tensorflow as tf
from tensorflow.keras.models import save_model

from model import *

h5_fp = "./models/DexiNed23_model.h5"
rgbn_mean = [103.939, 116.779, 123.68, 137.86]
model = DexiNed(rgb_mean=rgbn_mean)
input_shape = (1, 400, 400, 3)
model.build(input_shape=input_shape)
model.load_weights(h5_fp)

model._set_inputs(tf.zeros(input_shape, dtype=tf.dtypes.float32))

saved_model_fp = "./models/DexiNed23_saved_model"
save_model(model, saved_model_fp, save_format="tf")
