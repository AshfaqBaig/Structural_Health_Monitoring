import azureml.core
from azureml.core import Environment
from azureml.core.workspace import Workspace

print("SDK version:", azureml.core.VERSION)

ws = Workspace.from_config()
print(ws.name, ws.resource_group, ws.location, ws.subscription_id, sep=", ")

env = Environment.get(workspace=ws, name="AzureML-TensorFlow-2.2-GPU")
env = env.clone("TensorFlow-2.2-GPU")
env.docker.enabled = True
env.docker.arguments = ["-v", "FILL_VOLUME", "-p", "FILL_PORT"]

env.save_to_directory("environment")
