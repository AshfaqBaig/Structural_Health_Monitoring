import os
import cv2
import numpy as np
import argparse

def get_files_set(data_dir):
    # reading filenames from the path
    files=[]
    for f in os.listdir(data_dir):
        if f.endswith(".png") or f.endswith(".jpg"):
            files.append(data_dir + "/" + f)
    return files

def get_negative_tiles(labels_path):
    label_files = get_files_set(labels_path)
    empty_labels = []
    for lf in label_files:
        img = cv2.imread(lf,0)
        if img.sum() == 0:
            empty_labels.append(lf)
    
    return empty_labels

def get_partial_tiles(labels_path, min_side_size):
    label_files = get_files_set(labels_path)
    partial_files = []
    for lf in label_files:
        img = cv2.imread(lf,0)
        s = img.shape
        if s[0] < min_side_size or s[1] < min_side_size:
            partial_files.append(lf)
    
    return partial_files

def generate_list(dataset_path, set_name, include_negative_tiles, include_partial_tiles, min_side_size):
    labels_path = dataset_path + '/' + set_name + '/' + 'labels'
    full_labels_list = get_files_set(labels_path)

    if not include_partial_tiles:
        partial_labels_list = get_partial_tiles(labels_path, min_side_size)
        #print(partial_labels_list)
        full_labels_list = list(set(full_labels_list) - set(partial_labels_list))

    if not include_negative_tiles:
        negative_labels_list = get_negative_tiles(labels_path)
        #print(negative_labels_list)
        full_labels_list = list(set(full_labels_list) - set(negative_labels_list))
    
    set_list_file = set_name + '_' + 'list.txt'
    print("[INFO] writing", set_list_file)
    with open(set_list_file, 'w') as f:
        for lf in full_labels_list:
            file_name = lf.split('/')[-1]
            f.write(set_name + '/images/' + file_name + ' ' + set_name + '/labels/' + file_name + '\n')


if __name__ == '__main__':
    
    parser = argparse.ArgumentParser(description='DexiNed aux functions.')
    parser.add_argument("--dataset_path", required=True,
                    help="path to the training dataset with train, valid and test directories each containing (images and labels).")
    parser.add_argument("--include_negative_tiles", type=str, required=True,
                    help="if to include tiles not containing edges")
    parser.add_argument("--include_partial_tiles", type=str, required=True,
                    help="if to include tiles smaller than default tile size")
    parser.add_argument("--min_side_size", type=int, required=True,
                    help="side size of the normal tile")
    args = vars(parser.parse_args())

    inc_par = args['include_partial_tiles'].strip()
    inc_neg = args['include_negative_tiles'].strip()

    #print(inc_neg, type(inc_neg))
    #print(inc_par, type(inc_par))

    if inc_par == 'True' or inc_par == 'False':
        inc_par = eval(inc_par)
    else:
        raise ValueError('Wrong parameter value for --include_partial_tiles')
    
    if inc_neg == 'True' or inc_neg == 'False':
        inc_neg = eval(inc_neg)
    else:
        raise ValueError('Wrong parameter value for --include_negative_tiles')

    #print(inc_neg, type(inc_neg))
    #print(inc_par, type(inc_par))

    generate_list(args['dataset_path'],
                  'train',
                  inc_neg,
                  inc_par,
                  args['min_side_size'])

    generate_list(args['dataset_path'],
                  'valid',
                  inc_neg,
                  inc_par,
                  args['min_side_size'])
    

