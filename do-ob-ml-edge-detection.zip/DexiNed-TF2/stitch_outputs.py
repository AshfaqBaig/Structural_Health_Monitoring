
import os
import cv2
import numpy as np
import argparse

def get_files_set(data_dir):
    # reading filenames from the path
    files=[]
    for f in os.listdir(data_dir):
        if f.endswith(".png") or f.endswith(".jpg"):
            files.append(data_dir + "/" + f)
    return files

def stitch_image(image_files, shape, outimg):
    img = np.zeros(shape)
    #files = get_files_set(input_dir)
    for f in image_files:
        x_y_w_h = f.split('/')[-1].split('.')[0]
        #print(x_y_w_h)
        x = int(x_y_w_h.split('_')[2])
        y = int(x_y_w_h.split('_')[3])
        w = int(x_y_w_h.split('_')[4])
        h = int(x_y_w_h.split('_')[5])
        sub = cv2.imread(f)
        #border = 4
        #dst = cv2.copyMakeBorder(sub[border:-border,border:-border], border, border, border, border, cv2.BORDER_CONSTANT, (0,0,0))
        
        if y + h >= shape[0] and y < shape[0]:
            h = shape[0] - y
        elif y >= shape[0]:
            h = 0
        if x + w >= shape[1] and x < shape[1]:
            w = shape[1] - x
        elif x >= shape[1]:
            w = 0
        
        img[y:y + h, x:x + w] = sub[:h, :w]
    
    cv2.imwrite(outimg, (255-img))


# TODO provide a map camera_id: resolution
def stitch_all_images(input_dir, output_dir):
    files = get_files_set(input_dir)
    uniq_names = set([f.split('/')[-1].split('.')[0].split('_')[1] for f in files])
    #print(uniq_names)
    for name in uniq_names:
        image_name = 'DEV_' + name + '.jpg'
        print("[INFO] processing image", image_name)
        image_files = [f for f in files if name in f]
        cam_mac = name.split('-')[0]
        if cam_mac == '000F310380BE':
            shape = (2300, 6480, 3)
        elif cam_mac == '000F310380BD':
            shape = (3512, 6480, 3)
        else:
            shape = (4860, 6480, 3)
        stitch_image(image_files, shape, os.path.join(output_dir, image_name))


if __name__ == '__main__':
    
    parser = argparse.ArgumentParser(description='DexiNed postprocessing. Stitch outputs.')
    parser.add_argument('-i', '--input_tiles_dir', type=str, help='input dir path containing DexiNed outputs')
    parser.add_argument('-o', '--output_images_dir', type=str, help='output directory for stiched outputs')
    args = vars(parser.parse_args())
    
    if not os.path.exists(args['output_images_dir']):
        os.makedirs(args['output_images_dir'], exist_ok=True)
    
    stitch_all_images(input_dir=args['input_tiles_dir'], output_dir=args['output_images_dir'])