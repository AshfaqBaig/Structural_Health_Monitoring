import argparse
import uuid

import azureml.core
from azureml.core import Environment, Experiment, ScriptRunConfig
from azureml.core.workspace import Workspace

parser = argparse.ArgumentParser(
    description="Edge detection parameters for feeding the model"
)
parser.add_argument(
    "--model_state", default="test", choices=["train", "test", "export"]
)
parser.add_argument(
    "--checkpoint_dir",
    default="checkpoints",
    help="directory with checkpoint to resume training from or use for testing",
)
parser.add_argument(
    "--train_dir",
    default="train_list.txt",
    help="path to folder containing images",
)
parser.add_argument("--train_list", default="valid_list.txt", type=str)
parser.add_argument("--valid_list", default=None, type=str)
parser.add_argument(
    "--max_epochs", type=int, default=24, help="number of training epochs"
)
parser.add_argument(
    "--batch_size", type=int, default=8, help="number of images in batch"
)
parser.add_argument(
    "--image_height",
    type=int,
    default=400,
    help="scale images to this size before cropping to 256x256",
)
parser.add_argument(
    "--image_width",
    type=int,
    default=400,
    help="scale images to this size before cropping to 256x256",
)
parser.add_argument("--rgbn_mean", type=str, default="103.939,116.779,123.68,137.86", help="pixels mean")
parser.add_argument("--gpu", type=int, default=0, help="GPU index")
parser.add_argument("--run_id", type=str, default="", help="Run ID")

args = vars(parser.parse_args())
run_id = args.pop("run_id", None)
args = {"--" + str(key): val for key, val in args.items()}
args = [item for k in args for item in (k, args[k])]

print("SDK version:", azureml.core.VERSION)

ws = Workspace.from_config()
print(ws.name, ws.resource_group, ws.location, ws.subscription_id, sep=", ")

env = Environment.load_from_directory("environment")

exp_name = "dexined-edge-detection"
exp = Experiment(workspace=ws, name=exp_name)

src = ScriptRunConfig(
    source_directory=".",
    script="main.py",
    arguments=args,
    compute_target="local",
    environment=env,
)

if run_id:
    run_id = "_".join([run_id, uuid.uuid4().hex[:5]])
    run = exp.submit(config=src, run_id=run_id)
else:
    run = exp.submit(config=src)

run.wait_for_completion(show_output=True)
