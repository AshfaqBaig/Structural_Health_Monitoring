from __future__ import absolute_import, division, print_function

import time, os
import numpy as np
from os.path import join
import cv2 as cv

from model import *
from utls import image_normalization,visualize_result, tensor2image, cv_imshow,h5_writer
from dataset_manager import DataLoader

from azureml.core import Model as azmodel

BUFFER_SIZE = 448

# tf.set_random_seed(1)
class run_DexiNed():
^^
    def __init__(self, args, run=None):
        self.args = args
        self.model_state= args.model_state
        self.img_width=args.image_width
        self.img_height = args.image_height
        self.epochs = args.max_epochs
        self.bs = args.batch_size

        # AZML
        self.run = run
        if self.run:
            os.makedirs("./outputs", exist_ok=True)
            os.makedirs("./models", exist_ok=True)

    def train(self):
        # Validation and Train dataset generation
        train_data = DataLoader(data_name=self.args.data4train, arg=self.args)
        n_train =train_data.indices.size #data_cache["n_files"]
        val_data = DataLoader(data_name=self.args.data4train,
                              arg=self.args, is_val=True)
        val_idcs = np.arange(val_data.indices.size)

        # Summary and checkpoint manager
        model_dir =self.args.model_name+'2'+self.args.data4train
        summary_dir = os.path.join('logs',model_dir)
        train_log_dir=os.path.join(summary_dir,'train')
        val_log_dir =os.path.join(summary_dir,'test')

        checkpoint_dir = os.path.join(self.args.checkpoint_dir, model_dir)
        os.makedirs(checkpoint_dir, exist_ok=True)

        epoch_ckpt_dir = checkpoint_dir + 'epochs'
        os.makedirs(epoch_ckpt_dir, exist_ok=True)

        os.makedirs(train_log_dir,exist_ok=True)
        os.makedirs(val_log_dir,exist_ok=True)

        train_writer = tf.summary.create_file_writer(train_log_dir)
        val_writer = tf.summary.create_file_writer(val_log_dir)

        mirrored_strategy = tf.distribute.MirroredStrategy()
        print('Number of devices: {}'.format(mirrored_strategy.num_replicas_in_sync))
        BUFFER_SIZE = len(train_images)
        BATCH_SIZE_PER_REPLICA = 64
        GLOBAL_BATCH_SIZE = BATCH_SIZE_PER_REPLICA * strategy.num_replicas_in_sync
        train_dataset = tf.data.Dataset.from_generator(train_data, (tf.float32, tf.float32))

        with mirrored_strategy.scope():



        my_model = DexiNed(rgb_mean=self.args.rgbn_mean)

        # accuracy = metrics.SparseCategoricalAccuracy()
        accuracy = metrics.BinaryAccuracy()
        accuracy_val = metrics.BinaryAccuracy()
        loss_bc = losses.BinaryCrossentropy(from_logits=True, reduction=losses.Reduction.NONE)

        optimizer = optimizers.Adam(
            learning_rate=self.args.lr, beta_1=self.args.beta1)
        iter = 0

        global_loss = 1000.
        t_loss = []
        val_acc_save = 0

        cv_vid = None

        for epoch in range(self.args.max_epochs):
            # training
            t_loss = []
            for step, (x, y) in enumerate(train_data):

                with tf.GradientTape() as tape:
                    pred = my_model(x, training=True)

                    preds, loss = pre_process_binary_cross_entropy(
                        loss_bc, pred, y, self.args, use_tf_loss=False)

                accuracy.update_state(y_true=y, y_pred=preds[-1])
                gradients = tape.gradient(loss, my_model.trainable_variables)
                optimizer.apply_gradients(zip(gradients, my_model.trainable_variables))

                # logging the current accuracy value so far.
                t_loss.append(loss.numpy())
                if step % 10 == 0:
                    print("Epoch:", epoch, "Step:", step, "Loss: %.4f" % loss.numpy(),
                          "Accuracy: %.4f" % accuracy.result(), time.ctime())

                if step % 10 == 0:
                    # visualize preds
                    img_test = 'Epoch: {0} Sample {1}/{2} Loss: {3}' \
                        .format(epoch, step, n_train // self.args.batch_size, loss.numpy())
                    vis_imgs = visualize_result(
                        x=x[2], y=y[2], p=preds, img_title=img_test)

                    if cv_vid:
                        cv_vid.write(vis_imgs)
                    else:
                        vid_size = (vis_imgs.shape[0], vis_imgs.shape[1])
                        cv_vid = cv.VideoWriter('./outputs/viz.avi', cv.VideoWriter_fourcc(*'DIVX'), 15, vid_size)

                if step % 500 == 0 and loss < global_loss:  # 500
                    if epoch==0 and step==0:
                        tmp_loss = np.array(t_loss)
                        with train_writer.as_default():
                            tf.summary.scalar('loss', tmp_loss.mean(), step=epoch)
                            tf.summary.scalar('accuracy', accuracy.result(), step=epoch)

                        # AZML
                        if self.run:
                            self.run.log('train_loss', tmp_loss.mean())
                            self.run.log('train_acc', accuracy.result().numpy())

                    global_loss = loss

                iter += 1  # global iteration

            t_loss = np.array(t_loss)
            # train summary
            if epoch!=0:
                with train_writer.as_default():
                    tf.summary.scalar('loss', t_loss.mean(), step=epoch)
                    tf.summary.scalar('accuracy', accuracy.result(), step=epoch)

                # AZML
                if self.run:
                    self.run.log('train_loss', t_loss.mean())
                    self.run.log('train_acc', accuracy.result().numpy())

            # validation
            t_val_loss = []
            for i, (x_val, y_val) in enumerate(val_data):

                pred_val = my_model(x_val)
                v_logits, V_loss = pre_process_binary_cross_entropy(
                    loss_bc, pred_val, y_val, self.args, use_tf_loss=False)
                accuracy_val.update_state(y_true=y_val, y_pred=v_logits[-1])
                t_val_loss.append(V_loss.numpy())
                if i == 7:
                    break
            val_acc = accuracy_val.result()
            t_val_loss = np.array(t_val_loss)
            print("Epoch(validation):", epoch, "Val loss: ", t_val_loss.mean(),
                  "Accuracy: ", val_acc.numpy())
            # validation summary
            with val_writer.as_default():
                tf.summary.scalar('loss', t_val_loss.mean(), step=epoch)
                tf.summary.scalar('accuracy', val_acc.numpy(), step=epoch)

            # AZML
            if self.run:
                self.run.log('val_loss', t_val_loss.mean())
                self.run.log('val_acc', val_acc.numpy())

            if val_acc.numpy() > val_acc_save:
                save_ckpt_path = os.path.join('./models', "DexiNedL_model.h5")
                Model.save_weights(my_model, save_ckpt_path, save_format='h5')

                # Tensorflow SavedModel for deployment.
                savedmodel_path = os.path.join('./models', "DexiNedL_savedmodel")
                save_model(my_model, savedmodel_path, save_format='tf')

                val_acc_save = val_acc.numpy()

                print("Epoch:", epoch, "Model saved in Loss: ", t_loss.mean())

            # Reset metrics every epoch
            accuracy.reset_states()
            accuracy_val.reset_states()

        cv_vid.release()

        # AZML
        if self.run:
            self.run.upload_file(save_ckpt_path, save_ckpt_path)
            self.run.register_model(
                model_name="dexined_h5",
                model_path=save_ckpt_path,
                description="A fine-tuned dexined model.",
                tags={"type": "edge-detection"},
                model_framework=azmodel.Framework.TFKERAS,
                model_framework_version=tf.__version__,
            )

            self.run.upload_folder(savedmodel_path, savedmodel_path)
            self.run.register_model(
                model_name="dexined_savedmodel",
                model_path=savedmodel_path,
                description="A fine-tuned dexined model.",
                tags={"type": "edge-detection"},
                model_framework=azmodel.Framework.TENSORFLOW,
                model_framework_version=tf.__version__,
            )

        my_model.summary()


    def test(self):
        # Test dataset generation

        test_data = DataLoader(data_name=self.args.data4test, arg=self.args)
        n_test = test_data.indices.size  # data_cache["n_files"]

        optimizer = tf.keras.optimizers.Adam(
            learning_rate=self.args.lr, beta_1=self.args.beta1)

        my_model = DexiNed(rgb_mean=self.args.rgbn_mean)
        input_shape = test_data.input_shape
        my_model.build(input_shape=input_shape)  # rgb_mean=self.args.rgbn_mean

        checkpoit_dir = os.path.join(self.args.checkpoint_dir,
                                     self.args.model_name + "2" + self.args.data4train)

        my_model.load_weights(os.path.join(checkpoit_dir, self.args.checkpoint))

        result_dir = os.path.join(
            self.args.output_dir,
            self.args.model_name + '-' + self.args.data4train + "2" + self.args.data4test)
        os.makedirs(result_dir, exist_ok=True)
        if self.args.scale is not None:
            scl = self.args.scale
            save_dir = ['fuse_'+str(scl), 'avrg_'+str(scl), 'h5_'+str(scl)]
        else:
            save_dir = ['fuse', 'avrg', 'h5']
        save_dirs = []
        for tmp_dir in save_dir:
            os.makedirs(os.path.join(result_dir, tmp_dir), exist_ok=True)
            save_dirs.append(os.path.join(result_dir, tmp_dir))

        total_time = []
        data_names = test_data.imgs_name
        data_shape = test_data.imgs_shape
        k = 0
        for step, (x, y) in enumerate(test_data):

            start_time = time.time()
            preds = my_model(x, training=False)
            tmp_time = time.time() - start_time
            total_time.append(tmp_time)

            preds = [tf.sigmoid(i).numpy() for i in preds]
            all_preds = np.array(preds)
            for i in range(all_preds.shape[1]):
                tmp_name = data_names[k]
                tmp_name, _ = os.path.splitext(tmp_name)
                tmp_shape = data_shape[k]
                #print("[DEBUG] data_shape -> h,w:", tmp_shape[0],tmp_shape[1])

                tmp_preds = all_preds[:, i, ...]
                tmp_av = np.expand_dims(tmp_preds.mean(axis=0), axis=0)
                tmp_preds = np.concatenate((tmp_preds, tmp_av), axis=0)
                res_preds = []
                for j in range(tmp_preds.shape[0]):
                    tmp_pred = tmp_preds[j, ...]
                    tmp_pred[tmp_pred < 0.0] = 0.0
                    tmp_pred = cv.bitwise_not(np.uint8(image_normalization(tmp_pred)))
                    h, w = tmp_pred.shape[:2]
                    #print("[DEBUG] pred_shape -> h,w:", h,w)
                    if h > tmp_shape[0] or w > tmp_shape[1]:
                        # tmp_pred = cv.resize(tmp_pred, (tmp_shape[1], tmp_shape[0]))
                        tmp_pred = tmp_pred[:tmp_shape[0],:tmp_shape[1]]
                    res_preds.append(tmp_pred)
                n_save =len(tmp_preds)-2
                for idx in range(len(save_dirs) - 1):
                    s_dir = save_dirs[idx]
                    tmp = res_preds[n_save + idx]
                    cv.imwrite(join(s_dir, tmp_name + '.png'), tmp)
                print("saved:", join(s_dir, tmp_name + '.png'))
                h5_writer(path=join(save_dirs[-1], tmp_name + '.h5'),
                          vars=np.squeeze(res_preds))
                #print("saved:", join(save_dirs[-1], tmp_name + '.h5'), tmp_preds.shape)
                k += 1

            # tmp_name = data_names[step][:-3]+"png"
            # tmp_shape = data_shape[step]
            # tmp_path = os.path.join(result_dir,tmp_name)
            # tensor2image(preds[-1].numpy(), img_path =tmp_path,img_shape=tmp_shape)

        total_time = np.array(total_time)

        print('-------------------------------------------------')
        print("End testing in: ", self.args.data4test)
        print("Batch size: ", self.args.test_bs)
        print("Time average per batch: ", total_time.mean(), "secs")
        print("Total time: ", total_time.sum(), "secs")
        print('-------------------------------------------------')
