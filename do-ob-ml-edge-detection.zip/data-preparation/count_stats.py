import os
import cv2
import numpy as np
import argparse

def get_file_set(path, file_type='jpg'):
    '''
    param path: path to files
    read filenames from the path
    '''

    files=[]
    for f in os.listdir(path):
        if f.endswith("." + file_type):
            files.append(path + "/" + f)
    
    return np.array(files)


def count_stats(data_dir, image_size):
    files = get_file_set(data_dir)
    i = 0
    j = 0
    k = 0
    for f in files:
        i += 1
        if i%1000 == 0:
            print("[INFO] checked", i, "files...")
        img = cv2.imread(f)
        if img.sum() > 0:
            j += 1
            if img.shape[0] == image_size and img.shape[1] == image_size:
                k += 1
    
    print("[INFO] checked", i, "files")
    print("[INFO]", j, "found to contain labeled data")
    print("[INFO]", k, "found to be of expected size.")

    with open(os.path.abspath(data_dir + '../../train_stats.txt'),'w') as F:
        F.write("Full size non-empty:" + str(k) + '\n')
        F.write("Generally non-empty:" + str(j) + '\n')
        F.write("Total images number:" + str(i) + '\n')


if __name__ == "__main__":
	# construct the argument parse and parse the arguments
    parser = argparse.ArgumentParser()

    parser.add_argument("-i", "--input_path", required=True,
                    help="input labels path.")
    parser.add_argument("-s", "--image_size", required=True, type=int,
                    help="input labels expected size.")
    
    args = vars(parser.parse_args())

    count_stats(args['input_path'], args['image_size'])

