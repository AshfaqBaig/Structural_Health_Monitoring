#!/bin/bash

RAWDATA_DIR=${1:-/mnt/azure/raw-data/key-frames}
CVAT_LABELS=${2:-cvat_labels_02}
DATASET_DIR=${3:-${HOME}/data/dataset-handover}

IMAGES_SIZE=${4:-400}
TILING_STEP=${5:-400}

# TODO: implement steps as if else
#PREP_STEPS=${6:-'EXTRACT, CONVERT, SPLIT, CLAHE, TILE, AUGMENT'}

echo "#######################################################################"
echo "### DATASET PREPARATION PIPELINE ######################################"
echo "#######################################################################"
echo -e "\n"

echo "EXCTRACTING LABELED IMAGES..."
mkdir -p ${DATASET_DIR}/fullsize/images
python extract_images.py --cvat_xml_labels_path=${RAWDATA_DIR}/${CVAT_LABELS}\
                         --fullsize_images_path=${DATASET_DIR}/fullsize/images
echo -e "\n"

echo "CONVERTING CVAT LABELS TO MASKS..."
mkdir -p ${DATASET_DIR}/fullsize/labels
python convert_labels.py --cvat_xml_labels_path=${RAWDATA_DIR}/${CVAT_LABELS}\
                         --fullsize_labels_path=${DATASET_DIR}/fullsize/labels
echo -e "\n"

echo "SPLITTING DATASET INTO TRAINING, VALIDATION AND TEST SETS..."
mkdir -p ${DATASET_DIR}/splitset
python split_dataset.py  --input_path=${DATASET_DIR}/fullsize \
                         --output_path=${DATASET_DIR}/splitset \
                         --train_fraction=0.8 \
                         --keep_input=True
echo -e "\n"

echo "APPLYING CLAHE..."
python equalize_dataset.py --input_path=${DATASET_DIR}/splitset \
                           --output_path=${DATASET_DIR}/claheset \
                           --clahe_params=5,50
cp -r ${DATASET_DIR}/splitset/train/labels ${DATASET_DIR}/claheset/train/labels
cp -r ${DATASET_DIR}/splitset/valid/labels ${DATASET_DIR}/claheset/valid/labels
echo -e "\n"

echo "TILING TRAINING AND VALIDATION IMAGES..."
mkdir -p ${DATASET_DIR}/tiledset
python tile_dataset.py   --input_path=${DATASET_DIR}/claheset \
                         --output_path=${DATASET_DIR}/tiledset \
                         --image_width=${IMAGES_SIZE} \
                         --image_height=${IMAGES_SIZE} \
                        --step_size=${TILING_STEP}
rm -rf ${DATASET_DIR}/claheset
echo -e "\n"

echo "AUGMENTING TRAINING IMAGES..."
mkdir -p ${DATASET_DIR}/trainset
rm -rf ${DATASET_DIR}/trainset/*
python augment_dataset.py --input_path=${DATASET_DIR}/tiledset/train \
                          --output_path=${DATASET_DIR}/trainset/train \
                          --augmentation_factor=4 \
                          --lower_augmentation_factor=1

cp -r ${DATASET_DIR}/tiledset/* ${DATASET_DIR}/trainset/
rm -rf ${DATASET_DIR}/tiledset
echo -e "\n"

echo "CALCULATING DATASET MEAN..."
python dataset_mean.py --input_path=${DATASET_DIR}/trainset/train/images \
                       --output_path=${DATASET_DIR}/trainset/
echo -e "\n"

echo "COUNTING TRAIN DATA STATS..."
python count_stats.py --input_path=${DATASET_DIR}/trainset/train/labels \
                      --image_size=${IMAGES_SIZE}
echo -e "\n"

echo "#######################################################################"
echo "### DATA PREPARATION IS DONE.##########################################"
echo "#######################################################################"