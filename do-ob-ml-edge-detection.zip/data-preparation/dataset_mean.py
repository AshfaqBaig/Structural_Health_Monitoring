import os
import argparse
import shutil
import numpy as np
import cv2

def get_file_set(path, file_type='jpg'):
    '''
    param path: path to files
    read filenames from the path
    '''

    files=[]
    for f in os.listdir(path):
        if f.endswith("." + file_type):
            files.append(path + "/" + f)
    
    return np.array(files)


def get_mean_for_datset_channels(data_dir):
    files = get_file_set(data_dir)
    img_sum = np.zeros(4,)
    pix_cnt = 0
    i = 0
    for f in files:
        i += 1
        if i%1000 == 0:
            print("[INFO] summed", i, "files...")
        img_bgr =  cv2.imread(f)
        img_rgb =  cv2.cvtColor(img_bgr, cv2.COLOR_BGR2RGB)
        img_sum += cv2.sumElems(img_rgb)
        pix_cnt += img_rgb.shape[0]*img_rgb.shape[1]
    
    print("[INFO] calculated mean for", i, "files.")

    return img_sum/pix_cnt


if __name__ == "__main__":
	# construct the argument parse and parse the arguments
    parser = argparse.ArgumentParser()

    parser.add_argument("-i", "--input_path", required=True,
                    help="path to input dataset")
    parser.add_argument("-o", "--output_path", required=True,
                    help="path to output mean file")
    
    args = vars(parser.parse_args())

    data_mean = get_mean_for_datset_channels(args['input_path'])

    np.savetxt(args['output_path']+'/train_mean.dat', data_mean.reshape((1,4)), fmt="%s", delimiter=" ")
