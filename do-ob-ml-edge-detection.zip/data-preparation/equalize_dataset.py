import os
import cv2
import numpy as np
import argparse

def get_files_set(data_dir):
    # reading filenames from the path
    files=[]
    for f in os.listdir(data_dir):
        if f.endswith(".png") or f.endswith(".jpg") or f.endswith(".jpeg"):
            files.append(data_dir + "/" + f)
    return files

def equalize_clahe(input_file, output_file, clip_limit, grid_bins):
    bgr = cv2.imread(input_file)
    lab = cv2.cvtColor(bgr, cv2.COLOR_BGR2LAB)
    
    clahe = cv2.createCLAHE(clipLimit=clip_limit, tileGridSize=(grid_bins,grid_bins))  # images_clahe_cl5_100x100
    
    lab[...,0] = clahe.apply(lab[...,0])
    bgr = cv2.cvtColor(lab, cv2.COLOR_LAB2BGR)
    cv2.imwrite(output_file, bgr)


def equalize_dataset(input_path, output_path, clip_limit, grid_bins):
    if not os.path.exists(output_path):
        os.makedirs(output_path, exist_ok=True)
    
    files = get_files_set(input_path)
    for f in files:
        print("[INFO] equalizing", f)
        fname = f.split('/')[-1]
        equalize_clahe(f, os.path.join(output_path,fname), clip_limit, grid_bins)
    
if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("-i", "--input_path", required=True, help="Input path for data to augment.")
    ap.add_argument("-o", "--output_path", required=True, help="Output path for augmented data.")
    ap.add_argument("-c", "--clahe_params", type=str, required=True, help="Comma separated CLAHE parameters for clip limit and number of bins")
    args = vars(ap.parse_args())

    clip_limit, grid_bins = args['clahe_params'].split(',')
    clip_limit = float(clip_limit)
    grid_bins = int(grid_bins)

    equalize_dataset(os.path.join(args['input_path'], 'train', 'images'),
                     os.path.join(args['output_path'], 'train', 'images'),
                     clip_limit, grid_bins)

    equalize_dataset(os.path.join(args['input_path'], 'valid', 'images'),
                     os.path.join(args['output_path'], 'valid', 'images'),
                     clip_limit, grid_bins)
