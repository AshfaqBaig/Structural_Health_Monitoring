import random
import os
from glob import glob
# import ntpath
# from matplotlib import pyplot as plt
import cv2
import numpy as np
import albumentations as A
import argparse

def transform(img_name, image, mask, augmentation_factor, output_path):
    for i in range(augmentation_factor):
        aug = A.ReplayCompose([
            A.HorizontalFlip(p=0.5),
            #A.VerticalFlip(p=0.5),              
            A.RandomRotate90(p=0.5),
            #A.RandomBrightness(limit=0.5, p=0.5),
            A.RandomContrast(p=0.5),
            A.RandomGamma(p=0.5),
            A.RGBShift(p=0.5),
            A.ChannelShuffle(p=0.5),
            A.ShiftScaleRotate(p=0.5)
        ])
        # random.seed(20)
        augmented = aug(image=image, mask=mask)
        image_aug = augmented['image']
        mask_aug = augmented['mask']
        applied_params = augmented['replay']
        aug_name = img_name + '_'
        for aug in applied_params.get('transforms'):
            trans_class = aug.get('__class_fullname__').split('.')[-1]
            if aug.get('applied'):
                aug_name = aug_name + '_' + trans_class
        aug_name = aug_name + '.jpg'
        cv2.imwrite(os.path.join(output_path, 'images', aug_name), image_aug)
        cv2.imwrite(os.path.join(output_path, 'labels', aug_name), mask_aug)

def root_check(img_name, lower_factor_cams):
    cam_name = img_name.split('-')[0]
    cam_name = cam_name.split('_')[1]
    return True if cam_name in lower_factor_cams else False

if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("-i", "--input_path", required=True, help="Input path for data to augment.")
    ap.add_argument("-o", "--output_path", required=True, help="Output path for augmented data.")
    ap.add_argument("-f", "--augmentation_factor", type=int, required=True, help="Factor of augmentation.")
    ap.add_argument("-l", "--lower_augmentation_factor", type=int, help="Factor for cameras we want to augment less than the rest.")
    args = vars(ap.parse_args())
    input_path = os.path.abspath(args.get("input_path"))
    output_path = os.path.abspath(args.get("output_path"))
    augmentation_factor = args.get("augmentation_factor")
    label_threshold = args.get("label_threshold")
    root_aug_factor = args.get("lower_augmentation_factor", None)
    if not os.path.exists(os.path.join(output_path, 'images')): os.makedirs(os.path.join(output_path, 'images'), exist_ok=True)
    if not os.path.exists(os.path.join(output_path, 'labels')): os.makedirs(os.path.join(output_path, 'labels'), exist_ok=True)
    #TODO: EDIT CAMERA NAMES HERE
    LOWER_FACTOR_CAMS = [
        # list of cameras to augment with smaller factor
        #'000F310380C2', # Camera 10 # Root Cam07 as of Spec
        #'000F310380BC', # Camera 13 # Root Cam08 as of Spec
        #'000F310380C3', # Root Cam06 as of Spec
        #'000F310380C0', # Root Cam09 as of Spec
        #'000F310380C4', # Root Cam10
    ]
    
    image_files_list = [os.path.basename(p) for p in glob(f"{os.path.join(input_path, 'images')}/*.jpg")]
    print(len(image_files_list), "files found")

    i = 0
    for file_name in image_files_list:
        image = cv2.imread(os.path.join(input_path, 'images', file_name))
        mask = cv2.imread(os.path.join(input_path, 'labels', file_name))
        
        if image is None:
            print("Non-readable file", os.path.join(input_path, 'images', file_name))

        if mask is None:
            print("Non-readable file", os.path.join(input_path, 'labels', file_name))
        
        img_name = file_name.split('.')[0]

        if np.sum(mask) > 0:
            i+=1
            if root_aug_factor is not None and root_check(img_name, LOWER_FACTOR_CAMS):
                transform(img_name, image, mask, root_aug_factor, output_path)
            else:
                transform(img_name, image, mask, augmentation_factor, output_path)
            
            if i%1000 == 0:
                print("[INFO] augmented", i, "files")
    
    print("[INFO]", i, "files were augmented.")

