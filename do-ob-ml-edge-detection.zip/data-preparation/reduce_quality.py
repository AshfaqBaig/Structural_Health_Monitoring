import os
import argparse
import shutil
import numpy as np
import cv2


def get_file_set(path, file_type='jpg'):
    '''
    param path: path to files
    read filenames from the path
    '''

    files=[]
    for f in os.listdir(path):
        if f.endswith("." + file_type):
            files.append(path + "/" + f)
    
    return np.array(files)

def down_and_upscale(input_path, output_path):
    
    files = get_file_set(input_path)
    for f in files:
        image_name = f.split('/')[-1]
        
        # exclude 35mm cameras
        if not '000F310380BF' in image_name and not '000F310380BE' in image_name:
            print("[INFO] reducing quality for image", image_name)
            img_real_c1 = cv2.imread(f)
            img_reduced_c1 = cv2.resize(img_real_c1, (0,0), fx=0.5, fy=0.5)
            img_back_c1 = cv2.resize(img_reduced_c1, (0,0), fx=2, fy=2)
            cv2.imwrite(os.path.join(output_path,image_name), img_back_c1)
        else:
            print("[INFO] copying image", image_name)
            shutil.copy2(f, os.path.join(output_path,image_name))


if __name__ == "__main__":
	# construct the argument parse and parse the arguments
    parser = argparse.ArgumentParser()

    parser.add_argument("-i", "--input_path", required=True,
                    help="path to input dataset")
    parser.add_argument("-o", "--output_path", required=True,
                    help="path to output data")
    
    args = vars(parser.parse_args())

    for dataset in ['train', 'valid']:
        input_path = os.path.join(args['input_path'], dataset, 'images')
        output_path = os.path.join(args['output_path'], dataset, 'images')
        if not os.path.exists(output_path):
            os.makedirs(output_path, exist_ok=True)
        down_and_upscale(input_path, output_path)