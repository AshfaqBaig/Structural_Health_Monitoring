import os
from shutil import copy2
import argparse

from lxml import etree
from xml.etree import ElementTree


def copy_xml_labeled_images(path_to_xml_file, dir_raw_data, dir_out_images):
    
    xml_name = path_to_xml_file.split('.xml')[0].replace('\\','/').split('/')[-1]
    imgs_dir = os.path.join(xml_name.split('__')[0], xml_name.split('__')[1])

    parser = etree.XMLParser()
    xmltree = ElementTree.parse(path_to_xml_file, parser=parser).getroot()
    lst_img_elems = [child for child in xmltree if child.tag == 'image']
    
    for img_elem in lst_img_elems:
        img_name = img_elem.attrib['name']
        img_path = os.path.join(dir_raw_data, imgs_dir, img_name)
        out_path = os.path.join(dir_out_images, img_name)
        lst_polylines_strs = [ann.attrib['points'] for ann in img_elem if ann.tag=='polyline' and ann.attrib['label']=='Edge']
        if len(lst_polylines_strs) != 0:
            print("[INFO] copying", img_path, "to", dir_out_images)
            if not os.path.isfile(out_path):
                copy2(img_path, dir_out_images)
        else:
            if os.path.isfile(out_path):
                print("[INFO] removing", out_path, "as no polyline 'Edge' labels found")
                os.remove(out_path)
            print("[INFO] skipping", img_path, "as no polyline 'Edge' labels found")


def extract_labeled_images(dir_cvat_xmls, dir_out_images):
    dir_raw_data = os.path.abspath(os.path.join(dir_cvat_xmls,'..'))
    dir_out_images = os.path.abspath(dir_out_images)
    if not os.path.exists(dir_out_images):
        os.makedirs(dir_out_images, exist_ok=True)
    
    print("[INFO] extracting data from", dir_raw_data, '...')
    lst_xmls = [x for x in os.listdir(dir_cvat_xmls) if x.endswith('.xml')]
    for x in lst_xmls:
        copy_xml_labeled_images(os.path.join(dir_cvat_xmls, x), dir_raw_data, dir_out_images)
    #return True  

if __name__ == "__main__":

    parser = argparse.ArgumentParser(description='Tool to copy labeled images to dataset')
    parser.add_argument('--cvat_xml_labels_path', type=str, help='input directory with cvat xml labels')
    parser.add_argument('--fullsize_images_path', type=str, help='output directory to put fullsize image')
    args = vars(parser.parse_args())

    extract_labeled_images(args['cvat_xml_labels_path'],\
                           args['fullsize_images_path'])
