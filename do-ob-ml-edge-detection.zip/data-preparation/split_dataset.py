import os
import json
import shutil
import argparse

import numpy as np
from sklearn.model_selection import train_test_split


def get_file_set(path, file_type):
    '''
    param path: path to files
    read filenames from the path
    '''

    files=[]
    for f in os.listdir(path):
        if f.endswith("." + file_type):
            files.append(path + "/" + f)
    
    return np.array(files)


#def get_image_name(label_file):
#    with open(label_file, mode='r') as json_file:
#        label_data = json.load(json_file)
#    image_name = label_data['asset']['name']
#    return image_name

def split_idx(idx, train_frac, random_state=42):
    ''' https://scikit-learn.org/stable/modules/generated/sklearn.model_selection.train_test_split.html
    param idx:        Data indeces
    param train_frac: Ratio of train set to whole dataset

    Randomly split indeces of dataset, based on these ratios:
        'train': train_frac
        'valid': (1-train_frac) / 2
        'test':  (1-train_frac) / 2

    Eg: passing train_frac=0.8 gives a 80% / 10% / 10% split
    '''

    assert train_frac >= 0 and train_frac <= 1, "Invalid training set fraction"

    idx_train, idx_temp = train_test_split(idx, train_size=train_frac, random_state=random_state)
    idx_valid, idx_test = train_test_split(idx_temp, train_size=0.5, random_state=random_state)

    return idx_train, idx_valid, idx_test


def copy_files(source_labels, input_path, target, rename_images=False):

    # create dirs
    if not os.path.exists(target + "/images"): os.makedirs(target + "/images", exist_ok=True)
    if not os.path.exists(target + "/labels"): os.makedirs(target + "/labels", exist_ok=True)

    for label_file in source_labels:
        image_name = label_file.split('/')[-1].split('.')[0] + ".jpg"
        image_file = input_path + "/images/" + image_name

        shutil.copy(label_file, target + "/labels/")
        shutil.copy(image_file, target + "/images/")


#split data by moving files to production and testing folders (do it once only!!!)
def split_data(input_path, output_path, train_frac=0.8, keep_input=True):
        
    #get labels file list
    label_files = get_file_set(input_path+"/labels", "jpg")
    try:
        existing_train = os.listdir(output_path + "/train/labels")
    except:
        existing_train = []
    
    try:
        existing_valid = os.listdir(output_path + "/valid/labels")
    except:
        existing_valid = []
    
    try:
        existing_test = os.listdir(output_path + "/test/labels")
    except:
        existing_test = []
    
    existing = existing_train + existing_valid + existing_test
    
    if len(existing) > 0:
        existing_fullpath = [f for f in label_files if any(e in f for e in  existing)]
        if set(existing_fullpath) == set(label_files):
            print("[INFO] all labels are already in the split set. Exiting...")
            if not keep_input:
                print("[INFO]: removing input files!")
                shutil.rmtree(input_path)
            exit(0)
        else:
            #print("[INFO] following labels are already in the split set:\n", existing_fullpath)
            print("[INFO]", len(existing_fullpath), "labels are already in the split set")
            print("[INFO] creating new labels set that is not in the split set...")
            label_files = np.array(list(set(label_files) - set(existing_fullpath)))
            #print("[INFO] files to be added to the split set:\n", label_files)
            print("[INFO]", len(label_files), "files will be added to the split set")

    label_idx = np.arange(0, len(label_files))
    idx_train, idx_valid, idx_test = split_idx(label_idx, train_frac)

    #print(label_files[idx_train])
    #print(idx_train)

    copy_files(label_files[idx_train], input_path, output_path + "/train")
    copy_files(label_files[idx_valid], input_path, output_path + "/valid")
    copy_files(label_files[idx_test],  input_path, output_path + "/test")

    if not keep_input:
        print("[INFO]: removing input files!")
        shutil.rmtree(input_path)

    print("-----------------------")
    print("[INFO]", len(os.listdir(output_path + "/train/images")), "images are now in", output_path + "/train/images")
    print("[INFO]", len(os.listdir(output_path + "/train/labels")), "labels are now in", output_path + "/train/labels")
    print("---")
    print("[INFO]", len(os.listdir(output_path + "/valid/images")), "images are now in", output_path + "/valid/images")
    print("[INFO]", len(os.listdir(output_path + "/valid/labels")), "labels are now in", output_path + "/valid/labels")
    print("---")
    print("[INFO]", len(os.listdir(output_path + "/test/images")), "images are now in", output_path + "/test/images")
    print("[INFO]", len(os.listdir(output_path + "/test/labels")), "labels are now in", output_path + "/test/labels")
    
    print("Splitting data is done.")    


if __name__ == "__main__":
	# construct the argument parse and parse the arguments
    parser = argparse.ArgumentParser()

    parser.add_argument("-i", "--input_path", required=True,
                    help="path to input unsplit data (images and labels).")
    parser.add_argument("-o", "--output_path", required=True,
                    help="path to output split data (images and labels).")
    parser.add_argument("-p", "--train_fraction", required=True, type=float,
                    help="train fraction of the dataset; the rest will be split equally between validation and test")
    parser.add_argument("-k", "--keep_input", required=True, type=str, 
                    help="set False if want to remove input files; default=True")
    
    args = vars(parser.parse_args())

    keep_input = args['keep_input']
    if keep_input == 'True' or keep_input == 'False':
        keep_input = eval(keep_input)
    else:
        raise ValueError('Wrong parameter value for --keep_input')


    split_data(input_path=os.path.abspath(args["input_path"]),
               output_path=os.path.abspath(args["output_path"]),
               train_frac=args["train_fraction"],
               keep_input=keep_input)
    