import os
import cv2
import numpy as np
import argparse

def get_files_set(data_dir):
    # reading filenames from the path
    files=[]
    for f in os.listdir(data_dir):
        if f.endswith(".png") or f.endswith(".jpg"):
            files.append(data_dir + "/" + f)
    return files


def tile_image(image, image_name, output_path, step_size, window_size):
    # slide a window across the image
    for y in range(0, image.shape[0], step_size):
        for x in range(0, image.shape[1], step_size):
        # yield the current window
            cv2.imwrite(output_path + "/" + image_name + "_" + 
                        str(x) + "_" + str(y) + "_" + 
                        str(window_size[0]) + "_" + 
                        str(window_size[1]) + 
                        ".jpg", 
                        image[y:y + window_size[1], x:x + window_size[0]])


def tile_images_set(input_path, output_path, step_size, window_size):
    image_files = sorted(get_files_set(input_path))
    for f in image_files:
        print("[INFO] tiling image:", f)
        image = cv2.imread(f)
        image_name = f.split('/')[-1].split('.')[0]
        tile_image(image, image_name, output_path, step_size, window_size)


def combine_image(input_dir, shape, outimg):
    img = np.zeros(shape)
    files = get_files_set(input_dir)
    for f in files:
        x_y_w_h = f.split('/')[-1].split('.')[0]
        x = int(x_y_w_h.split('_')[0])
        y = int(x_y_w_h.split('_')[1])
        w = int(x_y_w_h.split('_')[2])
        h = int(x_y_w_h.split('_')[3])
        sub = cv2.imread(f)
        border = 4
        dst = cv2.copyMakeBorder(sub[border:-border,border:-border], border, border, border, border, cv2.BORDER_DEFAULT, None, (0,0,0))
        img[y:y + h, x:x + w] = dst
    
    cv2.imwrite(outimg, img)




if __name__ == '__main__':
    
    parser = argparse.ArgumentParser(description='DexiNed aux functions.')
    parser.add_argument("-i", "--input_path", required=True,
                    help="path to input fullsize split dataset with train, valid and test directories each containing (images and labels).")
    parser.add_argument("-o", "--output_path", required=True,
                    help="path to output tiledset directory.")
    parser.add_argument("--image_width", type=int, required=True,
                    help="output image width")
    parser.add_argument("--image_height", type=int, required=True,
                    help="output image height")
    parser.add_argument("--step_size", type=int, required=True,
                    help="step size")
    args = vars(parser.parse_args())
    

    # tiling training set
    if not os.path.exists(args['output_path'] + '/train/images'):
        os.makedirs(args['output_path'] + '/train/images', exist_ok=True)
    tile_images_set(input_path  = args['input_path']  + '/train/images', 
                    output_path = args['output_path'] + '/train/images', 
                    step_size   = args['step_size'],
                    window_size = (args['image_width'],args['image_height']))

    if not os.path.exists(args['output_path'] + '/train/labels'):
        os.makedirs(args['output_path'] + '/train/labels', exist_ok=True)
    tile_images_set(input_path  = args['input_path']  + '/train/labels', 
                    output_path = args['output_path'] + '/train/labels', 
                    step_size   = args['step_size'],
                    window_size = (args['image_width'],args['image_height']))


    # splitting validation set
    if not os.path.exists(args['output_path'] + '/valid/images'):
        os.makedirs(args['output_path'] + '/valid/images', exist_ok=True)
    tile_images_set(input_path  = args['input_path']  + '/valid/images', 
                    output_path = args['output_path'] + '/valid/images', 
                    step_size   = args['step_size'],
                    window_size = (args['image_width'],args['image_height']))

    if not os.path.exists(args['output_path'] + '/valid/labels'):
        os.makedirs(args['output_path'] + '/valid/labels', exist_ok=True)
    tile_images_set(input_path  = args['input_path']  + '/valid/labels', 
                    output_path = args['output_path'] + '/valid/labels', 
                    step_size   = args['step_size'],
                    window_size = (args['image_width'],args['image_height']))
    
    # TRAIN SET WILL NOT BE TILED AS IT IS NOT GOING TO BE USED IN TRAINING PIPELINE
    
    #combine_image(args['work_dir'], (4428, 4416, 3), args['image_file'])
    