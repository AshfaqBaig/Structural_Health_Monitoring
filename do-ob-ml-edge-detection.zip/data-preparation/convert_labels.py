import os
import argparse

from lxml import etree
from xml.etree import ElementTree

import numpy as np
from PIL import Image, ImageDraw


def draw_edges_from_cvat_polylines(lst_polylines_strs, w, h, line_width=1):
    """
    Given a list of polyline strings as in cvat 1.1 xml this 
    function draws edges of specified width on image (assuming same size).
    A new gray scale (binary) image is created in png format. 
    """
    #arr = np.zeros(shape=(w,h), dtype=np.uint8)
    # creating background image in BW
    img_bg = Image.new("L", (w,h), color=0) 
    #img_bg = Image.fromarray(arr)
    draw = ImageDraw.Draw(img_bg) 
    for ln_str in lst_polylines_strs:
        #double conversion below to avoid valueerror.
        lst_points = [(int(float(pt.split(',')[0])), int(float(pt.split(',')[1]))) for pt in ln_str.split(';')] 
        for i in range(len(lst_points)-1):
            pt1, pt2 = lst_points[i], lst_points[i+1]
            draw.line((pt1[0],pt1[1], pt2[0],pt2[1]), fill=255, width=line_width)
    
    return img_bg


def create_gt_from_xml(path_to_xml_file, dir_out_gt, line_width=1):
    """
    Takes as input a path of an xml file and a path
    where output file with same name shall be stored 
    """
    parser = etree.XMLParser()
    xmltree = ElementTree.parse(path_to_xml_file, parser=parser).getroot()
    lst_img_elems = [child for child in xmltree if child.tag == 'image']
    
    if not os.path.exists(dir_out_gt):
        os.mkdir(dir_out_gt)
    #creating one image for each image tagged in xml file (with possible multile polylines labeled "Edge")
    for img_elem in lst_img_elems:
        img_name = img_elem.attrib['name']
        print("[INFO] converting", img_name)
        w, h = np.int(img_elem.attrib['width']), np.int(img_elem.attrib['height'])
        lst_polylines_strs = [ann.attrib['points'] for ann in img_elem if ann.tag=='polyline' and ann.attrib['label']=='Edge']
        if len(lst_polylines_strs) != 0:
            img_gt = draw_edges_from_cvat_polylines(lst_polylines_strs, w, h, line_width=line_width)
            path_out_gt = os.path.join(dir_out_gt, img_name) #todo: insert info o fparams e.g. line_width in output directory or image name
            img_gt.save(path_out_gt)
        else:
            print("[INFO] skipping", img_name, "as no polyline 'Edge' labels found")
    


def create_cvat_based_gt(dir_cvat_xmls, dir_out_gt, line_width=1):
    """
    Given a directory containing cvat xmls, this function creates binary images of edges.
    """
    lst_xmls = [x for x in os.listdir(dir_cvat_xmls) if x.endswith('.xml')]
    for x in lst_xmls:
        create_gt_from_xml(os.path.join(dir_cvat_xmls, x), dir_out_gt, line_width=line_width)
    return True  
    
if __name__ == "__main__":

    parser = argparse.ArgumentParser(description='Tool to convert cvat polyline labels into edge masks')
    parser.add_argument('--cvat_xml_labels_path', type=str, help='input directory with cvat xml labels')
    parser.add_argument('--fullsize_labels_path', type=str, help='output directory to put masks')
    args = vars(parser.parse_args())

    create_cvat_based_gt(os.path.abspath(args['cvat_xml_labels_path']), 
                         os.path.abspath(args['fullsize_labels_path']))
