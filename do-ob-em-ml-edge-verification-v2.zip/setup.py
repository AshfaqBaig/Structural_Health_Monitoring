import setuptools

setuptools.setup(
    name="edge-verification",
    packages=setuptools.find_packages(),
)