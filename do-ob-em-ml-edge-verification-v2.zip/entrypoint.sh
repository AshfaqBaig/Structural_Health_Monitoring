#!/bin/sh

mkdir /image-output
chown -R nonroot:nonroot /image-output
exec runuser -u nonroot "$@"