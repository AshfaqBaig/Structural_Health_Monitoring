"""
Justifications for certain parameters
-> REDUCE_MASK_BY:
At the root end we want to get rid of curvature.
FF_Image_Cut does not create a need to modify REDUCE_MASK_BY, because we only modify the mask.
The mask is based on Ground Truth and therefore

-> NOISE_SIZE_THRESHOLD:
Length of edge varies across mould.
In tip end it is very short, longer in the root end.
That means the number of possible pixels differs.
So value should be lower than at tip end than at root end.

-> REGION_OF_VERIFICATION:
In the root end, plies are placed very close to one another.
Therefore we pick a smaller

"""
ROOT_END       = range(1, 2)
ROOT_MID_BLADE = range(2, 10)
MID_BLADE      = range(10, 21)
TIP_END        = range(21, 29)
LOWER_MOULD = ""
UPPER_MOULD = ""

MOULDS = ["b9701u1", "b9701u2", "b9702u1", "b9702u2"]
out_str =  []
for mould in MOULDS:
    for cam in ROOT_END:
        out_str.append(f"[aal-{mould}-cam{str(cam):{0}>{3}}]")
        out_str.append("TOLERANCE = 25")
        out_str.append("REDUCE_MASK_BY = 500")
        out_str.append("NOISE_SIZE_THRESHOLD = 4000")
        out_str.append("REGION_OF_VERIFICATION = 15")
    for cam in ROOT_MID_BLADE:
        out_str.append(f"[aal-{mould}-cam{str(cam):{0}>{3}}]")
        out_str.append("TOLERANCE = 25")
        out_str.append("REDUCE_MASK_BY = 500")
        out_str.append("NOISE_SIZE_THRESHOLD = 4000")
        out_str.append("REGION_OF_VERIFICATION = 20")
    for cam in MID_BLADE:
        out_str.append(f"[aal-{mould}-cam{str(cam):{0}>{3}}]")
        out_str.append("TOLERANCE = 30")
        out_str.append("REDUCE_MASK_BY = 200")
        out_str.append("NOISE_SIZE_THRESHOLD = 2500")
        out_str.append("REGION_OF_VERIFICATION = 25")
    for cam in TIP_END:
        out_str.append(f"[aal-{mould}-cam{str(cam):{0}>{3}}]")
        out_str.append("TOLERANCE = 25")
        out_str.append("REDUCE_MASK_BY = 10")
        out_str.append("NOISE_SIZE_THRESHOLD = 1000")
        out_str.append("REGION_OF_VERIFICATION = 30")
    out_str.append("")
    out_str.append("")
out = "\n".join(out_str)

with open(f"./app/static/cam_config.ini", "w", encoding="utf-8") as fh:
    fh.write(out)
