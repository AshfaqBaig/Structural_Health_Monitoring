# em-edge-verification
![Python](https://img.shields.io/badge/Python-3.9-informational)
![Docker](https://img.shields.io/badge/do--ob--dops--base--image-v0.0.6-green)

![azure-iot-device](https://img.shields.io/badge/azure--iot--device-v2.10.0-informational)
![azure-iot-device (latest)](https://img.shields.io/pypi/v/azure--iot--device?label=latest)
![opencv-python-headless](https://img.shields.io/badge/opencv--python--headless-v=4.5.5.62-informational)
![opencv-python-headless (latest)](https://img.shields.io/pypi/v/opencv--python--headless?label=latest)
![scipy](https://img.shields.io/badge/scipy-v1.8.0-informational)
![scipy (latest)](https://img.shields.io/pypi/v/scipy?label=latest)
![matplotlib](https://img.shields.io/badge/matplotlib-v3.5.1-informational)
![matplotlib (latest)](https://img.shields.io/pypi/v/matplotlib?label=latest)
![cachetools](https://img.shields.io/badge/cachetools-v5.0.0-informational)
![cachetools (latest)](https://img.shields.io/pypi/v/cachetools?label=latest)
![joblib](https://img.shields.io/badge/joblib-v1.1.0-informational)
![joblib (latest)](https://img.shields.io/pypi/v/joblib?label=latest)
![ray](https://img.shields.io/badge/ray-v1.10.0-informational)
![ray (latest)](https://img.shields.io/pypi/v/ray?label=latest)
![prometheus-python](https://img.shields.io/badge/prometheus--client-v0.13.1-informational)
![prometheus-python (latest)](https://img.shields.io/pypi/v/prometheus--client?label=latest)
![python-json-logger](https://img.shields.io/badge/python--json--logger-v2.0.2-informational)
![python-json-logger (latest)](https://img.shields.io/pypi/v/python--json--logger?label=latest)

# Introduction

TODO

# Environment variables

Module can be configured using env variables and overriden by module twin patch messages

| Parameter      | Default value                                      | Overridable by Twin | Description                                                                                            |
| -------------- | -------------------------------------------------- | --------------- | ------------------------------------------------------------------------------------------------------ |
| - Path vars - | - | - | - |
| INPUT_PATH | |  No |Input path which is used to read data from |
| DEBUG_PATH |  |  No |Debug path which is used to write data to |
| GROUNDTRUTH_PATH |  |  No |Groundtruth config path |
| - Production Env vars - | - | - | - |
| CAMERA_ID | - | - | - |
| LOCATION_ID | - | - | - |
| HALL_ID | - | - | - |
| MOULD_ID | - | - | - |
| BLADE_ID | - | - | - |
| - Statistical vars - | - | - | - |
| TOLERANCE  | 30 |  Yes |Tolerance in mm added to prediction interval to accommodate camera calibration uncertainty |
| REGION_OF_VERIFICATION  | 30 |  Yes |Region in mm around ground truth edge to extract detected edge |
| REDUCE_MASK_BY  | 500 |  Yes |Reduce mould mask each side by this value in mm to reduce the impact of camera calibration uncertainty at the borders of the mould |
| NOISE_SIZE_THRESHOLD  | 500 |  Yes |Number of positively detected pixels below which the detection is discarded and assumed to be noise |
| MIN_RANGE_THRESHOLD_FACTOR | 0.40 |  Yes | # The higher the stricter |
| BAD_RANGE_THRESHOLD        | 0.45 | Yes | # The higher the stricter |
| - Debug vars - | - | - | - |
| SAVE_PLOTS  | True |  Yes | Boolean specifying if edge fit plots should be saved for debug purposes |
| LOG_LEVEL  | 20 |  Yes |Default log level |
| - Other vars - | - | - | - |
| MOULD_ID | None | Yes | No | ID of mould being used |
| IOTEDGE_DEVICEID | None | No | ID of device being used |
| IOTEDGE_MODULEID | None | No | ID of device being used |

### Start Container...
```
Using VSCode "Remote Containers" extension function "Open Folder in Container".
Requires installation of Docker.
```

### ...or install dependencies

```
pip3 install -r requirements.txt
pip3 install -r requirements-dev.txt
pip3 install -r requirements-tests.txt
```

### Check verification results

Verification results are shown for individual edges and the constructed payload to decision module is displayed.

# Test
### Run component tests, unit tests, pylint...
```
bash run_tests.sh
```

# Notes
"""
Information on FF_COMPLETE_IMAGE!
Cutting off in EV is now the new default and it cannot be deactivated until further notice.
Automatic inference of whether an incoming image is cropped or not based on its size!
"""

## Module direct method commands

### Update log level
```
az iot hub invoke-module-method \
    -n IOTDEVDVLGENOBAWE01-iot-hub-dev1-sgre \
    -d EDDEVDVLGENOBAWE01-dev1-edge-device-3 \
    -m edge-verification-aal-b9702u1-cam001  \
    --method-name 'set_log_level' \
    --method-payload '{"value":"INFO" }'
```

### Update verifier

```
az iot hub invoke-module-method \
    -n IOTDEVDVLGENOBAWE01-iot-hub-dev1-sgre \
    -d EDDEVDVLGENOBAWE01-dev1-edge-device-3 \
    -m edge-verification-aal-b9702u1-cam001  \
    --method-name 'update_verifier' \
    --method-payload '{
        "TOLERANCE": 30,
        "REGION_OF_VERIFICATION": 30,
        "REDUCE_MASK_BY": 30,
        "NOISE_SIZE_THRESHOLD": 30,
        "SAVE_PLOTS": "False",
        "MIN_RANGE_THRESHOLD_FACTOR": 0.5,
        "BAD_RANGE_THRESHOLD": 0.5,
        "FF_ENABLE_1ST_EDGE_ONLY": "True"
    }'
```
