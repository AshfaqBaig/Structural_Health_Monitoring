# Authors
- Malte Hoffmann - SGRE (malte.hoffmann@siemensgamesa.com)
- Pranjall Kumar - SGRE (pranjall.kumar@siemensgamesa.com)