import app.config as module_cfg
import config as cfg
from module_config_wrapper import ModuleConfigWrapper

PROPERTIES_TO_UPDATE = {
    # Enter your PAYLOAD
    "TOLERANCE": 50
}
LOG_LEVEL = "INFO"

for key in PROPERTIES_TO_UPDATE:
    if key not in module_cfg.MODIFIABLE_ATTRIBUTES:
        raise Exception(f"Invalid Property {key}")

if __name__ == '__main__':
    module_config_wrapper = ModuleConfigWrapper(conn_str=cfg.CONNECTION_STRING,
                                       device_em=cfg.DEVICE_EM)
    module_config_wrapper.get_configuration()
    module_config_wrapper.set_log_level(LOG_LEVEL)
    module_config_wrapper.set_configuration(PROPERTIES_TO_UPDATE)
