import logging
from azure.iot.hub import IoTHubRegistryManager
from azure.iot.hub.models import CloudToDeviceMethod

class ModuleConfigWrapper:
    """Module interacts with module configuration running on the edge"""

    def __init__(self, conn_str, device_em):
        self.device_em = device_em
        self._client = IoTHubRegistryManager.from_connection_string(conn_str)

    def get_configuration(self):
        self._invoke_method_on_all("get_configuration")

    def _invoke_method_on_all(self, method: str, payload: dict=None):
        for device_id, modules in self.device_em.items():
            for module in modules:
                print(f"Invoking method {method} for {device_id}/{module}")
                self._invoke_method(device_id, module, method, payload)

    def _invoke_method(self, device_id: str, module: str, method: str, payload: dict=None):
        device_method = CloudToDeviceMethod(method_name=method, payload=payload)
        result = self._client.invoke_device_module_method(device_id, module, device_method)
        print(result)

    def set_configuration(self, payload: dict):
        self._invoke_method_on_all("update_verifier", payload)

    def set_log_level(self, log_level):
        allowed_log_levels = set(list(logging._levelToName.keys()) + list(logging._levelToName.values()))
        if log_level not in allowed_log_levels:
            raise Exception(f"Invalid log level, must be in {allowed_log_levels}")

        self._invoke_method_on_all("set_log_level", {"value": log_level})
