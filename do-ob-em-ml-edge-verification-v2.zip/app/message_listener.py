import asyncio
import json
import time
from typing import Tuple, Any

from azure.iot.device.aio import IoTHubModuleClient
from azure.iot.device.iothub.models import Message

from app.logging import logger
import app.config as cfg
import app.static.routes_constants as routes

from app.processors.default import DefaultProcessor
from app.data_handler.verifier_provider import VerifierProvider
from app.method_request_handler import MethodRequestHandler

log = logger.yield_logger()

class MessageListener:
    """
    AMQP Listener implementation.
    It accepts AMQP payloads and forwards them to default processor.
    Also module direct methods are supported.
    """

    def __init__(self):
        self.verifier_provider = VerifierProvider()
        self.default_processor = DefaultProcessor(self.verifier_provider)
        # Here's all the information concerning communication with other devices
        self.module_client = IoTHubModuleClient.create_from_edge_environment()
        self.method_request_handler = MethodRequestHandler(self.module_client, self.verifier_provider, self.default_processor)

    async def message_handler(self, input_message: Message):
        """
        Default message handler
        """

        try:
            log.info(f"{'-' * 30}    New message received    {'-' * 30}")
            correlation_id, custom_properties, payload = self._extract_input(input_message)

            if input_message.input_name == routes.DECISION_MAKER_INPUT:
                self.process_dm_message(payload)

            if input_message.input_name == routes.EDGE_DETECTION_INPUT:
                await self.process_ed_message(payload, correlation_id, custom_properties)

        except Exception as ex:
            # pass data further to error output
            log.exception(ex)
            await self.module_client.send_message_to_output(str(ex), routes.ERROR_OUTPUT)

    def process_dm_message(self, payload: dict) -> None:
        """ Processes message from DM """
        log.info("├──> Inbound message from Decision Maker")
        self.verifier_provider.update(payload.get("metadata"))
        visible_edges_for_cam: list(str) = payload.get("data").get(cfg.CAMERA_ID)
        if visible_edges_for_cam is None:
            log.info("Dropping request because no edges for this CAM were provided by DM")
        else:
            self.default_processor.set_edges(visible_edges_for_cam)

    async def process_ed_message(self, payload: dict, correlation_id: str, custom_properties: dict) -> None:
        """ Processes message from ED """
        log.info("├──> Inbound message from Edge Detection")
        # TODO: Design change... this is too nested and testing sucks.
        response_dm, response_dcm = self.default_processor.run(payload)
        if response_dm is not None:
            # pass data further to output (DM)
            log.debug("Passing output to DM")
            message = self.build_message(response_dm, correlation_id, custom_properties)
            await self.module_client.send_message_to_output(message, routes.DEFAULT_OUTPUT)
        if response_dcm is not None:
            # pass data further to output (DCM)
            log.debug("Passing output to DCM")
            message = self.build_message(response_dcm, correlation_id, custom_properties)
            await self.module_client.send_message_to_output(message, routes.DCM_OUTPUT)

    @staticmethod
    def build_message(output_message: dict, correlation_id: str, custom_properties: Any) -> Message:
        """ Creates message to DM """
        log.debug(
                f"AMQP on Output {routes.DEFAULT_OUTPUT} with following payload "
                f"(correlation_id={correlation_id}) "
                f"sent: {output_message}, custom_properties={custom_properties}",
                extra={"correlation_id": correlation_id})
        message = Message(data=str(output_message))
        message.correlation_id = correlation_id
        message.custom_properties = custom_properties
        return message

    @staticmethod
    def _extract_input(input_message: Message) -> Tuple:
        """ Extracts message components"""
        correlation_id = input_message.correlation_id
        custom_properties = input_message.custom_properties
        payload = json.loads(input_message.data)
        log.debug(f"Extracted correlation_id={correlation_id} and custom_properties={custom_properties} "
                  f"and data={payload} from message.", extra={"correlation_id": correlation_id})
        return correlation_id, custom_properties, payload

    @staticmethod
    def empty_listener():
        """
        Empty listener to keep module always running
        """
        while True:
            time.sleep(600) # nosemgrep: python.lang.best-practice.sleep.arbitrary-sleep

    async def run(self):
        """
        Entrypoint main method
        """
        try:
            await self.module_client.connect()

            self.module_client.on_message_received = self.message_handler
            self.module_client.on_method_request_received = self.method_request_handler.run

            log.info("Message Listener started")
            log.info(f"Log level for {log.name} logger is: {log.getEffectiveLevel()}")

            # Run the empty listener in the event loop
            loop = asyncio.get_event_loop()
            user_finished = loop.run_in_executor(None, self.empty_listener)
            await user_finished

            # Finally, disconnect
            await self.module_client.disconnect()

        except Exception:
            log.exception("Unexpected error")
            raise
