""" Edge Hub routes constants """

DECISION_MAKER_INPUT = "decisionMakerInput"
EDGE_DETECTION_INPUT = "edgeDetectionInput"

DEFAULT_OUTPUT = "defaultOutput"
DCM_OUTPUT = "dcmOutput"
ERROR_OUTPUT = "errorOutput"
