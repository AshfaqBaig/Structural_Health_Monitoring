from pythonjsonlogger import jsonlogger
import app.config as cfg

class CustomJsonFormatter(jsonlogger.JsonFormatter):
    """ Custom JSON formatter for appending custom properties to log messages """

    def add_fields(self, log_record, record, message_dict):
        super().add_fields(log_record, record, message_dict)
        log_record["mould_id"] = cfg.MOULD_ID
        log_record["location_id"] = cfg.LOCATION_ID
        log_record["hall_id"] = cfg.HALL_ID
        log_record["blade_id"] = cfg.BLADE_ID
        log_record["camera_id"] = cfg.CAMERA_ID
