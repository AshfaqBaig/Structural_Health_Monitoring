# pylint: disable=wrong-import-position

from datetime import datetime, timedelta
from distutils.util import strtobool
from typing import Union, Tuple

from cachetools import TTLCache

Numeric = Union[int, float]

from app.processors.verifier import Verifier
from app.data_handler.team_instructions import TeamInstructions
from app.data_handler.ground_truth_data_service import GroundTruthDataService
import app.config as cfg

from app.logging.logger import yield_logger
log = yield_logger()

class VerifierProvider:
    """Class responsible for provider correct verifier instances based on team instructions"""

    def __init__(self):
        self.ground_truth_data_service = GroundTruthDataService(cfg.GROUNDTRUTH_PATH)
        self.active_verifier: Verifier = None
        self.verifiers = TTLCache(maxsize=10, ttl=timedelta(hours=12), timer=datetime.now)

    def update(self, team_instructions: dict) -> None:
        """ Updates set of verifiers """
        team_instructions = TeamInstructions(team_instructions)

        if team_instructions not in self.verifiers:
            log.info("Existing verifiers: %s", self.verifiers.keys())
            log.info("Creating new verifier for %s", team_instructions)

            #############################################
            # Load EV Data
            #############################################
            camera_properties: dict = self.ground_truth_data_service.get_camera_properties(team_instructions)
            ev_input: dict = self.ground_truth_data_service.get_ev_groundtruth_data(team_instructions)

            #############################################
            # Check files for correctness
            #############################################
            self.check_ev_input(ev_input, cfg.CAMERA_ID)
            self.check_camera_properties(camera_properties, cfg.CAMERA_ID)

            #############################################
            # Initialise verifier instance
            #############################################
            self.verifiers[team_instructions] = Verifier(
                camera_properties=camera_properties,
                ev_input=ev_input[cfg.CAMERA_ID],
                camera_id=cfg.CAMERA_ID
            )
        self.active_verifier = self.verifiers[team_instructions]

    def get(self) -> Verifier:
        """ Returns available verifiers """
        return self.active_verifier

    def set_tolerance(self, value) -> bool:
        """ Wrapper for setter for tolerance """
        if not self.check_expected_type("tolerance", value, int):
            value, status = self.try_adjust_type("tolerance", value, int)
            if not status:
                return False
        if not self.check_expected_range("tolerance", value, 0, float('inf')):
            return False

        for _, verifier in self.verifiers.items():
            verifier.set_value("tolerance", value)
            if verifier.tolerance != value:
                log.error("tolerance: Something went wrong!")
                return False
        log.info(f"tolerance: Set to {value}")
        return True

    def set_region_of_verification(self, value) -> bool:
        """ Wrapper for setter for region_of_verification """
        if not self.check_expected_type("region_of_verification", value, int):
            value, status = self.try_adjust_type("region_of_verification", value, int)
            if not status:
                return False
        if not self.check_expected_range("region_of_verification", value, 0, float('inf')):
            return False

        for _, verifier in self.verifiers.items():
            verifier.set_value("region_of_verification", value)
            if verifier.region_of_verification != value:
                log.error("region_of_verification: Something went wrong!")
                return False
        log.info(f"region_of_verification: Set to {value}")
        return True

    def set_reduce_mask_by(self, value) -> bool:
        """ Wrapper for setter for reduce_mask_by """
        if not self.check_expected_type("reduce_mask_by", value, int):
            value, status = self.try_adjust_type("reduce_mask_by", value, int)
            if not status:
                return False
        if not self.check_expected_range("reduce_mask_by", value, 0, float('inf')):
            return False

        for _, verifier in self.verifiers.items():
            verifier.set_value("reduce_mask_by", value)
            if verifier.reduce_mask_by != value:
                log.error("reduce_mask_by: Something went wrong!")
                return False
        log.info(f"reduce_mask_by: Set to {value}")
        return True

    def set_noise_size_threshold(self, value) -> bool:
        """ Wrapper for setter for noise_size_threshold """
        if not self.check_expected_type("noise_size_threshold", value, int):
            value, status = self.try_adjust_type("noise_size_threshold", value, int)
            if not status:
                return False
        if   not self.check_expected_range("noise_size_threshold", value, 0, float('inf')):
            return False

        for _, verifier in self.verifiers.items():
            verifier.set_value("noise_size_threshold", value)
            if verifier.noise_size_threshold != value:
                log.error("noise_size_threshold: Something went wrong!")
                return False
        log.info(f"noise_size_threshold: Set to {value}")
        return True

    def set_min_range_threshold_factor(self, value) -> bool:
        """ Wrapper for setter for min_range threshold """
        if not self.check_expected_type("min_range_threshold_factor", value, float):
            value, status = self.try_adjust_type("min_range_threshold_factor", value, float)
            if not status:
                return False
        if not self.check_expected_range("min_range_threshold_factor", value, 0, 1):
            return False

        for _, verifier in self.verifiers.items():
            verifier.set_value("min_range_threshold_factor", value)
            if verifier.min_range_threshold_factor != value:
                log.error("min_range_threshold_factor: Something went wrong!")
                return False
        log.info(f"min_range_threshold_factor: Set to {value}")
        return True

    def set_bad_range_threshold(self, value) -> bool:
        """ Wrapper for setter for bad range threshold """
        if not self.check_expected_type("bad_range_threshold", value, float):
            value, status = self.try_adjust_type("bad_range_threshold", value, float)
            if not status:
                return False
        if not self.check_expected_range("bad_range_threshold", value, 0, 1):
            return False

        for _, verifier in self.verifiers.items():
            verifier.set_value("bad_range_threshold", value)
            if verifier.bad_range_threshold != value:
                log.error("bad_range_threshold: Something went wrong!")
                return False
        log.info(f"bad_range_threshold: Set to {value}")
        return True

    def set_save_plots(self, value) -> bool:
        """ Wrapper for setter for saving plots """
        try:
            value = strtobool(value)
        except (ValueError, AttributeError):
            log.error(f"set_save_plots: Could not boolean {value}!")
            return False
        for _, verifier in self.verifiers.items():
            verifier.set_value("save_plots", value)
            if verifier.save_plots != value:
                log.error("set_save_plots: Something went wrong!")
                return False
        log.info(f"set_save_plots: Set to {value}")
        return True

    @staticmethod
    def check_expected_type(var_name: str, var_value, exp_val) -> bool:
        """ Checks whether type of variable is correct """
        if not isinstance(var_value, exp_val):
            log.error(f"{var_name}: Invalid value, is {type(var_value)} not {exp_val}.")
            return False
        return True

    @staticmethod
    def try_adjust_type(var_name: str, var_value, exp_val) -> Tuple[bool, bool]:
        """ Checks whether type of variable is correct """
        try:
            if exp_val == bool:
                var_name = strtobool(var_value)
            else:
                var_name = exp_val(var_value)
        except ValueError:
            log.info(f"-> Could not convert {type(var_value)} to {exp_val}.")
            return False, False
        log.info(f"-> Converted {type(var_value)} to {exp_val} successfully.")
        return var_name, True

    @staticmethod
    def check_expected_range(var_name: str,
                             var_value: Numeric,
                             lower: Numeric = float("-inf"),
                             upper: Numeric = float("inf")
                             ) -> bool:
        """ Checks whether value of variable is correct """
        if var_value < lower or var_value > upper:
            log.error(f"{var_name}: Invalid value, must be bigger than {lower} and smaller than {upper}.")
            return False
        return True

    @staticmethod
    def check_ev_input(ev_input: dict, active_camera: str) -> None:
        """ Checks data of ev input file """
        if active_camera not in ev_input:
            available_cams = [*ev_input]
            raise ValueError(f"'{active_camera}' not in ev_input! Available cams:\n{available_cams}")

        # check for "edges", check for "metadata"
        if not "edgedata" in ev_input[active_camera] or not "metadata" in ev_input[active_camera]:
            raise ValueError("Metadata or Edgedata field missing!")

        for edge in ev_input[active_camera]["edgedata"]:
            provided_data = ev_input[active_camera]["edgedata"][edge]
            expected_keys = [
                'x_groundtruth',
                'edge_orientation',
                'y_x_polynom_groundtruth',
                'pi_x_polynom_groundtruth',
                'metric',
                ]
            if not all(key in provided_data for key in expected_keys):
                available_keys = [*provided_data]
                raise ValueError(f"Important key missing in ev_input file!\n"
                                 f"Missing key(s): {set(expected_keys) - set(available_keys)}")

    @staticmethod
    def check_camera_properties(camera_properties: dict, active_camera: str) -> None:
        """ Checks camera-meta input """
        if active_camera not in camera_properties:
            available_cams = [*camera_properties]
            raise ValueError(f"'{active_camera}' not in canera-meta-file! Available cams:\n{available_cams}")

        if "orientation" not in camera_properties[active_camera]:
            raise ValueError(f"Orientation information missing for camera {active_camera}!")

        if "pixels_per_mm_along_coverage" not in camera_properties[active_camera]:
            raise ValueError(f"Px-per-mm information missing for camera {active_camera}!")
