# pylint: disable=protected-access
import json

import os
from os import access, R_OK
from os.path import isfile, getsize
from typing import Optional, Any

import joblib

import app.config as cfg

from app.data_handler.team_instructions import TeamInstructions

from app.logging.logger import yield_logger
log = yield_logger()

class GroundTruthDataService:
    """Service responsible for caching and resolving correct groundtruth data from external files"""

    def __init__(self, ground_truth_data_path: str):
        self.cameras_properties: dict = {}
        self.ev_input: dict = {}
        self._path = ground_truth_data_path

    @staticmethod
    def _validate_team_instructions(team_instructions):
        if not team_instructions.ground_truth_data_version \
                or not team_instructions.layer_id \
                or not team_instructions.blade_revision:
            raise ValueError(
                f"Team instructions requires 'ground_truth_data_version', " \
                f"'blade_revision' and 'layer_id' properties. " \
                f"Got: {team_instructions}")

    def get_camera_properties(self, team_instructions: TeamInstructions):
        """Try to resolve or and load if needed camera properties data"""

        self._validate_team_instructions(team_instructions)

        if team_instructions.ground_truth_data_version not in self.cameras_properties:
            camera_properties_path = self.establish_camera_meta_path(team_instructions)
            self.cameras_properties[team_instructions.ground_truth_data_version] = self.load_camera_properties(
                camera_properties_path)
        return self.cameras_properties.get(team_instructions.ground_truth_data_version)

    def establish_camera_meta_path(self, team_instructions: TeamInstructions) -> str:
        """ Establishes Camera-Meta Filepath """
        mould_id = team_instructions.mould_id
        groundtruth_version = team_instructions.ground_truth_data_version
        filename = f"{cfg.LOCATION_ID}_{cfg.HALL_ID}_{mould_id}-{cfg.CAMERAPARAMS_FN}"
        camera_properties_path = os.path.join(self._path, mould_id, groundtruth_version, filename)
        log.info(f"Path for camera meta information is: {camera_properties_path}")
        return camera_properties_path

    def get_ev_groundtruth_data(self, team_instructions: TeamInstructions) -> dict:
        """
        Try to resolve - or and load if needed - ev input data

        Format:
        result = {"layer-id": [list-of-cameras]}
        """

        self._validate_team_instructions(team_instructions)

        # Try to get exisiting data
        ev_input: Optional[Any] = self.ev_input.get(team_instructions.ground_truth_data_version)
        # If not there, or layer_id (can be mix of several) not there
        if ev_input is None or team_instructions.layer_id not in ev_input:
            result = {}
            for layer_to_load in team_instructions._layers:
                ev_input_path = self.establish_ev_input_path(team_instructions, layer_to_load)
                self.ev_input[team_instructions.ground_truth_data_version] = {}
                result[layer_to_load] = self.load_ev_input(ev_input_path)
            merged_result = self.merge_layers(result)
            self.ev_input[team_instructions.ground_truth_data_version][
                team_instructions.layer_id] = merged_result

        return self.ev_input.get(team_instructions.ground_truth_data_version).get(team_instructions.layer_id)

    @staticmethod
    def merge_layers(result: dict) -> dict:
        """
        This function removes layer as the top key from `result`
        and yields `merged_dict` in which the top key is the cam.
        Cam collects all edges (so also multiple layers).
        Format:
        from {"layer-id": [list-of-cameras]}
        to {"camera_01": (edgedata, metadata), "camera_02": ...}
        """
        merged_dict = {}
        for layer in result:
            if not merged_dict:
                merged_dict = result[layer]
            else:
                for cam in result[layer]:
                    if not cam in merged_dict: # If camera was not yet seen, add and update edgedata and metadata
                        merged_dict[cam] = result[layer][cam]
                    else: # Update already seen camera with additional edgedata
                        merged_dict[cam]["edgedata"].update(result[layer][cam]["edgedata"])
        return merged_dict


    def establish_ev_input_path(self, team_instructions: TeamInstructions, layer_to_load: str) -> str:
        """ Establishes EV-Input Filepath """
        mould_id = team_instructions.mould_id
        blade_revision = team_instructions.blade_revision
        groundtruth_version = team_instructions.ground_truth_data_version
        filename = f"{mould_id}-{blade_revision}-{layer_to_load}-{cfg.EV_INPUT_FN}"
        ev_input_path = os.path.join(self._path, mould_id, groundtruth_version, filename)
        log.info(f"Path for EV-Input Data is: {ev_input_path}")
        return ev_input_path

    def load_camera_properties(self, path_cameras_data: str) -> dict:
        """ Provides Camera Meta Information """
        self.check_file(path_cameras_data, "Camera Meta")
        with open(path_cameras_data, "r", encoding="utf-8") as file:
            camera_meta = json.load(file)
        return self.build_camera_dict(camera_meta)

    def load_ev_input(self, path_ev_input: str) -> dict:
        """ Provides Ground Truth Approximation """
        self.check_file(path_ev_input, "EV Input")
        with open(path_ev_input, "rb") as file:
            data = joblib.load(file)
        return data

    @staticmethod
    def check_file(path, identifier=""):
        """ Checks whether file exists, is readable, has content """
        if not isfile(path):
            out_msg = f"Data file '{identifier}' not found at {path}"
            raise FileNotFoundError(out_msg)
        if not access(path, R_OK):
            out_msg = f"Data file '{identifier}' at {path} not readable!"
            raise RuntimeError(out_msg)
        filesize = getsize(path)
        if filesize == 0:
            raise ValueError(f"Can't process '{identifier}', empty file: {path}")

    @staticmethod
    def build_camera_dict(camera_meta: dict) -> dict:
        """ Selects relevant information from camera-meta-file"""
        cam_props = {}
        for entry in camera_meta:
            if isinstance(entry["cam_id"], str):
                cam_props.update(
                    {
                        entry["cam_id"]: {
                            "orientation": entry["orientation"],
                            "pixels_per_mm_along_coverage": entry[
                                "pixels_per_mm_along_coverage"
                            ],
                        }
                    }
                )
        return cam_props
