class TeamInstructions:
    """Team instructions object used for fetching correct data for the verifier"""

    def __init__(self, team_instructions: dict):
        self.ground_truth_data_version: str = team_instructions.get("groundTruthVersion")
        self.mould_id: str = team_instructions.get("mouldId")
        self.blade_sn: str = team_instructions.get("bladeSn")
        self.blade_revision: str = team_instructions.get("bladeRevision")
        self._layers: list[str] = team_instructions.get("layers")

    @property
    def layer_id(self) -> str:
        '''
        Team instructions layer identifier
        For multiple layers it is a comma-concatenated string
        '''
        return ",".join(self._layers)

    def __repr__(self):
        return f'TeamInstructions(ground_truth_data_version={self.ground_truth_data_version}, ' \
               f'mould_id={self.mould_id}, bladeSn={self.blade_sn}, ' \
               f'blade_revision={self.blade_revision}, layers={self._layers}))'

    def __eq__(self, other):
        if not isinstance(other, TeamInstructions):
            return NotImplemented

        return self.ground_truth_data_version == other.ground_truth_data_version and \
               self.mould_id == other.mould_id and self.blade_sn == other.blade_sn and \
               self.blade_revision == other.blade_revision and self.layer_id == other.layer_id

    def __hash__(self):
        return hash(self.ground_truth_data_version) ^ hash(self.mould_id) ^ hash(self.blade_sn) \
               ^ hash(self.blade_revision) ^ hash(self.layer_id)
