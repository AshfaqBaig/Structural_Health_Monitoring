# pylint: disable=no-member, expression-not-assigned
"""
Edge verification module
"""
from copy import deepcopy
from typing import Tuple

import logging
import os
import time
from math import ceil

import cv2
import ray
import psutil
import numpy as np

import app.config as cfg

from app.utils.helper_functions import convert_from_gid_to_pid
from app.utils.helper_functions import create_polygon_around_line
from app.utils.helper_functions import fit_ci
from app.utils.helper_functions import img2points
from app.utils.helper_functions import get_points_outside
from app.utils.log_metrics import log_metrics

from app.utils.plot_util import PlottingUtil

from app.logging.logger import yield_logger
log = yield_logger()

logging.getLogger('ray').setLevel(logging.WARNING)


class Verifier:
    ''' class to implement verifier '''
    def __init__(
            self,
            camera_properties: dict,
            ev_input: dict,
            camera_id: str
    ):
        """
        Terminology: The term UV-Coordinates is used synonymously with Ground Truth (GT)
        camera_properties         : Camera parameter data
        ev_input                  : Data bundle for Edge Verification
        camera_id                 : Name of camera-id for verifier instance
        tolerance                 : (in px) One-side tolerance of verification,
                                  : reflects uncertainty about transformations
        region_of_verification    : (in px) Defines the extraction region around the GT polyline
        reduce_mask_by            : (in px) Value defining how much mould is removed from each side
        noise_size_threshold      : Min number of points to be treated as a line (for the case when a
                                  : ply has not yet been laid, but sth is still recognized by edge detection)
        min_range_threshold_factor: Factor relating to ratio of detected pixel range
                                  : to ground truth range
        bad_range_threshold       : Factor relating to minimum pixel coverage over detected range
        save_plots                : Saves plots or not
        """
        self.camera_id = camera_id
        self._camera_properties: dict = camera_properties[camera_id]
        self._ev_input: dict = ev_input

        # Statistical variables
        self.tolerance = cfg.TOLERANCE
        self.region_of_verification = cfg.REGION_OF_VERIFICATION
        self.reduce_mask_by = cfg.REDUCE_MASK_BY
        self.noise_size_threshold = cfg.NOISE_SIZE_THRESHOLD
        self.min_range_threshold_factor = cfg.MIN_RANGE_THRESHOLD_FACTOR
        self.bad_range_threshold = cfg.BAD_RANGE_THRESHOLD
        self.save_plots = cfg.SAVE_PLOTS
        self.ff_complete_image = None

        # plotting utility
        self.plotting_obj = PlottingUtil()

        # Initialising the ray with all cores
        ray.shutdown()
        ray.init(num_cpus=psutil.cpu_count())

    @staticmethod
    def create_and_log_edge_status(edge_results: dict) -> None:
        """ Merges edge status """
        edges_status = {}
        for edge_list in edge_results:
            edges_status[edge_list[1]['edge_id']] = edge_list[0]
            log_metrics(edge_list[1])
        return edges_status

    @staticmethod
    def generate_data_info(
        edge_id: str, plots_output_filepath: str, tolerance: int,
        camera_pix_per_mm: float, var_error_metric_residuals: float, status: str
    ) -> dict:
        """ Function to generate a dictionary of relavant data for plotting """
        return {
            "edge_id": edge_id,
            "data_type": "Detected points fit",
            "plots_output_filepath": plots_output_filepath,
            "tolerance": tolerance * camera_pix_per_mm,
            "r2": str(round(var_error_metric_residuals, 2)),
            "title": f"Decision Plot - Status: {status} - {convert_from_gid_to_pid(edge_id)}",
            "zero_line": True,
        }

    def verify_single_edge(
            self,
            detections_image: np.ndarray,
            edge_id: str,
            edge_type: str,
            camera_pix_per_mm: float,
            plots_output_filepath: str,
            ev_input: dict):
        """
        detections_image     : Grayscale prepared (masked and transposed) detection image
        gt_polyline          : uv coordinates of the projected ground truth edge vertices
        edge_id              : Edge identifier
        camera_orientation   : Camera orientation with respect to the mould,
                             : 'lon' for along, 'lat' for across the mould
        camera_pix_per_mm    : Mean pixels per mm as measured by calibration
        plots_output_filepath: Path to plots output
        ev_input             : Contains a variety of precomputed data per cam and per edge
        """
        start_time = time.time()

        ##############################
        # Unpack groundtruth & orientation
        ##############################
        # Use precomputed data
        edge_precomputation = ev_input["edgedata"][edge_id]
        x_groundtruth            = edge_precomputation['x_groundtruth']
        edge_orientation         = edge_precomputation['edge_orientation']

        y_x_polynom_groundtruth  = edge_precomputation['y_x_polynom_groundtruth']
        pi_x_polynom_groundtruth = edge_precomputation['pi_x_polynom_groundtruth']

        ##############################
        # Set the correct tolerance and RoV value based on the edge-type
        ##############################
        tolerance = self.get_tolerance_val(edge_type)
        region_of_verification = self.get_region_of_verification_val(edge_type)

        ##############################
        # Initialise metrics
        ##############################
        metrics = {
            "edge_id": edge_id,
            "edge_orientation": edge_orientation,
            "used_tolerance": tolerance,
            "used_rov": region_of_verification
        }

        #################################
        # Obtain detected points in image
        #################################
        # Drawing polygon around groundtruth edge to reduce detection field
        reduced_extraction = int(self.reduce_mask_by * camera_pix_per_mm)
        tube_size = region_of_verification * camera_pix_per_mm
        polygon = create_polygon_around_line(x_gt=x_groundtruth,
                                             yf_gt=y_x_polynom_groundtruth,
                                             pi_gt=pi_x_polynom_groundtruth,
                                             polygon_step=cfg.POLYGON_STEP,
                                             reduced_extraction=reduced_extraction,
                                             tube_size=tube_size)
        # Safety copy of original image
        detections_image_copy = deepcopy(detections_image)

        mask = self.get_mask(detections_image, polygon)
        # Handle exception when mask cannot be build
        if isinstance(mask, str) and mask == cfg.NOT_DETECTED_STATUS:
            metrics["edge_verification_duration"] = round(time.time() - start_time, 2)
            return mask, metrics

        # Extracting detections from the image in the detection field
        x_detected, y_detected = img2points(detections_image & mask)

        #################################
        # The actual analysis
        #################################
        x_range, shared_points = self.get_range(x_detected)

        # Determine min_range_threshold dynamically by ground truth
        # TODO: include REDUCE_MASK_BY
        min_no_pixels = int(
            (max(x_groundtruth) - min(x_groundtruth))
            * self.min_range_threshold_factor
        )

        # Case 1: Number of positively detected pixels undershot (detection = noise)
        cond_case_1 = x_detected.size < self.noise_size_threshold \
                      or y_detected.size < self.noise_size_threshold
        # Case 2: Range of pixels undershot
        cond_case_2 = len(x_range) < min_no_pixels
        # Case 3: Pixels are not covering area enough (point vs. range)
        cond_case_3 = shared_points < self.bad_range_threshold

        status = self.obtain_status(cond_case_1, cond_case_2, cond_case_3)

        # Plot ground truth on image in case of error using short-circuit
        if self.save_plots:
            detections_image_rgb = self.plotting_obj.plot_groundtruth_uv_lines(
                cv2.cvtColor(detections_image_copy, cv2.COLOR_BGR2RGB),
                x_groundtruth, y_x_polynom_groundtruth, tube_size
            )
            detections_image_rgb = self.plotting_obj.plot_groundtruth_detected_pixels(
                detections_image_rgb, x_detected, y_detected
            )
            self.plotting_obj.save_groundtruth_plot(detections_image_rgb, plots_output_filepath, edge_id)

        metrics["edge_type"]            = edge_type
        metrics["detected_points"]      = x_detected.size
        metrics["x_range_to_min_range"] = round(len(x_range) / min_no_pixels, 2)
        metrics["pixel_population"]     = shared_points

        # Case 1: Number of positively detected pixels undershot (detection = noise) - Output
        if status == cfg.NOT_DETECTED_STATUS:
            metrics["edge_verification_duration"] = round(time.time() - start_time, 2)
            return status, metrics

        ####################
        # Estimate the model
        ####################

        # Using Residual approach
        y_detected_res = y_detected - y_x_polynom_groundtruth(x_detected)

        # Fit Regression on Residuals
        y_x_polynom_residuals, pi_x_polynom_residuals, var_error_metric_residuals = fit_ci(
            x_detected, y_detected_res, poly_degree=cfg.POLY_DEGREE_RESIDUALS
        )

        # Case 2: Range of pixels undershot - Output
        # Case 3: Pixels are not covering area enough - Output
        if status in (cfg.MIN_RANGE_STATUS, cfg.BAD_RANGE_STATUS):
            metrics["edge_verification_duration"] = round(time.time() - start_time, 2)
            if self.save_plots:
                info = self.generate_data_info(
                    edge_id, plots_output_filepath, tolerance, camera_pix_per_mm, var_error_metric_residuals, status
                )
                self.plotting_obj.plot_data(
                    x_detected, y_detected_res, x_range, y_x_polynom_residuals, pi_x_polynom_residuals, info
                )
            return status, metrics

        # Case 4: Normal ply detection (placed correctly / misplaced)
        below_0, above_0 = get_points_outside(
            points = y_x_polynom_residuals(x_range),
            pi_smoothed = pi_x_polynom_residuals(x_range),
            total_tolerance = tolerance * camera_pix_per_mm,
        )

        status = cfg.NOT_OK_STATUS if above_0 > 0 or below_0 > 0 else cfg.OK_STATUS

        metrics["no_outside_points_above_0"] = above_0
        metrics["no_outside_points_below_0"] = below_0

        if self.save_plots:
            info = self.generate_data_info(
                edge_id, plots_output_filepath, tolerance, camera_pix_per_mm, var_error_metric_residuals, status
            )
            self.plotting_obj.plot_data(
                x_detected, y_detected_res, x_range, y_x_polynom_residuals, pi_x_polynom_residuals, info
            )

        metrics["edge_verification_duration"] = round(time.time() - start_time, 2)
        return status, metrics

    def get_tolerance_val(self, edge_type: str) -> int:
        """ Gets the used tolerance value """
        if edge_type == cfg.DETECTED_EDGE:
            return int(ceil(self.tolerance * cfg.TOLERANCE_FACTOR))
        return int(self.tolerance)

    def get_region_of_verification_val(self, edge_type: str) -> int:
        """ Gets the appropriate RoV value """
        if edge_type == cfg.DETECTED_EDGE:
            return int(ceil(self.region_of_verification * cfg.REGION_OF_VERIFICATION_FACTOR))
        return int(self.region_of_verification)

    @staticmethod
    def get_range(x_detected: np.ndarray) -> Tuple[int, float]:
        """ Gets range and populated-points in detected points"""
        try:
            x_range = range(min(x_detected), max(x_detected) + 1)  # Determine range of x-points
            shared_points = round(len(set(x_detected)) / len(x_range), 2)  # Calculate pixel population
        except (ValueError, TypeError, ZeroDivisionError):
            x_range = range(0)
            shared_points = 0.0
        return x_range, shared_points

    @staticmethod
    def get_mask(detections_image: np.ndarray, polygon: int):
        """ Initialise mask by image size """
        mask = np.zeros(detections_image.shape)
        # Mark detection field
        try:
            cv2.fillPoly(mask, [polygon], 1)
        except cv2.error:
            return cfg.NOT_DETECTED_STATUS
        mask = mask.astype(bool)
        return mask

    @staticmethod
    def obtain_status(cond_1: bool, cond_2: bool, cond_3: bool) -> str:
        """ Evaluates conditions and return detection status """
        if cond_1:
            return cfg.NOT_DETECTED_STATUS

        if cond_2:
            return cfg.MIN_RANGE_STATUS

        if cond_3:
            return cfg.BAD_RANGE_STATUS
        return "unknown"

    @ray.remote
    def wrap_verify_single_edge(
        self,
        edge_id: str,
        edge_type: str,
        detections_image: np.ndarray,
        plots_output_filepath: str
    ):
        """Wrapper function for verify_single_edge()"""
        pix_per_mm = self._camera_properties["pixels_per_mm_along_coverage"]
        result = self.verify_single_edge(
            detections_image = detections_image,
            edge_id = edge_id,
            edge_type = edge_type,
            camera_pix_per_mm = pix_per_mm,
            plots_output_filepath = plots_output_filepath,
            ev_input = self._ev_input
        )
        return result

    def verify_edges(self,
                     detections_image: np.ndarray,
                     detected_edges: list,
                     missing_edges: list,
                     image_filename: str,
                     plots_output: bool
                     ):
        """
        Key function to organzise the verification / called at new message
        * Does some input checking
        * Starts the multiprocessing
        """
        # Test for data consistency btw DM and Ground Truth
        if not self.check_data_consistency(detected_edges,
                                           missing_edges,
                                           self._ev_input["edgedata"]):
            return False

        # Deal with debug plotting
        plots_output_filepath = ""
        if self.save_plots:
            plots_output_filepath = os.path.join(plots_output, image_filename)
            # Create folder per image
            os.makedirs(plots_output_filepath, exist_ok=True)

        detections_image = cv2.threshold(detections_image, 10, 255, cv2.THRESH_BINARY)[1]

        self.infer_image_status(detections_image)

        # Cut images to increase processing speed - done by IG usually
        # EV will either crop the image or assume a cropped image!
        if self.ff_complete_image:
            if self._camera_properties["orientation"] == "lon":
                log.info("camera orientation is lon, transposing image")
                detections_image = detections_image.T
            left_mould_border = self._ev_input['metadata']['extreme_point_left']
            right_mould_border = self._ev_input['metadata']['extreme_point_right']
            detections_image = detections_image[:,left_mould_border:right_mould_border:]
        start_time = time.time() * 1000

        # Do the ray-multiprocessing
        if detected_edges:
            detected_edge_results = ray.get([
                self.wrap_verify_single_edge.remote(self,
                edge_id = edge,
                edge_type = cfg.DETECTED_EDGE,
                detections_image = detections_image,
                plots_output_filepath = plots_output_filepath)
                for edge in detected_edges])
        else:
            detected_edge_results = []

        if missing_edges:
            missing_edge_results = ray.get([
                self.wrap_verify_single_edge.remote(self,
                edge_id = edge,
                edge_type = cfg.MISSING_EDGE,
                detections_image = detections_image,
                plots_output_filepath = plots_output_filepath)
                for edge in missing_edges])
        else:
            missing_edge_results = []

        verification_results = detected_edge_results + missing_edge_results
        edges_status = self.create_and_log_edge_status(verification_results)

        total_time = (time.time() * 1000) - start_time
        log.warning(f"Total pool time: {round(total_time, 4)} ms")
        return edges_status

    def check_data_consistency(self, detected_edges: list, missing_edges: list, edge_data) -> bool:
        """ Checks data consistency between expected and incoming data """
        # TODO: Pass over layer id from verifier instance from teaminstructions.layer_i
        if not all(edge in edge_data for edge in detected_edges + missing_edges):
            available_edges = [*edge_data]
            log.error(f"Not all edges (from DM) have corresponding data in "
                      f"ev-input file for camera {self.camera_id}!\n"
                      f"Missing: {sorted(set(detected_edges + missing_edges) - set(available_edges))}")
            return False
        return True

    def infer_image_status(self, detections_image):
        """ Infer whether complete image, or cropped image is consumed """
        if detections_image.shape in ((6480, 4860), (4860, 6480)):
            log.info("Automatically inferring: uncropped image")
            self.ff_complete_image = True
        else:
            log.info("Automatically inferring: cropped image")
            self.ff_complete_image = False

    def set_value(self, prop: str, value):
        """ Sets an instance variable generically """
        log.info(f"Setting {prop} to {value}")
        setattr(self, prop, value)

    def run(self, det_mask: np.ndarray, detected_edges: list, missing_edges: list, image_filename: str):
        ''' code entry point '''
        log.info("Verifier Settings:")
        log.info("Camera ID                            : %s", self.camera_id)
        log.info("Image filename                       : %s", image_filename)
        log.info("Save plots value                     : %s", self.save_plots)
        log.info("Region of verification (1)           : %s", self.region_of_verification)
        log.info("Tolerance (2)                        : %s", self.tolerance)
        log.info("Reduced mask by                      : %s", self.reduce_mask_by)
        log.info("Noise size threshold value (3)       : %s", self.noise_size_threshold)
        log.info("Minimum range factor value (4)       : %s", self.min_range_threshold_factor)
        log.info("PX population threshold value (5)    : %s", self.bad_range_threshold)

        if not os.path.exists(cfg.OUTPUT_PATH):
            os.makedirs(cfg.OUTPUT_PATH, exist_ok=True)

        status = self.verify_edges(
            detections_image = det_mask,
            detected_edges = detected_edges,
            missing_edges = missing_edges,
            image_filename = image_filename,
            plots_output = os.path.join(cfg.OUTPUT_PATH, self.camera_id),
        )
        if not status:
            return

        log.info("------------> Verification Results <----------------")
        ver_results = {convert_from_gid_to_pid(k): v for k, v in status.items()}
        ordered_keys = sorted(ver_results)
        log.info(str({k: ver_results[k] for k in ordered_keys}))
        log.info("----------------------------------------------------")

        return status
