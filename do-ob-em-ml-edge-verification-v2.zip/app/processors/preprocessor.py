"""
Preprocessor module, handing the incoming payload
"""
import os

from typing import Union

import cv2
import numpy as np

import app.config as cfg

from app.logging.logger import yield_logger
log = yield_logger()

class RequestPreprocessor:
    """
    Inference server request preprocessor
    """

    def __init__(self):
        # From Edge-Detection-Module
        self.det_mask = None
        self.image_filename = None

    @staticmethod
    def extract_data_from_payload(payload: dict):
        """ Extracts relevant data from payload """
        # Assume only 1 image in payload.
        image_data = payload["images"][0]
        image_filename = image_data["location"]
        return image_filename

    @staticmethod
    def load_image_from_disk(full_path: str):
        """ Attempts to load an image from disk """
        if os.path.exists(full_path):
            try:
                image = cv2.imread(full_path, cv2.IMREAD_GRAYSCALE)
                return image
            except Exception as exc:
                log.error(exc)
        log.error("File %s doesn't exist", full_path)
        return None

    @staticmethod
    def get_image_filename(path: str):
        """ Gets the name of the image """
        return path.split(".")[0]

    def run(self, payload: dict) -> Union[None, np.ndarray]:
        """ Feedback from Edge-Detection-Module """
        image_filename = self.extract_data_from_payload(payload)

        full_path = os.path.join(cfg.INPUT_PATH, image_filename)
        self.det_mask = self.load_image_from_disk(full_path)
        self.image_filename = self.get_image_filename(image_filename)

        return self.det_mask
