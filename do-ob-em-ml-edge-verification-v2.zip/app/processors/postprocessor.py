"""
Response postprocessor module
"""
from typing import Tuple

import app.config as cfg

from app.logging.logger import yield_logger
log = yield_logger()

class ResponsePostprocessor:
    """
    Inference server response postprocessor
    """

    def __init__(self, ff_enable_1st_edge_only: bool=cfg.FF_ENABLE_1ST_EDGE_ONLY):
        self.ff_enable_1st_edge_only = ff_enable_1st_edge_only

    def set_enable_1st_edge_only(self, val: bool):
        """ Feature Flag for making the first edge count """
        self.ff_enable_1st_edge_only = val

    @staticmethod
    def apply_ff_enable_1st_edge_only(results):
        """Apply feature toggle"""
        ply_ids = {k[:-2] for k in results}
        for ply in ply_ids:
            edge_1 = ply + "_1"
            edge_2 = ply + "_2"
            if results.get(edge_1) and results.get(edge_2):
                if results[edge_1]!=cfg.OK_STATUS and results[edge_2]==cfg.OK_STATUS:
                    results[edge_2] = cfg.FORCED_NOT_OK
                if results[edge_1]==cfg.OK_STATUS:
                    results[edge_2] = cfg.OK_STATUS
        return results

    def assign_edges_to_ok_and_not_ok(self, results: dict) -> Tuple[set, set]:
        """ Returns tuple of (detected_edges, missing_edges) """
        # This code bit applys the algorithm that 1st edge is decisive
        if self.ff_enable_1st_edge_only:
            results = self.apply_ff_enable_1st_edge_only(results)
        detected_edges = set()
        missing_edges = set()
        for edge, edge_status in results.items():
            if edge_status == cfg.OK_STATUS:
                detected_edges.add(edge)
            else:
                missing_edges.add(edge)

        return detected_edges, missing_edges

    @staticmethod
    def make_response_for_dm(payload: dict,
                             detected_edges: set,
                             missing_edges: set) -> dict:
        """ Standardized Response from EV Module To DM """
        response = {
            "session": payload["session"],
            "feedback": [
                {
                    "type": "detected-edges",
                    "edges": list(detected_edges),
                },
                {
                    "type": "missing-edges",
                    "edges": list(missing_edges),
                },
            ],
        }
        response["session"]["moduleId"] = "edge-verification"
        return response

    @staticmethod
    def make_response_for_dcm(results: dict, payload: dict) -> dict:
        """ Standardized Response from EV Module To DM """
        response = {
            "session": payload["session"],
            "feedback": results,
        }
        response["session"]["moduleId"] = "edge-verification"
        return response

    def run(self, payload: dict, results: dict):
        """ Runs the postprocessor """
        detected_edges, missing_edges = self.assign_edges_to_ok_and_not_ok(results)
        response_dm  = self.make_response_for_dm(payload, detected_edges, missing_edges)
        response_dcm = self.make_response_for_dcm(results, payload)
        return response_dm, response_dcm
