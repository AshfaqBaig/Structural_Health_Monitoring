
import json
import math
import os
import time

from distutils.util import strtobool
from typing import Tuple, Union

import numpy as np

from prometheus_client import Histogram, Summary

import app.config as cfg
from app.config import get_repo_root
from app.data_handler.verifier_provider import VerifierProvider
from app.processors.postprocessor import ResponsePostprocessor
from app.processors.preprocessor import RequestPreprocessor
from app.utils.helper_functions import convert_from_gid_to_pid
from app.utils.ini_parser import get_config

from app.logging.logger import yield_logger
log = yield_logger()

HISTOGRAM_BUCKETS = (0.5, 1, 1.5, 2, 2.5, 3, 3.5, 4, 5, math.inf)
METRICS_HISTOGRAM = \
    Histogram('ev_total_duration_histogram_seconds',
              'Edge Verification (EV) total duration histogram in seconds',
              buckets=HISTOGRAM_BUCKETS,
              labelnames=cfg.METRIC_LABELS).labels(mould_id=cfg.MOULD_ID,
                                                   device_id=cfg.IOTEDGE_DEVICEID,
                                                   module_id=cfg.IOTEDGE_MODULEID)
METRICS_SUMMARY = Summary('ev_total_duration_seconds',
                          'Edge Verification (EV) total duration summary in seconds',
                          labelnames=cfg.METRIC_LABELS).labels(mould_id=cfg.MOULD_ID,
                                                               device_id=cfg.IOTEDGE_DEVICEID,
                                                               module_id=cfg.IOTEDGE_MODULEID)

VERIFIER_HISTOGRAM_BUCKETS = (0.5, 1, 1.5, 2, 2.5, 3, 3.5, 4, 5, math.inf)
VERIFIER_METRICS_HISTOGRAM = \
    Histogram('ev_verification_duration_histogram_seconds',
              'Edge Verification (EV) verification duration histogram in seconds',
              buckets=HISTOGRAM_BUCKETS,
              labelnames=cfg.METRIC_LABELS).labels(mould_id=cfg.MOULD_ID,
                                                   device_id=cfg.IOTEDGE_DEVICEID,
                                                   module_id=cfg.IOTEDGE_MODULEID)
VERIFIER_METRICS_SUMMARY = Summary('ev_verification_duration_seconds',
                          'Edge Verification (EV) verification duration summary in seconds',
                          labelnames=cfg.METRIC_LABELS).labels(mould_id=cfg.MOULD_ID,
                                                               device_id=cfg.IOTEDGE_DEVICEID,
                                                               module_id=cfg.IOTEDGE_MODULEID)


class DefaultProcessor:
    """Default message processor for messages emmitted by edge-detection module"""

    def __init__(self, verifier_provider: VerifierProvider):
        self.preprocessor = RequestPreprocessor()
        self.postprocessor = ResponsePostprocessor(cfg.FF_ENABLE_1ST_EDGE_ONLY)
        self.verifier_provider: VerifierProvider = verifier_provider

        #######################################################
        # Load camera-specific-config // override if applicable
        #######################################################
        cam_path = os.path.join(get_repo_root(), "app", "static", "cam_config.ini")
        cam_cfg = get_config(path=cam_path,
                             mode=cfg.CAMERA_ID)

        for param in cam_cfg:
            setattr(cfg, param, cam_cfg[param])

        # List of edges detected by ED of plies that are correctly placed on the mold
        self.detected_edges = []
        # List of edges yet to be placed (hence not detected) by ED or are detected as misplaced.
        self.missing_edges = []

    def set_edges(self, all_possible_edges: dict):
        """Update list of visible edges. Triggered by DM message"""
        self.detected_edges = all_possible_edges.get("detectedEdges", [])
        self.missing_edges = all_possible_edges.get("missingEdges", [])
        log.debug(f"Detected edges set to:\n{[convert_from_gid_to_pid(i) for i in self.detected_edges]}")
        log.debug(f"Missing edges set to:\n{[convert_from_gid_to_pid(i) for i in self.missing_edges]}")

    def set_enable_1st_edge_only(self, value):
        """Wrapper for setter for saving plots"""
        try:
            value = strtobool(value)
        except ValueError:
            log.error(f"Could not boolean {value}...")
            return False
        log.info(f"Setting FF_ENABLE_1ST_EDGE_ONLY to {value}")
        self.postprocessor.set_enable_1st_edge_only(value)

        if self.postprocessor:
            self.postprocessor.set_enable_1st_edge_only(value)
        else:
            cfg.FF_ENABLE_1ST_EDGE_ONLY = value
        return True

    @METRICS_HISTOGRAM.time()
    @METRICS_SUMMARY.time()
    def run(self, payload: dict) -> Union[None, Tuple[str, str]]:
        """Entrypoint for messages"""
        start_time = time.time() * 1000

        if not self.detected_edges and not self.missing_edges:
            log.info("Dropping request because no edges were provided by DM")
            return None, None

        # preprocess AMQP message
        log.debug("Starting preprocessor")
        request: Tuple[None, np.ndarray] = self.preprocessor.run(payload)
        log.debug("Preprocessor finished")
        if request is None:
            log.info("Dropping request on account of invalid preprocessor message")
            return None, None

        log.debug("Starting verifier")
        results = self.verify()
        log.debug("Verifier finished")
        if not results:
            log.info("Dropping request because verification result is empty")
            return None, None

        # postprocess inference result
        log.debug("Starting postprocessor")
        response_dm, response_dcm = self.postprocessor.run(payload, results)
        log.debug("Postprocessor finished")
        total_time = (time.time() * 1000) - start_time
        log.warning(f"Total processing time: {round(total_time, 4)} ms")

        return json.dumps(response_dm), json.dumps(response_dcm)

    def verify(self):
        """Verifier function call"""
        log.debug("Starting verifier")
        verifier = self.verifier_provider.get()
        results = verifier.run(
            det_mask = self.preprocessor.det_mask,
            detected_edges = self.detected_edges,
            missing_edges = self.missing_edges,
            image_filename = self.preprocessor.image_filename
        )
        log.debug("Verifier finished")
        return results
