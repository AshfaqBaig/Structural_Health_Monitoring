from azure.iot.device import MethodRequest, MethodResponse
from azure.iot.device.aio import IoTHubModuleClient
import app.config as cfg
from app.data_handler.verifier_provider import VerifierProvider
from app.processors.default import DefaultProcessor
from app.logging import logger

log = logger.yield_logger()

class MethodRequestHandler:
    """Main method request handler class"""

    def __init__(self, module_client: IoTHubModuleClient, verifier_provider: VerifierProvider, default_processor: DefaultProcessor):
        self._module_client = module_client
        self.target_function_mapping = {
            "TOLERANCE": verifier_provider.set_tolerance,
            "REGION_OF_VERIFICATION": verifier_provider.set_region_of_verification,
            "REDUCE_MASK_BY": verifier_provider.set_reduce_mask_by,
            "NOISE_SIZE_THRESHOLD": verifier_provider.set_noise_size_threshold,
            "SAVE_PLOTS": verifier_provider.set_save_plots,
            "MIN_RANGE_THRESHOLD_FACTOR": verifier_provider.set_min_range_threshold_factor,
            "BAD_RANGE_THRESHOLD": verifier_provider.set_bad_range_threshold,
            "FF_ENABLE_1ST_EDGE_ONLY": default_processor.set_enable_1st_edge_only
        }

    async def run(self, request: MethodRequest):
        """ Method request handler entrypoint """

        result = None
        try:
            log.info(f'Method {request.name} invocation with: {request.payload}')
            if request.name == "set_log_level" and request.payload.get("value"):
                status = self._update_log_level(request.payload.get("value"))
                result = {
                    "value": cfg.LOG_LEVEL
                }
            elif request.name == "update_verifier":
                status = self._update_verifier(request.payload)
            elif request.name == "get_configuration":
                result = self._get_configuration()
                status = 200
            else:
                status = 400

            method_response = MethodResponse.create_from_method_request(request, status, result)
            await self._module_client.send_method_response(method_response)

        except Exception:
            log.exception("Unexpected error while handling method request")
            raise

    @staticmethod
    def _update_log_level(log_level: str):
        """Update LOG_LEVEL"""
        if cfg.LOG_LEVEL != log_level:
            cfg.LOG_LEVEL = log_level
            logger.update_log_level(log, cfg.LOG_LEVEL)
            return 200
        return 304

    def _update_verifier(self, payload: dict):
        """Update verifier method implementation"""

        log.info(f"New verifier settings received: {payload}")

        status: int = 200
        patchable_verifier_settings = [key for key in payload if key in cfg.MODIFIABLE_ATTRIBUTES]
        for key in patchable_verifier_settings:
            result = self._dispatcher(key, payload.get(key))
            if not result:
                status = 500
        return status

    @staticmethod
    def _get_configuration() -> dict:
        """Get module configuration method implementation"""

        result = {
            "LOG_LEVEL": cfg.LOG_LEVEL
        }
        for key in cfg.MODIFIABLE_ATTRIBUTES:
            result[key] = getattr(cfg, key)
        return result


    def _dispatcher(self, key: str, value: str) -> bool:
        """ Dispatches for functions"""

        setattr(cfg, key, value)
        return self.target_function_mapping[key](value)
