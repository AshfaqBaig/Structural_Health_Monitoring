""" Plotting utility which saves data for debugging purposes """

import os
import numpy as np
import cv2
import matplotlib.pyplot as plt
import matplotlib
from app.utils.helper_functions import convert_from_gid_to_pid
from app.logging.logger import yield_logger

matplotlib.use("Agg")

log = yield_logger()

class PlottingUtil:
    """ Class to implement plotting utility """

    def __init__(self) -> None:
        pass

    @staticmethod
    def _set_plot_dimensions(fig, dimension: int) -> None:
        """ Function to set required figure size """
        fig.set_figheight(dimension)
        fig.set_figwidth(dimension)

    @staticmethod
    def _save_plot(fig, info: dict) -> None:
        """ Function to save plots """
        try:
            fig.savefig(
                os.path.join(
                    info["plots_output_filepath"], convert_from_gid_to_pid(
                        f"{info['edge_id']}_fitted_{info['data_type']}.png"
                    )
                )
            )
        except OSError:
            log.error("Could not save the required data plot", exc_info=True)
        plt.close(fig)

    @staticmethod
    def plot_data(
        x_points: np.ndarray, y_points: np.ndarray, x_range: int,
        fit_function: np.polynomial, pred_int_function: np.polynomial, info: dict
    ) -> None:
        """ Function to plot data """
        fig, ax = plt.subplots()

        PlottingUtil._set_plot_dimensions(fig, 6)

        # zero line
        if info["data_type"] == 'detections':
            ax.hlines(
                0, min(x_range), max(x_range), colors='black', linestyles='dashed', lw=0.1, label="zero-line"
            )

        # Data (e.g. Ground truth)
        ax.scatter(x_points, y_points, s=0.5, lw=0.1, color="blue", label="Data (x, y)")

        # fit
        ax.plot(
            x_range, fit_function(x_range), lw=1, color="green", label=f"{info['data_type']} (yf), R2: {info['r2']}"
        )

        # Prediction interval lower
        ax.plot(
            x_range, fit_function(x_range) - pred_int_function(x_range), "-.", lw=1, color="peru",
            label="95% prediction interval lower (yf(x) - pif(x))"
        )

        # Prediction interval upper
        ax.plot(
            x_range, fit_function(x_range) + pred_int_function(x_range), "-.", lw=1, color="darkorange",
            label="95% prediction interval upper (yf(x) + pif(x))"
        )

        # Prediction interval w. Tolerance lower
        ax.plot(
            x_range, fit_function(x_range) - pred_int_function(x_range) - info["tolerance"], "-", lw=1, color="red",
            label="prediction interval + tolerance (yf(x) - pif(x) - tol)",
        )

        # Prediction interval w. Tolerance upper
        ax.plot(
            x_range, fit_function(x_range) + pred_int_function(x_range) + info["tolerance"], "-", lw=1, color="darkred",
            label="prediction interval + tolerance (yf(x) + pif(x) + tol)"
        )

        # Plot zero line
        if info["zero_line"]:
            ax.plot(x_range, [0 for _ in range(len(x_range))], "-", lw=2, color="black", label="")

        ax.legend(loc="best", prop={'size': 6})
        ax.title.set_text(info["title"])

        PlottingUtil._save_plot(fig, info)

    @staticmethod
    def plot_groundtruth_uv_lines(
        detections_image_rgb: np.ndarray, x_groundtruth: list, y_x_polynom_groundtruth: np.polynomial, tube_size: int
    ) -> np.ndarray:
        """ Function to plot a diagnostic plot for evaluation """
        image_size = detections_image_rgb.shape[0]
        green_color = (160, 232, 343)
        for y in range(min(x_groundtruth), max(x_groundtruth)):
            try:
                upper_line = int(y_x_polynom_groundtruth(y)) + int(tube_size)
                if not (upper_line < 0 and (upper_line + 2) < 0 and (upper_line + 2) > image_size):
                    detections_image_rgb[upper_line:upper_line + 2, y] = green_color
                lower_line = int(y_x_polynom_groundtruth(y)) - int(tube_size)
                if not (lower_line < 0 and (lower_line - 2) < 0 and (lower_line - 2) > image_size):
                    detections_image_rgb[lower_line-2:lower_line, y] = green_color
            except IndexError:
                log.error(f"Index out of range as it is more than the size of the image: {image_size}")
        return detections_image_rgb

    @staticmethod
    def plot_groundtruth_detected_pixels(
        detections_image_rgb: np.ndarray, x_detected: list, y_detected: list
    ) -> np.ndarray:
        """ Function to plot a diagnostic plot for evaluation """
        red_color = (100, 100, 200)
        for x, y in zip(x_detected, y_detected):
            detections_image_rgb[y, x] = red_color
        return detections_image_rgb

    @staticmethod
    def save_groundtruth_plot(detections_image_rgb: np.ndarray, plots_output_filepath: str, edge_id: str) -> list:
        """ Function to save groundtruth plot """
        try:
            filename = f"{plots_output_filepath}/{convert_from_gid_to_pid(edge_id)}-with_GT.jpg"
            cv2.imwrite(filename, detections_image_rgb)
            return [detections_image_rgb.shape[0], detections_image_rgb]
        except OSError:
            log.error("Could not generate ground-truth plot on original image", exc_info=True)
