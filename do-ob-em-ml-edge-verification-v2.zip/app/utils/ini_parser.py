import os
import configparser
import json

from typing import Dict, Any

from app.logging.logger import yield_logger
log = yield_logger()

def get_config(path: str, mode: str = 'DEFAULT') -> dict:
    """ Reads config and returns it as a case-insensitive dict """
    if not os.path.exists(path):
        raise FileNotFoundError(os.path.realpath(path))
    config = configparser.SafeConfigParser()
    if path is None or mode is None:
        raise IOError("No valid Config-parametrization, maybe camera_id was not specified?")
    config.read(path)

    # Fall back to default, if mode is not in file
    if mode not in config:
        log.warning(f"{mode} not found in cam-config.ini, falling back to default.")
        mode = "DEFAULT"

    # Load into correct Python Format
    config_dict: Dict[Any, Any] = {}
    config_dict[mode] = {}
    for key in config[mode]:
        try:
            tmp = json.loads(config[mode][key])
            config_dict[mode][key] = tmp
            config_dict[mode][key.upper()] = tmp
        except json.decoder.JSONDecodeError:
            config_dict[mode][key] = config[mode][key]
            config_dict[mode][key.upper()] = config[mode][key]
        except configparser.InterpolationMissingOptionError:
            config_dict[mode][key] = config.get(mode, key, raw=True)
            config_dict[mode][key.upper()] = config.get(mode, key, raw=True)

    return config_dict[mode]
