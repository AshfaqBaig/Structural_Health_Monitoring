# pylint: disable=invalid-name
""" This module collects some helper functions """
import re

from typing import Tuple

import numpy as np
from scipy import stats

import app.config as cfg

from app.logging.logger import yield_logger
log = yield_logger()
expr_pid = re.compile(r"([0-9]{9}_[1-2])")
expr_layer = re.compile(r"_([A-Z]*[0-9]{1})_")


def fit_ci(
    x: np.ndarray,
    y: np.ndarray,
    poly_degree: int = 11,
    poly_intv_degree: int = None,
    yerr=None,
) -> Tuple[np.poly1d, np.poly1d, float]:
    """
    Fitting a polynomial of poly_degree for x on y and returning polynomial
    functions (applied to get from points to a line) for y on x, pi on x,
    and ci on x. Also returns a variance-error-metric.

    Args:
        x: Regressor
        y: Regressand
        poly_degree: Degree of Polynomial for x - y regression
        poly_intv_degree: Degree of Polynomial for x - pi/ci regression; does not
            have much influence.
        yerr: Individual error of points, can be used as weights, derived for example
            from regions of the image, where transformations where good/bad

    Returns:
        y_x_polynom: Polynom coeficients* for regression y on x
        pi_x_polynom: Polynom coeficients for regression pi on x
        ci_x_polynom: Polynom coeficients for regression ci on x
        var_error_metric: Metric of regression error.

    *Let f be a poly1d instance, i.e. coefficients
    of a polynomial, then f(x) evaluates f at x.
    E.g.: p = np.poly1d([1, 2, 3]) -> p(0.5) = 4.25

    TODO:
    * Convert np.poly1d to np.polynomial class
    * Split into smaller, testable functions
    """
    ########################
    # Calculating regression
    ########################
    if poly_intv_degree is None:
        poly_intv_degree = poly_degree

    if yerr is None:  # If it is the same for all points, yerr only scales error
        y_x_polynom = np.poly1d(np.polyfit(x, y, poly_degree))
    elif isinstance(yerr, list):  # Individual error per point
        yerr = np.array(yerr)
        y_x_polynom = np.poly1d(np.polyfit(x, y, poly_degree, w=1 / yerr))

    #############################
    # Calculating test statistics
    #############################
    SSE = (y - y_x_polynom(x)) ** 2 # Residual sum of squares
    N_OBS = y.size                  # Sample size
    N_PARAMS = poly_degree + 1      # Number of Parameters
    DOF = N_OBS - N_PARAMS          # Degrees of freedom

    # Terminological difference arises in the expression mean squared error (MSE):
    # The mean squared error of a regression is a number computed from the SSE
    # of the computed residuals, not of the unobservable errors.
    # If the SSE is divided by N_OBS, this results in the mean of squared residuals.
    # This is a biased estimate of the variance of the unobserved errors.
    # The bias is removed by dividing the sum of the squared residuals by
    # DOF = N_OBS − N_PARAMS − 1, instead of n, where df is the number of degrees of freedom
    # (n minus the number of parameters (excluding the intercept) p being estimated - 1).
    # This forms an unbiased estimate of the variance of the unobserved
    # errors, and is called the mean squared error, too.

    R2 = np.round(1 - (np.sum(SSE) / np.sum((y - np.mean(y)) ** 2)), 4)
    R_B_MSE = np.sqrt(np.sum(SSE) / N_OBS)  # Root of biased Mean-squared error (div by N_OBS)
    T_STATISTIC = stats.t.ppf(
        1 - ((1 - cfg.SIGNIFICANCE_LVL) / 2), DOF
    )  # t-statistic

    # Prediction Interval Formula
    # https://online.stat.psu.edu/stat501/lesson/3/3.3
    pi = (
        T_STATISTIC
        * R_B_MSE
        * np.sqrt(
            1
            + 1 / N_OBS
            + (x - np.mean(x)) ** 2 / np.sum((x - np.mean(x)) ** 2)
        )
    )

    # Prediction Interval Polynomial
    pi_x_polynom = np.poly1d(np.polyfit(x, pi, poly_intv_degree))

    return y_x_polynom, pi_x_polynom, R2

def img2points(img: np.ndarray) -> Tuple[np.ndarray, np.ndarray]:
    """This function takes an array and returns Tuple of points"""
    # Use argwhere to get list of pairs linking to non-zero indices
    yx = np.argwhere(img)
    # Order by second dimension of argwhere output (2nd dim: x-axis)
    yx = yx[yx[:, 1].argsort()]
    # x := 2nd axis __ y := 1st axis
    x = yx[:, 1]
    y = yx[:, 0]
    return x, y

def create_polygon_around_line(x_gt: np.ndarray,
                               yf_gt: np.poly1d,
                               pi_gt: np.poly1d,
                               polygon_step: int,
                               reduced_extraction: int,
                               tube_size: float
                               ) -> np.ndarray:
    """Draws a polygon tube around ground truth to extract detections"""
    polygon = []
    for i in range(
        min(x_gt) + reduced_extraction,
        max(x_gt) - reduced_extraction + polygon_step,
        polygon_step,
    ):
        polygon.append((i, yf_gt(i) - pi_gt(i) - tube_size))
    for i in range(
        max(x_gt) - reduced_extraction,
        min(x_gt) + reduced_extraction - 1,
        -polygon_step,
    ):
        polygon.append((i, yf_gt(i) + pi_gt(i) + tube_size))

    polygon = np.array(polygon).astype(int)
    return polygon


def get_points_outside(points: np.ndarray,
                       pi_smoothed: np.ndarray,
                       total_tolerance: float
                       ) -> Tuple:
    """
    Calculates the sum of points that lie < 0 when adding
    `pi_smoothed + total_tolerance` and > 0 when subtracting
    `pi_smoothed + total_tolerance.
    Boils down to finding out whether a point on the prediction
    intervals crosses the zero line.
    """
    offset = pi_smoothed + total_tolerance
    nr_points_upper_pi_below_0 = sum((points + offset) < 0)
    nr_points_lower_pi_above_0 = sum((points - offset) > 0)
    return nr_points_upper_pi_below_0, nr_points_lower_pi_above_0


def convert_from_gid_to_pid(global_ply_id: str) -> str:
    """Convert from global-ply-id to LAY-xyz000xyz"""
    # TODO: Refactor this function incl. regexprs one day...
    if global_ply_id is None:
        return None
    result_pid = re.search(expr_pid, global_ply_id)
    if not result_pid:
        return global_ply_id
    result_layer = re.search(expr_layer, global_ply_id)
    if not result_layer:
        return global_ply_id
    return result_layer[0][1:] + result_pid[0][6:]


def convert_from_pid_to_gid(ply_id: str) -> str:
    """Convert xyz000xyz to global-ply-id"""
    if ply_id is None:
        return None
    result = "000" + f'{str(ply_id):{0}>{3}}' + "000"
    return result
