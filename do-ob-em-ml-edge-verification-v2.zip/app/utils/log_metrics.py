# pylint: disable=missing-module-docstring
from app.utils.helper_functions import convert_from_gid_to_pid

from app.logging.logger import yield_logger
log = yield_logger()

def log_metrics(metrics):
    """Logs detailed metrics"""
    log.debug("-" * 46)
    log.debug(f"{'Metrics logging for edge_id': <46}: {convert_from_gid_to_pid(metrics.get('edge_id'))}")
    log.debug(f"{'Metrics type': <46}: {metrics.get('edge_type')}")
    log.debug(f"{'Applied RoV value (1)': <46}: {metrics.get('used_rov')}")
    log.debug(f"{'Applied Tolerance value (2)': <46}: {metrics.get('used_tolerance')}")

    detected_points = metrics.get("detected_points")
    if isinstance(detected_points, int):
        out = "Detected pixels (3)"
        log.debug(f"{out: <46}: {detected_points}")

    x_axis_range = metrics.get("x_range_to_min_range")
    if x_axis_range:
        out = "X-axis-range/min-range (4)"
        log.debug(f"{out: <46}: {x_axis_range}")

    pixel_population = metrics.get("pixel_population")
    if isinstance(pixel_population, float):
        out = "Pixel population (5)"
        log.debug(f"{out: <46}: {pixel_population} ")

    above_0 = metrics.get("no_outside_points_above_0")
    below_0 = metrics.get("no_outside_points_below_0")
    if above_0 or below_0:
        log.debug(f"{'Number of outside points > 0': <46}: {above_0}")
        log.debug(f"{'Number of outside points < 0': <46}: {below_0}")

    duration = metrics.get("edge_verification_duration")
    if duration:
        log.debug(f"{'Duration on thread (sec) ': <46}: {duration}")
