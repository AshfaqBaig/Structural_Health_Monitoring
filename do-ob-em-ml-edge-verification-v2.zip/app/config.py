"""Module defines all configuration options"""
import os
import logging
from distutils.util import strtobool

MODULE_APP_NAME = "edge-verification"

# Logging config
LOGGER_CONFIG = os.getenv("LOGGER_CONFIG", "logging-plain.ini")

# Path/file variables
IOTEDGE_MODULEID = os.environ.get("IOTEDGE_MODULEID")
IOTEDGE_DEVICEID = os.environ.get("IOTEDGE_DEVICEID")
IOTEDGE_GATEWAYHOSTNAME = os.environ.get("IOTEDGE_GATEWAYHOSTNAME")

# env vars
INPUT_PATH       = os.environ.get("INPUT_PATH")
OUTPUT_PATH      = os.environ.get("DEBUG_PATH")
GROUNDTRUTH_PATH = os.environ.get("GROUNDTRUTH_PATH")

CAMERA_ID   = os.getenv("CAMERA_ID")
LOCATION_ID = os.getenv("LOCATION_ID")
HALL_ID     = os.getenv("HALL_ID")
MOULD_ID    = os.getenv("MOULD_ID")
BLADE_ID    = os.getenv("BLADE_ID")

CAMERAPARAMS_FN = "camera_meta.json"
EV_INPUT_FN     = "ev-input.joblib"

# Constants
DETECTED_EDGE = "detected"
MISSING_EDGE  = "missing"

# Statistical variables
POLYGON_STEP             = os.environ.get("POLYGON_STEP", 20)
SIGNIFICANCE_LVL         = os.environ.get("SIGNIFICANCE_LVL", 0.95)
POLY_DEGREE_RESIDUALS    = 2

# Detection statuses
OK_STATUS           = "ok" # ply correctly placed
NOT_OK_STATUS       = "misplaced" # ply incorrectly placed
FORCED_NOT_OK       = "forced not ok"
NOT_DETECTED_STATUS = "not enough px" # Number of pixels in tube < NOISE_SIZE_THRESHOLD
MIN_RANGE_STATUS    = "too shortly ranged x-axis" # Dif of min/max on x-axis < SHORT_RANGE_THRESHOLD
BAD_RANGE_STATUS    = "insufficient px population" # Number of x-values/range < BAD_RANGE_THRESHOLD

# env vars overridable by direct method
## Parameters
LOG_LEVEL                     = os.environ.get("LOG_LEVEL", logging.INFO)
TOLERANCE                     = int(os.environ.get("TOLERANCE", 30))
TOLERANCE_FACTOR              = float(os.environ.get("TOLERANCE_FACTOR", 1.2))
REGION_OF_VERIFICATION        = int(os.environ.get("REGION_OF_VERIFICATION", 30))
REGION_OF_VERIFICATION_FACTOR = float(os.environ.get("REGION_OF_VERIFICATION_FACTOR", 1.2))
REDUCE_MASK_BY                = int(os.environ.get("REDUCE_MASK_BY", 350))
SAVE_PLOTS                    = bool(strtobool(os.environ.get("SAVE_PLOTS", "False")))
NOISE_SIZE_THRESHOLD          = int(os.environ.get("NOISE_SIZE_THRESHOLD", 3000)) # The higher the stricter
MIN_RANGE_THRESHOLD_FACTOR    = float(os.environ.get("MIN_RANGE_THRESHOLD_FACTOR", 0.45)) # The higher the stricter
BAD_RANGE_THRESHOLD           = float(os.environ.get("BAD_RANGE_THRESHOLD", 0.48)) # The higher the stricter

## Feature Toggles
# Only first edge is decisive
FF_ENABLE_1ST_EDGE_ONLY    = bool(strtobool(os.environ.get("FF_ENABLE_1ST_EDGE_ONLY", "False")))

MODIFIABLE_ATTRIBUTES = [
    "TOLERANCE",
    "REGION_OF_VERIFICATION",
    "REDUCE_MASK_BY",
    "NOISE_SIZE_THRESHOLD",
    "SAVE_PLOTS",
    "MIN_RANGE_THRESHOLD_FACTOR",
    "BAD_RANGE_THRESHOLD",
    "FF_ENABLE_1ST_EDGE_ONLY"
]

METRIC_LABELS = ["device_id", "module_id", "mould_id"]
PROMETHEUS_PORT = int(os.environ.get("PROMETHEUS_PORT") or 9060)

MODULE_SETTINGS_KEY = f"/devices/{IOTEDGE_GATEWAYHOSTNAME}/modules/{MODULE_APP_NAME}/settings"
ETCD_URL = os.getenv("ETCD_URL", "localhost:2379")
ETCD_TTL = int(os.getenv("ETCD_TTL", "600"))

def get_repo_root() -> str:
    """
    Returns the absolute path to the root of the repository
    specific to the system the code is run on.
    """
    return os.path.dirname(os.path.dirname(os.path.realpath(__file__))) + "/"
