# pylint: disable=protected-access, missing-module-docstring, missing-class-docstring, missing-function-docstring

import ast
import os

import pytest

import numpy as np

from app.processors.default import DefaultProcessor
from app.data_handler.verifier_provider import VerifierProvider

import app.config as cfg

#############################################################
# 3 Fixtures
# 1. Default Processor, all config settings
# 2. Message from DM, modify visible edges
# 3. Message from ED, modify image-path
#############################################################
CAMERA = os.path.dirname(__file__).split("/")[-1]

@pytest.fixture(name="default_processor")
def fixture_default_processor():
    """Test case configurion goes here"""
    cfg.CAMERA_ID = CAMERA
    cfg.LOCATION_ID = "aal"
    cfg.HALL_ID = "hall10"
    cfg.MOULD_ID = "b9701u2"

    cfg.DATA_PATH = os.path.join("tests", "test_resources")
    cfg.INPUT_PATH = os.path.join("tests", "test_resources", cfg.MOULD_ID, "images", cfg.CAMERA_ID)
    cfg.OUTPUT_PATH = os.path.join(cfg.DATA_PATH, "plot_output")
    cfg.GROUNDTRUTH_PATH = cfg.DATA_PATH

    cfg.SAVE_PLOTS = True
    cfg.MIN_RANGE_THRESHOLD_FACTOR = 0.4
    cfg.BAD_RANGE_THRESHOLD = 0.45

    cfg.TOLERANCE = 30
    cfg.REGION_OF_VERIFICATION = 20
    cfg.REDUCE_MASK_BY = 350
    cfg.NOISE_SIZE_THRESHOLD = 4000

    cfg.FF_ENABLE_1ST_EDGE_ONLY = False

    verifier_provider = VerifierProvider()
    team_instructions = {
        "groundTruthVersion": "v0.0.1",
        "mouldId": cfg.MOULD_ID,
        "bladeSn": "sn-2022-01-01",
        "bladeRevision": "b97-00",
        "layers": ["090_B97-00_LP_Outer_B1_1-288"]
    }
    verifier_provider.update(team_instructions)
    verifier_provider.get().tolerance              = cfg.TOLERANCE
    verifier_provider.get().region_of_verification = cfg.REGION_OF_VERIFICATION
    verifier_provider.get().noise_size_threshold   = cfg.NOISE_SIZE_THRESHOLD
    verifier_provider.get().reduce_mask_by         = cfg.REDUCE_MASK_BY    
    processor = DefaultProcessor(verifier_provider)
    return processor

@pytest.fixture(name="dm_message")
def yield_visible_plies():
    message = {
    cfg.CAMERA_ID: {
        "detectedEdges": [
            "090_B97-00_LP_Outer_B1_1-288_130000130_1",
            "090_B97-00_LP_Outer_B1_1-288_131000131_1",
            "090_B97-00_LP_Outer_B1_1-288_139000139_1",
            "090_B97-00_LP_Outer_B1_1-288_140000140_1",
            "090_B97-00_LP_Outer_B1_1-288_147000147_1",
            "090_B97-00_LP_Outer_B1_1-288_147000147_2",
            ]
        }
    }
    return message

@pytest.fixture(name="ed_message")
def yield_ed_message():
    message = {
        "data": {
            "session": {
            },
            "images": [
            {
                "location": "cam-008-b1-raw.jpg",
                "metadata": {
                "camera-id": cfg.CAMERA_ID,
                "capture-timestamp": "2020-06-22T13:00:01Z"
                }
            }
            ]
        }
    }
    return message

@pytest.mark.on_demand
def test_run(default_processor, dm_message, ed_message):
    # build sample message

    # run preprocessor, processor, postprocessor
    default_processor.set_edges(dm_message[cfg.CAMERA_ID])
    result, _ = default_processor.run(ed_message['data'])

    ######################################################
    # Check function inference results
    ######################################################
    result = ast.literal_eval(result)
    detected_edges = result['feedback'][0]['edges']
    missing_edges = result['feedback'][1]['edges']
    assert "090_B97-00_LP_Outer_B1_1-288_130000130_1" in detected_edges
    assert "090_B97-00_LP_Outer_B1_1-288_131000131_1" in detected_edges
    assert "090_B97-00_LP_Outer_B1_1-288_139000139_1" in detected_edges
    assert "090_B97-00_LP_Outer_B1_1-288_140000140_1" in detected_edges
    assert "090_B97-00_LP_Outer_B1_1-288_147000147_1" in detected_edges
    assert "090_B97-00_LP_Outer_B1_1-288_147000147_2" in detected_edges
    assert "090_B97-00_LP_Outer_B1_1-288_147000147_2" not in missing_edges
