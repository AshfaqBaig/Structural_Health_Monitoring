# pylint: disable=protected-access, missing-module-docstring, missing-class-docstring, missing-function-docstring

import ast
import os

import pytest

import numpy as np

from app.processors.default import DefaultProcessor
from app.data_handler.verifier_provider import VerifierProvider

import app.config as cfg

#############################################################
# 3 Fixtures
# 1. Default Processor, all config settings
# 2. Message from DM, modify visible edges
# 3. Message from ED, modify image-path
#############################################################
CAMERA = os.path.dirname(__file__).split("/")[-1]

@pytest.fixture(name="default_processor")
def fixture_default_processor():
    """Test case configurion goes here"""
    cfg.CAMERA_ID = CAMERA
    cfg.LOCATION_ID = "aal"
    cfg.HALL_ID = "hall10"
    cfg.MOULD_ID = "b9702u1"

    cfg.DATA_PATH = os.path.join("tests", "test_resources")
    cfg.INPUT_PATH = os.path.join("tests", "test_resources", cfg.MOULD_ID, "images", cfg.CAMERA_ID)
    cfg.OUTPUT_PATH = os.path.join(cfg.DATA_PATH, "plot_output")
    cfg.GROUNDTRUTH_PATH = cfg.DATA_PATH

    cfg.SAVE_PLOTS = True
    cfg.MIN_RANGE_THRESHOLD_FACTOR = 0.9
    cfg.BAD_RANGE_THRESHOLD = 0.45

    cfg.TOLERANCE = 30
    cfg.REDUCE_MASK_BY = 350
    cfg.NOISE_SIZE_THRESHOLD = 4000
    cfg.REGION_OF_VERIFICATION = 20

    cfg.FF_ENABLE_1ST_EDGE_ONLY = False

    verifier_provider = VerifierProvider()

    cfg.CAMERA_ID = "aal-b9702u1-cam013"

    team_instructions = {
        "groundTruthVersion": "v0.0.1",
        "mouldId": cfg.MOULD_ID,
        "bladeSn": "sn-2022-01-01",
        "bladeRevision": "b97-00",
        "layers": ["410_B97-00_LP_INNER_B2_1-50"]
    }
    verifier_provider.update(team_instructions)

    cfg.CAMERA_ID = "aal-b9702u1-cam015"

    team_instructions = {
        "groundTruthVersion": "v0.0.1",
        "mouldId": cfg.MOULD_ID,
        "bladeSn": "sn-2022-01-01",
        "bladeRevision": "b97-00",
        "layers": ["410_B97-00_LP_INNER_B2_1-50", "420_B97-00_LP_INNER_UD2_1-352"]
    }
    verifier_provider.update(team_instructions)
    verifier_provider.get().tolerance              = cfg.TOLERANCE
    verifier_provider.get().region_of_verification = cfg.REGION_OF_VERIFICATION
    verifier_provider.get().noise_size_threshold   = cfg.NOISE_SIZE_THRESHOLD
    verifier_provider.get().reduce_mask_by         = cfg.REDUCE_MASK_BY
    processor = DefaultProcessor(verifier_provider)
    return processor

@pytest.fixture(name="dm_message")
def yield_visible_plies():
    message = {
    cfg.CAMERA_ID: {
        "detectedEdges": [
            "090_B97-00_LP_Outer_B1_1-288_038000038_2",
            "090_B97-00_LP_Outer_B1_1-288_039000039_2",
            "090_B97-00_LP_Outer_B1_1-288_040000040_1",
            "090_B97-00_LP_Outer_B1_1-288_050000050_1",
            "130_B97-00_LP_Outer_UD1_1-352_019000019_2"
            ],
        "missingEdges": [
            ]
        }
    }
    return message


def test_run(default_processor, dm_message):
    # build sample message

    # run preprocessor, processor, postprocessor
    default_processor.set_edges(dm_message[cfg.CAMERA_ID])
    assert default_processor
