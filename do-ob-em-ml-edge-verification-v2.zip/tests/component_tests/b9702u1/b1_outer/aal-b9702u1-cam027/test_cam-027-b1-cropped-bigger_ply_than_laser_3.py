# pylint: disable=protected-access, missing-module-docstring, missing-class-docstring, missing-function-docstring

import ast
import os

import pytest

import numpy as np

from app.processors.default import DefaultProcessor
from app.data_handler.verifier_provider import VerifierProvider

import app.config as cfg

#############################################################
# 3 Fixtures
# 1. Default Processor, all config settings
# 2. Message from DM, modify visible edges
# 3. Message from ED, modify image-path
#############################################################
CAMERA = os.path.dirname(__file__).split("/")[-1]

@pytest.fixture(name="default_processor")
def fixture_default_processor():
    """Test case configurion goes here"""
    cfg.CAMERA_ID = CAMERA
    cfg.LOCATION_ID = "aal"
    cfg.HALL_ID = "hall10"
    cfg.MOULD_ID = "b9702u1"

    cfg.DATA_PATH = os.path.join("tests", "test_resources")
    cfg.INPUT_PATH = os.path.join("tests", "test_resources", cfg.MOULD_ID, "images", cfg.CAMERA_ID)
    cfg.OUTPUT_PATH = os.path.join(cfg.DATA_PATH, "plot_output")
    cfg.GROUNDTRUTH_PATH = cfg.DATA_PATH

    cfg.SAVE_PLOTS = True
    cfg.MIN_RANGE_THRESHOLD_FACTOR = 0.9
    cfg.BAD_RANGE_THRESHOLD = 0.45

    cfg.TOLERANCE = 25
    cfg.REDUCE_MASK_BY = 10
    cfg.NOISE_SIZE_THRESHOLD = 1000
    cfg.REGION_OF_VERIFICATION = 30

    cfg.FF_ENABLE_1ST_EDGE_ONLY = False

    verifier_provider = VerifierProvider()
    team_instructions = {
        "groundTruthVersion": "v0.0.1",
        "mouldId": cfg.MOULD_ID,
        "bladeSn": "sn-2022-01-01",
        "bladeRevision": "b97-00",
        "layers": ["090_B97-00_LP_Outer_B1_1-288"]
    }
    verifier_provider.update(team_instructions)
    verifier_provider.get().tolerance              = cfg.TOLERANCE
    verifier_provider.get().region_of_verification = cfg.REGION_OF_VERIFICATION
    verifier_provider.get().noise_size_threshold   = cfg.NOISE_SIZE_THRESHOLD
    verifier_provider.get().reduce_mask_by         = cfg.REDUCE_MASK_BY    
    processor = DefaultProcessor(verifier_provider)
    return processor

@pytest.fixture(name="dm_message")
def yield_visible_plies():
    message = {
    cfg.CAMERA_ID: {
        "detectedEdges": [
            ],
        "missingEdges": [
            "090_B97-00_LP_Outer_B1_1-288_281000281_1",
            "090_B97-00_LP_Outer_B1_1-288_282000282_1",
            "090_B97-00_LP_Outer_B1_1-288_282000282_2",
            "090_B97-00_LP_Outer_B1_1-288_283000283_1",
            "090_B97-00_LP_Outer_B1_1-288_283000283_2",
            "090_B97-00_LP_Outer_B1_1-288_284000284_1",
            "090_B97-00_LP_Outer_B1_1-288_284000284_2",
            "090_B97-00_LP_Outer_B1_1-288_285000285_1",
            "090_B97-00_LP_Outer_B1_1-288_286000286_1",
        ]
        }
    }
    return message

@pytest.fixture(name="ed_message")
def yield_ed_message():
    message = {
        "data": {
            "session": {
            },
            "images": [
            {
                "location": "cam-027-b1-cropped-bigger_ply_than_laser_3.jpg",
                "metadata": {
                "camera-id": cfg.CAMERA_ID,
                "capture-timestamp": "2020-06-22T13:00:01Z"
                }
            }
            ]
        }
    }
    return message

@pytest.mark.on_demand
def test_run(default_processor, dm_message, ed_message):
    # build sample message

    # run preprocessor, processor, postprocessor
    default_processor.set_edges(dm_message[cfg.CAMERA_ID])
    result, _ = default_processor.run(ed_message['data'])

    ######################################################
    # Check function inference results
    ######################################################
    result = ast.literal_eval(result)
    _ = result['feedback'][0]['edges']
    _ = result['feedback'][1]['edges']
    assert result
