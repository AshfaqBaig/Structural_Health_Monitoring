# pylint: disable=protected-access, missing-class-docstring, missing-function-docstring, no-self-use

import pytest

import app.config as cfg
from app.processors.postprocessor import ResponsePostprocessor


@pytest.fixture(name="postprocessor_instance", scope="session")
def fixture_postprocessor_instance():
    instance = ResponsePostprocessor()
    return instance

@pytest.fixture(name="results")
def result_fixture():
    results = {"P0_1": cfg.OK_STATUS,
               "P0_2": cfg.OK_STATUS,

               "P1_1": cfg.OK_STATUS,
               "P1_2": cfg.NOT_DETECTED_STATUS,

               "P2_1": cfg.NOT_OK_STATUS,
               "P2_2": cfg.NOT_DETECTED_STATUS,

               "P3_1": cfg.NOT_OK_STATUS,
               "P3_2": cfg.OK_STATUS,

               "P4_1": cfg.OK_STATUS,

               "P5_2": cfg.OK_STATUS,

               "P6_2": cfg.NOT_OK_STATUS,

               "P7_1": cfg.OK_STATUS,
                }
    return results

def test_assign_edges_to_ok_and_not_ok_ff_true(postprocessor_instance, results):
    # GIVEN
    postprocessor_instance.set_enable_1st_edge_only(True)
    # WHEN
    result = postprocessor_instance.assign_edges_to_ok_and_not_ok(results)
    # THEN
    assert isinstance(result, tuple)
    assert isinstance(result[0], set)
    assert isinstance(result[1], set)
    assert len(result) == 2
    detected_edges, missing_edges = result
    assert detected_edges == {"P0_1", "P0_2", "P1_1", "P1_2", "P4_1", "P5_2", "P7_1"}
    assert missing_edges == {"P2_1", "P2_2", "P3_1", "P3_2", "P6_2"}

def test_assign_edges_to_ok_and_not_ok_ff_false(postprocessor_instance, results):
    # GIVEN
    postprocessor_instance.set_enable_1st_edge_only(False)
    # WHEN
    detected_edges, missing_edges = postprocessor_instance.assign_edges_to_ok_and_not_ok(results)
    # THEN
    assert detected_edges == {"P0_1", "P0_2", "P1_1", "P3_2", "P4_1", "P5_2", "P7_1"}
    assert missing_edges == {"P1_2", "P2_1", "P2_2", "P3_1", "P6_2"}

def test_make_response_create_dm_feedback_type_items_when_given_edges_empty(postprocessor_instance):
    # GIVEN
    payload = {"session": {"moduleId": ""}}
    detected_edges = set()
    missing_edges = set()
    # WHEN
    result = postprocessor_instance.make_response_for_dm(payload, detected_edges, missing_edges)
    # THEN
    assert isinstance(result, dict)
    assert result["session"]["moduleId"] == "edge-verification"
    expected_feedback = [
        {
            "type": "detected-edges",
            "edges": list(detected_edges),
        },
        {
            "type": "missing-edges",
            "edges": list(missing_edges),
        },
    ]
    assert result["feedback"] == expected_feedback


def test_make_response_create_dm_feedback_type_items_when_detected_and_missing_edges_given(
        postprocessor_instance):
    # GIVEN
    payload = {"session": {"moduleId": ""}}
    detected_edges = {"P0_1", "P0_2", "P1_1", "P3_2"}
    missing_edges = {"P1_2", "P2_1", "P2_2", "P3_1"}
    # WHEN
    result = postprocessor_instance.make_response_for_dm(payload, detected_edges, missing_edges)
    # THEN
    assert isinstance(result, dict)
    assert result["session"]["moduleId"] == "edge-verification"
    expected_feedback = [
        {
            "type": "detected-edges",
            "edges": list(detected_edges),
        },
        {
            "type": "missing-edges",
            "edges": list(missing_edges),
        },
    ]
    assert result["feedback"] == expected_feedback


def test_make_response_create_dm_feedback_type_items_when_only_detected_edges_given(
        postprocessor_instance):
    # GIVEN
    payload = {"session": {"moduleId": ""}}
    detected_edges = {"P0_1", "P0_2", "P1_1", "P3_2"}
    missing_edges = set()
    # WHEN
    result = postprocessor_instance.make_response_for_dm(payload, detected_edges, missing_edges)
    # THEN
    assert isinstance(result, dict)
    assert result["session"]["moduleId"] == "edge-verification"
    expected_feedback = [
        {
            "type": "detected-edges",
            "edges": list(detected_edges),
        },
        {
            "type": "missing-edges",
            "edges": list(missing_edges),
        },
    ]
    assert result["feedback"] == expected_feedback


def test_make_response_create_dm_feedback_type_items_when_only_missing_edges_given(
        postprocessor_instance):
    # GIVEN
    payload = {"session": {"moduleId": ""}}
    detected_edges = set()
    missing_edges = {"P1_2", "P2_1", "P2_2", "P3_1"}
    # WHEN
    result = postprocessor_instance.make_response_for_dm(payload, detected_edges, missing_edges)
    # THEN
    assert isinstance(result, dict)
    assert result["session"]["moduleId"] == "edge-verification"
    expected_feedback = [
        {
            "type": "detected-edges",
            "edges": list(detected_edges),
        },
        {
            "type": "missing-edges",
            "edges": list(missing_edges),
        },
    ]
    assert result["feedback"] == expected_feedback

def test_make_response_create_dcm_feedback_when_only_missing_edges_given(postprocessor_instance):
    # GIVEN
    payload = {"session": {"moduleId": ""}}
    results = {"P1_2": cfg.NOT_DETECTED_STATUS,
               "P2_2": cfg.NOT_DETECTED_STATUS,
              }
    # WHEN
    result = postprocessor_instance.make_response_for_dcm(results, payload)
    # THEN
    assert isinstance(result, dict)
    assert result["session"]["moduleId"] == "edge-verification"
    expected_feedback = {'P1_2': 'not enough px', 'P2_2': 'not enough px'}
    assert result["feedback"] == expected_feedback

def test_make_response_create_dcm_feedback_when_only_detected_edges_given(postprocessor_instance):
    # GIVEN
    payload = {"session": {"moduleId": ""}}
    results = {"P1_2": cfg.OK_STATUS,
               "P2_2": cfg.OK_STATUS,
              }
    # WHEN
    result = postprocessor_instance.make_response_for_dcm(results, payload)
    # THEN
    assert isinstance(result, dict)
    assert result["session"]["moduleId"] == "edge-verification"
    expected_feedback = {'P1_2': 'ok', 'P2_2': 'ok'}
    assert result["feedback"] == expected_feedback    

def test_make_response_create_dcm_feedback_when_no_feedback(postprocessor_instance):
    # GIVEN
    payload = {"session": {"moduleId": ""}}
    results = {}
    # WHEN
    result = postprocessor_instance.make_response_for_dcm(results, payload)
    # THEN
    assert isinstance(result, dict)
    assert result["session"]["moduleId"] == "edge-verification"
    expected_feedback = {}
    assert result["feedback"] == expected_feedback        


def test_run(postprocessor_instance, results):
    # GIVEN
    payload = {"session": {"moduleID": "EV"}}
    # WHEN
    result_dm, result_dcm  = postprocessor_instance.run(payload, results)
    # THEN
    assert result_dm['session'] == {'moduleID': 'EV', 'moduleId': 'edge-verification'}
    assert 'type' in result_dm['feedback'][0]
    assert 'type' in result_dm['feedback'][1]
