# pylint: disable=protected-access, missing-class-docstring, missing-function-docstring, no-self-use
import datetime
import logging

import pytest

import app.config as cfg

from app.config import get_repo_root
from app.processors.preprocessor import RequestPreprocessor

@pytest.fixture(name="config_setup")
def config_setup():
    # Ensure Debug Level, so logging is caught
    cfg.LOG_LEVEL = 'DEBUG'
    logging.getLogger(cfg.MODULE_APP_NAME).setLevel('DEBUG')
    cfg.INPUT_PATH = get_repo_root()
    return cfg

@pytest.fixture(name="preprocessor_instance")
def fixture_setup(config_setup):
    assert config_setup
    preprocessor_obj = RequestPreprocessor()
    return preprocessor_obj

@pytest.fixture(name="dateformat_from_ed")
def fixture_dateformat_from_ed():
    """ Fixture stores assumption on incoming date format """
    return datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')

@pytest.fixture(name="payload")
def fixture_payload(dateformat_from_ed):
    return {
        "images": [
            {
                "location": "cam-001.jpg",
                "metadata": {
                    "capture-timestamp": dateformat_from_ed
                }
            }
        ]
    }


def test_extract_data_from_payload(preprocessor_instance, payload):
    # GIVEN
    inp_val = payload
    # WHEN
    image_filename = preprocessor_instance.extract_data_from_payload(inp_val)
    # THEN
    assert isinstance(image_filename, str)
    assert image_filename == "cam-001.jpg"

def test_get_image_filename(preprocessor_instance):
    # GIVEN
    inp_val = "abc.jpg"
    # WHEN
    image_filename = preprocessor_instance.get_image_filename(inp_val)
    # THEN
    assert image_filename == "abc"

def test_load_image_from_disk_sad_path(caplog, preprocessor_instance):
    # GIVEN
    path = "a.i"
    # WHEN
    result = preprocessor_instance.load_image_from_disk(path)
    # THEN
    assert result is None
    assert "File a.i doesn't exist" in caplog.text

def test_load_image_from_disk_happy_path(tmpdir, caplog, preprocessor_instance):
    # GIVEN
    with open(f"{tmpdir}/a.i", "w") as fh:
        fh.write("[0,1,1,1,0]")
    path = f"{tmpdir}/a.i"
    # WHEN
    preprocessor_instance.load_image_from_disk(path)
    # THEN
    assert caplog.text == ""


def test_run_missing_img(caplog, payload, preprocessor_instance):
    # GIVEN
    inp_val = payload
    inp_val["images"][0]["metadata"]["capture-timestamp"] = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    # WHEN
    preprocessor_instance.run(inp_val)
    # THEN
    assert "do-ob-em-ml-edge-verification-v2/cam-001.jpg doesn't exist" in caplog.text
    assert preprocessor_instance.image_filename is not None

def test_run_complete(tmpdir, payload, preprocessor_instance):
    # GIVEN
    inp_val = payload
    inp_val["images"][0]["metadata"]["capture-timestamp"] = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    with open(f"{tmpdir}/a.i", "w") as fh:
        fh.write("[0,1,1,1,0]")
    path = f"{tmpdir}/a.i"

    inp_val["images"][0]["location"] = path
    # WHEN
    preprocessor_instance.run(inp_val)
    # THEN
    assert preprocessor_instance.image_filename is not None
