# pylint: disable=protected-access, missing-class-docstring, missing-function-docstring, no-self-use
import numpy as np

import pytest

from app.processors.verifier import Verifier
import app.config as cfg

@pytest.fixture(name="verifier_instance")
def provide_verifier():
    verifier_instance = Verifier({"c1": {"orientation": "lat", "pixels_per_mm_along_coverage": 1}}, {}, "c1")
    return verifier_instance

@pytest.mark.parametrize(
    "cond_1, cond_2, cond_3, expectation",
    [
        (True,  False, False, cfg.NOT_DETECTED_STATUS),
        (True,  True,  False, cfg.NOT_DETECTED_STATUS),
        (False, True,  False, cfg.MIN_RANGE_STATUS),
        (False, False, True,  cfg.BAD_RANGE_STATUS),
        (False, False, False, "unknown"),
    ],
)
def test_obtain_status(cond_1, cond_2, cond_3, expectation, verifier_instance):
    """ Tests obtain_status function"""
    assert verifier_instance.obtain_status(cond_1, cond_2, cond_3) == expectation

def test_get_range(verifier_instance):
    """ Tests get_range function"""
    x_detected = np.array([1,2,3,4])
    x_range, shared_points = verifier_instance.get_range(x_detected)
    assert len(x_range) == 4
    assert np.allclose(shared_points, 1.0)

    x_detected = np.array([1])
    x_range, shared_points = verifier_instance.get_range(x_detected)
    assert len(x_range) == 1
    assert np.allclose(shared_points, 1.0)

    x_detected = np.array([])
    x_range, shared_points = verifier_instance.get_range(x_detected)
    assert len(x_range) == 0
    assert np.allclose(shared_points, 0.0)

    x_detected = np.array([1, 3, 4])
    x_range, shared_points = verifier_instance.get_range(x_detected)
    assert len(x_range) == 4
    assert np.allclose(shared_points, 0.75)

def test_get_mask(verifier_instance):
    """ Test get_mask function """
    x_detected = np.array([1,2,3])
    polygon = 1
    mask = verifier_instance.get_mask(x_detected, polygon)
    assert mask == cfg.NOT_DETECTED_STATUS

    x_detected = np.random.rand(300,200)
    polygon = np.array(
        [
            [3, -1],
            [5, -1],
            [4, 3]
        ]
    )
    cfg.REDUCE_MASK_BY = 1
    mask = verifier_instance.get_mask(x_detected, polygon)
    assert isinstance(mask, np.ndarray)

def test_get_tolerance_val(verifier_instance):
    """ Test verifier function """
    # GIVEN
    cfg.TOLERANCE_FACTOR = 1.15
    verifier_instance.tolerance = 30
    # WHEN
    tolerance_detected = verifier_instance.get_tolerance_val(cfg.DETECTED_EDGE)
    tolerance_missing  = verifier_instance.get_tolerance_val(cfg.MISSING_EDGE)
    # THEN
    # We want to assert that detected plies are treated more lavishly
    assert tolerance_detected >= tolerance_missing

def test_get_region_of_verification_val(verifier_instance):
    """ Test to validate Verifier.get_region_of_verification_val """
    # setup:
    cfg.REGION_OF_VERIFICATION_FACTOR = 1.35
    verifier_instance.region_of_verification = 20

    rov_detected = verifier_instance.get_region_of_verification_val(cfg.DETECTED_EDGE)
    rov_missing  = verifier_instance.get_region_of_verification_val(cfg.MISSING_EDGE)

    assert rov_detected == 27
    assert rov_missing == 20
    assert rov_detected >= rov_missing

@pytest.mark.parametrize(
    "detected, missing, edgedata, expectation",
    [
        ([], [], {}, True),
        (["1"], ["2"], {"1": "_", "2": "_"}, True),
        (["1"], ["2"], {"2": "_"}, False),
        (["1"], ["2"], {"1": "_"}, False),
    ],
)
def test_check_data_consistency(verifier_instance, detected, missing, edgedata, expectation, caplog):
    # GIVEN
    # mark.parametrize
    # WHEN
    result = verifier_instance.check_data_consistency(detected, missing, edgedata)
    # THEN
    assert result == expectation
    if result is False:
        assert "Not all edges (from DM) have corresponding data in " in caplog.text

@pytest.mark.parametrize(
    "input_, expectation",
    [
        ((6480, 4860), True),
        ((4860, 6480), True),
        ((1, 4860), False)
    ],
)
def test_infer_image_status(verifier_instance, input_, expectation, caplog):
    # GIVEN
    detections_image = np.zeros(input_)
    # WHEN
    verifier_instance.infer_image_status(detections_image)
    # THEN
    assert verifier_instance.ff_complete_image is expectation
    if expectation is True:
        assert "Automatically inferring: uncropped image" in caplog.text
    if expectation is False:
        assert " Automatically inferring: cropped image" in caplog.text

@pytest.mark.parametrize(
    "input_, expectation",
    [
        (
            [
            ('ok', {'edge_id': '090_B97-00_LP_Outer_B1_1-288_286000286_1', 'edge_orientation': 'lat', 'edge_type': 'detected'}),
            ('not enough px', {'edge_id': '090_B97-00_LP_Outer_B1_1-288_286000286_2', 'edge_orientation': 'lat', 'edge_type': 'detected'}),
            ('ok', {'edge_id': '090_B97-00_LP_Outer_B1_1-288_287000287_1', 'edge_orientation': 'lat', 'edge_type': 'detected'})
            ],
            {'090_B97-00_LP_Outer_B1_1-288_286000286_1': 'ok',
             '090_B97-00_LP_Outer_B1_1-288_286000286_2': 'not enough px',
             '090_B97-00_LP_Outer_B1_1-288_287000287_1': 'ok'}
        ),
        (
            [],
            {}
        )
    ]
)
def test_create_and_log_edge_status(verifier_instance, input_, expectation):
    # GIVEN
    # mark.parametrize
    # WHEN
    result = verifier_instance.create_and_log_edge_status(input_)
    # THEN
    for k, v in expectation.items():
        assert result[k] == v
