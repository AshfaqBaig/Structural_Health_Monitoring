# pylint: disable=protected-access, missing-class-docstring, missing-function-docstring, no-self-use
import logging
import pytest

from app.utils.log_metrics import log_metrics
import app.config as cfg

@pytest.mark.parametrize("metrics, expected", [
   ({"edge_id": "202000202"}, f"{'Metrics logging for edge_id': <46}: 202000202"),
   ({"edge_type": "missing"}, f"{'Metrics type': <46}: missing"),
   ({"detected_points": 5}, f"{'Detected pixels (3)': <46}: 5"),
   ({"used_rov": 20}, f"{'Applied RoV value (1)': <46}: 20"),
   ({"used_tolerance":  20}, f"{'Applied Tolerance value (2)': <46}: 20"),
   ({"x_range_to_min_range":  20}, f"{'X-axis-range/min-range (4)': <46}: 20"),
   ({"pixel_population":  20.0}, f"{'Pixel population (5)': <46}: 20.0"),
   ({"no_outside_points_above_0":  20}, f"{'Number of outside points > 0': <46}: 20"),
   ({"no_outside_points_below_0":  20}, f"{'Number of outside points < 0': <46}: 20"),
   ({"edge_verification_duration":  20}, f"{'Duration on thread (sec)': <46}: 20"),
])
def test_log_metrics(caplog, metrics, expected):
    # Ensure Debug Level, so logging is caught
    caplog.set_level(logging.DEBUG, logger="edge-verification")
    cfg.LOG_LEVEL = 'DEBUG'
    logging.getLogger(cfg.MODULE_APP_NAME).setLevel('DEBUG')

    # Given
    # When
    log_metrics(metrics)
    # Then
    assert expected in caplog.text
