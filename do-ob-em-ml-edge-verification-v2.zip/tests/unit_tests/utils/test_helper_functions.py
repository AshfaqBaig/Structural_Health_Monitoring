# pylint: disable=protected-access, missing-class-docstring, missing-function-docstring, no-self-use
import pytest

import numpy as np
np.random.seed(10)

from app.utils.helper_functions import create_polygon_around_line, fit_ci, \
    img2points, get_points_outside, convert_from_gid_to_pid, convert_from_pid_to_gid


def test_fit_ci():
    ###############################################################
    # Set up example data
    x = np.random.randint(10, size=500)
    y = 20 - 3 * x + 2 * x ** 2 - 10 * np.random.randint(4, size=500)
    polynomial_degree = 11
    ###############################################################
    # The following test-case compares the sklearn approach with the current one
    y_pred, pif, r2 = fit_ci(x, y, poly_degree=polynomial_degree)
    assert len(y_pred) == polynomial_degree
    assert len(pif) == polynomial_degree
    assert np.allclose(r2, 0.9483, atol=0.1)

    ###############################################################
    # Test yerr-function
    ###############################################################    
    y_pred, pif, r2 = fit_ci(x, y, poly_degree=polynomial_degree, yerr=[1 for _ in range(len(x))])

def test_get_points_outside():
    ###############################################################
    # Set up example data
    points = np.array([-10, -10, -10])
    pi_smoothed = np.array([1, 2, 3])
    total_tolerance = 2
    ###############################################################
    # Test
    assert get_points_outside(points, pi_smoothed, total_tolerance) == (3, 0)

    ###############################################################
    # Set up example data
    points = np.array([1, 1, -10])
    pi_smoothed = np.array([1, 2, 3])
    total_tolerance = 2
    ###############################################################
    # Test
    assert get_points_outside(points, pi_smoothed, total_tolerance) == (1, 0)


def test_img2points():
    bin_img = np.array([[0, 0, 1],
                        [1, 1, 0]])
    x1, y1 = img2points(bin_img)

    bin_img = np.array([[1, 1, 0],
                        [0, 0, 1]])
    x2, y2 = img2points(bin_img)

    assert x1.shape == (3,)
    assert np.array_equal(x1, x2)
    assert np.array_equal(x1, np.array([0, 1, 2]))
    assert np.array_equal(y1, np.array([1, 1, 0]))
    assert np.array_equal(y2, np.array([0, 0, 1]))


def test_create_polygon_around_line():
    ###############################################################
    # Set up example data
    x_gt = np.array([3, 2, 5])
    yf_gt = np.poly1d(np.arange(1))
    pi_gt = np.poly1d(np.arange(1))
    polygon_step = 2
    reduced_extraction = 1
    tube_size = 1.0
    ###############################################################
    # Test
    actual = create_polygon_around_line(
        x_gt,
        yf_gt,
        pi_gt,
        polygon_step,
        reduced_extraction,
        tube_size
    )
    expected = np.array(
        [
            [3, -1],
            [5, -1],
            [4, 1]
        ]
    )
    assert len(actual) == len(expected)
    assert all([np.array_equal(a, b) for a, b in zip(actual, expected)])
    ###############################################################
    # Set up example data
    x_gt = np.array([5, 2, 3])
    yf_gt = np.poly1d(np.arange(2))
    pi_gt = np.poly1d(np.arange(2))
    polygon_step = 2
    reduced_extraction = 1
    tube_size = 1.5
    ################################################################
    # Test
    actual = create_polygon_around_line(
        x_gt,
        yf_gt,
        pi_gt,
        polygon_step,
        reduced_extraction,
        tube_size
    )
    expected = np.array(
        [
            [3, -1],
            [5, -1],
            [4, 3]
        ]
    )
    assert len(actual) == len(expected)
    assert all([np.array_equal(a, b) for a, b in zip(actual, expected)])

@pytest.mark.parametrize("input_, expected", [
   (None, None),
   ("288_187000187_2", "288_187000187_2"),
   ("288_001000001_2", "288_001000001_2"),
   ("187000187_2", "187000187_2"),
   ("090_B97-00_LP_Outer_B1_", "090_B97-00_LP_Outer_B1_"),
   ("288_001000001_2", "288_001000001_2"),
   ('090_B97-00_LP_Outer_B1_1-288_038000038_2', "B1_038_2"),
   ('130_B97-00_LP_Outer_UD1_1-352_038000038_2', "UD1_038_2")
])
def test_convert_from_gid_to_pid(input_, expected):
    # Given "input_", When
    result = convert_from_gid_to_pid(input_)
    # Then
    assert result == expected

@pytest.mark.parametrize("input_, expected", [
   (288, "000288000"),
   ("288", "000288000"),
   (None, None)
])
def test_convert_from_pid_to_gid(input_, expected):
    # Given "input_", When
    result = convert_from_pid_to_gid(input_)
    # Then
    assert result == expected
