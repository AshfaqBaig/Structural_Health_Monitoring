# pylint: disable=protected-access
import os
import cv2

import pytest
import numpy as np
import matplotlib.pyplot as plt

from app.utils.plot_util import PlottingUtil

@pytest.fixture(name="info")
def fixture_info():
    """ Fixture to mock info dictionary """
    return {
        "plots_output_filepath": "some file path",
        "edge_id": "some edge id",
        "data_type": "detections",
        "r2": 5,
        "tolerance": 30,
        "zero_line": True,
        "title": "some title"
    }


@pytest.fixture(name="plot_util_obj")
def fixture_plot_util_obj():
    """ Fixture to mock an object of class PlottingUtil """
    return PlottingUtil()

def test_set_plot_dimensions(plot_util_obj: PlottingUtil):
    """ Function to test PlottingUtil._set_plot_dimensions """
    some_fig, _ = plt.subplots()
    plot_util_obj._set_plot_dimensions(some_fig, 10)

    assert some_fig.get_size_inches()[0] == 10
    assert some_fig.get_size_inches()[1] == 10

def test_save_plot(mocker, info: dict, plot_util_obj: PlottingUtil):
    """ Function to test PlottingUtil.save_plot """
    some_fig, _ = plt.subplots()
    mocked_savefig = mocker.patch("matplotlib.figure.Figure.savefig")
    mocked_join = mocker.patch("os.path.join")
    plot_util_obj._save_plot(some_fig, info)

    assert mocked_savefig.call_count == 1
    assert mocked_join.call_count == 1
    assert mocked_join.call_args.args[0] == "some file path"
    assert mocked_join.call_args.args[1] == "some edge id_fitted_detections.png"

def test_plot_data(mocker, info: dict, plot_util_obj: PlottingUtil):
    """ Function to test PlottingUtil._plot_data """
    mocked_hlines = mocker.patch("matplotlib.axes._axes.Axes.hlines")
    mocked_scatter = mocker.patch("matplotlib.axes._axes.Axes.scatter")
    mocked_plot = mocker.patch("matplotlib.axes._axes.Axes.plot")
    mocked_legend = mocker.patch("matplotlib.axes._axes.Axes.legend")
    plot_util_obj.plot_data(
        np.array([1, 2]), np.array([3, 4]), np.array([1, 4]), np.poly1d([5, 6]), np.poly1d([5, 6]), info
    )

    assert mocked_hlines.call_count == 1
    assert mocked_scatter.call_count == 1
    assert mocked_plot.call_count == 6
    assert mocked_legend.call_count == 1

def test_plot_groundtruth_uv_lines(plot_util_obj: PlottingUtil):
    """ Function to test PlottingUtil._plot_groundtruth_uv_lines """
    image = plot_util_obj.plot_groundtruth_uv_lines(
        np.ones((486, 648, 3)), np.array([1, 2]), np.poly1d([3, 4]), 15
    )
    r, g, b = cv2.split(image)

    assert 160 in r
    assert 232 in g
    assert 343 in b

def test_groundtruth_detected_pixels(plot_util_obj: PlottingUtil):
    """ Function to test PlottingUtil._groundtruth_detected_pixels"""
    image = plot_util_obj.plot_groundtruth_detected_pixels(np.ones((468, 648, 3)), [1, 2], [3, 4])
    r, g, b = cv2.split(image)

    assert 100 in r
    assert 100 in g
    assert 200 in b

def test_save_groundtruth_plot(tmpdir, plot_util_obj: PlottingUtil):
    """ Function to test PlottingUtil._save_groundtruth_plot """
    # GIVEN
    output_path = tmpdir
    # WHEN
    plot_util_obj.save_groundtruth_plot(np.zeros((468, 648, 3)), output_path, "some_edge")
    # THEN
    assert os.path.isfile(os.path.join(tmpdir, "some_edge-with_GT.jpg"))
    assert not os.path.isfile(os.path.join(tmpdir, "some_rubbish-can"))
