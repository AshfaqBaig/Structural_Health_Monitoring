# pylint: disable=protected-access, missing-class-docstring, missing-function-docstring, no-self-use
import os

from app.logging.logger import yield_logger
from app.config import get_repo_root
import app.config as cfg

def test_yield_logger():
    cfg.LOG_LEVEL = 10
    yield_logger(os.path.join(get_repo_root(), "logging-plain.ini"))
    assert True
