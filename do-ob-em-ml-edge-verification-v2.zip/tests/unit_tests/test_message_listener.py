# pylint: disable=missing-class-docstring, missing-function-docstring, protected-access
import json
import logging

from unittest.mock import  MagicMock

import pytest
import pytest_asyncio

from azure.iot.device.aio import IoTHubModuleClient

from app.message_listener import MessageListener
import app.static.routes_constants as routes
import app.config as cfg

@pytest_asyncio.fixture(name="message_listener_mock", scope="function")
def message_listener(mocker):
    cfg.CAMERA_ID = "cam01"
    mocker.patch("azure.iot.device.aio.IoTHubModuleClient.create_from_edge_environment", return_value=IoTHubModuleClient)
    mocker.patch("app.processors.default.DefaultProcessor", return_value=MagicMock)
    mocker.patch("app.data_handler.verifier_provider.VerifierProvider.__init__", return_value=None)
    mocker.patch("app.method_request_handler.MethodRequestHandler.__init__", return_value=None)
    message_listener_instance = MessageListener()
    return message_listener_instance

@pytest.mark.asyncio
async def test_build_message(message_listener_mock):
    # GIVEN
    output_message = {"output": 1}
    correlation_id = "abc"
    custom_properties = ""

    # WHEN
    message = message_listener_mock.build_message(output_message,
                                                      correlation_id,
                                                      custom_properties)
    # THEN
    assert message.correlation_id == "abc"

@pytest.mark.asyncio
async def test_extract_input(message_listener_mock, caplog):
    # Ensure Debug Level, so logging is caught
    caplog.set_level(logging.DEBUG, logger="edge-verification")
    # GIVEN
    message = message_listener_mock.build_message(output_message=json.dumps({"output": 1}),
                                                  correlation_id="abc",
                                                  custom_properties="")

    # WHEN
    with caplog.at_level(logging.DEBUG):
        correlation_id, custom_properties, data = message_listener_mock._extract_input(message)

        # THEN
        expected_log_messages = [
            (
            f"AMQP on Output defaultOutput with following payload "
            f"(correlation_id=abc) sent: {json.dumps({'output': 1})}, custom_properties="
            )
        ]
        for message in expected_log_messages:
            assert message in caplog.text
        assert correlation_id == "abc"
        assert custom_properties == ""
        assert data == {"output": 1}

@pytest.mark.asyncio
async def test_message_handler_on_ed_message(message_listener_mock, caplog):
    # Ensure Debug Level, so logging is caught
    caplog.set_level(logging.DEBUG, logger="edge-verification")

    # GIVEN
    message = message_listener_mock.build_message(output_message=json.dumps({"output": 1}),
                                                  correlation_id='abc',
                                                  custom_properties='custom')
    message.input_name = routes.EDGE_DETECTION_INPUT

    # WHEN
    with caplog.at_level(logging.DEBUG):
        await message_listener_mock.message_handler(message)

        # THEN
        expected_log_messages = [
            (
            f"AMQP on Output {routes.DEFAULT_OUTPUT} with following payload "
            f"(correlation_id=abc) sent: {json.dumps({'output': 1})}, custom_properties=custom"
            )
        ]
        for message in expected_log_messages:
            assert message in caplog.text


@pytest.mark.asyncio
async def test_process_ed_message_with_no_edges_set(message_listener_mock, mocker, caplog):
    # Ensure Debug Level, so logging is caught
    caplog.set_level(logging.DEBUG, logger="edge-verification")
    mocker.patch("azure.iot.device.aio.IoTHubModuleClient.send_message_to_output", return_value=True)

    # GIVEN
    payload = {}
    correlation_id = "x"
    custom_properties = {}

    # WHEN
    with caplog.at_level(logging.DEBUG):
        await message_listener_mock.process_ed_message(payload, correlation_id, custom_properties)

        # THEN
        expected_log_messages = [
            "Dropping request because no edges were provided by DM"
        ]
        for message in expected_log_messages:
            assert message in caplog.text
        assert "Passing output to" not in caplog.text
