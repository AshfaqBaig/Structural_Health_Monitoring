# pylint: disable=protected-access, missing-class-docstring, missing-function-docstring, no-self-use
import os

from contextlib import nullcontext as does_not_raise

import pytest

from app.data_handler.verifier_provider import VerifierProvider
from app.processors.verifier import Verifier
from app.data_handler.team_instructions import TeamInstructions

import app.config as cfg


@pytest.fixture(name="verifier_provider")
def fixture_ground_truth_data_service():
    cfg.DATA_PATH = os.path.join("../", "test_resources", "b9701u2")
    cfg.GROUNDTRUTH_PATH = os.path.join(cfg.DATA_PATH, "work_instructions")
    return VerifierProvider()

@pytest.fixture(name="team_instructions_v1")
def fixture_team_instructions_v1():
    return {
        "groundTruthVersion": "v0.0.1",
        "mouldId": "b9701u2",
        "bladeSn": "sn-2022-01-01",
        "bladeRevision": "b97-00",
        "layers": ["090_B97-00_LP_Outer_B1_1-288"]
    }

@pytest.fixture(name="team_instructions_v2")
def fixture_team_instructions_v2():
    return {
        "groundTruthVersion": "v0.0.2",
        "mouldId": "b9701u2",
        "bladeSn": "sn-2022-01-01",
        "bladeRevision": "b97-00",
        "layers": ["090_B97-00_LP_Outer_B1_1-288"]
    }

@pytest.fixture(name="team_instructions_v3")
def fixture_team_instructions_v3():
    return {
        "groundTruthVersion": "v0.0.3",
        "mouldId": "b9701u2",
        "bladeSn": "sn-2022-01-01",
        "bladeRevision": "b97-00",
        "layers": ["090_B97-00_LP_Outer_B1_1-288", "130_B97-00_LP_Outer_UD1_1-352"]
    }

def test_creation_of_verifier_and_update_with_multiple_layers(mocker, verifier_provider,
                                                         team_instructions_v1, team_instructions_v3):
    # GIVEN
    cfg.CAMERA_ID = "cam01"
    get_camera_properties_mock = mocker.patch(
        "app.data_handler.ground_truth_data_service.GroundTruthDataService.get_camera_properties",
        return_value={cfg.CAMERA_ID: {"orientation": "lat", "pixels_per_mm_along_coverage": 1}})
    get_ev_groundtruth_data_mock = mocker.patch(
        "app.data_handler.ground_truth_data_service.GroundTruthDataService.get_ev_groundtruth_data",
        return_value={cfg.CAMERA_ID: {"edgedata": {}, "metadata": {}}})

    # WHEN verifier_provider.update is called
    verifier_provider.update(team_instructions_v1)
    # When additional layer comes on top
    verifier_provider.update(team_instructions_v3)

    # THEN new verifier instance is created
    assert verifier_provider.active_verifier is not None
    created_verifier = verifier_provider.verifiers[TeamInstructions(team_instructions_v3)]
    assert created_verifier is not None
    assert created_verifier is verifier_provider.active_verifier
    assert len(verifier_provider.verifiers) == 2

    # AND mocks are called with correct argument
    assert get_camera_properties_mock.call_count == 2
    assert get_camera_properties_mock._mock_call_args_list[0].args[0] == TeamInstructions(team_instructions_v1)
    assert get_camera_properties_mock._mock_call_args_list[1].args[0] == TeamInstructions(team_instructions_v3)
    assert get_ev_groundtruth_data_mock.call_count == 2
    assert get_ev_groundtruth_data_mock._mock_call_args_list[0].args[0] == TeamInstructions(team_instructions_v1)
    assert get_ev_groundtruth_data_mock._mock_call_args_list[1].args[0] == TeamInstructions(team_instructions_v3)    

def test_update_should_create_verifier_when_no_verifiers_exist(mocker, verifier_provider,
                                                               team_instructions_v1):
    # GIVEN
    cfg.CAMERA_ID = "cam01"
    get_camera_properties_mock = mocker.patch(
        "app.data_handler.ground_truth_data_service.GroundTruthDataService.get_camera_properties",
        return_value={cfg.CAMERA_ID: {"orientation": "lat", "pixels_per_mm_along_coverage": 1}})
    get_ev_input_mock = mocker.patch(
        "app.data_handler.ground_truth_data_service.GroundTruthDataService.get_ev_groundtruth_data",
        return_value={cfg.CAMERA_ID: {"edgedata": {}, "metadata": {}}})

    # WHEN verifier_provider.update is called
    verifier_provider.update(team_instructions_v1)

    # THEN new verifier instance is created
    assert verifier_provider.active_verifier is not None
    created_verifier = verifier_provider.verifiers[TeamInstructions(team_instructions_v1)]
    assert created_verifier is not None
    assert created_verifier is verifier_provider.active_verifier
    assert len(verifier_provider.verifiers) == 1

    # AND mocks are called with correct argument
    assert get_camera_properties_mock.call_count == 1
    assert get_camera_properties_mock.call_args.args[0] == TeamInstructions(team_instructions_v1)
    assert get_ev_input_mock.call_count == 1
    assert get_ev_input_mock.call_args.args[0] == TeamInstructions(team_instructions_v1)

def test_update_should_create_verifier_when_matching_verifier_not_found(mocker, verifier_provider,
                                                                        team_instructions_v1, team_instructions_v2):
    # GIVEN
    cfg.CAMERA_ID = "cam01"
    verifier_provider.verifiers = {
        TeamInstructions(team_instructions_v1): Verifier({cfg.CAMERA_ID: ""}, {}, camera_id="cam01")
    }
    get_camera_properties_mock = mocker.patch(
        "app.data_handler.ground_truth_data_service.GroundTruthDataService.get_camera_properties",
        return_value={cfg.CAMERA_ID: {"orientation": "lat", "pixels_per_mm_along_coverage": 1}})
    get_ev_input_mock = mocker.patch(
        "app.data_handler.ground_truth_data_service.GroundTruthDataService.get_ev_groundtruth_data",
        return_value={cfg.CAMERA_ID: {"edgedata": {}, "metadata": {}}})

    # WHEN verifier_provider.update is called
    verifier_provider.update(team_instructions_v2)

    # THEN new verifier instance is created
    assert verifier_provider.active_verifier is not None
    created_verifier = verifier_provider.verifiers[TeamInstructions(team_instructions_v2)]
    assert created_verifier is verifier_provider.active_verifier
    assert len(verifier_provider.verifiers) == 2

    # AND mocks are called with correct argument
    assert get_camera_properties_mock.call_count == 1
    assert get_camera_properties_mock.call_args.args[0] == TeamInstructions(team_instructions_v2)
    assert get_ev_input_mock.call_count == 1
    assert get_ev_input_mock.call_args.args[0] == TeamInstructions(team_instructions_v2)

def test_update_should_not_create_verifier_for_existing_team_instructions(mocker, verifier_provider,
                                                                            team_instructions_v1):
    # GIVEN
    cfg.CAMERA_ID = "cam01"
    verifier_provider.verifiers = {
        TeamInstructions(team_instructions_v1): Verifier({cfg.CAMERA_ID: ""}, {}, camera_id=cfg.CAMERA_ID)
    }
    get_camera_properties_mock = mocker.patch(
        "app.data_handler.ground_truth_data_service.GroundTruthDataService.get_camera_properties",
        return_value={cfg.CAMERA_ID: {"orientation": "lat", "pixels_per_mm_along_coverage": 1}})
    get_ev_input_mock = mocker.patch(
        "app.data_handler.ground_truth_data_service.GroundTruthDataService.get_ev_groundtruth_data",
        return_value={cfg.CAMERA_ID: {"edgedata": {}, "metadata": {}}})

    # WHEN verifier_provider.update is called
    verifier_provider.update(team_instructions_v1)

    # THEN new verifier instance is created
    assert verifier_provider.active_verifier is not None
    created_verifier = verifier_provider.verifiers[TeamInstructions(team_instructions_v1)]
    assert created_verifier is not None
    assert created_verifier is verifier_provider.active_verifier
    assert len(verifier_provider.verifiers) == 1

    # AND mocks are called with correct argument
    assert get_camera_properties_mock.call_count == 0
    assert get_ev_input_mock.call_count == 0


def test_check_expected_type():
    test_on_int = 5

    assert VerifierProvider.check_expected_type("test_on_int", test_on_int, int)
    assert not VerifierProvider.check_expected_type("test_on_int", test_on_int, float)

def test_check_expected_range():
    test_on_int = 5

    assert VerifierProvider.check_expected_range("test_on_int", test_on_int, 0, 10)
    assert not VerifierProvider.check_expected_range("test_on_int", test_on_int, 10, 20)
    assert VerifierProvider.check_expected_range("test_on_int", test_on_int)
    assert VerifierProvider.check_expected_range("test_on_int", test_on_int, upper = 5)
    assert VerifierProvider.check_expected_range("test_on_int", test_on_int, lower = 5)
    assert not VerifierProvider.check_expected_range("test_on_int", test_on_int, lower = 10)

@pytest.mark.parametrize(
    "given_properties, given_active_camera, expectation",
    [
        ({"cam01": {"orientation": "", "pixels_per_mm_along_coverage": ""}}, "cam01", does_not_raise()),
        ({"cam02": {"orientation": "", "pixels_per_mm_along_coverage": ""}}, "cam01", pytest.raises(ValueError)),
        ({"cam01": {"pixels_per_mm_along_coverage": ""}}, "cam01", pytest.raises(ValueError)),
        ({"cam01": {"orientation": ""}}, "cam01", pytest.raises(ValueError)),
    ],
)
def test_check_camera_properties(given_properties, given_active_camera, expectation):
    with expectation:
        VerifierProvider.check_camera_properties(given_properties, given_active_camera)

@pytest.mark.parametrize(
    "given_ev_input, given_active_camera, expectation",
    [
        ({"c1":
            {"edgedata":
                {"edge":
                    {"x_groundtruth": "", "edge_orientation": "", "y_x_polynom_groundtruth": "",
                    "pi_x_polynom_groundtruth": "", "metric": ""}
                    },
            "metadata": {}
            }
        }, "c1", does_not_raise()),
       ({"c2":
            {"edgedata":
                {"edge":
                    {
                    "x_groundtruth": "", "edge_orientation": "", "y_x_polynom_groundtruth": "",
                    "pi_x_polynom_groundtruth": "", "metric": ""
                    }
                },
            "metadata": {}
            }
        }, "c1", pytest.raises(ValueError)),
       ({"c1":
            {"edgedata": {
                "edge":
                    {"x_groundtruth": ""}
                },
            "metadata": {}
            }
        }, "c1", pytest.raises(ValueError)),
       ({"c1":
            {"edgedata": {
                "edge":
                    {"x_groundtruth": ""}
                }
            }
        }, "c1", pytest.raises(ValueError)),

    ],
)
def test_check_ev_input(given_ev_input, given_active_camera, expectation):
    with expectation:
        VerifierProvider.check_ev_input(given_ev_input, given_active_camera)

def test_set_functions(verifier_provider, team_instructions_v1):
    """Testing variable setter functions"""
    verifier_provider.verifiers = {
    TeamInstructions(team_instructions_v1): Verifier({cfg.CAMERA_ID: ""}, {}, camera_id=cfg.CAMERA_ID)}

    # Test tolerance setter
    result = verifier_provider.set_tolerance("value")
    assert not result
    result = verifier_provider.set_tolerance(-10)
    assert not result
    result = verifier_provider.set_tolerance(10)
    assert result

    # Test Region of Verification setter
    result = verifier_provider.set_region_of_verification("value")
    assert not result
    result = verifier_provider.set_tolerance(-10)
    assert not result
    result = verifier_provider.set_region_of_verification(10)
    assert result

    # Test Reduce Mask By setter
    result = verifier_provider.set_reduce_mask_by("value")
    assert not result
    result = verifier_provider.set_reduce_mask_by(-10)
    assert not result
    result = verifier_provider.set_reduce_mask_by(10)
    assert result

    # Test Noise Size Threshold setter
    result = verifier_provider.set_noise_size_threshold("value")
    assert not result
    result = verifier_provider.set_noise_size_threshold(-10)
    assert not result
    result = verifier_provider.set_noise_size_threshold(10)
    assert result

    # Test Min Range Threshold setter
    result = verifier_provider.set_min_range_threshold_factor("value")
    assert not result
    result = verifier_provider.set_min_range_threshold_factor(-10)
    assert not result
    result = verifier_provider.set_min_range_threshold_factor(1)
    assert result #implicit conversion
    result = verifier_provider.set_min_range_threshold_factor(1.0)
    assert result

    # Test Bad Range Threshold setter
    result = verifier_provider.set_bad_range_threshold("value")
    assert not result
    result = verifier_provider.set_bad_range_threshold(-10)
    assert not result
    result = verifier_provider.set_bad_range_threshold(1)
    assert result #implicit conversion
    result = verifier_provider.set_bad_range_threshold(1.0)
    assert result

    # Test Set Save Plots setter
    result = verifier_provider.set_save_plots("value")
    assert not result
    result = verifier_provider.set_save_plots("False")
    assert result
