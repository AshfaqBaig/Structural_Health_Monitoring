# pylint: disable=protected-access, missing-class-docstring, missing-function-docstring
import os
import pytest

from app.data_handler.ground_truth_data_service import GroundTruthDataService
from app.data_handler.team_instructions import TeamInstructions
import app.config as cfg


@pytest.fixture(name="ground_truth_data_service")
def fixture_ground_truth_data_service():
    cfg.DATA_PATH = os.path.join("../", "test_resources", "september_touchpoint")
    return GroundTruthDataService(os.path.join(cfg.DATA_PATH, "work_instructions"))

@pytest.fixture(name="team_instructions")
def fixture_team_instructions():
    return {
        "groundTruthVersion": "v0.0.1",
        "mouldId": "b9701u2",
        "bladeSn": "sn-2022-01-01",
        "bladeRevision": "blade_rev",
        "layers": ["090_B97-00_LP_Outer_B1_1-288"]
    }

@pytest.fixture(name="camera_properties")
def fixture_camera_properties():
    return [
        {
            "cam_id": "aal-b9701u2-cam013",
            "orientation": "lat",
            "pixels_per_mm_along_coverage": 1.1070615034
        }]

@pytest.fixture(name="ev_input")
def fixture_ev_input():
    return {"090_B97-00_LP_Outer_B1_1-288": {"camera-004": "test"}}


def test_get_ev_input_should_read_from_file_when_data_not_loaded(mocker, ground_truth_data_service,
                                                                 team_instructions, ev_input):
    cfg.LOCATION_ID = "aal"
    cfg.HALL_ID = "hall10"

    file_loader_mock = mocker.patch("app.data_handler.ground_truth_data_service.GroundTruthDataService.load_ev_input",
                                    return_value=ev_input)

    # GIVEN
    team_instructions = TeamInstructions(team_instructions)

    # WHEN ground_truth_data_service.get_camera_properties is called
    result = ground_truth_data_service.get_ev_groundtruth_data(team_instructions)

    # THEN correct result is returned
    assert result is ev_input

    # AND file_loader_mock is called with correct argument
    assert file_loader_mock.call_count == 1
    expected_filename = f"{team_instructions.mould_id}-{team_instructions.blade_revision}-{team_instructions.layer_id}-{cfg.EV_INPUT_FN}"
    expected_path = os.path.join(ground_truth_data_service._path,
                                 team_instructions.mould_id,
                                 team_instructions.ground_truth_data_version,
                                 expected_filename)
    call_args = file_loader_mock.call_args.args
    assert call_args[0] == expected_path

def test_get_ev_input_should_read_from_memory_when_data_loaded(mocker, ground_truth_data_service,
                                                                        team_instructions, ev_input):
    cfg.LOCATION_ID = "aal"
    cfg.HALL_ID = "hall10"

    # GIVEN
    team_instructions = TeamInstructions(team_instructions)
    file_loader_mock = mocker.patch("app.data_handler.ground_truth_data_service.GroundTruthDataService.load_ev_input",
                                    return_value=ev_input)

    ground_truth_data_service.ev_input = {
        team_instructions.ground_truth_data_version: {
            team_instructions.layer_id: ev_input
        }
    }

    # WHEN ground_truth_data_service.get_camera_properties is called
    result = ground_truth_data_service.get_ev_groundtruth_data(team_instructions)

    # THEN correct result is returned
    assert result is ev_input

    # AND file_loader_mock is not called
    assert file_loader_mock.call_count == 0


def test_get_camera_properties_should_read_from_file_when_data_not_loaded(mocker, ground_truth_data_service,
                                                                          team_instructions, camera_properties):
    cfg.LOCATION_ID = "aal"
    cfg.HALL_ID = "hall10"

    file_loader_mock = mocker.patch("app.data_handler.ground_truth_data_service.GroundTruthDataService.load_camera_properties",
                                    return_value=camera_properties)

    # GIVEN
    team_instructions = TeamInstructions(team_instructions)

    # WHEN ground_truth_data_service.get_camera_properties is called
    result = ground_truth_data_service.get_camera_properties(team_instructions)

    # THEN correct result is returned
    assert result is camera_properties

    # AND file_loader_mock is called with correct argument
    assert file_loader_mock.call_count == 1
    call_args = file_loader_mock.call_args.args
    expected_filename = os.path.join(ground_truth_data_service._path,
                                     team_instructions.mould_id,
                                     team_instructions.ground_truth_data_version,
                                     f"{cfg.LOCATION_ID}_{cfg.HALL_ID}_{team_instructions.mould_id}-{cfg.CAMERAPARAMS_FN}")
    assert call_args[0] == expected_filename

def test_get_camera_properties_should_read_from_memory_when_data_loaded(mocker, ground_truth_data_service,
                                                                        team_instructions, camera_properties):
    cfg.LOCATION_ID = "aal"
    cfg.HALL_ID = "hall10"

    # GIVEN
    team_instructions = TeamInstructions(team_instructions)
    file_loader_mock = mocker.patch("app.data_handler.ground_truth_data_service.GroundTruthDataService.load_camera_properties",
                                    return_value=camera_properties)
    ground_truth_data_service.cameras_properties = {
        team_instructions.ground_truth_data_version: camera_properties
    }

    # WHEN ground_truth_data_service.get_camera_properties is called
    result = ground_truth_data_service.get_camera_properties(team_instructions)

    # THEN correct result is returned
    assert result is camera_properties

    # AND file_loader_mock is not called
    assert file_loader_mock.call_count == 0


def test_load_camera_properties(tmp_path, ground_truth_data_service):
    d = tmp_path / "tmp"
    d.mkdir()
    file_1 = d / "camera_meta.json"
    camera_meta = """
    [
        {
            "cam_id": "cam-aal-h08-020",
            "hostname": "cam-aal-h08-020",
            "mac": "XXXX",
            "size": [
                6480,
                4860
            ],
            "orientation":"lon",
            "rotation": 0.0,
            "coverage_area": [
                30.844,
                37.137
            ],
            "pixels_per_mm_along_coverage": 1.029715557
        }
    ]
    """        
    file_1.write_text(camera_meta)
    loaded_properties = ground_truth_data_service.load_camera_properties(path_cameras_data=os.path.join(d, "camera_meta.json"))
    assert loaded_properties

def test_check_file(tmp_path):
    # Regular file
    some_file = tmp_path / "tmpfile"
    some_file.write_text("content")
    assert GroundTruthDataService.check_file(path=some_file) is None

    # Non existent file
    path = os.path.join("non_existent")
    with pytest.raises(FileNotFoundError) as exp:
        GroundTruthDataService.check_file(path=path)
    assert str(exp.value) == "Data file '' not found at non_existent"

    # Empty File
    empty_file = tmp_path / "tmpfile"
    empty_file.write_text("")
    with pytest.raises(ValueError) as exp:
        GroundTruthDataService.check_file(path=empty_file)
    assert str(exp.value).startswith("Can't process '', empty file:")

    # Non readable file
    # TODO
