# pylint: disable=missing-class-docstring, missing-function-docstring, no-self-use, protected-access
import logging
from unittest.mock import MagicMock, AsyncMock
import pytest
from app.method_request_handler import MethodRequestHandler
import app.config as cfg

@pytest.fixture(name="method_request_handler")
def fixture_method_request_handler():
    return MethodRequestHandler(AsyncMock(), MagicMock(), MagicMock())

@pytest.fixture(name="set_log_level_request")
def fixture_set_log_level_payload(mocker):
    mock_request = MagicMock()
    mocker.patch.object(mock_request, "name", "set_log_level")
    mocker.patch.object(mock_request, "payload",  {"value": "DEBUG"})
    return mock_request

@pytest.fixture(name="update_verifier_payload_v1")
def fixture_update_verifier_payload_v1():
    return {
        "TOLERANCE": 30,
        "REGION_OF_VERIFICATION": 30,
        "REDUCE_MASK_BY": 30,
        "NOISE_SIZE_THRESHOLD": 30,
        "SAVE_PLOTS": "False",
        "MIN_RANGE_THRESHOLD_FACTOR": 0.5,
        "BAD_RANGE_THRESHOLD": 0.5,
        "FF_ENABLE_1ST_EDGE_ONLY": "True"
    }

@pytest.fixture(name="update_verifier_payload_v2")
def fixture_update_verifier_payload_v2():
    return {
        "TOLERANCE": "30",
        "REGION_OF_VERIFICATION": "30",
        "REDUCE_MASK_BY": "30",
        "NOISE_SIZE_THRESHOLD": "30",
        "SAVE_PLOTS": "false",
        "MIN_RANGE_THRESHOLD_FACTOR": "0.5",
        "BAD_RANGE_THRESHOLD": "0.5",
        "FF_ENABLE_1ST_EDGE_ONLY": "true"
    }

@pytest.fixture(name="update_verifier_request_v1")
def fixture_update_verifier_request_v1(mocker, update_verifier_payload_v1):
    mock_request = MagicMock()
    mocker.patch.object(mock_request, "name", "update_verifier")
    mocker.patch.object(mock_request, "payload",  update_verifier_payload_v1)
    return mock_request

@pytest.fixture(name="update_verifier_request_v2")
def fixture_update_verifier_request_v2(mocker, update_verifier_payload_v2):
    mock_request = MagicMock()
    mocker.patch.object(mock_request, "name", "update_verifier")
    mocker.patch.object(mock_request, "payload",  update_verifier_payload_v2)
    return mock_request

@pytest.fixture(name="update_verifier_request_invalid")
def fixture_update_verifier_request_invalid(mocker, update_verifier_payload_invalid):
    mock_request = MagicMock()
    mocker.patch.object(mock_request, "name", "update_verifier")
    mocker.patch.object(mock_request, "payload",  update_verifier_payload_invalid)
    return mock_request

@pytest.fixture(name="get_configuration_request")
def fixture_get_configuration_request(mocker):
    mock_request = MagicMock()
    mocker.patch.object(mock_request, "name", "get_configuration")
    return mock_request

@pytest.mark.asyncio
async def test_set_log_level_when_different_log_level(mocker, method_request_handler, set_log_level_request, caplog):
    mock_create_method_response = mocker.patch("app.method_request_handler.MethodResponse.create_from_method_request")
    mock_client = mocker.patch.object(method_request_handler, "_module_client", new_callable=MagicMock)
    mock_send_method_response = mocker.patch.object(mock_client, "send_method_response", new_callable=AsyncMock)
    cfg.LOG_LEVEL = "ERROR"

    # RUN
    with caplog.at_level(logging.DEBUG):
        await method_request_handler.run(set_log_level_request)

    # VERIFY
    assert mock_send_method_response.call_count == 1
    assert mock_create_method_response.call_count == 1
    assert mock_create_method_response.call_args[0][1] == 200
    assert mock_create_method_response.call_args[0][2] == {"value": "DEBUG"}
    assert "Method set_log_level invocation with:" in caplog.text
    assert "Updated log level to" in caplog.text
    assert cfg.LOG_LEVEL == set_log_level_request.payload.get("value")

@pytest.mark.asyncio
async def test_set_log_level_when_same_log_level(mocker, method_request_handler, set_log_level_request, caplog):
    mock_create_method_response = mocker.patch("app.method_request_handler.MethodResponse.create_from_method_request")
    mock_client = mocker.patch.object(method_request_handler, "_module_client", new_callable=MagicMock)
    mock_send_method_response = mocker.patch.object(mock_client, "send_method_response", new_callable=AsyncMock)
    cfg.LOG_LEVEL = "DEBUG"

    # RUN
    with caplog.at_level(logging.DEBUG):
        await method_request_handler.run(set_log_level_request)

    # VERIFY
    assert mock_send_method_response.call_count == 1
    assert mock_create_method_response.call_count == 1
    assert mock_create_method_response.call_args[0][1] == 304
    assert "Method set_log_level invocation with:" in caplog.text
    assert cfg.LOG_LEVEL == set_log_level_request.payload.get("value")

@pytest.mark.asyncio
async def test_update_verifier_when_valid_payload_v1(mocker, method_request_handler, update_verifier_request_v1, caplog):
    """This one tests regular, correct updates"""
    mock_create_method_response = mocker.patch("app.method_request_handler.MethodResponse.create_from_method_request")
    mock_client = mocker.patch.object(method_request_handler, "_module_client", new_callable=MagicMock)
    mock_send_method_response = mocker.patch.object(mock_client, "send_method_response", new_callable=AsyncMock)

    # RUN
    await method_request_handler.run(update_verifier_request_v1)

    # VERIFY
    assert mock_send_method_response.call_count == 1
    assert mock_create_method_response.call_count == 1
    assert mock_create_method_response.call_args[0][1] == 200
    assert "Method update_verifier invocation with:" in caplog.text
    assert method_request_handler.target_function_mapping["TOLERANCE"].call_count == 1
    assert method_request_handler.target_function_mapping["REGION_OF_VERIFICATION"].call_count == 1
    assert method_request_handler.target_function_mapping["REDUCE_MASK_BY"].call_count == 1
    assert method_request_handler.target_function_mapping["NOISE_SIZE_THRESHOLD"].call_count == 1
    assert method_request_handler.target_function_mapping["SAVE_PLOTS"].call_count == 1
    assert method_request_handler.target_function_mapping["MIN_RANGE_THRESHOLD_FACTOR"].call_count == 1
    assert method_request_handler.target_function_mapping["BAD_RANGE_THRESHOLD"].call_count == 1
    assert method_request_handler.target_function_mapping["FF_ENABLE_1ST_EDGE_ONLY"].call_count == 1

@pytest.mark.asyncio
async def test_update_verifier_when_valid_payload_v2(mocker, method_request_handler, update_verifier_request_v2, caplog):
    """This one tests regular, correct updates"""
    mock_create_method_response = mocker.patch("app.method_request_handler.MethodResponse.create_from_method_request")
    mock_client = mocker.patch.object(method_request_handler, "_module_client", new_callable=MagicMock)
    mock_send_method_response = mocker.patch.object(mock_client, "send_method_response", new_callable=AsyncMock)

    # RUN
    await method_request_handler.run(update_verifier_request_v2)

    # VERIFY
    assert mock_send_method_response.call_count == 1
    assert mock_create_method_response.call_count == 1
    assert mock_create_method_response.call_args[0][1] == 200
    assert "Method update_verifier invocation with:" in caplog.text
    assert method_request_handler.target_function_mapping["TOLERANCE"].call_count == 1
    assert method_request_handler.target_function_mapping["REGION_OF_VERIFICATION"].call_count == 1
    assert method_request_handler.target_function_mapping["REDUCE_MASK_BY"].call_count == 1
    assert method_request_handler.target_function_mapping["NOISE_SIZE_THRESHOLD"].call_count == 1
    assert method_request_handler.target_function_mapping["SAVE_PLOTS"].call_count == 1
    assert method_request_handler.target_function_mapping["MIN_RANGE_THRESHOLD_FACTOR"].call_count == 1
    assert method_request_handler.target_function_mapping["BAD_RANGE_THRESHOLD"].call_count == 1
    assert method_request_handler.target_function_mapping["FF_ENABLE_1ST_EDGE_ONLY"].call_count == 1

@pytest.mark.asyncio
async def test_update_verifier_when_verifier_fails(mocker, update_verifier_request_v2, caplog):
    """Those value should never work"""
    mock_create_method_response = mocker.patch("app.method_request_handler.MethodResponse.create_from_method_request")
    verifier_provider = MagicMock()
    mock_set_tolerance = mocker.patch.object(verifier_provider, "set_tolerance", return_value=False)
    method_request_handler = MethodRequestHandler(AsyncMock(), verifier_provider, MagicMock())
    mock_client = mocker.patch.object(method_request_handler, "_module_client", new_callable=MagicMock)
    mock_send_method_response = mocker.patch.object(mock_client, "send_method_response", new_callable=AsyncMock)

    # RUN
    await method_request_handler.run(update_verifier_request_v2)

    # VERIFY
    assert mock_send_method_response.call_count == 1
    assert mock_create_method_response.call_count == 1
    assert mock_create_method_response.call_args[0][1] == 500
    assert "Method update_verifier invocation with:" in caplog.text
    assert mock_set_tolerance.call_count == 1
    assert method_request_handler.target_function_mapping["REGION_OF_VERIFICATION"].call_count == 1
    assert method_request_handler.target_function_mapping["REDUCE_MASK_BY"].call_count == 1
    assert method_request_handler.target_function_mapping["NOISE_SIZE_THRESHOLD"].call_count == 1
    assert method_request_handler.target_function_mapping["SAVE_PLOTS"].call_count == 1
    assert method_request_handler.target_function_mapping["MIN_RANGE_THRESHOLD_FACTOR"].call_count == 1
    assert method_request_handler.target_function_mapping["BAD_RANGE_THRESHOLD"].call_count == 1
    assert method_request_handler.target_function_mapping["FF_ENABLE_1ST_EDGE_ONLY"].call_count == 1

@pytest.mark.asyncio
async def test_get_configuration(mocker, method_request_handler, get_configuration_request, caplog):
    mock_create_method_response = mocker.patch("app.method_request_handler.MethodResponse.create_from_method_request")
    mock_client = mocker.patch.object(method_request_handler, "_module_client", new_callable=MagicMock)
    mock_send_method_response = mocker.patch.object(mock_client, "send_method_response", new_callable=AsyncMock)

    # RUN
    with caplog.at_level(logging.DEBUG):
        await method_request_handler.run(get_configuration_request)

    # VERIFY
    assert mock_send_method_response.call_count == 1
    assert mock_create_method_response.call_count == 1
    assert mock_create_method_response.call_args[0][1] == 200
    expected_args = { 
        "LOG_LEVEL": cfg.LOG_LEVEL
    }
    for key in cfg.MODIFIABLE_ATTRIBUTES:
        expected_args[key] = getattr(cfg, key)
    assert mock_create_method_response.call_args[0][2] == expected_args
    assert "Method get_configuration invocation with:" in caplog.text

@pytest.mark.asyncio
async def test_invalid_method(mocker, method_request_handler, caplog):
    mock_client = mocker.patch.object(method_request_handler, "_module_client", new_callable=MagicMock)
    mock_send_method_response = mocker.patch.object(mock_client, "send_method_response", new_callable=AsyncMock)
    mock_create_method_response = mocker.patch("app.method_request_handler.MethodResponse.create_from_method_request")

    mock_request = MagicMock()
    mocker.patch.object(mock_request, "name", "invalid_method_name")

    # RUN
    with caplog.at_level(logging.DEBUG):
        await method_request_handler.run(mock_request)

    # VERIFY
    assert mock_send_method_response.call_count == 1
    assert mock_create_method_response.call_count == 1
    assert mock_create_method_response.call_args[0][1] == 400
    assert "Method invalid_method_name invocation with:" in caplog.text
