## ~/do-ob-ml-marker-detection/torchvision_keypoints/training_results/v1.1.0/sgd_e15_lr5e-3_1cycle
#python train.py --lr 5e-3 --epochs 15

#python train.py --optimizer 'AdaBelief' --outputs "/home/bdou/do-ob-ml-marker-detection/torchvision_keypoints/training_results/v1.1.0/adaBelief_e20_lr1e-4_1cycle" \
#                --lr 1e-4 --epochs 20

python train.py --optimizer 'AdaBelief' --outputs "/home/bdou/do-ob-ml-marker-detection/torchvision_keypoints/training_results/v1.1.0/adaBelief_e20_lr5e-5_1cycle" \
                --lr 5e-5 --epochs 20 