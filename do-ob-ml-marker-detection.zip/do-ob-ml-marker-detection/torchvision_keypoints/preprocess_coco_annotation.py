import numpy as np
import matplotlib
import matplotlib.pyplot as plt
from PIL import Image
import requests
from pycocotools.coco import COCO

coco_annotation_file_path = "/home/bdou/data/do-ob-ml-dataset-marker-detection/raw/train.json"

coco_annotation = COCO(annotation_file=coco_annotation_file_path)
#anns = coco_annotation.loadAnns(ann_ids)
print(coco_annotation)