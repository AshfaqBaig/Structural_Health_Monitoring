import torch
import torchvision

#from torchvision.datasets import CocoDetection

def to_matrix(l, n=3):
    return [l[i:i+n] for i in range(0, len(l), n)]

class VisionKeypoints(torchvision.datasets.CocoDetection):

    def __getitem__(self, index):

        image, target = super().__getitem__(index)
        
        boxes = []
        labels = []
        keypoints = []
        for instance in target:
            x,y,w,h = instance['bbox']
            #print("DEBUG", instance['bbox'])
            #print("DEBUG", x,y,w,h)
            boxes.append([x, y, x+w, y+h])
            labels.append(instance['category_id'])
            keypoints.append(to_matrix(instance['keypoints']))
            
        vision_target = {'boxes': torch.FloatTensor(boxes),
                         'labels': torch.IntTensor(labels).type(torch.int64),
                         'keypoints': torch.FloatTensor(keypoints)}

        return image, vision_target
