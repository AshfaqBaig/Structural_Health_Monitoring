import os
import argparse
import time
import datetime

import numpy as np
import torch
import holocron

from dataset import VisionKeypoints

import torchvision
from torchvision import transforms as VT
import transforms as T

from torchvision.models.detection import keypointrcnn_resnet50_fpn

from coco_utils import get_coco_api_from_dataset
from coco_utils import ConvertCocoPolysToMask,ConvertCocoPolysToMaskKeyPoints
from coco_utils import CocoDetection
from coco_utils import _coco_remove_images_without_annotations

from coco_eval import CocoEvaluator

import utils
from group_by_aspect_ratio import GroupedBatchSampler, create_aspect_ratio_groups

from torchvision.utils import draw_bounding_boxes
import torchvision.transforms.functional as F

from tensorboardX import SummaryWriter


class AverageMeter(object):
    """Computes and stores the average and current value"""

    def __init__(self):
        self.reset()

    def reset(self):
        self.val = 0
        self.avg = 0
        self.sum = 0
        self.count = 0

    def update(self, val, n=1):
        self.val = val
        self.sum += val * n
        self.count += n
        self.avg = self.sum / self.count


def main():
    os.environ["CUDA_VISIBLE_DEVICES"] = '0'
    #print(torch.cuda.current_device())
    torch.cuda.empty_cache()

    parser = argparse.ArgumentParser(description="Custom implementation of Torchvisoin keypoint train script")
    parser.add_argument('--gpus', nargs='+', type=int, default=[0])
    #parser.add_argument('--dataset_location', type=str, default="/home/itelezhinsky/data/dataset-marker_detection")
    parser.add_argument('--dataset_location', type=str, default="/home/bdou/data/do-ob-ml-dataset-marker-detection/raw")
    #parser.add_argument('--outputs', type=str, default='/home/itelezhinsky/code/ml-marker-detection/torchvision_keypoints/test')
    parser.add_argument('--outputs', type=str, default='/home/bdou/do-ob-ml-marker-detection/torchvision_keypoints/training_results/v1.1.0/sgd_e15_lr5e-3_1cycle')
    parser.add_argument('--lr', type=float, default=1e-3)
    parser.add_argument('--optimizer', type=str, default='SGD')
    parser.add_argument('--weight_decay', type=float, default=5e-4)
    parser.add_argument('--batch_size', type=int, default=1)
    parser.add_argument('--epochs', type=int, default=15)
    parser.add_argument('--eval_freq', type=int, default=1)

    parser.add_argument('--aspect_ratio_group_factor', default=0, type=int)

    parser.add_argument('--num_workers', type=int, default=4)
    parser.add_argument('--device', default='cuda', help='device')

    # distributed training parameters
    parser.add_argument('--world-size', default=1, type=int, help='number of distributed processes')
    parser.add_argument('--dist-url', default='env://', help='url used to set up distributed training')
    parser.add_argument('--sync-bn', dest="sync_bn", help="Use sync batch norm", action="store_true")

    parser.add_argument('--test_only', dest="test_only", help="Use sync batch norm", action="store_true")

    args = parser.parse_args()

    if args.outputs:
        utils.mkdir(args.outputs)
        utils.mkdir(os.path.join(args.outputs,'tf_logs'))

    utils.init_distributed_mode(args)
    print(args)

    device = torch.device(args.device)

    #train_transform = VT.Compose([VT.ToTensor()])
    #valid_transform = VT.Compose([VT.ToTensor()])
    #train_data = VisionKeypoints(args.dataset_location,
    #                             os.path.join(args.dataset_location, 'train.json'),
    #                             transform=train_transform)
    #valid_data = VisionKeypoints(args.dataset_location,
    #                             os.path.join(args.dataset_location, 'valid.json'),
    #                             transform=valid_transform)
    

    coco_transform = T.Compose([ConvertCocoPolysToMask(), T.ToTensor()])

    train_data = CocoDetection(args.dataset_location,
                               os.path.join(args.dataset_location, 'train.json'),
                               transforms=coco_transform)
    train_data = _coco_remove_images_without_annotations(train_data)
    print('[DEBUG] train_data', len(list(train_data)))

    valid_data = CocoDetection(args.dataset_location,
                               os.path.join(args.dataset_location, 'val.json'),
                               transforms=coco_transform)
    valid_data = _coco_remove_images_without_annotations(valid_data)

    coco_train = CocoDetection(args.dataset_location,
                               os.path.join(args.dataset_location, 'train_processed.json'),
                               transforms=T.Compose([ConvertCocoPolysToMaskKeyPoints(),T.ToTensor()]))
    coco_train = _coco_remove_images_without_annotations(coco_train)
    print('[DEBUG] coco train ', len(list(coco_train)))
    coco_valid = CocoDetection(args.dataset_location,
                               os.path.join(args.dataset_location, 'val_processed.json'),
                               transforms=T.Compose([ConvertCocoPolysToMaskKeyPoints(),T.ToTensor()]))
    coco_valid  = _coco_remove_images_without_annotations(coco_valid)
    #valid_data = train_data

    if args.distributed:
        train_sampler = torch.utils.data.distributed.DistributedSampler(train_data)
        valid_sampler = torch.utils.data.distributed.DistributedSampler(valid_data)
    else:
        print('[DEBUG] NOT DISTRIBUTED!')
        train_sampler = torch.utils.data.RandomSampler(train_data)
        valid_sampler = torch.utils.data.SequentialSampler(valid_data)
        #valid_sampler = torch.utils.data.RandomSampler(valid_data)

    args.aspect_ratio_group_factor = -1
    if args.aspect_ratio_group_factor >= 0:
        group_ids = create_aspect_ratio_groups(train_data, k=args.aspect_ratio_group_factor)
        train_sampler = GroupedBatchSampler(train_sampler, group_ids, args.batch_size)
    else:
        train_sampler = torch.utils.data.BatchSampler(train_sampler, args.batch_size, drop_last=True)


    #for i,t in valid_coco:
    #    print('[DEBUG] train.py -> dataset:', t)

    # NB need custom collate not to convert to tensor contents of labels dictionary when batches are formed
    train_loader = torch.utils.data.DataLoader(train_data,
                                                #batch_size=args.batch_size,
                                                batch_sampler=train_sampler,
                                                collate_fn=utils.collate_fn, #lambda x: zip(*x),
                                                #shuffle=True,
                                                num_workers=args.num_workers,
                                                pin_memory=True,
                                                #drop_last=False
                                               )
    
    valid_loader = torch.utils.data.DataLoader(valid_data,
                                                batch_size=args.batch_size,
                                                sampler=valid_sampler,
                                                collate_fn=utils.collate_fn, #lambda x: zip(*x),
                                                #shuffle=False,
                                                num_workers=args.num_workers,
                                                pin_memory=True,
                                                #drop_last=False
                                               )
    
    coco_loader_train = torch.utils.data.DataLoader(coco_train,
                                              batch_size=args.batch_size,
                                              collate_fn=utils.collate_fn,
                                              shuffle=False,
                                              num_workers=args.num_workers,
                                              pin_memory=True,
                                              drop_last=False)
    coco_loader_valid = torch.utils.data.DataLoader(coco_valid,
                                              batch_size=args.batch_size,
                                              collate_fn=utils.collate_fn,
                                              shuffle=False,
                                              num_workers=args.num_workers,
                                              pin_memory=True,
                                              drop_last=False)                                        
    #coco_loader = torch.utils.data.DataLoader(valid_data,
    #                                          batch_size=args.batch_size,
    #                                          batch_sampler=valid_sampler,
    #                                          #shuffle=False,
    #                                          num_workers=args.num_workers,
    #                                          pin_memory=True,
    #                                          #drop_last=False
    #                                          )

    #print('[DEBUG] len(train_loader):', len(train_loader))
    #print('[DEBUG] train.py -> coco_train:', coco_train.dataset)
    #for i,t in coco_loader_train:
    #    for n in t : print('[DEBUG] train.py -> coco_loader_train:\n',n['num_keypoints'])
    #for images, targets in train_loader:
    #    for target in targets: print(target["image_id"].item())
    #    break

    #print('[DEBUG] train.py -> valid_loader:', valid_data)
    #for i,t in valid_loader:
    #    print('[DEBUG] train.py -> valid_loader:\n', t)
    #    break

    if args.test_only:
        vis_output = os.path.join(args.outputs,'visual')
        utils.mkdir(vis_output)
        #test(valid_loader, os.path.join(args.outputs, 'checkpoint.pth'), output=vis_output, 
        #     epoch=None, score_threshold=0.7, keypoints_score_threshold=10, device=device)
        ### use models in epoch 12 to test the adaBelief models
        test(valid_loader, os.path.join(args.outputs, 'model_12.pth'), output=vis_output, 
             epoch=None, score_threshold=0.7, keypoints_score_threshold=10, device=device)
        return

    model = keypointrcnn_resnet50_fpn(num_keypoints=1)
    model = torch.nn.DataParallel(model, device_ids=args.gpus).cuda()

    if args.distributed and args.sync_bn:
        model = torch.nn.SyncBatchNorm.convert_sync_batchnorm(model)

    model_without_ddp = model
    if args.distributed:
        model = torch.nn.parallel.DistributedDataParallel(model, device_ids=[args.gpu])
        model_without_ddp = model.module

    params = [p for p in model.parameters() if p.requires_grad]
    if args.optimizer == 'SGD':
        optimizer = torch.optim.SGD(params, 
                                    lr=args.lr,
                                    momentum=0.9,
                                    weight_decay=args.weight_decay)

    elif args.optimizer == 'AdaBelief':
        optimizer = holocron.optim.AdaBelief(params, #model.parameters(),
                                             lr=args.lr,
                                             amsgrad=True,
                                             weight_decay=args.weight_decay)
    else:
        raise RuntimeError("Invalid optimizer") 

    

    scheduler = torch.optim.lr_scheduler.OneCycleLR(optimizer,
                                                    max_lr=2.5*args.lr, 
                                                    steps_per_epoch=len(train_sampler),
                                                    epochs=args.epochs,
                                                    cycle_momentum=True,
                                                    verbose=False)
    batch_steps = True

    tf_writer = SummaryWriter(log_dir=os.path.join(args.outputs, "tf_logs"))
    
    # NOTE might need to set epoch in non-batched sampler
    if args.distributed:
            train_sampler.set_epoch(epoch)
    
    start_time = time.time()
    for epoch in range(0, args.epochs):
        if epoch >= 1:
            print("Unfreezing deep layers")
            # TODO unfreeze layers here

        train(train_loader, model, optimizer, scheduler, batch_steps, epoch, tf_writer, device)
        validate_map_05(coco_loader_train, model, epoch, tf_writer, device, 'train')

        # step should be after train otherwise first value of LR is skipped
        if not batch_steps:
            scheduler.step()

        if (epoch) % args.eval_freq == 0 or epoch == args.epochs - 1:
            validate_losses(valid_loader, model, epoch, tf_writer, device)
            validate_map_05(coco_loader_valid, model, epoch, tf_writer, device, 'valid')

            if args.outputs:
                checkpoint = {
                    'model': model_without_ddp.state_dict(),
                    'optimizer': optimizer.state_dict(),
                    'lr_scheduler': scheduler.state_dict(),
                    'args': args,
                    'epoch': epoch
                }
                utils.save_on_master(
                    checkpoint,
                    os.path.join(args.outputs,'model_{}.pth'.format(epoch)))
                utils.save_on_master(
                    checkpoint,
                    os.path.join(args.outputs, 'checkpoint.pth'))

    
    total_time = time.time() - start_time
    total_time_str = str(datetime.timedelta(seconds=int(total_time)))
    print('Training time {}'.format(total_time_str))

def train(train_loader, model, optimizer, scheduler, batch_steps, epoch, tf_writer, device):
    loss_log_tot = AverageMeter()
    loss_log_obj = AverageMeter()
    loss_log_cls = AverageMeter()
    loss_log_rpn = AverageMeter()
    loss_log_box = AverageMeter()
    loss_log_key = AverageMeter()
    
    print("Training epoch:", epoch)
    model.train()
    
    with torch.set_grad_enabled(True):
        for inputs, targets in train_loader:
                      
            inputs = list(image.to(device) for image in inputs)
            targets = [{k: v.to(device) for k, v in t.items()} for t in targets]
            
            #print("[DEBUG]",inputs[0].shape)
            #print("[DEBUG]",targets)

            train_output = model(inputs, targets)
            
            loss_obj = train_output['loss_objectness']
            loss_cls = train_output['loss_classifier']
            loss_rpn = train_output['loss_rpn_box_reg']
            loss_box = train_output['loss_box_reg']
            loss_key = train_output['loss_keypoint']
            
            loss = loss_obj + loss_cls + loss_rpn + loss_box + loss_key
            
            L = len(inputs)
            loss_log_tot.update(loss.item(), L)
            loss_log_obj.update(loss_obj.item(), L)
            loss_log_cls.update(loss_cls.item(), L)
            loss_log_rpn.update(loss_rpn.item(), L)
            loss_log_box.update(loss_box.item(), L)
            loss_log_key.update(loss_key.item(), L)
            #print("[DEBUG]", loss)

            # compute gradient and do optimizer step
            optimizer.zero_grad()
            loss.backward()
            optimizer.step()
            if batch_steps:
                scheduler.step()
    
    # NOTE might need to reduce losses if multi gpu training is used
    tf_writer.add_scalar('train/loss_tot', loss_log_tot.avg, epoch)
    tf_writer.add_scalar('train/loss_obj', loss_log_obj.avg, epoch)
    tf_writer.add_scalar('train/loss_cls', loss_log_cls.avg, epoch)
    tf_writer.add_scalar('train/loss_rpn', loss_log_rpn.avg, epoch)
    tf_writer.add_scalar('train/loss_box', loss_log_box.avg, epoch)
    tf_writer.add_scalar('train/loss_key', loss_log_key.avg, epoch)
    
    tf_writer.add_scalar('lr', optimizer.param_groups[-1]['lr'], epoch)

def validate_losses(valid_loader, model, epoch, tf_writer, device):
    loss_log_tot = AverageMeter()
    loss_log_obj = AverageMeter()
    loss_log_cls = AverageMeter()
    loss_log_rpn = AverageMeter()
    loss_log_box = AverageMeter()
    loss_log_key = AverageMeter()

    print("Validation epoch:", epoch)
    model.train()
    # the model needs to be in train mode to provide appropriate output -> check
    with torch.set_grad_enabled(False):
        for inputs, targets in valid_loader:

            inputs = list(image.to(device) for image in inputs)
            targets = [{k: v.to(device) for k, v in t.items()} for t in targets]

            # compute output
            valid_output = model(inputs, targets)
            
            loss_obj = valid_output['loss_objectness']
            loss_cls = valid_output['loss_classifier']
            loss_rpn = valid_output['loss_rpn_box_reg']
            loss_box = valid_output['loss_box_reg']
            loss_key = valid_output['loss_keypoint']

            # print("[DEBUG]", valid_output)
            
            loss = loss_obj + loss_cls + loss_rpn + loss_box + loss_key
            
            L = len(inputs)
            loss_log_tot.update(loss.item(),     L)
            loss_log_obj.update(loss_obj.item(), L)
            loss_log_cls.update(loss_cls.item(), L)
            loss_log_rpn.update(loss_rpn.item(), L)
            loss_log_box.update(loss_box.item(), L)
            loss_log_key.update(loss_key.item(), L)

    # NOTE might need to reduce losses if multi gpu training is used
    tf_writer.add_scalar('valid/loss_tot', loss_log_tot.avg, epoch)
    tf_writer.add_scalar('valid/loss_obj', loss_log_obj.avg, epoch)
    tf_writer.add_scalar('valid/loss_cls', loss_log_cls.avg, epoch)
    tf_writer.add_scalar('valid/loss_rpn', loss_log_rpn.avg, epoch)
    tf_writer.add_scalar('valid/loss_box', loss_log_box.avg, epoch)
    tf_writer.add_scalar('valid/loss_key', loss_log_key.avg, epoch)


@torch.no_grad()
def validate_map_05(data_loader, model, epoch, tf_writer, device, subset):
    n_threads = torch.get_num_threads()
    torch.set_num_threads(1)
    cpu_device = torch.device("cpu")

    model.eval()

    coco_api = get_coco_api_from_dataset(data_loader.dataset)
    coco_evaluator = CocoEvaluator(coco_api, iou_types=['keypoints','bbox'])
    coco_evaluator.coco_eval['keypoints'].params.kpt_oks_sigmas = np.array([0.1])

    for images, targets in data_loader:
        images = list(img.to(device) for img in images)

        if torch.cuda.is_available():
            torch.cuda.synchronize()
        
        outputs = model(images)

        outputs = [{k: v.to(cpu_device) for k, v in t.items()} for t in outputs]
        res = {target["image_id"].item(): output for target, output in zip(targets, outputs)}

        coco_evaluator.update(res)

    coco_evaluator.synchronize_between_processes()

    # accumulate predictions from all images
    coco_evaluator.accumulate()
    coco_evaluator.summarize()
    torch.set_num_threads(n_threads)
    
    tf_writer.add_scalar(subset + '/key_mAP@0.5', coco_evaluator.coco_eval['keypoints'].stats[1], epoch)
    tf_writer.add_scalar(subset + '/box_mAP@0.5', coco_evaluator.coco_eval['bbox'].stats[1], epoch)

    return coco_evaluator

from torchvision.transforms.functional import convert_image_dtype

def test(valid_loader, model_path, output, epoch, score_threshold, keypoints_score_threshold, device):
    
    print("Testing epoch:", epoch)
    model = keypointrcnn_resnet50_fpn(num_keypoints=1)
    model = torch.nn.DataParallel(model, device_ids=[0]).cuda()
    model.load_state_dict(torch.load(model_path)['model'])
    #print(model)
    model.eval()
    # the model needs to be in train mode to provide appropriate output -> check
    with torch.set_grad_enabled(False):
        for inputs, targets in valid_loader:

            inputs = list(image.to(device) for image in inputs)
            #targets = [{k: v.to(device) for k, v in t.items()} for t in targets]

            outputs = model(inputs)

            #print(outputs)

            #print(outputs['scores'] > score_threshold)
            #print(outputs['boxes'])
            scores_str_list = outputs[0]['keypoints_scores'][outputs[0]['keypoints_scores'] > keypoints_score_threshold]
            scores_str_list = [str(s.cpu().numpy().round(2)) for s in scores_str_list]
            print('Train --> test()',scores_str_list)
            img = convert_image_dtype(inputs[0], torch.uint8).cpu()
            img = draw_bounding_boxes(img, boxes=outputs[0]['boxes'][outputs[0]['scores'] > score_threshold], width=4)
            img = utils.draw_keypoints(img, keypoints=outputs[0]['keypoints'][outputs[0]['keypoints_scores'] > keypoints_score_threshold],
                                       width=4, labels=scores_str_list, font='fonts/arial.ttf', font_size=32)
            img = F.to_pil_image(img)
            img.save(os.path.join(output, str(targets[0]['image_id'])+'.jpg'))


if __name__ == '__main__':
    main()