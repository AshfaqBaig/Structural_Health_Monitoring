#### test-only puprose for different models 

### test model on epoch 12
#python train.py --test_only --outputs /home/bdou/do-ob-ml-marker-detection/torchvision_keypoints/training_results/v1.1.0/adaBelief_e20_lr1e-4_1cycle 

python train.py --test_only --outputs /home/bdou/do-ob-ml-marker-detection/torchvision_keypoints/training_results/v1.1.0/adaBelief_e20_lr5e-5_1cycle