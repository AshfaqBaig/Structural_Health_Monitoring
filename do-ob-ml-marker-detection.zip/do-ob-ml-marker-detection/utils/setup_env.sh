#!/bin/bash

#conda env create --name actev -f environment.yml
conda create --name pytorch python=3.8
eval "$(conda shell.bash hook)"
conda activate pytorch


pip install numpy
#pip install torch==1.8.0 torchvision==0.9.0 # -f https://download.pytorch.org/whl/torch_stable.html
pip install torch==1.9.0 torchvision==0.10.0
pip install opencv-python
pip install pillow
pip install psutil
pip install nvidia-ml-py3
pip install virtualenv
pip install python-dotenv
pip install tensorboardX
pip install tqdm
pip install pandas
pip install seaborn
pip install requests
pip install scipy
pip install scikit-learn
pip install matplotlib
pip install pyyaml
pip install fastprogress==1.0.0
pip install --no-deps contiguous-params==1.0.0
pip install --no-deps pylocron
pip install pycocotools
pip install ipython

#pip install --user joblib
#pip install --user netcal==1.1.3

#conda uninstall pytorch -y
#conda install -c pytorch pytorch=1.8.0 -y
