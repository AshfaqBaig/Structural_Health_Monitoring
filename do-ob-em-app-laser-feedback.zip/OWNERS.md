# Authors
- Dirk Rannacher - SGRE (dirk.rannacher@siemensgamesa.com)
- Devendra Jha - SGRE (devendra.jha.ext@siemensgamesa.com)