# em-laser-feedback
![Python](https://img.shields.io/badge/Python-3.9-informational)
![Docker](https://img.shields.io/badge/image-amd64/python:3.9.0--slim--buster-informational)

![azure-iot-device](https://img.shields.io/badge/azure--iot--device-v2.9.0-informational)
![azure-iot-device (latest)](https://img.shields.io/pypi/v/azure--iot--device?label=latest)
![ezdxf](https://img.shields.io/badge/ezdxf-v0.17.1-informational)
![ezdxf (latest)](https://img.shields.io/pypi/v/ezdxf?label=latest)
![requests](https://img.shields.io/badge/requests-v2.26.0-informational)
![requests (latest)](https://img.shields.io/pypi/v/requests?label=latest)
![numpy](https://img.shields.io/badge/numpy-v1.21.4-informational)
![numpy (latest)](https://img.shields.io/pypi/v/numpy?label=latest)
![prometheus_client](https://img.shields.io/badge/prometheus_client-v0.12.0-informational)
![prometheus_client (latest)](https://img.shields.io/pypi/v/prometheus_client?label=latest)
![humanize](https://img.shields.io/badge/humanize-v3.13.1-informational)
![humanize (latest)](https://img.shields.io/pypi/v/humanize?label=latest)

# Introduction 
Laser feedback module responsible for generating DXF files and forwarding them to `em-laser-hub` module

# Environment variables

| Parameter      | Default value                                      | Description                                                                                            |
| -------------- | -------------------------------------------------- | ------------------------------------------------------------------------------------------------------ |
| DEFAULT_SHAPE_COLOR | 1 (red)                                      | Default color of the shape. It can be overriden by API per each request of by this environment variable |
| DEFAULT_CIRCLE_RADIUS | 1                                          | Circle's default radius. It can be overriden by API per each request of by this environment variable |
| DEFAULT_TEXT_ALIGN  | LEFT                                         | Text's default align. It can be overriden by API per each request of by this environment variable |
| DEFAULT_DXF_VERSION  | AC1032                                      | Default DXF version |
| BLADE_LAYOUT_PATH | blade-blueprints | Folder for loading blade plies layout. Each dxf file in this path is loaded and split into smaller DXF file containing 2 polylines only |
| LOG_LEVEL  | INFO                                       | Logging level |
| ACTIVE_LASER_HUB_HOST | | Default laser-hub instance hostname |
| PROMETHEUS_PORT | 9060 | Port exposed for Prometheus |
| MOULD_ID | None | ID of mould being used |
| IOTEDGE_DEVICEID | None | ID of device being used |
| IOTEDGE_MODULEID | None | ID of device being used |

# Run
```
pip3 install -r requirements.txt
export PYTHONPATH='./'
python3 app/main.py
```

# Test
```
pip3 install -r requirements-tests.txt
export PYTHONPATH='./'
pytest tests/
```
