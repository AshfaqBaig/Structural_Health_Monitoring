#!/bin/bash
curl -X POST -H "Content-Type: application/json" \
  -d '{"type":"text", "text":"Test", "coordinates": [0, 0, 10]}' \
  http://localhost:8080/api/feedback/shape