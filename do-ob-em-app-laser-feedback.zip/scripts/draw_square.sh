#!/bin/bash
curl -X POST -H "Content-Type: application/json" \
  -d '{"type":"polyline", "coordinates": [[0, 0, 10], [10, 0, 10], [10, 10, 4], [0, 10, 4]]}' \
  http://localhost:8080/api/feedback/shape