'''
Blade layout blueprint cache module
'''
import io
import os
import sys
import json
import numpy as np

from ezdxf.addons import r12writer
import app.config as cfg

from app.logging.logger import yield_logger

log = yield_logger()

DEFAULT_COLOR = os.environ.get('DEFAULT_SHAPE_COLOR', 3)


class BladeLayoutCache:
    """
    Blade layout blueprint cache class implements json reading and splitting into multiple
    plies and stream into dxf strings and store them in memory. Ply is defined by 2 polylines.
    Additionaly it is possible to create a 4-laser-lines string
    """

    def __init__(self):
        self.cache = {}

    def init(self):
        '''Init cache dict and scan folder for input json files'''

        design_files = [os.path.join(root, filename)
                        for root, dirnames, filenames in os.walk(cfg.BLADE_LAYOUT_PATH)
                        for filename in filenames if filename.endswith('.json')]
        for file in design_files:
            key = os.path.splitext(os.path.basename(file))[0]
            self.cache[key] = {}

            dxf_count = self._read_file(file, key)
            log.info('Generated %s DXF files total size of %s MB out of %s', \
                     dxf_count, round(self._calculate_size() / 1024 / 1024, 1), file)

    def _save_to_cache_6_lines(self, design_ply: dict, key: str, ply: str):
        '''Take DXF document and save it as string to dict cache'''
        str_stream = io.StringIO()
        with r12writer(str_stream, fixed_tables=False) as dxf:
            for entity in design_ply:
                xyz = design_ply[entity]['coordinates']
                xyz_tuple = tuple(map(tuple, xyz))
                dxf.add_polyline(xyz_tuple, layer=ply, color=DEFAULT_COLOR)
        self.cache[key][f"{ply}_6lines"] = str_stream.getvalue()
        str_stream.close()

    def _save_to_cache_4_lines(self, design_ply: dict, key: str, ply: str):
        '''
        Picks out from 6-laser-lines only 4-laser-lines, which are related to each plie corner
        and store them as a string to the dict cache, which was already created.
        '''
        x_mean, z_mean = np.zeros(0), np.zeros(0)
        xyz_tuple_lst = []
        for entity in design_ply:
            xyz = np.asarray(design_ply[entity]['coordinates'])
            xyz_tuple_lst.append(tuple(map(tuple, xyz)))

            x_mean = np.append(x_mean, 0.5 * (xyz[:, 0].max() + xyz[:, 0].min()))
            z_mean = np.append(z_mean, 0.5 * (xyz[:, 2].max() + xyz[:, 2].min()))

        xz_mean = np.vstack((x_mean, z_mean)).T
        x_idx_sorted = np.argsort(xz_mean[:, 0])
        x_idx_desired = [0, 1, -2, -1]
        x_idx_res = np.take(x_idx_sorted, x_idx_desired)

        str_stream = io.StringIO()
        with r12writer(str_stream, fixed_tables=False) as dxf:
            for i in x_idx_res:
                dxf.add_polyline(xyz_tuple_lst[i], layer=ply, color=DEFAULT_COLOR)

        self.cache[key][f"{ply}_4lines"] = str_stream.getvalue()
        str_stream.close()

    def _cluster(self, points: list):
        clusters = []
        eps = 0.2
        points_sorted = sorted(points)
        curr_point = points_sorted[0]
        curr_cluster = [curr_point]
        for point in points_sorted[1:]:
            if point <= curr_point + eps:
                curr_cluster.append(point)
            else:
                clusters.append(curr_cluster)
                curr_cluster = [point]
            curr_point = point
        clusters.append(curr_cluster)
        return clusters

    def _calculate_size(self):
        '''Calculate total size of dict cache in bytes'''

        total_size = 0
        for key in self.cache:
            for ply in self.cache[key]:
                total_size = total_size + sys.getsizeof(self.cache[key][ply])

        return total_size

    def _read_file(self, file_path: str, key: str):
        '''Read json files, grab single plies and convert these into DXF strings'''

        try:
            log.info('Reading file %s', file_path)
            with open(file_path, 'r', encoding='utf-8') as design_file:
                design_dict = json.load(design_file)

            if 'color' in design_dict[key]:
                design_dict[key].pop('color', None)

            contour_count = 0
            log.debug('%s entities found in %s', len(design_dict[key].keys()), key)
            for ply in design_dict[key]:
                progress_percentage = round(contour_count * 100 / len(design_dict[key].keys()))
                log.debug('Processing %s contour %s (%s%%)', key, ply, progress_percentage)

                if 'color' in design_dict[key][ply]:
                    design_dict[key][ply].pop('color', None)
                group = [k for k in design_dict[key][ply].keys() if k.startswith("Group")][0]  # get the key of group
                if 'color' in design_dict[key][ply][group]:
                    design_dict[key][ply][group].pop('color', None)

                self._save_to_cache_6_lines(design_dict[key][ply][group], key, ply.replace("_R", ""))
                if cfg.PROVIDE_FOUR_LASER_LINES:
                    self._save_to_cache_4_lines(design_dict[key][ply][group], key, ply.replace("_R", ""))

                contour_count += 1
            return contour_count
        except IOError as ex:
            log.exception(ex)

    def get(self, key: str, ply: str):
        '''Get DXF as string for dict cache

        Keyword arguments:
        layout -- layout file
        contour -- contour id
        '''

        log.debug('Fetching %s contour for %s layout', ply, key)
        layout_blueprint = self.cache.get(key)
        if layout_blueprint:
            return layout_blueprint.get(ply)
        raise Exception(f'Layout {key} blueprint not found')
