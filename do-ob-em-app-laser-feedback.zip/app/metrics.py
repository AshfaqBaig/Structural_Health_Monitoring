import math
import app.config as cfg

HISTOGRAM_BUCKETS = (.1, .2, .5, 1.0, math.inf)

def get_labels():
    return {
        "mould_id": cfg.MOULD_ID,
        "device_id": cfg.IOTEDGE_DEVICEID,
        "module_id": cfg.IOTEDGE_MODULEID
    }

def get_label_keys():
    return list(get_labels().keys())
