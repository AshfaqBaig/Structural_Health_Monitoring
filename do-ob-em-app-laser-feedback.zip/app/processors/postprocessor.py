import sys
import base64
import humanize

from app.util.dxf_util import merge_dxf_str

from app.logging.logger import yield_logger
log = yield_logger()
class ResponsePostprocessor:

    def _build_laser_hub_payload(self, payload: dict, projections: list) -> dict:
        output_message: dict = {}
        if projections and len(projections) > 0:
            merged_projections = merge_dxf_str(projections).encode()
            output_message = {
                'session': payload.get('session'),
                'feedbackType': payload.get('feedbackType'),
                'content': base64.b64encode(merged_projections).decode('ascii')
            }
            expiration = payload.get('expiration')
            if expiration:
                output_message['expiration'] = payload.get('expiration')
            else:
                log.info('Missing expiration for %s', payload.get('session'))
            log.info('Final DXF size %s; DXF base64 size %s', humanize.naturalsize(sys.getsizeof(
                merged_projections)), humanize.naturalsize(sys.getsizeof(output_message['content'])))
        else:
            output_message = {
                'session': payload.get('session'),
                'feedbackType': payload.get('feedbackType'),
                'expiration': 0
            }
            log.info('Sending empty feedback to laser-hub for %s', payload.get('session'))
        return output_message

    def run(self, payload: dict, projections: list) -> dict:
        '''Aggregate feedbacks into one and build output payload for laser-hub'''

        return self._build_laser_hub_payload(payload, projections)
