import os
import sys

import humanize

from app.shapes.circle import Circle
from app.shapes.circle_v2 import CircleV2
from app.shapes.polyline import Polyline
from app.shapes.polyline_text import PolylineText

from app.logging.logger import yield_logger
log = yield_logger()

DEFAULT_COLOR = os.environ.get('DEFAULT_SHAPE_COLOR', 3)  # green
DEFAULT_CIRCLE_RADIUS = os.environ.get('DEFAULT_CIRCLE_RADIUS', 500)
DEFAULT_TEXT_ZOOM_RATE = os.environ.get('DEFAULT_TEXT_ZOOM_RATE', 10)
DEFAULT_DXF_VERSION = os.environ.get('DEFAULT_DXF_VERSION', 'AC1032')


class LaserShapeFeedback:
    """
    This class implements DXF generation and routing logic to em-laser-hub
    """

    @staticmethod
    def _generate_polyline(coordinates: list, color: int):
        '''Generate polyline DXF string'''

        return Polyline(DEFAULT_DXF_VERSION, coordinates, color).generate()

    @staticmethod
    def _generate_circle(radius: int, coordinates: list, color: int):
        '''Generate circle DXF string'''

        return Circle(DEFAULT_DXF_VERSION, radius, coordinates, color).generate()

    @staticmethod
    def _generate_circle_v2(radius: int, coordinates: list, color: int):
        '''Generate circle DXF string'''

        return CircleV2(DEFAULT_DXF_VERSION, radius, coordinates, color).generate()

    @staticmethod
    def _generate_text(text: str, zoom_rate: float, coordinates: list, color: int):
        '''Generate text DXF string'''

        return PolylineText(DEFAULT_DXF_VERSION, text, zoom_rate, coordinates, color).generate()

    def run(self, feedback: dict) -> None:
        '''Main entrypoint method for generating DXF files'''

        shape_type = feedback.get('type')
        color = feedback.get('color', DEFAULT_COLOR)

        if shape_type is None:
            raise BaseException('Missing shape type')

        if shape_type == 'polyline':
            coordinates = feedback.get('coordinates')
            log.debug('Generating a polyline of %s points: %s', len(coordinates), coordinates)
            dxf = self._generate_polyline(coordinates, color)
        elif shape_type == 'text':
            text = feedback.get('text')
            position = feedback.get('position')
            dxf = self._generate_text(text, DEFAULT_TEXT_ZOOM_RATE, position, color)
        elif shape_type == 'circle':
            coordinates = feedback.get('center')
            radius = feedback.get('radius', DEFAULT_CIRCLE_RADIUS)
            log.debug('Generating a circle at %s of radius %s', coordinates, radius)
            dxf = self._generate_circle(radius, coordinates, color)
        elif shape_type == 'circle-v2':
            coordinates = feedback.get('center')
            radius = feedback.get('circle', DEFAULT_CIRCLE_RADIUS)
            log.debug('Generating a circle at %s of radius %s', coordinates, radius)
            dxf = self._generate_circle_v2(radius, coordinates, color)
        else:
            raise BaseException("Unsupported drawing type")

        size = humanize.naturalsize(sys.getsizeof(dxf))
        log.info('Generated dxf file of size %s', size)

        return dxf
