import logging
import app.config as cfg

log = logging.getLogger('em-laser-feedback')

class RequestPreprocessor:

    def run(self, payload: dict) -> list:
        '''
        Feedback payload preprocessor
        '''

        feedback_list: list = None
        if cfg.FF_PAYLOAD_DATA_NESTING:
            feedback_list = payload.get('data').get('feedback')
        else:
            feedback_list = payload.get('feedback')
        if feedback_list is None:
            log.warning('Message has no fedback %s', str(payload))
            return None
        return feedback_list
