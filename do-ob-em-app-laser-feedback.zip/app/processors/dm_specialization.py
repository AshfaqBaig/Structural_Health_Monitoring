import copy
import app.config as cfg
from app.feedback.laser_feedback_creation import LaserFeedbackCreation
from app.feedback.feedback_positions import FeedbackPositions
from app.logging.logger import yield_logger
log = yield_logger()


def _correct_last_plies_placed(dm_payload: dict) -> dict:
    new_payload = copy.deepcopy(dm_payload)
    ply_id = new_payload["metadata"]["session"]["plyId"]
    current_pallet = new_payload["feedback"][0][ply_id]["pallet_id"]
    next_pallets = new_payload["feedback"][0][ply_id]["next_plies_pallets"]
    if current_pallet not in next_pallets and new_payload["feedbackType"] == "correctly-placed-plies":
        new_payload["feedbackType"] = "pallets-last-plies-placed"
        new_payload["feedback"][0]["type"] = "pallets-last-plies-placed"
    return new_payload


def _get_expiration(feedback_type: str) -> int:
    """Get he expiration time for different ply types"""
    expirations = {
        "plies-to-be-placed": cfg.LONG_LIVED_LASER_MARK_TTL,
        "missing-plies": cfg.LONG_LIVED_LASER_MARK_TTL,
        "correctly-placed-plies": cfg.SHORT_LIVED_LASER_MARK_TTL,
        "last-plies-placed": cfg.LONG_LIVED_LASER_MARK_TTL,
        "pallets-last-plies-placed": cfg.SHORT_LIVED_LASER_MARK_TTL,
        "phantom-plies": cfg.LONG_LIVED_LASER_MARK_TTL,
        "plies-to-null": 0,
    }
    expiration = expirations.get(feedback_type)
    if expiration is not None:
        return expiration
    else:
        raise ValueError(
            f"Failed to get expiration for feedback payload creation, unrecognised feedback_type: {feedback_type}")


def _create_full_feedback(feedback_items: list[dict], ply_id: str, feedback_type: str) -> dict:
    """Function for compose the full feedback"""
    feedback_level = "error" if feedback_type == "missing-plies" else "info"
    expiration = _get_expiration(feedback_type)
    full_feedback = {
        "session": {
            "mouldId": cfg.MOULD_ID,
            "plyId": ply_id,
            "moduleId": "em-decision-maker"
        },
        "expiration": expiration,
        "feedback": feedback_items,
        "feedbackLevel": feedback_level,
        "feedbackType": feedback_type
    }
    log.debug(f"Full feedback with coordinates is composed: {full_feedback}")
    return full_feedback

def dm_message_preprocessing(payload: dict, feedback_positions: FeedbackPositions) -> dict:
    """function for composing full feedback message with coordinates"""
    payload = _correct_last_plies_placed(payload)
    ply_id = payload.get("metadata").get("session").get("plyId")
    ply_data = payload.get("feedback")[0][ply_id]
    feedback_type = payload["feedbackType"]
    feedback_items = LaserFeedbackCreation(feedback_positions).generate_feedback_items(ply_data, ply_id,
                                                                                       feedback_type)
    return _create_full_feedback(feedback_items, ply_id, feedback_type)
