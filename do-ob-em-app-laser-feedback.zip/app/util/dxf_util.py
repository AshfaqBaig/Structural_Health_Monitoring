'''Various DXF related helper methods'''

import io
import os

import ezdxf
from ezdxf.addons import Importer

from app.logging.logger import yield_logger
log = yield_logger()

DEFAULT_DXF_VERSION = os.environ.get('DEFAULT_DXF_VERSION', 'AC1032')

def _extract_entities(dxf):
    '''Extract entities from supplied DXF modelspace'''

    entities = dxf.modelspace().query('CIRCLE LINE POINT ARC TEXT POLYLINE')
    log.debug('Found %s entities in layer %s', len(entities), entities[0].dxf.layer if len(entities) > 0 else 'N/A')

    # rename entities and merge them into one
    for entity in entities:
        entity.dxf.layer = 'merged'
    return entities

def merge_dxf(projections: list):
    '''Merged all projections into single DXF. All entities are merged into single "merged" layed"'''

    target_dxf = ezdxf.new(DEFAULT_DXF_VERSION)

    for projection in projections:
        dxf_stream = io.StringIO(projection)
        dxf = ezdxf.read(dxf_stream)
        importer = Importer(dxf, target_dxf)
        entities = _extract_entities(dxf)
        importer.import_entities(entities, target_dxf.modelspace())
        importer.finalize()

    return target_dxf


def merge_dxf_str(projections: list) -> str:
    '''Merged all projections into single DXF string. All entities are merged into single "merged" layer"'''

    dxf_document = merge_dxf(projections)
    str_stream = io.StringIO()
    dxf_document.write(str_stream)
    return str_stream.getvalue()
