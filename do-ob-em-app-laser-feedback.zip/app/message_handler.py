import json
from timeit import default_timer as timer
from typing import Tuple, Any
from datetime import timedelta
import requests
from azure.iot.device.iothub.models import Message
import app.config as cfg
import app.routes_constants as route
from app.logging.logger import yield_logger

log = yield_logger()

DEFAULT_OUTPUT = "defaultOutput"
ERROR_OUTPUT = "errorOutput"

class MessageHandler:
    """Main method request handler method"""

    def __init__(self, module_client, default_processor):
        self.module_client = module_client
        self.default_processor = default_processor

    async def run(self, input_message: Message):
        '''Default message handler'''

        try:
            start = timer()
            correlation_id, custom_properties, payload = self._extract_input(input_message)
            log.info(f"Payload is {payload}. correlation_id={correlation_id}) custom_properties={custom_properties}", extra={ "correlation_id": correlation_id})
            result: dict = self.default_processor.run(payload)
            laser_hub_payload: dict = self._build_message(result, correlation_id, custom_properties)
            # pass data further to output
            response = self._invoke_laser_hub(laser_hub_payload)

            if response.status_code != requests.codes.ok:  # pylint: disable=no-member
                log.error('Failed to forward DXF to laser hub. Session: %s', payload.get('session'))

            end = timer()
            log.debug(f"Time for payload {payload.get('session')} in laser-feedback module: {timedelta(seconds=end-start)}")

        except Exception as ex:
            # pass data further to error output
            log.exception(ex)
            await self.module_client.send_message_to_output(str(ex), route.ERROR_OUTPUT)

    @staticmethod
    def _build_message(message: dict, correlation_id: str, custom_properties: Any) -> dict:
        '''Creates message to LH'''
        log.info(f"Building message with correlation_id={correlation_id} and custom_properties={custom_properties}.")
        message["correlation_id"] = correlation_id
        message["custom_properties"] = custom_properties
        return message

    @staticmethod
    def _extract_input(input_message: Message) -> Tuple:
        '''Extracts message components'''
        correlation_id = input_message.correlation_id
        custom_properties = input_message.custom_properties
        payload = json.loads(input_message.data)
        return correlation_id, custom_properties, payload

    @staticmethod
    def _invoke_laser_hub(payload: dict):
        projection_uri = f'http://{cfg.ACTIVE_LASER_HUB_HOST}:{cfg.ACTIVE_LASER_HUB_PORT}/api/projection'
        log.info('Forwarding projection to laser_hub %s. session=%s. feedback_type=%s',
                 projection_uri, payload.get('session'), payload.get('feedbackType'),
                 extra={"correlation_id": payload.get('correlation_id')})
        response = requests.post(projection_uri, json=payload,headers={'Content-type': 'application/json'}, timeout=5)
        return response
