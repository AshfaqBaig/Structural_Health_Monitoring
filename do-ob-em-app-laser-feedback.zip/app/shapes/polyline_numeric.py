import numpy as np
import ezdxf

from app.shapes.shape import Shape
from app.shapes.constants import NUMERIC_COORDINATE_DICT


class PolylineNumeric(Shape):
    """This class implements DXF numeric drawing logic"""

    def __init__(self, dxf_version: str, numeric: str, zoom_rate: int, center_coordinates: list[float], color: int):
        self.dxf_version = dxf_version
        self.numeric = numeric
        self.color = color
        self.zoom_rate = zoom_rate
        self.center_coordinates = np.array(center_coordinates)

    def _build_doc(self):
        """Numeric DXF build logic"""

        numeric_blueprint = self.numeric_coordinates()+self.center_coordinates.reshape(3, 1)

        doc = ezdxf.new(self.dxf_version)
        msp = doc.modelspace()

        msp.add_polyline3d(points=numeric_blueprint.T, dxfattribs={
            'color': self.color,
            'closed': False
        })
        doc.saveas("new_name.dxf")
        return doc

    def generate(self):
        """Generate DXF and return its string value"""

        return self._build_doc()

    def numeric_coordinates(self):
        return NUMERIC_COORDINATE_DICT[self.numeric]*self.zoom_rate
