import numpy as np
import ezdxf

from app.shapes.shape import Shape
from app.logging.logger import yield_logger
from app.shapes.polyline_numeric import PolylineNumeric
from app.shapes.polyline_symbol import PolylineSymbol
from app.shapes.constants import X_SHIFT

log = yield_logger()


class PolylineText(Shape):
    """This class implements DXF text drawing logic"""

    def __init__(self, dxf_version: str, text: str, zoom_rate: int, center_coordinates: list[float], color: int):
        self.dxf_version = dxf_version
        self.text = text
        self.color = color
        self.zoom_rate = zoom_rate
        self.center_coordinates = np.array(center_coordinates)
        self.x_shift = self.zoom_rate*X_SHIFT.get(self.text[0]) if X_SHIFT.get(self.text[0]) else 0

    def _build_doc(self):
        """Alphabet DXF build logic"""
        text_blueprints = self.text_coordinates()
        doc = ezdxf.new(self.dxf_version)
        msp = doc.modelspace()
        for blueprint in text_blueprints:
            blueprint = blueprint + self.center_coordinates.reshape(3, 1)
            msp.add_polyline3d(points=blueprint.T, dxfattribs={
                'color': self.color,
                'closed': False
            })
        return doc

    def _get_centroid_shifts(self):
        return np.arange(-2.5 * (len(self.text) - 1), 2.5 * (len(self.text) - 1) + 1, 5) * self.zoom_rate * -1

    @staticmethod
    def _rotate_coordinates_90(coordinates: np.array):
        return np.array([[0, 0, 1], [0, 0, 0], [-1, 0, 0]]).dot(coordinates)

    @staticmethod
    def _flip_x_coordinates(coordinates: np.array):
        return np.concatenate(([coordinates[0] * -1], coordinates[1:]), axis=0)

    def text_coordinates(self):
        coordinates = []
        centroid_shifts = self._get_centroid_shifts()
        for i in range(len(self.text)):
            if self.text[i].isdigit():
                digit_polyline = PolylineNumeric(self.dxf_version, self.text[i], self.zoom_rate,
                                                 self.center_coordinates, self.color)
                coordinates.append(
                    self._flip_x_coordinates(
                        self._rotate_coordinates_90(digit_polyline.numeric_coordinates())) + np.array(
                        [self.x_shift, 0, centroid_shifts[i]]).reshape(3, 1))
            else:
                alphabet_polyline = PolylineSymbol(self.dxf_version, self.text[i], self.zoom_rate,
                                                   self.center_coordinates, self.color)
                coordinates.append(
                    self._flip_x_coordinates(
                        self._rotate_coordinates_90(alphabet_polyline.symbol_coordinates())) + np.array(
                        [self.x_shift, 0, centroid_shifts[i]+self.zoom_rate*5]).reshape(3, 1))
        return coordinates
