import numpy as np
import ezdxf
from app.shapes.shape import Shape
from app.logging.logger import yield_logger
from app.shapes.constants import SYMBOL_COORDINATE_DICT

log = yield_logger()


class PolylineSymbol(Shape):
    """This class implements DXF Alphabet drawing logic"""

    def __init__(self, dxf_version: str, symbol: str, zoom_rate: int, center_coordinates: list[float], color: int):
        self.dxf_version = dxf_version
        self.symbol = symbol
        self.color = color
        self.zoom_rate = zoom_rate
        self.center_coordinates = np.array(center_coordinates)

    def _build_doc(self):
        """Alphabet DXF build logic"""
        alphabet_blueprint = self.symbol_coordinates() + self.center_coordinates.reshape(3, 1)
        doc = ezdxf.new(self.dxf_version)
        msp = doc.modelspace()
        msp.add_polyline3d(points=alphabet_blueprint.T, dxfattribs={
            'color': self.color,
            'closed': False
        })
        return doc

    def generate(self):
        """Generate DXF and return its string value"""

        return self._build_doc()

    def symbol_coordinates(self):
        if self.symbol not in "SXHRT":
            raise KeyError(f"The letter {self.symbol} is not supported yet.")
        return SYMBOL_COORDINATE_DICT[self.symbol] * self.zoom_rate
