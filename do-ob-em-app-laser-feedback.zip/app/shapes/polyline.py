# pylint: disable=missing-module-docstring

import ezdxf

from app.shapes.shape import Shape


class Polyline(Shape):
    '''This class implements DXF polyline drawing logic'''

    def __init__(self, dxf_version, coordinates, color):
        self.dxf_version = dxf_version
        self.color = color
        self.points = []
        for point in coordinates:
            self.points.append(tuple(point))

    def _build_doc(self):
        '''Polyline DXF build logic'''

        doc = ezdxf.new(self.dxf_version)

        msp = doc.modelspace()

        msp.add_polyline3d(points=self.points, dxfattribs={
            'color': self.color,
            'closed': True
        })

        return doc
