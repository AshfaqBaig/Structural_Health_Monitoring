import io

from abc import abstractmethod


class Shape:
    '''This class implements parent class for all child DXF drawing classes'''

    @staticmethod
    def _as_string(drawing):
        '''Convert DXF to string'''

        str_stream = io.StringIO()
        drawing.write(str_stream)
        dxf = str_stream.getvalue()
        return dxf

    def generate(self):
        '''Generate DXF and return its string value'''

        doc = self._build_doc()
        return self._as_string(doc)

    @abstractmethod
    def _build_doc(self):
        '''Each shape implementation should override and implement this method'''
