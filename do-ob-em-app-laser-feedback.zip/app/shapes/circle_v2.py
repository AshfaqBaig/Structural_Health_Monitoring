# pylint: disable=missing-module-docstring
import io

import numpy as np
from ezdxf.addons import r12writer

from app.shapes.shape import Shape

class CircleV2(Shape):
    '''This class implements DXF circle drawing logic kindly provided by Dirk Rannacher (SGRE)'''

    def __init__(self, dxf_version, radius, center_coordinates, color):
        self.dxf_version = dxf_version
        self.color = color
        self.radius = radius
        self.center_coordinates = np.array(center_coordinates)

    def _build_doc(self):
        '''Circle DXF build logic'''

        circ_blueprint = self.circle()

        dxf_stream = io.StringIO()
        with r12writer(dxf_stream) as dxf:
            for i in range(np.size(circ_blueprint, 1) - 1):
                dxf.add_polyline(self.center_coordinates + [(circ_blueprint[1][i], 0, circ_blueprint[0][i]),
                                                            (circ_blueprint[1][i + 1], 0, circ_blueprint[0][i + 1])],
                                 self.color)
        return dxf_stream.getvalue()

    def generate(self):
        '''Generate DXF and return its string value'''

        return self._build_doc()

    def circle(self):
        eta = np.arange(0, 360.5, 0.5) * np.pi / 180
        x = self.radius * np.cos(eta)
        y = self.radius * np.sin(eta)
        return ([x, y])
