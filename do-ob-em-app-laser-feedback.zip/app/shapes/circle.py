# pylint: disable=missing-module-docstring

import ezdxf
from ezdxf.math import OCS

from app.shapes.shape import Shape

from app.logging.logger import yield_logger
log = yield_logger()

class Circle(Shape):
    '''This class implements DXF circle drawing logic'''

    def __init__(self, dxf_version, radius, center_coordinates, color):
        self.dxf_version = dxf_version
        self.color = color
        self.radius = radius
        self.center_coordinates = tuple(center_coordinates)

    def _build_doc(self):
        '''Circle DXF build logic'''

        log.info('Building a circle of %s radius at %s', self.radius, self.center_coordinates)
        doc = ezdxf.new(self.dxf_version)

        msp = doc.modelspace()

        ocs = OCS((1, 0, 0))
        center_coordinates = ocs.from_wcs(self.center_coordinates)
        msp.add_circle(center=center_coordinates, radius=self.radius, dxfattribs={
            'color': self.color,
            'extrusion': ocs.ux,
        })

        return doc
