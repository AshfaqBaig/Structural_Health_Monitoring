from azure.iot.device import MethodResponse
from azure.iot.device.iothub.models import Message
import app.config as cfg
from app.logging.logger import yield_logger, update_log_level

log = yield_logger()

class MethodRequestHandler:
    """Main method request handler method"""

    def __init__(self, module_client, message_handler):
        self.module_client = module_client
        self.message_handler = message_handler

    async def run(self, request: dict):
        """ Module method handler entrypoint method """
        try:
            error_message = None
            status: int = None
            log.info(f'Method {request.name} invocation with: {request.payload}')
            if request.name == "set_log_level":
                status = self._update_log_level(request.payload.get("value"))
            elif request.name == "set_payload":
                status = await self._set_payload(request.payload)
            else:
                error_message = f"Unknown method request received: {request.name}"
                log.info(error_message)
                status = 500

            method_response = MethodResponse.create_from_method_request(request, status, error_message)
            await self.module_client.send_method_response(method_response)

        except Exception:
            log.exception('Unexpected error while invoking direct method')
            raise

    def _update_log_level(self, log_level: str) -> int:
        '''Update LOG_LEVEL'''

        if cfg.LOG_LEVEL != log_level:
            cfg.LOG_LEVEL = log_level
            update_log_level(log, cfg.LOG_LEVEL)
            return 200
        return 304

    async def _set_payload(self, request: dict) -> int:
        '''Method for testing payloads'''
        try:
            custom_properties = request["custom_properties"]
            correlation_id = request["correlation_id"]
            message = Message(request["data"], custom_properties, correlation_id)
            await self.message_handler.run(message)
            return 200
        except Exception:
            log.exception('Unexpected error while invoking set_payload method')
            return 500
