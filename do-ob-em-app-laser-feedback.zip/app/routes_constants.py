""" Edge Hub routes constants """


DEFAULT_INPUT = 'defaultInput'
DEFAULT_OUTPUT = 'defaultOutput'
ERROR_OUTPUT = 'errorOutput'
