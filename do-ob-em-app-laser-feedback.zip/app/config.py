'''
Module defines all configuration options
'''
import logging
import os
from distutils.util import strtobool

LOGGER_CONFIG = os.environ.get('LOGGER_CONFIG', 'logging-plain.ini')
MODULE_APP_NAME = 'laser-feedback'

MOULD_ID = os.environ.get("MOULD_ID")
IOTEDGE_DEVICEID = os.environ.get("IOTEDGE_DEVICEID")
IOTEDGE_MODULEID = os.environ.get("IOTEDGE_MODULEID")
IOTEDGE_GATEWAYHOSTNAME = os.environ.get("IOTEDGE_GATEWAYHOSTNAME")
LOG_LEVEL = os.environ.get('LOG_LEVEL', logging.INFO)
BLADE_LAYOUT_PATH = os.environ.get('BLADE_LAYOUT_PATH')
ACTIVE_LASER_HUB_HOST = os.environ.get('ACTIVE_LASER_HUB_HOST', 'localhost')
ACTIVE_LASER_HUB_PORT = os.environ.get('ACTIVE_LASER_HUB_PORT', '9080')
FF_PAYLOAD_DATA_NESTING = bool(strtobool(os.environ.get("FF_PAYLOAD_DATA_NESTING", "False")))
PROVIDE_FOUR_LASER_LINES = bool(strtobool(os.environ.get("PROVIDE_FOUR_LASER_LINES", "True")))

PROMETHEUS_PORT = int(os.environ.get("PROMETHEUS_PORT") or 9060)
DATA_PROVISIONING_PATH = os.getenv("DATA_PROVISIONING_PATH")
FEEDBACK_POSITIONS_FILE_SUFFIX = os.getenv("FEEDBACK_POSITIONS_FILE_SUFFIX", "feedback-positions")
LASER_MARK_SIZE = int(os.getenv("LASER_MARK_SIZE", "200"))

LONG_LIVED_LASER_MARK_TTL = int(os.getenv("LONG_LIVED_LASER_MARK_TTL", "600"))
SHORT_LIVED_LASER_MARK_TTL = int(os.getenv("SHORT_LIVED_LASER_MARK_TTL", "20"))

MODULE_SETTINGS_KEY = f"/devices/{IOTEDGE_GATEWAYHOSTNAME}/modules/{MODULE_APP_NAME}/settings"
ETCD_URL = os.getenv("ETCD_URL", "localhost:2379")
ETCD_TTL = int(os.getenv("ETCD_TTL", "600"))
