# pylint: disable=missing-module-docstring

import time
import asyncio
from azure.iot.device.aio import IoTHubModuleClient
from app.logging import logger
from app.processors.default import DefaultProcessor
from app.method_request_handler import MethodRequestHandler
from app.message_handler import MessageHandler
from app.blade_layout_cache import BladeLayoutCache

log = logger.yield_logger()

class MessageListener:
    '''
    Message Listener implementation. It accepts Message payloads and forwards them to request processor.
    Also module direct methods supported.
    '''

    def __init__(self, blade_layout_cache):
        self.blade_layout_cache = BladeLayoutCache()
        self.module_client = IoTHubModuleClient.create_from_edge_environment()
        self.default_processor = DefaultProcessor(blade_layout_cache)
        self.message_handler = MessageHandler(self.module_client, self.default_processor)
        self.method_request_handler = MethodRequestHandler(self.module_client, self.message_handler)

    def restart(self):
        """Restart module logic"""

        log.info("Restarting module listener")
        self.blade_layout_cache.cache = {}
        self.blade_layout_cache.init()
        self.default_processor = DefaultProcessor(self.blade_layout_cache)
        self.message_handler = MessageHandler(self.module_client, self.default_processor)

    @staticmethod
    def empty_listener():
        '''Empty listener to keep module always running'''
        while True:
            time.sleep(600) # nosemgrep: python.lang.best-practice.sleep.arbitrary-sleep

    async def run(self):
        '''Entrypoint main method'''
        try:
            await self.module_client.connect()

            self.module_client.on_message_received = self.message_handler.run
            self.module_client.on_method_request_received = self.method_request_handler.run

            log.info('Message listener started')

            # Run the empty listener in the event loop
            loop = asyncio.get_event_loop()
            user_finished = loop.run_in_executor(None, self.empty_listener)
            await user_finished

            # Finally, disconnect
            await self.module_client.disconnect()

        except Exception:
            log.exception('Unexpected error')
            raise
