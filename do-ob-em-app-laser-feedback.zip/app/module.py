import asyncio

import prometheus_client as prometheus
from prometheus_client import start_http_server

import config as cfg
from app.message_listener import MessageListener
from app.shared_storage import SharedStorage
from app.settings_change_handler import SettingsChangeHandler
from app.blade_layout_cache import BladeLayoutCache

from app.logging.logger import yield_logger
log = yield_logger()

class Module():
    """Module wrapper class"""

    def __init__(self):
        self.shared_storage = SharedStorage(cfg.ETCD_URL, cfg.ETCD_TTL)
        self.blade_layout_cache = BladeLayoutCache()
        self.blade_layout_cache.init()
        self.message_listener = MessageListener(self.blade_layout_cache)

    def start(self):
        """"Start module"""

        Module.initialize_prometheus()
        self.subscribe_on_settings_change()
        asyncio.run(self.message_listener.run())

    def subscribe_on_settings_change(self):
        """Listen for configurational changes"""

        settings_change_handler = SettingsChangeHandler(self.restart)
        self.shared_storage.watch_key(cfg.MODULE_SETTINGS_KEY, settings_change_handler.on_settings_change)

    def restart(self):
        """Reinitialise module"""

        # start
        self.message_listener.restart()

    @staticmethod
    def initialize_prometheus():
        """Start Prometheus server"""

        prometheus.REGISTRY.unregister(prometheus.PROCESS_COLLECTOR)
        prometheus.REGISTRY.unregister(prometheus.PLATFORM_COLLECTOR)
        prometheus.REGISTRY.unregister(prometheus.GC_COLLECTOR)
        start_http_server(cfg.PROMETHEUS_PORT)
