"""Application entrypoint module"""

import config as cfg
from app.module import Module
from app.logging.logger import yield_logger, update_log_level

log = yield_logger()
update_log_level(log, cfg.LOG_LEVEL)

if __name__ == "__main__":
    module = Module()
    module.start()
