import app.config as cfg
from app.feedback.ground_truth_util import validate, get_file_name, get_file_path, merge_dicts_of_data_structures, \
    attempt_to_read
from app.feedback.team_instructions import TeamInstructions
from app.feedback.feedback_positions import FeedbackPositions

from app.logging.logger import yield_logger
log = yield_logger()

class GroundTruthDataService:
    """Service responsible for caching and resolving correct groundtruth data from external files"""

    def __init__(self):
        self.feedback_position: dict = {}

    def get_feedback_position(self, team_instructions: TeamInstructions, ply_layer_id: str):
        """Compose the feedback coordinates"""
        self._validate_team_instructions(team_instructions)
        ground_truth_version = team_instructions.ground_truth_version
        self._load_feedback_position(team_instructions, ground_truth_version, ply_layer_id)
        return self.feedback_position.get(ground_truth_version).get(ply_layer_id)

    def _load_feedback_position(self, team_instructions: TeamInstructions, ground_truth_version: str, ply_layer_id: str):
        if ground_truth_version not in self.feedback_position:
            self.feedback_position[ground_truth_version] = {}

        if ply_layer_id not in self.feedback_position[ground_truth_version]:
            self.feedback_position[ground_truth_version][ply_layer_id] = FeedbackPositions(
                    self._read_files(team_instructions))

    @staticmethod
    def _validate_team_instructions(team_instructions):
        """Valid the team instruction object"""
        if not team_instructions.ground_truth_version \
                or not team_instructions.layer_id \
                or not team_instructions.blade_revision:
            raise ValueError(
                f"Team instructions requires 'ground_truth_data_version', 'blade_revision' and 'layer_id' properties. "
                f"Got: {team_instructions}")

    @staticmethod
    def _read_files(team_instructions: TeamInstructions) -> dict:
        """ Reads file from file system for given filepath (parameters). """
        mould_id = team_instructions.mould_id
        blade_revision = team_instructions.blade_revision
        ground_truth_version = team_instructions.ground_truth_version
        layer_ids = team_instructions.layer_ids

        path = cfg.DATA_PROVISIONING_PATH
        log.debug(f"Data provisiong path is {path}")
        file_suffix = cfg.FEEDBACK_POSITIONS_FILE_SUFFIX

        merged_files_data: dict = {}

        for layer_id in sorted(layer_ids):
            file_name = get_file_name(mould_id, blade_revision, layer_id, file_suffix)
            file_path = get_file_path(path, mould_id, ground_truth_version, file_name)
            file_data = attempt_to_read(file_path)
            if file_data:
                validate(file_data, file_path, mould_id, blade_revision)
                merged_files_data = merge_dicts_of_data_structures(merged_files_data, file_data)
            else:
                error_message = f"Failed to load {file_suffix} for given mould_id: {mould_id}, " \
                                f"blade_revision: {blade_revision}, ground_truth_version: {ground_truth_version} " \
                                f"and layer_ids: {layer_ids} taken from Team Instructions."
                raise ValueError(error_message) from None

        return merged_files_data
