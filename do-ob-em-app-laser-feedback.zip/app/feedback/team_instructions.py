class TeamInstructions:
    """Team instructions object used for fetching correct data for the verifier"""

    def __init__(self, team_instructions: dict):
        self._ground_truth_version: str = team_instructions.get("groundTruthVersion")
        self._mould_id: str = team_instructions.get("mouldId")
        self._blade_id: str = team_instructions.get("bladeId")
        self._blade_revision: str = team_instructions.get("bladeRevision")
        self._layers: list[str] = team_instructions.get("layers")

    @property
    def ground_truth_version(self) -> str:
        return self._ground_truth_version

    @property
    def mould_id(self) -> str:
        """Team instructions mould id"""
        return self._mould_id

    @property
    def blade_id(self) -> str:
        """Team instructions blade id"""
        return self._blade_id

    @property
    def blade_revision(self) -> str:
        """Team instructions blade revision"""
        return self._blade_revision

    @property
    def layer_id(self) -> str:
        """Team instructions layer id"""
        return self._layers[0]

    @property
    def layer_ids(self) -> list:
        """Team instructions layer id"""
        return self._layers

    def __repr__(self):
        return f'TeamInstructions(ground_truth_data_version={self._ground_truth_version}, ' \
               f'mould_id={self._mould_id}, blade_id={self._blade_id}, ' \
               f'blade_revision={self._blade_revision}, layers={self._layers}))'

    def __eq__(self, other):
        if not isinstance(other, TeamInstructions):
            return NotImplemented

        return self._ground_truth_version == other.ground_truth_version and \
               self._mould_id == other.mould_id and self._blade_id == other.blade_id and \
               self.blade_revision == other.blade_revision and self.layer_id == other.layer_id

    def __hash__(self):
        return hash(self._ground_truth_version) ^ hash(self._mould_id) ^ hash(self._blade_id) \
               ^ hash(self._blade_revision) ^ hash(self.layer_id)
