""" Module for storing and processing feedback positions """


class FeedbackPositions:
    """ Model for storing feedback positions. """

    def __init__(self, feedback_positions: dict):
        self._feedback_positions = feedback_positions

    @property
    def mould_id(self) -> str:
        """ Get the mould_id assigned to feedback positions. """
        return self._feedback_positions["mould_id"]

    @property
    def blade_revision(self) -> str:
        """ Get the blade_revision assigned to feedback positions. """
        return self._feedback_positions["blade_revision"]

    def get_mid_point(self, ply_id: str) -> list[int]:
        """ Returns ply's mid point by given ply_id. """
        return self._feedback_positions["plies"][ply_id]["mid_point"]
