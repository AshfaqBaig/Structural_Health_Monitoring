""" Module to create feedback laser marks. """

from app.feedback.feedback_positions import FeedbackPositions

from app.logging.logger import yield_logger
log = yield_logger()

class LaserFeedbackCreation:
    """
    Class to create feedback items for laser marks to be displayed on the mould.

    Different feedback_type messages can be generated: "missing-plies", "plies-to-be-placed", "phantom-plies",
    "last-plies-placed" and "correctly-placed-plies".\n
    Two different type of feedback items can be generated: polyline and dxf-id.\n
    For both type feedback items feedback_level can be "error" or "info".\n
    Polyline items generated to make figures to laser on the mould:\n
    ◊ - a rhombus for plies-to-be-placed;\n
    ⧖ - a hourglass for phantom-plies;\n
    X - a cross for missing-plies;\n
    Δ - a triangle for correctly-placed-plies.
    □ - a square for last-plies-placed and pallets-last-plies-placed.
    """

    def __init__(self, feedback_positions: FeedbackPositions):
        self._feedback_positions = feedback_positions

    def generate_feedback_items(self, ply: dict, ply_id: str, feedback_type: str) -> list[dict]:
        """
        Generates feedback items, used to display laser marks on the mould, for given ply and feedback_type.\n

        :returns: list of feedback items: polyline and dxf-id for "missing-plies", "plies-to-be-placed",
            "phantom-plies", "plies-to-be-placed" and "correctly-placed-plies",
            only polyline items for "last-plies-placed"
            or empty feedback items list for "plies-to-null".
        """
        self._require_not_empty(ply, ply_id)

        # NOTE: implement in Strategy pattern
        feedback_items = []
        if feedback_type in ["correctly-placed-plies"]:
            contour_item = self._generate_edge_contour_4_lines(ply)
            feedback_items.append(contour_item)
            text_item = self._generate_ply_id_text(ply_id, "T")
            feedback_items.append(text_item)
        elif feedback_type in ["last-plies-placed", "pallets-last-plies-placed"]:
            contour_item = self._generate_edge_contour_4_lines(ply)
            feedback_items.append(contour_item)
            text_item = self._generate_ply_id_text(ply_id, "S" + self._get_short_ply_id(ply_id))
            feedback_items.append(text_item)
        elif feedback_type in ["missing-plies"]:
            contour_item = self._generate_edge_contour_4_lines(ply)
            feedback_items.append(contour_item)
            text_item = self._generate_ply_id_text(ply_id, "X"+self._get_short_ply_id(ply_id))
            feedback_items.append(text_item)
        elif feedback_type in ["plies-to-be-placed"]:
            contour_item = self._generate_edge_contour_6_lines(ply)
            feedback_items.append(contour_item)
            text_item = self._generate_ply_id_text(ply_id, "R"+self._get_short_ply_id(ply_id))
            feedback_items.append(text_item)
        elif feedback_type in ["phantom-plies"]:
            contour_item = self._generate_edge_contour_6_lines(ply)
            feedback_items.append(contour_item)
            text_item = self._generate_ply_id_text(ply_id, "H" + self._get_short_ply_id(ply_id))
            feedback_items.append(text_item)
        elif feedback_type != "plies-to-null":
            error_message = f"Failed to generate laser marks for feedback, unrecognised feedback_type={feedback_type}"
            log.error(error_message)
            raise ValueError(error_message)
        return feedback_items

    @staticmethod
    def _require_not_empty(ply: dict, ply_id: str) -> None:
        if ply == {}:
            raise ValueError(f"Failed to generate feedback items, given ply for ply_id {ply_id} is empty dict: {ply}")

    @staticmethod
    def _generate_figure(polyline_coordinates: list) -> list:
        """ Creates cross figure from two polyline items, while triangle only from one polyline item. """
        polyline_items = []
        for coordinates in polyline_coordinates:
            polyline = {
                "type": "polyline",
                "coordinates": coordinates
            }
            polyline_items.append(polyline)
        return polyline_items

    @staticmethod
    def _generate_edge_contour_6_lines(ply: dict) -> dict:
        """ Creates edge marks, dxf-id type item, for given ply. """
        dxf_item = {
            "type": "contour-6-lines",
            "dxfId": ply["dxf_id"],
            "dxfPlyId": ply["dxf_ply_id"]
        }
        return dxf_item

    @staticmethod
    def _generate_edge_contour_4_lines(ply: dict) -> dict:
        """ Creates edge marks for previous plies, dxf-previous-id type item. """
        dxf_item = {
            "type": "contour-4-lines",
            "dxfId": ply["dxf_id"],
            "dxfPlyId": ply["dxf_ply_id"]
        }
        return dxf_item

    def _generate_ply_id_text(self, ply_id: str, text: str) -> dict:
        """ Creates edge marks for previous plies, dxf-previous-id type item. """
        ply_mid_point = self._feedback_positions.get_mid_point(ply_id)
        dxf_item = {
            "type": "text",
            "text": text,
            "position": ply_mid_point
        }
        return dxf_item

    @staticmethod
    def _get_short_ply_id(ply_id):
        try:
            return str(int(ply_id[-3:]))
        except ValueError:
            return ply_id[-3:]
