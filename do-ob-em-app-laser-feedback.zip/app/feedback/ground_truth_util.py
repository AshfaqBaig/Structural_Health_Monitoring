""" functions for reading ground truth data """

import json
import os
from os import access, R_OK
from os.path import isfile

from app.logging.logger import yield_logger
log = yield_logger()

def load_json_from_file(path: str) -> dict:
    """ Reads JSON from file, parses and returns content as dict type. """
    log.info(f"Checking R/O file {path}")
    assert isfile(path) and access(path, R_OK), f"File {path} doesn't exist or isn't readable"
    filesize = os.path.getsize(path)
    if filesize == 0:
        raise ValueError(f"Can't process empty file: {path}")

    try:
        with open(path, "r", encoding='utf-8') as file_handle:
            file_content = file_handle.read()
            return json.loads(file_content)
    except (OSError, IOError) as exc:
        log.error(f"Error parsing file {path}: \t {exc}")


def get_file_path(path: str, folder_name: str, ground_truth_version: str, file_name: str) -> str:
    """Get the ground truth file path"""
    file_path = os.path.join(path, folder_name, ground_truth_version, file_name)
    log.debug(f"The file path is {file_path}")
    return file_path


def get_file_name(mould_id: str, blade_revision: str, layer_id: str, file_suffix: str) -> str:
    """Get the ground truth file name"""
    file_name = f"{mould_id}-{blade_revision}-{layer_id}-{file_suffix}.json"
    log.debug(f"The file name is {file_name}")
    return file_name


def attempt_to_read(file_path: str) -> dict:
    """Read the ground truth file"""
    log.info(f"Attempting to read file: {file_path}")
    if isfile(file_path):
        log.info(f"Found file: {file_path}, loading....")
        return load_json_from_file(file_path)
    else:
        log.warning(f"Did not found file: {file_path}")


def validate(file_data: dict, file_path: str, mould_id: str, blade_revision: str) -> None:
    """Get the ground truth file path"""
    if _is_matching(file_data, mould_id, blade_revision):
        log.info(f"Successfully loaded {file_path} from file")
    else:
        error_message = f"Data in file: {file_path}, do not match given mould_id: {mould_id} " \
                        f"and blade_revision: {blade_revision} from Team Instructions."
        raise ValueError(error_message)


def _is_matching(file_data: dict, mould_id: str, blade_revision: str) -> bool:
    """Check if the ground truth data matching the input or not"""
    try:
        return file_data["mould_id"] == mould_id and file_data["blade_revision"] == blade_revision
    except KeyError as ex:
        error_message = f"Missing mould_id or blade_revision attribute: {ex}, in file"
        raise Exception(error_message) from None


def merge_dicts_of_data_structures(dict_1: dict, dict_2: dict) -> dict:
    """Merge data"""
    merged_dict = {**dict_2}
    for key, value in merged_dict.items():
        if key in dict_1 and key in dict_2:
            _merge_dicts_only(dict_1, key, value, merged_dict)

    return merged_dict


def _merge_dicts_only(dict_1: dict, key: dict, value: dict, merged_dict: dict) -> None:
    """Merge data dictionaries"""
    if isinstance(value, dict) and isinstance(dict_1[key], dict):
        merged_dict[key] = {**value, **dict_1[key]}
