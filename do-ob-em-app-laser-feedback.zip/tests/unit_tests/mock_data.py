# pylint: disable=protected-access, missing-class-docstring, missing-function-docstring, too-few-public-methods, too-many-lines

static_graph_data: dict = {
    "mould_id": "mould_id",
    "blade_revision": "blade_revision",
    "version": "v1.0.0",
    "plies": {
        "P1": {
            "pallet_id": "pallet_p_1",
            "dxf_id": "dxf_id_P",
            "layer_id": "layer_id_P",
            "dxf_ply_id": "dxf_ply_id_P1",
            "edges": ["P1.1", "P1.2"],
            "edges_covered": [],
            "previous_plies": [],
            "next_plies": ["P2"],
        },
        "P2": {
            "pallet_id": "pallet_p_1",
            "dxf_id": "dxf_id_P",
            "layer_id": "layer_id_P",
            "dxf_ply_id": "dxf_ply_id_P2",
            "edges": ["P2.1", "P2.2"],
            "edges_covered": ["P1.2"],
            "previous_plies": ["P1"],
            "next_plies": ["P3"],
        },
        "P3": {
            "pallet_id": "pallet_p_1",
            "dxf_id": "dxf_id_P",
            "layer_id": "layer_id_P",
            "dxf_ply_id": "dxf_ply_id_P3",
            "edges": ["P3.1", "P3.2"],
            "edges_covered": ["P2.2"],
            "previous_plies": ["P2"],
            "next_plies": [],
        },
        "P4": {
            "pallet_id": "pallet_p_2",
            "dxf_id": "dxf_id_P",
            "layer_id": "layer_id_P",
            "dxf_ply_id": "dxf_ply_id_P4",
            "edges": ["P4.1", "P4.2"],
            "edges_covered": ["P3.2"],
            "previous_plies": [],
            "next_plies": ["P5"],
        },
        "P5": {
            "pallet_id": "pallet_p_2",
            "dxf_id": "dxf_id_P",
            "layer_id": "layer_id_P",
            "dxf_ply_id": "dxf_ply_id_P5",
            "edges": ["P5.1", "P5.2"],
            "edges_covered": ["P4.2"],
            "previous_plies": ["P4"],
            "next_plies": ["P6"],
        },
        "P6": {
            "pallet_id": "pallet_p_2",
            "dxf_id": "dxf_id_P",
            "layer_id": "layer_id_P",
            "dxf_ply_id": "dxf_ply_id_P6",
            "edges": ["P6.1", "P6.2"],
            "edges_covered": ["P5.2"],
            "previous_plies": ["P5"],
            "next_plies": [],
        },
        "P7": {
            "pallet_id": "pallet_p_3",
            "dxf_id": "dxf_id_P",
            "layer_id": "layer_id_P",
            "dxf_ply_id": "dxf_ply_id_P7",
            "edges": ["P7.1", "P7.2"],
            "edges_covered": ["P6.2"],
            "previous_plies": [],
            "next_plies": ["P8"],
        },
        "P8": {
            "pallet_id": "pallet_p_3",
            "dxf_id": "dxf_id_P",
            "layer_id": "layer_id_P",
            "dxf_ply_id": "dxf_ply_id_P8",
            "edges": ["P8.1", "P8.2"],
            "edges_covered": ["P7.2"],
            "previous_plies": ["P7"],
            "next_plies": ["P9"],
        },
        "P9": {
            "pallet_id": "pallet_p_3",
            "dxf_id": "dxf_id_P",
            "layer_id": "layer_id_P",
            "dxf_ply_id": "dxf_ply_id_P9",
            "edges": ["P9.1", "P9.2"],
            "edges_covered": ["P8.2"],
            "previous_plies": ["P8"],
            "next_plies": [],
        },

        # supposedly upper layer plies, alike layer UD1 starting at pallet_4
        "U1": {
            "pallet_id": "pallet_u_1",
            "dxf_id": "dxf_id_U",
            "layer_id": "layer_id_U",
            "dxf_ply_id": "dxf_ply_id_U1",
            "edges": ["U1.1", "U1.2"],
            "edges_covered": [],
            "previous_plies": [],
            "next_plies": ["U2"],
        },
        "U2": {
            "pallet_id": "pallet_u_1",
            "dxf_id": "dxf_id_U",
            "layer_id": "layer_id_U",
            "dxf_ply_id": "dxf_ply_id_U2",
            "edges": ["U2.1", "U2.2"],
            "edges_covered": ["U1.2"],
            "previous_plies": ["U1"],
            "next_plies": ["U3"],
        },
        "U3": {
            "pallet_id": "pallet_u_1",
            "dxf_id": "dxf_id_U",
            "layer_id": "layer_id_U",
            "dxf_ply_id": "dxf_ply_id_U3",
            "edges": ["U3.1", "U3.2"],
            "edges_covered": ["U2.2"],
            "previous_plies": ["U2"],
            "next_plies": ["U4"],
        },
        "U4": {
            "pallet_id": "pallet_u_1",
            "dxf_id": "dxf_id_U",
            "layer_id": "layer_id_U",
            "dxf_ply_id": "dxf_ply_id_U4",
            "edges": ["U4.1", "U4.2"],
            "edges_covered": ["U3.2"],
            "previous_plies": ["U3"],
            "next_plies": ["U5"],
        },
        "U5": {
            "pallet_id": "pallet_u_1",
            "dxf_id": "dxf_id_U",
            "layer_id": "layer_id_U",
            "dxf_ply_id": "dxf_ply_id_U5",
            "edges": ["U5.1", "U5.2"],
            "edges_covered": ["U4.2"],
            "previous_plies": ["U4"],
            "next_plies": ["U6"],
        },
        "U6": {
            "pallet_id": "pallet_u_1",
            "dxf_id": "dxf_id_U",
            "layer_id": "layer_id_U",
            "dxf_ply_id": "dxf_ply_id_U6",
            "edges": ["U6.1", "U6.2"],
            "edges_covered": ["U1.1", "U2.1", "U3.1", "U4.1", "U5.1", "U5.2"],
            "previous_plies": ["U1", "U2", "U3", "U4", "U5"],
            "next_plies": ["U7"],
        },
        "U7": {
            "pallet_id": "pallet_u_1",
            "dxf_id": "dxf_id_U",
            "layer_id": "layer_id_U",
            "dxf_ply_id": "dxf_ply_id_U7",
            "edges": ["U7.1", "U7.2"],
            "edges_covered": ["U6.2"],
            "previous_plies": ["U6"],
            "next_plies": [],
        },
    }
}


def create_decision_maker_message(feedback_type: str) -> dict:
    decision_maker_message = {}
    for ply in static_graph_data["plies"].keys():
        refactored_ply_data = {k: v for k, v in static_graph_data["plies"][ply].items() if k not in ["edges", "edges_covered"]}
        refactored_ply_data["next_plies_pallets"] = [static_graph_data["plies"][p]["pallet_id"] for p in static_graph_data["plies"][ply]["next_plies"]]
        decision_maker_message[ply] = {
            "metadata": {
                "session": {
                    "mouldId": static_graph_data["mould_id"],
                    "plyId": ply,
                    "moduleId": "em-decision-maker"
                },
                "groundTruthVersion": static_graph_data["version"],
                "mouldId": static_graph_data["mould_id"],
                "bladeSn": "blade_sn",
                "bladeRevision": static_graph_data["blade_revision"],
                "layers": [
                    static_graph_data["plies"][ply]["layer_id"]
                ]
            },
            "feedback": [
                {
                    "type": feedback_type,
                    ply: refactored_ply_data
                }
            ],
            "feedbackType": feedback_type
        }
    return decision_maker_message


dm_message_missing_plies = create_decision_maker_message("missing-plies")
dm_message_plies_to_be_placed = create_decision_maker_message("plies-to-be-placed")
dm_message_correctly_placed_plies = create_decision_maker_message("correctly-placed-plies")
dm_message_pallets_last_plies_placed = create_decision_maker_message("pallets-last-plies-placed")
dm_message_phantom_plies = create_decision_maker_message("phantom-plies")
dm_message_plies_to_null = create_decision_maker_message("plies-to-null")
dm_message_last_plies_placed = create_decision_maker_message("last-plies-placed")


feedback_positions_data: dict = {
    "mould_id": "mould_id",
    "blade_revision": "blade_revision",
    "version": "v1.0.0",
    "plies": {
        "P1": {
            "mid_point": [1, 0, 1]
        },
        "P2": {
            "mid_point": [1, 0, 2]
        },
        "P3": {
            "mid_point": [1, 0, 3]
        },
        "P4": {
            "mid_point": [1, 0, 4]
        },
        "P5": {
            "mid_point": [1, 0, 5]
        },
        "P6": {
            "mid_point": [1, 0, 6]
        },
        "P7": {
            "mid_point": [1, 0, 7]
        },
        "P8": {
            "mid_point": [1, 0, 8]
        },
        "P9": {
            "mid_point": [1, 0, 9]
        },

        "U1": {
            "mid_point": [1, 1, 1]
        },
        "U2": {
            "mid_point": [1, 1, 2]
        },
        "U3": {
            "mid_point": [1, 1, 3]
        },
        "U4": {
            "mid_point": [1, 1, 4]
        },
        "U5": {
            "mid_point": [1, 1, 5]
        },
        "U6": {
            "mid_point": [1, 1, 6]
        },
        "U7": {
            "mid_point": [1, 1, 7]
        },
    }
}


class ExpectedFullFeedback:
    class PliesToBePlaced:
        class FirstPalletP:
            first_ply = {
                "session": {"mouldId": "mould_id", "plyId": "P1", "moduleId": "em-decision-maker"},
                "expiration": 600,
                "feedback": [
                    {
                        "type": "contour-6-lines",
                        "dxfId": "dxf_id_P",
                        "dxfPlyId": "dxf_ply_id_P1"
                    },
                    {
                        "type": "text",
                        "text": "RP1",
                        "position": [1, 0, 1],
                    }
                ],
                "feedbackLevel": "info",
                "feedbackType": "plies-to-be-placed"
            }
            second_ply = {
                "session": {"mouldId": "mould_id", "plyId": "P2", "moduleId": "em-decision-maker"},
                "expiration": 600,
                "feedback": [
                    {
                        "type": "contour-6-lines",
                        "dxfId": "dxf_id_P",
                        "dxfPlyId": "dxf_ply_id_P2",
                    },
                    {
                        "type": "text",
                        "text": "RP2",
                        "position": [1, 0, 2],
                    }
                ],
                "feedbackLevel": "info",
                "feedbackType": "plies-to-be-placed",
            }
            third_ply = {
                "session": {"mouldId": "mould_id", "plyId": "P3", "moduleId": "em-decision-maker"},
                "expiration": 600,
                "feedback": [
                    {
                        "type": "contour-6-lines",
                        "dxfId": "dxf_id_P",
                        "dxfPlyId": "dxf_ply_id_P3"
                    },
                    {
                        "type": "text",
                        "text": "RP3",
                        "position": [1, 0, 3],
                    }
                ],
                "feedbackLevel": "info",
                "feedbackType": "plies-to-be-placed",
            }

        class SecondPalletP:
            fourth_ply = {
                "session": {"mouldId": "mould_id", "plyId": "P4", "moduleId": "em-decision-maker"},
                "expiration": 600,
                "feedback": [
                    {
                        "type": "contour-6-lines",
                        "dxfId": "dxf_id_P",
                        "dxfPlyId": "dxf_ply_id_P4"
                    },
                    {
                        "type": "text",
                        "text": "RP4",
                        "position": [1, 0, 4],
                    }
                ],
                "feedbackLevel": "info",
                "feedbackType": "plies-to-be-placed"
            }
            fifth_ply = {
                "session": {"mouldId": "mould_id", "plyId": "P5", "moduleId": "em-decision-maker"},
                "expiration": 600,
                "feedback": [
                    {
                        "type": "contour-6-lines",
                        "dxfId": "dxf_id_P",
                        "dxfPlyId": "dxf_ply_id_P5",
                    },
                    {
                        "type": "text",
                        "text": "RP5",
                        "position": [1, 0, 5],
                    }
                ],
                "feedbackLevel": "info",
                "feedbackType": "plies-to-be-placed",
            }
            sixth_ply = {
                "session": {"mouldId": "mould_id", "plyId": "P6", "moduleId": "em-decision-maker"},
                "expiration": 600,
                "feedback": [
                    {
                        "type": "contour-6-lines",
                        "dxfId": "dxf_id_P",
                        "dxfPlyId": "dxf_ply_id_P6"
                    },
                    {
                        "type": "text",
                        "text": "RP6",
                        "position": [1, 0, 6],
                    }
                ],
                "feedbackLevel": "info",
                "feedbackType": "plies-to-be-placed",
            }

        class ThirdPalletP:
            seventh_ply = {
                "session": {"mouldId": "mould_id", "plyId": "P7", "moduleId": "em-decision-maker"},
                "expiration": 600,
                "feedback": [
                    {
                        "type": "contour-6-lines",
                        "dxfId": "dxf_id_P",
                        "dxfPlyId": "dxf_ply_id_P7"
                    },
                    {
                        "type": "text",
                        "text": "RP7",
                        "position": [1, 0, 7],
                    }
                ],
                "feedbackLevel": "info",
                "feedbackType": "plies-to-be-placed"
            }
            eighth_ply = {
                "session": {"mouldId": "mould_id", "plyId": "P8", "moduleId": "em-decision-maker"},
                "expiration": 600,
                "feedback": [
                    {
                        "type": "contour-6-lines",
                        "dxfId": "dxf_id_P",
                        "dxfPlyId": "dxf_ply_id_P8",
                    },
                    {
                        "type": "text",
                        "text": "RP8",
                        "position": [1, 0, 8],
                    }
                ],
                "feedbackLevel": "info",
                "feedbackType": "plies-to-be-placed",
            }
            ninth_ply = {
                "session": {"mouldId": "mould_id", "plyId": "P9", "moduleId": "em-decision-maker"},
                "expiration": 600,
                "feedback": [
                    {
                        "type": "contour-6-lines",
                        "dxfId": "dxf_id_P",
                        "dxfPlyId": "dxf_ply_id_P9"
                    },
                    {
                        "type": "text",
                        "text": "RP9",
                        "position": [1, 0, 9],
                    }
                ],
                "feedbackLevel": "info",
                "feedbackType": "plies-to-be-placed",
            }

        class FirstPalletU:
            first_ply = {
                "session": {"mouldId": "mould_id", "plyId": "U1", "moduleId": "em-decision-maker"},
                "expiration": 600,
                "feedback": [
                    {
                        "type": "contour-6-lines",
                        "dxfId": "dxf_id_U",
                        "dxfPlyId": "dxf_ply_id_U1"
                    },
                    {
                        "type": "text",
                        "text": "RU1",
                        "position": [1, 1, 1],
                    }
                ],
                "feedbackLevel": "info",
                "feedbackType": "plies-to-be-placed"
            }
            second_ply = {
                "session": {"mouldId": "mould_id", "plyId": "U2", "moduleId": "em-decision-maker"},
                "expiration": 600,
                "feedback": [
                    {
                        "type": "contour-6-lines",
                        "dxfId": "dxf_id_U",
                        "dxfPlyId": "dxf_ply_id_U2",
                    },
                    {
                        "type": "text",
                        "text": "RU2",
                        "position": [1, 1, 2],
                    }
                ],
                "feedbackLevel": "info",
                "feedbackType": "plies-to-be-placed",
            }
            third_ply = {
                "session": {"mouldId": "mould_id", "plyId": "U3", "moduleId": "em-decision-maker"},
                "expiration": 600,
                "feedback": [
                    {
                        "type": "contour-6-lines",
                        "dxfId": "dxf_id_U",
                        "dxfPlyId": "dxf_ply_id_U3"
                    },
                    {
                        "type": "text",
                        "text": "RU3",
                        "position": [1, 1, 3],
                    }
                ],
                "feedbackLevel": "info",
                "feedbackType": "plies-to-be-placed",
            }
            fourth_ply = {
                "session": {"mouldId": "mould_id", "plyId": "U4", "moduleId": "em-decision-maker"},
                "expiration": 600,
                "feedback": [
                    {
                        "type": "contour-6-lines",
                        "dxfId": "dxf_id_U",
                        "dxfPlyId": "dxf_ply_id_U4"
                    },
                    {
                        "type": "text",
                        "text": "RU4",
                        "position": [1, 1, 4],
                    }
                ],
                "feedbackLevel": "info",
                "feedbackType": "plies-to-be-placed"
            }
            fifth_ply = {
                "session": {"mouldId": "mould_id", "plyId": "U5", "moduleId": "em-decision-maker"},
                "expiration": 600,
                "feedback": [
                    {
                        "type": "contour-6-lines",
                        "dxfId": "dxf_id_U",
                        "dxfPlyId": "dxf_ply_id_U5",
                    },
                    {
                        "type": "text",
                        "text": "RU5",
                        "position": [1, 1, 5],
                    }
                ],
                "feedbackLevel": "info",
                "feedbackType": "plies-to-be-placed",
            }
            sixth_ply = {
                "session": {"mouldId": "mould_id", "plyId": "U6", "moduleId": "em-decision-maker"},
                "expiration": 600,
                "feedback": [
                    {
                        "type": "contour-6-lines",
                        "dxfId": "dxf_id_U",
                        "dxfPlyId": "dxf_ply_id_U6"
                    },
                    {
                        "type": "text",
                        "text": "RU6",
                        "position": [1, 1, 6],
                    }
                ],
                "feedbackLevel": "info",
                "feedbackType": "plies-to-be-placed",
            }
            seventh_ply = {
                "session": {"mouldId": "mould_id", "plyId": "U7", "moduleId": "em-decision-maker"},
                "expiration": 600,
                "feedback": [
                    {
                        "type": "contour-6-lines",
                        "dxfId": "dxf_id_U",
                        "dxfPlyId": "dxf_ply_id_U7"
                    },
                    {
                        "type": "text",
                        "text": "RU7",
                        "position": [1, 1, 7],
                    }
                ],
                "feedbackLevel": "info",
                "feedbackType": "plies-to-be-placed"
            }

    class PhantomPlies:
        class FirstPalletP:
            first_ply = {
                "session": {"mouldId": "mould_id", "plyId": "P1", "moduleId": "em-decision-maker"},
                "expiration": 600,
                "feedback": [
                    {
                        "type": "contour-6-lines",
                        "dxfId": "dxf_id_P",
                        "dxfPlyId": "dxf_ply_id_P1"
                    },
                    {
                        "type": "text",
                        "text": "HP1",
                        "position": [1, 0, 1],
                    }
                ],
                "feedbackLevel": "info",
                "feedbackType": "phantom-plies"
            }
            second_ply = {
                "session": {"mouldId": "mould_id", "plyId": "P2", "moduleId": "em-decision-maker"},
                "expiration": 600,
                "feedback": [
                    {
                        "type": "contour-6-lines",
                        "dxfId": "dxf_id_P",
                        "dxfPlyId": "dxf_ply_id_P2"
                    },
                    {
                        "type": "text",
                        "text": "HP2",
                        "position": [1, 0, 2],
                    }
                ],
                "feedbackLevel": "info",
                "feedbackType": "phantom-plies",
            }
            third_ply = {
                "session": {"mouldId": "mould_id", "plyId": "P3", "moduleId": "em-decision-maker"},
                "expiration": 600,
                "feedback": [
                    {
                        "type": "contour-6-lines",
                        "dxfId": "dxf_id_P",
                        "dxfPlyId": "dxf_ply_id_P3"
                    },
                    {
                        "type": "text",
                        "text": "HP3",
                        "position": [1, 0, 3],
                    }
                ],
                "feedbackLevel": "info",
                "feedbackType": "phantom-plies",
            }

        class SecondPalletP:
            fourth_ply = {
                "session": {"mouldId": "mould_id", "plyId": "P4", "moduleId": "em-decision-maker"},
                "expiration": 600,
                "feedback": [
                    {
                        "type": "contour-6-lines",
                        "dxfId": "dxf_id_P",
                        "dxfPlyId": "dxf_ply_id_P4"
                    },
                    {
                        "type": "text",
                        "text": "HP4",
                        "position": [1, 0, 4],
                    }
                ],
                "feedbackLevel": "info",
                "feedbackType": "phantom-plies"
            }
            fifth_ply = {
                "session": {"mouldId": "mould_id", "plyId": "P5", "moduleId": "em-decision-maker"},
                "expiration": 600,
                "feedback": [
                    {
                        "type": "contour-6-lines",
                        "dxfId": "dxf_id_P",
                        "dxfPlyId": "dxf_ply_id_P5"
                    },
                    {
                        "type": "text",
                        "text": "HP5",
                        "position": [1, 0, 5],
                    }
                ],
                "feedbackLevel": "info",
                "feedbackType": "phantom-plies",
            }
            sixth_ply = {
                "session": {"mouldId": "mould_id", "plyId": "P6", "moduleId": "em-decision-maker"},
                "expiration": 600,
                "feedback": [
                    {
                        "type": "contour-6-lines",
                        "dxfId": "dxf_id_P",
                        "dxfPlyId": "dxf_ply_id_P6"
                    },
                    {
                        "type": "text",
                        "text": "HP6",
                        "position": [1, 0, 6],
                    }
                ],
                "feedbackLevel": "info",
                "feedbackType": "phantom-plies",
            }

        class ThirdPalletP:
            seventh_ply = {
                "session": {"mouldId": "mould_id", "plyId": "P7", "moduleId": "em-decision-maker"},
                "expiration": 600,
                "feedback": [
                    {
                        "type": "contour-6-lines",
                        "dxfId": "dxf_id_P",
                        "dxfPlyId": "dxf_ply_id_P7"
                    },
                    {
                        "type": "text",
                        "text": "HP7",
                        "position": [1, 0, 7],
                    }
                ],
                "feedbackLevel": "info",
                "feedbackType": "phantom-plies"
            }
            eighth_ply = {
                "session": {"mouldId": "mould_id", "plyId": "P8", "moduleId": "em-decision-maker"},
                "expiration": 600,
                "feedback": [
                    {
                        "type": "contour-6-lines",
                        "dxfId": "dxf_id_P",
                        "dxfPlyId": "dxf_ply_id_P8"
                    },
                    {
                        "type": "text",
                        "text": "HP8",
                        "position": [1, 0, 8],
                    }
                ],
                "feedbackLevel": "info",
                "feedbackType": "phantom-plies",
            }
            ninth_ply = {
                "session": {"mouldId": "mould_id", "plyId": "P9", "moduleId": "em-decision-maker"},
                "expiration": 600,
                "feedback": [
                    {
                        "type": "contour-6-lines",
                        "dxfId": "dxf_id_P",
                        "dxfPlyId": "dxf_ply_id_P9"
                    },
                    {
                        "type": "text",
                        "text": "HP9",
                        "position": [1, 0, 9],
                    }
                ],
                "feedbackLevel": "info",
                "feedbackType": "phantom-plies",
            }

        class FirstPalletU:
            first_ply = {
                "session": {"mouldId": "mould_id", "plyId": "U1", "moduleId": "em-decision-maker"},
                "expiration": 600,
                "feedback": [
                    {
                        "type": "contour-6-lines",
                        "dxfId": "dxf_id_U",
                        "dxfPlyId": "dxf_ply_id_U1"
                    },
                    {
                        "type": "text",
                        "text": "HU1",
                        "position": [1, 1, 1],
                    }
                ],
                "feedbackLevel": "info",
                "feedbackType": "phantom-plies"
            }
            second_ply = {
                "session": {"mouldId": "mould_id", "plyId": "U2", "moduleId": "em-decision-maker"},
                "expiration": 600,
                "feedback": [
                    {
                        "type": "contour-6-lines",
                        "dxfId": "dxf_id_U",
                        "dxfPlyId": "dxf_ply_id_U2"
                    },
                    {
                        "type": "text",
                        "text": "HU2",
                        "position": [1, 1, 2],
                    }
                ],
                "feedbackLevel": "info",
                "feedbackType": "phantom-plies",
            }
            third_ply = {
                "session": {"mouldId": "mould_id", "plyId": "U3", "moduleId": "em-decision-maker"},
                "expiration": 600,
                "feedback": [
                    {
                        "type": "contour-6-lines",
                        "dxfId": "dxf_id_U",
                        "dxfPlyId": "dxf_ply_id_U3"
                    },
                    {
                        "type": "text",
                        "text": "HU3",
                        "position": [1, 1, 3],
                    }
                ],
                "feedbackLevel": "info",
                "feedbackType": "phantom-plies",
            }
            fourth_ply = {
                "session": {"mouldId": "mould_id", "plyId": "U4", "moduleId": "em-decision-maker"},
                "expiration": 600,
                "feedback": [
                    {
                        "type": "contour-6-lines",
                        "dxfId": "dxf_id_U",
                        "dxfPlyId": "dxf_ply_id_U4"
                    },
                    {
                        "type": "text",
                        "text": "HU4",
                        "position": [1, 1, 4],
                    }
                ],
                "feedbackLevel": "info",
                "feedbackType": "phantom-plies"
            }
            fifth_ply = {
                "session": {"mouldId": "mould_id", "plyId": "U5", "moduleId": "em-decision-maker"},
                "expiration": 600,
                "feedback": [
                    {
                        "type": "contour-6-lines",
                        "dxfId": "dxf_id_U",
                        "dxfPlyId": "dxf_ply_id_U5"
                    },
                    {
                        "type": "text",
                        "text": "HU5",
                        "position": [1, 1, 5],
                    }
                ],
                "feedbackLevel": "info",
                "feedbackType": "phantom-plies",
            }
            sixth_ply = {
                "session": {"mouldId": "mould_id", "plyId": "U6", "moduleId": "em-decision-maker"},
                "expiration": 600,
                "feedback": [
                    {
                        "type": "contour-6-lines",
                        "dxfId": "dxf_id_U",
                        "dxfPlyId": "dxf_ply_id_U6"
                    },
                    {
                        "type": "text",
                        "text": "HU6",
                        "position": [1, 1, 6],
                    }
                ],
                "feedbackLevel": "info",
                "feedbackType": "phantom-plies",
            }
            seventh_ply = {
                "session": {"mouldId": "mould_id", "plyId": "U7", "moduleId": "em-decision-maker"},
                "expiration": 600,
                "feedback": [
                    {
                        "type": "contour-6-lines",
                        "dxfId": "dxf_id_U",
                        "dxfPlyId": "dxf_ply_id_U7"
                    },
                    {
                        "type": "text",
                        "text": "HU7",
                        "position": [1, 1, 7],
                    }
                ],
                "feedbackLevel": "info",
                "feedbackType": "phantom-plies"
            }

    class CorrectlyPlacedPlies:
        class FirstPalletP:
            first_ply = {
                "session": {"mouldId": "mould_id", "plyId": "P1", "moduleId": "em-decision-maker"},
                "expiration": 20,
                "feedback": [
                    {
                        "type": "contour-4-lines",
                        "dxfId": "dxf_id_P",
                        "dxfPlyId": "dxf_ply_id_P1"
                    },
                    {
                        "type": "text",
                        "text": "T",
                        "position": [1, 0, 1],
                    }

                ],
                "feedbackLevel": "info",
                "feedbackType": "correctly-placed-plies",
            }
            second_ply = {
                "session": {"mouldId": "mould_id", "plyId": "P2", "moduleId": "em-decision-maker"},
                "expiration": 20,
                "feedback": [
                    {
                        "type": "contour-4-lines",
                        "dxfId": "dxf_id_P",
                        "dxfPlyId": "dxf_ply_id_P2"
                    },
                    {
                        "type": "text",
                        "text": "T",
                        "position": [1, 0, 2],
                    }
                ],
                "feedbackLevel": "info",
                "feedbackType": "correctly-placed-plies",
            }
            third_ply = {
                "session": {"mouldId": "mould_id", "plyId": "P3", "moduleId": "em-decision-maker"},
                "expiration": 20,
                "feedback": [
                    {
                        "type": "contour-4-lines",
                        "dxfId": "dxf_id_P",
                        "dxfPlyId": "dxf_ply_id_P3"
                    },
                    {
                        "type": "text",
                        "text": "T",
                        "position": [1, 0, 3],
                    }
                ],
                "feedbackLevel": "info",
                "feedbackType": "correctly-placed-plies",
            }

        class SecondPalletP:
            fourth_ply = {
                "session": {"mouldId": "mould_id", "plyId": "P4", "moduleId": "em-decision-maker"},
                "expiration": 20,
                "feedback": [
                    {
                        "type": "contour-4-lines",
                        "dxfId": "dxf_id_P",
                        "dxfPlyId": "dxf_ply_id_P4"
                    },
                    {
                        "type": "text",
                        "text": "T",
                        "position": [1, 0, 4],
                    }

                ],
                "feedbackLevel": "info",
                "feedbackType": "correctly-placed-plies",
            }
            fifth_ply = {
                "session": {"mouldId": "mould_id", "plyId": "P5", "moduleId": "em-decision-maker"},
                "expiration": 20,
                "feedback": [
                    {
                        "type": "contour-4-lines",
                        "dxfId": "dxf_id_P",
                        "dxfPlyId": "dxf_ply_id_P5"
                    },
                    {
                        "type": "text",
                        "text": "T",
                        "position": [1, 0, 5],
                    }
                ],
                "feedbackLevel": "info",
                "feedbackType": "correctly-placed-plies",
            }
            sixth_ply = {
                "session": {"mouldId": "mould_id", "plyId": "P6", "moduleId": "em-decision-maker"},
                "expiration": 20,
                "feedback": [
                    {
                        "type": "contour-4-lines",
                        "dxfId": "dxf_id_P",
                        "dxfPlyId": "dxf_ply_id_P6"
                    },
                    {
                        "type": "text",
                        "text": "T",
                        "position": [1, 0, 6],
                    }
                ],
                "feedbackLevel": "info",
                "feedbackType": "correctly-placed-plies",
            }

        class ThirdPalletP:
            seventh_ply = {
                "session": {"mouldId": "mould_id", "plyId": "P7", "moduleId": "em-decision-maker"},
                "expiration": 20,
                "feedback": [
                    {
                        "type": "contour-4-lines",
                        "dxfId": "dxf_id_P",
                        "dxfPlyId": "dxf_ply_id_P7"
                    },
                    {
                        "type": "text",
                        "text": "T",
                        "position": [1, 0, 7],
                    }

                ],
                "feedbackLevel": "info",
                "feedbackType": "correctly-placed-plies",
            }
            eighth_ply = {
                "session": {"mouldId": "mould_id", "plyId": "P8", "moduleId": "em-decision-maker"},
                "expiration": 20,
                "feedback": [
                    {
                        "type": "contour-4-lines",
                        "dxfId": "dxf_id_P",
                        "dxfPlyId": "dxf_ply_id_P8"
                    },
                    {
                        "type": "text",
                        "text": "T",
                        "position": [1, 0, 8],
                    }
                ],
                "feedbackLevel": "info",
                "feedbackType": "correctly-placed-plies",
            }
            ninth_ply = {
                "session": {"mouldId": "mould_id", "plyId": "P9", "moduleId": "em-decision-maker"},
                "expiration": 20,
                "feedback": [
                    {
                        "type": "contour-4-lines",
                        "dxfId": "dxf_id_P",
                        "dxfPlyId": "dxf_ply_id_P9"
                    },
                    {
                        "type": "text",
                        "text": "T",
                        "position": [1, 0, 9],
                    }
                ],
                "feedbackLevel": "info",
                "feedbackType": "correctly-placed-plies",
            }

        class FirstPalletU:
            first_ply = {
                "session": {"mouldId": "mould_id", "plyId": "U1", "moduleId": "em-decision-maker"},
                "expiration": 20,
                "feedback": [
                    {
                        "type": "contour-4-lines",
                        "dxfId": "dxf_id_U",
                        "dxfPlyId": "dxf_ply_id_U1"
                    },
                    {
                        "type": "text",
                        "text": "T",
                        "position": [1, 1, 1],
                    }

                ],
                "feedbackLevel": "info",
                "feedbackType": "correctly-placed-plies",
            }
            second_ply = {
                "session": {"mouldId": "mould_id", "plyId": "U2", "moduleId": "em-decision-maker"},
                "expiration": 20,
                "feedback": [
                    {
                        "type": "contour-4-lines",
                        "dxfId": "dxf_id_U",
                        "dxfPlyId": "dxf_ply_id_U2"
                    },
                    {
                        "type": "text",
                        "text": "T",
                        "position": [1, 1, 2],
                    }
                ],
                "feedbackLevel": "info",
                "feedbackType": "correctly-placed-plies",
            }
            third_ply = {
                "session": {"mouldId": "mould_id", "plyId": "U3", "moduleId": "em-decision-maker"},
                "expiration": 20,
                "feedback": [
                    {
                        "type": "contour-4-lines",
                        "dxfId": "dxf_id_U",
                        "dxfPlyId": "dxf_ply_id_U3"
                    },
                    {
                        "type": "text",
                        "text": "T",
                        "position": [1, 1, 3],
                    }
                ],
                "feedbackLevel": "info",
                "feedbackType": "correctly-placed-plies",
            }
            fourth_ply = {
                "session": {"mouldId": "mould_id", "plyId": "U4", "moduleId": "em-decision-maker"},
                "expiration": 20,
                "feedback": [
                    {
                        "type": "contour-4-lines",
                        "dxfId": "dxf_id_U",
                        "dxfPlyId": "dxf_ply_id_U4"
                    },
                    {
                        "type": "text",
                        "text": "T",
                        "position": [1, 1, 4],
                    }

                ],
                "feedbackLevel": "info",
                "feedbackType": "correctly-placed-plies",
            }
            fifth_ply = {
                "session": {"mouldId": "mould_id", "plyId": "U5", "moduleId": "em-decision-maker"},
                "expiration": 20,
                "feedback": [
                    {
                        "type": "contour-4-lines",
                        "dxfId": "dxf_id_U",
                        "dxfPlyId": "dxf_ply_id_U5"
                    },
                    {
                        "type": "text",
                        "text": "T",
                        "position": [1, 1, 5],
                    }
                ],
                "feedbackLevel": "info",
                "feedbackType": "correctly-placed-plies",
            }
            sixth_ply = {
                "session": {"mouldId": "mould_id", "plyId": "U6", "moduleId": "em-decision-maker"},
                "expiration": 20,
                "feedback": [
                    {
                        "type": "contour-4-lines",
                        "dxfId": "dxf_id_U",
                        "dxfPlyId": "dxf_ply_id_U6"
                    },
                    {
                        "type": "text",
                        "text": "T",
                        "position": [1, 1, 6],
                    }
                ],
                "feedbackLevel": "info",
                "feedbackType": "correctly-placed-plies",
            }
            seventh_ply = {
                "session": {"mouldId": "mould_id", "plyId": "U7", "moduleId": "em-decision-maker"},
                "expiration": 20,
                "feedback": [
                    {
                        "type": "contour-4-lines",
                        "dxfId": "dxf_id_U",
                        "dxfPlyId": "dxf_ply_id_U7"
                    },
                    {
                        "type": "text",
                        "text": "T",
                        "position": [1, 1, 7],
                    }

                ],
                "feedbackLevel": "info",
                "feedbackType": "correctly-placed-plies",
            }

    class LastPliesPlaced:
        class FirstPalletP:
            third_ply = {
                "session": {"mouldId": "mould_id", "plyId": "P3", "moduleId": "em-decision-maker"},
                "expiration": 600,
                "feedback": [
                    {"dxfId": "dxf_id_P", "dxfPlyId": "dxf_ply_id_P3", "type": "contour-4-lines"},
                    {
                        "type": "text",
                        "text": "SP3",
                        "position": [1, 0, 3],
                    }
                ],
                "feedbackLevel": "info",
                "feedbackType": "last-plies-placed",
            }

        class SecondPalletP:
            sixth_ply = {
                "session": {"mouldId": "mould_id", "plyId": "P6", "moduleId": "em-decision-maker"},
                "expiration": 600,
                "feedback": [
                    {"dxfId": "dxf_id_P", "dxfPlyId": "dxf_ply_id_P6", "type": "contour-4-lines"},
                    {
                        "type": "text",
                        "text": "SP6",
                        "position": [1, 0, 6],
                    }
                ],
                "feedbackLevel": "info",
                "feedbackType": "last-plies-placed",
            }

        class ThirdPalletP:
            ninth_ply = {
                "session": {"mouldId": "mould_id", "plyId": "P9", "moduleId": "em-decision-maker"},
                "expiration": 600,
                "feedback": [
                    {"dxfId": "dxf_id_P", "dxfPlyId": "dxf_ply_id_P9", "type": "contour-4-lines"},
                    {
                        "type": "text",
                        "text": "SP9",
                        "position": [1, 0, 9],
                    }
                ],
                "feedbackLevel": "info",
                "feedbackType": "last-plies-placed",
            }

        class FirstPalletU:
            seventh_ply = {
                "session": {"mouldId": "mould_id", "plyId": "U7", "moduleId": "em-decision-maker"},
                "expiration": 600,
                "feedback": [
                    {"dxfId": "dxf_id_U", "dxfPlyId": "dxf_ply_id_U7", "type": "contour-4-lines"},
                    {
                        "type": "text",
                        "text": "SU7",
                        "position": [1, 1, 7],
                    }
                ],
                "feedbackLevel": "info",
                "feedbackType": "last-plies-placed",
            }

    class MissingPlies:
        class FirstPalletP:
            first_ply = {
                "session": {"mouldId": "mould_id", "plyId": "P1", "moduleId": "em-decision-maker"},
                "expiration": 600,
                "feedback": [
                    {"dxfId": "dxf_id_P", "dxfPlyId": "dxf_ply_id_P1", "type": "contour-4-lines"},
                    {"type": "text", "text": "XP1", "position": [1, 0, 1]}
                ],
                "feedbackLevel": "error",
                "feedbackType": "missing-plies"
            }
            second_ply = {
                "session": {"mouldId": "mould_id", "plyId": "P2", "moduleId": "em-decision-maker"},
                "expiration": 600,
                "feedback": [
                    {"dxfId": "dxf_id_P", "dxfPlyId": "dxf_ply_id_P2", "type": "contour-4-lines"},
                    {"type": "text", "text": "XP2", "position": [1, 0, 2]}
                ],
                "feedbackLevel": "error",
                "feedbackType": "missing-plies",
            }
            third_ply = {
                "session": {"mouldId": "mould_id", "plyId": "P3", "moduleId": "em-decision-maker"},
                "expiration": 600,
                "feedback": [
                    {"dxfId": "dxf_id_P", "dxfPlyId": "dxf_ply_id_P3", "type": "contour-4-lines"},
                    {"type": "text", "text": "XP3", "position": [1, 0, 3]}
                ],
                "feedbackLevel": "error",
                "feedbackType": "missing-plies",
            }

        class SecondPalletP:
            fourth_ply = {
                "session": {"mouldId": "mould_id", "plyId": "P4", "moduleId": "em-decision-maker"},
                "expiration": 600,
                "feedback": [
                    {"dxfId": "dxf_id_P", "dxfPlyId": "dxf_ply_id_P4", "type": "contour-4-lines"},
                    {"type": "text", "text": "XP4", "position": [1, 0, 4]}
                ],
                "feedbackLevel": "error",
                "feedbackType": "missing-plies"
            }
            fifth_ply = {
                "session": {"mouldId": "mould_id", "plyId": "P5", "moduleId": "em-decision-maker"},
                "expiration": 600,
                "feedback": [
                    {"dxfId": "dxf_id_P", "dxfPlyId": "dxf_ply_id_P5", "type": "contour-4-lines"},
                    {"type": "text", "text": "XP5", "position": [1, 0, 5]}
                ],
                "feedbackLevel": "error",
                "feedbackType": "missing-plies",
            }
            sixth_ply = {
                "session": {"mouldId": "mould_id", "plyId": "P6", "moduleId": "em-decision-maker"},
                "expiration": 600,
                "feedback": [
                    {"dxfId": "dxf_id_P", "dxfPlyId": "dxf_ply_id_P6", "type": "contour-4-lines"},
                    {"type": "text", "text": "XP6", "position": [1, 0, 6]}
                ],
                "feedbackLevel": "error",
                "feedbackType": "missing-plies",
            }

        class ThirdPalletP:
            seventh_ply = {
                "session": {"mouldId": "mould_id", "plyId": "P7", "moduleId": "em-decision-maker"},
                "expiration": 600,
                "feedback": [
                    {"dxfId": "dxf_id_P", "dxfPlyId": "dxf_ply_id_P7", "type": "contour-4-lines"},
                    {"type": "text", "text": "XP7", "position": [1, 0, 7]}
                ],
                "feedbackLevel": "error",
                "feedbackType": "missing-plies"
            }
            eighth_ply = {
                "session": {"mouldId": "mould_id", "plyId": "P8", "moduleId": "em-decision-maker"},
                "expiration": 600,
                "feedback": [
                    {"dxfId": "dxf_id_P", "dxfPlyId": "dxf_ply_id_P8", "type": "contour-4-lines"},
                    {"type": "text", "text": "XP8", "position": [1, 0, 8]}
                ],
                "feedbackLevel": "error",
                "feedbackType": "missing-plies",
            }
            ninth_ply = {
                "session": {"mouldId": "mould_id", "plyId": "P9", "moduleId": "em-decision-maker"},
                "expiration": 600,
                "feedback": [
                    {"dxfId": "dxf_id_P", "dxfPlyId": "dxf_ply_id_P9", "type": "contour-4-lines"},
                    {"type": "text", "text": "XP9", "position": [1, 0, 9]}
                ],
                "feedbackLevel": "error",
                "feedbackType": "missing-plies",
            }

        class FirstPalletU:
            first_ply = {
                "session": {"mouldId": "mould_id", "plyId": "U1", "moduleId": "em-decision-maker"},
                "expiration": 600,
                "feedback": [
                    {"dxfId": "dxf_id_U", "dxfPlyId": "dxf_ply_id_U1", "type": "contour-4-lines"},
                    {"type": "text", "text": "XU1", "position": [1, 1, 1]}
                ],
                "feedbackLevel": "error",
                "feedbackType": "missing-plies"
            }
            second_ply = {
                "session": {"mouldId": "mould_id", "plyId": "U2", "moduleId": "em-decision-maker"},
                "expiration": 600,
                "feedback": [
                    {"dxfId": "dxf_id_U", "dxfPlyId": "dxf_ply_id_U2", "type": "contour-4-lines"},
                    {"type": "text", "text": "XU2", "position": [1, 1, 2]}
                ],
                "feedbackLevel": "error",
                "feedbackType": "missing-plies",
            }
            third_ply = {
                "session": {"mouldId": "mould_id", "plyId": "U3", "moduleId": "em-decision-maker"},
                "expiration": 600,
                "feedback": [
                    {"dxfId": "dxf_id_U", "dxfPlyId": "dxf_ply_id_U3", "type": "contour-4-lines"},
                    {"type": "text", "text": "XU3", "position": [1, 1, 3]}
                ],
                "feedbackLevel": "error",
                "feedbackType": "missing-plies",
            }
            fourth_ply = {
                "session": {"mouldId": "mould_id", "plyId": "U4", "moduleId": "em-decision-maker"},
                "expiration": 600,
                "feedback": [
                    {"dxfId": "dxf_id_U", "dxfPlyId": "dxf_ply_id_U4", "type": "contour-4-lines"},
                    {"type": "text", "text": "XU4", "position": [1, 1, 4]}
                ],
                "feedbackLevel": "error",
                "feedbackType": "missing-plies"
            }
            fifth_ply = {
                "session": {"mouldId": "mould_id", "plyId": "U5", "moduleId": "em-decision-maker"},
                "expiration": 600,
                "feedback": [
                    {"dxfId": "dxf_id_U", "dxfPlyId": "dxf_ply_id_U5", "type": "contour-4-lines"},
                    {"type": "text", "text": "XU5", "position": [1, 1, 5]}
                ],
                "feedbackLevel": "error",
                "feedbackType": "missing-plies",
            }
            sixth_ply = {
                "session": {"mouldId": "mould_id", "plyId": "U6", "moduleId": "em-decision-maker"},
                "expiration": 600,
                "feedback": [
                    {"dxfId": "dxf_id_U", "dxfPlyId": "dxf_ply_id_U6", "type": "contour-4-lines"},
                    {"type": "text", "text": "XU6", "position": [1, 1, 6]}
                ],
                "feedbackLevel": "error",
                "feedbackType": "missing-plies",
            }
            seventh_ply = {
                "session": {"mouldId": "mould_id", "plyId": "U7", "moduleId": "em-decision-maker"},
                "expiration": 600,
                "feedback": [
                    {"dxfId": "dxf_id_U", "dxfPlyId": "dxf_ply_id_U7", "type": "contour-4-lines"},
                    {"type": "text", "text": "XU7", "position": [1, 1, 7]}
                ],
                "feedbackLevel": "error",
                "feedbackType": "missing-plies"
            }

    class PliesToNull:
        class FirstPalletP:
            first_ply = {
                "session": {"mouldId": "mould_id", "plyId": "P1", "moduleId": "em-decision-maker"},
                "expiration": 0,
                "feedback": [],
                "feedbackLevel": "info",
                "feedbackType": "plies-to-null",
            }
            second_ply = {
                "session": {"mouldId": "mould_id", "plyId": "P2", "moduleId": "em-decision-maker"},
                "expiration": 0,
                "feedback": [],
                "feedbackLevel": "info",
                "feedbackType": "plies-to-null",
            }
            third_ply = {
                "session": {"mouldId": "mould_id", "plyId": "P3", "moduleId": "em-decision-maker"},
                "expiration": 0,
                "feedback": [],
                "feedbackLevel": "info",
                "feedbackType": "plies-to-null",
            }

        class SecondPalletP:
            fourth_ply = {
                "session": {"mouldId": "mould_id", "plyId": "P4", "moduleId": "em-decision-maker"},
                "expiration": 0,
                "feedback": [],
                "feedbackLevel": "info",
                "feedbackType": "plies-to-null",
            }
            fifth_ply = {
                "session": {"mouldId": "mould_id", "plyId": "P5", "moduleId": "em-decision-maker"},
                "expiration": 0,
                "feedback": [],
                "feedbackLevel": "info",
                "feedbackType": "plies-to-null",
            }
            sixth_ply = {
                "session": {"mouldId": "mould_id", "plyId": "P6", "moduleId": "em-decision-maker"},
                "expiration": 0,
                "feedback": [],
                "feedbackLevel": "info",
                "feedbackType": "plies-to-null",
            }

        class ThirdPalletP:
            seventh_ply = {
                "session": {"mouldId": "mould_id", "plyId": "P7", "moduleId": "em-decision-maker"},
                "expiration": 0,
                "feedback": [],
                "feedbackLevel": "info",
                "feedbackType": "plies-to-null",
            }
            eighth_ply = {
                "session": {"mouldId": "mould_id", "plyId": "P8", "moduleId": "em-decision-maker"},
                "expiration": 0,
                "feedback": [],
                "feedbackLevel": "info",
                "feedbackType": "plies-to-null",
            }
            ninth_ply = {
                "session": {"mouldId": "mould_id", "plyId": "P9", "moduleId": "em-decision-maker"},
                "expiration": 0,
                "feedback": [],
                "feedbackLevel": "info",
                "feedbackType": "plies-to-null",
            }

        class FirstPalletU:
            first_ply = {
                "session": {"mouldId": "mould_id", "plyId": "U1", "moduleId": "em-decision-maker"},
                "expiration": 0,
                "feedback": [],
                "feedbackLevel": "info",
                "feedbackType": "plies-to-null",
            }
            second_ply = {
                "session": {"mouldId": "mould_id", "plyId": "U2", "moduleId": "em-decision-maker"},
                "expiration": 0,
                "feedback": [],
                "feedbackLevel": "info",
                "feedbackType": "plies-to-null",
            }
            third_ply = {
                "session": {"mouldId": "mould_id", "plyId": "U3", "moduleId": "em-decision-maker"},
                "expiration": 0,
                "feedback": [],
                "feedbackLevel": "info",
                "feedbackType": "plies-to-null",
            }
            fourth_ply = {
                "session": {"mouldId": "mould_id", "plyId": "U4", "moduleId": "em-decision-maker"},
                "expiration": 0,
                "feedback": [],
                "feedbackLevel": "info",
                "feedbackType": "plies-to-null",
            }
            fifth_ply = {
                "session": {"mouldId": "mould_id", "plyId": "U5", "moduleId": "em-decision-maker"},
                "expiration": 0,
                "feedback": [],
                "feedbackLevel": "info",
                "feedbackType": "plies-to-null",
            }
            sixth_ply = {
                "session": {"mouldId": "mould_id", "plyId": "U6", "moduleId": "em-decision-maker"},
                "expiration": 0,
                "feedback": [],
                "feedbackLevel": "info",
                "feedbackType": "plies-to-null",
            }
            seventh_ply = {
                "session": {"mouldId": "mould_id", "plyId": "U7", "moduleId": "em-decision-maker"},
                "expiration": 0,
                "feedback": [],
                "feedbackLevel": "info",
                "feedbackType": "plies-to-null",
            }

    class PalletsLastPliesPlaced:
        class FirstPalletP:
            third_ply = {
                "session": {"mouldId": "mould_id", "plyId": "P3", "moduleId": "em-decision-maker"},
                "expiration": 20,
                "feedback": [
                    {"dxfId": "dxf_id_P", "dxfPlyId": "dxf_ply_id_P3", "type": "contour-4-lines"},
                    {
                        "type": "text",
                        "text": "SP3",
                        "position": [1, 0, 3],
                    }
                ],
                "feedbackLevel": "info",
                "feedbackType": "pallets-last-plies-placed",
            }

        class SecondPalletP:
            sixth_ply = {
                "session": {"mouldId": "mould_id", "plyId": "P6", "moduleId": "em-decision-maker"},
                "expiration": 20,
                "feedback": [
                    {"dxfId": "dxf_id_P", "dxfPlyId": "dxf_ply_id_P6", "type": "contour-4-lines"},
                    {
                        "type": "text",
                        "text": "SP6",
                        "position": [1, 0, 6],
                    }
                ],
                "feedbackLevel": "info",
                "feedbackType": "pallets-last-plies-placed",
            }

        class ThirdPalletP:
            ninth_ply = {
                "session": {"mouldId": "mould_id", "plyId": "P9", "moduleId": "em-decision-maker"},
                "expiration": 20,
                "feedback": [
                    {"dxfId": "dxf_id_P", "dxfPlyId": "dxf_ply_id_P9", "type": "contour-4-lines"},
                    {
                        "type": "text",
                        "text": "SP9",
                        "position": [1, 0, 9],
                    }
                ],
                "feedbackLevel": "info",
                "feedbackType": "pallets-last-plies-placed",
            }

        class FirstPalletU:
            seventh_ply = {
                "session": {"mouldId": "mould_id", "plyId": "U7", "moduleId": "em-decision-maker"},
                "expiration": 20,
                "feedback": [
                    {"dxfId": "dxf_id_U", "dxfPlyId": "dxf_ply_id_U7", "type": "contour-4-lines"},
                    {
                        "type": "text",
                        "text": "SU7",
                        "position": [1, 1, 7],
                    }
                ],
                "feedbackLevel": "info",
                "feedbackType": "pallets-last-plies-placed",
            }
