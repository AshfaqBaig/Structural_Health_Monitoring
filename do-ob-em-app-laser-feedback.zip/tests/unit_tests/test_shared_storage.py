# pylint: disable=missing-class-docstring, missing-function-docstring

import logging
from unittest import mock
from unittest.mock import MagicMock
import pytest
from etcd3 import Etcd3Exception
from app.shared_storage import SharedStorage

@pytest.fixture(name="shared_storage")
def fixture_payload(mocker):
    mocker.patch("app.shared_storage.etcd3")
    return SharedStorage("localhost:2379")

def test_watch_key(shared_storage, mocker, caplog):
    # GIVEN
    key = "/moulds/mould_id"

    # WHEN
    with caplog.at_level(logging.INFO):
        handler = mocker.stub(name="handle_global_mould_state_update_stub")
        etcd_var = mocker.patch.object(shared_storage.etcd_client, "add_watch_callback", new_callable=None)
        shared_storage.watch_key(key, handler)

        # VERIFY
        assert etcd_var.call_count == 1
        etcd_var.assert_called_with(key, callback=handler)
        assert "Adding watch by given key_prefix" in caplog.text

def test_put_key(shared_storage, mocker, caplog):
    # GIVEN
    key = "/moulds/mould_id"
    value = ["invalid_data_type"]
    mock_put_key = mocker.patch.object(shared_storage.etcd_client, "put")

    # WHEN
    with caplog.at_level(logging.DEBUG, logger="laser-feedback"):
        shared_storage.put_key(key, value)
        assert "Putting into etcd store key" in caplog.text

    # VERIFY
    assert mock_put_key.call_count == 1
    mock_put_key.assert_called_with(key, mock.ANY)

def test_fail_etcd(mocker, caplog):
    # GIVEN
    mock_sys_exit = mocker.patch("sys.exit")

    etcd3_module = mocker.patch("app.shared_storage.etcd3")
    etcd_client = MagicMock()
    mocker.patch.object(etcd3_module, "client", return_value=etcd_client)

    # AND patched module etcd3 client connect attribute
    mocker.patch.object(etcd_client, "get", side_effect=Etcd3Exception())

    # WHEN SharedStorage is called and is unable to connect - terminate application
    SharedStorage("localhost:2379")

    # THEN error is logged
    assert "Unexpected ETCD storage error" in caplog.text

    # THEN an exception of correct type is raised
    assert mock_sys_exit.call_count == 1

def test_fail_connection(mocker, caplog):
    # GIVEN
    mock_sys_exit = mocker.patch("sys.exit")

    etcd3_module = mocker.patch("app.shared_storage.etcd3")
    etcd_client = MagicMock()
    mocker.patch.object(etcd3_module, "client", return_value=etcd_client)

    # AND patched module etcd3 client connect attribute
    mocker.patch.object(etcd_client, "get", side_effect=ConnectionError())

    # WHEN SharedStorage is called and is unable to connect - terminate application
    SharedStorage("localhost:2379")

    # THEN error is logged
    assert "No ETCD connection available" in caplog.text

    # THEN an exception of correct type is raised
    assert mock_sys_exit.call_count == 1
