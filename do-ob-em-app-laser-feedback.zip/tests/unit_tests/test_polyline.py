# pylint: disable=protected-access, missing-module-docstring, missing-class-docstring, missing-function-docstring

import unittest

import pytest

from app.shapes.circle import Circle
from app.shapes.polyline import Polyline
from app.shapes.polyline_numeric import PolylineNumeric
from app.shapes.polyline_symbol import PolylineSymbol
from app.shapes.polyline_text import PolylineText
from app.processors.shape_feedback import DEFAULT_DXF_VERSION, DEFAULT_COLOR

# pylint: disable=protected-access

class ShapesTest(unittest.TestCase):
    def test_shape_generate(self):
        dxf = Circle(DEFAULT_DXF_VERSION, 2, (1, 1, 1), DEFAULT_COLOR).generate()
        self.assertIsNotNone(dxf)
        self.assertEqual(type(dxf), str)

    def test_build_circle(self):
        circle = Circle(DEFAULT_DXF_VERSION, 2, (1, 1, 1), DEFAULT_COLOR)._build_doc()
        self.assertIsNotNone(circle)
        self.assertEqual(len(circle.modelspace().query('CIRCLE')), 1)
        self.assertIsNotNone(circle.modelspace().query('CIRCLE')[0])

    def test_build_polyline(self):
        polyline = Polyline(
            DEFAULT_DXF_VERSION, [(0, 0, 10),
                                  (10, 0, 10),
                                  (10, 10, 4),
                                  (0, 10, 4)],
            DEFAULT_COLOR)._build_doc()
        self.assertIsNotNone(polyline)
        self.assertEqual(len(polyline.modelspace().query('POLYLINE')), 1)
        self.assertIsNotNone(polyline.modelspace().query('POLYLINE')[0])

    def test_build_polyline_digit_2(self):
        # digit 2， zoom_rate 1
        polyline_digit = PolylineNumeric(
            DEFAULT_DXF_VERSION, "2", 1, (1, 1, 1), DEFAULT_COLOR)
        _ = polyline_digit.generate()
        coord_xy = polyline_digit.numeric_coordinates()
        assert coord_xy[0][0] == -2
        assert coord_xy[0][-1] == 2
        assert coord_xy[2][0] == 2
        assert coord_xy[2][-1] == -3
        self.assertIsNotNone(polyline_digit)

    def test_build_polyline_digit_3(self):
        # digit 3， zoom_rate 2
        polyline_digit = PolylineNumeric(
            DEFAULT_DXF_VERSION, "3", 2, (1, 1, 1), DEFAULT_COLOR)
        _ = polyline_digit.generate()
        coord_xy = polyline_digit.numeric_coordinates()
        assert coord_xy[0][0] == -4
        assert coord_xy[0][2] == 2
        assert coord_xy[0][-1] == -4
        assert coord_xy[2][0] == 4
        assert coord_xy[2][2] == 6
        assert coord_xy[2][-1] == -4
        self.assertIsNotNone(polyline_digit)

    def test_build_polyline_digit_8(self):
        # digit 8， zoom_rate 10
        polyline_digit = PolylineNumeric(
            DEFAULT_DXF_VERSION, "8", 10, (1, 1, 1), DEFAULT_COLOR)
        _ = polyline_digit.generate()
        coord_xy = polyline_digit.numeric_coordinates()
        assert coord_xy[0][0] == -10
        assert coord_xy[0][3] == -10
        assert coord_xy[0][-1] == 10
        assert coord_xy[2][0] == 0
        assert coord_xy[2][3] == 30
        assert coord_xy[2][-1] == 0
        self.assertIsNotNone(polyline_digit)

    def test_build_polyline_symbol_X(self):
        # letter X， zoom_rate 2
        polyline_digit = PolylineSymbol(
            DEFAULT_DXF_VERSION, "X", 2, (1, 2, 0), DEFAULT_COLOR)
        _ = polyline_digit.generate()
        coord_xy = polyline_digit.symbol_coordinates()
        assert coord_xy[0][0] == -4
        assert coord_xy[0][3] == -4
        assert coord_xy[0][-1] == 4
        assert coord_xy[2][0] == 6
        assert coord_xy[2][3] == -6
        assert coord_xy[2][-1] == 6
        self.assertIsNotNone(polyline_digit)

    def test_build_polyline_symbol_H(self):
        # letter H， zoom_rate 2
        polyline_digit = PolylineSymbol(
            DEFAULT_DXF_VERSION, "H", 2, (1, 2, 0), DEFAULT_COLOR)
        _ = polyline_digit.generate()
        coord_xy = polyline_digit.symbol_coordinates()
        assert coord_xy[0][0] == -6
        assert coord_xy[0][3] == 6
        assert coord_xy[0][-1] == -6
        assert coord_xy[2][0] == 6
        assert coord_xy[2][3] == -6
        assert coord_xy[2][-1] == 6
        self.assertIsNotNone(polyline_digit)

    def test_build_polyline_text(self):
        # text X123， zoom_rate 2
        polyline_text = PolylineText(
            DEFAULT_DXF_VERSION, "X123", 2, (0, 0, 0), DEFAULT_COLOR)
        _ = polyline_text.generate()
        coord_xy = polyline_text.text_coordinates()
        centroid_shifts = polyline_text._get_centroid_shifts()
        assert len(centroid_shifts) == 4
        assert centroid_shifts[0] == pytest.approx(15.)
        assert coord_xy[0][0][0] == -46
        assert coord_xy[0][0][3] == -34
        assert coord_xy[0][2][0] == 29
        assert coord_xy[0][2][-1] == 21

        assert coord_xy[1][0][0] == -44
        assert coord_xy[1][0][3] == -34
        assert coord_xy[1][2][0] == 7
        assert coord_xy[1][2][-1] == 1

        assert coord_xy[2][0][0] == -44
        assert coord_xy[2][0][3] == -44
        assert coord_xy[2][2][0] == -1
        assert coord_xy[2][2][-1] == -9

        assert coord_xy[3][0][0] == -44
        assert coord_xy[3][0][3] == -44
        assert coord_xy[3][2][0] == -11
        assert coord_xy[3][2][-1] == -11

        self.assertIsNotNone(polyline_text)
