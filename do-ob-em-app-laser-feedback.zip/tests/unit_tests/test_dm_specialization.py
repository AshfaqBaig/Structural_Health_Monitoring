# pylint: disable=protected-access, missing-class-docstring, missing-function-docstring

from unittest.mock import patch
from mock_data import feedback_positions_data, ExpectedFullFeedback, dm_message_missing_plies, \
    dm_message_plies_to_be_placed, dm_message_correctly_placed_plies, \
    dm_message_plies_to_null, dm_message_phantom_plies, dm_message_last_plies_placed, \
    dm_message_pallets_last_plies_placed
from app.feedback.feedback_positions import FeedbackPositions
from app.processors.dm_specialization import dm_message_preprocessing

from app.logging.logger import yield_logger

log = yield_logger()


@patch("app.config.MOULD_ID", "mould_id")
class HandleMissingPliesTests:
    def test_correctly_process_p1(self):
        feedback_positions = FeedbackPositions(feedback_positions_data)
        assert dm_message_preprocessing(
            dm_message_missing_plies['P1'],
            feedback_positions) == ExpectedFullFeedback.MissingPlies.FirstPalletP.first_ply

    def test_correctly_process_p2(self):
        feedback_positions = FeedbackPositions(feedback_positions_data)
        assert dm_message_preprocessing(
            dm_message_missing_plies['P2'],
            feedback_positions) == ExpectedFullFeedback.MissingPlies.FirstPalletP.second_ply

    def test_correctly_process_p3(self):
        feedback_positions = FeedbackPositions(feedback_positions_data)
        assert dm_message_preprocessing(
            dm_message_missing_plies['P3'],
            feedback_positions) == ExpectedFullFeedback.MissingPlies.FirstPalletP.third_ply

    def test_correctly_process_p4(self):
        feedback_positions = FeedbackPositions(feedback_positions_data)
        assert dm_message_preprocessing(
            dm_message_missing_plies['P4'],
            feedback_positions) == ExpectedFullFeedback.MissingPlies.SecondPalletP.fourth_ply

    def test_correctly_process_p5(self):
        feedback_positions = FeedbackPositions(feedback_positions_data)
        assert dm_message_preprocessing(
            dm_message_missing_plies['P5'],
            feedback_positions) == ExpectedFullFeedback.MissingPlies.SecondPalletP.fifth_ply

    def test_correctly_process_p6(self):
        feedback_positions = FeedbackPositions(feedback_positions_data)
        assert dm_message_preprocessing(
            dm_message_missing_plies['P6'],
            feedback_positions) == ExpectedFullFeedback.MissingPlies.SecondPalletP.sixth_ply

    def test_correctly_process_p7(self):
        feedback_positions = FeedbackPositions(feedback_positions_data)
        assert dm_message_preprocessing(
            dm_message_missing_plies['P7'],
            feedback_positions) == ExpectedFullFeedback.MissingPlies.ThirdPalletP.seventh_ply

    def test_correctly_process_p8(self):
        feedback_positions = FeedbackPositions(feedback_positions_data)
        assert dm_message_preprocessing(
            dm_message_missing_plies['P8'],
            feedback_positions) == ExpectedFullFeedback.MissingPlies.ThirdPalletP.eighth_ply

    def test_correctly_process_p9(self):
        feedback_positions = FeedbackPositions(feedback_positions_data)
        assert dm_message_preprocessing(
            dm_message_missing_plies['P9'],
            feedback_positions) == ExpectedFullFeedback.MissingPlies.ThirdPalletP.ninth_ply

    def test_correctly_process_u1(self):
        feedback_positions = FeedbackPositions(feedback_positions_data)
        assert dm_message_preprocessing(
            dm_message_missing_plies['U1'],
            feedback_positions) == ExpectedFullFeedback.MissingPlies.FirstPalletU.first_ply

    def test_correctly_process_u2(self):
        feedback_positions = FeedbackPositions(feedback_positions_data)
        assert dm_message_preprocessing(
            dm_message_missing_plies['U2'],
            feedback_positions) == ExpectedFullFeedback.MissingPlies.FirstPalletU.second_ply

    def test_correctly_process_u3(self):
        feedback_positions = FeedbackPositions(feedback_positions_data)
        assert dm_message_preprocessing(
            dm_message_missing_plies['U3'],
            feedback_positions) == ExpectedFullFeedback.MissingPlies.FirstPalletU.third_ply

    def test_correctly_process_u4(self):
        feedback_positions = FeedbackPositions(feedback_positions_data)
        assert dm_message_preprocessing(
            dm_message_missing_plies['U4'],
            feedback_positions) == ExpectedFullFeedback.MissingPlies.FirstPalletU.fourth_ply

    def test_correctly_process_u5(self):
        feedback_positions = FeedbackPositions(feedback_positions_data)
        assert dm_message_preprocessing(
            dm_message_missing_plies['U5'],
            feedback_positions) == ExpectedFullFeedback.MissingPlies.FirstPalletU.fifth_ply

    def test_correctly_process_u6(self):
        feedback_positions = FeedbackPositions(feedback_positions_data)
        assert dm_message_preprocessing(
            dm_message_missing_plies['U6'],
            feedback_positions) == ExpectedFullFeedback.MissingPlies.FirstPalletU.sixth_ply

    def test_correctly_process_u7(self):
        feedback_positions = FeedbackPositions(feedback_positions_data)
        assert dm_message_preprocessing(
            dm_message_missing_plies['U7'],
            feedback_positions) == ExpectedFullFeedback.MissingPlies.FirstPalletU.seventh_ply


@patch("app.config.MOULD_ID", "mould_id")
class HandlePliesToBePlacedTests:
    def test_correctly_process_p1(self):
        feedback_positions = FeedbackPositions(feedback_positions_data)
        assert dm_message_preprocessing(
            dm_message_plies_to_be_placed[
                'P1'], feedback_positions) == ExpectedFullFeedback.PliesToBePlaced.FirstPalletP.first_ply

    def test_correctly_process_p2(self):
        feedback_positions = FeedbackPositions(feedback_positions_data)
        assert dm_message_preprocessing(
            dm_message_plies_to_be_placed[
                'P2'], feedback_positions) == ExpectedFullFeedback.PliesToBePlaced.FirstPalletP.second_ply

    def test_correctly_process_p3(self):
        feedback_positions = FeedbackPositions(feedback_positions_data)
        assert dm_message_preprocessing(
            dm_message_plies_to_be_placed[
                'P3'], feedback_positions) == ExpectedFullFeedback.PliesToBePlaced.FirstPalletP.third_ply

    def test_correctly_process_p4(self):
        feedback_positions = FeedbackPositions(feedback_positions_data)
        assert dm_message_preprocessing(
            dm_message_plies_to_be_placed[
                'P4'], feedback_positions) == ExpectedFullFeedback.PliesToBePlaced.SecondPalletP.fourth_ply

    def test_correctly_process_p5(self):
        feedback_positions = FeedbackPositions(feedback_positions_data)
        assert dm_message_preprocessing(
            dm_message_plies_to_be_placed[
                'P5'], feedback_positions) == ExpectedFullFeedback.PliesToBePlaced.SecondPalletP.fifth_ply

    def test_correctly_process_p6(self):
        feedback_positions = FeedbackPositions(feedback_positions_data)
        assert dm_message_preprocessing(
            dm_message_plies_to_be_placed[
                'P6'], feedback_positions) == ExpectedFullFeedback.PliesToBePlaced.SecondPalletP.sixth_ply

    def test_correctly_process_p7(self):
        feedback_positions = FeedbackPositions(feedback_positions_data)
        assert dm_message_preprocessing(
            dm_message_plies_to_be_placed[
                'P7'], feedback_positions) == ExpectedFullFeedback.PliesToBePlaced.ThirdPalletP.seventh_ply

    def test_correctly_process_p8(self):
        feedback_positions = FeedbackPositions(feedback_positions_data)
        assert dm_message_preprocessing(
            dm_message_plies_to_be_placed[
                'P8'], feedback_positions) == ExpectedFullFeedback.PliesToBePlaced.ThirdPalletP.eighth_ply

    def test_correctly_process_p9(self):
        feedback_positions = FeedbackPositions(feedback_positions_data)
        assert dm_message_preprocessing(
            dm_message_plies_to_be_placed[
                'P9'], feedback_positions) == ExpectedFullFeedback.PliesToBePlaced.ThirdPalletP.ninth_ply

    def test_correctly_process_u1(self):
        feedback_positions = FeedbackPositions(feedback_positions_data)
        assert dm_message_preprocessing(
            dm_message_plies_to_be_placed[
                'U1'], feedback_positions) == ExpectedFullFeedback.PliesToBePlaced.FirstPalletU.first_ply

    def test_correctly_process_u2(self):
        feedback_positions = FeedbackPositions(feedback_positions_data)
        assert dm_message_preprocessing(
            dm_message_plies_to_be_placed[
                'U2'], feedback_positions) == ExpectedFullFeedback.PliesToBePlaced.FirstPalletU.second_ply

    def test_correctly_process_u3(self):
        feedback_positions = FeedbackPositions(feedback_positions_data)
        assert dm_message_preprocessing(
            dm_message_plies_to_be_placed[
                'U3'], feedback_positions) == ExpectedFullFeedback.PliesToBePlaced.FirstPalletU.third_ply

    def test_correctly_process_u4(self):
        feedback_positions = FeedbackPositions(feedback_positions_data)
        assert dm_message_preprocessing(
            dm_message_plies_to_be_placed[
                'U4'], feedback_positions) == ExpectedFullFeedback.PliesToBePlaced.FirstPalletU.fourth_ply

    def test_correctly_process_u5(self):
        feedback_positions = FeedbackPositions(feedback_positions_data)
        assert dm_message_preprocessing(
            dm_message_plies_to_be_placed[
                'U5'], feedback_positions) == ExpectedFullFeedback.PliesToBePlaced.FirstPalletU.fifth_ply

    def test_correctly_process_u6(self):
        feedback_positions = FeedbackPositions(feedback_positions_data)
        assert dm_message_preprocessing(
            dm_message_plies_to_be_placed[
                'U6'], feedback_positions) == ExpectedFullFeedback.PliesToBePlaced.FirstPalletU.sixth_ply

    def test_correctly_process_u7(self):
        feedback_positions = FeedbackPositions(feedback_positions_data)
        assert dm_message_preprocessing(
            dm_message_plies_to_be_placed[
                'U7'], feedback_positions) == ExpectedFullFeedback.PliesToBePlaced.FirstPalletU.seventh_ply


@patch("app.config.MOULD_ID", "mould_id")
class HandleCorrectlyPlacedPliesTests:
    def test_correctly_process_p1(self):
        feedback_positions = FeedbackPositions(feedback_positions_data)
        assert dm_message_preprocessing(
            dm_message_correctly_placed_plies[
                'P1'], feedback_positions) == ExpectedFullFeedback.CorrectlyPlacedPlies.FirstPalletP.first_ply

    def test_correctly_process_p2(self):
        feedback_positions = FeedbackPositions(feedback_positions_data)
        assert dm_message_preprocessing(
            dm_message_correctly_placed_plies[
                'P2'], feedback_positions) == ExpectedFullFeedback.CorrectlyPlacedPlies.FirstPalletP.second_ply

    def test_correctly_process_p3(self):
        feedback_positions = FeedbackPositions(feedback_positions_data)
        assert dm_message_preprocessing(
            dm_message_correctly_placed_plies[
                'P3'], feedback_positions) == ExpectedFullFeedback.PalletsLastPliesPlaced.FirstPalletP.third_ply

    def test_correctly_process_p4(self):
        feedback_positions = FeedbackPositions(feedback_positions_data)
        assert dm_message_preprocessing(
            dm_message_correctly_placed_plies[
                'P4'], feedback_positions) == ExpectedFullFeedback.CorrectlyPlacedPlies.SecondPalletP.fourth_ply

    def test_correctly_process_p5(self):
        feedback_positions = FeedbackPositions(feedback_positions_data)
        assert dm_message_preprocessing(
            dm_message_correctly_placed_plies[
                'P5'], feedback_positions) == ExpectedFullFeedback.CorrectlyPlacedPlies.SecondPalletP.fifth_ply

    def test_correctly_process_p6(self):
        feedback_positions = FeedbackPositions(feedback_positions_data)
        assert dm_message_preprocessing(
            dm_message_correctly_placed_plies[
                'P6'], feedback_positions) == ExpectedFullFeedback.PalletsLastPliesPlaced.SecondPalletP.sixth_ply

    def test_correctly_process_p7(self):
        feedback_positions = FeedbackPositions(feedback_positions_data)
        assert dm_message_preprocessing(
            dm_message_correctly_placed_plies[
                'P7'], feedback_positions) == ExpectedFullFeedback.CorrectlyPlacedPlies.ThirdPalletP.seventh_ply

    def test_correctly_process_p8(self):
        feedback_positions = FeedbackPositions(feedback_positions_data)
        assert dm_message_preprocessing(
            dm_message_correctly_placed_plies[
                'P8'], feedback_positions) == ExpectedFullFeedback.CorrectlyPlacedPlies.ThirdPalletP.eighth_ply

    def test_correctly_process_p9(self):
        feedback_positions = FeedbackPositions(feedback_positions_data)
        assert dm_message_preprocessing(
            dm_message_correctly_placed_plies[
                'P9'], feedback_positions) == ExpectedFullFeedback.PalletsLastPliesPlaced.ThirdPalletP.ninth_ply

    def test_correctly_process_u1(self):
        feedback_positions = FeedbackPositions(feedback_positions_data)
        assert dm_message_preprocessing(
            dm_message_correctly_placed_plies[
                'U1'], feedback_positions) == ExpectedFullFeedback.CorrectlyPlacedPlies.FirstPalletU.first_ply

    def test_correctly_process_u2(self):
        feedback_positions = FeedbackPositions(feedback_positions_data)
        assert dm_message_preprocessing(
            dm_message_correctly_placed_plies[
                'U2'], feedback_positions) == ExpectedFullFeedback.CorrectlyPlacedPlies.FirstPalletU.second_ply

    def test_correctly_process_u3(self):
        feedback_positions = FeedbackPositions(feedback_positions_data)
        assert dm_message_preprocessing(
            dm_message_correctly_placed_plies[
                'U3'], feedback_positions) == ExpectedFullFeedback.CorrectlyPlacedPlies.FirstPalletU.third_ply

    def test_correctly_process_u4(self):
        feedback_positions = FeedbackPositions(feedback_positions_data)
        assert dm_message_preprocessing(
            dm_message_correctly_placed_plies[
                'U4'], feedback_positions) == ExpectedFullFeedback.CorrectlyPlacedPlies.FirstPalletU.fourth_ply

    def test_correctly_process_u5(self):
        feedback_positions = FeedbackPositions(feedback_positions_data)
        assert dm_message_preprocessing(
            dm_message_correctly_placed_plies[
                'U5'], feedback_positions) == ExpectedFullFeedback.CorrectlyPlacedPlies.FirstPalletU.fifth_ply

    def test_correctly_process_u6(self):
        feedback_positions = FeedbackPositions(feedback_positions_data)
        assert dm_message_preprocessing(
            dm_message_correctly_placed_plies[
                'U6'], feedback_positions) == ExpectedFullFeedback.CorrectlyPlacedPlies.FirstPalletU.sixth_ply

    def test_correctly_process_u7(self):
        feedback_positions = FeedbackPositions(feedback_positions_data)
        assert dm_message_preprocessing(
            dm_message_correctly_placed_plies[
                'U7'], feedback_positions) == ExpectedFullFeedback.PalletsLastPliesPlaced.FirstPalletU.seventh_ply


@patch("app.config.MOULD_ID", "mould_id")
class HandlePliesToNullTests:
    def test_correctly_process_p1(self):
        feedback_positions = FeedbackPositions(feedback_positions_data)
        assert dm_message_preprocessing(
            dm_message_plies_to_null[
                'P1'], feedback_positions) == ExpectedFullFeedback.PliesToNull.FirstPalletP.first_ply

    def test_correctly_process_p2(self):
        feedback_positions = FeedbackPositions(feedback_positions_data)

        assert dm_message_preprocessing(
            dm_message_plies_to_null[
                'P2'], feedback_positions) == ExpectedFullFeedback.PliesToNull.FirstPalletP.second_ply

    def test_correctly_process_p3(self):
        feedback_positions = FeedbackPositions(feedback_positions_data)

        assert dm_message_preprocessing(
            dm_message_plies_to_null[
                'P3'], feedback_positions) == ExpectedFullFeedback.PliesToNull.FirstPalletP.third_ply

    def test_correctly_process_p4(self):
        feedback_positions = FeedbackPositions(feedback_positions_data)

        assert dm_message_preprocessing(
            dm_message_plies_to_null[
                'P4'], feedback_positions) == ExpectedFullFeedback.PliesToNull.SecondPalletP.fourth_ply

    def test_correctly_process_p5(self):
        feedback_positions = FeedbackPositions(feedback_positions_data)

        assert dm_message_preprocessing(
            dm_message_plies_to_null[
                'P5'], feedback_positions) == ExpectedFullFeedback.PliesToNull.SecondPalletP.fifth_ply

    def test_correctly_process_p6(self):
        feedback_positions = FeedbackPositions(feedback_positions_data)

        assert dm_message_preprocessing(
            dm_message_plies_to_null[
                'P6'], feedback_positions) == ExpectedFullFeedback.PliesToNull.SecondPalletP.sixth_ply

    def test_correctly_process_p7(self):
        feedback_positions = FeedbackPositions(feedback_positions_data)

        assert dm_message_preprocessing(
            dm_message_plies_to_null[
                'P7'], feedback_positions) == ExpectedFullFeedback.PliesToNull.ThirdPalletP.seventh_ply

    def test_correctly_process_p8(self):
        feedback_positions = FeedbackPositions(feedback_positions_data)

        assert dm_message_preprocessing(
            dm_message_plies_to_null[
                'P8'], feedback_positions) == ExpectedFullFeedback.PliesToNull.ThirdPalletP.eighth_ply

    def test_correctly_process_p9(self):
        feedback_positions = FeedbackPositions(feedback_positions_data)

        assert dm_message_preprocessing(
            dm_message_plies_to_null[
                'P9'], feedback_positions) == ExpectedFullFeedback.PliesToNull.ThirdPalletP.ninth_ply

    def test_correctly_process_u1(self):
        feedback_positions = FeedbackPositions(feedback_positions_data)

        assert dm_message_preprocessing(
            dm_message_plies_to_null[
                'U1'], feedback_positions) == ExpectedFullFeedback.PliesToNull.FirstPalletU.first_ply

    def test_correctly_process_u2(self):
        feedback_positions = FeedbackPositions(feedback_positions_data)

        assert dm_message_preprocessing(
            dm_message_plies_to_null[
                'U2'], feedback_positions) == ExpectedFullFeedback.PliesToNull.FirstPalletU.second_ply

    def test_correctly_process_u3(self):
        feedback_positions = FeedbackPositions(feedback_positions_data)

        assert dm_message_preprocessing(
            dm_message_plies_to_null[
                'U3'], feedback_positions) == ExpectedFullFeedback.PliesToNull.FirstPalletU.third_ply

    def test_correctly_process_u4(self):
        feedback_positions = FeedbackPositions(feedback_positions_data)

        assert dm_message_preprocessing(
            dm_message_plies_to_null[
                'U4'], feedback_positions) == ExpectedFullFeedback.PliesToNull.FirstPalletU.fourth_ply

    def test_correctly_process_u5(self):
        feedback_positions = FeedbackPositions(feedback_positions_data)

        assert dm_message_preprocessing(
            dm_message_plies_to_null[
                'U5'], feedback_positions) == ExpectedFullFeedback.PliesToNull.FirstPalletU.fifth_ply

    def test_correctly_process_u6(self):
        feedback_positions = FeedbackPositions(feedback_positions_data)

        assert dm_message_preprocessing(
            dm_message_plies_to_null[
                'U6'], feedback_positions) == ExpectedFullFeedback.PliesToNull.FirstPalletU.sixth_ply

    def test_correctly_process_u7(self):
        feedback_positions = FeedbackPositions(feedback_positions_data)

        assert dm_message_preprocessing(
            dm_message_plies_to_null[
                'U7'], feedback_positions) == ExpectedFullFeedback.PliesToNull.FirstPalletU.seventh_ply


@patch("app.config.MOULD_ID", "mould_id")
class HandlePhantomPliesTests:
    def test_correctly_process_p1(self):
        feedback_positions = FeedbackPositions(feedback_positions_data)

        assert dm_message_preprocessing(
            dm_message_phantom_plies[
                'P1'], feedback_positions) == ExpectedFullFeedback.PhantomPlies.FirstPalletP.first_ply

    def test_correctly_process_p2(self):
        feedback_positions = FeedbackPositions(feedback_positions_data)

        assert dm_message_preprocessing(
            dm_message_phantom_plies[
                'P2'], feedback_positions) == ExpectedFullFeedback.PhantomPlies.FirstPalletP.second_ply

    def test_correctly_process_p3(self):
        feedback_positions = FeedbackPositions(feedback_positions_data)

        assert dm_message_preprocessing(
            dm_message_phantom_plies[
                'P3'], feedback_positions) == ExpectedFullFeedback.PhantomPlies.FirstPalletP.third_ply

    def test_correctly_process_p4(self):
        feedback_positions = FeedbackPositions(feedback_positions_data)

        assert dm_message_preprocessing(
            dm_message_phantom_plies[
                'P4'], feedback_positions) == ExpectedFullFeedback.PhantomPlies.SecondPalletP.fourth_ply

    def test_correctly_process_p5(self):
        feedback_positions = FeedbackPositions(feedback_positions_data)

        assert dm_message_preprocessing(
            dm_message_phantom_plies[
                'P5'], feedback_positions) == ExpectedFullFeedback.PhantomPlies.SecondPalletP.fifth_ply

    def test_correctly_process_p6(self):
        feedback_positions = FeedbackPositions(feedback_positions_data)

        assert dm_message_preprocessing(
            dm_message_phantom_plies[
                'P6'], feedback_positions) == ExpectedFullFeedback.PhantomPlies.SecondPalletP.sixth_ply

    def test_correctly_process_p7(self):
        feedback_positions = FeedbackPositions(feedback_positions_data)

        assert dm_message_preprocessing(
            dm_message_phantom_plies[
                'P7'], feedback_positions) == ExpectedFullFeedback.PhantomPlies.ThirdPalletP.seventh_ply

    def test_correctly_process_p8(self):
        feedback_positions = FeedbackPositions(feedback_positions_data)

        assert dm_message_preprocessing(
            dm_message_phantom_plies[
                'P8'], feedback_positions) == ExpectedFullFeedback.PhantomPlies.ThirdPalletP.eighth_ply

    def test_correctly_process_p9(self):
        feedback_positions = FeedbackPositions(feedback_positions_data)

        assert dm_message_preprocessing(
            dm_message_phantom_plies[
                'P9'], feedback_positions) == ExpectedFullFeedback.PhantomPlies.ThirdPalletP.ninth_ply

    def test_correctly_process_u1(self):
        feedback_positions = FeedbackPositions(feedback_positions_data)

        assert dm_message_preprocessing(
            dm_message_phantom_plies[
                'U1'], feedback_positions) == ExpectedFullFeedback.PhantomPlies.FirstPalletU.first_ply

    def test_correctly_process_u2(self):
        feedback_positions = FeedbackPositions(feedback_positions_data)

        assert dm_message_preprocessing(
            dm_message_phantom_plies[
                'U2'], feedback_positions) == ExpectedFullFeedback.PhantomPlies.FirstPalletU.second_ply

    def test_correctly_process_u3(self):
        feedback_positions = FeedbackPositions(feedback_positions_data)

        assert dm_message_preprocessing(
            dm_message_phantom_plies[
                'U3'], feedback_positions) == ExpectedFullFeedback.PhantomPlies.FirstPalletU.third_ply

    def test_correctly_process_u4(self):
        feedback_positions = FeedbackPositions(feedback_positions_data)

        assert dm_message_preprocessing(
            dm_message_phantom_plies[
                'U4'], feedback_positions) == ExpectedFullFeedback.PhantomPlies.FirstPalletU.fourth_ply

    def test_correctly_process_u5(self):
        feedback_positions = FeedbackPositions(feedback_positions_data)

        assert dm_message_preprocessing(
            dm_message_phantom_plies[
                'U5'], feedback_positions) == ExpectedFullFeedback.PhantomPlies.FirstPalletU.fifth_ply

    def test_correctly_process_u6(self):
        feedback_positions = FeedbackPositions(feedback_positions_data)

        assert dm_message_preprocessing(
            dm_message_phantom_plies[
                'U6'], feedback_positions) == ExpectedFullFeedback.PhantomPlies.FirstPalletU.sixth_ply

    def test_correctly_process_u7(self):
        feedback_positions = FeedbackPositions(feedback_positions_data)

        assert dm_message_preprocessing(
            dm_message_phantom_plies[
                'U7'], feedback_positions) == ExpectedFullFeedback.PhantomPlies.FirstPalletU.seventh_ply


@patch("app.config.MOULD_ID", "mould_id")
class HandleLastPliesPlaced:
    def test_correctly_process_p1(self):
        feedback_positions = FeedbackPositions(feedback_positions_data)

        assert dm_message_preprocessing(
            dm_message_last_plies_placed[
                'P1'], feedback_positions) == ExpectedFullFeedback.PhantomPlies.FirstPalletP.first_ply

    def test_correctly_process_p2(self):
        feedback_positions = FeedbackPositions(feedback_positions_data)

        assert dm_message_preprocessing(
            dm_message_last_plies_placed[
                'P2'], feedback_positions) == ExpectedFullFeedback.PhantomPlies.FirstPalletP.second_ply

    def test_correctly_process_p3(self):
        feedback_positions = FeedbackPositions(feedback_positions_data)

        assert dm_message_preprocessing(
            dm_message_last_plies_placed[
                'P3'], feedback_positions) == ExpectedFullFeedback.PhantomPlies.FirstPalletP.third_ply

    def test_correctly_process_p4(self):
        feedback_positions = FeedbackPositions(feedback_positions_data)

        assert dm_message_preprocessing(
            dm_message_last_plies_placed[
                'P4'], feedback_positions) == ExpectedFullFeedback.PhantomPlies.SecondPalletP.fourth_ply

    def test_correctly_process_p5(self):
        feedback_positions = FeedbackPositions(feedback_positions_data)

        assert dm_message_preprocessing(
            dm_message_last_plies_placed[
                'P5'], feedback_positions) == ExpectedFullFeedback.PhantomPlies.SecondPalletP.fifth_ply

    def test_correctly_process_p6(self):
        feedback_positions = FeedbackPositions(feedback_positions_data)

        assert dm_message_preprocessing(
            dm_message_last_plies_placed[
                'P6'], feedback_positions) == ExpectedFullFeedback.PhantomPlies.SecondPalletP.sixth_ply

    def test_correctly_process_p7(self):
        feedback_positions = FeedbackPositions(feedback_positions_data)

        assert dm_message_preprocessing(
            dm_message_last_plies_placed[
                'P7'], feedback_positions) == ExpectedFullFeedback.PhantomPlies.ThirdPalletP.seventh_ply

    def test_correctly_process_p8(self):
        feedback_positions = FeedbackPositions(feedback_positions_data)

        assert dm_message_preprocessing(
            dm_message_last_plies_placed[
                'P8'], feedback_positions) == ExpectedFullFeedback.PhantomPlies.ThirdPalletP.eighth_ply

    def test_correctly_process_p9(self):
        feedback_positions = FeedbackPositions(feedback_positions_data)

        assert dm_message_preprocessing(
            dm_message_last_plies_placed[
                'P9'], feedback_positions) == ExpectedFullFeedback.PhantomPlies.ThirdPalletP.ninth_ply

    def test_correctly_process_u1(self):
        feedback_positions = FeedbackPositions(feedback_positions_data)

        assert dm_message_preprocessing(
            dm_message_last_plies_placed[
                'U1'], feedback_positions) == ExpectedFullFeedback.PhantomPlies.FirstPalletU.first_ply

    def test_correctly_process_u2(self):
        feedback_positions = FeedbackPositions(feedback_positions_data)

        assert dm_message_preprocessing(
            dm_message_last_plies_placed[
                'U2'], feedback_positions) == ExpectedFullFeedback.PhantomPlies.FirstPalletU.second_ply

    def test_correctly_process_u3(self):
        feedback_positions = FeedbackPositions(feedback_positions_data)

        assert dm_message_preprocessing(
            dm_message_last_plies_placed[
                'U3'], feedback_positions) == ExpectedFullFeedback.PhantomPlies.FirstPalletU.third_ply

    def test_correctly_process_u4(self):
        feedback_positions = FeedbackPositions(feedback_positions_data)

        assert dm_message_preprocessing(
            dm_message_last_plies_placed[
                'U4'], feedback_positions) == ExpectedFullFeedback.PhantomPlies.FirstPalletU.fourth_ply

    def test_correctly_process_u5(self):
        feedback_positions = FeedbackPositions(feedback_positions_data)

        assert dm_message_preprocessing(
            dm_message_last_plies_placed[
                'U5'], feedback_positions) == ExpectedFullFeedback.PhantomPlies.FirstPalletU.fifth_ply

    def test_correctly_process_u6(self):
        feedback_positions = FeedbackPositions(feedback_positions_data)

        assert dm_message_preprocessing(
            dm_message_last_plies_placed[
                'U6'], feedback_positions) == ExpectedFullFeedback.PhantomPlies.FirstPalletU.sixth_ply

    def test_correctly_process_u7(self):
        feedback_positions = FeedbackPositions(feedback_positions_data)

        assert dm_message_preprocessing(
            dm_message_last_plies_placed[
                'U7'], feedback_positions) == ExpectedFullFeedback.PhantomPlies.FirstPalletU.seventh_ply


@patch("app.config.MOULD_ID", "mould_id")
class HandlePalletsLastPliesPlacedTests:
    def test_correctly_process_p3(self):
        feedback_positions = FeedbackPositions(feedback_positions_data)

        assert dm_message_preprocessing(
            dm_message_pallets_last_plies_placed[
                'P3'], feedback_positions) == ExpectedFullFeedback.PalletsLastPliesPlaced.FirstPalletP.third_ply

    def test_correctly_process_p6(self):
        feedback_positions = FeedbackPositions(feedback_positions_data)

        assert dm_message_preprocessing(
            dm_message_pallets_last_plies_placed[
                'P6'], feedback_positions) == ExpectedFullFeedback.PalletsLastPliesPlaced.SecondPalletP.sixth_ply

    def test_correctly_process_p9(self):
        feedback_positions = FeedbackPositions(feedback_positions_data)

        assert dm_message_preprocessing(
            dm_message_pallets_last_plies_placed[
                'P9'], feedback_positions) == ExpectedFullFeedback.PalletsLastPliesPlaced.ThirdPalletP.ninth_ply

    def test_correctly_process_u7(self):
        feedback_positions = FeedbackPositions(feedback_positions_data)

        assert dm_message_preprocessing(
            dm_message_pallets_last_plies_placed[
                'U7'], feedback_positions) == ExpectedFullFeedback.PalletsLastPliesPlaced.FirstPalletU.seventh_ply
