# pylint: disable=protected-access, missing-module-docstring, missing-class-docstring, missing-function-docstring

import unittest

from app.blade_layout_cache import BladeLayoutCache
import app.config as cfg

class BladeLayoutCacheTestCase(unittest.TestCase):
    def setUp(self):
        self.cache = BladeLayoutCache()
        cfg.BLADE_LAYOUT_PATH = 'samples-json/'

class TestBladeLayoutCache(BladeLayoutCacheTestCase):

    def test_init_and_get(self):
        self.cache.init()

        self.assertIsNotNone(self.cache.get('090_only_5_plies_from_json', '003000003_6lines'))
        self.assertIsNotNone(self.cache.get('090_only_5_plies_from_json', '005000005_6lines'))
        self.assertIsNotNone(self.cache.get('090_only_5_plies_from_json', '003000003_4lines'))
        self.assertIsNotNone(self.cache.get('090_only_5_plies_from_json', '005000005_4lines'))
