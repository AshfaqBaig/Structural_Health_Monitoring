# pylint: disable=protected-access, missing-module-docstring, missing-class-docstring, missing-function-docstring

import io
import unittest
import ezdxf


from app.processors.shape_feedback import LaserShapeFeedback

class LaserShapeFeedbackTestCase(unittest.TestCase):
    def setUp(self):
        self.processor = LaserShapeFeedback()


class TestShapeFeedback(LaserShapeFeedbackTestCase):

    def test_success_circle(self):
        # build sample message
        payload = {
            'type': 'circle',
            'center': [0, 0, 1],
            'radius': 400
        }

        result = self.processor.run(payload)

        self.assertIsNotNone(result)

        dxf_stream = io.StringIO(result)
        dxf = ezdxf.read(dxf_stream)
        entities = dxf.modelspace().query('CIRCLE')
        self.assertEqual(len(entities), 1)
        self.assertEqual(entities[0].dxf.radius, payload['radius'])

    def test_success_circlev2(self):
        # build sample message
        payload = {
            'type': 'circle-v2',
            'center': [0, 0, 1]
        }

        result = self.processor.run(payload)

        self.assertIsNotNone(result)

    def test_success_text_alphanumeric(self):
        # build sample message
        payload = {
            'type': 'text',
            'position': [1, 2, 0],
            'text': 'X123'
        }

        result = self.processor.run(payload)

        self.assertIsNotNone(result)


    def test_success_text_3_numeric(self):
        # build sample message
        payload = {
            'type': 'text',
            'position': [1, 2, 0],
            'text': '456'
        }

        result = self.processor.run(payload)

        self.assertIsNotNone(result)

    def test_success_text_4_numeric(self):
        # build sample message
        payload = {
            'type': 'text',
            'position': [1, 2, 0],
            'text': '7890'
        }

        result = self.processor.run(payload)

        self.assertIsNotNone(result)

    def test_failure_text_invalid_letter(self):
        # build sample message
        payload = {
            'type': 'text',
            'position': [1, 2, 0],
            'text': 'A123'
        }

        self.assertRaises(KeyError, self.processor.run, payload)

    def test_failure_1(self):
        # build sample message
        payload = {
            'type': 'circle'
        }

        self.assertRaises(BaseException, self.processor.run, payload)

    def test_failure_2(self):
        payload = {
            'coordinates': [0, 0, 1]
        }

        self.assertRaises(BaseException, self.processor.run, payload)

    def test_success_polyline(self):
        # build sample message
        payload = {
            'type': 'polyline',
            'coordinates': [[1, -1, 1.0],[1, -2, 1.1]]
        }

        result = self.processor.run(payload)

        self.assertIsNotNone(result)

        dxf_stream = io.StringIO(result)
        dxf = ezdxf.read(dxf_stream)
        entities = dxf.modelspace().query('POLYLINE')
        self.assertEqual(len(entities), 1)
