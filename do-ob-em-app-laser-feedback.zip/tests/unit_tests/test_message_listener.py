# pylint: disable=protected-access, missing-class-docstring, missing-function-docstring
from queue import Queue
from unittest.mock import AsyncMock
from azure.iot.device.aio import IoTHubModuleClient
import pytest
import pytest_asyncio
from app.message_listener import MessageListener

projection_queue = Queue()


@pytest_asyncio.fixture(name="message_listener_instance")
def fixture_message_listener_instance(mocker):
    mocker.patch("azure.iot.device.aio.IoTHubModuleClient.create_from_edge_environment",
                 return_value=IoTHubModuleClient)
    mocker.patch("asyncio.run")
    mocker.patch("asyncio.get_event_loop", return_value=AsyncMock())

    message_listener_instance = MessageListener(projection_queue)
    return message_listener_instance

@pytest.mark.asyncio
async def test_run(mocker, message_listener_instance) -> None:
    """ Function to test ModuleListener.run() """
    mocked_connect = mocker.patch.object(message_listener_instance.module_client, "connect", new_callable=AsyncMock)
    mocked_disconnect = mocker.patch.object(
        message_listener_instance.module_client, "disconnect", new_callable=AsyncMock)

    await message_listener_instance.run()

    assert mocked_connect.call_count == 1
    assert mocked_disconnect.call_count == 1
