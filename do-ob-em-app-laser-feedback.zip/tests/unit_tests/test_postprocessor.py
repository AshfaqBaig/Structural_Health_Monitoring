# pylint: disable=missing-class-docstring, missing-function-docstring
import json

import pytest

from app.processors.postprocessor import ResponsePostprocessor


class ResponsePostprocessorTests:

    @pytest.mark.asyncio
    async def test_success(self):
        postprocessor = ResponsePostprocessor()

        with open("./samples/payload.json", "rb") as file, \
                open("./samples/polyline.dxf", "r", encoding="UTF8") as dxf_file:
            payload = json.loads(file.read())
            dxf = dxf_file.read()

            # run test
            result: str = postprocessor.run(payload, [dxf, dxf])

            # verify
            assert result is not None
            assert result['session'] == payload['session']
            assert result['feedbackType'] is not None
            assert result['expiration'] == payload['expiration']
            assert result['content'] is not None
