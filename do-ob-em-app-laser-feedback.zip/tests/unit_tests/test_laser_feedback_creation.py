# pylint: disable=protected-access, missing-module-docstring, missing-class-docstring, missing-function-docstring
import pytest

from app.feedback.laser_feedback_creation import LaserFeedbackCreation
from app.feedback.feedback_positions import FeedbackPositions


class LaserFeedbackCreationGenerateFeedbackItemsTests:
    def test_should_return_empty_feedback_items_list_when_type_of_plies_to_null_given(
            self, sample_graph_data, sample_feedback_positions):
        # GIVEN
        feedback_type = "plies-to-null"
        ply_id = "P1"
        ply = sample_graph_data["plies"][ply_id]
        laser_feedback_creation = LaserFeedbackCreation(FeedbackPositions(sample_feedback_positions))

        # WHEN laser_feedback_creation.generate_feedback_items is called
        result = laser_feedback_creation.generate_feedback_items(ply, ply_id, feedback_type)

        # THEN correct result is returned
        assert not result

    def test_should_correctly_create_feedback_items_when_ply_for_type_of_missing_plies_given(
            self, sample_graph_data, sample_feedback_positions):
        # GIVEN
        feedback_type = "missing-plies"
        ply_id = "P1"
        ply = sample_graph_data["plies"][ply_id]
        laser_feedback_creation = LaserFeedbackCreation(FeedbackPositions(sample_feedback_positions))

        # WHEN laser_feedback_creation.generate_feedback_items is called
        result = laser_feedback_creation.generate_feedback_items(ply, ply_id, feedback_type)

        # THEN correct result is returned
        expected_dxf_item = {
             "type": "contour-4-lines",
            "dxfId": ply["dxf_id"],
            "dxfPlyId": ply["dxf_ply_id"]
        }

        expected_text_item = {
            "type": "text",
            "text": "X"+ply_id[-3:],
            "position": [1, 0, 1]
        }

        expected_result = [expected_dxf_item, expected_text_item]
        assert result == expected_result

    def test_should_correctly_create_feedback_items_when_ply_for_type_of_plies_to_be_placed_given(
            self, sample_graph_data, sample_feedback_positions):
        # GIVEN
        feedback_type = "plies-to-be-placed"
        ply_id = "P1"
        ply = sample_graph_data["plies"][ply_id]
        laser_feedback_creation = LaserFeedbackCreation(FeedbackPositions(sample_feedback_positions))

        # WHEN laser_feedback_creation.generate_feedback_items is called
        result = laser_feedback_creation.generate_feedback_items(ply, ply_id, feedback_type)

        # THEN correct result is returned
        expected_dxf_item = {
             "type": "contour-6-lines",
            "dxfId": ply["dxf_id"],
            "dxfPlyId": ply["dxf_ply_id"]
        }

        expected_text_item = {
            "type": "text",
            "text": "R"+ply_id[-3:],
            "position": [1, 0, 1]
        }

        expected_result = [expected_dxf_item, expected_text_item]
        assert result == expected_result

    def test_should_correctly_create_feedback_items_when_ply_for_type_of_phantom_plies_given(
            self, sample_graph_data, sample_feedback_positions):
        # GIVEN
        feedback_type = "phantom-plies"
        ply_id = "P1"
        ply = sample_graph_data["plies"][ply_id]
        laser_feedback_creation = LaserFeedbackCreation(FeedbackPositions(sample_feedback_positions))

        # WHEN laser_feedback_creation.generate_feedback_items is called
        result = laser_feedback_creation.generate_feedback_items(ply, ply_id, feedback_type)

        # THEN correct result is returned
        expected_dxf_item = {
             "type": "contour-6-lines",
            "dxfId": ply["dxf_id"],
            "dxfPlyId": ply["dxf_ply_id"]
        }

        expected_text_item = {
            "type": "text",
            "text": "H"+ply_id[-3:],
            "position": [1, 0, 1]
        }

        expected_result = [expected_dxf_item, expected_text_item]
        assert result == expected_result

    def test_should_correctly_create_feedback_items_when_ply_for_type_of_correctly_placed_plies_given(
            self, sample_graph_data, sample_feedback_positions):
        # GIVEN
        feedback_type = "correctly-placed-plies"
        ply_id = "P1"
        ply = sample_graph_data["plies"][ply_id]
        laser_feedback_creation = LaserFeedbackCreation(FeedbackPositions(sample_feedback_positions))

        # WHEN laser_feedback_creation.generate_feedback_items is called
        result = laser_feedback_creation.generate_feedback_items(ply, ply_id, feedback_type)

        # THEN correct result is returned
        expected_dxf_item = {
             "type": "contour-4-lines",
            "dxfId": ply["dxf_id"],
            "dxfPlyId": ply["dxf_ply_id"]
        }

        expected_text_item = {
            "type": "text",
            "text": "T",
            "position": [1, 0, 1]
        }

        expected_result = [expected_dxf_item, expected_text_item]
        assert result == expected_result

    def test_should_correctly_create_feedback_items_when_ply_for_type_of_last_plies_placed_given(
            self, sample_graph_data, sample_feedback_positions):
        # GIVEN
        feedback_type = "last-plies-placed"
        ply_id = "P1"
        ply = sample_graph_data["plies"][ply_id]
        laser_feedback_creation = LaserFeedbackCreation(FeedbackPositions(sample_feedback_positions))

        # WHEN laser_feedback_creation.generate_feedback_items is called
        result = laser_feedback_creation.generate_feedback_items(ply, ply_id, feedback_type)

        # THEN correct result is returned
        expected_dxf_item = {
             "type": "contour-4-lines",
            "dxfId": ply["dxf_id"],
            "dxfPlyId": ply["dxf_ply_id"]
        }

        expected_text_item = {
            "type": "text",
            "text": "S"+ply_id[-3:],
            "position": [1, 0, 1]
        }

        expected_result = [expected_dxf_item, expected_text_item]
        assert result == expected_result

    @pytest.mark.parametrize(
        "feedback_type",
        ["missing-plies", "plies-to-be-placed", "correctly-placed-plies", "last-plies-placed", "plies-to-null"],
    )
    def test_should_raise_exception_when_empty_ply_dict_given_for_various_feedback_types(
            self, sample_feedback_positions, feedback_type):
        # GIVEN
        ply_id = "P1"
        ply = {}
        laser_feedback_creation = LaserFeedbackCreation(FeedbackPositions(sample_feedback_positions))

        # WHEN laser_feedback_creation.generate_feedback_items is called, assert that an exception is raised
        with pytest.raises(Exception) as exc_info:
            laser_feedback_creation.generate_feedback_items(ply, ply_id, feedback_type)

        # THEN an exception of type ValueError is raised
        assert exc_info.type is ValueError
        exc_message = f"Failed to generate feedback items, given ply for ply_id {ply_id} is empty dict: {ply}"
        assert exc_info.value.args[0] == exc_message

    def test_should_raise_exception_when_invalid_feedback_type_given(self, mocker, sample_feedback_positions):
        # GIVEN
        feedback_type = "non_existing_feedback_type"
        ply_id = "mock"
        ply = {"mock": "data"}
        laser_feedback_creation = LaserFeedbackCreation(FeedbackPositions(sample_feedback_positions))

        # AND more patched external methods
        log = mocker.patch("app.feedback.laser_feedback_creation.log")

        # WHEN laser_feedback_creation.generate_feedback_items is called, assert that an exception is raised
        with pytest.raises(Exception) as exc_info:
            laser_feedback_creation.generate_feedback_items(ply, ply_id, feedback_type)

        # THEN an exception of type ValueError is raised
        assert exc_info.type is ValueError
        error_message = f"Failed to generate laser marks for feedback, unrecognised feedback_type={feedback_type}"
        assert exc_info.value.args[0] == error_message

        # AND log.error is called once with correct argument
        log.error.assert_called_once()
        call_args = log.error.call_args.args
        assert call_args[0] == error_message
