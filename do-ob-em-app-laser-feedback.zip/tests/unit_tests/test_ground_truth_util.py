# pylint: disable=protected-access, missing-class-docstring, missing-function-docstring
import os
import pytest
from app.feedback.ground_truth_util import get_file_path, get_file_name, load_json_from_file,\
    attempt_to_read, validate, merge_dicts_of_data_structures

class GroundTruthUtilTests():
    def test_get_file_path(self):
        root_path = os.path.join("mnt", "azure", "data-provisioning", "aal", "hall10")
        folder_name = "b9701u2"
        ground_truth_version = "202204280935"
        file_name = "b9701u2-b97-00-130_B97-00_LP_Outer_UD1_1-352-static-graph.json"
        file_path = get_file_path(root_path, folder_name, ground_truth_version, file_name)

        assert file_path == os.path.join(root_path, folder_name, ground_truth_version, file_name)

    def test_get_file_name(self):
        mould_id = "b9701u2"
        blade_revision = "b97-00"
        layer_id = "130_B97-00_LP_Outer_UD1_1-352"
        file_suffix = "static-graph"
        file_name = get_file_name(mould_id, blade_revision, layer_id, file_suffix)

        assert file_name == f"{mould_id}-{blade_revision}-{layer_id}-{file_suffix}.json"


    def test_successfully_load_json_from_file(self):
        loaded_json = load_json_from_file(os.path.join("samples", "feedback_position.json"))
        assert loaded_json["blade_id"] == "blade_id"


    def test_load_empty_json_from_file(self):
        with pytest.raises(Exception) as exc_info:
            file_path = os.path.join("samples", "empty_feedback_position.json")
            _ = load_json_from_file(file_path)

        assert exc_info.type is ValueError
        error_message = f"Can't process empty file: {file_path}"
        assert exc_info.value.args[0] == error_message


    def test_successfully_attempt_to_read(self):
        loaded_json = attempt_to_read(os.path.join("samples", "feedback_position.json"))
        assert loaded_json["blade_id"] == "blade_id"


    def test_failed_to_attempt_to_read(self,mocker):
        file_path = os.path.join("samples", "not_exists_.json")
        log = mocker.patch("app.feedback.ground_truth_util.log")

        _ = attempt_to_read(file_path)

        assert log.warning.call_count == 1
        assert "Did not found file" in log.warning.call_args.args[0]


    def test_validate_successfully(self, mocker):
        file_path = os.path.join("samples", "feedback_position.json")
        log = mocker.patch("app.feedback.ground_truth_util.log")
        mould_id = "b9702u2"
        blade_revision = "b97-00"
        file_data = {
            "blade_id": "b97-00",
            "mould_id": "b9702u2",
            "blade_revision": "b97-00",
            "plies": {
                "090_B97-00_LP_Outer_B1_1-288_001000001": {
                    "mid_point": [
                        0,
                        -2219,
                        305
                    ]
                },
                "version": "v0.0.9"
            }
        }
        validate(file_data, file_path, mould_id, blade_revision)
        assert log.info.call_count == 1
        assert f"Successfully loaded {file_path} from file" in log.info.call_args.args[0]


    def test_failed_validate(self):
        file_path = os.path.join("samples", "not_exists_.json")
        mould_id = "b9701u2"
        blade_revision = "b97-00"
        file_data = {
            "blade_id": "b97-00",
            "mould_id": "b9702u2",
            "blade_revision": "b97-00",
            "plies": {
                "090_B97-00_LP_Outer_B1_1-288_001000001": {
                    "mid_point": [
                        0,
                        -2219,
                        305
                    ]
                },
                "version": "v0.0.9"
            }
        }
        with pytest.raises(Exception) as exc_info:
            validate(file_data, file_path, mould_id, blade_revision)

        assert exc_info.type is ValueError
        error_message = f"Data in file: {file_path}, do not match given mould_id: {mould_id} " \
                        f"and blade_revision: {blade_revision} from Team Instructions."
        assert exc_info.value.args[0] == error_message

    def test_merge_dicts_of_data_structures_should_merge_two_dicts_of_dicts_with_values_of_common_keys(self):
        # GIVEN
        dict_1 = {
            "key_1": "value",
            "inner_dict_1": {
                "inner_dict_1": {"key": "value", "list": ["a", "b"]},
                "inner_dict_2": {"key": "value", "list": ["a", "b"]},
                "inner_dict_3": {"key": "value", "list": ["a", "b"]},
            },
        }
        dict_2 = {
            "key_1": "value",
            "key_2": "value",
            "key_3": "value",
            "inner_dict_1": {
                "inner_dict_4": {"key": "value", "list": ["a", "b"]},
                "inner_dict_5": {"key": "value", "list": ["a", "b"]},
                "inner_dict_6": {"key": "value", "list": ["a", "b"]},
            },
            "inner_dict_2": {
                "inner_dict_1": {"key": "value", "list": ["a", "b"]},
                "inner_dict_2": {"key": "value", "list": ["a", "b"]},
                "inner_dict_3": {"key": "value", "list": ["a", "b"]},
            },
        }

        # WHEN
        result = merge_dicts_of_data_structures(dict_1, dict_2)

        # THEN
        assert result == {
            "key_1": "value",
            "key_2": "value",
            "key_3": "value",
            "inner_dict_1": {
                "inner_dict_1": {"key": "value", "list": ["a", "b"]},
                "inner_dict_2": {"key": "value", "list": ["a", "b"]},
                "inner_dict_3": {"key": "value", "list": ["a", "b"]},
                "inner_dict_4": {"key": "value", "list": ["a", "b"]},
                "inner_dict_5": {"key": "value", "list": ["a", "b"]},
                "inner_dict_6": {"key": "value", "list": ["a", "b"]}
            },
            "inner_dict_2": {
                "inner_dict_1": {"key": "value", "list": ["a", "b"]},
                "inner_dict_2": {"key": "value", "list": ["a", "b"]},
                "inner_dict_3": {"key": "value", "list": ["a", "b"]},
            }
        }
