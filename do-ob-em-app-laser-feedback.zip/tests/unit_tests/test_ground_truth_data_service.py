# pylint: disable=protected-access, missing-class-docstring, missing-function-docstring
import os
import pytest
from app.feedback.team_instructions import TeamInstructions
from app.feedback.ground_truth_data_service import GroundTruthDataService


class GroundTruthDataServiceTests():
    ground_truth_data = GroundTruthDataService()

    def test_validate_team_instructions_successfully(self):
        team_instructions = TeamInstructions({
            "session": {
                "mouldId": "mould_id",
                "plyId": "P1",
                "moduleId": "em-decision-maker"
            },
            "groundTruthVersion": "latest",
            "mouldId": "mould_id",
            "bladeSn": "blade_sn",
            "bladeRevision": "blade_revision",
            "layers": [
                "layer_id_P"
            ]
        })
        self.ground_truth_data._validate_team_instructions(team_instructions)

    def test_validate_team_instructions_failed(self):
        team_instructions = TeamInstructions({
            "session": {
                "mouldId": "mould_id",
                "plyId": "P1",
                "moduleId": "em-decision-maker"
            },
            "mouldId": "mould_id",
            "bladeSn": "blade_sn",
            "bladeRevision": "blade_revision",
            "layers": [
                "layer_id_P"
            ]
        })
        with pytest.raises(Exception) as exc_info:
            self.ground_truth_data._validate_team_instructions(team_instructions)

        assert exc_info.type is ValueError
        error_message = "Team instructions requires 'ground_truth_data_version', 'blade_revision'"
        assert error_message in exc_info.value.args[0]

    def test_read_file_sucessfully(self, mocker):
        team_instructions = TeamInstructions({
            "session": {
                "mouldId": "mould_id",
                "plyId": "P1",
                "moduleId": "em-decision-maker"
            },
            "groundTruthVersion": "latest",
            "mouldId": "mould_id",
            "bladeSn": "blade_sn",
            "bladeRevision": "blade_revision",
            "layers": [
                "layer_id_P"
            ]
        })
        mocker.patch("app.feedback.ground_truth_data_service.get_file_path",
                     return_value=os.path.join("samples", "feedback_position.json"))
        self.ground_truth_data._read_files(team_instructions)

    def test_read_file_failed(self, mocker):
        team_instructions = TeamInstructions({
            "session": {
                "mouldId": "mould_id",
                "plyId": "P1",
                "moduleId": "em-decision-maker"
            },
            "groundTruthVersion": "latest",
            "mouldId": "mould_id",
            "bladeSn": "blade_sn",
            "bladeRevision": "blade_revision",
            "layers": [
                "layer_id_P"
            ]
        })
        mocker.patch("app.feedback.ground_truth_data_service.get_file_path",
                     return_value=os.path.join("samples", "feedback_position_2.json"))

        with pytest.raises(Exception) as exc_info:
            self.ground_truth_data._read_files(team_instructions)

        assert exc_info.type is ValueError
        error_message = "Failed to load"
        assert error_message in exc_info.value.args[0]

    def test_get_feedback_position(self, mocker):
        team_instructions = TeamInstructions({
            "session": {
                "mouldId": "mould_id",
                "plyId": "P1",
                "moduleId": "em-decision-maker"
            },
            "groundTruthVersion": "latest",
            "mouldId": "mould_id",
            "bladeSn": "blade_sn",
            "bladeRevision": "blade_revision",
            "layers": [
                "layer_id_P"
            ]
        })
        mocker.patch("app.feedback.ground_truth_data_service.get_file_path",
                     return_value=os.path.join("samples", "feedback_position.json"))
        ground_truth = self.ground_truth_data.get_feedback_position(team_instructions, "layer_id_P")
        assert ground_truth.mould_id == "mould_id"
        assert ground_truth.get_mid_point("P1") == [0, -2219, 305]
