# pylint: disable=protected-access, missing-class-docstring, missing-function-docstring
from app.feedback.feedback_positions import FeedbackPositions


class FeedbackPositionsTests:
    def test_mould_id_should_return_correct_result(self, sample_feedback_positions):
        # GIVEN
        feedback_positions = FeedbackPositions(sample_feedback_positions)

        # WHEN feedback_positions.mould_id is called
        result = feedback_positions.mould_id

        # THEN correct result is returned
        assert result == sample_feedback_positions["mould_id"]

    def test_blade_revision_should_return_correct_result(self, sample_feedback_positions):
        # GIVEN
        feedback_positions = FeedbackPositions(sample_feedback_positions)

        # WHEN feedback_positions.blade_revision is called
        result = feedback_positions.blade_revision

        # THEN correct result is returned
        assert result == sample_feedback_positions["blade_revision"]

    def test_get_mid_point_should_return_correct_result_for_given_ply_id(self, sample_feedback_positions):
        # GIVEN
        ply_id = "P3"
        feedback_positions = FeedbackPositions(sample_feedback_positions)

        # WHEN feedback_positions.get_mid_point is called
        result = feedback_positions.get_mid_point(ply_id)

        # THEN correct result is returned
        assert result == sample_feedback_positions["plies"][ply_id]["mid_point"]
