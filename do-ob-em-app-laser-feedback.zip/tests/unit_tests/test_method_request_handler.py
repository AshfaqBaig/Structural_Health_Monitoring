# pylint: disable=missing-class-docstring, missing-function-docstring
import logging
from unittest.mock import MagicMock, AsyncMock
import pytest
from app.method_request_handler import MethodRequestHandler
from app.message_handler import MessageHandler
import app.config as cfg

@pytest.fixture(name="method_request_handler")
def fixture_method_request(mocker):
    message_handler = mocker.patch("app.message_handler.MessageHandler")
    return MethodRequestHandler(MagicMock(), message_handler)

@pytest.fixture(name="set_log_level_payload")
def fixture_set_log_level_payload(mocker):
    mock_request = MagicMock()
    mocker.patch.object(mock_request, "name", "set_log_level")
    mocker.patch.object(mock_request, "payload",  {"value": "DEBUG"})
    return mock_request

@pytest.fixture(name="status_log")
def fixture_set_status_log_payload(mocker):
    mock_request = MagicMock()
    mocker.patch.object(mock_request, "status_log", "ok")
    return mock_request

@pytest.fixture(name="set_payload")
def fixture_set_payload(mocker):
    mock_request = MagicMock()
    mocker.patch.object(mock_request, "name", "set_payload")
    mocker.patch.object(mock_request, "payload", {"correlation_id":"test", "custom_properties": {"test2":"test3"}, "data":"{\"metadata\": {\"session\": {\"moduleId\": \"random\"}}, \"feedback\": []}"})
    return mock_request

@pytest.mark.asyncio
async def test_set_log_level_when_different_log_level(mocker, method_request_handler, set_log_level_payload, caplog):
    mock_create_method_response = mocker.patch("app.method_request_handler.MethodResponse.create_from_method_request")
    mock_client = mocker.patch.object(method_request_handler, "module_client", new_callable=MagicMock)
    mock_send_method_response = mocker.patch.object(mock_client, "send_method_response", new_callable=AsyncMock)
    cfg.LOG_LEVEL = "ERROR"

    # RUN
    with caplog.at_level(logging.DEBUG):
        await method_request_handler.run(set_log_level_payload)

    # VERIFY
    assert mock_send_method_response.call_count == 1
    assert mock_create_method_response.call_count == 1
    assert mock_create_method_response.call_args[0][1] == 200
    assert "Method set_log_level invocation with:" in caplog.text
    assert "Updated log level to" in caplog.text
    assert cfg.LOG_LEVEL == set_log_level_payload.payload.get("value")

@pytest.mark.asyncio
async def test_set_log_level_when_same_log_level(mocker, method_request_handler, set_log_level_payload, caplog):
    mock_create_method_response = mocker.patch("app.method_request_handler.MethodResponse.create_from_method_request")
    mock_client = mocker.patch.object(method_request_handler, "module_client", new_callable=MagicMock)
    mock_send_method_response = mocker.patch.object(mock_client, "send_method_response", new_callable=AsyncMock)
    cfg.LOG_LEVEL = "DEBUG"

    # RUN
    with caplog.at_level(logging.DEBUG):
        await method_request_handler.run(set_log_level_payload)

    # VERIFY
    assert mock_send_method_response.call_count == 1
    assert mock_create_method_response.call_count == 1
    assert mock_create_method_response.call_args[0][1] == 304
    assert "Method set_log_level invocation with:" in caplog.text
    assert cfg.LOG_LEVEL == set_log_level_payload.payload.get("value")

@pytest.mark.asyncio
async def test_set_payload(mocker, method_request_handler, status_log, set_payload, caplog):
    method_request_handler = MethodRequestHandler(MagicMock(), MessageHandler(MagicMock(), MagicMock()))
    response = status_log(status_code=200)
    mock_requests_post = mocker.patch("requests.post", return_value=response)
    mock_create_method_response = mocker.patch("app.method_request_handler.MethodResponse.create_from_method_request")
    mock_client = mocker.patch.object(method_request_handler, "module_client", new_callable=MagicMock)
    mock_send_method_response = mocker.patch.object(mock_client, "send_method_response", new_callable=AsyncMock)

    # RUN
    with caplog.at_level(logging.DEBUG):
        await method_request_handler.run(set_payload)

    # VERIFY
    assert mock_send_method_response.call_count == 1
    assert mock_create_method_response.call_count == 1
    assert mock_requests_post.call_count == 1
    assert "Method set_payload invocation with:" in caplog.text
    assert "Payload is" in caplog.text
    assert "Building message with correlation_id=" in caplog.text
    assert "Forwarding projection to laser_hub" in caplog.text
    assert "Failed to forward DXF to laser hub" in caplog.text

@pytest.mark.asyncio
async def test_invalid_method(mocker, method_request_handler, caplog):
    mock_client = mocker.patch.object(method_request_handler, "module_client", new_callable=MagicMock)
    mock_send_method_response = mocker.patch.object(mock_client, "send_method_response", new_callable=AsyncMock)
    mock_create_method_response = mocker.patch("app.method_request_handler.MethodResponse.create_from_method_request")

    mock_request = MagicMock()
    mocker.patch.object(mock_request, "name", "invalid_method_name")

    # RUN
    with caplog.at_level(logging.DEBUG):
        await method_request_handler.run(mock_request)

    # VERIFY
    assert mock_send_method_response.call_count == 1
    assert mock_create_method_response.call_count == 1
    assert mock_create_method_response.call_args[0][1] == 500
    assert "Method invalid_method_name invocation with:" in caplog.text
