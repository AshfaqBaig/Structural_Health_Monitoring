# pylint: disable=protected-access, missing-module-docstring, missing-class-docstring, missing-function-docstring
import os
import json
from unittest.mock import Mock
import pytest
from app.processors.default import DefaultProcessor


class DefaultProcessorTests:

    @pytest.mark.asyncio
    async def test_success(self, mocker):
        # prepare testing subjects
        blade_layout_cache_mock = mocker.patch("app.blade_layout_cache", new_callable=Mock)

        default_processor = DefaultProcessor(blade_layout_cache_mock)

        with open("./samples/dm_payload.json", "rb") as file:
            payload = json.loads(file.read())

            dm_preprocessing_output = {
                "session": {
                    "mouldId": "mould_id",
                    "plyId": "mock_correctly_placed_ply",
                    "moduleId": "em-decision-maker"
                },
                "expiration": 600,
                "feedback": [
                    {
                        "type": "polyline",
                        "coordinates": []
                    },
                    {
                        "type": "text",
                        "coordinates": []
                    },
                    {
                        "type": "dxf-id",
                        "coordinates": []
                    }
                ],
                "feedbackLevel": "info",
                "feedbackType": "correctly-placed-plies"
            }

            request_preprocessor_mock = mocker.patch("app.processors.preprocessor.RequestPreprocessor.run",
                                                     return_value=dm_preprocessing_output["feedback"])
            shape_feedback_processor_mock = mocker.patch("app.processors.shape_feedback.LaserShapeFeedback.run",
                                                         return_value="shape")

            request_postprocessor_mock = mocker.patch("app.processors.postprocessor.ResponsePostprocessor.run",
                                                      return_value={'session': dm_preprocessing_output['session'],
                                                                    'feedbackType': 'feedbackType',
                                                                    'content': 'shapeshapedxf-id',
                                                                    'expiration': dm_preprocessing_output['expiration']
                                                                    })

            mocker.patch("app.processors.default.dm_message_preprocessing", return_value=dm_preprocessing_output)
            mocker.patch("app.feedback.ground_truth_data_service.get_file_path",
                         return_value=os.path.join("samples", "feedback_position.json"))
            # run test
            result: str = default_processor.run(payload)

            # verify
            assert result is not None
            assert result['session'] == dm_preprocessing_output['session']
            assert result['feedbackType'] is not None
            assert result['expiration'] == dm_preprocessing_output['expiration']
            assert result['content'] is not None

            request_preprocessor_mock.assert_called_once_with(dm_preprocessing_output)
            request_postprocessor_mock.assert_called_once_with(dm_preprocessing_output,
                                                               ["shape", "shape"])

            assert shape_feedback_processor_mock.call_count == 2

    def test_collect_projections(self, mocker):
        blade_layout_cache_mock = mocker.patch("app.blade_layout_cache", new_callable=Mock)
        default_processor = DefaultProcessor(blade_layout_cache_mock)
        feedback_list = [
            {
                "type": "polyline",
                "coordinates": [[1, 1, 102], [201, 1, 102], [101, 1, 202], [101, 1, 2]],
            },
            {
                "type": "contour-6-lines",
                "dxfId": "dxf_id_U",
                "dxfPlyId": "dxf_ply_id_U2"
            },
            {
                "type": "contour-4-lines",
                "dxfId": "dxf_id_U",
                "dxfPlyId": "dxf_ply_id_U2"
            },
            {
                "type": "text",
                "text": "X123",
                "position": [1, 1, 2],
            }
        ]
        projections = default_processor._collect_projections(feedback_list)
        assert len(projections) == 4
