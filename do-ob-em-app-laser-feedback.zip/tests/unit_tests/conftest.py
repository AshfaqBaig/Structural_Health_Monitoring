# pylint: disable=protected-access, missing-class-docstring, missing-function-docstring, duplicate-code
import pytest


@pytest.fixture
def sample_graph_data():
    return {
        "mould_id": "mould_id",
        "blade_revision": "blade_revision",
        "plies": {
            "P1": {
                "layer_id": "layer_id_P",
                "pallet_id": "pallet_id_P",
                "previous_plies": [],
                "next_plies": ["P2"],
                "edges_covered": [],
                "dxf_id": "dxf_id_P",
                "dxf_ply_id": "dxf_ply_id_P1",
                "edges": ["P1.1", "P1.2"]
            },
            "P2": {
                "layer_id": "layer_id_P",
                "pallet_id": "pallet_id_P",
                "previous_plies": ["P1"],
                "next_plies": ["P3"],
                "edges_covered": ["P1.2"],
                "dxf_id": "dxf_id_P",
                "dxf_ply_id": "dxf_ply_id_P2",
                "edges": ["P2.1", "P2.2"]
            },
            "P3": {
                "layer_id": "layer_id_P",
                "pallet_id": "pallet_id_P",
                "previous_plies": ["P2"],
                "next_plies": [],
                "edges_covered": ["P2.2"],
                "dxf_id": "dxf_id_P",
                "dxf_ply_id": "dxf_ply_id_P3",
                "edges": ["P3.1", "P3.2"]
            },

            "T1": {
                "layer_id": "layer_id_T",
                "pallet_id": "pallet_id_T",
                "previous_plies": ["P1", "P2"],
                "edges_covered": ["P1.1", "P2.1"],  # if covers 1.5 plies
                "dxf_id": "dxf_id_T",
                "dxf_ply_id": "dxf_ply_id_T1",
                "edges": ["T1.1", "T1.2"]
            },
            "Z1": {
                "layer_id": "layer_id_Z",
                "pallet_id": "pallet_id_Z",
                "previous_plies": [],
                "next_plies": ["Z1"],
                "edges_covered": [],
                "dxf_id": "dxf_id_Z",
                "dxf_ply_id": "dxf_ply_id_Z1",
                "edges": ["Z1.1", "Z1.2"]
            },
            "E1": {
                "layer_id": "layer_id_E",
                "pallet_id": "pallet_id_E",
                "previous_plies": [],
                "next_plies": ["E1"],
                "edges_covered": [],
                "dxf_id": "dxf_id_E",
                "dxf_ply_id": "dxf_ply_id_E1",
                "edges": ["E1.1", "E1.2"]
            },
            "L1": {
                "layer_id": "layer_id_L",
                "pallet_id": "pallet_id_L",
                "previous_plies": [],
                "next_plies": ["L1"],
                "edges_covered": [],
                "dxf_id": "dxf_id_L",
                "dxf_ply_id": "dxf_ply_id_L1",
                "edges": ["L1.1", "L1.2"]
            },
            "PH1": {
                "layer_id": "layer_id_PH",
                "pallet_id": "pallet_id_PH",
                "previous_plies": [],
                "next_plies": ["PH2"],
                "edges_covered": [],
                "dxf_id": "dxf_id_PH",
                "dxf_ply_id": "dxf_ply_id_PH1",
                "edges": []
            },
            "PH2": {
                "layer_id": "layer_id_PH",
                "pallet_id": "pallet_id_PH",
                "previous_plies": ["PH1"],
                "next_plies": [],
                "edges_covered": ["PH1.1", "PH1.2"],
                "dxf_id": "dxf_id_PH",
                "dxf_ply_id": "dxf_ply_id_PH2",
                "edges": []
            },
        }
    }


@pytest.fixture
def sample_feedback_positions() -> dict:
    return {
        "mould_id": "mould_id",
        "blade_revision": "blade_revision",
        "plies": {
            "P1": {
                "mid_point": [1, 0, 1]
            },
            "P2": {
                "mid_point": [1, 0, 2]
            },
            "P3": {
                "mid_point": [1, 0, 3]
            },
            "T1": {
                "mid_point": [1, 1, 1]
            },
            "Z1": {
                "mid_point": [1, 0, 10]
            },
            "E1": {
                "mid_point": [1, 0, 20]
            },
            "L1": {
                "mid_point": [1, 0, 30]
            },
            "PH1": {
                "mid_point": [1, 1, 1]
            },
            "PH2": {
                "mid_point": [1, 1, 2]
            },
        }
    }
