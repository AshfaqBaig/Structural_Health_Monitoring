echo "Executing Component Tests..."
python -m pytest tests/component_tests 
if (($? != '0'))
then
  echo "Failed for Component-Test"
  rm -r Noneverifier-*.log
  rm -r .pytest_cache 2> /dev/null
  exit $?
fi