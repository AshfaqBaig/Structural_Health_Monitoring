echo "Executing Component Tests..."
python -m pytest tests/component_tests 
if (($? != '0'))
then
  echo "Failed for Component-Test"
  rm -r Noneverifier-*.log
  rm -r .pytest_cache 2> /dev/null
  exit $?
fi

echo "Executing Unit Tests..."
python -m pytest --cov-report html:htmlcov --cov=app tests/unit_tests --junitxml=result.xml 
if (($? != '0'))
then
  echo "Failed for Unit-Test"
  rm -r Noneverifier-*.log
  rm -r htmlcov
  rm -r .coverage
  rm -r result.xml
  rm -r .pytest_cache 2> /dev/null
  exit $?
fi

echo "Executing Pylint"
pylint --rcfile=.pylintrc app/ || pylint-exit --error-fail $?

# Delete Logs
rm -r Noneverifier-*.log 2> /dev/null
rm -r result.xml 2> /dev/null
rm -r .coverage 2> /dev/null
rm -r htmlcov 2> /dev/null
rm -r .pytest_cache 2> /dev/null
