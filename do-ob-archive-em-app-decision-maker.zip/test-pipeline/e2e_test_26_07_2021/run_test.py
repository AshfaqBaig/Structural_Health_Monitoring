"""
Test Case 1
"""
import asyncio
import json
from typing import Iterator
from unittest.mock import AsyncMock, patch

import pytest

import app.config as cfg
from app.decision_module import DecisionModule


@pytest.fixture
def default_session_fixture() -> Iterator[None]:
    with patch('app.storage_wrapper.StorageWrapper', new_callable=AsyncMock) as mock_storage:
        with patch('app.messaging_wrapper.MessagingWrapper', new_callable=AsyncMock) as mock_message:
            return (mock_storage, mock_message)


def test_run(default_session_fixture):
    """Inference server test case configurion goes here"""
    cfg.CAD_DATA_PATH = "./input/cad/"
    cfg.CAD_FILE_SUFFIX = ".mapping.json"
    cfg.FEEDBACK_FILE_SUFFIX = ".regions.json"

    cfg.JOB_CONFIG_PATH = "./input/jobs/"
    cfg.JOB_FILE_SUFFIX = ".json"

    cfg.ETCD_URL = "localhost:2379"
    cfg.ETCD_TTL = 600

    cfg.FEEDBACK_OUTPUT = "feedback"
    cfg.DIRECTION_OUTPUT = "directions"
    cfg.DEFAULT_OUTPUT = "default"

    mock_storage, mock_message = default_session_fixture

    processor = DecisionModule(mock_storage,
                               mock_message,
                               cad_file_suffix = cfg.CAD_FILE_SUFFIX,
                               cad_data_path = cfg.CAD_DATA_PATH,
                               job_config_path = cfg.JOB_CONFIG_PATH,
                               job_file_suffix = cfg.JOB_FILE_SUFFIX,
                               feedback_file_suffix = cfg.FEEDBACK_FILE_SUFFIX)

    ###############################################################
    ### Load messages ###
    ###############################################################

    message_1 = json.loads(open(f"./payload/payload_1.json", "rb").read())


    ###############################################################
    ### Process message 1 ###
    ###############################################################

    asyncio.run(processor.handle_inbound_message("random", message_1))
    assert processor.watchedJobs["20201020-101010-blade-190-team-1-feedback"]["currentPly"] == "202000202"

if __name__ == "__main__":
    pytest.main(["."])
