Convention:
# TBD with Grigorij if input needed

Test Case 1:
- Starting the module: Sending empty feedback to Laser Hub? Could be skipped, right?
- Current Ply remains the same after Edge-Verifcation Status "missing", why send a payload again?

Test Case 3:
- How do we terminate? Currently ply keeps sending to edge-verifcation?


Updating of jobs - how does it happen?

Ply Edge Case (Ply is in both cameras a bit.)