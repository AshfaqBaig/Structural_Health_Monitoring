echo "Executing Unit Tests..."
python -m pytest --cov-report xml:coverage.xml --cov=app tests/unit_tests --junitxml=test-result.xml 
if (($? != '0'))
then
  echo "Failed for Unit-Test"
  rm -r Noneverifier-*.log
  rm -r htmlcov
  rm -r .coverage
  rm -r result.xml
  rm -r .pytest_cache 2> /dev/null
  exit $?
fi