# Introduction

Decision maker module implements blade production assistance logic. It decides whether the next ply location be shown by laser or not. To make this decision the module gets detection results from other modules, such as ground truth based edge detection and foreign object detection.
The module has no error detection and coordinate transformation logic, instead it relies on other modules' output information and makes decisions based on objects (plies, anomalies) detected and missing.

The module supports multiple teams so one's team decisions do not affect any other team. That is based on job id's assigned to each team. It is expected that all modules include job id in their output messages to the decion module.

Decisions made by the module are sent to a dedicated output that can listened by any other module that is interested in decision information. There only one decision module per edge server handling all other modules' output.
Decision modules installed at different edge servers communicate by storing decisions and received input to the distributed etcd database available at all edge servers. Thus decision modules can make decision based on all known input for a specific job and propagate remote decicions to the local edge modules

## Build and Test

Install dependencies:

```sh
npm install
```

Run tests:

```sh
npx jest test
```

