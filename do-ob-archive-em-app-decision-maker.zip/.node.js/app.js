'use strict';
const logger = require('./src/logger');
const Transport = require('azure-iot-device-mqtt').Mqtt;
const Client = require('azure-iot-device').ModuleClient;

const DecisionModule = require('./src/decision-module');
const StorageWrapper = require('./src/storage-wrapper');
const MessagingWrapper = require('./src/messaging-wrapper');


const ETCD_URL = process.env.ETCD_URL || 'localhost:2379';
const ETCD_TTL = !Number.isNaN(Number.parseInt(process.env.ETCD_TTL)) && Number.parseInt(process.env.ETCD_TTL) || 600;
const FEEDBACK_OUTPUT = process.env.FEEDBACK_OUTPUT || 'feedback';
const DIRECTION_OUTPUT = process.env.DIRECTIONS_OUTPUT || 'directions';
const DEFAULT_OUTPUT = process.env.DEFAULT_OUTPUT || 'default';
const CAD_DATA_PATH = process.env.CAD_DATA_PATH || './';
const CAD_FILE_SUFFIX = process.env.CAD_FILE_SUFFIX || '.mapping.json';
const JOB_CONFIG_PATH = process.env.JOB_CONFIG_PATH || './';
const JOB_FILE_SUFFIX = process.env.JOB_FILE_SUFFIX || '.job.json';
const FEEDBACK_FILE_SUFFIX = process.env.FEEDBACK_FILE_SUFFIX || '.feedbacks.json';



async function app() {
  try {
    const client = await Client.fromEnvironment(Transport);
    // logger.info(`client initialised opening connection ${JSON.stringify(client)}`);

    const transportObj = await client.open();
    logger.info(`Client open, initializing other services. Transport object: ${JSON.stringify(transportObj)}`);

    client.on('error', err => handleError(err));

    const storage = new StorageWrapper(ETCD_URL, ETCD_TTL);
    const twin = await client.getTwin();

    const messaging = new MessagingWrapper(
      {
        client: client,
        twin: twin,
        feedbackOutput: FEEDBACK_OUTPUT,
        directionOutput: DIRECTION_OUTPUT,
        defaultOutput: DEFAULT_OUTPUT
      }
    );
    const decisionMaker = new DecisionModule(
      {
        storage: storage,
        messaging: messaging,
        cadPath: CAD_DATA_PATH,
        cadFileSuffix: CAD_FILE_SUFFIX,
        jobConfigPath: JOB_CONFIG_PATH,
        jobFileSuffix: JOB_FILE_SUFFIX,
        feedbackFileSuffix: FEEDBACK_FILE_SUFFIX
      }
    );

    client.on('inputMessage', getInputMessageHandler(decisionMaker));

    twin.on('properties.desired', getTwinUpdateHandler(decisionMaker));

    return client;

  } catch (err) {
    return handleError(err);
  }
}

function getInputMessageHandler(decisionMaker) {
  return async (inputName, msg) => {
    logger.debug(`Message received to input ${inputName}, content: ${printMessage(msg)}`);
    return decisionMaker.handleInboundMessage(inputName, msg).catch(err => logger.error(err));
  };
}

function getTwinUpdateHandler(decisionMaker) {
  logger.info('Setting handler for module twin');
  return async (desiredProps) => {
    logger.info(`Twin data received ${JSON.stringify(desiredProps)}`);
    return decisionMaker.handleConfigUpdate(desiredProps).catch(err => logger.error(err));
  };
}

function handleError(err) {
  logger.error(err);
  throw err;
}
function printMessage(msg) {
  const newMsg = Object.assign({}, msg);
  newMsg.data = newMsg.data.toString();
  return JSON.stringify(newMsg);
}
app();