const { createLogger, format, transports} = require('winston');
const path = require('path');

const logFormat = format.printf(info => `${info.timestamp} ${info.level} [${info.label}]: ${info.message}`);

const logger = createLogger({
    level: process.env.LOG_LEVEL || 'debug',
    format: format.combine(
        format.label({ label: require.main ? path.basename(require.main.filename): ">" }),
        format.timestamp({ format: 'YYYY-MM-DD HH:mm:ss' }),
        // Format the metadata object
        format.metadata({ fillExcept: ['message', 'level', 'timestamp', 'label'] })
      ),
    transports: [
        new transports.Console({
            format: format.combine(
              format.colorize(),
              logFormat
            )
          })
    ]
});
module.exports = logger;