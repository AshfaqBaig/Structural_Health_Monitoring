const logger = require('./logger');
const utils = require('./utils');

function extractPlies(feedback, feedbackLevel) {
    if (!feedback) {
        return [];
    }
    let filtered = feedback.filter(f => f.feedbackLevel === feedbackLevel);
    return filtered.length > 0 ? filtered[0].plies : [];
}

function cadDataToJobPlies(cadData) {
    const plies = cadData
        .filter(
            item => item.plies && item.plies.length && item.plies.length > 0
        )
        .map(item => item.plies)
        .flat()
        .map(
            item => item[0]
        )
        .sort();

    // removing duplicates
    const res = [];
    let prevPly;

    for (let index = 0; index < plies.length; index++) {
        const ply = plies[index];
        if (ply !== prevPly) {
            prevPly = ply;
            res.push(ply);
        }

    }
    return res;
}

function simplifyMapping(cadMapping, jobPlies = []) {
    const filteredPlies = {};
    const isPlyInJob = (ply) => jobPlies.includes(ply);

    for (let index = 1; index < cadMapping.length; index++) {

        const camera = cadMapping[index];

        const plies = camera.plies
            .map(ply => ply[0])
            .filter(isPlyInJob);

        if (plies.length > 0) {
            filteredPlies[camera.cam_id] = plies;
        }
    }

    return {
        dxfId: cadMapping[0].dxfId,
        cameraPlies: filteredPlies
    };

}


function getFeedbackLocations(path) {
    logger.debug(`Loading locations from file: ${path}`);
    const locations = utils.loadJsonFromFile(path) || [];
    const feedbackLocations = {};
    locations.forEach(loc => {
        feedbackLocations[loc.ply] = [loc.mid_point];
    });
    return feedbackLocations;
}

function makeX(xyz, size) {
    return [
        xyz,
        [xyz[0] + size, xyz[1], xyz[2] + size],
        [xyz[0], xyz[1], xyz[2] + size],
        [xyz[0] + size, xyz[1], xyz[2]]
    ];
}
function makeV(xyz, size) {
    return [
        [xyz[0], xyz[1], xyz[2] + size],
        [(xyz[0] + size / 2), xyz[1], xyz[2]],
        [xyz[0] + size, xyz[1], xyz[2] + size],
    ];
}

module.exports = {
    extractPlies,
    cadDataToJobPlies,
    simplifyMapping,
    getFeedbackLocations,
    makeX,
    makeV
};