const logger = require('./logger');
const uId = require('uuid').v1;
const Message = require('azure-iot-device').Message;
class MessagingWrapper {

    constructor({
        client,
        twin,
        feedbackOutput = 'default',
        directionOutput = 'default',
        defaultOutput = 'default'
    }) {

        this.client = client;
        this.twin = twin;
        this.feedbackOutput = feedbackOutput;
        this.directionOutput = directionOutput;
        this.defaultOutput = defaultOutput;
    }

    async sendFeedback(data, originalMsg) {
        const outputMsg = this.generateMessage({ data }, originalMsg);
        return this.client.sendOutputEvent(this.feedbackOutput, outputMsg, printResultFor(`Feedback sent ${JSON.stringify(outputMsg)}`));
    }
    async sendDirection(data, originalMsg) {
        const outputMsg = this.generateMessage({ data }, originalMsg);
        return this.client.sendOutputEvent(this.directionOutput, outputMsg, printResultFor(`Direction sent ${JSON.stringify(outputMsg)}`));
    }

    generateMessage(data, originalMsg) {

        var outputMsg = new Message(JSON.stringify(data));
        outputMsg.contentType = 'application/json';
        outputMsg.messageId = uId();

        const correlationId = originalMsg && originalMsg.correlationId || outputMsg.messageId;
        outputMsg.correlationId = correlationId;

        outputMsg.contentEncoding = 'utf-8';
        outputMsg.time = new Date().toISOString();
        return outputMsg;

    }

    async reportTwinProperties(property, data) {
        const twinData = {};
        twinData[property] = data;
        return this.twin.properties.reported.update(
            twinData,
            function (err) {
                if (err) throw err;
                logger.info('twin state reported');
            }
        );

    }
}

function printResultFor(op) {
    return function printResult(err, res) {
        if (err) {
            logger.error(`${op} error: ${err.toString()}`);
        }
        if (res) {
            logger.debug(`${op} status: ${res.constructor.name}`);
        }
    };
}

module.exports = MessagingWrapper;