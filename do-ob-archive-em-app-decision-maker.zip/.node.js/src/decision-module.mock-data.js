
const CADMapping = [
    {
        "dxfId": "090_B97-00_LP_Outer_B1__merged_with__130_B97-00_LP_Outer_UD1.dxf"
    },
    {
        "cam_id": "camera-1",
        "plies": [
            [
                "id-0",
                "221000221_2"
            ],
            [
                "id-1",
                "222000222_1",
                "222000222_2"
            ],
            [
                "id-2",
                "223000223_1",
                "223000223_2"
            ],
            [
                "id-3",
                "223000223_1",
                "223000223_2"
            ],
            [
                "id-8",
                "224000224_1",
                "224000224_2"
            ]
        ]
    },
    {
        "cam_id": "camera-2",
        "plies": [
            [
                "id-2",
                "224000224_2"
            ],
            [
                "id-3",
                "225000225_2"
            ],
            [
                "id-4",
                "226000226_1",
                "226000226_2"
            ],
            [
                "id-5",
                "227000227_1",
                "227000227_2"
            ],
            [
                "id-6",
                "228000228_1",
                "228000228_2"
            ],
            [
                "id-7",
                "229000229_1",
                "229000229_2"
            ],
            [
                "id-9",
                "230000230_1",
                "230000230_2"
            ]
        ]
    },
    {
        "cam_id": "camera-3",
        "plies": [
            [
                "id-7",
                "226000226_2"
            ]
        ]
    }
];

const Jobs = {
    "job-a": {
        "dxfId": "mould-10-blade-190-v1",
        "plies": ["id-0", "id-1", "id-2", "id-3", "id-4", "id-5", "id-6"],
        "startTime": "2020-11-11 10:00:00Z"
    },
    "job-b": {
        "dxfId": "mould-10-blade-190-v1",
        "plies": ["id-7", "id-8", "id-9", "id-10"],
        "startTime": "2020-11-11 11:00:00Z"
    }
};

const Sessions = {
    camera1: {
        "jobId": "job-a",
        "cameraId": "camera-1",
        "moduleId": "em-edge-detection-feedback"
    },
    camera2: {
        "jobId": "job-a",
        "cameraId": "camera-2",
        "moduleId": "em-edge-detection-feedback"
    },
    jobA: {
        "jobId": "job-a",
    }
};

const Feedbacks = {
    camera1: {
        empty: {
            session: Sessions.camera1,
            feedback: []
        },
        secondPlyMissing: {
            session: Sessions.camera1,
            feedback: [
                {
                    "type": "dxf-id",
                    "dxfId": "mould-10-blade-190-v1",
                    "plies": ["id-0"],
                    "feedbackLevel": "detected-plies"
                },
                {
                    "type": "dxf-id",
                    "dxfId": "mould-10-blade-190-v1",
                    "plies": ["id-1"],
                    "feedbackLevel": "missing-plies"
                }
            ]
        },
        thirdPlyMissing: {
            session: Sessions.camera1,
            feedback: [
                {
                    "type": "dxf-id",
                    "dxfId": "mould-10-blade-190-v1",
                    "plies": ["id-3", "id-1", "id-0"],
                    "feedbackLevel": "detected-plies"
                },
                {
                    "type": "dxf-id",
                    "dxfId": "mould-10-blade-190-v1",
                    "plies": ["id-2"],
                    "feedbackLevel": "missing-plies"
                }
            ]
        },
        complete: {
            session: Sessions.camera1,
            feedback: [
                {
                    "type": "dxf-id",
                    "dxfId": "mould-10-blade-190-v1",
                    "plies": ["id-3", "id-1", "id-0", "id-2"],
                    "feedbackLevel": "detected-plies"
                },
                {
                    "type": "dxf-id",
                    "dxfId": "mould-10-blade-190-v1",
                    "plies": [],
                    "feedbackLevel": "missing-plies"
                }
            ]
        }
    },
    camera2: {
        empty: {
            session: Sessions.camera2,
            feedback: []
        },
        camera1Overlap: {
            session: Sessions.camera2,
            feedback: [
                {
                    "type": "dxf-id",
                    "dxfId": "mould-10-blade-190-v1",
                    "plies": ["id-2"],
                    "feedbackLevel": "detected-plies"
                },
                {
                    "type": "dxf-id",
                    "dxfId": "mould-10-blade-190-v1",
                    "plies": [],
                    "feedbackLevel": "missing-plies"
                }
            ]
        },
        threePlies: {
            session: Sessions.camera2,
            feedback: [
                {
                    "type": "dxf-id",
                    "dxfId": "mould-10-blade-190-v1",
                    "plies": ["id-4", "id-3", "id-2"],
                    "feedbackLevel": "detected-plies"
                },
                {
                    "type": "dxf-id",
                    "dxfId": "mould-10-blade-190-v1",
                    "plies": [],
                    "feedbackLevel": "missing-plies"
                }
            ]
        },
        fourMissing: {
            session: Sessions.camera2,
            feedback: [
                {
                    "type": "dxf-id",
                    "dxfId": "mould-10-blade-190-v1",
                    "plies": ["id-5", "id-3", "id-2"],
                    "feedbackLevel": "detected-plies"
                },
                {
                    "type": "dxf-id",
                    "dxfId": "mould-10-blade-190-v1",
                    "plies": ["id-4"],
                    "feedbackLevel": "missing-plies"
                }
            ]
        },
        lastPly: {
            session: Sessions.camera2,
            feedback: [
                {
                    "type": "dxf-id",
                    "dxfId": "mould-10-blade-190-v1",
                    "plies": ["id-5", "id-4", "id-6", "id-3", "id-2"],
                    "feedbackLevel": "detected-plies"
                },
                {
                    "type": "dxf-id",
                    "dxfId": "mould-10-blade-190-v1",
                    "plies": [],
                    "feedbackLevel": "missing-plies"
                }
            ]
        }
    }
};

const FeedbackLocations =
    [
        {
            "ply": "id-0",
            "mid_point": [
                0,
                0,
                41821
            ]
        },
        {
            "ply": "id-1",
            "mid_point": [
                0,
                0,
                42406
            ]
        },
        {
            "ply": "id-2",
            "mid_point": [
                0,
                0,
                42991
            ]
        },
        {
            "ply": "id-3",
            "mid_point": [
                0,
                0,
                43576
            ]
        },
        {
            "ply": "id-4",
            "mid_point": [
                0,
                0,
                44162
            ]
        },
        {
            "ply": "id-5",
            "mid_point": [
                0,
                0,
                44747
            ]
        },
        {
            "ply": "id-6",
            "mid_point": [
                0,
                0,
                41683
            ]
        },
        {
            "ply": "id-7",
            "mid_point": [
                0,
                0,
                42268
            ]
        },
        {
            "ply": "id-8",
            "mid_point": [
                0,
                0,
                42854
            ]
        },
        {
            "ply": "id-9",
            "mid_point": [
                0,
                0,
                43439
            ]
        }
    ];

const FeedbackMarks = {
    error: {
        "id-1": [{ "type": "polyline", "coordinates": [[0, 0, 42406], [200, 0, 42606]], "feedbackLevel": "error" }, { "type": "polyline", "coordinates": [[0, 0, 42606], [200, 0, 42406]], "feedbackLevel": "error" }],
        "id-2": [{ "type": "polyline", "coordinates": [[0, 0, 42991], [200, 0, 43191]], "feedbackLevel": "error" }, { "type": "polyline", "coordinates": [[0, 0, 43191], [200, 0, 42991]], "feedbackLevel": "error" }],
        "id-4": [{ "type": "polyline", "coordinates": [[0, 0, 44162], [200, 0, 44362]], "feedbackLevel": "error" }, { "type": "polyline", "coordinates": [[0, 0, 44362], [200, 0, 44162]], "feedbackLevel": "error" }]
    },
    info: {
        "id-0": { "type": "polyline", "coordinates": [[0, 0, 42021], [100, 0, 41821], [200, 0, 42021]], "feedbackLevel": "info" },
        "id-1": { "type": "polyline", "coordinates": [[0, 0, 42606], [100, 0, 42406], [200, 0, 42606]], "feedbackLevel": "info" },
        "id-4": { "type": "polyline", "coordinates": [[0, 0, 44362], [100, 0, 44162], [200, 0, 44362]], "feedbackLevel": "info" }
    }
};

function feedback(feedbackLevel, plies) {
    return [
        {
            type: "dxf-id",
            dxfId: "mould-10-blade-190-v1",
            plies: plies,
            feedbackLevel: feedbackLevel
        }
    ];
}

function feedbackMarks(feedbackLevel, plies) {
    return plies.map(
        ply => FeedbackMarks[feedbackLevel][ply]
    ).flat();
}

const FeedbackScenarios = {
    startOfSession: {
        feedbacks: [
            Feedbacks.camera1.empty
        ],
        laserOut: {
            session: Sessions.camera1,
            feedback: []
        },
        directionOut: {
            session: Sessions.jobA,
            feedback: feedback('direction', ["id-0"])
        }
    },
    secondPlyMissing: {
        feedbacks: [
            Feedbacks.camera1.empty,
            Feedbacks.camera1.secondPlyMissing
        ],
        laserOut: {
            session: Sessions.camera1,
            feedback: [
                ...feedback('error', ["id-1"]),
                ...feedbackMarks('error', ["id-1"]),
                ...feedbackMarks('info', ["id-0"])

            ]
        },
        directionOut: {
            session: Sessions.jobA,
            feedback: feedback('direction', ["id-1"])
        }
    },
    thirdPlyMissing: {
        feedbacks: [
            Feedbacks.camera1.empty,
            Feedbacks.camera1.secondPlyMissing,
            Feedbacks.camera1.thirdPlyMissing
        ],
        laserOut: {
            session: Sessions.camera1,
            feedback: [
                ...feedback('error', ["id-2"]),
                ...feedbackMarks('error', ["id-2"]),
                ...feedbackMarks('info', ["id-1"])
            ]
        },
        directionOut: {
            session: Sessions.jobA,
            feedback: feedback('direction', ["id-4"])
        }
    },
    endOfCamera1: {
        feedbacks: [
            Feedbacks.camera1.empty,
            Feedbacks.camera1.secondPlyMissing,
            Feedbacks.camera1.thirdPlyMissing,
            Feedbacks.camera1.complete
        ],
        laserOut: {
            session: Sessions.camera1,
            feedback: []
        },
        directionOut: {
            session: Sessions.jobA,
            feedback: feedback('direction', ["id-4"])
        }
    },
    startOfSessionCopy: {
        feedbacks: [
            Feedbacks.camera1.empty
        ],
        laserOut: {
            session: Sessions.camera1,
            feedback: []
        },
        directionOut: {
            session: Sessions.jobA,
            feedback: feedback('direction', ["id-0"])
        }
    },
    secondCameraEmpty: {
        feedbacks: [
            Feedbacks.camera1.secondPlyMissing,
            Feedbacks.camera2.empty
        ],
        laserOut: {
            session: Sessions.camera2,
            feedback: []
        },
        directionOut: {
            session: Sessions.jobA,
            feedback: feedback('direction', ["id-1"])
        }
    },
    firstCameraOverlap: {
        feedbacks: [
            Feedbacks.camera1.complete,
            Feedbacks.camera2.camera1Overlap
        ],
        laserOut: {
            session: Sessions.camera2,
            feedback: []
        },
        directionOut: {
            session: Sessions.jobA,
            feedback: feedback('direction', ["id-4"])
        }
    },
    secondCameraOneMissing: {
        feedbacks: [
            Feedbacks.camera1.complete,
            Feedbacks.camera2.fourMissing,
        ],
        laserOut: {
            session: Sessions.camera2,
            feedback: [
                ...feedback('error', ["id-4"]),
                ...feedbackMarks('error', ["id-4"])
            ]
        },
        directionOut: {
            session: Sessions.jobA,
            feedback: feedback('direction', ["id-6"])
        }
    },
    firstCameraRepeat: {
        feedbacks: [
            Feedbacks.camera1.complete,
            Feedbacks.camera2.fourMissing,
            Feedbacks.camera1.complete,
        ],
        laserOut: {
            session: Sessions.camera1,
            feedback: []
        },
        directionOut: {
            session: Sessions.jobA,
            feedback: feedback('direction', ["id-6"])
        }
    },
    allDone: {
        feedbacks: [
            Feedbacks.camera1.complete,
            Feedbacks.camera2.lastPly,
        ],
        laserOut: {
            session: Sessions.camera2,
            feedback: [...feedbackMarks('info', ["id-4"])]
        },
        directionOut: {
            session: Sessions.jobA,
            feedback: feedback('direction', ["id-6"])
        }
    },

};

module.exports = {
    CADMapping,
    Jobs,
    FeedbackScenarios,
    Feedbacks,
    FeedbackLocations
};
