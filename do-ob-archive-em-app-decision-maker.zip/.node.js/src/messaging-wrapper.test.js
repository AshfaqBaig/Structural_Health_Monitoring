const MessagingWrapper = require('./messaging-wrapper');
const Client = require('azure-iot-device').ModuleClient;
const sinon = require('sinon');

describe('messagging wrapper tests', () => {
    let wrapper;
    let client;
    beforeEach(() => {
        client = sinon.createStubInstance(Client);
        wrapper = new MessagingWrapper({ client: client, twin: null, feedbackOutput: 'feedback', directionOutput: 'direction' });
    });

    it('generateMessage should accept previous correlation id', () => {
        const data = { a: 'b' };
        const origMsg = { correlationId: 'corr' };
        const out = wrapper.generateMessage(data, origMsg);
        expect(origMsg.correlationId).toEqual(out.correlationId);
    });

    it('generateMessage should generate new correlation id', () => {
        const data = { a: 'b' };
        const out = wrapper.generateMessage({});
        expect(out.correlationId).toBeDefined();
    });

    it('generateMessage should accept objects', () => {
        const data = { a: 'b' };
        const out = wrapper.generateMessage(data);
        expect(JSON.parse(out.getData())).toEqual(data);
    });

    it('sendFeedback should wrap message into data', async () => {
        const data = { a: 'b' };
        await wrapper.sendFeedback(data);
        expect(client.sendOutputEvent.lastCall.args[0]).toEqual('feedback');
        expect(JSON.parse(client.sendOutputEvent.lastCall.args[1].getData())).toEqual({ data: data });

    });

    it('sendDirection should wrap message into data', async () => {
        const data = { feedback: 'b' };
        await wrapper.sendDirection(data);
        expect(client.sendOutputEvent.lastCall.args[0]).toEqual('direction');
        expect(JSON.parse(client.sendOutputEvent.lastCall.args[1].getData())).toEqual({ data: data });
    });

    // it('sendDirection should wrap message into data', async () => {
    //     const data = { feedback: 'b' };
    //     await wrapper.sendDirection(data);
    //     expect(client.sendOutputEvent.lastCall.args[0]).toEqual('direction');
    //     expect(JSON.parse(client.sendOutputEvent.lastCall.args[1].getData())).toEqual({ data: data });
    // });




});