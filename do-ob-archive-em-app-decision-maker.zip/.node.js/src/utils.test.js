const fs = require('fs');
const { isFileReadable, getFirstArrayItem } = require('./utils');

const sinon = require('sinon');

describe('Utils tests', () => {

    describe('misc tests', () => {

        it('isFileReadable should return true if file is readable', () => {
            sinon.stub(fs, 'accessSync').returns(true);

            expect(isFileReadable('testwrite.log')).toEqual(true);

            sinon.restore();
        });

        it('isFileReadable should return false if file is not available', () => {
            expect(isFileReadable('anyfile')).toEqual(false);
        });
    });
    describe('getFirstArrayItem tests', () => {

        const data = [
            {
                type: 'direction',
                plies: ["id-1"]
            }
        ];

        it('should return first array item', () => {
            expect(data[0]).toEqual(getFirstArrayItem(data));
        });

        it('should throw exception on null array', () => {
            expect(() => { getFirstArrayItem(); }).toThrow('array is undefined or null');
        });

        it('should throw exception on empty array', () => {
            expect(() => { getFirstArrayItem([], 'list'); }).toThrow('list should be an non-empty array');
        });
    });
});