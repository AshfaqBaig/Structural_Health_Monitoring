const fs = require('fs');
const logger = require('./logger');

function readFile(path) {
    logger.info(`Reading file ${path}`);
    const data = fs.readFileSync(path, 'utf-8');
    return data.toString();
}

function isFileReadable(path) {
    logger.info(`Checking R/O file ${path}`);
    try {
        fs.accessSync(path, fs.constants.R_OK);
        return true;
    } catch (err) {
        logger.error(`Can't read file ${path} \t ${err.message}`);
        return false;
    }
}

function loadJsonFromFile(path) {
    let json;
    if (isFileReadable(path)) {
        const fileText = readFile(path);
        try {
            json = JSON.parse(fileText);
        } catch (e) {
            logger.error(`Error parsing file ${path}: ${e.getMessage()}`);
        }
    }
    return json;
}

function getFirstArrayItem(array, itemName = 'array') {
    if (!array) {
        throw new Error(`${itemName} is undefined or null`);
    } else if (!array.length) {
        throw new Error(`${itemName} should be an non-empty array`);
    } else if (array.length > 1) {
        logger.warn(`Only first ${itemName} element is used`);
    }
    return array[0];
}


module.exports = {
    loadJsonFromFile,
    isFileReadable,
    getFirstArrayItem
};