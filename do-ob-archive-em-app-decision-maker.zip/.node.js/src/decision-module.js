const logger = require('./logger');
const utils = require('./utils');
const helper = require('./decision-helper');

const FEEDBACK_LEVELS = {
    info: "info",
    warning: "warning",
    error: "error",
    direction: "direction",
    detectedPlies: 'detected-plies',
    missingPlies: 'missing-plies'
};

class DecisionModule {

    constructor({
        storage,
        messaging,
        cadFileSuffix = '.history.json',
        cadPath = './',
        jobConfigPath = './',
        jobFileSuffix = '.job.json',
        feedbackFileSuffix = '.feedbacks.json',
        feedbackSize = 200
    }) {
        this.watchedJobs = {};
        this.storage = storage;
        this.messaging = messaging;
        this.cadFileSuffix = cadFileSuffix;
        this.cadPath = cadPath;
        this.jobConfigPath = jobConfigPath;
        this.jobFileSuffix = jobFileSuffix;
        this.feedbackFileSuffix = feedbackFileSuffix;
        this.feedbackSize = feedbackSize;
    }

    async updateJobConfig(jobs) {
        logger.debug(`updateJobConfig ${JSON.stringify(jobs)}`);
        // removing jobs dissapeared from config

        const removedJobs = Object.keys(this.watchedJobs).filter(job => !jobs[job]);
        logger.debug(`Removed jobs ${JSON.stringify(removedJobs)}`);

        const newJobs = {};
        Object.keys(jobs)
            .filter(job => !this.watchedJobs[job])
            .forEach(job => {
                newJobs[job] = jobs[job];
            });

        return this.removeJobs(removedJobs).then(() => this.addJobs(newJobs));

    }

    async addJobs(jobs) {
        logger.debug(`addJobs ${JSON.stringify(jobs)}`);
        const promises = Object.keys(jobs).map((job) => this.addJob(job, jobs[job]));
        return Promise.all(promises);
    }

    async addJob(jobId, newJob) {
        logger.debug(`addJob ${jobId} \t job json: ${JSON.stringify(newJob)}`);

        const jobFilePath = `${this.jobConfigPath}${jobId}${this.jobFileSuffix}`;

        // try to get data from a job file definition
        newJob = newJob || utils.loadJsonFromFile(jobFilePath);

        if (!newJob) {
            logger.error('Unable to add a job with no job data or a corresponding job file');
            return 'ignored';
        }

        this.watchedJobs[jobId] = Object.assign({}, newJob); // add job to job list 

        const job = this.watchedJobs[jobId];

        const feedbacks = {};
        job.feedbacks = feedbacks;

        const cadData = utils.loadJsonFromFile(`${this.cadPath}${job.dxfId}${this.cadFileSuffix}`);

        if (!cadData) {
            logger.error('Unable to add a job as no CAD data is available');
            return 'ignored';
        }

        if (!job.plies || job.plies.length == 0) {
            job.plies = helper.cadDataToJobPlies(cadData);
        }

        //removing unused plies from cadMapping to make it shorter
        job.cadMapping = helper.simplifyMapping(
            cadData,
            job.plies
        );

        // add feedback locations to the job

        job.feedbackLocations = helper.getFeedbackLocations(`${this.cadPath}${job.dxfId}${this.feedbackFileSuffix}`);

        return this.refreshFromStorage(jobId)
            .then(_ => this.storage.watchPrefix(jobId, this.getStorageUpdateListener()));
        // watch the job in data storage
        // return this.storage.watchPrefix(jobId, this.getStorageUpdateListener());
    }


    async refreshFromStorage(jobId) {
        logger.debug(`Loading feedbacks from storage for job ${jobId}`);
        // loading existing feedbacks
        const lastFeedbacks = await this.storage.getByPrefix(jobId) || {};

        const feedbackHandlers = Object.keys(lastFeedbacks).map(sessionKey => {
            const feedback = lastFeedbacks[sessionKey];
            return this.handleStorageUpdate({
                key: sessionKey,
                value: feedback
            });
        });

        // waiting for all handlers to complete
        return Promise.all(feedbackHandlers);

    }

    async removeJobs(jobs) {
        const promises = jobs.map((job) => this.removeJob(job));
        return Promise.all(promises);

    }

    async removeJob(jobId) {
        logger.debug(`removing job ${jobId}`);
        delete this.watchedJobs[jobId];
        return this.storage.unwatchPrefix(jobId);
    }

    getFeedbacks(jobId) {
        return this.watchedJobs[jobId].feedbacks;
    }

    getJobCount() {
        return Object.keys(this.watchedJobs).length;
    }
    getCadMapping(jobId) {
        return this.watchedJobs[jobId].cadMapping;
    }

    getStorageUpdateListener() {
        return (data) => this.handleStorageUpdate(data).catch(err => logger.error(err));
    }

    async handleStorageUpdate(data) {
        // if data.key matches job-id-:  then this is a direction 
        // if data.key matched job-id-<something-else> then this is a feedback
        // otherwise just ignore it

        const key = data.key.toString();
        const rawValue = data.value.toString();
        logger.debug(`New data record is received ${JSON.stringify(key)} = ${rawValue}`);

        const session = this.keyToSession(key);
        const value = JSON.parse(rawValue);

        if (!session.jobId || !this.watchedJobs[session.jobId]) {
            logger.debug(`session is ${JSON.stringify(session.jobId)}, jobs are ${JSON.stringify(this.watchedJobs[session.jobId])}`);
            return this.handleUnknownStorageVariable(key, value);
        } else if (this.isSessionDirection(session)) {
            logger.debug("direction job " + session.jobId);
            return this.handleStorageDirection(session.jobId, key, value);
        } else {
            logger.debug("feedback job " + session.jobId);
            return this.handleStorageFeedback(session.jobId, key, value);
        }
    }

    handleStorageFeedback(job, key, value) {
        // cache locally
        this.watchedJobs[job].feedbacks[key] = value;
    }

    async handleStorageDirection(job, key, feedbacks) {
        logger.debug(`Handling new direction: job is ${job}, key is ${key}, feedbacks is ${JSON.stringify(feedbacks)}`);
        // logger.debug(`Jobs are ${JSON.stringify(this.watchedJobs)}`);
        // sharing direction to local interested nodes, no caching locally, as it is transient for now

        const feedback = utils.getFirstArrayItem(feedbacks, 'directions');
        const ply = utils.getFirstArrayItem(feedback.plies, 'feedback.plies');
        // const currentPly = this.watchedJobs[job].currentPly;

        this.watchedJobs[job].currentPly = ply;

        // send direction to direction output
        return await this.messaging.sendDirection({
            session: { jobId: job },
            feedback: feedbacks
        });
    }

    handleUnknownStorageVariable(key, value) {
        logger.error(`Unknown job's message ${key} \t ${value}`);
    }


    async handleInboundMessage(_input, msg) {
        const data = msg.getData();
        logger.debug('==============================================================');
        logger.debug(`message received from ${_input} with ${data}`);

        // todo validate input message for JSON, session and feedback parts

        let dataObject = JSON.parse(data);

        if (!dataObject.data || !dataObject.data.session || !dataObject.data.session.jobId || !dataObject.data.feedback) {
            logger.error('Wrong formatted message is received');
            return 'ignored';
        }
        const session = dataObject.data.session;
        const jobId = session.jobId;
        var job = this.watchedJobs[jobId];

        if (!job) {
            logger.warn(`Trying to init yet unseen job: ${jobId}`);
            await this.addJob(jobId);
            job = this.watchedJobs[jobId];
        }

        if (!job) {
            logger.error(`Unknown job message is received: ${jobId}`);
            return 'ignored';
        }

        const sessionKey = this.createFeedbackKey(session);

        const detectedPlies = helper.extractPlies(dataObject.data.feedback, FEEDBACK_LEVELS.detectedPlies) || [];
        const missingPlies = helper.extractPlies(dataObject.data.feedback, FEEDBACK_LEVELS.missingPlies) || [];

        const feedbackMarks = this.generateFeedbackMarks(jobId, missingPlies, detectedPlies, job.currentPly);
        // const feedbackMarks = [];

        // save to storage locally
        // this.handleStorageFeedback(session.jobId, sessionKey, dataObject.data.feedback);

        // send feedback to storage so it is shared between edges
        await this.storage.putKey(
            sessionKey,
            dataObject.data.feedback);


        // calculate new direction and errors
        const nextPly = this.calculateNewDirection(jobId, detectedPlies, missingPlies);


        // exclude ply info and 
        const feedbacks = dataObject.data.feedback
            .filter(
                item => item.feedbackLevel !== FEEDBACK_LEVELS.missingPlies && item.feedbackLevel !== FEEDBACK_LEVELS.detectedPlies
            );

        // add detected errors
        if (missingPlies && missingPlies.length > 0) {
            feedbacks.push(
                {
                    type: "dxf-id",
                    dxfId: job.dxfId,
                    plies: missingPlies,
                    feedbackLevel: FEEDBACK_LEVELS.error
                }
            );
        }

        // adding feedback marks to the overall feedback list
        feedbacks.push(...feedbackMarks);

        await this.messaging.sendFeedback(
            {
                session: session,
                feedback: feedbacks
            },
            msg
        );

        // updating current ply locally
        job.currentPly = nextPly;

        // preparing direction to laser feedback
        const directionFeedbacks = [{
            type: "dxf-id",
            dxfId: job.dxfId,
            plies: [nextPly],
            feedbackLevel: FEEDBACK_LEVELS.direction
        }];

        // send direction to storage.
        const directionKey = this.createDirectionKey(session);
        this.storage.putKey(directionKey, directionFeedbacks);

        // send direction to feedback module
        this.messaging.sendFeedback(
            {
                session: this.keyToSession(directionKey),
                feedback: directionFeedbacks
            },
            msg
        );
        logger.debug('==============================================================');
    }

    calculateNewDirection(jobId, detectedPlies, missingPlies) {
        const job = this.watchedJobs[jobId];
        const jobPlies = [...job.plies];
        const currentPly = job.currentPly || jobPlies[0];

        logger.debug(`Current ply is ${currentPly}`);
        logger.debug(`Job plies are ${JSON.stringify(jobPlies)}`);
        logger.debug(`Missing plies are ${missingPlies}`);
        logger.debug(`Detected plies are ${detectedPlies}`);

        let nextExpectedIndex = detectedPlies.reduce(
            (maxIndex, ply) => {
                const index = jobPlies.findIndex(item => item === ply);
                return index > maxIndex ? index : maxIndex;
            }, -1);

        // if detected index was in detected plies, then we can move it to the next ply
        nextExpectedIndex = nextExpectedIndex + 1;

        logger.debug(`Next expected index is ${nextExpectedIndex}`);

        // check id any missing ply has higher index
        nextExpectedIndex = missingPlies.reduce(
            (maxIndex, ply) => {
                const index = jobPlies.findIndex(item => item === ply);
                return index > maxIndex ? index : maxIndex;
            }, nextExpectedIndex);

        logger.debug(`Next expected index is ${nextExpectedIndex}`);

        const currentPlyIndex = jobPlies.findIndex(ply => ply === currentPly);

        let nextPlyIndex = nextExpectedIndex > currentPlyIndex ? nextExpectedIndex : currentPlyIndex;

        // just in case we reached the end of the job plies
        nextPlyIndex = nextPlyIndex >= jobPlies.length ? jobPlies.length - 1 : nextPlyIndex;

        return jobPlies[nextPlyIndex];
    }

    generateFeedbackMarks(jobId, missingPlies, detectedPlies, currentPly) {
        const feedbackLocations = this.watchedJobs[jobId].feedbackLocations;

        // adding X mark for each missing ply
        let marks = missingPlies.map(ply => {

            // there might be multiple feedback locations for each ply, creating marks for all of them
            const locations = feedbackLocations[ply] || [];
            return locations.map(loc => {
                return [
                    {
                        type: "polyline",
                        coordinates: helper.makeX(loc, this.feedbackSize).splice(0, 2),
                        feedbackLevel: "error"
                    },
                    {
                        type: "polyline",
                        coordinates: helper.makeX(loc, this.feedbackSize).splice(2),
                        feedbackLevel: "error"
                    },
                ];
            });
        });
        marks = marks.flat();
        // adding triangle mark if current ply was successfully detected
        if (detectedPlies.includes(currentPly)) {
            const locations = feedbackLocations[currentPly] || [];
            locations.forEach((loc) => {
                marks.push(
                    {
                        type: "polyline",
                        coordinates: helper.makeV(loc, this.feedbackSize),
                        feedbackLevel: "info"
                    }
                );

            });
        }
        return marks.flat();
    }
    async handleConfigUpdate(properties) {
        logger.debug(`Configuration update was received: ${JSON.stringify(properties)}`);
        const jobs = properties.jobs || {};
        await this.updateJobConfig(jobs).then(() => this.messaging.reportTwinProperties('jobs', jobs));

    }
    createFeedbackKey(session) {
        return `${session.jobId}#${session.cameraId}#${session.moduleId}`;
    }

    createDirectionKey(session) {
        return `${session.jobId}#direction`;
    }

    keyToSession(key) {
        const tokens = key.split("#");
        const session = {
            jobId: tokens[0]
        };

        if (tokens.length > 1 && tokens[1] !== 'direction') {
            session.cameraId = tokens[1];
        }
        if (tokens.length > 2) {
            session.moduleId = tokens[2];
        }
        return session;
    }

    isSessionDirection(session) {
        return !session.cameraId;
    }

}

module.exports = DecisionModule;