const DecisionModule = require('./decision-module');
const StorageWrapper = require('./storage-wrapper');
const MessagingWrapper = require('./messaging-wrapper');
const utils = require('./utils');

const { CADMapping, Jobs, Feedbacks, FeedbackScenarios, FeedbackLocations } = require('./decision-module.mock-data');

const sinon = require('sinon');

describe('Decision module suite', () => {

    it('Test should just start', () => {
        expect(true).toBe(true);
    });

    it('Decision module should exist', () => {
        expect(DecisionModule).toBeDefined();
    });

    describe('Job configuration tests', () => {
        let service;
        let storage;
        let messaging;
        let readFileMock;

        beforeEach(() => {
            storage = sinon.createStubInstance(StorageWrapper);
            readFileMock = sinon.stub(utils, "loadJsonFromFile")
                .withArgs(sinon.match(".history.json")).returns(CADMapping);
            messaging = sinon.createStubInstance(MessagingWrapper);
            service = new DecisionModule({ storage, messaging });
        });

        afterEach(() => {
            sinon.restore();
        });

        const oneJob = {
            'job-a': {}
        };

        const twoJobs = {
            'job-a': {},
            'job-b': {}
        };

        it('should register one job', async () => {
            await service.updateJobConfig(oneJob);
            expect(service.getJobCount()).toBe(1);
        });

        it('should register job via module twin', async () => {
            await service.handleConfigUpdate({ jobs: oneJob });
            expect(service.getJobCount()).toBe(1);
        });

        it('should register no jobs if empty module twin', async () => {
            await service.handleConfigUpdate({ noJobs: oneJob });
            expect(service.getJobCount()).toBe(0);
        });

        it('should start watching new jobs', async () => {
            await service.updateJobConfig(twoJobs);
            expect(service.getJobCount()).toBe(2);
        });

        it('should create a watcher in storage', async () => {
            await service.updateJobConfig(oneJob);

            expect(storage.watchPrefix.callCount).toBe(1);
            expect(storage.watchPrefix.lastCall.firstArg).toBe('job-a');
        });

        it('should not create watcher duplicates', async () => {

            await service.updateJobConfig(oneJob);
            await service.updateJobConfig(twoJobs);
            expect(service.getJobCount()).toBe(2);
            expect(storage.watchPrefix.callCount).toBe(2);
            expect(storage.watchPrefix.lastCall.firstArg).toBe('job-b');
        });

        it('should remove watchers when they dissapear from config', async () => {


            await service.updateJobConfig(twoJobs);
            await service.updateJobConfig(oneJob);

            expect(service.getJobCount()).toBe(1);

            expect(storage.unwatchPrefix.callCount).toBe(1);
            expect(storage.unwatchPrefix.lastCall.firstArg).toBe('job-b');

        });

        it('should load existing values from the storage for each new job', async () => {

            const feedbackValue = {
                'job-a#cam05#pov': '[{"type":"dxf-id","dxfId":"mould-10-blade-190-v1","plies":["221000221"],"feedbackLevel":"missing-plies"}]',
                'job-a#direction': '[{"type":"dxf-id","dxfId":"mould-10-blade-190-v1","plies":["222000222"],"feedbackLevel":"direction"}]'
            };

            // storage.getByPrefix.resolves({ fKey: feedbackValue });
            storage.getByPrefix.resolves(feedbackValue);

            await service.updateJobConfig(oneJob);
            expect(service.getFeedbacks('job-a')['job-a#cam05#pov']).toEqual(JSON.parse(feedbackValue['job-a#cam05#pov']));

            expect(storage.getByPrefix.callCount).toBe(1);
            expect(storage.getByPrefix.lastCall.firstArg).toBe('job-a');

            expect(messaging.sendDirection.callCount).toBe(1);
            expect(messaging.sendDirection.lastCall.firstArg).toEqual(
                {
                    session: { jobId: "job-a" },
                    feedback: JSON.parse(feedbackValue['job-a#direction'])
                }
            );

        });

        it('should load CAD mapping for each job', () => {

            service.addJobs(Jobs);
            // expect(readFileMock.lastCall.firstArg).toEqual(`./${Jobs["job-a"].dxfId}.history.json`);
            expect(service.getCadMapping("job-a")).toBeDefined();
            expect(service.getCadMapping("job-b")).toBeDefined();

        });

        it('should remove irrelevant plies from CAD mapping', () => {
            service.addJobs(Jobs);
            expect(service.getCadMapping("job-a").cameraPlies).toEqual(
                {
                    "camera-1": [
                        "id-0",
                        "id-1",
                        "id-2",
                        "id-3"
                    ],
                    "camera-2": [
                        "id-2",
                        "id-3",
                        "id-4",
                        "id-5",
                        "id-6"
                    ]
                }
            );
        });
        xit('should handle startTime', () => { });
    });

    describe('Session key serialisation', () => {
        let service;

        beforeEach(() => {
            service = new DecisionModule(
                {
                    storage: sinon.createStubInstance(StorageWrapper),
                    messaging: sinon.createStubInstance(MessagingWrapper)
                }
            );
        });

        afterEach(() => {
            sinon.restore();
        });
        const session1 = {
            jobId: 'job-id'
        };

        const session3 = {
            jobId: 'job-id',
            cameraId: 'camera-id',
            moduleId: 'module-id',
        };

        it('Direction key should consist only from job id', () => {
            const key = service.createDirectionKey(session3);
            expect(key).toEqual(`${session3.jobId}#direction`);
        });

        it('Direction key should use only from job id', () => {
            const key = service.createDirectionKey(session1);
            expect(key).toEqual(`${session3.jobId}#direction`);
        });

        it('Feedback key should use all three keys', () => {
            const key = service.createFeedbackKey(session3);
            expect(key).toEqual(`${session3.jobId}#${session3.cameraId}#${session3.moduleId}`);
        });

        it('Key should be converted to feedback session', () => {
            const key = service.createFeedbackKey(session3);
            const session = service.keyToSession(key);
            expect(session).toEqual(session3);
            expect(session.isDirection).toBeFalsy();
        });

        it('Key should be converted to direction session', () => {
            const key = service.createDirectionKey(session3);
            const session = service.keyToSession(key);
            expect(session.jobId).toEqual(session3.jobId);
            // expect(session.isDirection).toBe(true);
            expect(service.isSessionDirection(session)).toBeTruthy();
        });

    });

    describe('Storage message handler', () => {
        let service;
        let storage;
        let messaging;

        beforeEach(() => {
            sinon.stub(utils, "loadJsonFromFile").returns(CADMapping);
            storage = sinon.stub(new StorageWrapper());
            messaging = sinon.createStubInstance(MessagingWrapper);
            service = new DecisionModule({ storage, messaging });
        });

        afterEach(() => {
            sinon.restore();
        });

        it('handler function should call feedback handler for feedback input', async () => {

            const stub = sinon.stub(service, 'handleStorageFeedback').resolves('');

            const data = {
                key: stringToBuffer('jobId#camera-id#module-id'),
                value: stringToBuffer(JSON.stringify(Feedbacks.camera1.secondPlyMissing.feedback))
            };

            await service.updateJobConfig({ jobId: {} });
            await service.getStorageUpdateListener()(data);

            expect(stub.callCount).toBe(1);
            expect(stub.lastCall.args[0]).toEqual('jobId');
        });

        it('handler function should call direction handler for direction input', async () => {
            const JOB_ID = 'key';
            const session = { jobId: JOB_ID };
            const feedback = [{ plies: ["id-0"] }];
            const sessionKey = service.createDirectionKey(session);

            const mock = sinon.mock(service).expects('handleStorageDirection').once().withArgs(JOB_ID, sessionKey, feedback);

            const data = {
                key: stringToBuffer(sessionKey),
                value: stringToBuffer(JSON.stringify(feedback))
            };

            await service.updateJobConfig({ key: {} });
            service.handleStorageUpdate(data);

            mock.verify();

        });

        // may need to read them from the file system
        it('handler function should ignore unknown jobs feedbacks if happens', async () => {

            const spy = sinon.spy(service, 'handleUnknownStorageVariable');

            const data = {
                key: stringToBuffer('key1#direction'),
                value: stringToBuffer(JSON.stringify('value'))
            };

            await service.updateJobConfig({ key: {} });
            service.handleStorageUpdate(data);

            expect(spy.calledOnce).toBeTruthy();

        });

        it('direction handler should cache and overwrite previous values', async () => {
            await service.updateJobConfig({
                'job-a': {},
                'job-b': {}
            });

            const data1 = {
                key: stringToBuffer('job-a#camera-a#module-a'),
                value: stringToBuffer('["value-1"]')
            };
            const data2 = {
                key: stringToBuffer('job-b#camera-a#module-a'),
                value: stringToBuffer('["value-2"]')
            };
            const data3 = {
                key: stringToBuffer('job-a#camera-a#module-a'),
                value: stringToBuffer('["value-3"]')
            };

            service.handleStorageUpdate(data1);
            service.handleStorageUpdate(data2);
            service.handleStorageUpdate(data3);

            expect(service.getFeedbacks('job-a')['job-a#camera-a#module-a']).toEqual(['value-3']);
            expect(service.getFeedbacks('job-b')['job-b#camera-a#module-a']).toEqual(['value-2']);

        });

        it('direction handler should forward directions to the message to outbound listeners', async () => {
            const JOB_ID = 'key';
            const session = { jobId: JOB_ID };
            const sessionKey = service.createDirectionKey(session);

            messaging.sendDirection.resolves(true);
            const feedback = [
                {
                    type: 'direction',
                    plies: ["id-1"]
                }
            ];

            const data = {
                key: stringToBuffer(sessionKey),
                value: stringToBuffer(JSON.stringify(feedback))
            };

            await service.updateJobConfig({ key: {} });

            await service.handleStorageUpdate(data);
            expect(messaging.sendDirection.lastCall.args).toEqual(
                [
                    {
                        session: session,
                        feedback: feedback
                    }
                ]
            );
        });
    });

    describe('New inbound message handler', () => {
        let service;
        let storage;
        let messaging;
        const calculatedFeedback = "id-5";

        beforeEach(async () => {

            sinon.stub(utils, "loadJsonFromFile")
                .withArgs(sinon.match('unknown-id')).returns()
                .withArgs().returns(CADMapping);

            storage = sinon.createStubInstance(StorageWrapper);
            messaging = sinon.createStubInstance(MessagingWrapper);
            service = new DecisionModule({ storage, messaging });
            sinon.stub(service, 'calculateNewDirection').returns(calculatedFeedback);
            await service.addJobs(Jobs);
        });

        afterEach(() => {
            sinon.restore();
        });

        it('inbound message listener should exist', () => {
            expect(service.handleInboundMessage).toBeDefined();
        });

        it('inbound message should be JSON formatted and ignored when no feedback', async () => {
            const msg = {
                data: {
                    session: {
                        jobId: 'a-value'
                    },
                    b: 10,
                    c: new Date()
                }
            };
            const result = await service.handleInboundMessage('test-input', objectToMessage(msg));
            expect(result).toEqual('ignored');
        });

        it('messages without session should be ignored', async () => {
            const msg = { data: { a: 'b' } };
            const result = await service.handleInboundMessage('test-input', objectToMessage(msg));
            expect(result).toEqual('ignored');

        });

        it('messages without jobId should be ignored', async () => {
            const msg = {
                data: {
                    session: {
                        a: 'b'
                    }
                }
            };
            const result = await service.handleInboundMessage('test-input', objectToMessage(msg));
            expect(result).toEqual('ignored');

        });

        it('messages with unknown jobId should be ignored', async () => {
            const msg = {
                data: {
                    session: {
                        jobId: 'unknown-id',
                        a: 'b'
                    },
                    feedback: []

                }
            };
            const result = await service.handleInboundMessage('test-input', objectToMessage(msg));
            expect(result).toEqual('ignored');

        });


        it('non-JSON inbound messages should raise exception', async () => {
            const nonJson = '{a:B}';
            await expect(service.handleInboundMessage('test-input', stringToMessage(nonJson)))
                .rejects.toThrow('Unexpected token a in JSON');
        });

        it('incoming feedback should store feedback to store', async () => {

            const msg = objectToMessage({ data: Feedbacks.camera1.secondPlyMissing });

            await service.handleInboundMessage('test-input', msg);

            expect(storage.putKey.callCount).toBe(2);

            expect(storage.putKey.getCall(0).args).toEqual(
                [
                    "job-a#camera-1#em-edge-detection-feedback",
                    Feedbacks.camera1.secondPlyMissing.feedback

                ]
            );
        });

        it('new direction should be saved to store', async () => {
            const msg = objectToMessage({ data: Feedbacks.camera1.secondPlyMissing });

            await service.handleInboundMessage('test-input', msg);

            expect(storage.putKey.callCount).toBe(2);
            expect(storage.putKey.lastCall.args).toEqual(
                [
                    'job-a#direction',
                    [
                        {
                            type: "dxf-id",
                            dxfId: "mould-10-blade-190-v1",
                            plies: ["id-5"],
                            feedbackLevel: 'direction'
                        }
                    ]
                ]);
        });

    });

    describe('Scenario tests', () => {
        let service;
        let storage;
        let messaging;

        beforeEach(async () => {
            storage = sinon.createStubInstance(StorageWrapper);
            messaging = sinon.createStubInstance(MessagingWrapper);
            service = new DecisionModule({ storage, messaging });

            readFileMock = sinon.stub(utils, "loadJsonFromFile")
                .withArgs(sinon.match(".history.json")).returns(CADMapping)
                .withArgs(sinon.match(".feedbacks.json")).returns(FeedbackLocations);

            await service.addJobs(Jobs);
        });

        afterEach(() => {
            sinon.restore();
        });

        Object.keys(FeedbackScenarios).forEach(key => {

            it(`Scenario: ${key}`, async () => {
                const scenario = FeedbackScenarios[key];
                for (const feedback in scenario.feedbacks) {
                    await service.handleInboundMessage('test-input', objectToMessage({ data: scenario.feedbacks[feedback] }));
                }

                const callCount = messaging.sendFeedback.callCount;

                expect(scenario.feedbacks.length * 2).toEqual(callCount);

                expect(scenario.laserOut).toEqual(messaging.sendFeedback.getCall(callCount - 2).firstArg);

                expect(scenario.directionOut).toEqual(messaging.sendFeedback.lastCall.firstArg);
            });
        });
    });
});

function stringToBuffer(str) {
    return {
        toString: () => str
    };
}
function objectToMessage(obj) {
    return {
        getData: () => JSON.stringify(obj)
    };
}
function stringToMessage(str) {
    return {
        getData: () => str
    };
}
