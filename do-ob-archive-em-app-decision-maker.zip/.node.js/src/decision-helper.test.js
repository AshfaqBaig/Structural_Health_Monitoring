const { extractPlies, cadDataToJobPlies, simplifyMapping, getFeedbackLocations, makeX, makeV } = require('./decision-helper');
const utils = require('./utils');
const { CADMapping } = require('./decision-module.mock-data');
const sinon = require('sinon');

describe('Utils tests', () => {

    describe('extractPlies tests', () => {
        const feedback = [
            {
                "type": "dxf-id",
                "dxfId": "mould-10-blade-190-v1",
                "plies": ["id-0"],
                "feedbackLevel": "detected-plies"
            },
            {
                "type": "dxf-id",
                "dxfId": "mould-10-blade-190-v1",
                "plies": ["id-1"],
                "feedbackLevel": "missing-plies"
            }
        ];

        it('extractPlies should extact feedback plies based on type', () => {
            expect(["id-0"]).toEqual(extractPlies(feedback, 'detected-plies'));
        });

        it('extractPlies should extact feedback plies based on type missing', () => {
            expect(["id-1"]).toEqual(extractPlies(feedback, 'missing-plies'));
        });

        it('extractPlies should return empty array if nothing is found', () => {
            expect([]).toEqual(extractPlies(feedback, ''));
        });

        it('extractPlies should return empty array for empty feedback', () => {
            expect([]).toEqual(extractPlies([], 'missing-plies'));
        });

        it('extractPlies should return empty array for undefined', () => {
            let feed;
            expect([]).toEqual(extractPlies(feed, 'missing-plies'));
        });
    });

    describe('cadDataToJobPlies tests', () => {
        it('should generate a single list of plies out of camera list in alphabetic order', () => {
            expect([
                "id-0",
                "id-1",
                "id-2",
                "id-3",
                "id-4",
                "id-5",
                "id-6",
                "id-7",
                "id-8",
                "id-9"
            ]).toEqual(cadDataToJobPlies(CADMapping));
        });
    });

    describe('simplifyMapping tests', () => {

        it('should simplify cad data based on job plies ', () => {
            expect(
                {
                    dxfId: "090_B97-00_LP_Outer_B1__merged_with__130_B97-00_LP_Outer_UD1.dxf",
                    cameraPlies: {
                        "camera-1": [
                            "id-0",
                            "id-1",
                            "id-2",
                            "id-3"
                        ],
                        "camera-2": [
                            "id-2",
                            "id-3",
                            "id-4",
                            "id-5",
                            "id-6"
                        ]
                    }
                })
                .toEqual(
                    simplifyMapping(
                        CADMapping,
                        [
                            "id-0",
                            "id-1",
                            "id-2",
                            "id-3",
                            "id-4",
                            "id-5",
                            "id-6",
                        ]
                    )
                );
        });

    });

    describe('testing get feedbackLocations', () => {

        const feedbackLocations = [
            { "ply": "221000221", "mid_point": [0, 0, 41821] },
            { "ply": "222000222", "mid_point": [0, 0, 42406] }
        ];

        beforeEach(() => {
            sinon.stub(utils, 'loadJsonFromFile').returns(feedbackLocations);
        });

        afterEach(() => {
            sinon.restore();
        });

        it('should return map of feedbacks when file is read', () => {
            expect(getFeedbackLocations('something')).toEqual({
                "221000221": [
                    [0, 0, 41821]
                ],
                "222000222": [
                    [0, 0, 42406]
                ]
            });
        });
    });

    describe('makeN tests', () => {
        it('make X should create X figure coordinates using the starting point', () => {
            expect(makeX([10, 20, 30], 500)).toEqual(
                [
                    [10, 20, 30],
                    [510, 20, 530],
                    [10, 20, 530],
                    [510, 20, 30]
                ]);
        });

        it('make V should create V figure coordinates using the starting point', () => {
            expect(makeV([10, 20, 30], 500)).toEqual(
                [
                    [10, 20, 530],
                    [260, 20, 30],
                    [510, 20, 530]
                ]);
        });
    });

});