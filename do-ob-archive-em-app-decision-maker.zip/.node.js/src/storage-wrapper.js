const { Etcd3 } = require('etcd3');
const logger = require('./logger');

class StorageWrapper {

    constructor(etcdUrl, ttl) {
        this.client = new Etcd3({
            hosts: etcdUrl || 'localhost:2379',
        });
        this.ttl = ttl || 600; // 10 minutes - default ttl
        this.watchers = {};
        // this.lease = this.client.lease(this.ttl);
    }


    async watchPrefix(prefix, handler) {
        // we are watching for put-events with specific prefix and call "handler" in case
        const watcher = await this.client
            .watch()
            .prefix(prefix)
            .create().then(watcher => watcher.on('put', handler));

        this.watchers[prefix] = watcher;

        return watcher;
    }

    async unwatchPrefix(prefix) {
        // keep clean, unwatch prefix when done
        const watcher = this.watchers[prefix];
        if (watcher) {
            await watcher.cancel();
        }
        return watcher;
    }

    async getByPrefix(prefix) {
        // prefix : jobId
        return this.client.getAll().prefix(prefix).exec().then(
            results => results.kvs.reduce(
                (obj, kv) => {
                    obj[kv.key.toString()] = kv.value.toString();
                    return obj;
                }, {}
            )
        );
    }

    async putKey(key, value) {
        // Inserting/Updating key value in etcd
        // two types of information: feedback and direction createFeedbackKey() createDirectionKey() as "key"
        logger.info(`Put key/value ${key} \t ${JSON.stringify(value)}`);
        return this.client.put(key).value(JSON.stringify(value));

    }

}

module.exports = StorageWrapper;