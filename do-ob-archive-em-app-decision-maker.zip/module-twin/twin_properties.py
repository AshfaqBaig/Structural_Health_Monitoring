from azure.iot.hub import IoTHubRegistryManager
from azure.iot.hub.models import Twin, TwinProperties

class ModuleTwinProperties:
    """module interacts with Twin properties of IotEdgeModule"""

    def __init__(self, conn_str, device_em, payload=None):
        self.conn_str = conn_str
        self.device_em = device_em
        self.payload = payload

    def twinClient(self, device_id, module_id):
        # RegistryManager
        iothub_registry_manager = IoTHubRegistryManager(self.conn_str)
        module_twin = iothub_registry_manager.get_module_twin(
            device_id, module_id)
        print(f"\n\nSelected device: {device_id}, module_id: {module_id}")
        return module_twin, iothub_registry_manager

    def getModuleTwin(self):

        try:
            for device_id, moduleId_list in self.device_em.items():
                print(device_id, moduleId_list)
                for module_id in moduleId_list:
                    module_twin, _ = self.twinClient(
                        device_id=device_id, module_id=module_id)
                    print(
                        "Module twin properties before update-----------------------------------------------")
                    print("")
                    print("{0}".format(module_twin.properties))
        except Exception as ex:
            print("Unexpected error {0}".format(ex))
        except KeyboardInterrupt:
            print("IoTHubRegistryManager sample stopped")

    def setModuleTwin(self):

        try:
            for device_id, moduleId_list in self.device_em.items():
                print(device_id, moduleId_list)
                for module_id in moduleId_list:
                    module_twin, iothub_registry_manager = self.twinClient(
                        device_id=device_id, module_id=module_id)
                    # Update twin
                    twin_patch = Twin()
                    payload_json = self.payload
                    twin_patch.properties = TwinProperties(desired=payload_json)
                    updated_module_twin = iothub_registry_manager.update_module_twin(
                        device_id, module_id, twin_patch, module_twin.etag
                    )

                    print(
                        "Module twin properties after update-----------------------------------------------")
                    print("\n")
                    print("{0}".format(updated_module_twin.properties))

        except Exception as ex:
            print("Unexpected error {0}".format(ex))
        except KeyboardInterrupt:
            print("IoTHubRegistryManager sample stopped")
