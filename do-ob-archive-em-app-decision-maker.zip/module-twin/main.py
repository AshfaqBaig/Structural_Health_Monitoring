import logging

import mt_config as cfg
from twin_properties import ModuleTwinProperties

PROPERTIES_TO_UPDATE = {
    # Enter your PAYLOAD
    "LOG_LEVEL": "ERROR"
}

allowed_keys = ["CAD_DATA_PATH", "CAD_FILE_SUFFIX", "JOB_CONFIG_PATH", "JOB_FILE_SUFFIX", "FEEDBACK_FILE_SUFFIX", "FEEDBACK_SIZE", "LOG_LEVEL"]

log_names = list(logging._levelToName.keys())
log_values = list(logging._levelToName.values())
allowed_log_levels = set(log_names + log_values)

for key in PROPERTIES_TO_UPDATE:
    if key not in allowed_keys:
        raise Exception(f"Invalid Property {key}")
    if key == "LOG_LEVEL":
        if PROPERTIES_TO_UPDATE[key] not in allowed_log_levels:
            raise Exception(f"Invalid log level, must be in {allowed_log_levels}")

if __name__ == '__main__':
    twin_client = ModuleTwinProperties(conn_str = cfg.CONNECTION_STRING,
                                       device_em = cfg.DEVICE_EM,
                                       payload=PROPERTIES_TO_UPDATE)
    twin_client.getModuleTwin()
    twin_client.setModuleTwin()
