import os

# Needs to be IoTHub Connection String, not device connection, nor module connection string
CONNECTION_STRING = os.getenv("AZURE_CONNECTION_STRING")

# [
#   "EDDEVDVLGENOBAWE01-dev-edge-device-1",
#   "EDDEVDVLGENOBAWE01-dev-1-edge-device-1",
#   "EDDEVDVLGENOBAWE01-mvp-edge-1",
#   "EDDEVDVLGENOBAWE01-mvp-edge-2",
#   "EDDEVDVLGENOBAWE01-mvp-edge-3",
#   "EDDEVDVLGENOBAWE01-mvp-edge-4"
# ]

DEVICE_EM = {"EDDEVDVLGENOBAWE01-dev-edge-device-1": ["decision-maker"]}
