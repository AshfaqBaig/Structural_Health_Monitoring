#####################################################################
#####################################################################
# decision_module     
        # #-----Adding CAD data------------------------------------------------------
        # cad_data_filepath = os.path.join(self.cad_data_path, job.get('dxfId', "undefined") + self.cad_file_suffix)
        # logger.debug(f"Attempting to load CAD DATA from {cad_data_filepath}")
        # cad_data = load_json_from_file(cad_data_filepath)

        # if cad_data is None:
        #     logger.error(f"Unable to add job {jobId} since CAD DATA is missing.")
        #     return "ignored"

        # #-----Get the ply order----------------------------------------------------
        # # Get plies from CAD-Mapping - Only used if plies are not listed in job file
        #if 'plies' not in job or len(job['plies']) == 0:
            #job['plies'] = cad_data_to_job_plies(cad_data)

        #-----Get mapping from cam to ply------------------------------------------
        #job['cadMapping'] = simplify_mapping(cad_data, job['plies'])

#####################################################################
#####################################################################
# test_decision_module
    # @pytest.mark.asyncio
    # @patch('app.decision_module.load_json_from_file', mock_loadJsonFromFile)
    # async def test_job_config_IX():
    #     with patch('app.storage_wrapper.StorageWrapper', new_callable=AsyncMock) as mock_storage:
    #         with patch('app.messaging_wrapper.MessagingWrapper', new_callable=AsyncMock) as mock_message:
    #             service = app.decision_module.DecisionModule(mock_storage, mock_message)

    #             ###################################################################
    #             # should load CAD mapping for each job
    #             ###################################################################
    #             await service.add_jobs(deepcopy(JOBS))
    #             assert service.get_cad_mapping("job-a")
    #             assert service.get_cad_mapping("job-b")

    # @pytest.mark.asyncio
    # @patch('app.decision_module.load_json_from_file', mock_loadJsonFromFile)
    # async def test_job_config_X():
    #     with patch('app.storage_wrapper.StorageWrapper', new_callable=AsyncMock) as mock_storage:
    #         with patch('app.messaging_wrapper.MessagingWrapper', new_callable=AsyncMock) as mock_message:
    #             service = app.decision_module.DecisionModule(mock_storage, mock_message)

    #             ###################################################################
    #             # should remove irrelevant plies from CAD mapping
    #             ###################################################################
    #             await service.add_jobs(deepcopy(JOBS))
    #             expected = {
    #                     "camera-1": [
    #                         "id-0",
    #                         "id-1",
    #                         "id-2",
    #                         "id-3"
    #                     ],
    #                     "camera-2": [
    #                         "id-2",
    #                         "id-3",
    #                         "id-4",
    #                         "id-5",
    #                         "id-6"
    #                     ]
    #                 }
    #             assert service.get_cad_mapping("job-a")["cameraPlies"] == expected

#####################################################################
#####################################################################
# test_decision_helper
    # def test_cad_data_to_job_plies():
    #     # it should generate a single list of plies out of camera list in alphabetic order'
    #     expected = ["id-0",
    #                 "id-1",
    #                 "id-2",
    #                 "id-3",
    #                 "id-4",
    #                 "id-5",
    #                 "id-6",
    #                 "id-7",
    #                 "id-8",
    #                 "id-9"]
    #     assert cad_data_to_job_plies(CAD_MAPPING) == expected

    # def test_simplify_mapping():
    #     expected = {
    #                 "dxfId": "090_B97-00_LP_Outer_B1__merged_with__130_B97-00_LP_Outer_UD1.dxf",
    #                 "cameraPlies": {
    #                     "camera-1": ["id-0", "id-1", "id-2", "id-3"],
    #                     "camera-2": ["id-2", "id-3", "id-4", "id-5", "id-6"]
    #                 }
    #     }
    #     id_list = ["id-0", "id-1", "id-2", "id-3", "id-4", "id-5", "id-6"]
    #     # should simplify cad data based on job plies
    #     assert simplify_mapping(CAD_MAPPING, id_list) == expected

#####################################################################
#####################################################################
# decision_helper
        # def cad_data_to_job_plies(cad_data: list) -> list:
        #     """
        #     Extracts unique ply-ids from cadData and returns them alphabetically ordered
        #     ASSUMPTION: The 0-index element is the one of interest.

        #     E.g.:
        #     [
        #     ...
        #     {
        #         "cam_id": "camera-1",
        #         "plies": [
        #             ["id-0","221000221_2"],
        #             ["id-1","222000222_1","222000222_2"]
        #             ]
        #     },
        #     {
        #         "cam_id": "camera-2",
        #         "plies": [
        #             ["id-2","224000224_2"],
        #             ]
        #     }
        #     ]

        #     => ["id-0", "id-1", "id-2"]
        #     """
        #     ELEMENT_OF_INTEREST_IDX = 0

        #     ply_list      = [cad_data[ix]["plies"] for ix, _ in enumerate(cad_data) if "plies" in cad_data[ix]]
        #     ply_list_flat = more_itr.flatten(ply_list)
        #     ply_id_set    = {el[ELEMENT_OF_INTEREST_IDX] for el in ply_list_flat}
        #     ply_ids_srtd  = sorted(ply_id_set)
        #     return ply_ids_srtd

        # def simplify_mapping(cad_mapping: dict, job_plies: list) -> dict:
        #     """
        #     Returns a dictionary which maps camera-ids to job-plies for the
        #     plies given through jobPlies.
        #     With the upper example, this is returned:
        #     {
        #         "dxfId": "090_B97-00_LP_Outer_B1__merged_with__130_B97-00_LP_Outer_UD1.dxf",
        #         "cameraPlies": {
        #             "camera-1": ["id-0", "id-1"],
        #             "camera-2": ["id-2"]
        #         }
        #     }
        #     """
        #     #TODO: Refactoring...
        #     return_dict = {}
        #     return_dict['cameraPlies'] = {}
        #     for idx, elem in enumerate(cad_mapping):
        #         if "dxfId" in elem:
        #             return_dict['dxfId'] = cad_mapping[idx]["dxfId"]
        #         if "cam_id" in elem:
        #             filtered_plies = [ply[0] for ply in cad_mapping[idx]['plies'] if ply[0] in job_plies]
        #             if filtered_plies:
        #                 return_dict['cameraPlies'][cad_mapping[idx]["cam_id"]] = filtered_plies
        #     return return_dict''''''