""" MQTT-Listener taking care of interaction with IoT-Hub"""

import asyncio
import json
import logging
import time

from azure.iot.device.aio import IoTHubModuleClient

import app.config as cfg
from app.decision_module import DecisionModule
from app.messaging_wrapper import MessagingWrapper
from app.storage_wrapper import StorageWrapper

logger = logging.getLogger("decision-maker")

class MqttListener:
    """
    MQTT Listener implementation. It accepts MQTT payloads and forwards them to request processor.
    Also module twin patches are supported.
    """

    def __init__(self):
        self.module_client = IoTHubModuleClient.create_from_edge_environment()

        self.messaging_client = MessagingWrapper(client=self.module_client,
                                                 feedback_output=cfg.FEEDBACK_OUTPUT,
                                                 direction_output=cfg.DIRECTION_OUTPUT,
                                                 default_output=cfg.DEFAULT_OUTPUT)

        self.storage = StorageWrapper(cfg.ETCD_URL, cfg.ETCD_TTL)

        self.decision_module = DecisionModule(storage=self.storage,
                                              messaging=self.messaging_client,
                                              cad_data_path=cfg.CAD_DATA_PATH,
                                              cad_file_suffix=cfg.CAD_FILE_SUFFIX,
                                              job_config_path=cfg.JOB_CONFIG_PATH,
                                              job_file_suffix=cfg.JOB_FILE_SUFFIX,
                                              feedback_file_suffix=cfg.FEEDBACK_FILE_SUFFIX)

        asyncio.run(self.read_config())

    async def read_config(self):
        global logger

        twin = await self.module_client.get_twin()
        twin = twin.get('desired')
        logger.info("Configured twin properties:\n%s", twin)
        if "ETCD_URL" in twin:
            cfg.ETCD_URL = twin.get("ETCD_URL")
        if "ETCD_TTL" in twin:
            cfg.ETCD_TTL = twin.get("ETCD_TTL")
        if "FEEDBACK_OUTPUT" in twin:
            cfg.FEEDBACK_OUTPUT = twin.get("FEEDBACK_OUTPUT")
        if "DIRECTION_OUTPUT" in twin:
            cfg.DIRECTION_OUTPUT = twin.get("DIRECTION_OUTPUT")
        if "DEFAULT_OUTPUT" in twin:
            cfg.DEFAULT_OUTPUT = twin.get("DEFAULT_OUTPUT")
        if "CAD_DATA_PATH" in twin:
            cfg.CAD_DATA_PATH = twin.get("CAD_DATA_PATH")
        if "CAD_FILE_SUFFIX" in twin:
            cfg.CAD_FILE_SUFFIX = twin.get("CAD_FILE_SUFFIX")
        if "JOB_CONFIG_PATH" in twin:
            cfg.JOB_CONFIG_PATH = twin.get("JOB_CONFIG_PATH")
        if "JOB_FILE_SUFFIX" in twin:
            cfg.JOB_FILE_SUFFIX = twin.get("JOB_FILE_SUFFIX")
        if "FEEDBACK_FILE_SUFFIX" in twin:
            cfg.FEEDBACK_FILE_SUFFIX = twin.get("FEEDBACK_FILE_SUFFIX")
        if "FEEDBACK_SIZE" in twin:
            cfg.FEEDBACK_SIZE = twin.get("FEEDBACK_SIZE")
        if "LOG_LEVEL" in twin:
            cfg.LOG_LEVEL = twin.get('LOG_LEVEL')
            if logger.getEffectiveLevel() != cfg.LOG_LEVEL:
                logger = logging.getLogger('decision-maker')
                logger.setLevel(level=cfg.LOG_LEVEL)
                logger.info(f"Updated log-level to {logging.getLevelName(cfg.LOG_LEVEL)}")

    async def message_handler(self, input_message):
        """
        Default MQTT message handler
        """
        global logger

        try:
            logger.info(f"{'-'*30}    New message received    {'-'*30}")
            logger.info(f"Message received on channel: {input_message.input_name}")
            logger.info(f"Payload: {json.loads(input_message.data)}")
            await self.decision_module.handle_inbound_message(input_message.input_name, json.loads(input_message.data))
        except Exception as ex:
            # pass data further to error output
            logger.error("Error in message handler", exc_info=True)
            await self.module_client.send_message_to_output(str(ex), cfg.DEFAULT_OUTPUT)

    async def twin_patch_handler(self, patch):
        """
        Module twin patch message handler
        """

        global logger

        logger.info("New desired properties patch received: %s", patch)

        ######################################################
        # Patch Log Level
        ######################################################
        if "LOG_LEVEL" in patch:
            cfg.LOG_LEVEL = patch.get('LOG_LEVEL')
            if logger.getEffectiveLevel() != cfg.LOG_LEVEL:
                logger = logging.getLogger('decision-maker')
                logger.setLevel(level=cfg.LOG_LEVEL)
                logger.info(f"Updated log-level to {logging.getLevelName(cfg.LOG_LEVEL)}")

        ######################################################
        # Patch Decision Module variables (dangerous way)
        ######################################################
        patchable = ["CAD_DATA_PATH", "CAD_FILE_SUFFIX", "JOB_CONFIG_PATH", "JOB_FILE_SUFFIX", "FEEDBACK_FILE_SUFFIX", "FEEDBACK_SIZE"]
        for var in patchable:
            if var in patch:
                logger.debug(f"Patching {var}")
                self.decision_module.set_parameter(var, patch.get(var))

        ######################################################
        # Attempt Job Config Update
        ######################################################
        # try:
        #     await self.decision_module.handle_config_update(patch)
        # except Exception as exc:
        #     logger.critical(f"Error in Job Config Update: {exc}")

        ######################################################
        # Update Report to module twin (only "jobs"/"JOBS"...)
        ######################################################
        try:
            for key in patch:
                # Ignoring metadata entries
                if key.startswith("$"):
                    continue
                output = {}
                output[key] = patch[key]
                logger.info(f"Attempting to report to module twin with {output}")
                await self.module_client.patch_twin_reported_properties(output)
                logger.info(f"Successfully reported to module twin with {output}")
        except Exception:
            logger.error("Error in Module Twin Update", exc_info=True)

        ######################################################
        # Log away status
        ######################################################
        logger.debug("Status after Twin-Update Decision Module:")
        logger.debug(self.decision_module)
        logger.debug("Watched Jobs:")
        logger.debug(self.decision_module.watchedJobs)
        logger.debug("Status after Twin-Update Storage:")
        logger.debug(self.storage)
        logger.debug("Status after Twin-Update Messaging Client:")
        logger.debug(self.messaging_client)

    @staticmethod
    def empty_listener():
        """
        Empty listener to keep module always running
        """
        while True:
            time.sleep(600)

    async def run(self):
        """
        Entrypoint main method
        """
        try:
            await self.module_client.connect()

            self.module_client.on_message_received = self.message_handler
            self.module_client.on_twin_desired_properties_patch_received = self.twin_patch_handler

            logger.info("MQTT listener started")
            logger.info("Log level for %s logger is: %s", logger.name, logger.getEffectiveLevel())

            # Run the empty listener in the event loop
            loop = asyncio.get_event_loop()
            user_finished = loop.run_in_executor(None, self.empty_listener)
            await user_finished

            # Finally, disconnect
            await self.module_client.disconnect()

        except Exception:
            logger.exception("Unexpected error %s ", exc_info=True)
            raise
