""" Logging function """
import logging

def yield_logger(module_name):
    FORMAT = '%(asctime)s %(levelname)s %(filename)s:%(lineno)s - %(message)s'
    logging.basicConfig(format=FORMAT, level="INFO")
    logger = logging.getLogger(module_name)
    filehandle = logging.FileHandler(f"{module_name}-logs.log")
    filehandle.setLevel(logging.INFO)
    formatter = logging.Formatter(
        'info => %(asctime)s %(levelname)s %(filename)s:%(lineno)s - %(message)s'
    )
    filehandle.setFormatter(formatter)
    logger.addHandler(filehandle)
    return logger
