""" Decision module main class """

import asyncio
import json
import logging
import os

from typing import List, Union

import etcd3

from app.decision_helper import (extract_plies, get_feedback_locations)
from app.decision_helper import make_v, make_x
from app.utils import get_first_array_item, load_json_from_file
from app.config import FEEDBACK_LEVELS

logger = logging.getLogger("decision-maker")

class DecisionModule():
    def __init__(self,
                 storage,
                 messaging,
                 cad_file_suffix: str = '.mapping.json',
                 cad_data_path: str = './',
                 job_config_path: str = './',
                 job_file_suffix: str = '.job.json',
                 feedback_file_suffix: str = '.regions.json',
                 feedback_size: int = 200):
        self.watchedJobs = {} # Local job cache, contains JobIds which - under "plies" contain the order of plies
        self.storage = storage
        self.messaging = messaging
        self.cad_file_suffix = cad_file_suffix
        self.cad_data_path = cad_data_path
        self.job_config_path = job_config_path
        self.job_file_suffix = job_file_suffix
        self.feedback_file_suffix = feedback_file_suffix
        self.feedback_size = feedback_size

    def __str__(self):
        """ Representation of object with parameters """
        return str(self.__dict__)

    def set_parameter(self, var, value):
        """ Sets a decision module parameter generically (dangerous) """
        logger.warning(f"Setting {var} to {value}")
        setattr(self, var, value)

    async def update_job_config(self, job_update: dict):
        """
        If a new set of jobs (job_update) is coming, this function updates the jobs.
        Removes Jobs from self.watchedJobs not in job_update (Call)
        Adds Jobs from job_update which are not in self.watchedJobs (Call)
        """
        logger.debug(f"update_job_config {job_update}")

        if not isinstance(job_update, dict):
            raise TypeError(f"Invalid job configuration received, expected dict but got {type(job_update)}")

        #FIXME: Add reporting to module twin for added jobs (Bug)
        jobs_to_remove = [job for job in self.watchedJobs if job not in job_update]
        jobs_to_add    = {job: job_update[job] for job in job_update if job not in self.watchedJobs}

        logger.debug(f"Removed jobs: {jobs_to_remove}")

        await self.remove_jobs(jobs_to_remove)
        await self.add_jobs(jobs_to_add)

    async def add_jobs(self, jobs: dict):
        """ Calls in parallel addJob """
        logger.debug(f"Added jobs: {jobs}")
        inp = [self.add_job(job, jobs[job]) for job in jobs]
        await asyncio.gather(*inp)

    async def add_job(self, jobId: str, newJob: dict = None):
        """
        Adds a job

        The following steps are taken:
        * Checking for job-config a.k.a job-data, exit if not available
        * Adding job to Watched Jobs
        * Adding CAD data, exit if not available
        * Get the ply order, map to cameras
        * Get feedback regions
        * Watch job on storage
        """
        logger.debug(f"add_job '{jobId}'' \t with job config: {json.dumps(newJob)}")

        #-----Checking for job-config---------------------------------------------
        if not isinstance(newJob, dict):
            job_filepath = os.path.join(self.job_config_path, jobId + self.job_file_suffix)
            logger.debug(f"Attempting to load Job data from {job_filepath}")
            newJob = load_json_from_file(job_filepath)

        if newJob is None:
            logger.error(f"Unable to add job '{jobId}'' since job file is missing.")
            return "ignored"

        #-----Adding job to Watched Jobs-------------------------------------------
        self.watchedJobs[jobId] = newJob
        job = self.watchedJobs[jobId]

        job['feedbacks'] = {}

        #-----Check for ply list---------------------------------------------------
        if 'plies' not in job or len(job['plies']) == 0:
            logger.error(f"Unable to add job '{jobId}'' since ply data is missing.")
            return "ignored"

        #-----Get feedback regions-------------------------------------------------
        feedback_regions_filepath = os.path.join(self.cad_data_path, job.get('dxfId', '') + self.feedback_file_suffix)
        logger.debug(f"Attempting to load REGIONS from {feedback_regions_filepath}")
        job['feedbackLocations'] = get_feedback_locations(feedback_regions_filepath)

        await self.refresh_from_storage(jobId)
        await self.storage.watch_prefix(jobId, self.get_storage_update_listener)

    async def refresh_from_storage(self, jobId: str):
        """ Loads feedbacks from storage for a specific jobID """
        logger.debug(f"Loading FEEDBACKS from storage for job {jobId}")
        # loading existing feedbacks
        last_feedbacks = await self.storage.get_by_prefix(jobId)

        feedback_handlers = [self.handle_storage_update({"key": key, "value": last_feedbacks[key]}) for key in last_feedbacks]
        await asyncio.gather(*feedback_handlers)

    async def remove_jobs(self, jobs: list):
        """ Removes a list of jobs """
        inp = [self.remove_job(job) for job in jobs]
        if not inp:
            return []
        await asyncio.gather(*inp)

    async def remove_job(self, jobId: str) -> None:
        """ Removes a job with jobId from watched jobs """
        logger.debug(f"removing job {jobId}")
        self.watchedJobs.pop(jobId)
        await self.storage.unwatch_prefix(jobId)

    def get_feedbacks(self, jobId: str) -> dict:
        """ Return the feedback for a specific jobId """
        return self.watchedJobs[jobId]['feedbacks']

    def get_job_count(self) -> int:
        """ Returns the number of currently watched jobs """
        return len(self.watchedJobs)

    def get_storage_update_listener(self, event: etcd3.watch.WatchResponse):
        """ That is my workaround to the callback-function """
        key = event.events[0].key.decode('utf-8')
        value = event.events[0].value.decode('utf-8')
        logger.info(f"Callback event: {key}, {value}")
        data = {"key": key, "value": value}
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        future = asyncio.ensure_future(self.handle_storage_update(data)) # tasks to do
        loop.run_until_complete(future) # loop until done

    async def handle_storage_update(self, data: dict = {}):
        """ Handles Direction or Feedback Update """
        key = data.get("key", None)
        raw_value = data.get("value", None)
        logger.info(f"New data record is received {key} = {raw_value}")

        session = self.key_to_session(key)
        value = json.loads(raw_value)

        #-----Invalid case----------------------------------------------------
        if 'jobId' not in session or not session['jobId'] in self.watchedJobs:
            out_session = session.get('jobId', None)
            out_jobs = self.watchedJobs.get(session.get('jobId', None), None)
            logger.debug(f"Session is {out_session}, jobs are {out_jobs}")
            return self.handle_unknown_storage_variable(key, value)

        #-----Change in currently ply/direction-------------------------------
        if self.is_session_direction(session): # Change in current ply ID => Direction
            logger.debug(f"direction job {session['jobId']}")
            return await self.handle_storage_direction(session['jobId'], key, value)

        #-----Feedback of other kind------------------------------------------
        logger.debug(f"feedback job {session['jobId']}")
        self.handle_storage_feedback(session['jobId'], key, value)

    def handle_storage_feedback(self, job: str, key: str, value: Union[list, dict]):
        """ Caches the feedback from storage locally """
        self.watchedJobs[job]['feedbacks'][key] = value

    async def handle_storage_direction(self, job: str, key: str, feedbacks: List[dict]):
        """ Handles storage direction. TODO: Explanation... """
        logger.debug(f"Handling new direction: job is {job}, key is {key}, feedbacks is {feedbacks}")
        # sharing direction to local interested nodes, no caching locally, as it is transient for now

        feedback = get_first_array_item(feedbacks, 'directions')
        ply = get_first_array_item(feedback['plies'], 'feedback.plies')

        self.watchedJobs[job]['currentPly'] = ply

        # send direction to direction output
        return_value = {"session": { "jobId": job}, "feedback": feedbacks}
        return await self.messaging.send_direction(return_value)

    @staticmethod
    def handle_unknown_storage_variable(key: str, value: str) -> None:
        logger.error(f"Unknown job's message {key} \t {value}")

    @staticmethod
    def check_inbound_message_content(message: dict):
        """ Checks inbound message for certain keys """
        try:
            assert isinstance(message, dict)
            assert "data" in message
        except Exception:
            logger.error("Invalid message format", exc_info=True)
            return False

        message_data = message['data']

        try:
            assert message_data
            assert 'session' in message_data
            assert 'jobId' in message_data.get('session')
            assert 'feedback' in message_data
        except Exception:
            logger.error("Invalid message content", exc_info=True)
            return False
        return True

    async def handle_inbound_message(self, _input: str, message: dict):
        """
        Handles inbound messages
        _input: some arbitrary name
        msg: dict as Message-Format

        Can be feedback from anomaly detection or edge-verification
        """
        try:
            msg_source = message['data']['session']['module_id']
        except:
            msg_source = 'UNKNOWN'

        if not self.check_inbound_message_content(message):
            return "ignored"

        message_data   = message['data']
        session: str   = message['data']["session"]
        job_id: str    = message['data']["session"]["jobId"]
        job: str       = self.watchedJobs.get(job_id)

        if not job:
            logger.warning(f"Trying to initialise yet unseen job with job_id: {job_id}")
            await self.add_job(job_id)
            job = self.watchedJobs.get(job_id)

        if not job:
            logger.error(f"Unknown job message is received: {job_id}, ignoring...")
            return "ignored"

        camera_id = session["cameraId"]
        module_id = session["moduleId"]

        # Generating a feedback key
        session_key    = self.create_feedback_key(job_id, camera_id, module_id)
        detected_plies = extract_plies(message_data["feedback"], FEEDBACK_LEVELS["detectedPlies"])
        missing_plies  = extract_plies(message_data["feedback"], FEEDBACK_LEVELS["missingPlies"])
        feedback_marks = self.generate_feedback_marks(job_id, missing_plies, detected_plies, job.get("currentPly"))

        ##############################################################
        # save feedback to storage so it is shared between edge-computers
        ##############################################################
        await self.storage.put_key(session_key, message_data["feedback"])

        # calculate new direction and errors
        next_ply = self.calculate_new_direction(job_id, detected_plies, missing_plies)

        # keep only detected and missing plies
        known_plies = (FEEDBACK_LEVELS["missingPlies"], FEEDBACK_LEVELS["detectedPlies"])

        # this line grabs all feedbacks which are not missing and detected
        # e.g. Anomaly Detection or maybe crane-classification
        feedbacks = [el for el in message_data["feedback"] \
                    if el["feedbackLevel"] not in known_plies]

        # add detected errors
        if missing_plies:
            feedbacks.append(
                {
                    "type": "dxf-id",
                    "dxfId": job["dxfId"],
                    "plies": missing_plies,
                    "feedbackLevel": FEEDBACK_LEVELS["error"]
                }
            )

        # adding feedback marks to the overall feedback list
        feedbacks.extend(feedback_marks)

        ##############################################################
        # Send feedback to laser feedback (info, error)
        ##############################################################
        await self.messaging.send_feedback(
            {
                "session": session,
                "feedback": feedbacks
            },
            message_data.get('correlationId', "")
        )

        ##############################################################
        # Preparing direction to edge verification and laser-feedback
        ##############################################################
        # updating current ply locally
        job["currentPly"] = next_ply

        direction_feedbacks = [{
            "type": "dxf-id",
            "dxfId": job["dxfId"],
            "plies": [next_ply],
            "feedbackLevel": FEEDBACK_LEVELS["direction"]
        }]

        ##############################################################
        # save direction to storage so it is shared between edge-computers
        ##############################################################
        direction_key = self.create_direction_key(job_id)
        await self.storage.put_key(direction_key, direction_feedbacks)

        ##############################################################
        # Send direction to laser-feedback and edge-verification
        ##############################################################
        await self.messaging.send_feedback(
            {
                "session": self.key_to_session(direction_key),
                "feedback": direction_feedbacks
            },
            message_data.get('correlationId', "")
        )
        await self.messaging.send_direction(
            {
                "session": self.key_to_session(direction_key),
                "feedback": direction_feedbacks
            },
            message_data.get('correlationId', "")
        )        
        logger.info("="*70)

    def calculate_new_direction(self, jobId: str, detected_plies: list, missing_plies: list) -> list:
        """ This function calculates the next ply """
        job = self.watchedJobs[jobId]
        job_plies = job['plies']

        # In the first message, currently ply might not be set
        # Then we just take the first ply from jobs: jobPlies[0]
        current_ply = job.get("currentPly", None) or job_plies[0]

        logger.debug("#"*100)
        logger.debug(f"calculate_new_direction -> Current ply is {current_ply}")
        logger.debug(f"calculate_new_direction -> Job plies are {job_plies}")
        logger.debug(f"calculate_new_direction -> Missing plies are {missing_plies}")
        logger.debug(f"calculate_new_direction -> Detected plies are {detected_plies}")

        # Getting (max) index of current ply in detected plies
        if not detected_plies:
            next_expctd_idx = -1
        else:
            next_expctd_idx = max([job_plies.index(ply) for ply in detected_plies])

        # if detected index was in detected plies, then we can move it to the next ply
        next_expctd_idx = next_expctd_idx + 1

        # Getting (max) index of current ply in detected plies
        if not missing_plies:
            next_expctd_idx_2 = -1
        else:
            next_expctd_idx_2 = max([job_plies.index(ply) for ply in missing_plies])

        # check id any missing ply has higher index
        next_expctd_idx = max(next_expctd_idx, next_expctd_idx_2)

        if not current_ply in job_plies:
            current_ply_idx = -1
        else:
            current_ply_idx = job_plies.index(current_ply)

        next_ply_idx = next_expctd_idx if next_expctd_idx > current_ply_idx else current_ply_idx

        # just in case we reached the end of the job plies
        next_ply_idx = len(job_plies) - 1 if next_ply_idx >= len(job_plies) else next_ply_idx

        logger.info(f"Current ply moves to '{job_plies[next_ply_idx]}'")
        return job_plies[next_ply_idx]

    def generate_feedback_marks(self,
                                job_id: str,
                                missing_plies: list,
                                detected_plies: list,
                                current_ply: str) -> list:
        """
        Returns Feedback Marks
        X for missingPLies
        Δ for detectedPlies
        as a concatenated list
        """
        feedback_regions = self.watchedJobs[job_id].get("feedbackLocations")

        if not feedback_regions:
            return []

        logger.debug("#"*100)
        logger.debug(f"generate_feedback_marks -> Missing plies: {missing_plies}")
        logger.debug(f"generate_feedback_marks -> Detected plies: {detected_plies}")
        logger.debug(f"generate_feedback_marks -> Current Ply: {current_ply}")

        missingmapper = lambda x:  [
                    {
                        "type": "polyline",
                        "coordinates": make_x(x, self.feedback_size)[2:],
                        "feedbackLevel": "error"
                    },
                    {
                        "type": "polyline",
                        "coordinates": make_x(x, self.feedback_size)[:2],
                        "feedbackLevel": "error"
                    },
                ]

        # adding X mark for each missing ply
        missing_marks = [missingmapper(feedback_regions[ply][0]) for ply in missing_plies]

        # Flatten the list
        if missing_marks:
            missing_marks = missing_marks[0]

        detectedmapper = lambda x:  [
                    {
                        "type": "polyline",
                        "coordinates": make_v(x, self.feedback_size),
                        "feedbackLevel": "info"
                    }
                ]

        # adding triangle mark if current ply was successfully detected
        if current_ply in detected_plies:
            detected_marks = [detectedmapper(ply) for ply in feedback_regions[current_ply]]
        else:
            detected_marks = []

        # Flatten the list
        if detected_marks:
            detected_marks = detected_marks[0]

        # Merge
        marks = missing_marks + detected_marks
        logger.debug(f"generate_feedback_marks -> marks: {marks}")
        return marks

    async def handle_config_update(self, properties: dict):
        logger.info(f"Configuration update was received: {properties}")
        if 'jobs' in properties:
            jobs = properties['jobs']
        elif 'JOBS' in properties:
            jobs = properties['JOBS']
        else:
            jobs = {}

        logger.debug(f"Jobs: {jobs}")
        await self.update_job_config(jobs)

    @staticmethod
    def create_feedback_key(job_id: str, camera_id: str, module_id: str) -> str:
        """ Creates a feedback key for outbound message """
        return f"{job_id}#{camera_id}#{module_id}"

    @staticmethod
    def create_direction_key(job_id: str) -> str:
        """ Creates a direction key for outbound message """
        return f"{job_id}#direction"

    @staticmethod
    def key_to_session(key: str) -> dict:
        """ Translates a #-split key into data bits for output message """
        tokens = key.split("#")
        session = {}
        session["jobId"] = tokens[0]
        if len(tokens) > 1 and tokens[1] != 'direction':
            session["cameraId"] = tokens[1]
        if len(tokens) > 2:
            session["moduleId"] = tokens[2]
        return session

    @staticmethod
    def is_session_direction(session: dict) -> bool:
        return not "cameraId" in session
