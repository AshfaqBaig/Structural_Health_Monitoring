import json
import logging

import etcd3

logger = logging.getLogger("decision-maker")

class StorageWrapper():

    def __init__(self,
                 etdc_url: str = None,
                 ttl: int = 600):
        self.etdc_url = etdc_url
        if etdc_url is None:
            self.client = etcd3.client(host="localhost")
        else:
            if ":" in etdc_url:
                host = etdc_url.split(":")[0]
                port = etdc_url.split(":")[1]
                self.client = etcd3.client(host=host, port=port)
            else:
                self.client = etcd3.client(host=etdc_url)
        self.ttl = ttl
        self.watchers = {}

        # Database info
        logger.info("ETCD-Parameters:")
        logger.info(self.client.__dict__)

        # Database connection-test
        try:
            self.client.get('foo')
            logger.info("Database connection established!")
        except ConnectionError:
            logger.error("No database connection available")
        except Exception as exc:
            logger.critical(f"Other database error: {exc}")

    def __str__(self):
        return str(self.__dict__)

    async def watch_prefix(self, prefix, handler):
        watch_id = None
        try:
            logger.debug(f"Trying to add watch callback '{handler}' for '{prefix}'")
            watch_id = self.client.add_watch_callback(prefix, callback=handler)
            logger.debug("Added watch callback sucessfully")
        except Exception as exc:
            logger.error(f"Error in adding callback {exc}")
        self.watchers[prefix] = watch_id

    async def unwatch_prefix(self, prefix):
        logger.info(f"Trying to un-watch prefix {prefix}")
        watcher = self.watchers.get(prefix, None)
        if watcher is not None:
            logger.debug(f"Un-watching prefix {prefix}")
            self.client.cancel_watch(prefix)

    async def get_by_prefix(self, prefix):
        logger.info(f"Getting by prefix '{prefix}'")
        obj = None
        try:
            obj = self.client.get_prefix(prefix)
        except Exception as exc:
            logger.error(exc)
            return {}

        try:
            return {prefix: key.decode("utf-8") for key, _ in obj}
        except Exception as exc:
            logger.error(exc)
            return {}

    async def put_key(self, key, value):
        logger.info(f"Putting key/value {key} \t {json.dumps(value)}")
        self.client.put(key, json.dumps(value))
