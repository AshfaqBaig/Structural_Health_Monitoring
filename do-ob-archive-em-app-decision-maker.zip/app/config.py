""" Config parameters """
import logging
import os

# env vars
FEEDBACK_OUTPUT      = os.environ.get("FEEDBACK_OUTPUT",        "feedback") # Module output name for feedback messages
DIRECTION_OUTPUT     = os.environ.get("DIRECTIONS_OUTPUT",      "directions") # Module output name for direction messages
DEFAULT_OUTPUT       = os.environ.get("DEFAULT_OUTPUT",         "default") # Default module output. Currently not used

# env vars overridable by module twin
CAD_DATA_PATH        = os.environ.get("CAD_DATA_PATH",          "./") # Folder to look for CAD mapping data (dxf+ range of plies)
CAD_FILE_SUFFIX      = os.environ.get("CAD_FILE_SUFFIX",        ".mapping.json") # Suffix to generate cad mapping data file name using "<CAD_DATA_PATH><job_id><CAD_FILE_SUFFIX>" pattern
JOB_CONFIG_PATH      = os.environ.get("JOB_CONFIG_PATH",        "./") # Folder to look for job descriptors
JOB_FILE_SUFFIX      = os.environ.get("JOB_FILE_SUFFIX",        ".job.json") # Suffix to generate job descriptor file name using "<JOB_CONFIG_PATH><job_id><JOB_FILE_SUFFIX>" pattern
FEEDBACK_FILE_SUFFIX = os.environ.get("FEEDBACK_FILE_SUFFIX",   ".regions.json") # Suffix to generate feedback locations file name using "<CAD_DATA_PATH><job_id><FEEDBACK_FILE_SUFFIX>" pattern
FEEDBACK_SIZE        = os.environ.get("FEEDBACK_SIZE",          None) # Feedback size

ETCD_URL  = os.environ.get("ETCD_URL", "localhost") # ETCD database url
ETCD_TTL  = os.environ.get("ETCD_TTL", 600) # TTL
LOG_LEVEL = os.environ.get("LOG_LEVEL", logging.INFO)

FEEDBACK_LEVELS = {
    # #################################################
    # this type is for informational puposes. It does not affect decision and is
    # propagated to the module output without changes
    "info": "info",
    # #################################################
    #  this type is used to point to a non-critical issue that should not stop operation
    # (i.e. a item found on a mould where no operation currently occurs). This type of
    # information does not affect decision and is propagated to the module output.
    # This type, however, might be taken into consideration in the next phases for laser colour differentiation
    "warning": "warning",
    # #################################################
    # this type corresponds to critical findings which should be resolved to continue operations
    # (i.e. a ply is misplaced). It is planned that in the future error feedback will affect decision
    # logic in a specific way. I.e: next ply location will not be shown until all errors are resolved.
    # It could also be more specific that the next ply location will not be shown until there are errors
    # in the area for the next ply. _USED_
    "error": "error",
    # #################################################
    # _USED_
    "direction": "direction",
    # #################################################
    # This type corresponds to the list of detected plies.
    # In case there are no missing plies, decision module will increase value of the next ply
    # to the maximum detected ply+1. If both detected and missing ply lists are empty,
    # decision module will take the first ply id from the corresponding job's scope. Decision module
    # logic does not decrease value of the current ply, so if calculated value for the next ply is lower
    # than current, it will keep current ply value. This helps handling feedback from multiple cameras,
    # so that only current camera affects ply number change. _USED_
    "detectedPlies": 'detected-plies',
    # #################################################
    # List of plies which were either not detected or are not in their place.
    # Decision module does not increase the next ply location until there are missing plies _USED_
    "missingPlies": 'missing-plies'
}

def get_repo_root() -> str:
    """
    Returns the absolute path to the root of the repository
    specific to the system the code is run on.
    """
    path_to_this_file = os.path.dirname(os.path.dirname(os.path.realpath(__file__)))
    return path_to_this_file
