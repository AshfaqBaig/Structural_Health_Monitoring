""" Helper functions to decision module """

import logging
from typing import Optional

from app.utils import load_json_from_file

# Set up logger
logger = logging.getLogger("decision-maker")

def extract_plies(feedback: Optional[list], feedback_level: str) -> list:
    """
    Takes a feedback list (s. Unit-test) and filters it for a specific feedbackLevel
    Returns the ply-id(s) for the filtered data.

    ASSUMPTION: Every sub-dictionary in feedback contains an overall unique
    feedbackLevel (e.g. 'missing-plies'), hence the 0th index can chosen safely.
    """
    ELEMENT_OF_INTEREST_IDX = 0

    feedback_fltrd = [el["plies"] for el in feedback if el['feedbackLevel'] == feedback_level]
    if feedback_fltrd:
        return feedback_fltrd[ELEMENT_OF_INTEREST_IDX]
    return []

def get_feedback_locations(path: str) -> dict:
    """ Loads a json of regions and arranges it differently """
    logger.debug(f"Loading REGIONS from file: {path}")
    locations = load_json_from_file(path)
    if locations is None:
        logger.debug(f"REGIONS not found at: {path}")
        return []
    feedback_locations = {}
    for idx, _ in enumerate(locations):
        feedback_locations[locations[idx]["ply"]] = [locations[idx]["mid_point"]]
    return feedback_locations

def make_x(xyz: list, size: int) -> list:
    """
    Creates X figure coordinates using the starting point
    xyz: 3-dim list (x, y, z)
    size: "font size"
    #TODO: Move this to LaserFeedback
    """
    return [
        xyz,
        [xyz[0] + size, xyz[1], xyz[2] + size],
        [xyz[0], xyz[1], xyz[2] + size],
        [xyz[0] + size, xyz[1], xyz[2]]
    ]

def make_v(xyz: list, size: int) -> list:
    """
    Creates V figure coordinates using the starting point
    xyz: 3-dim list (x, y, z)
    size: "font size"
    #TODO: Move this to LaserFeedback
    """
    return [
        [xyz[0], xyz[1], xyz[2] + size],
        [(xyz[0] + size / 2), xyz[1], xyz[2]],
        [xyz[0] + size, xyz[1], xyz[2] + size],
    ]
