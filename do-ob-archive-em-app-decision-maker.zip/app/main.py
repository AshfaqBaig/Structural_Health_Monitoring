"""
Main entrypoint module
"""
import asyncio

from app.mqtt_listener import MqttListener

from app.logger import yield_logger
logger = yield_logger("decision-maker")

if __name__ == "__main__":
    mqtt_listener = MqttListener()
    asyncio.run(mqtt_listener.run())
