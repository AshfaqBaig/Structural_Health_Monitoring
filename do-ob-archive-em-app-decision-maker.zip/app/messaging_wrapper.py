import logging
import json
import uuid

from datetime import datetime

from azure.iot.device.aio import IoTHubModuleClient

logger = logging.getLogger("decision-maker")


class MessagingWrapper():

    def __init__(self,
                 client: IoTHubModuleClient = None,
                 feedback_output: str = 'feedback',
                 direction_output: str = 'directions',
                 default_output: str = 'default'):
        self.client = client
        self.feedback_output = feedback_output
        self.direction_output = direction_output
        self.default_output = default_output

    def __str__(self):
        return str(self.__dict__)

    async def send_feedback(self, data, corr_id: str = ""):
        """ Sends a feedback message """
        output_msg = self.generate_message(data, corr_id)
        logger.debug(f"Sending {self.feedback_output} message {output_msg}")
        await self.client.send_message_to_output(json.dumps(output_msg), self.feedback_output)

    async def send_direction(self, data, corr_id: str = ""):
        """ Sends a direction message """
        output_msg = self.generate_message(data, corr_id)
        logger.debug(f"Sending {self.direction_output} message {output_msg}")
        await self.client.send_message_to_output(json.dumps(output_msg), self.direction_output)

    @staticmethod
    def generate_message(data, corr_id: str = ""):
        """ Generates a payload for a message """
        output_msg = {}
        output_msg['data'] = data
        output_msg["contentType"] = 'application/json'
        output_msg["messageId"] = str(uuid.uuid4())
        if corr_id != "":
            output_msg['correlationId'] = corr_id
        else:
            output_msg['correlationId'] = output_msg["messageId"]

        output_msg['contentEncoding'] = 'utf-8'
        output_msg['time'] = datetime.now().isoformat()
        return output_msg
