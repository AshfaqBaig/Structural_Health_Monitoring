""" Helper functions """
import json
import logging

from typing import Any

# Set up logger
logger = logging.getLogger("decision-maker")

def is_file_readable(path: str) -> bool:
    logger.info(f"Checking R/O file {path}")
    try:
        with open(path, "r") as filehandle:
            _ = filehandle.read()
        return True
    except Exception as exc:
        logger.error(exc)
        return False

def load_json_from_file(path: str) -> dict:
    if is_file_readable(path):
        try:
            with open(path, "r") as filehandle:
                data = json.loads(filehandle.read())
            return data
        except Exception as exc:
            logger.error(exc)
    return None

def get_first_array_item(array: list, item_name: str="array") -> Any:
    """ Gets the first item of `array`, itemName is just an arbitrary name """
    if not isinstance(array, list):
        raise ValueError(f"{item_name} must be of type 'list', but is {type(array)}.")
    if not array:
        raise ValueError(f"{item_name} should be an non-empty array.")
    if len(array) == 1:
        logger.warning(f"Only first {item_name} element is used.")
    return array[0]
