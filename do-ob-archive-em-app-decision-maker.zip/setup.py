import setuptools

setuptools.setup(
    name="decision-maker",
    packages=setuptools.find_packages(),
)