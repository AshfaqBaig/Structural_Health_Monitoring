echo "Executing Database Tests..."
python -m pytest tests/database_tests/*
if (($? != '0'))
then
  echo "Failed for Database-Test"
  rm -r Noneverifier-*.log 2> /dev/null
  exit $?
fi
