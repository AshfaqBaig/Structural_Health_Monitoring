echo "Executing Preproduction Tests..."
python -m pytest tests/preprod_tests 
if (($? != '0'))
then
  echo "Failed for Preproduction-Test"
  rm -r Noneverifier-*.log
  rm -r .pytest_cache 2> /dev/null
  exit $?
fi