"""
Test Case 2
"""
import asyncio
import json

from app.decision_module import DecisionModule

import app.config as cfg

TESTCASE = 3

def test_run(default_session_fixture):
    """Inference server test case configurion goes here"""
    cfg.CAD_DATA_PATH = "tests/test_resources/samples/cad/"
    cfg.CAD_FILE_SUFFIX = ".mapping.json"
    cfg.FEEDBACK_FILE_SUFFIX = ".regions.json"

    cfg.JOB_CONFIG_PATH = "tests/test_resources/samples/jobs/"
    cfg.JOB_FILE_SUFFIX = ".job.json"

    cfg.ETCD_URL = "localhost:2379"
    cfg.ETCD_TTL = 600

    cfg.FEEDBACK_OUTPUT = "feedback"
    cfg.DIRECTION_OUTPUT = "directions"
    cfg.DEFAULT_OUTPUT = "default"

    mock_storage, mock_message = default_session_fixture

    processor = DecisionModule(mock_storage,
                               mock_message,
                               cad_file_suffix = cfg.CAD_FILE_SUFFIX,
                               cad_data_path = cfg.CAD_DATA_PATH,
                               job_config_path = cfg.JOB_CONFIG_PATH,
                               job_file_suffix = cfg.JOB_FILE_SUFFIX,
                               feedback_file_suffix = cfg.FEEDBACK_FILE_SUFFIX)

    ###############################################################
    ### Load messages ###
    ###############################################################                                
    
    message_1 = json.loads(open(f"tests/component_tests/case_{TESTCASE}/payloads/payload_1.json", "rb").read())
    message_2 = json.loads(open(f"tests/component_tests/case_{TESTCASE}/payloads/payload_2.json", "rb").read())

    ###############################################################
    ### Process message 1 ###
    ###############################################################

    ### Process ###
    asyncio.run(processor.handle_inbound_message("random", message_1))

    ### Tests ###
    # test message to laser-feedback (:> No news)
    expected = []
    result = mock_message.send_feedback._mock_call_args_list[0].args[0]['feedback']
    #assert expected == result

    # test message to edge verification (:> set current ply)
    expected = [
        {
            'type': 'dxf-id',
            'dxfId': 'mould-10-blade-190-v1',
            'plies': ['id-4'],
            'feedbackLevel': 'direction'
            }
        ]
    result = mock_message.send_feedback._mock_call_args_list[1].args[0]['feedback']
    assert expected == result

    # test: number of calls
    assert mock_message.send_feedback.call_count == 2
    assert mock_storage.put_key.call_count == 2


    ###############################################################
    ### Process message 2 ###
    ###############################################################

    ### Process ###
    asyncio.run(processor.handle_inbound_message("random", message_2))

    ### Tests ###
    # test message to laser-feedback (:> id-4 is placed correctly)
    expected = [{'dxfId': 'mould-10-blade-190-v1', 'feedbackLevel': 'direction', 'plies': ['id-4'], 'type': 'dxf-id'}]
    result = mock_message.send_feedback._mock_call_args_list[1].args[0]['feedback']

    assert expected == result

    # test message to edge verification (:> set current ply)
    # TODO: Why do we send another feedback to edge-verification?
    expected = [
        {
            'type': 'dxf-id',
            'dxfId': 'mould-10-blade-190-v1',
            'plies': ['id-4'],
            'feedbackLevel': 'direction'
            }
        ]
    result = mock_message.send_feedback._mock_call_args_list[1].args[0]['feedback']
    assert expected == result

    # test: number of calls
    assert mock_message.send_feedback.call_count == 4
    assert mock_storage.put_key.call_count == 4