This case deals with the end of a job.

DM := Decision Maker
LF := Laser Feedback Module
EV := Edge Verification Module
CP := Current ply

Message 1: Payload Message from EV.
- 3/4 plies are done, DM sends nothing (now news) to LF
- DM finds next ply and sends next ply information to EV 
Message 2: Payload Message from EV
- all plies are correctly placed, DM sends Feedback to Laser
- DM also sends current ply to EV (do we need that?)
