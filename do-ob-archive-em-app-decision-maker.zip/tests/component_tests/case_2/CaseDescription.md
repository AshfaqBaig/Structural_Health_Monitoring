This case deals with anomaly detection output.

DM := Decision Maker
LF := Laser Feedback Module
EV := Edge Verification Module
CP := Current ply

Message 1: Payload Message from Anomaly Detection.
- DM sends Feedback to LF (anomaly detected)
- DM registers the new job and sets CP, which is sent to EV.
Message 2: Payload Message from EV.
- 1st ply was found by EV to be correctly placed. DM sends Info Feedback to LF.
- DM sends next ply information to EV.
Message 3: Payload Message from Anomaly Detection (Same as Message 1).
- DM sends Feedback to LF (still anomaly)
- DM sends next ply information to EV (still the same as in Message 2)