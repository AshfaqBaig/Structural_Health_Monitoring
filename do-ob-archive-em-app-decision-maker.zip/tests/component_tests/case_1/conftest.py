from typing import Iterator
from unittest.mock import patch, AsyncMock

import pytest

@pytest.fixture(scope="session", autouse=True)
def default_session_fixture() -> Iterator[None]:
    with patch('app.storage_wrapper.StorageWrapper', new_callable=AsyncMock) as mock_storage:
        with patch('app.messaging_wrapper.MessagingWrapper', new_callable=AsyncMock) as mock_message:
            return (mock_storage, mock_message)
