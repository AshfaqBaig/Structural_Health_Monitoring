This cases deals with the standard case.

DM := Decision Module
LF := Laser Feedback Module
EV := Edge Verification Module
CP := Current ply

Message 1: Payload Message from EV
- DM sends empty feedback to LF
- DM registers the new job and sets CP, which is sent to EV.
Message 2: Payload Message from EV.
- 1st ply was found by EV to be wrongly placed. DM sends Error Feedback to LF.
- DM sends CP information to EV (Note: superfluous, actually).
Message 3: Payload Message from EV.
- 1st ply was found by EV to be correctly placed. DM sends Info Feedback to LF.
- DM finds next ply and sends next ply information to EV 

