import json

from copy import deepcopy
from unittest.mock import patch, AsyncMock

import pytest

import app.decision_module
from app.messaging_wrapper import MessagingWrapper
from app.utils import load_json_from_file
from tests.test_resources.mock_data.Jobs import JOBS
from tests.test_resources.mock_data.CADMapping import CAD_MAPPING

def mock_loadJsonFromFile(path=""):
    if ".history.json" in path:
        return CAD_MAPPING
    else:
        return load_json_from_file(path)

@pytest.fixture()
def messaging():
    messaging_instance = MessagingWrapper()
    return messaging_instance

@pytest.fixture(autouse=True)
def jobs():
    job_list = {
        "one_job" : {
                'job-a': {"plies": ["232000232"]}
            },
        "two_jobs" : {
                'job-a': {"plies": ["232000232"]},
                'job-b': {"plies": ["232000232"]}
            }
    }
    return job_list

@pytest.mark.asyncio
@patch('app.decision_module.load_json_from_file', mock_loadJsonFromFile)
async def test_job_config_I(jobs):
    with patch('app.storage_wrapper.StorageWrapper', new_callable=AsyncMock) as mock_storage:
        with patch('app.messaging_wrapper.MessagingWrapper', new_callable=AsyncMock) as mock_message:
            service = app.decision_module.DecisionModule(mock_storage, mock_message)
            one_job = jobs["one_job"]

            # ###################################################################
            # # should register one job
            # ###################################################################
            await service.update_job_config(one_job)
            assert service.get_job_count() == 1

@pytest.mark.asyncio
@patch('app.decision_module.load_json_from_file', mock_loadJsonFromFile)
async def test_job_config_II(jobs):
    with patch('app.storage_wrapper.StorageWrapper', new_callable=AsyncMock) as mock_storage:
        with patch('app.messaging_wrapper.MessagingWrapper', new_callable=AsyncMock) as mock_message:
            service = app.decision_module.DecisionModule(mock_storage, mock_message)
            one_job = jobs["one_job"]

            ###################################################################
            # should register job via module twin
            ###################################################################
            await service.handle_config_update({"jobs": one_job})
            assert service.get_job_count() == 1

@pytest.mark.asyncio
@patch('app.decision_module.load_json_from_file', mock_loadJsonFromFile)
async def test_job_config_III(jobs):
    with patch('app.storage_wrapper.StorageWrapper', new_callable=AsyncMock) as mock_storage:
        with patch('app.messaging_wrapper.MessagingWrapper', new_callable=AsyncMock) as mock_message:
            service = app.decision_module.DecisionModule(mock_storage, mock_message)
            one_job = jobs["one_job"]

            ###################################################################
            # should register no jobs if empty module twin
            ###################################################################
            await service.handle_config_update({"nojobs": one_job})
            assert service.get_job_count() == 0

@pytest.mark.asyncio
@patch('app.decision_module.load_json_from_file', mock_loadJsonFromFile)
async def test_job_config_IV(jobs):
    with patch('app.storage_wrapper.StorageWrapper', new_callable=AsyncMock) as mock_storage:
        with patch('app.messaging_wrapper.MessagingWrapper', new_callable=AsyncMock) as mock_message:
            service = app.decision_module.DecisionModule(mock_storage, mock_message)
            two_jobs = jobs["two_jobs"]

            ###################################################################
            # should start watching new jobs
            ###################################################################
            await service.update_job_config(two_jobs)
            assert service.get_job_count() == 2

@pytest.mark.asyncio
@patch('app.decision_module.load_json_from_file', mock_loadJsonFromFile)
async def test_job_config_V(jobs):
    with patch('app.storage_wrapper.StorageWrapper', new_callable=AsyncMock) as mock_storage:
        with patch('app.messaging_wrapper.MessagingWrapper', new_callable=AsyncMock) as mock_message:
            service = app.decision_module.DecisionModule(mock_storage, mock_message)
            one_job = jobs["one_job"]

            ###################################################################
            # should create a watcher in storage
            ###################################################################
            await service.update_job_config(one_job)
            assert mock_storage.watch_prefix.call_count == 1
            assert mock_storage.watch_prefix.call_args.args[0] =='job-a'

@pytest.mark.asyncio
@patch('app.decision_module.load_json_from_file', mock_loadJsonFromFile)
async def test_job_config_VI(jobs):
    with patch('app.storage_wrapper.StorageWrapper', new_callable=AsyncMock) as mock_storage:
        with patch('app.messaging_wrapper.MessagingWrapper', new_callable=AsyncMock) as mock_message:
            service = app.decision_module.DecisionModule(mock_storage, mock_message)
            one_job = jobs["one_job"]
            two_jobs = jobs["two_jobs"]

            ###################################################################
            # should not create watcher duplicates
            ###################################################################
            await service.update_job_config(one_job)
            await service.update_job_config(two_jobs)

            assert service.get_job_count() == 2
            assert mock_storage.watch_prefix.call_count == 2
            assert mock_storage.watch_prefix.call_args.args[0] =='job-b'

@pytest.mark.asyncio
@patch('app.decision_module.load_json_from_file', mock_loadJsonFromFile)
async def test_job_config_VII(jobs):
    with patch('app.storage_wrapper.StorageWrapper', new_callable=AsyncMock) as mock_storage:
        with patch('app.messaging_wrapper.MessagingWrapper', new_callable=AsyncMock) as mock_message:
            service = app.decision_module.DecisionModule(mock_storage, mock_message)
            one_job = jobs["one_job"]
            two_jobs = jobs["two_jobs"]

            ###################################################################
            # should remove watchers when they dissapear from config
            ###################################################################
            await service.update_job_config(two_jobs)
            await service.update_job_config(one_job)

            assert service.get_job_count() == 1
            assert mock_storage.unwatch_prefix.call_count == 1
            assert mock_storage.unwatch_prefix.call_args.args[0] =='job-b'

@pytest.mark.asyncio
@patch('app.decision_module.load_json_from_file', mock_loadJsonFromFile)
async def test_job_config_VIII(jobs):
    with patch('app.storage_wrapper.StorageWrapper', new_callable=AsyncMock) as mock_storage:
        with patch('app.messaging_wrapper.MessagingWrapper', new_callable=AsyncMock) as mock_message:
            service = app.decision_module.DecisionModule(mock_storage, mock_message)
            one_job = jobs["one_job"]

            feedbackValue = {
                'job-a#cam05#pov': '[{"type":"dxf-id","dxfId":"mould-10-blade-190-v1","plies":["221000221"],"feedbackLevel":"missing-plies"}]',
                'job-a#direction': '[{"type":"dxf-id","dxfId":"mould-10-blade-190-v1","plies":["222000222"],"feedbackLevel":"direction"}]'
            }

            ###################################################################
            # should load existing values from the storage for each new job
            ###################################################################
            mock_storage.get_by_prefix.return_value = feedbackValue

            await service.update_job_config(one_job)
            assert service.get_feedbacks('job-a')['job-a#cam05#pov'] == json.loads(feedbackValue['job-a#cam05#pov'])

            assert mock_storage.get_by_prefix.call_count == 1
            assert mock_storage.get_by_prefix.call_args.args[0] == 'job-a'

            assert mock_message.send_direction.call_count == 1
            expected = {
                "session": { "jobId": "job-a" },
                "feedback": json.loads(feedbackValue['job-a#direction'])
            }
            assert expected == mock_message.send_direction.call_args.args[0]


@pytest.mark.asyncio
def test_session_key_serialisation():
    with patch('app.storage_wrapper.StorageWrapper', new_callable=AsyncMock) as mock_storage:
        with patch('app.messaging_wrapper.MessagingWrapper', new_callable=AsyncMock) as mock_message:
            service = app.decision_module.DecisionModule(mock_storage, mock_message)

            session1 = {"jobId": 'job-id'}
            session3 = {"jobId": 'job-id',
                        "cameraId": 'camera-id',
                        "moduleId": 'module-id'}

            ###################################################################
            # Direction key should consist only from job id
            ###################################################################
            key = service.create_direction_key(session3["jobId"])
            assert key == f"{session3['jobId']}#direction"

            ###################################################################
            # Direction key should use only from job id
            ###################################################################
            key = service.create_direction_key(session1["jobId"])
            assert key == f"{session3['jobId']}#direction"

            ###################################################################
            # Feedback key should use all three keys
            ###################################################################
            key = service.create_feedback_key(session3['jobId'], session3['cameraId'], session3['moduleId'])
            assert key == f"{session3['jobId']}#{session3['cameraId']}#{session3['moduleId']}"

            ###################################################################
            # Key should be converted to feedback session
            ###################################################################
            key = service.create_feedback_key(session3['jobId'], session3['cameraId'], session3['moduleId'])
            session = service.key_to_session(key)
            assert session == session3
            assert 'isDirection' not in session

            ###################################################################
            # Key should be converted to direction session
            ###################################################################
            key = service.create_direction_key(session3['jobId'])
            session = service.key_to_session(key)
            assert session['jobId'] == session3['jobId']
            assert service.is_session_direction(session)

@pytest.mark.asyncio
async def test_handle_inbound_message():
    with patch('app.storage_wrapper.StorageWrapper', new_callable=AsyncMock) as mock_storage:
        with patch('app.messaging_wrapper.MessagingWrapper', new_callable=AsyncMock) as mock_message:
            service = app.decision_module.DecisionModule(mock_storage, mock_message)

            # Test bad input I
            res = await service.handle_inbound_message("_input", "")
            assert res == "ignored"

            # Test bad input II
            res = await service.handle_inbound_message("_input", {})
            assert res == "ignored"

            # Assert ok input
            assert await service.handle_inbound_message("_input", {"data": ""})

            # Assert ok input
            assert await service.handle_inbound_message("_input", {"data": {'feedback': '', 'session': {'jobId': ''}}})   

@pytest.mark.asyncio
@patch('app.decision_module.load_json_from_file', mock_loadJsonFromFile)
async def test_handle_config_update():
    with patch('app.storage_wrapper.StorageWrapper', new_callable=AsyncMock) as mock_storage:
        with patch('app.messaging_wrapper.MessagingWrapper', new_callable=AsyncMock) as mock_message:
            service = app.decision_module.DecisionModule(mock_storage, mock_message)
            one_job = {"jobs": {"invalid": ""}}
            # ###################################################################
            # # should register "one job"
            # ###################################################################
            result = await service.handle_config_update(one_job)
            assert result is None
