import json

import pytest

from unittest.mock import patch, AsyncMock

from app.messaging_wrapper import MessagingWrapper

def test_messaging_wrapper_I():
    wrapper = MessagingWrapper()
    ###################################################################
    # generateMessage should accept previous correlation id
    ###################################################################
    data = {"a": 'b'}
    origMsg = "corr"
    out = wrapper.generate_message(data, origMsg)
    #assert origMsg["correlationId"] == out["correlationId"]

    ###################################################################
    # generateMessage should generate new correlation id
    ###################################################################
    data = {"a": 'b'}
    out = wrapper.generate_message({})
    assert len(out["correlationId"]) > 0
    assert isinstance(out["correlationId"], str)

    ###################################################################
    # generateMessage should accept objects
    ###################################################################
    data = {"a": 'b'}
    out = wrapper.generate_message(data)
    assert out["data"] == data

@pytest.mark.asyncio
async def test_messaging_wrapper_II():
    with patch('azure.iot.device.aio.IoTHubModuleClient', new_callable=AsyncMock) as mock_client:
        wrapper = MessagingWrapper(client=mock_client,
                                   feedback_output='feedback',
                                   direction_output='direction')
        ###################################################################
        # send_feedback should wrap message into data
        ###################################################################
        data = {"a": 'b'}    
        await wrapper.send_feedback(data)

        # Is "feedback" in message?
        assert "feedback" in mock_client.send_message_to_output.call_args.args
        # Is data in message? .data needed to access the content of iot-message
        assert "data" in mock_client.send_message_to_output.call_args.args[0]
        assert "a" in json.loads(mock_client.send_message_to_output.call_args.args[0])["data"]

@pytest.mark.asyncio
async def test_messaging_wrapper_III():
    with patch('azure.iot.device.aio.IoTHubModuleClient', new_callable=AsyncMock) as mock_client:
        wrapper = MessagingWrapper(client=mock_client,
                                   feedback_output='feedback',
                                   direction_output='direction')
        ###################################################################
        # sendDirection should wrap message into data
        ###################################################################
        data = {"a": 'b'}
        await wrapper.send_direction(data) 
        # Is "direction" in message?
        assert "direction" in mock_client.send_message_to_output.call_args.args
        # Is data in message? .data needed to access the content of iot-message
        assert "data" in mock_client.send_message_to_output.call_args.args[0]
        print(mock_client.send_message_to_output.call_args.args[0])
        assert "a" in json.loads(mock_client.send_message_to_output.call_args.args[0])["data"]