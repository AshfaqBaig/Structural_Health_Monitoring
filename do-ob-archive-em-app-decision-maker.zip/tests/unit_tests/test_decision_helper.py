from app.decision_helper import extract_plies
#from app.decision_helper import cad_data_to_job_plies
#from app.decision_helper import simplify_mapping
from app.decision_helper import get_feedback_locations
from app.decision_helper import make_x
from app.decision_helper import make_v
from tests.test_resources.mock_data.CADMapping import CAD_MAPPING

import json

def test_extract_plies():
    feedback = [
        {
          "type": 'dxf-id',
          "dxfId": 'mould-10-blade-190-v1',
          "plies": ['id-0'],
          "feedbackLevel": 'detected-plies'
        },
        {
          "type": 'dxf-id',
          "dxfId": 'mould-10-blade-190-v1',
          "plies": ['id-1'],
          "feedbackLevel": 'missing-plies'
        },
        {
          "type": 'dxf-id',
          "dxfId": 'mould-10-blade-190-v1',
          "plies": ['id-1', 'id-3'],
          "feedbackLevel": 'strange-plies'
        }
      ]

    # extractPlies should extact feedback plies based on type detected
    assert extract_plies(feedback, 'detected-plies') == ['id-0']
    # extractPlies should extact feedback plies based on type missing
    assert extract_plies(feedback, 'missing-plies') == ['id-1']
    # multiple Plies
    assert extract_plies(feedback, 'strange-plies') == ['id-1', 'id-3']
    # extractPlies should return empty array if nothing is found
    assert extract_plies(feedback, '') == []
    # extractPlies should return empty array for empty feedback
    assert extract_plies([], 'missing-plies') == []
    # extractPlies should return empty array for undefined
    assert extract_plies('', 'missing-plies') == []

def test_get_feedback_locations(tmpdir):
    locations = [
             {"ply": "221000221", "mid_point": [0, 0, 41821]},
             {"ply": "222000222", "mid_point": [0, 0, 42406]}
        ]
    expected = {
                "221000221": [[0, 0, 41821]],
                "222000222": [[0, 0, 42406]]
        }

    # Mocking file
    fh = tmpdir.join("feedbackLocations.file")
    content_as_json = json.dumps(locations)
    fh.write(content_as_json)

    result = get_feedback_locations(tmpdir.join("feedbackLocations.file"))
    assert result == expected

def test_make_x():
    # make X should create X figure coordinates using the starting point
    given = ([10, 20, 30], 500)
    expected = [
                    [10, 20, 30],
                    [510, 20, 530],
                    [10, 20, 530],
                    [510, 20, 30]
                ]
    assert make_x(given[0], given[1]) == expected

def test_make_v():
    # make V should create V figure coordinates using the starting point
    given = ([10, 20, 30], 500)
    expected = [
                    [10, 20, 530],
                    [260, 20, 30],
                    [510, 20, 530]
                ]
    assert make_v(given[0], given[1]) == expected
