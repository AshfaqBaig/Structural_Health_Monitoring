import json
from unittest.mock import AsyncMock, patch, MagicMock

import etcd3
import pytest

import app.decision_module
from app.utils import load_json_from_file
from tests.test_resources.mock_data.CADMapping import CAD_MAPPING
from tests.test_resources.mock_data.Feedbacks import FEEDBACKS


def mock_loadJsonFromFile(path=""):
    return CAD_MAPPING

# @pytest.mark.asyncio
# @patch('app.decision_module.load_json_from_file', mock_loadJsonFromFile)
# async def test_storage_handler_I():
#     with patch('app.storage_wrapper.StorageWrapper', new_callable=AsyncMock) as mock_storage:
#         with patch('app.messaging_wrapper.MessagingWrapper', new_callable=AsyncMock) as mock_message:
#             service = app.decision_module.DecisionModule(mock_storage, mock_message)

#             ###################################################################
#             # handler function should call feedback handler for feedback input
#             ###################################################################
#             with patch.object(service, 'handle_storage_feedback', return_value=''):
#                 data = {"key": 'jobId#camera-id#module-id',
#                         "value": json.dumps(FEEDBACKS['camera1']['secondPlyMissing']['feedback'])}

#                 await service.update_job_config({"jobId": {}})

#                 return_val = {"jobId#camera-id#module-id": FEEDBACKS['camera1']['secondPlyMissing']['feedback']}
#                 with patch.object(mock_storage, 'get_by_prefix', return_value=return_val):
                    
#                     event = MagicMock()
#                     await service.get_storage_update_listener(event)
                    
#                     assert service.handle_storage_feedback._mock_call_count == 1
#                     assert service.handle_storage_feedback.call_args_list[0].args[0] == 'jobId'

@pytest.mark.asyncio
@patch('app.decision_module.load_json_from_file', mock_loadJsonFromFile)
async def test_storage_handler_II():
    with patch('app.storage_wrapper.StorageWrapper', new_callable=AsyncMock) as mock_storage:
        with patch('app.messaging_wrapper.MessagingWrapper', new_callable=AsyncMock) as mock_message:
            service = app.decision_module.DecisionModule(mock_storage, mock_message)    
            service.handle_storage_direction = AsyncMock(side_effect="1")
            ###################################################################
            # handler function should call direction handler for direction input
            ###################################################################
            JOB_ID = 'key'
            session = {"jobId": JOB_ID }
            feedback = [{"plies": ["id-0"]}]
            sessionKey = service.create_direction_key(session['jobId'])
            data = {
                "key": sessionKey,
                "value": json.dumps(feedback)
            }

            await service.update_job_config({"key": {} })
            await service.handle_storage_update(data)
            assert service.handle_storage_direction._mock_await_count == 1
            expected = (JOB_ID, sessionKey, feedback)
            assert service.handle_storage_direction._mock_call_args[0] == expected

@pytest.mark.asyncio
@patch('app.decision_module.load_json_from_file', mock_loadJsonFromFile)
async def test_storage_handler_III():
    with patch('app.storage_wrapper.StorageWrapper', new_callable=AsyncMock) as mock_storage:
        with patch('app.messaging_wrapper.MessagingWrapper', new_callable=AsyncMock) as mock_message:
            service = app.decision_module.DecisionModule(mock_storage, mock_message)
            ###################################################################
            # handler function should ignore unknown jobs feedbacks if happens
            ###################################################################
            data = {
            "key": 'key1#direction',
            "value": json.dumps('value')
            }
            with patch.object(service, 'handle_unknown_storage_variable', wraps=service.handle_unknown_storage_variable) as wrapped_foo:
                await service.update_job_config({"key": {} })
                await service.handle_storage_update(data)
                assert wrapped_foo.assert_called_once

@pytest.mark.asyncio
@patch('app.decision_module.load_json_from_file', mock_loadJsonFromFile)
async def test_storage_handler_IV():
    with patch('app.storage_wrapper.StorageWrapper', new_callable=AsyncMock) as mock_storage:
        with patch('app.messaging_wrapper.MessagingWrapper', new_callable=AsyncMock) as mock_message:
            service = app.decision_module.DecisionModule(mock_storage, mock_message)
            ###################################################################
            # direction handler should cache and overwrite previous values
            ###################################################################
            await service.update_job_config({
            'job-a': {},
            'job-b': {}
            })

            data1 = {
                    "key": 'job-a#camera-a#module-a',
                    "value": '["value-1"]'
                    }
            data2 = {
                    "key": 'job-b#camera-a#module-a',
                    "value": '["value-2"]'
                    }
            data3 = {
                    "key": 'job-a#camera-a#module-a',
                    "value": '["value-3"]'
                    }
            await service.handle_storage_update(data1)
            await service.handle_storage_update(data2)
            await service.handle_storage_update(data3)
            assert service.get_feedbacks('job-a')['job-a#camera-a#module-a'] == ['value-3']
            assert service.get_feedbacks('job-b')['job-b#camera-a#module-a'] == ['value-2']

def mock_loadJsonFromFile_3(path=""):
    if "unknown-id" in path:
        return CAD_MAPPING
    else:
        return load_json_from_file(path)

@pytest.mark.asyncio
@patch('app.decision_module.load_json_from_file', mock_loadJsonFromFile_3)
async def test_storage_handler_V():
    with patch('app.storage_wrapper.StorageWrapper', new_callable=AsyncMock) as mock_storage:
        with patch('app.messaging_wrapper.MessagingWrapper', new_callable=AsyncMock) as mock_message:
            service = app.decision_module.DecisionModule(mock_storage, mock_message)
            ###################################################################
            # direction handler should forward directions to the message to outbound listeners
            ###################################################################
            JOB_ID = 'key'
            session = {"jobId": JOB_ID }
            sessionKey = service.create_direction_key(session["jobId"])
            with patch.object(mock_message, 'send_direction', new_callable=AsyncMock, return_value=True) as mock:
                feedback = [
                    {
                        "type": 'direction',
                        "plies": ["id-1"]
                    }
                ]

                data = {
                    "key": sessionKey,
                    "value": json.dumps(feedback)
                }

                await service.update_job_config({"key": {}})
                await service.handle_storage_update(data)
                result = {
                            "session": session,
                            "feedback": feedback
                        }
                mock.assert_called_with(result)
