import json
import pytest

from copy import deepcopy

import app.decision_module
from tests.test_resources.mock_data.Jobs import JOBS
from tests.test_resources.mock_data.CADMapping import CAD_MAPPING
from tests.test_resources.mock_data.Feedbacks import FEEDBACKS

from unittest.mock import patch, AsyncMock

def mock_loadJsonFromFile(path=""):
    if "unknown-id" in path:
        return CAD_MAPPING
    return CAD_MAPPING

@pytest.mark.asyncio
@patch('app.decision_module.load_json_from_file', mock_loadJsonFromFile)
async def test_new_inbd_mess_handler_I():
    with patch('app.storage_wrapper.StorageWrapper', new_callable=AsyncMock) as mock_storage:
        with patch('app.messaging_wrapper.MessagingWrapper', new_callable=AsyncMock) as mock_message:
            service = app.decision_module.DecisionModule(mock_storage, mock_message)
            await service.add_jobs(deepcopy(JOBS))
            calculatedFeedback = "id-5"

            ###################################################################
            # inbound message listener should exist
            ###################################################################
            with patch.object(service, 'calculate_new_direction', return_value=calculatedFeedback):
                await service.add_jobs(deepcopy(JOBS))

                assert service.handle_inbound_message is not None

@pytest.mark.asyncio
@patch('app.decision_module.load_json_from_file', mock_loadJsonFromFile)
async def test_new_inbd_mess_handler_II():
    with patch('app.storage_wrapper.StorageWrapper', new_callable=AsyncMock) as mock_storage:
        with patch('app.messaging_wrapper.MessagingWrapper', new_callable=AsyncMock) as mock_message:
            service = app.decision_module.DecisionModule(mock_storage, mock_message)
            await service.add_jobs(deepcopy(JOBS))
            calculatedFeedback = "id-5"

            ###################################################################
            # inbound message should be JSON formatted and ignored when no feedback
            ###################################################################
            with patch.object(service, 'calculate_new_direction', return_value=calculatedFeedback):
                msg = {
                    "data": {
                        "session": {
                            "jobId": 'a-value'
                        },
                        "b": 10,
                        "c": 'date'
                    }
                }
                result = await service.handle_inbound_message('test-input', msg)
                assert result == 'ignored'

@pytest.mark.asyncio
@patch('app.decision_module.load_json_from_file', mock_loadJsonFromFile)
async def test_new_inbd_mess_handler_III():
    with patch('app.storage_wrapper.StorageWrapper', new_callable=AsyncMock) as mock_storage:
        with patch('app.messaging_wrapper.MessagingWrapper', new_callable=AsyncMock) as mock_message:
            service = app.decision_module.DecisionModule(mock_storage, mock_message)
            calculatedFeedback = "id-5"
            await service.add_jobs(deepcopy(JOBS))

            ###################################################################
            # messages without session should be ignored
            ###################################################################
            with patch.object(service, 'calculate_new_direction', return_value=calculatedFeedback):
                msg = {"data": { "a": 'b' }}
                result = await service.handle_inbound_message('test-input', msg)
                assert result == 'ignored'

@pytest.mark.asyncio
@patch('app.decision_module.load_json_from_file', mock_loadJsonFromFile)
async def test_new_inbd_mess_handler_IV():
    with patch('app.storage_wrapper.StorageWrapper', new_callable=AsyncMock) as mock_storage:
        with patch('app.messaging_wrapper.MessagingWrapper', new_callable=AsyncMock) as mock_message:
            service = app.decision_module.DecisionModule(mock_storage, mock_message)
            calculatedFeedback = "id-5"
            await service.add_jobs(deepcopy(JOBS))

            ###################################################################
            # messages without jobId should be ignored
            ###################################################################
            with patch.object(service, 'calculate_new_direction', return_value=calculatedFeedback):
                msg = {
                    "data": {
                        "session": {
                            "a": 'b'
                        }
                    }
                }
                result = await service.handle_inbound_message('test-input', msg)
                assert result == 'ignored'

def mock_loadJsonFromFile_2(path=""):
    if "unknown-id" in path:
        return None
    return CAD_MAPPING

@pytest.mark.asyncio
@patch('app.decision_module.load_json_from_file', mock_loadJsonFromFile_2)
async def test_new_inbd_mess_handler_V():
    with patch('app.storage_wrapper.StorageWrapper', new_callable=AsyncMock) as mock_storage:
        with patch('app.messaging_wrapper.MessagingWrapper', new_callable=AsyncMock) as mock_message:
            service = app.decision_module.DecisionModule(mock_storage, mock_message)
            calculatedFeedback = "id-5"
            await service.add_jobs(deepcopy(JOBS))
            ###################################################################
            # messages with unknown jobId should be ignored
            ###################################################################
            with patch.object(service, 'calculate_new_direction', return_value=calculatedFeedback):
                msg = {
                    "data": {
                        "session": {
                            "jobId": 'unknown-id',
                            "a": 'b'
                        },
                        "feedback": []

                    }
                }

                result = await service.handle_inbound_message('test-input', msg) # Problem was described to Grigorij
                # There is no file for unknown-id (the other way round!)
                assert result == 'ignored'

@pytest.mark.asyncio
@patch('app.decision_module.load_json_from_file', mock_loadJsonFromFile)
async def test_new_inbd_mess_handler_VI():
    with patch('app.storage_wrapper.StorageWrapper', new_callable=AsyncMock) as mock_storage:
        with patch('app.messaging_wrapper.MessagingWrapper', new_callable=AsyncMock) as mock_message:
            service = app.decision_module.DecisionModule(mock_storage, mock_message)
            calculatedFeedback = "id-5"
            await service.add_jobs(deepcopy(JOBS))

            ###################################################################
            # non-JSON inbound messages should raise exception
            ###################################################################
            with patch.object(service, 'calculate_new_direction', return_value=calculatedFeedback):
                nonJson = '{a:B}'
                res = await service.handle_inbound_message('test-input', json.dumps(json.dumps(nonJson)))
                assert res == "ignored"

@pytest.mark.asyncio
@patch('app.decision_module.load_json_from_file', mock_loadJsonFromFile)
async def test_new_inbd_mess_handler_VII():
    with patch('app.storage_wrapper.StorageWrapper', new_callable=AsyncMock) as mock_storage:
        with patch('app.messaging_wrapper.MessagingWrapper', new_callable=AsyncMock) as mock_message:
            service = app.decision_module.DecisionModule(mock_storage, mock_message)
            calculatedFeedback = "id-5"
            await service.add_jobs(deepcopy(JOBS))

            ###################################################################
            # incoming feedback should store feedback to store
            ###################################################################
            with patch.object(service, 'calculate_new_direction', return_value=calculatedFeedback):
                msg = {"data": deepcopy(FEEDBACKS['camera1']['secondPlyMissing'])}
                await service.handle_inbound_message('test-input', msg)

                assert mock_storage.put_key.call_count == 2
                expected = (
                        "job-a#camera-1#em-edge-detection-feedback",
                        deepcopy(FEEDBACKS['camera1']['secondPlyMissing']['feedback'])
                )
                assert mock_storage.put_key._mock_call_args_list[0].args == expected

@pytest.mark.asyncio
@patch('app.decision_module.load_json_from_file', mock_loadJsonFromFile)
async def test_new_inbd_mess_handler_VIII():
    with patch('app.storage_wrapper.StorageWrapper', new_callable=AsyncMock) as mock_storage:
        with patch('app.messaging_wrapper.MessagingWrapper', new_callable=AsyncMock) as mock_message:
            service = app.decision_module.DecisionModule(mock_storage, mock_message)
            calculatedFeedback = "id-5"
            await service.add_jobs(deepcopy(JOBS))

            ###################################################################
            # new direction should be saved to store
            ###################################################################
            with patch.object(service, 'calculate_new_direction', return_value=calculatedFeedback):
                msg = {"data": deepcopy(FEEDBACKS['camera1']['secondPlyMissing'])}
                await service.handle_inbound_message('test-input', msg)

                assert mock_storage.put_key.call_count == 2
                expected = (
                        'job-a#direction',
                        [
                            {
                                "type": "dxf-id",
                                "dxfId": "mould-10-blade-190-v1",
                                "plies": ["id-5"],
                                "feedbackLevel": 'direction'
                            }
                        ]
                )
                assert mock_storage.put_key._mock_call_args_list[1].args == expected
