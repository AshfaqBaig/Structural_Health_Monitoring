from app.decision_module import DecisionModule

import pytest

def test_generateFeedbackMarks():
    # Given
    detectedPlies = ['id-0']
    missingPlies = ['id-1']
    jobId = "118"
    currentPly = 'id-0'
    feedback_locs = {
        'id-0': [[0, 0, 41821]],
        'id-1': [[0, 0, 42406]],
        'id-2': [[0, 0, 42991]],
        'id-3': [[0, 0, 43576]],
        'id-4': [[0, 0, 44162]],
        'id-5': [[0, 0, 44747]],
        'id-6': [[0, 0, 41683]],
        'id-7': [[0, 0, 42268]],
        'id-8': [[0, 0, 42854]],
        'id-9': [[0, 0, 43439]]
      }
    watchedJobs = {}
    watchedJobs[jobId] = {}
    watchedJobs[jobId]['feedbackLocations'] = feedback_locs
    instance = DecisionModule(storage=None, messaging=None)
    instance.watchedJobs = watchedJobs

    # Expected
    expected = [
        {
          "type": 'polyline',
          "coordinates": [[0, 0, 42606], [200, 0, 42406]],
          "feedbackLevel": 'error'
        },
        {
          "type": 'polyline',
          "coordinates": [[0, 0, 42406], [200, 0, 42606]],
          "feedbackLevel": 'error'
        },
        {
          "type": 'polyline',
          "coordinates": [[0, 0, 42021], [100.0, 0, 41821], [200, 0, 42021]],
          "feedbackLevel": 'info'
        }
      ]

    result = instance.generate_feedback_marks(jobId, missingPlies, detectedPlies, currentPly)
    assert result == expected

    #TODO: More tests

@pytest.mark.parametrize("jobId, jobId_Plies, jobId_currentPly, missingPlies, detectedPlies, expected",
    [
        ('1', ['Jan', 'March', 'April', 'June'], 'Jan', ['March'], ['Jan'], "March"),
        ('2', ['Jan', 'March', 'April', 'June'], 'Jan', ['Jan', 'March'], ['April'], "June"),
        ('3', ['Jan', 'March', 'April', 'June'], 'June', ['Jan'], ['Jan', 'March'], "June"),
        ('4', ['Jan', 'March', 'April', 'June'], 'FALSE', ['Jan'], ['Jan', 'March'], "April"),
        ('5', ['Jan', 'March', 'April', 'June'], '', [], [], "Jan"),
        ('6', ['Jan', 'March', 'April', 'June'], 'June', ['Jan', 'March'], ['April'], "June"),
        ('7', ['id-1', 'id-2', 'id-3', 'id-4'], 'id-1', [], ['id-1'], 'id-2')
    ]
)
def test_calculateNewDirection(jobId, jobId_Plies, jobId_currentPly, missingPlies, detectedPlies, expected):
    instance = DecisionModule(storage=None, messaging=None)
    watchedJobs = {}
    watchedJobs[jobId] = {'plies': jobId_Plies, 'currentPly': jobId_currentPly}
    instance.watchedJobs = watchedJobs
    result = instance.calculate_new_direction(jobId, detectedPlies, missingPlies)
    assert result == expected

@pytest.mark.parametrize("key, expected",
    [
        ("343#3434#34", {"jobId": "343", "cameraId": "3434", "moduleId": "34"}),
        ("343#direction#34", {"jobId": "343", "moduleId": "34"}),
        ("343", {"jobId": "343"}),
        ("gfg#54#435#43#gr", {"jobId": "gfg", "cameraId": "54", "moduleId": "435"})
    ]
)
def test_keyToSession(key, expected):
    instance = DecisionModule(storage=None, messaging=None)
    assert instance.key_to_session(key) == expected
    
@pytest.mark.parametrize("session, expected",
    [
        ({"jobId": "gfg", "cameraId": "000", "moduleId": "435"}, "gfg#000#435"),
        ({"jobId": "", "cameraId": "000", "moduleId": ""}, "#000#"),
    ]
)
def test_createFeedbackKey(session, expected):
    instance = DecisionModule(storage=None, messaging=None)
    assert instance.create_feedback_key(session['jobId'], session['cameraId'], session['moduleId']) == expected

def test_set_parameter():
    instance = DecisionModule(storage=None, messaging=None)
    instance.set_parameter("cad_data_path", "a")
    assert instance.cad_data_path == "a"
