from app.utils import get_first_array_item
from app.utils import is_file_readable

import pytest

def test_is_file_readable(tmpdir):
    fh = tmpdir.join("test.file")
    fh.write("Test")    
    assert is_file_readable(fh)
    assert not is_file_readable("fake.file")

def test_get_first_array_item():
    data = [ 
        {
            "type": 'direction',
            "plies": ["id-1"]
        }
    ]

    # Should return first array item
    assert get_first_array_item(data) == data[0]

    # Should throw exception on not array
    with pytest.raises(ValueError): 
        get_first_array_item({})

    # Should throw exception on null array
    with pytest.raises(ValueError): 
        get_first_array_item([])        
