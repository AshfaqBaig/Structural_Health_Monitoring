from copy import deepcopy

import pytest

import app.decision_module
from tests.test_resources.mock_data.Jobs import JOBS
from tests.test_resources.mock_data.CADMapping import CAD_MAPPING
from tests.test_resources.mock_data.FeedbackLocations import FEEDBACK_LOCATIONS
from tests.test_resources.mock_data.FeedbackScenarios import FEEDBACK_SCENARIOS

from unittest.mock import patch, AsyncMock

def mock_loadJsonFromFile(path=""):
    if "history.json" in path:
        return CAD_MAPPING
    elif ".feedbacks.json" in path:
        return FEEDBACK_LOCATIONS        
    else:
        return None

@pytest.mark.asyncio
@patch('app.decision_module.load_json_from_file', mock_loadJsonFromFile)
async def test_scenario_tests():
    for scenario in FEEDBACK_SCENARIOS:
        with patch('app.storage_wrapper.StorageWrapper', new_callable=AsyncMock) as mock_storage:
            with patch('app.messaging_wrapper.MessagingWrapper', new_callable=AsyncMock) as mock_message:

                print("\n\n>>>>>>>>>> Scenario: ", scenario)
                service = app.decision_module.DecisionModule(mock_storage, mock_message)
                await service.add_jobs(deepcopy(JOBS))               
                    
                for feedback in FEEDBACK_SCENARIOS[scenario]['feedbacks']:
                    await service.handle_inbound_message('test-input', {"data": feedback})


                assert len(FEEDBACK_SCENARIOS[scenario]['feedbacks'])*2 == mock_message.send_feedback.call_count
                #assert len(FEEDBACK_SCENARIOS[scenario]['laserOut']) == mock_message.send_feedback.callCount
                assert FEEDBACK_SCENARIOS[scenario]['directionOut'] == mock_message.send_feedback.call_args.args[0]
        
