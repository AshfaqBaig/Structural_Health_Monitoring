""" Defines the Jobs """

JOBS = {
    "job-a": {
        "dxfId": "mould-10-blade-190-v1",
        "plies": ["id-0", "id-1", "id-2", "id-3", "id-4", "id-5", "id-6"],
        "startTime": "2020-11-11 10:00:00Z"
    },
    "job-b": {
        "dxfId": "mould-10-blade-190-v1",
        "plies": ["id-7", "id-8", "id-9", "id-10"],
        "startTime": "2020-11-11 11:00:00Z"
    }
}