""" Defines location of where to draw signs """
# Is actually called "regions"

FEEDBACK_LOCATIONS = [
        {
            "ply": "id-0",
            "mid_point": [
                0,
                0,
                41821
            ]
        },
        {
            "ply": "id-1",
            "mid_point": [
                0,
                0,
                42406
            ]
        },
        {
            "ply": "id-2",
            "mid_point": [
                0,
                0,
                42991
            ]
        },
        {
            "ply": "id-3",
            "mid_point": [
                0,
                0,
                43576
            ]
        },
        {
            "ply": "id-4",
            "mid_point": [
                0,
                0,
                44162
            ]
        },
        {
            "ply": "id-5",
            "mid_point": [
                0,
                0,
                44747
            ]
        },
        {
            "ply": "id-6",
            "mid_point": [
                0,
                0,
                41683
            ]
        },
        {
            "ply": "id-7",
            "mid_point": [
                0,
                0,
                42268
            ]
        },
        {
            "ply": "id-8",
            "mid_point": [
                0,
                0,
                42854
            ]
        },
        {
            "ply": "id-9",
            "mid_point": [
                0,
                0,
                43439
            ]
        }
    ]