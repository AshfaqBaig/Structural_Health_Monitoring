""" Defines the sessions """

SESSIONS = {
    "camera1": {
        "jobId": "job-a",
        "cameraId": "camera-1",
        "moduleId": "em-edge-detection-feedback"
    },
    "camera2": {
        "jobId": "job-a",
        "cameraId": "camera-2",
        "moduleId": "em-edge-detection-feedback"
    },
    "jobA": {
        "jobId": "job-a",
    }
}