""" Denotes the expected results for Laser """

FEEDBACK_MARKS = {
    "error": { # X or Cross
        "id-1": [{ "type": "polyline", "coordinates": [[0, 0, 42406], [200, 0, 42606]], "feedbackLevel": "error" }, { "type": "polyline", "coordinates": [[0, 0, 42606], [200, 0, 42406]], "feedbackLevel": "error" }],
        "id-2": [{ "type": "polyline", "coordinates": [[0, 0, 42991], [200, 0, 43191]], "feedbackLevel": "error" }, { "type": "polyline", "coordinates": [[0, 0, 43191], [200, 0, 42991]], "feedbackLevel": "error" }],
        "id-4": [{ "type": "polyline", "coordinates": [[0, 0, 44162], [200, 0, 44362]], "feedbackLevel": "error" }, { "type": "polyline", "coordinates": [[0, 0, 44362], [200, 0, 44162]], "feedbackLevel": "error" }]
    },
    "info": { # Triangle
        "id-0": { "type": "polyline", "coordinates": [[0, 0, 42021], [100, 0, 41821], [200, 0, 42021]], "feedbackLevel": "info" },
        "id-1": { "type": "polyline", "coordinates": [[0, 0, 42606], [100, 0, 42406], [200, 0, 42606]], "feedbackLevel": "info" },
        "id-4": { "type": "polyline", "coordinates": [[0, 0, 44362], [100, 0, 44162], [200, 0, 44362]], "feedbackLevel": "info" }
    }
}