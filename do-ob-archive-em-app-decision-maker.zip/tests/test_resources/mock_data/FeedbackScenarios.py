""" This creates the Feedback Scenarios """

from .FeedbackMarks import FEEDBACK_MARKS
from .Feedbacks import FEEDBACKS
from .Sessions import SESSIONS

def feedback(feedbackLevel: str, plies: list) -> list:
    return [
        {
            "type": "dxf-id",
            "dxfId": "mould-10-blade-190-v1",
            "plies": plies,
            "feedbackLevel": feedbackLevel
        }
    ]

def feedbackMarks(feedbackLevel: str, plies: list):
    result = FEEDBACK_MARKS[feedbackLevel][plies[0]]
    return result

FEEDBACK_SCENARIOS = {
    "startOfSession": {
        "feedbacks": [
            FEEDBACKS['camera1']['empty'] # Used to set empty cache
        ],
        "laserOut": {
            "session": SESSIONS['camera1'],
            "feedback": []
        },
        "directionOut": {
            "session": SESSIONS['jobA'],
            "feedback": feedback('direction', ["id-0"])
        }
    },
    "secondPlyMissing": {
        "feedbacks": [
            FEEDBACKS['camera1']['empty'],
            FEEDBACKS['camera1']['secondPlyMissing']
        ],
        "laserOut": {
            "session": SESSIONS['camera1'],
            "feedback": [
                feedback('error', ["id-1"]),
                feedbackMarks('error', ["id-1"]),
                feedbackMarks('info', ["id-0"])

            ]
        },
        "directionOut": {
            "session": SESSIONS['jobA'],
            "feedback": feedback('direction', ["id-1"])
        }
    },
    "thirdPlyMissing": {
        "feedbacks": [
            FEEDBACKS['camera1']['empty'],
            FEEDBACKS['camera1']['secondPlyMissing'],
            FEEDBACKS['camera1']['thirdPlyMissing']
        ],
        "laserOut": {
            "session": SESSIONS['camera1'],
            "feedback": [
                feedback('error', ["id-2"]),
                feedbackMarks('error', ["id-2"]),
                feedbackMarks('info', ["id-1"])
            ]
        },
        "directionOut": {
            "session": SESSIONS['jobA'],
            "feedback": feedback('direction', ["id-4"])
        }
    },
    "endOfCamera1": {
        "feedbacks": [
            FEEDBACKS['camera1']['empty'],
            FEEDBACKS['camera1']['secondPlyMissing'],
            FEEDBACKS['camera1']['thirdPlyMissing'],
            FEEDBACKS['camera1']['complete']
        ],
        "laserOut": {
            "session": SESSIONS['camera1'],
            "feedback": []
        },
        "directionOut": {
            "session": SESSIONS['jobA'],
            "feedback": feedback('direction', ["id-4"])
        }
    },
    "startOfSessionCopy": {
        "feedbacks": [
            FEEDBACKS['camera1']['empty']
        ],
        "laserOut": {
            "session": SESSIONS['camera1'],
            "feedback": []
        },
        "directionOut": {
            "session": SESSIONS['jobA'],
            "feedback": feedback('direction', ["id-0"])
        }
    },
    "secondCameraEmpty": {
        "feedbacks": [
            FEEDBACKS['camera1']['secondPlyMissing'],
            FEEDBACKS['camera2']['empty']
        ],
        "laserOut": {
            "session": SESSIONS['camera2'],
            "feedback": []
        },
        "directionOut": {
            "session": SESSIONS['jobA'],
            "feedback": feedback('direction', ["id-1"])
        }
    },
    "firstCameraOverlap": {
        "feedbacks": [
            FEEDBACKS['camera1']['complete'],
            FEEDBACKS['camera2']['camera1Overlap']
        ],
        "laserOut": {
            "session": SESSIONS['camera2'],
            "feedback": []
        },
        "directionOut": {
            "session": SESSIONS['jobA'],
            "feedback": feedback('direction', ["id-4"])
        }
    },
    "secondCameraOneMissing": {
        "feedbacks": [
            FEEDBACKS['camera1']['complete'],
            FEEDBACKS['camera2']['fourMissing'],
        ],
        "laserOut": {
            "session": SESSIONS['camera2'],
            "feedback": [
                feedback('error', ["id-4"]),
                feedbackMarks('error', ["id-4"])
            ]
        },
        "directionOut": {
            "session": SESSIONS['jobA'],
            "feedback": feedback('direction', ["id-6"])
        }
    },
    "firstCameraRepeat": {
        "feedbacks": [
            FEEDBACKS['camera1']['complete'],
            FEEDBACKS['camera2']['fourMissing'],
            FEEDBACKS['camera1']['complete'],
        ],
        "laserOut": {
            "session": SESSIONS['camera1'],
            "feedback": []
        },
        "directionOut": {
            "session": SESSIONS['jobA'],
            "feedback": feedback('direction', ["id-6"])
        }
    },
    "allDone": {
        "feedbacks": [
            FEEDBACKS['camera1']['complete'],
            FEEDBACKS['camera2']['lastPly'],
        ],
        "laserOut": {
            "session": SESSIONS['camera2'],
            "feedback": [feedbackMarks('info', ["id-4"])]
        },
        "directionOut": {
            "session": SESSIONS['jobA'],
            "feedback": feedback('direction', ["id-6"])
        }
    },
}
