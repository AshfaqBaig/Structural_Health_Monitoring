""" Denotes the Feedbacks """

from .Sessions import SESSIONS

FEEDBACKS = {
    "camera1": {
        "empty": {
            "session": SESSIONS['camera1'],
            "feedback": []
        },
        "secondPlyMissing": {
            "session": SESSIONS['camera1'],
            "feedback": [
                {
                    "type": "dxf-id",
                    "dxfId": "mould-10-blade-190-v1",
                    "plies": ["id-0"],
                    "feedbackLevel": "detected-plies"
                },
                {
                    "type": "dxf-id",
                    "dxfId": "mould-10-blade-190-v1",
                    "plies": ["id-1"],
                    "feedbackLevel": "missing-plies"
                }
            ]
        },
        "thirdPlyMissing": {
            "session": SESSIONS['camera1'],
            "feedback": [
                {
                    "type": "dxf-id",
                    "dxfId": "mould-10-blade-190-v1",
                    "plies": ["id-3", "id-1", "id-0"],
                    "feedbackLevel": "detected-plies"
                },
                {
                    "type": "dxf-id",
                    "dxfId": "mould-10-blade-190-v1",
                    "plies": ["id-2"],
                    "feedbackLevel": "missing-plies"
                }
            ]
        },
        "complete": {
            "session": SESSIONS['camera1'],
            "feedback": [
                {
                    "type": "dxf-id",
                    "dxfId": "mould-10-blade-190-v1",
                    "plies": ["id-3", "id-1", "id-0", "id-2"],
                    "feedbackLevel": "detected-plies"
                },
                {
                    "type": "dxf-id",
                    "dxfId": "mould-10-blade-190-v1",
                    "plies": [],
                    "feedbackLevel": "missing-plies"
                }
            ]
        }
    },
    "camera2": {
        "empty": {
            "session": SESSIONS['camera2'],
            "feedback": []
        },
        "camera1Overlap": {
            "session": SESSIONS['camera2'],
            "feedback": [
                {
                    "type": "dxf-id",
                    "dxfId": "mould-10-blade-190-v1",
                    "plies": ["id-2"],
                    "feedbackLevel": "detected-plies"
                },
                {
                    "type": "dxf-id",
                    "dxfId": "mould-10-blade-190-v1",
                    "plies": [],
                    "feedbackLevel": "missing-plies"
                }
            ]
        },
        "threePlies": {
            "session": SESSIONS['camera2'],
            "feedback": [
                {
                    "type": "dxf-id",
                    "dxfId": "mould-10-blade-190-v1",
                    "plies": ["id-4", "id-3", "id-2"],
                    "feedbackLevel": "detected-plies"
                },
                {
                    "type": "dxf-id",
                    "dxfId": "mould-10-blade-190-v1",
                    "plies": [],
                    "feedbackLevel": "missing-plies"
                }
            ]
        },
        "fourMissing": {
            "session": SESSIONS['camera2'],
            "feedback": [
                {
                    "type": "dxf-id",
                    "dxfId": "mould-10-blade-190-v1",
                    "plies": ["id-5", "id-3", "id-2"],
                    "feedbackLevel": "detected-plies"
                },
                {
                    "type": "dxf-id",
                    "dxfId": "mould-10-blade-190-v1",
                    "plies": ["id-4"],
                    "feedbackLevel": "missing-plies"
                }
            ]
        },
        "lastPly": {
            "session": SESSIONS['camera2'],
            "feedback": [
                {
                    "type": "dxf-id",
                    "dxfId": "mould-10-blade-190-v1",
                    "plies": ["id-5", "id-4", "id-6", "id-3", "id-2"],
                    "feedbackLevel": "detected-plies"
                },
                {
                    "type": "dxf-id",
                    "dxfId": "mould-10-blade-190-v1",
                    "plies": [],
                    "feedbackLevel": "missing-plies"
                }
            ]
        }
    }
}