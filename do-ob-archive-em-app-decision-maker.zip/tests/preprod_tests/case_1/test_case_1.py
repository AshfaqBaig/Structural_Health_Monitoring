"""
Test Case 1
Requires a running etcd3-database
"""
import time
from app.decision_module import DecisionModule
from app.storage_wrapper import StorageWrapper

import app.config as cfg

import pytest

@pytest.mark.asyncio
async def test_run(default_session_fixture):
    """Inference server test case configurion goes here"""
    cfg.CAD_DATA_PATH = "tests/test_resources/samples/cad/"
    cfg.CAD_FILE_SUFFIX = ".mapping.json"
    cfg.FEEDBACK_FILE_SUFFIX = ".regions.json"

    cfg.JOB_CONFIG_PATH = "tests/test_resources/samples/jobs/"
    cfg.JOB_FILE_SUFFIX = ".job.json"

    cfg.ETCD_URL = "localhost"
    cfg.ETCD_TTL = 600

    cfg.FEEDBACK_OUTPUT = "feedback"
    cfg.DIRECTION_OUTPUT = "directions"
    cfg.DEFAULT_OUTPUT = "default"

    _, mock_message = default_session_fixture
    storage = StorageWrapper(cfg.ETCD_URL, cfg.ETCD_TTL)

    processor = DecisionModule(storage,
                               mock_message,
                               cad_file_suffix = cfg.CAD_FILE_SUFFIX,
                               cad_data_path = cfg.CAD_DATA_PATH,
                               job_config_path = cfg.JOB_CONFIG_PATH,
                               job_file_suffix = cfg.JOB_FILE_SUFFIX,
                               feedback_file_suffix = cfg.FEEDBACK_FILE_SUFFIX)

    job = {'jobs' :{"2020-12-15-09-s": ""}}
    await processor.handle_config_update(job)
    job = {"jobs": {"invalid": ""}}	
    await processor.handle_config_update(job)
    job = {"jobs": {"20201020-101010-blade-190-team-1-feedback": '{""}'}}
    await processor.handle_config_update(job)
    
    storage_other_module = StorageWrapper(cfg.ETCD_URL, cfg.ETCD_TTL)
    await storage_other_module.put_key("20201020-101010-blade-190-team-1-feedback", [])
    time.sleep(0.5)
    result = await storage.get_by_prefix("20201020-101010-blade-190-team-1-feedback")
