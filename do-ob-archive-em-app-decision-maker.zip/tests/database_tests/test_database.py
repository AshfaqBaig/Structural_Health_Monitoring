import json
import pytest
import sys
import time

from unittest.mock import MagicMock

import requests

from app.storage_wrapper import StorageWrapper

#Ensures etcd-DB is running
res = requests.get("http://localhost:2379")
status = res.status_code
if not status == 404:
    sys.exit(0)

@pytest.mark.asyncio
async def test_basic_functions():
    module = StorageWrapper()
    key = "job-a#camera-2#em-edge-detection-feedback"
    prefix = key.split("#")[0]
    value = [{"type": "dxf-id", "dxfId": "mould-10-blade-190-v1", "plies": ["id-2"], "feedbackLevel": "detected-plies"}, {"type": "dxf-id", "dxfId": "mould-10-blade-190-v1", "plies": [], "feedbackLevel": "missing-plies"}]

    await module.put_key(key, value)
    result = await module.get_by_prefix(prefix)

    assert prefix in result
    assert result[prefix] == json.dumps(value)

@pytest.mark.asyncio
async def test_multiple_module_interaction():
    module_1 = StorageWrapper()
    module_2 = StorageWrapper()

    callback_module_1 = MagicMock()
    callback_module_2 = MagicMock()

    key = "two_module#test"
    prefix = key.split("#")[0] # -> two_module
    value = ['value']

    # Let module_2 watch for prefix
    await module_2.watch_prefix(prefix, callback_module_2)

    # Let module_1 change the prefix
    await module_1.put_key(prefix, value)
    time.sleep(1)

    # Assert Callback Module 2 was called once
    assert callback_module_2.call_count == 1

    # Assert prefix is added to module_2's watchers
    assert 'two_module' in module_2.watchers

    # Let module_1 watch for prefix, as well
    await module_1.watch_prefix(prefix, callback_module_1)
 
    # Assert Callback Module 2 was still called once
    assert callback_module_2.call_count == 1

    # Assert Callback Module 1 was not called
    assert callback_module_1.call_count == 0

    # Assert prefix is added to module_1's watchers
    assert 'two_module' in module_1.watchers

    # Let module_2 change something with prefix
    key = "two_module#test"
    prefix = key.split("#")[0] # -> two_module
    value = ['new_value']
    await module_2.put_key(prefix, value)
    time.sleep(1)

    # Assert that module_1 sees the change
    result = await module_1.get_by_prefix(prefix)
    assert json.loads(result[prefix])[0] == "new_value"

    # Assert Callback Module 1 was called once
    assert callback_module_1.call_count == 1

    # Let module_1 unwatch this prefix
    await module_1.unwatch_prefix(prefix)

    # Let module_2 change something once more
    key = "two_module#test"
    prefix = key.split("#")[0]
    value = ['yet_a_new_value']
    await module_2.put_key(prefix, value)

    # Assert Callback was still called only once
    assert callback_module_1.call_count == 1

    # Assert that module_1 sees the change even though not watched
    result = await module_1.get_by_prefix(prefix)
    assert json.loads(result[prefix])[0] == "yet_a_new_value"

@pytest.mark.asyncio
async def test_get_prefix_is_na():
    module_1 = StorageWrapper()
    result = await module_1.get_by_prefix("Schibboleth")
    assert not result
    assert isinstance(result, dict)

@pytest.mark.asyncio
async def test_unwatch_prefix_is_na():
    module_1 = StorageWrapper()
    await module_1.unwatch_prefix("Schibboleth")

    callback = MagicMock()
    await module_1.watch_prefix("Test", callback)
    await module_1.unwatch_prefix("Schibboleth")
    assert module_1.watchers == {'Test': 0} 
