echo "Executing Pylint"
pylint --rcfile=.pylintrc app/ || pylint-exit --error-fail $?

# Delete Logs
rm -r Noneverifier-*.log 2> /dev/null
rm -r result.xml 2> /dev/null
rm -r .coverage 2> /dev/null
rm -r htmlcov 2> /dev/null
rm -r .pytest_cache 2> /dev/null
