cd etcd-v3.3.1-linux-amd64
./etcdctl del "" --from-key=true
./etcd &